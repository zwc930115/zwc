#ifndef RECVBKBEPS131_H
#define RECVBKBEPS131_H

#include "recvbkbepsbase.h"
#include "beps131.h"
#include "beps132.h"

#include "bpbdsendlist.h" 
#include "bpbdsndcl.h" 
#include "bpbcoutrecvlist.h" 
#include "bpbcoutrcvcl.h" 

class CRecvBkBeps131 : public CRecvbkBepsBase
{
public:
	CRecvBkBeps131();

	~CRecvBkBeps131();

	INT32 Work(LPCSTR szMsg);

private:
	int  UnPack(const char* szmsg);

	int  InsertData(void);

	int  InsertData_bc_cl(void);

	int  InsertData_bc_list(void);

	int  InsertData_bd_cl(void);

	int  InsertData_bd_list(void);

	void SetReply(void);

	int  BuildReplyMsg132(void);

	void ChkSign131(void);

	void AddSign132(void);

	int  DoReply(void);

private:
	beps131          m_cBeps131;

	beps132          m_cBeps132;

	CBpbcoutrcvcl    m_bcsndcl;

	CBpbcoutrecvlist m_bcsndlist;

	CBpbdsndcl       m_bdrcvcl;

	CBpbdsendlist    m_bdrcvlist;

	string           m_strNpcMsg;

	char             m_szRefId[32+1];

	char             m_szMsgId[32+1];

	char             m_szTxId[32+1];

};

#endif /*RECVBEPS131_H*/


