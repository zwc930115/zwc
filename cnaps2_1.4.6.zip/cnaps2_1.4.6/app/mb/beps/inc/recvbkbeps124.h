#ifndef RECVBKBEPS124_H
#define RECVBKBEPS124_H

#include "recvbkbepsbase.h"
#include "beps124.h"

#include "bpbdsendlist.h" 
#include "bpbdsndcl.h" 

#include "bpbcoutrecvlist.h"
#include "bpbcoutsndcl.h"

class CRecvBkBeps124 : public CRecvbkBepsBase
{
public:
	CRecvBkBeps124();

	~CRecvBkBeps124();

	INT32 Work(LPCSTR szMsg);

private:
	int  UnPack(const char* szmsg);

	int  QryOrgnlBiz(void);

	int  InsertData(void);

	int  InsertData_bd_cl(void);

	int  InsertData_bd_list(void);

	int  UpdateOrgnlBiz(void);

	void ChkSign124(void);

	int  CheckValues(void);

	int  FundSettle(void);

	int  ChargeMb(void);
	
	void InsertUserInfoTel(void);

private:
	CBpbdsndcl       m_bdrcvcl;
	CBpbdsendlist    m_bdrcvlist;

	CBpbcoutrecvlist m_orgnlbiz;
	//CBpbcoutsndcl    m_bdrcvcl;

	

	beps124          m_cBeps124;
	
	string           m_strNpcMsg;
};

#endif /*RECVBKBEPS124_H*/


