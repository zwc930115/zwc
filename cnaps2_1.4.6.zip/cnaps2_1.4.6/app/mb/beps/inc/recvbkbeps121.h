/******************************************************************** 
�ļ����� recvbeps121.h
�����ˣ� handongfeng
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __RECVBKBEPS121_H__
#define __RECVBKBEPS121_H__

#include "recvbkbepsbase.h"
#include "beps121.h"
#include "bpbcoutrecvlist.h"
#include "bpbcoutsndcl.h"
#include "bpbcoutsendlist.h"
#include "bpbcoutsendlisthis.h"

class CRecvBkbeps121 : public CRecvbkBepsBase
{
public:
    CRecvBkbeps121();
    ~CRecvBkbeps121();
    int Work(LPCSTR szMsg);
    
private:
    void  CheckSign121();
    INT32 InsertData();
    INT32 SetData(LPCSTR pchMsg);
    INT32 unPack(LPCSTR szMsg);
    void UpdateOrgnlBiz(const string& dbtrbrnchid, const string& txid);
    beps121			    m_cBeps121;
    CBpbcoutsendlist	m_BpList;
    CBpbcoutsndcl		m_Bpcl;
    string  m_strOrgnlTable;
	string  m_strOrgnlTxid;
	string  m_strOrgnlDbtrbrnchid;

};

#endif
