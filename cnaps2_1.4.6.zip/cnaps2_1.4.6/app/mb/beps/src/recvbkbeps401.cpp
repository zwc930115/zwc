/******************************************************************** 
�ļ����� recvbeps401.cpp
�����ˣ� aps-lel
��  �ڣ� 2011-04-25
�޸��ˣ� 
��  �ڣ� 
��  ����С������beps.401���Ĵ�����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkbeps401.h"


CRecvBkbeps401::CRecvBkbeps401()
{

}

CRecvBkbeps401::~CRecvBkbeps401()
{

}

int CRecvBkbeps401::Work(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps401::Work()...");
	
	// ��������
    unPack(szMsg);
	
    SetData(szMsg);
	
    // ��������
    InsertData();
		
	//���ֺ�ǩ
	//CheckSign();    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps401::Work()...");
	
    return OPERACT_SUCCESS;
}

INT32 CRecvBkbeps401::unPack(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps401::unPack()...");
    // �����Ƿ�Ϊ��
    if (NULL == szMsg || '\0' == szMsg)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
    	PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }
	/*
    //��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(iRet != RTN_SUCCESS)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");	
    	PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    */
    m_strWorkDate = m_sWorkDate;    


    // ��������
    iRet = m_cBeps401.ParseXml(szMsg);
	
    if (OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= [%d]", iRet);	
        return iRet;
    }
	
	m_strMsgID = m_cBeps401.MsgId;
	
	ZFPTLOG.SetLogInfo("401", m_strMsgID.c_str());
	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps401::unPack()...");
	
    return OPERACT_SUCCESS;
}

INT32 CRecvBkbeps401::SetData(LPCSTR pchMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps401::SetData()");
	
	m_cBprealtmcstacctmg.m_msgid = m_cBeps401.MsgId		  ;//���ı�ʶ�� 

	m_cBprealtmcstacctmg.m_workdate =  m_sWorkDate 	  ;//��������
	m_cBprealtmcstacctmg.m_msgtp = m_cBeps401.m_PMTSHeader.getMesgType();//��������
	m_cBprealtmcstacctmg.m_mesgid= m_cBeps401.m_PMTSHeader.getMesgID();//ͨ�ż���ʶ��
	m_cBprealtmcstacctmg.m_mesgrefid= m_cBeps401.m_PMTSHeader.getMesgRefID();//ͨ�ż��ο���
	m_cBprealtmcstacctmg.m_instgdrctpty= m_cBeps401.InstgDrctPty  ;//����ֱ�Ӳ������ 
	m_cBprealtmcstacctmg.m_instgpty = m_cBeps401.GrpHdrInstgPty;//����������	  
	m_cBprealtmcstacctmg.m_instddrctpty = m_cBeps401.InstdDrctPty  ;//����ֱ�Ӳ������ 
	m_cBprealtmcstacctmg.m_instdpty = m_cBeps401.GrpHdrInstdPty;//���ղ������	  
	m_cBprealtmcstacctmg.m_syscd = m_cBeps401.SysCd		  ;//ϵͳ���		  
	m_cBprealtmcstacctmg.m_rmk = m_cBeps401.Rmk 		  ;//��ע		
    m_cBprealtmcstacctmg.m_acctpmttp = m_cBeps401.AcctPmtTp;// �˻�֧������ 
    m_cBprealtmcstacctmg.m_acctid = m_cBeps401.AcctId;//  �ͻ��˻��˺�
    m_cBprealtmcstacctmg.m_acctnm = m_cBeps401.AcctNm;//  �ͻ��˻�����
    m_cBprealtmcstacctmg.m_chckmd = m_cBeps401.ChckMd;// У��ģʽ��������֤���㷨�� 
    m_cBprealtmcstacctmg.m_chckcdlen = atoi(m_cBeps401.ChckCdLen.c_str());//  ������֤�볤��
    m_cBprealtmcstacctmg.m_chckcdcntt = m_cBeps401.Cntt;//  ������֤��ֵ
    m_cBprealtmcstacctmg.m_qrybalorststp = m_cBeps401.QryBalOrStsTp;// ��ѯ����״̬ 
    m_cBprealtmcstacctmg.m_procstate = PR_HVBP_01;//OPR_RECVND01 ������
	   
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps401::SetData()");
	
    return OPERACT_SUCCESS;
}

INT32 CRecvBkbeps401::InsertData()
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps401::InsertData()...");
    
	SETCTX(m_cBprealtmcstacctmg);
	
	//��������
	iRet = m_cBprealtmcstacctmg.insert();
	
	if(OPERACT_SUCCESS != iRet)
	{
		 sprintf(m_szErrMsg,"insert() error,error code = [%d] error cause = [%s]",iRet,m_cBprealtmcstacctmg.GetSqlErr());
		 Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);	  
		 PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);

	}

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps401::InsertData()...");
	
    return OPERACT_SUCCESS;
}

int CRecvBkbeps401::CheckSign()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkbeps401::CheckSign...");

	char sOrigenStr[1024] = {0};
	
	sprintf(sOrigenStr,"%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|",
						Trim(m_cBeps401.MsgId).c_str(),
						Trim(m_cBeps401.CreDtTm).c_str(),
						Trim(m_cBeps401.InstgDrctPty).c_str(),
						Trim(m_cBeps401.GrpHdrInstgPty).c_str(),
						Trim(m_cBeps401.InstdDrctPty).c_str(),
						Trim(m_cBeps401.GrpHdrInstdPty).c_str(),
						Trim(m_cBeps401.SysCd).c_str(),					
						Trim(m_cBeps401.AcctPmtTp).c_str(),
						Trim(m_cBeps401.AcctId).c_str(),
						Trim(m_cBeps401.AcctNm).c_str(),
						Trim(m_cBeps401.ChckMd).c_str(),
						Trim(m_cBeps401.QryBalOrStsTp).c_str()
						);


    iRet = checkSignDetached(m_dbproc,signTrim(sOrigenStr),
                            (char *)m_cBeps401.m_szDigitSign.c_str(),
                            Trim(m_cBeps401.InstgDrctPty).c_str()
                            );
	if( RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR, __FILE__, __LINE__, "����ǩ����֤δͨ��,ԭ��:[%s]!",m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, OPT_CHECKSIGN_FAIL, "����ǩ����֤δͨ��!");
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkbeps401::CheckSign...");
	
	return RTN_SUCCESS;
}

int CRecvBkbeps401::DigitSign()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkbeps401::DigitSign...");

	char sOrigenStr[1024] = {0};
	char szDigitSign[4096 + 1] = {0};

	//��ִʱ������
	sprintf(sOrigenStr,"%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s%s|%s|",
						Trim(m_cBeps402.MsgId).c_str(),
						Trim(m_cBeps402.CreDtTm).c_str(),
						Trim(m_cBeps402.InstgDrctPty).c_str(),
						Trim(m_cBeps402.GrpHdrInstgPty).c_str(),
						Trim(m_cBeps402.InstdDrctPty).c_str(),
						Trim(m_cBeps402.GrpHdrInstdPty).c_str(),
						Trim(m_cBeps402.SysCd).c_str(),					
						Trim(m_cBeps402.OrgnlMsgId).c_str(),
						Trim(m_cBeps402.OrgnlInstgPty).c_str(),
						Trim(m_cBeps402.OrgnlMT).c_str(),
						Trim(m_cBeps402.QryBalOrStsTp).c_str(),
						Trim(m_cBeps402.AcctId).c_str(),
						Trim(m_cBeps402.Sts).c_str(),
						Trim(m_cBeps402.RjctCd).c_str(),
						Trim(m_cBeps402.Ccy).c_str(),
						Trim(m_cBeps402.Bal).c_str(),
						Trim(m_cBeps402.AcctSts).c_str()
						);


    iRet = digitSign(m_dbproc,signTrim(sOrigenStr),
                            szDigitSign,
                            SYS_BEPS
                            );
	if( RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR, __FILE__, __LINE__, "���ּ�ǩʧ��,ԭ��:[%s]!",m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, OPT_DIGITSIGN_FAIL, "���ּ�ǩʧ��!");
	}
	m_cBeps402.m_szDigitSign = szDigitSign;

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkbeps401::DigitSign...");
	
	return RTN_SUCCESS;
}

int CRecvBkbeps401::CreatePmtsMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CSendBeps402::CreatePmtsMsg...");
	
    GetIsoDateTime(m_dbproc,SYS_BEPS,m_sIsoWorkDate);
	
	char sErrordsc[1024] = {0};

	char sAmount[25] = {0};
	
	if(false == GetMsgIdValue(m_dbproc, m_sMsgId, eMsgId, SYS_BEPS ))
	{
		Trace(L_INFO,  __FILE__,  __LINE__,NULL, sErrordsc);
		
		PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_MSGID_FAIL, sErrordsc);
	}

	//��ȡ����ͨѶ��	
	GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);


	m_cBeps402.CreateXMlHeader("BEPS", 
								m_sWorkDate,
								m_cBprealtmcstacctmg.m_instgdrctpty.c_str(),
								m_cBprealtmcstacctmg.m_instddrctpty.c_str(),
				  				"beps.402.001.01",
				  				m_sMsgRefId);
				  				
  
	m_cBeps402.MsgId		      = m_sMsgId ;
	m_cBeps402.CreDtTm 		      = m_sIsoWorkDate ;
	m_cBeps402.InstgDrctPty	      = m_cBprealtmcstacctmg.m_instddrctpty ;
	m_cBeps402.GrpHdrInstgPty	  = m_cBprealtmcstacctmg.m_instdpty ;
	m_cBeps402.InstdDrctPty	      = m_cBprealtmcstacctmg.m_instgdrctpty ;
	m_cBeps402.GrpHdrInstdPty	  = m_cBprealtmcstacctmg.m_instgpty ;
	m_cBeps402.SysCd			  = m_cBprealtmcstacctmg.m_syscd ;
	m_cBeps402.Rmk 			      = m_cBprealtmcstacctmg.m_rmk ;
	
	m_cBeps402.OrgnlMsgId		  = m_cBprealtmcstacctmg.m_msgid ;
	m_cBeps402.OrgnlInstgPty	  = m_cBprealtmcstacctmg.m_instgdrctpty ;
	m_cBeps402.OrgnlMT            = "beps.401.001.01" ;

	m_cBeps402.QryBalOrStsTp      = m_cBprealtmcstacctmg.m_qrybalorststp;// ��ѯ����״̬
	m_cBeps402.AcctId             = m_cBprealtmcstacctmg.m_acctid;// �˻��˺�
	
	m_cBeps402.Sts                = "PR02";//�Ѹ��� PR09���Ѿ� ��ҵ��״̬
	m_cBeps402.RjctCd			  = m_cBprealtmcstacctmg.m_rjctcd;//ҵ��ܾ�������
	m_cBeps402.RjctInf            = m_cBprealtmcstacctmg.m_rjctinf ;//ҵ��ܾ���Ϣ
	m_cBeps402.PrcPty             = m_cBprealtmcstacctmg.m_rjcprcpty;//ҵ�����������
	
	m_cBeps402.Bal                = ftoa(sAmount,m_cBprealtmcstacctmg.m_currbal);// ��ǰ��� 
	m_cBeps402.Ccy                = "CNY";// 
	m_cBeps402.AcctSts            = m_cBprealtmcstacctmg.m_acctsts;// ��ǰ�˻�״̬
	
	//���ּ�ǩ
	//DigitSign();
			
	iRet = m_cBeps402.CreateXml();
	
	if (0 != iRet)
	{
		
		sprintf(sErrordsc,"�������˱���ʧ��iRet = [%d]! ",iRet);
		
		Trace(L_ERROR,  __FILE__,  __LINE__,NULL, sErrordsc);
		
		PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, sErrordsc);
	}

	m_cBprealtmcstacctmg.m_msgid  = m_sMsgId;//���±��ı�ʶ��
	
	//ʵʱ��ִ�������	
	InsertData();
	
	AddQueue(m_cBeps402.m_sXMLBuff,m_cBeps402.m_sXMLBuff.size());
	

	//����ԭҵ��״̬
	updateState();
	
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "leave CSendBeps402::CreatePmtsMsg..."); 
    
	return iRet;

}

int CRecvBkbeps401::updateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CRecvBkbeps401::updateState...");

	SETCTX(m_cBprealtmcstacctmg);
	
    string strSQL;
	
	strSQL += "UPDATE BP_REALTMCSTACCTMG  t SET t.PROCSTATE = '04'"; //04:�ѷ���/�Ѵ���/��ȷ��
	
	strSQL += " WHERE t.MSGID = '";
	strSQL += m_cBeps402.OrgnlMsgId;
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_cBeps402.OrgnlInstgPty  + "'"; 
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	
	iRet = m_cBprealtmcstacctmg.execsql(strSQL.c_str());
	
    if(OPERACT_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg,"execsql() error,error code = [%d] error cause = [%s]",iRet,m_cBprealtmcstacctmg.GetSqlErr());
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);		
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);

    }
  
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "leave CRecvBkbeps401::updateState...");
	
    return OPERACT_SUCCESS;
}


