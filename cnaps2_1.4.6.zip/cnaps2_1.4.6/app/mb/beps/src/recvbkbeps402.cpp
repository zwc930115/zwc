/******************************************************************** 
�ļ����� recvbeps402.cpp
�����ˣ� aps-lel
��  �ڣ� 2011-04-25
�޸��ˣ� 
��  �ڣ� 
��  ����С������beps.402���Ĵ�����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkbeps402.h"


CRecvBkbeps402::CRecvBkbeps402()
{

}

CRecvBkbeps402::~CRecvBkbeps402()
{

}

int CRecvBkbeps402::Work(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps402::Work()...");

	// ��������
    unPack(szMsg);
	
    SetData(szMsg);
	
    // ��������
    InsertData();
	
	//���ֺ�ǩ
	CheckSign();

    updateState();
	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps402::Work()...");
	
    return OPERACT_SUCCESS;
}

INT32 CRecvBkbeps402::unPack(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps402::unPack()...");
    int iRet = -1;
    // �����Ƿ�Ϊ��
    if (NULL == szMsg || '\0' == szMsg)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
    	PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }
	/*
    //��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(iRet != RTN_SUCCESS)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");	
    	PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    */
    m_strWorkDate = m_sWorkDate;    

    // ��������
    iRet = m_cBeps402.ParseXml(szMsg);
	
    if (OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= [%d]", iRet);	
        PMTS_ThrowException(OPT_PRS_MSG_FAIL);
    }

	m_strMsgID = m_cBeps402.MsgId;
	
	ZFPTLOG.SetLogInfo("402", m_strMsgID.c_str());

	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps402::unPack()...");
	
    return OPERACT_SUCCESS;
}

INT32 CRecvBkbeps402::SetData(LPCSTR pchMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps402::SetData()");
	
	m_cBprealtmcstacctmg.m_msgid = m_cBeps402.MsgId		  ;//���ı�ʶ�� 

	m_cBprealtmcstacctmg.m_workdate =  m_sWorkDate 	  ;//��������

	m_cBprealtmcstacctmg.m_instgdrctpty= m_cBeps402.InstgDrctPty  ;//����ֱ�Ӳ������ 
	m_cBprealtmcstacctmg.m_instgpty = m_cBeps402.GrpHdrInstgPty;//����������	  
	m_cBprealtmcstacctmg.m_instddrctpty = m_cBeps402.InstdDrctPty  ;//����ֱ�Ӳ������ 
	m_cBprealtmcstacctmg.m_instdpty = m_cBeps402.GrpHdrInstdPty;//���ղ������	  
	m_cBprealtmcstacctmg.m_syscd = m_cBeps402.SysCd		  ;//ϵͳ���		  
	m_cBprealtmcstacctmg.m_rmk = m_cBeps402.Rmk 		  ;//��ע		
    m_cBprealtmcstacctmg.m_qrybalorststp= m_cBeps402.QryBalOrStsTp;// �˻�֧������ 
    m_cBprealtmcstacctmg.m_acctid = m_cBeps402.AcctId;//  �ͻ��˻��˺�
    m_cBprealtmcstacctmg.m_rjctcd = m_cBeps402.RjctCd;//  �ͻ��˻�����
    m_cBprealtmcstacctmg.m_rjctinf = m_cBeps402.RjctInf;// У��ģʽ��������֤���㷨�� 
    m_cBprealtmcstacctmg.m_rjcprcpty = m_cBeps402.PrcPty;//  ������֤�볤��
    m_cBprealtmcstacctmg.m_currbal = atof(m_cBeps402.Bal.c_str());//  ������֤��ֵ
    m_cBprealtmcstacctmg.m_acctsts = m_cBeps402.AcctSts;// ��ѯ����״̬ 	
	   
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps402::SetData()");
	
    return OPERACT_SUCCESS;
}

INT32 CRecvBkbeps402::InsertData()
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps402::InsertData()...");
    
	SETCTX(m_cBprealtmcstacctmg);
	
	//��������
	iRet = m_cBprealtmcstacctmg.insert();
	if(OPERACT_SUCCESS != iRet)
	{
		sprintf(m_szErrMsg,"insert() error,error code = [%d] error cause = [%s]",iRet,m_cBprealtmcstacctmg.GetSqlErr());
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg); 	 
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);

	}

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps402::InsertData()...");
	
    return OPERACT_SUCCESS;
}

int CRecvBkbeps402::CheckSign()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkbeps402::CheckSign...");

    int iRet = -1;
	char sOrigenStr[1024] = {0};
	
	sprintf(sOrigenStr,"%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s%s|%s|",
						Trim(m_cBeps402.MsgId).c_str(),
						Trim(m_cBeps402.CreDtTm).c_str(),
						Trim(m_cBeps402.InstgDrctPty).c_str(),
						Trim(m_cBeps402.GrpHdrInstgPty).c_str(),
						Trim(m_cBeps402.InstdDrctPty).c_str(),
						Trim(m_cBeps402.GrpHdrInstdPty).c_str(),
						Trim(m_cBeps402.SysCd).c_str(),					
						Trim(m_cBeps402.OrgnlMsgId).c_str(),
						Trim(m_cBeps402.OrgnlInstgPty).c_str(),
						Trim(m_cBeps402.OrgnlMT).c_str(),
						Trim(m_cBeps402.QryBalOrStsTp).c_str(),
						Trim(m_cBeps402.AcctId).c_str(),
						Trim(m_cBeps402.Sts).c_str(),
						Trim(m_cBeps402.RjctCd).c_str(),
						Trim(m_cBeps402.Ccy).c_str(),
						Trim(m_cBeps402.Bal).c_str(),
						Trim(m_cBeps402.AcctSts).c_str()
						);



    iRet = checkSignDetached(m_dbproc,signTrim(sOrigenStr),
                            (char *)m_cBeps402.m_szDigitSign.c_str(),
                            Trim(m_cBeps402.InstgDrctPty).c_str()
                            );
	if( RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR, __FILE__, __LINE__, "����ǩ����֤δͨ��,ԭ��:[%s]!",m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, OPT_CHECKSIGN_FAIL, "����ǩ����֤δͨ��!");
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkbeps402::CheckSign...");
	
	return RTN_SUCCESS;
}

int CRecvBkbeps402::updateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CRecvBkbeps402::updateState...");

	SETCTX(m_cBprealtmcstacctmg);
	
    string strSQL;
	
	strSQL += "UPDATE BP_REALTMCSTACCTMG  t SET t.PROCSTATE = '04'"; //04:�ѷ���/�Ѵ���/��ȷ��
	
	strSQL += " WHERE t.MSGID = '";
	strSQL += m_cBeps402.OrgnlMsgId.c_str();
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_cBeps402.OrgnlInstgPty.c_str(); 
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());

	iRet =  m_cBprealtmcstacctmg.execsql(strSQL.c_str());
    if(OPERACT_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg,"execsql() error,error code = [%d] error cause = [%s]",iRet,m_cBprealtmcstacctmg.GetSqlErr());
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);		
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);

    }
   
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "leave CRecvBkbeps402::updateState...");
    return OPERACT_SUCCESS;
}


