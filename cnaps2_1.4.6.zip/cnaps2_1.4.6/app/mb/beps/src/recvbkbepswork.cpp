/********************************************************************
文件名：recvbkbepswork.cpp
创建人：zhj
日  期：2011-03-03
修改人：
日  期：
描  述：接收行内小额往帐线程工作类
版  本：
Copyright (c) 2011  YLINK
********************************************************************/
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "pubfunc.h"
#include "logger.h"
#include "recvbkbepswork.h"
#include "bprecvmsg.h"
#include "recvbkbepsbase.h"
#include "recvbkbeps121.h"
#include "recvbkbeps122.h"
#include "recvbkbeps123.h"
#include "recvbkbeps124.h"
#include "recvbkbeps125.h"
#include "recvbkbeps127.h"
#include "recvbkbeps128.h"
#include "recvbkbeps130.h"
#include "recvbkbeps131.h"
#include "recvbkbeps132.h"
#include "recvbkbeps133.h"
#include "recvbkbeps134.h"
#include "recvbkbeps381.h"
#include "recvbkbeps383.h"
#include "recvbkbeps385.h"
#include "recvbkbeps387.h"
#include "recvbkbeps388.h"
#include "recvbkbeps389.h"
#include "recvbkbeps392.h"
#include "recvbkbeps393.h"
#include "recvbkbeps394.h"
#include "recvbkbeps395.h"
#include "recvbkbeps396.h"
#include "recvbkbeps398.h"
#include "recvbkbeps397.h"
#include "recvbkbeps399.h"
#include "recvbkbeps401.h"
#include "recvbkbeps402.h"
#include "recvbkbeps403.h"
#include "recvbkbeps404.h"
#include "recvbkbeps720.h"
#include "recvbkbeps722.h"
#include "recvbkbeps724.h"

#include "recvbkbeps411.h"
#include "recvbkbeps412.h"
#include "recvbkbeps413.h"
#include "recvbkbeps415.h"
#include "recvbkbeps416.h"
#include "recvbkbeps417.h"


#include "recvbkbeps418.h"
#include "recvbkbeps419.h"
#include "recvbkpkg003.h"
#include "recvbkpkg004.h"
#include "recvbkpkg005.h"
#include "recvbkpkg006.h"
#include "recvbkpkg007.h"
#include "recvbkpkg008.h"
#include "recvbkpkg001.h"
#include "recvbkpkg002.h"
#include "recvbkpkg009.h"
#include "recvbkpkg012.h"
#include "recvbkpkg013.h"
//#include "recvbkcmt320.h"
#include "recvbkcmt324.h"
#include "recvbkcmt325.h"
//#include "recvbkcmt328.h"


using namespace ZFPT;

extern CConnectPool *g_DBConnPool;
extern int		g_IsConnPlatm;

CRecvbkBepsWork::CRecvbkBepsWork()
{
	m_sTrsCode = "";
    m_sMsgFile = "";
    m_strMsgID = "";		
}

CRecvbkBepsWork::~CRecvbkBepsWork()
{	
}

void CRecvbkBepsWork::setData(LPTSTR lpMsgID, int iErrMsgFlag, UINT32 len, LPCSTR data, LPCSTR lpTrsCode, LPCSTR lpMsgFile)
{
    
    if(NULL != data && 0 != len)
    {
        m_vData.resize(len + 1, 0);
    
        memset(&m_vData[0], 0, len * sizeof(char));
        memcpy(&m_vData[0], data, len);
    }
    
    if(lpTrsCode != NULL)
    {
        m_sTrsCode = lpTrsCode;
    }
    
    if(lpMsgFile != NULL)
    {
        m_sMsgFile = lpMsgFile;
    }
    
    if (NULL != lpMsgID)
    {
        m_strMsgID = lpMsgID;
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgID = %s", m_strMsgID.c_str());	
    }

    m_iErrMsgFlag = iErrMsgFlag;
}

void CRecvbkBepsWork::clear()
{
	
}

INT32 CRecvbkBepsWork::doWork()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbkBepsWork::doWork()");	

    // 大报文消息没传过来，需要从来帐通讯表取消息
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_vData.size() = %d", m_vData.size());	

	int iRet		= -1;
	int iBizCode	= -1; 
	int iVersion	= -1;
	
/*	if (0 == m_vData.size()) //当报文长度大于2000时,work从表里取;小于2000时,通过setdata设置
    {
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "0 == m_vData.size()");	

		iRet = GetMsg();
        if (0 != iRet)
        {
            return RTN_FAIL;
        }

        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "GetMsg() success");	
    }    
*/    
    

    //取业务码   
	iBizCode = GetBizCode(&m_vData[0], iVersion);	
    if (-1 == iBizCode)
    {
        return RTN_FAIL;
    }
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iBizCode = %d", iBizCode);	
    
    char szchBizCode[MAX_BIZ_CODE_LEN + 1] = {0};  // 业务码
    sprintf(szchBizCode, "%d", iBizCode);

    char sBizCode[MAX_BIZ_CODE_LEN + 1] = {0};  // 日志用
    sprintf(sBizCode, "%03d", iBizCode);
    
	CRecvbkBepsBase *PRecv = NULL;
		
    switch( iBizCode )
    {
        case 121:
        {
            PRecv = new CRecvBkbeps121;
            break;
        }
        case 1:
        {
            PRecv = new CRecvBkPkg001;
            break;
        }
        case 2:
        {
            PRecv = new CRecvBkPkg002;
            break;
        }
        case 3:
        {
            PRecv = new CRecvBkPkg003;
            break;
        }          
        case 4:
        {
            PRecv = new CRecvBkPkg004;
            break;
        }    
        case 122:
        {
            PRecv = new CRecvBkbeps122;
            break;
        }		
        case 123:
        {
            PRecv = new CRecvBkBeps123;
            break;
        }
        case 124:
        {
            PRecv = new CRecvBkBeps124;
            break;
        }
        case 125:
        {
            PRecv = new CRecvBkBeps125;
            break;
        }		
        case 127:
        {
            PRecv = new CRecvBkbeps127;
            break;
        }
      
        case 128:
        {
            PRecv = new CRecvBkBeps128;
            break;
        } 
        case 130:
        {
            PRecv = new CRecvBkBeps130;
            break;
        }   
        case 131:
        {
            PRecv = new CRecvBkBeps131;
            break;
        }   
        case 132:
        {
            PRecv = new CRecvBkBeps132;
            break;
        } 
        case 133:
        {
            PRecv = new CRecvBkBeps133;
            break;
        }   
        case 134:
        {
            PRecv = new CRecvBkBeps134;
            break;
        }
		case 720:
        {
            PRecv = new CRecvBkbeps720;
            break;
        }
		case 722:
        {
            PRecv = new CRecvBkbeps722;
            break;
        }
		case 724:
        {
            PRecv = new CRecvBkbeps724;
            break;
        }		
        case 324:
        {
            PRecv = new CRecvBkCmt324;
            break;
        }
        case 325:
        {
            PRecv = new CRecvBkCmt325;
            break;
        }  		
		case 381:
        {
            PRecv = new CRecvBkbeps381;
            break;
        }
		case 383:
        {
            PRecv = new CRecvBkbeps383;
            break;
        }
		case 385:
        {
            PRecv = new CRecvBkbeps385;
            break;
        }		
		case 387:
        {
            PRecv = new CRecvBkbeps387;
            break;
        }	
		case 388:
        {
            PRecv = new CRecvBkbeps388;
            break;
        }	
		case 389:
        {
            PRecv = new CRecvBkbeps389;
            break;
        }	
		case 392:
        {
            PRecv = new CRecvBkbeps392;
            break;
        }			
		case 393:
        {
            PRecv = new CRecvBkBeps393;
            break;
        }		
		case 394:
        {
            PRecv = new CRecvBkbeps394;
            break;
        }			
		case 395:
        {
            PRecv = new CRecvBkbeps395;
            break;
        }		
		case 396:
        {
            PRecv = new CRecvbkbeps396;
            break;
        }		
		case 398:
        {
            PRecv = new CRecvbkbeps398;
            break;
        }		                        
		case 401:
        {
            PRecv = new CRecvBkbeps401;
            break;
        }
		case 402:
        {
            PRecv = new CRecvBkbeps402;
            break;
        }
		case 403:
        {
            PRecv = new CRecvBkbeps403;
            break;
        }
		case 404:
        {
            PRecv = new CRecvBkbeps404;
            break;
        }

        case 411:
        {
            PRecv = new CRecvBkBeps411;
            break;
        }
        case 412:
        {
            PRecv = new CRecvBkBeps412;
            break;
        }        
        case 413:
        {
            PRecv = new CRecvBkBeps413;
            break;
        }     
        case 415:
        {
            PRecv = new CRecvBkBeps415;
            break;
        }
        case 416:
        {
            PRecv = new CRecvBkBeps416;
            break;
        }
         case 417:
        {
            PRecv = new CRecvBkBeps417;
            break;
        }
		case 418:
        {
            PRecv = new CRecvBkbeps418;
            break;
        }
		case 419:
        {
            PRecv = new CRecvBkbeps419;
            break;
        }
        case 5:
        {
            PRecv = new CRecvBkPkg005;
            break;
        }
        case 6:
        {
            PRecv = new CRecvBkPkg006;
            break;
        }
        case 7:
        {
            PRecv = new CRecvBkPkg007;
            break;
        }
        case 8:
        case 10:
        case 11:
        {
            PRecv = new CRecvBkPkg008;
            break;
        }        
        case 9:
        {
            PRecv = new CRecvBkPkg009;
            break;
        }     
        case 12:
        {
            PRecv = new CRecvBkPkg012;
            break;
        }
        case 13:
        {
            PRecv = new CRecvBkPkg013;
            break;
        }
        default:
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "switch defult");
            return RTN_FAIL;
        }
    }
	
	PRecv->m_strBizCode  = szchBizCode;
	PRecv->m_iMsgVer	 = iVersion;
	PRecv->m_strRcvMsgID = m_strMsgID;
	PRecv->m_iErrMsgFlag = m_iErrMsgFlag;
	
	ZFPTLOG.SetLogInfo(sBizCode, NULL);

	PRecv->doWork(&m_vData[0]);
	if (NULL != PRecv)
	{
	   
//       Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBepsWork::doWork11()");
		delete PRecv;
//        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBepsWork::doWork13()");
		PRecv = NULL;
//        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBepsWork::doWork22()");
        
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBepsWork::doWork()");

    return RTN_SUCCESS;
}

/******************************************************************************
*  Function:   GetMsg
*  Description:从来帐通讯表取消息
*  Input:	   无
*  Output:	   
*  Return:	   0   : 操作成功,
			   其他: 操作失败
*  Others:	   无
*  Author:	   zys
*  Date:	   2011-02-21
*******************************************************************************/
INT32 CRecvbkBepsWork::GetMsg(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBepsWork::GetMsg");	

	int    iRet = RTN_FAIL;
	DBProc cDBProc;

	// 获取数据库连接
	iRet = g_DBConnPool->GetConnect(cDBProc);
	if(0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "GetConnect failed");
		return iRet;	
	}

	CBprecvmsg CBprecvmsg;
	iRet= CBprecvmsg.setctx(cDBProc);
	if (0 != iRet)
	{
		g_DBConnPool->PutConnect(cDBProc);//释放连接
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CBprecvmsg.setctx error[%d]", iRet);	
		return iRet;
	}

	CBprecvmsg.m_msgid  = m_strMsgID;
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_strMsgID = %s", m_strMsgID.c_str());	
	
	// 从来帐通讯表取消息
	iRet = CBprecvmsg.findByPK();
	if (RTN_SUCCESS == iRet)
	{
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "CBprecvmsg.findByPK success");	
		m_vData.resize(CBprecvmsg.m_msgtext.length() + 1, 0);	
		memset(&m_vData[0], 0, CBprecvmsg.m_msgtext.length() * sizeof(char));
		memcpy(&m_vData[0], CBprecvmsg.m_msgtext.c_str(), CBprecvmsg.m_msgtext.length());
	}
	else
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CBprecvmsg.findByPKfailed[%d]", iRet);
	}

	//释放连接
	g_DBConnPool->PutConnect(cDBProc);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBepsWork::GetMsg");

	return iRet;
}


