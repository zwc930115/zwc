#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkbeps722.h"

using namespace ZFPT;

CRecvBkbeps722::CRecvBkbeps722()
{
}

CRecvBkbeps722::~CRecvBkbeps722()
{

}

INT32 CRecvBkbeps722::Work(LPCSTR szMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps722::Work()");

	//do nothing	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps722::Work()");
	return 0;
}
