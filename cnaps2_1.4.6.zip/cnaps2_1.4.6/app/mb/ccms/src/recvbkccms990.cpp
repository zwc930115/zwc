/******************************************************************** 
文件名： recvccms990.cpp
创建人： xlz
日  期： 2011-03-08
修改人： hq
日  期：
描  述： 通信级确认报文<ccms.990.001.02>来账处理*
版  本：
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkccms990.h"

using namespace ZFPT;

CRecvBkCcms990::CRecvBkCcms990()
{
    memset(m_sMsgTp,      0x00, sizeof(m_sMsgTp));
    memset(m_sSqlStr,     0x00, sizeof(m_sSqlStr));
    memset(m_sListSql,    0x00, sizeof(m_sListSql));
    memset(m_sOriSql,     0x00, sizeof(m_sOriSql));
    memset(m_sOriListSql, 0x00, sizeof(m_sOriListSql));
 m_strProcSts = "";
}


CRecvBkCcms990::~CRecvBkCcms990()
{
  
}

INT32 CRecvBkCcms990::Work(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms990::doWork()");
    
    // 解析报文O
    unPack(pchMsg);

    // 状态转换s
    TransProcSts();
 

    // 更新业务表状态F
    UpdateData();

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms990::doWork()");
    return RTN_SUCCESS;
}

INT32 CRecvBkCcms990::unPack(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms990::unPack()");

    int iRet = -1;
    
    // 报文是否为空-
    if (NULL == pchMsg || '\0' == pchMsg)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");
    	PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "报文为空");
    }
    
    // 解析报文t
    iRet = m_ccms990.ParseXml(pchMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文解析出错");
    }

    ZFPTLOG.SetLogInfo("990", m_ccms990.MsgId.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_ccms990.MsgId = [%s]", m_ccms990.MsgId .c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_ccms990.MT    = [%s]", m_ccms990.MT .c_str());
 
    if ( 7 == m_ccms990.MT.length() )
    {
    	memcpy(m_sMsgTp, m_ccms990.MT.c_str()+1, 6);
    }
    else
    {
    	memcpy(m_sMsgTp, m_ccms990.MT.c_str() + 5, 3);
    }

    // 测试信息c
    //Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_ccms990.OrigSndr = [%s]", m_ccms990.OrigSndr .c_str());
    //Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_ccms990.OrigSndDt= [%s]", m_ccms990.OrigSndDt.c_str());
    //Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_ccms990.MT       = [%s]", m_ccms990.MT       .c_str());
    //Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_ccms990.MsgId    = [%s]", m_ccms990.MsgId    .c_str());
    //Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_ccms990.MsgRefId = [%s]", m_ccms990.MsgRefId .c_str());
    //Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_ccms990.MsgPrcCd = [%s]", m_ccms990.MsgPrcCd .c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sMsgTp           = [%s]", m_sMsgTp);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms990::unPack()"); 
    return RTN_SUCCESS;
}

void CRecvBkCcms990::TransProcSts()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms990::TransProcSts()");

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strProcSts = [%s]", m_ccms990.MsgPrcCd.c_str()); 
    
    if ( 0 == strncmp(m_ccms990.MsgPrcCd.c_str()+4,"0000",4))
    {       
        m_strProcSts = PR_HVBP_13;
    }
    else if ( 0 == strncmp(m_ccms990.MsgPrcCd.c_str()+4,"0001" ,4))
    {
        m_strProcSts  = PR_HVBP_12;//PR_HVBP_09;
    }
    else if ( 0 == strncmp(m_ccms990.MsgPrcCd.c_str()+4,"0002" ,4))
    {
        m_strProcSts  = PR_HVBP_12; //PR_HVBP_10;
    }
    else if ( 0 == strncmp(m_ccms990.MsgPrcCd.c_str()+4,"0003",4 ))
    {
        m_strProcSts  = PR_HVBP_12;//PR_HVBP_11;
    }
    else if ( 0 == strncmp(m_ccms990.MsgPrcCd.c_str()+4,"0004",4 ))
    {
        m_strProcSts  = PR_HVBP_12;
    }
    else
    {
     	m_strProcSts  = PR_HVBP_12;
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms990::TransProcSts()");
} 

INT32 CRecvBkCcms990::UpdateData(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms990::UpdateData()");
 
    int iRet      = 0;
    
    // 设置连接
    SETCTX(m_centitybase);

    // ****************** 大额报文 ******************
    //客户发起汇兑业务报文/金融机构发起汇兑业务报文*
    if( 0 == strcmp("111"   , m_sMsgTp) || 0 == strcmp("112"   , m_sMsgTp)
    		|| 0 == strcmp("CMT100", m_sMsgTp) || 0 == strcmp("CMT101", m_sMsgTp)
    		|| 0 == strcmp("CMT102", m_sMsgTp) || 0 == strcmp("CMT103", m_sMsgTp)
    		|| 0 == strcmp("CMT105", m_sMsgTp) || 0 == strcmp("CMT108", m_sMsgTp)
    		|| 0 == strcmp("CMT121", m_sMsgTp) || 0 == strcmp("CMT122", m_sMsgTp)
    		|| 0 == strcmp("CMT123", m_sMsgTp) || 0 == strcmp("CMT124", m_sMsgTp) )
    {
    	PubUpSql("HV_SNDEXCHGLIST", "STATETIME");
    }
    //即时转账报文H
    else if( 0 == strcmp("141"   , m_sMsgTp) 
    		|| 0 == strcmp("CMT231", m_sMsgTp) || 0 == strcmp("CMT232", m_sMsgTp)
    		|| 0 == strcmp("CMT407", m_sMsgTp) || 0 == strcmp("CMT408", m_sMsgTp) )
    {
    	PubUpSql("HV_TROFACSNDLIST", "STATETIME");
    }
    //PVP结算申请信息报文A
    else if( 0 == strcmp("143" ,m_sMsgTp) )
    {
    	PubUpSql_("HV_PVPSETOFAC", "STATETIME");
    }
    //申请清算银行汇票资金报文/银行汇票申请退回业务报文=
    else if( 0 == strcmp("151" ,m_sMsgTp) || 0 == strcmp("153" ,m_sMsgTp) )
    {
    	PubUpSql("HV_DRAFT", "STATETIME");
    }
    //多边轧差净额结算报文"
    else if( 0 == strcmp("631", m_sMsgTp) )
    {
    	PubUpSql_("HV_MNETSTLCL", "STATETIME");
    }
    //多边净额业务撤销申请报文L
    else if( 0 == strcmp("634", m_sMsgTp) )
    {
    	PubUpSql_("HV_MNETSTLMCXL", "STATETIME");
    }
    // ****************** 小额报文 ******************
    //客户发起普通贷记业务报文/金融机构发起普通贷记业务报文5
    //实时贷记业务报文/定期贷记业务报文?
    //普通借记业务回执报文/CIS通用回执业务报文?
 	//实时借记业务回执报文/定期借记业务回执报文?
    else if( 0 == strcmp("121",    m_sMsgTp) || 0 == strcmp("122",    m_sMsgTp)
        || 0 == strcmp("123",    m_sMsgTp) || 0 == strcmp("125",    m_sMsgTp)
        || 0 == strcmp("128",    m_sMsgTp) || 0 == strcmp("130",    m_sMsgTp)
        || 0 == strcmp("132",    m_sMsgTp) || 0 == strcmp("134",    m_sMsgTp)
        || 0 == strcmp("PKG001", m_sMsgTp) || 0 == strcmp("PKG003", m_sMsgTp)
        || 0 == strcmp("PKG005", m_sMsgTp) || 0 == strcmp("PKG007", m_sMsgTp)
        || 0 == strcmp("PKG008", m_sMsgTp) || 0 == strcmp("PKG010", m_sMsgTp)
        || 0 == strcmp("PKG011", m_sMsgTp) )
    {
    	PubUpSql("BP_BCOUTSNDCL", "STATETIME"); //汇总t
    	m_bpbcsndcl.setctx(m_dbproc);
         
        if( (0 == strcmp("128",    m_sMsgTp) || 0 == strcmp("130",    m_sMsgTp)
        		|| 0 == strcmp("132",    m_sMsgTp) || 0 == strcmp("134",    m_sMsgTp)
        		|| 0 == strcmp("PKG008", m_sMsgTp) || 0 == strcmp("PKG009", m_sMsgTp)
        		|| 0 == strcmp("PKG010", m_sMsgTp) || 0 == strcmp("PKG011", m_sMsgTp))
        		&& m_ccms990.MsgPrcCd != "0000" )
        {
        	PubListSql(&m_bpbcsndcl, "BP_BCOUTSENDLIST", 0); //明细+原业务m
        }
        else
        {
            PubListSql(&m_bpbcsndcl, "BP_BCOUTSENDLIST", 0); //明细_
        }
    }
    //实时贷记回执业务报文/普通借记业务报文P
    //实时借记业务报文/定期借记业务报文?
    else if( 0 == strcmp("124" ,m_sMsgTp) || 0 == strcmp("127" ,m_sMsgTp)
       || 0 == strcmp("131" ,m_sMsgTp)    || 0 == strcmp("133" ,m_sMsgTp)
       || 0 == strcmp("PKG002" ,m_sMsgTp) || 0 == strcmp("PKG006" ,m_sMsgTp)
       || 0 == strcmp("PKG004" ,m_sMsgTp) || 0 == strcmp("PKG009" ,m_sMsgTp) )
    {
    	PubUpSql("BP_BDSNDCL", "STATETIME");
        m_bpbdsndcl.setctx(m_dbproc);
            
        if( (0 == strcmp("124" ,m_sMsgTp) || 0 == strcmp("PKG009" ,m_sMsgTp))
          && /*m_ccms990.MsgPrcCd != "0000"*/ m_strProcSts !="13")
        {
            PubListSql(&m_bpbdsndcl, "BP_BDSENDLIST", 0); //明细+原业务s
        }
        else
        {
            PubListSql(&m_bpbdsndcl, "BP_BDSENDLIST", 0); //明细+
        }
    }
    //批量代收业务报文/批量代收业务回执报文P
    //批量代付业务报文/批量代付业务回执报文P
    //实时代收业务报文/实时代收业务回执报文P
    //实时代付业务报文/实时代付业务回执报文P
    //388/389/390/391/392/393/394/395暂未加P
    else if( 0 == strcmp("380" ,m_sMsgTp) || 0 == strcmp("381" ,m_sMsgTp)
       || 0 == strcmp("382" ,m_sMsgTp) || 0 == strcmp("383" ,m_sMsgTp)
       || 0 == strcmp("384" ,m_sMsgTp) || 0 == strcmp("385" ,m_sMsgTp)
       || 0 == strcmp("386" ,m_sMsgTp) || 0 == strcmp("387" ,m_sMsgTp) )
    {
    	PubUpSql("BP_COLLTNCHRGSCL", "STATETIME");

        m_bpcoll.setctx(m_dbproc);
        
        if( ( 0 == strcmp("381" ,m_sMsgTp) || 0 == strcmp("383" ,m_sMsgTp) )
        		&& /*m_ccms990.MsgPrcCd != "0000"*/m_strProcSts !="13" )
        {
        	PubListSql(&m_bpcoll, "BP_COLLTNCHRGSLIST", 1);
        }
        else
        {
            PubListSql(&m_bpcoll, "BP_COLLTNCHRGSLIST", 0);
        }
    }
    else if(0 == strcmp("389" ,m_sMsgTp) || 0 == strcmp("388" ,m_sMsgTp))     //增加小额389
    {
    	PubUpSql_("BP_BIZPUBNTCE", "PROCTIME");
    }
    //主动缴款查询报文/主动缴款通知报文E
    //397,399没有发起权限,不需要处理?
    //add 2012-6-29  zql
    else if( 0 == strcmp("392" ,m_sMsgTp) || 0 == strcmp("393" ,m_sMsgTp))
    {
    	PubUpSql_("BP_CSTCTRCTMGCL", "STATETIME");
    }
    //add 2012-6-29  zql
    else if(0 == strcmp("394" ,m_sMsgTp) || 0 == strcmp("395" ,m_sMsgTp))
    {
    	PubUpSql_("BP_CSTACCTQRYCL", "STATETIME");
    }
    else if( 0 == strcmp("396" ,m_sMsgTp)  )
    {
    	PubUpSql_("BP_GETTX", "PROCTIME");
    }
    else if(0 == strcmp("398" ,m_sMsgTp))
    {
    	PubUpSql_("BP_BKTOCSTDCNTFCTN", "PROCTIME");
    }
    //客户账户实时查询报文/客户账户实时查询应答报文t
    else if( 0 == strcmp("401" ,m_sMsgTp) || 0 == strcmp("402" ,m_sMsgTp) )
    {
    	PubUpSql_("BP_REALTMCSTACCTMG", "PROCTIME");
    }
    //发票打印申请报文R
    else if( 0 == strcmp("403" ,m_sMsgTp) )
    {
    	PubUpSql_("BP_INVCPRTAPPLY", "PROCTIME");
    }
    //发票打印回应报文:更新原申请报文"
    else if( 0 == strcmp("404" ,m_sMsgTp))
    {
    	m_bpinvc.setctx(m_dbproc);
    	//PubListSql(&m_bpinvc, "BP_INVCPRTRSPN");
    	PubUpSql_("BP_INVCPRTRSPN", "PROCTIME");
    }
    //借记业务止付申请报文/借记业务止付应答报文;
    else if( 0 == strcmp("411" ,m_sMsgTp) || 0 == strcmp("412" ,m_sMsgTp)
        || 0 == strcmp("CMT327" ,m_sMsgTp) || 0 == strcmp("CMT328" ,m_sMsgTp) )
    {
    	PubUpSql_("BP_CSTBDPCXLCL", "STATETIME");
	 
    	if ( (0 == strcmp("CMT328" ,m_sMsgTp) )
    			&& /*m_ccms990.MsgPrcCd != "0000" */m_strProcSts =="13") //更新申请报文M
    	{
    		PubOriSql("BP_CSTBDPCXLCL", "BP_CSTBDPCXLCL", "STATETIME", "k.OSQLMSGID||k.OSQINSTGPTY", m_sOriSql);
    		//m_bpcstb.setctx(m_dbproc);
    		//   PubListSql(&m_bpcstb, "BP_CSTBDPCXLCL");
    	}
    }
    //实时业务冲正申请报文(
    //实时业务冲正应答报文(没发起权限,不处理)
    else if( 0 == strcmp("413" ,m_sMsgTp) )
    {
    	PubUpSql_("BP_CSTPMTCXL", "PROCTIME");
    }
    //支票圈存管理报文/支票圈存管理应答报文"
    else if( 0 == strcmp("418" ,m_sMsgTp) || 0 == strcmp("419" ,m_sMsgTp) || 0 == strcmp("PKG013" ,m_sMsgTp) )
    {
    	PubUpSql_("BP_CHCKCDTFORLD", "PROCTIME");
        
    	if ( 0 == strcmp("419" ,m_sMsgTp) && /*m_ccms990.MsgPrcCd != "0000"*/m_strProcSts !="13" ) //更新申请报文P
    	{
    		//  m_bpchck.setctx(m_dbproc);
    		//  PubListSql(&m_bpchck, "BP_CHCKCDTFORLD");
    	}
    }
    // ****************** 公共报文 ******************
    //自由格式报文*
    else if( 0 == strcmp("303" ,m_sMsgTp) || 0 == strcmp("CMT303" ,m_sMsgTp) )
    {
    	PubUpSql("CM_FREEINFO", "STATETIME");
    }
    //业务撤销申请报文R
    else if( 0 == strcmp("307" ,m_sMsgTp) || 0 == strcmp("CMT311" ,m_sMsgTp) )
    {
    	PubUpSql("CM_TRANSREPEAL", "STATETIME");
    }
    //通用非签名信息业务报文"
    else if( 0 == strcmp("310" ,m_sMsgTp) || 0 == strcmp("311" ,m_sMsgTp)
    		|| 0 == strcmp("312" ,m_sMsgTp) || 0 == strcmp("313" ,m_sMsgTp) )
    {
    	PubUpSql_("CM_CNOTSGNINFBIZ", "PROCTIME");
        
    	if ( (0 == strcmp("311" ,m_sMsgTp) || 0 == strcmp("313" ,m_sMsgTp))
    			&& /*m_ccms990.MsgPrcCd != "0000"*/m_strProcSts !="13" ) //更新申请报文3
    	{
    		//m_cmcnot.setctx(m_dbproc);
            //PubListSql(&m_cmcnot, "CM_CNOTSGNINFBIZ");
    	}
    }
    else if(0 == strcmp("PKG012" ,m_sMsgTp))
    {
    	PubUpSql_("BP_COLLTNCHRGSCL", "STATETIME");
    }
    //业务查询报文/业务查复报文m
    else if( 0 == strcmp("314" ,   m_sMsgTp) || 0 == strcmp("315"   , m_sMsgTp)
    		|| 0 == strcmp("CMT301", m_sMsgTp) || 0 == strcmp("CMT302", m_sMsgTp) )
    {
    	//由于CMT301,302收不到900 为配合对账特殊处理 ,如果PMTS成功则修改业务状态为PR00
    	if( (0 == strcmp("CMT301", m_sMsgTp) || 0 == strcmp("CMT302", m_sMsgTp)) &&
    			m_strProcSts == PR_HVBP_13 )
    	{
    		string PrcCdtmp = m_ccms990.MsgPrcCd;
    		m_ccms990.MsgPrcCd = PROCESS_PR00; // 这里是将CMT301 302表中的BUSISTATE改为"PR00" 处理状态改为PMTS成功
    		PubUpSql("CM_TRANSINFOQRY", "STATETIME", "BUSISTATE");
    		m_ccms990.MsgPrcCd = PrcCdtmp; //将原来的值放回去 后面还要用。
    	}
    	else
    	{
    		PubUpSql("CM_TRANSINFOQRY", "STATETIME");
    	}
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "处理码=[%s]",m_ccms990.MsgPrcCd.c_str());
    	if ( 0 == strcmp("CMT302", m_sMsgTp) && m_strProcSts =="13" ) //更新查询报文C
    	{
    		//如果收到302的990成功报文则修改301的回应状态。
    		//m_cmtrinq.setctx(m_dbproc);
    		// PubListSql(&m_cmtrinq, "CM_TRANSINFOQRY");
    		PubOriSql("CM_TRANSINFOQRY", "CM_TRANSINFOQRY", "STATETIME", "k.QORGNLMSGID||k.QORGNLINSTGDRCTPTY", m_sOriSql);
    	}
    }
    //by add zql 增加对309状态修改 310只接受不发起F
    else if( 0 == strcmp("CMT309" ,   m_sMsgTp) )
    {
    	PubUpSql_("HV_SEALERR", "STATETIME");
    }
    //探测请求报文"
    else if( 0 == strcmp("991" ,   m_sMsgTp) )
    {
    	PubUpSql_("CM_CHCKREQRSPN", "STATETIME");
    }
    //业务状态查询申请报文R
    else if( 0 == strcmp("316" ,m_sMsgTp) || 0 == strcmp("CMT651" ,m_sMsgTp) )
    {
    	PubUpSql("CM_TRANSSTQRY", "STATETIME");
    }
    //业务退回申请报文/业务退回应答报文E
    else if( 0 == strcmp("318" ,m_sMsgTp) || 0 == strcmp("319" ,m_sMsgTp) ||
    		0 == strcmp("CMT313" ,m_sMsgTp)  || 0 == strcmp("CMT314" ,m_sMsgTp) ||
    		0 == strcmp("CMT319" ,m_sMsgTp)  || 0 == strcmp("CMT320" ,m_sMsgTp) )
    {
    	PubUpSql("CM_PMTRTRCL", "STATETIME");
    	/*
     	 if ( (0 == strcmp("CMT314" ,m_sMsgTp) ||
           	   0 == strcmp("CMT320" ,m_sMsgTp) ) &&
            	m_strProcSts =="13" ) //更新申请报文?
     	 {
         	 m_cmpmtr.setctx(m_dbproc);
          	  PubListSql(&m_cmpmtr, "CM_PMTRTRCL");
     	 }
    	 */
    	if( (0 == strcmp("CMT314" ,m_sMsgTp) ||
    			0 == strcmp("CMT320" ,m_sMsgTp) )
    			&& m_strProcSts =="13" ) //更新查询报文C
    	{
    		PubOriSql("CM_PMTRTRCL", "CM_PMTRTRCL", "STATETIME", "k.ORGNLMSGID||k.ORGNINSTGDRCTPTY", m_sOriSql);
    	}
    }
    //数字证书绑定管理通知报文/数字证书下载申请报文)
    else if( 0 == strcmp("903" ,m_sMsgTp) ||0 == strcmp("919" ,m_sMsgTp) )
    {
    	PubUpSql_("CM_BNDDIGCERT", "STATETIME");
    }
    //清算帐户信息查询B
    else if( 0 == strcmp("366" ,m_sMsgTp))
    {
    	PubUpSql_("SA_ACCTINFQRYRSPN", "PROCTIME");
    }
    //登录退出申请报文A
    else if( 0 == strcmp("805" ,m_sMsgTp))
    {//不用做更新，数据库中没有存该报文信息C
    	Trace(L_INFO, __FILE__, __LINE__, NULL, "不用做更新，数据库中没有存该报文信息");
    	return RTN_SUCCESS;
    }
    else if( 0 == strcmp("350" ,m_sMsgTp))
    {
    	PubUpSql("SA_NTRYLIMTQRY", "PROCTIME");
    }
    else if( 0 == strcmp("353" ,m_sMsgTp) )
    {
    	PubUpSql("SA_NETDBTLMTDSTRBTNMGMT", "proctime", "PrcCd", "procstate");
    }
    else if( 0 == strcmp("354" ,m_sMsgTp))
    {
    	PubUpSql_("SA_DBTWRNAPP", "PROCTIME");
    }
    else if( 0 == strcmp("361" ,m_sMsgTp))
    {
        PubUpSql_("SA_BALWRNGMG", "PROCTIME");
    }
    else if( 0 == strcmp("365" ,m_sMsgTp) || 0 == strcmp("363" ,m_sMsgTp) )
    {
        PubUpSql_("SA_QAINFOQRY", "PROCTIME");
    }
    else if( 0 == strcmp("368" ,m_sMsgTp))
    {
        PubUpSql_("SA_BALWRNGMG", "PROCTIME");
    }
    else if( 0 == strcmp("371" ,m_sMsgTp) )
	{
    	PubUpSql("SA_AcctMgmtAppl", "prcdt", "PrcCd", "procstate");
	}
    else if( 0 == strcmp("373" ,m_sMsgTp))
    {
        PubUpSql_("SA_FNDSOFPOOLMGMT", "PROCTIME");
    }
    else if( 0 == strcmp("374" ,m_sMsgTp) || 0 == strcmp("375" ,m_sMsgTp) )
    {
        PubUpSql_("SA_INTRBKLNMGMT", "PROCTIME");
    }
    else if( 0 == strcmp("376" ,m_sMsgTp) || 0 == strcmp("377" ,m_sMsgTp) )
    {
        PubUpSql_("SA_LQDTYTFR", "PROCTIME");
    }
    else if( 0 == strcmp("376" ,m_sMsgTp) || 0 == strcmp("377" ,m_sMsgTp) )
    {
        PubUpSql_("SA_LQDTYTFR", "PROCTIME");
    }
    else if( 0 == strcmp("405" ,m_sMsgTp) || 0 ==  strcmp("407" ,m_sMsgTp))
    {
        PubUpSql_("SA_NETGQMGMT", "PROCTIME");
    }
    else if( 0 == strcmp("614" ,m_sMsgTp))
    {
        PubUpSql_("SA_PIBKLNQRYAPPL", "PROCTIME");
    }
 else if(   0 == strcmp("722" ,m_sMsgTp) || 0 == strcmp("724" ,m_sMsgTp)
		 || 0 == strcmp("720", m_sMsgTp) || 0 == strcmp("710", m_sMsgTp)
		 || 0 == strcmp("712", m_sMsgTp) || 0 == strcmp("714", m_sMsgTp))
 {//不用做更新，数据库中没有存该报文信息
        Trace(L_INFO, __FILE__, __LINE__, NULL, "不用做更新，数据库中没有存该报文信息");
        return RTN_SUCCESS;
 } 
 else
 {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "不支持的报文类型[%s]不做处理", m_sMsgTp);
		return RTN_SUCCESS;
        //PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "不支持的报文类型");
 }
 
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sSqlStr     = [%s]", m_sSqlStr);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sListSql    = [%s]", m_sListSql);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sOriSql     = [%s]", m_sOriSql);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sOriListSql = [%s]", m_sOriListSql);

    // 执行SQL，修改业务处理状态_
 iRet = m_centitybase.execsql(m_sSqlStr);
    if (iRet == SQLNOTFOUND)
    {
     Trace(L_ERROR, __FILE__, __LINE__, NULL,"no data found[%s][%s]", m_sMsgTp, m_ccms990.MsgId.c_str());
    }
    else if (iRet != SQL_SUCCESS)
    {
        sprintf(m_szErrMsg,  "更新原业务状态失败[%d][%s]", iRet, m_centitybase.GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
    }

    // 执行SQL，修改明细业务处理状态,
 if ( NULL != m_sListSql && '\0' != m_sListSql && 0 < strlen(m_sListSql) )
    {
        iRet = m_centitybase.execsql(m_sListSql);
        if (iRet == SQLNOTFOUND)
        {
         Trace(L_INFO, __FILE__, __LINE__, NULL,"更新时未找到数据[%s][%s]", m_sMsgTp, m_ccms990.MsgId.c_str());
        }
        else if (iRet != SQL_SUCCESS)
        {
            sprintf(m_szErrMsg,  "更新原业务状态失败[%d][%s]", iRet, m_centitybase.GetSqlErr());
            Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
            PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
        }
    }

    // 执行SQL，修改原业务处理状态F
 if ( NULL != m_sOriSql && '\0' != m_sOriSql && 0 < strlen(m_sOriSql) )
    {
        iRet = m_centitybase.execsql(m_sOriSql);
        if (iRet == SQLNOTFOUND)
        {
         Trace(L_INFO, __FILE__, __LINE__, NULL,"更新时未找到数据[%s][%s]", m_sMsgTp, m_ccms990.MsgId.c_str());
        }
        else if (iRet != SQL_SUCCESS)
        {
            sprintf(m_szErrMsg,  "更新原业务状态失败[%d][%s]", iRet, m_centitybase.GetSqlErr());
            Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
            PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
        }
    }

    // 执行SQL，修改原明细业务处理状态_
 if ( NULL != m_sOriListSql && '\0' != m_sOriListSql && 0 < strlen(m_sOriListSql) )
    {
        iRet = m_centitybase.execsql(m_sOriListSql);
        if (iRet == SQLNOTFOUND)
        {
         Trace(L_INFO, __FILE__, __LINE__, NULL,"更新时未找到数据[%s][%s]", m_sMsgTp, m_ccms990.MsgId.c_str());
        }
        else if (iRet != SQL_SUCCESS)
        {
            sprintf(m_szErrMsg,  "更新原业务状态失败[%d][%s]", iRet, m_centitybase.GetSqlErr());
            Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
            PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
        }
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms990::UpdateData()");
    return RTN_SUCCESS;
}

void CRecvBkCcms990::PubUpSql(LPCSTR sTableNm, LPCSTR sTimeNm, LPCSTR sPrcCdNm, LPCSTR sPrcStsNm)
{
    //人行990报文,没有系统号,不能按系统号去更新C
 sprintf(m_sSqlStr, "UPDATE %s t SET "
                  "t.%s = sysdate,"
                     "t.%s = '%s',"
                  "t.%s = '%s' "
                  " WHERE t.MESGID = '%s' "
                  " and t.MESGREFID = '%s'"
                  " and t.%s = '%s'  and procstate='08' ",   //and rsflag<>'2'
                  sTableNm,
                  sTimeNm,  
                  sPrcCdNm,   
                  m_ccms990.MsgPrcCd.c_str(),
                  sPrcStsNm, 
                  m_strProcSts.c_str(),                              
                  m_ccms990.MsgId.c_str(),
                  m_ccms990.MsgRefId.c_str(),
                  sPrcStsNm, 
                  PR_HVBP_08);
                   
    Trace(L_INFO, __FILE__, __LINE__, NULL, "m_sSqlStr = [%s]", m_sSqlStr);
}

void CRecvBkCcms990::PubUpSql_(LPCSTR sTableNm, LPCSTR sTimeNm)
{
    //人行990报文,没有系统号,不能按系统号去更新P
    
    if ( 0 == strcmp(sTableNm, "BP_CSTBDPCXLCL") || 0 ==strcmp(sTableNm,"BP_INVCPRTAPPLY") || 0 ==strcmp(sTableNm,"BP_INVCPRTRSPN"))        /*加入往来标识判断*/
    {
  		sprintf(m_sSqlStr, "UPDATE %s t SET "
                   "t.%s = sysdate,"
                   "t.PROCSTATE = '%s' "
                   " WHERE t.MESGID = '%s' "
                   " and t.MESGREFID = '%s'"
                   " and t.PROCSTATE = '%s' and t.RSFLAG = '1'",
                   sTableNm,
                   sTimeNm,
                   m_strProcSts.c_str(),                              
                   m_ccms990.MsgId.c_str(),
                   m_ccms990.MsgRefId.c_str(),
                   PR_HVBP_08);
    }
    else if (0 == strcmp(sTableNm, "BP_CSTACCTQRYCL"))
    {
    	sprintf(m_sSqlStr, "UPDATE %s t SET "
                   "t.%s = sysdate,"
                   "t.PROCSTATE = '%s' "
                   " WHERE t.MESGID = '%s' "
                   " and t.MESGREFID = '%s'"
                   " and t.PROCSTATE = '%s' and t.SRCFLAG != '2'",
                   sTableNm,
                   sTimeNm,
                   m_strProcSts.c_str(),                              
                   m_ccms990.MsgId.c_str(),
                   m_ccms990.MsgRefId.c_str(),
                   PR_HVBP_08);	
    }
    else
 	{
	  sprintf(m_sSqlStr, "UPDATE %s t SET "
	                   "t.%s = sysdate,"
	                   "t.PROCSTATE = '%s' "
	                   " WHERE t.MESGID = '%s' "
	                   " and t.MESGREFID = '%s'"
	                   " and t.PROCSTATE = '%s'",
	                   sTableNm,
	                   sTimeNm,
	                   m_strProcSts.c_str(),                              
	                   m_ccms990.MsgId.c_str(),
	                   m_ccms990.MsgRefId.c_str(),
	                   PR_HVBP_08);
 }
                   
    Trace(L_INFO, __FILE__, __LINE__, NULL, "m_sSqlStr = [%s]", m_sSqlStr);
}

void CRecvBkCcms990::PubListSql(CEntityBase* oDbDetail, LPCSTR sTableNm, int sType)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms990::PubListSql()");
    int iRet;
    char sSqlStr[1024 + 1] = {0};
    
    snprintf(sSqlStr, sizeof(sSqlStr) - 1, " mesgid = '%s' and mesgrefid = '%s' and procstate='08' ",
        m_ccms990.MsgId.c_str(), m_ccms990.MsgRefId.c_str());
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "sSqlStr = [%s]", sSqlStr);

    iRet = oDbDetail->find(sSqlStr);
    if (iRet != SQL_SUCCESS)
    {
        sprintf(m_szErrMsg,  "查找原业务信息失败[%d][%s]", iRet, oDbDetail->GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_FIND_BY_PK_FAIL, m_szErrMsg);
    }

    while (SQL_SUCCESS == iRet)
    {
    	
        iRet = oDbDetail->fetch();
        if (iRet == SQLNOTFOUND)
        {
            //Trace(L_DEBUG, __FILE__, __LINE__, NULL, "没有待可取的数据");
            oDbDetail->closeCursor();
            return;
        }
        else if (iRet != SQL_SUCCESS)
        {
            sprintf(m_szErrMsg,  "获取原业务信息失败[%d][%s]", iRet, oDbDetail->GetSqlErr());
            Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
            oDbDetail->closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);                
        }
        
    
        if ( 0 == strcmp(sTableNm, "BP_BCOUTSENDLIST") )        /*贷记往账*/
        {
            BpBcSndSql(sType);
        }
        else if ( 0 == strcmp(sTableNm, "BP_BDSENDLIST") )      /*借记往账*/
        {
            BpBdSndSql(sType);
        }
        else if ( 0 == strcmp(sTableNm, "BP_COLLTNCHRGSLIST") ) /*代收付往账*/
        {
            BpColltSql(sType);
        }
        else if ( 0 == strcmp(sTableNm, "BP_INVCPRTRSPN") )     /*发票打印应答*/
        {
            BpIncvpSql();
        }
        else if ( 0 == strcmp(sTableNm, "BP_CSTBDPCXLCL") )     /*借记业务止付应答*/
        {
            BpcstbdSql();
        }
        else if ( 0 == strcmp(sTableNm, "BP_CHCKCDTFORLD") )    /*支票圈存管理*/
        {
            BpchckcSql();
        }
        else if ( 0 == strcmp(sTableNm, "CM_CNOTSGNINFBIZ") )   /*通用非签名/签名信息*/
        {
            CmCnotsSql();
        }
        else if ( 0 == strcmp(sTableNm, "CM_TRANSINFOQRY") )    /*查询查复*/
        {
            CmTrInQsSql();
        }
        else if ( 0 == strcmp(sTableNm, "CM_PMTRTRCL") )        /*业务退回*/
        {
            CmPmtrtSql();
        }
    }
    oDbDetail->closeCursor();
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvBkCcms990::PubListSql()");
}

void CRecvBkCcms990::PubOriSql(LPCSTR sUpTable, LPCSTR sOriTable, LPCSTR sTimeNm, LPCSTR sColNm, LPTSTR sUpSql)
{
	string rspflag = "rspflag='1' ";

	string sColName = " WHERE t.MSGID||t.INSTGDRCTPTY in ";

	if( 0 == strcmp(sOriTable, "BP_CSTBDPCXLCL") )
	{
		sColName = " WHERE t.MSGID||t.INSTGPTY in ";
	}
	else if( 0 == strcmp(sOriTable, "CM_TRANSINFOQRY"))
	{
		sColName = " WHERE t.MSGID||t.INSTGINDRCTPTY in ";
	}
	else if( 0 == strcmp(sOriTable, "CM_PMTRTRCL")){
		sColName = " WHERE t.MSGID||t.INSTGINDRCTPTY in ";
	}

	sprintf(sUpSql, "UPDATE %s t SET "
					"t.%s = sysdate,"
					"%s"   //"rspflag='1'"
					"%s"//" WHERE t.MSGID||t.INSTGDRCTPTY in "
					" (SELECT %s "
					" FROM %s k"
					" WHERE k.RSFLAG <> '2' AND k.MESGID = '%s' "
					" AND k.MESGREFID = '%s') AND RSFLAG = '2' ",
					sUpTable,
					sTimeNm,
					rspflag.c_str(),
					sColName.c_str(),
					sColNm,
					sOriTable,
					m_ccms990.MsgId.c_str(),
					m_ccms990.MsgRefId.c_str());
	
			
}

void CRecvBkCcms990::BpBcSndSql(int sType)
{
    // 明细c
    snprintf(m_sListSql, sizeof(m_sListSql) - 1, "UPDATE BP_BCOUTSENDLIST t SET "
         "t.STATETIME = sysdate,"
                        "t.PROCSTATE = '%s' "
                        " WHERE t.procstate='08' and t.msgid = '%s' "
                        " and t.InstgDrctPty = '%s'", 
                        m_strProcSts.c_str(),                              
         m_bpbcsndcl.m_msgid.c_str(),
                        m_bpbcsndcl.m_instgdrctpty.c_str());

    // 原业务的汇总和明细_
    if ( 1 == sType )
    {
        snprintf(m_sOriSql, sizeof(m_sOriSql) - 1, "UPDATE BP_BCOUTSNDCL t SET "
            				 "t.STATETIME = sysdate,"
                            "t.PROCSTATE = '%s' "
                            " WHERE t.MSGID||t.INSTGDRCTPTY in "
                            " (SELECT k.ORGNLMSGID||k.ORIINSTGDRCTPTY "
                            " FROM BP_BCOUTSENDLIST k"
                            " WHERE k.MSGID = '%s' "
                            " AND k.INSTGDRCTPTY = '%s')", 
                            m_strProcSts.c_str(),                              
             				m_bpbcsndcl.m_msgid.c_str(),
                            m_bpbcsndcl.m_instgdrctpty.c_str());
                            
        snprintf(m_sOriListSql, sizeof(m_sOriListSql) - 1, "UPDATE BP_BCOUTSENDLIST t SET "
             				"t.STATETIME = sysdate,"
                            "t.PROCSTATE = '%s' "
                            " WHERE t.MSGID||t.INSTGDRCTPTY in "
                            " (SELECT k.ORGNLMSGID||k.ORIINSTGDRCTPTY "
                            " FROM BP_BCOUTSENDLIST k"
                            " WHERE k.MSGID = '%s' "
                            " AND k.INSTGDRCTPTY = '%s')", 
                            m_strProcSts.c_str(),                              
             				m_bpbcsndcl.m_msgid.c_str(),
                            m_bpbcsndcl.m_instgdrctpty.c_str());
    }
}

void CRecvBkCcms990::BpBdSndSql(int sType)
{
 //明细R
    snprintf(m_sListSql, sizeof(m_sListSql) - 1, "UPDATE BP_BDSENDLIST t SET "
         "t.STATETIME = sysdate,"
                        "t.PROCSTATE = '%s' "
                        " WHERE t.procstate='08' and t.msgid = '%s' "
                        " and t.InstgDrctPty = '%s'", 
                        m_strProcSts.c_str(),                              
         m_bpbdsndcl.m_msgid.c_str(),
                        m_bpbdsndcl.m_instgdrctpty.c_str());

    // 原业务的汇总和明细_
    if ( 1 == sType )
    {
        snprintf(m_sOriSql, sizeof(m_sOriSql) - 1, "UPDATE BP_BDSNDCL t SET "
             "t.STATETIME = sysdate,"
                            "t.PROCSTATE = '%s' "
                            " WHERE t.MSGID||t.INSTGDRCTPTY in "
                            " (SELECT k.ORGNLMSGID||k.ORIINSTGDRCTPTY "
                            " FROM BP_BDSENDLIST k"
                            " WHERE k.MSGID = '%s' "
                            " AND k.INSTGDRCTPTY = '%s')", 
                            m_strProcSts.c_str(),                              
             m_bpbdsndcl.m_msgid.c_str(),
                            m_bpbdsndcl.m_instgdrctpty.c_str());
                            
        snprintf(m_sOriListSql, sizeof(m_sOriListSql) - 1, "UPDATE BP_BDSENDLIST t SET "
             "t.STATETIME = sysdate,"
                            "t.PROCSTATE = '%s' "
                            " WHERE t.MSGID||t.INSTGDRCTPTY in "
                            " (SELECT k.ORGNLMSGID||k.ORIINSTGDRCTPTY "
                            " FROM BP_BDSENDLIST k"
                            " WHERE k.MSGID = '%s' "
                            " AND k.INSTGDRCTPTY = '%s')", 
                            m_strProcSts.c_str(),                              
             m_bpbdsndcl.m_msgid.c_str(),
                            m_bpbdsndcl.m_instgdrctpty.c_str());
    }
}

void CRecvBkCcms990::BpColltSql(int sType)
{
    //明细C
    /*
    snprintf(m_sListSql, sizeof(m_sListSql) - 1, "UPDATE BP_COLLTNCHRGSLIST t SET "
         "t.STATETIME = sysdate,"
                        "t.PROCSTATE = '%s' "
                        " WHERE t.msgid = '%s' ", 
                        m_strProcSts.c_str(),                              
         m_bpcoll.m_msgid.c_str());
    */

    // 原业务的汇总和明细;
    /*
    if ( 1 == sType )
    {
        snprintf(m_sOriSql, sizeof(m_sOriSql) - 1, "UPDATE BP_COLLTNCHRGSCL t SET "
             "t.STATETIME = sysdate,"
                            "t.PROCSTATE = '%s' "
                            " WHERE t.MSGID= "
                            " (SELECT k.ORGNLMSGID "
                            " FROM BP_COLLTNCHRGSLIST k"
                            " WHERE k.MSGID = '%s' ", 
                            m_strProcSts.c_str(),                              
             m_bpbdsndcl.m_msgid.c_str());
                            
        snprintf(m_sOriListSql, sizeof(m_sOriListSql) - 1, "UPDATE BP_COLLTNCHRGSLIST t SET "
             "t.STATETIME = sysdate,"
                            "t.PROCSTATE = '%s' "
                            " WHERE t.MSGID = "
                            " (SELECT k.ORGNLMSGID "
                            " FROM BP_COLLTNCHRGSLIST k"
                            " WHERE k.MSGID = '%s' ", 
                            m_strProcSts.c_str(),                              
             m_bpbdsndcl.m_msgid.c_str());
    }
    */
}

void CRecvBkCcms990::BpIncvpSql()
{
    snprintf(m_sOriSql, sizeof(m_sOriSql) - 1, "UPDATE BP_INVCPRTRSPN t SET "
         "t.PROCTIME = sysdate,"
                        "t.PROCSTATE = '%s' "
                        " WHERE t.msgid = '%s' "
                        " and t.InstgDrctPty = '%s'", 
                        m_strProcSts.c_str(),                              
         				m_bpinvc.m_orgnlmsgid.c_str(),
                        m_bpinvc.m_orgnlinstgpty.c_str());
}

void CRecvBkCcms990::BpcstbdSql()
{
    snprintf(m_sOriSql, sizeof(m_sOriSql) - 1, "UPDATE BP_CSTBDPCXLCL t SET "
         "t.STATETIME = sysdate,"
                        "t.PROCSTATE = '%s' "
                        " WHERE t.msgid = '%s' "
                        " and t.InstgDrctPty = '%s' and t.rsflag= '1' ", 
                        m_strProcSts.c_str(), 
         m_bpcstb.m_osqlmsgid.c_str(),
                        m_bpcstb.m_osqinstgpty.c_str());
}

void CRecvBkCcms990::BpchckcSql()
{
    snprintf(m_sOriSql, sizeof(m_sOriSql) - 1, "UPDATE BP_CHCKCDTFORLD t SET "
         "t.PROCTIME = sysdate,"
                        "t.PROCSTATE = '%s' "
                        " WHERE t.MSGID = '%s' "
                        " and t.INSTGDRCTPTY = '%s' and t.SRCFLAG = '1'",
                        m_strProcSts.c_str(),                              
         m_bpchck.m_orgnlmsgid.c_str(),
                        m_bpchck.m_orgnlinstgpty.c_str());
}

void CRecvBkCcms990::CmCnotsSql()
{
    snprintf(m_sOriSql, sizeof(m_sOriSql) - 1, "UPDATE CM_CNOTSGNINFBIZ t SET "
         				"t.PROCTIME = sysdate,"
                        "t.SRCFLAG = '1' "
                        " WHERE t.MSGID = '%s' "
                        " and t.INSTGDRCTPTY = '%s'",                     
         				m_cmcnot.m_orgnlmsgid.c_str(),
                        m_cmcnot.m_orgnlinstgpty.c_str());
}

void CRecvBkCcms990::CmTrInQsSql()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms990::CmTrInQsSql()");
    //人行990报文,没有系统号,不能按系统号去更新y
    snprintf(m_sOriSql, sizeof(m_sOriSql) - 1, "UPDATE CM_TRANSINFOQRY t SET "
                        "t.RSPFLAG = '1' "
                        " WHERE t.MSGID = '%s' "
                        " and t.INSTGINDRCTPTY = '%s' and rsflag = '2'",
         				m_cmtrinq.m_qorgnlmsgid.c_str(),
                        m_cmtrinq.m_qorgnlinstgdrctpty.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvBkCcms990::CmTrInQsSql()");
}

void CRecvBkCcms990::CmPmtrtSql()
{
    //人行990报文,没有系统号,不能按系统号去更新d
    snprintf(m_sOriSql, sizeof(m_sOriSql) - 1, "UPDATE CM_PMTRTRCL t SET t.PROCSTATE='%s', "
                        "t.RSPFLAG = '1' "
                        " WHERE t.MSGID = '%s' "
                        " and t.INSTGDRCTPTY = '%s' and rsflag = '2'",
                        m_strProcSts.c_str(), 
         m_cmpmtr.m_orgnlmsgid.c_str(),
                        m_cmpmtr.m_orgninstgdrctpty.c_str());
}
INT32 CRecvBkCcms990::InsertComsendmb(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms991::InsertComsendmb()");
	
	int    iRet = RTN_FAIL;
	char   sSqlStr[4096] = {0}; 
	string strRval = "";
	 	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "原报文编号 [%s]", m_sMsgTp);
	if( 0 == strcmp("111" ,m_sMsgTp) || 0 == strcmp("112" ,m_sMsgTp) 
	 || 0 == strcmp("CMT100" ,m_sMsgTp) || 0 == strcmp("CMT101" ,m_sMsgTp) 
	 || 0 == strcmp("CMT102" ,m_sMsgTp) || 0 == strcmp("CMT105" ,m_sMsgTp) 
	 || 0 == strcmp("CMT108" ,m_sMsgTp) || 0 == strcmp("CMT121" ,m_sMsgTp) 
	 || 0 == strcmp("CMT122" ,m_sMsgTp) || 0 == strcmp("CMT123" ,m_sMsgTp) 
	 || 0 == strcmp("CMT124" ,m_sMsgTp) || 0 == strcmp("CMT229" ,m_sMsgTp) )
	{
		CHvsndexchglist cHvsndexchglist;
		
		string strSql = "";
		strSql = " MESGID = '";
		strSql += m_ccms990.MsgId;
		strSql +=  "'";

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql[%s]", strSql.c_str());
		
		SETCTX(cHvsndexchglist);
			
		iRet = cHvsndexchglist.find(strSql);
		if(OPERACT_SUCCESS != iRet)
		{
			 sprintf(m_szErrMsg, "cBpbcoutsendlist find fail:  [%d][%s]", 
				 iRet, cHvsndexchglist.GetSqlErr());
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		while(0 == cHvsndexchglist.fetch())
		{
			iRet = GetTagVal(strRval, cHvsndexchglist.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cHvsndexchglist.m_mbmsgid.c_str(), 22);
		    
				//判断间直连，如果是直连就入行内通讯表 by add zql
				if(cHvsndexchglist.m_msgdirect == "0")
				{
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "开始写行内通讯表....");
					//m_strReserve = cHvsndexchglist.m_reserve; //往行内发990时，用于获取原报文类型
					m_strMsgTp = "ccms.990.001.02";
					m_strMsgID = cHvsndexchglist.m_msgid;
					m_strWorkDate= cHvsndexchglist.m_workdate;
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgID=[%s]....",cHvsndexchglist.m_msgid.c_str());
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strWorkDate=[%s]....",cHvsndexchglist.m_workdate.c_str());
				    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "pchMsg=[%s]....",pchMsg);
				    DirectInter(cHvsndexchglist.m_instgindrctpty.c_str(), 
				    			cHvsndexchglist.m_instdindrctpty.c_str(),
				    			cHvsndexchglist.m_instddrctpty.c_str(), 
				    			pchMsg);
			    }
			}
			else if(-2 == iRet)
			{
				Trace(L_INFO,  __FILE__,	__LINE__, NULL, "原业务行内发起系统号为空，该笔业务由客户端发起，不用转至行内。");
				// PMTS_ThrowException(OTH_ERR);
			}
		}
		
		cHvsndexchglist.closeCursor();
	}
    else if(0 == strcmp("143" ,m_sMsgTp) )
	{
		CHvpvpsetofac    cHvpvpsetofac;
		
		string strSql = "";
		strSql = " MESGID = '";
		strSql += m_ccms990.MsgId;
		strSql += "' ";

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql[%s]", strSql.c_str());
		
		SETCTX(cHvpvpsetofac);
			
		iRet = cHvpvpsetofac.find(strSql);
		if(OPERACT_SUCCESS != iRet)
		{
			 sprintf(m_szErrMsg, "cBpbcoutsendlist find fail:  [%d][%s]", 
				 iRet, cHvpvpsetofac.GetSqlErr());
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		while(0 == cHvpvpsetofac.fetch())
		{
			iRet = GetTagVal(strRval, cHvpvpsetofac.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cHvpvpsetofac.m_mbmsgid.c_str(), 22);
		    
				//判断间直连，如果是直连就入行内通讯表 by add zql
				if(cHvpvpsetofac.m_msgdirect =="0")
				{
					//m_strReserve = cHvpvpsetofac.m_reserve; //往行内发990时，用于获取原报文类型
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "开始写行内通讯表....");
					m_strMsgTp = "ccms.990.001.02";
					m_strMsgID = cHvpvpsetofac.m_msgid;
					m_strWorkDate= cHvpvpsetofac.m_workdate;
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgID=[%s]....",cHvpvpsetofac.m_msgid.c_str());
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strWorkDate=[%s]....",cHvpvpsetofac.m_workdate.c_str());
				    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "pchMsg=[%s]....",pchMsg);
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "开始执行DirectInter().....");
				    DirectInter(cHvpvpsetofac.m_instgindrctpty.c_str(), 
				    			cHvpvpsetofac.m_instdindrctpty.c_str(),
				    			cHvpvpsetofac.m_instddrctpty.c_str(), 
				    			pchMsg);
			    }
			}
			else if(-2 == iRet)
			{
				Trace(L_INFO,  __FILE__,	__LINE__, NULL, "原业务行内发起系统号为空，该笔业务由客户端发起，不用转至行内。");
				// PMTS_ThrowException(OTH_ERR);
			}
		}
		
		cHvpvpsetofac.closeCursor();
	}
	else if( 0 == strcmp("121",    m_sMsgTp) || 0 == strcmp("122",    m_sMsgTp)  
		  || 0 == strcmp("125",    m_sMsgTp)
		  || 0 == strcmp("PKG001", m_sMsgTp) || 0 == strcmp("PKG005", m_sMsgTp)
	      || 0 == strcmp("PKG007", m_sMsgTp) )
	{
		CBpbcoutsndcl cBpbcoutsndcl;
		
		CBpbcoutsendlist cBpbcoutsendlist;
		
		char szMsgid[35 + 1] = {0};
		
		string strSql = "";
		strSql = " MESGID = '";
		strSql += m_ccms990.MsgId;
		strSql +="'";
				
		iRet = cBpbcoutsndcl.find(strSql);
		if(OPERACT_SUCCESS != iRet)
		{
			 sprintf(m_szErrMsg, "cBpbcoutsndcl find fail:  [%d][%s]", 
				 iRet, cBpbcoutsndcl.GetSqlErr());
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
		
		if(0 != cBpbcoutsndcl.fetch())
		{
			 sprintf(m_szErrMsg, "cBpbcoutsndcl fetch fail:  [%d][%s]", 
				 iRet, cBpbcoutsndcl.GetSqlErr());
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}

		strSql = "";
		strSql = " MSGID = '";
		strSql += cBpbcoutsndcl.m_msgid;
		strSql +="' and INSTGDRCTPTY = '";
		strSql += cBpbcoutsndcl.m_instgdrctpty;
		strSql +="'";

		SETCTX(cBpbcoutsendlist);
			
		iRet = cBpbcoutsendlist.find(strSql);
		if(OPERACT_SUCCESS != iRet)
		{
			 sprintf(m_szErrMsg, "cBpbcoutsendlist find fail:  [%d][%s]", 
				 iRet, cBpbcoutsendlist.GetSqlErr());
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		while(0 == cBpbcoutsendlist.fetch())
		{
			iRet = GetTagVal(strRval, cBpbcoutsendlist.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, "txid[%s]", cBpbcoutsendlist.m_txid.c_str());
				m_strMsgID = cBpbcoutsendlist.m_txid;
				
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cBpbcoutsendlist.m_mbmsgid.c_str(), 22);
	        
			    //判断间直连，如果是直连就入行内通讯表 by add zql
			    if(cBpbcoutsendlist.m_srcflag =="0")
			    {
			    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "开始写行内通讯表....");
			    	//m_strReserve = cBpbcoutsendlist.m_reserve; //往行内发990时，用于获取原报文类型
					m_strMsgTp = "ccms.990.001.02";
					m_strMsgID = cBpbcoutsendlist.m_msgid;
					m_strWorkDate= cBpbcoutsendlist.m_workdate;
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgID=[%s]....",cBpbcoutsendlist.m_msgid.c_str());
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strWorkDate=[%s]....",cBpbcoutsendlist.m_workdate.c_str());
				    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "pchMsg=[%s]....",pchMsg);
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "开始执行DirectInter().....");
					DirectInter(cBpbcoutsendlist.m_cdtrbrnchid.c_str(), 
								cBpbcoutsendlist.m_dbtrbrnchid.c_str(), 
								cBpbcoutsendlist.m_instddrctpty.c_str(), 
								pchMsg);
				}
			}
			else if(-2 == iRet)
			{
				Trace(L_INFO,  __FILE__,	__LINE__, NULL, "原业务行内发起系统号为空，该笔业务由客户端发起，不用转至行内。");
				// PMTS_ThrowException(OTH_ERR);
			}
		}
		
		cBpbcoutsendlist.closeCursor();
	}
	else if( 0 == strcmp("303" ,m_sMsgTp) || 0 == strcmp("CMT303" ,m_sMsgTp) )
	{
		CCmfreeinfo cCmfreeinfo;
		
		string strSql = "";
		strSql = " MESGID = '";
		strSql += m_ccms990.MsgId;
		strSql += "'";

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql[%s]", strSql.c_str());
		
		SETCTX(cCmfreeinfo);
			
		iRet = cCmfreeinfo.find(strSql);
		if(OPERACT_SUCCESS != iRet)
		{
			 sprintf(m_szErrMsg, "cBpbcoutsendlist find fail:  [%d][%s]", 
				 iRet, cCmfreeinfo.GetSqlErr());
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		while(0 == cCmfreeinfo.fetch())
		{
			iRet = GetTagVal(strRval, cCmfreeinfo.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cCmfreeinfo.m_mbmsgid.c_str(), 22);
			
				//判断间直连，如果是直连就入行内通讯表 by add zql
				//if(NULL != strstr(cCmfreeinfo.m_msgcnt.c_str(), "/REF/TFS ref./REFEND/"))
				if(strlen(cCmfreeinfo.m_mbmsgid.c_str()) == 22)
				{
					//m_strReserve = cCmfreeinfo.m_reserve; //往行内发990时，用于获取原报文类型
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "开始写行内通讯表....");
					m_strMsgTp = "ccms.990.001.02";
					m_strMsgID = cCmfreeinfo.m_msgid;
					m_strWorkDate= cCmfreeinfo.m_wrkdate;
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgID=[%s]....",cCmfreeinfo.m_msgid.c_str());
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strWorkDate=[%s]....",cCmfreeinfo.m_wrkdate.c_str());
				    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "pchMsg=[%s]....",pchMsg);
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "开始执行DirectInter().....");
				    DirectInter(cCmfreeinfo.m_instgindrctpty.c_str(), 
				    			cCmfreeinfo.m_instdindrctpty.c_str(), 
				    			cCmfreeinfo.m_instddrctpty.c_str(), 
				    			pchMsg, 
				    			cCmfreeinfo.m_sysid.c_str());
				}
			}
			else if(-2 == iRet)
			{
				Trace(L_INFO,  __FILE__,	__LINE__, NULL, "原业务行内发起系统号为空，该笔业务由客户端发起，不用转至行内。");
				// PMTS_ThrowException(OTH_ERR);
			}
		}
		
		cCmfreeinfo.closeCursor();
	}
	else if( 0 == strcmp("310", m_sMsgTp) || 0 == strcmp("311", m_sMsgTp) 
		  || 0 == strcmp("312", m_sMsgTp) || 0 == strcmp("313", m_sMsgTp)
     	  || 0 == strcmp("PKG012", m_sMsgTp) )
	{
		CCmcnotsgninfbiz cCmcnotsgninfbiz;
		
		string strSql = "";
		strSql = " MESGID = '";
		strSql += m_ccms990.MsgId;
		strSql +=  "'";

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql[%s]", strSql.c_str());
		
		SETCTX(cCmcnotsgninfbiz);
			
		iRet = cCmcnotsgninfbiz.find(strSql);
		if(OPERACT_SUCCESS != iRet)
		{
			 sprintf(m_szErrMsg, "cCmcnotsgninfbiz find fail:  [%d][%s]", 
				 iRet, cCmcnotsgninfbiz.GetSqlErr());
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		while(0 == cCmcnotsgninfbiz.fetch())
		{
			iRet = GetTagVal(strRval, cCmcnotsgninfbiz.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cCmcnotsgninfbiz.m_mbmsgid.c_str(), 22);
			
				//判断间直连，如果是直连就入行内通讯表 by add zql
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_srcflag=[%s]....",cCmcnotsgninfbiz.m_srcflag.c_str());
				if(cCmcnotsgninfbiz.m_srcflag == "0")
				{
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "开始写行内通讯表....");
					//m_strReserve = cCmcnotsgninfbiz.m_reserve; //往行内发990时，用于获取原报文类型
					m_strMsgTp = "ccms.990.001.02";
					m_strMsgID = cCmcnotsgninfbiz.m_msgid;
					m_strWorkDate= cCmcnotsgninfbiz.m_workdate;
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgID=[%s]....",cCmcnotsgninfbiz.m_msgid.c_str());
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strWorkDate=[%s]....",cCmcnotsgninfbiz.m_workdate.c_str());
				    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "pchMsg=[%s]....",pchMsg);
				    DirectInter(cCmcnotsgninfbiz.m_instgpty.c_str(), 
				    			cCmcnotsgninfbiz.m_instddrctpty.c_str(), 
				    			cCmcnotsgninfbiz.m_instdpty.c_str(), 
				    			pchMsg, 
					    		cCmcnotsgninfbiz.m_syscd.c_str());
					
				}
			}
			else if(-2 == iRet)
			{
				Trace(L_INFO,  __FILE__,	__LINE__, NULL, "原业务行内发起系统号为空，该笔业务由客户端发起，不用转至行内。");
				// PMTS_ThrowException(OTH_ERR);
			}
		}
		
		cCmcnotsgninfbiz.closeCursor();
	}	
	else if( 0 == strcmp("314", m_sMsgTp) || 0 == strcmp("315", m_sMsgTp)
	      || 0 == strcmp("CMT301", m_sMsgTp) || 0 == strcmp("CMT302", m_sMsgTp) )
	{
		CCmtransinfoqry cCmtransinfoqry;
		
		string strSql = "";
		strSql = " MESGID = '";
		strSql += m_ccms990.MsgId;
		strSql += "'";

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql[%s]", strSql.c_str());
		
		SETCTX(cCmtransinfoqry);
			
		iRet = cCmtransinfoqry.find(strSql);
		if(OPERACT_SUCCESS != iRet)
		{
			 sprintf(m_szErrMsg, "cCmtransinfoqry find fail:  [%d][%s]", 
				 iRet, cCmtransinfoqry.GetSqlErr());
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		while(0 == cCmtransinfoqry.fetch())
		{
			iRet = GetTagVal(strRval, cCmtransinfoqry.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cCmtransinfoqry.m_mbmsgid.c_str(), 22);
		    
				//判断间直连，如果是直连就入行内通讯表 by add zql
				//if(cCmtransinfoqry.m_qrytp == "QT01")
				if(strlen(cCmtransinfoqry.m_mbmsgid.c_str()) ==22)
				{
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "开始写行内通讯表....");
					//m_strReserve = cCmtransinfoqry.m_reserve; //往行内发990时，用于获取原报文类型
					m_strMsgTp = "ccms.990.001.02";
					m_strMsgID = cCmtransinfoqry.m_msgid;
					m_strWorkDate= cCmtransinfoqry.m_wrkdate;
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgID=[%s]....",cCmtransinfoqry.m_msgid.c_str());
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strWorkDate=[%s]....",cCmtransinfoqry.m_wrkdate.c_str());
				    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "pchMsg=[%s]....",pchMsg);
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "开始执行DirectInter().....");
				    DirectInter(cCmtransinfoqry.m_instgindrctpty.c_str(),
				                cCmtransinfoqry.m_instdindrctpty.c_str(), 
				    			cCmtransinfoqry.m_instddrctpty.c_str(), 
				    			pchMsg, 
				    			cCmtransinfoqry.m_sysid.c_str());
			    }
			}
			else if(-2 == iRet)
			{
				Trace(L_INFO,  __FILE__,	__LINE__, NULL, "原业务行内发起系统号为空，该笔业务由客户端发起，不用转至行内。");
				// PMTS_ThrowException(OTH_ERR);
			}
		}
		
		cCmtransinfoqry.closeCursor();
	}
	else//不用入行内通讯表
	{
        Trace(L_INFO, __FILE__, __LINE__, NULL, "间联报文类型[%s]", m_sMsgTp);
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms911::InsertComsendmb()");
	return RTN_SUCCESS;
}
