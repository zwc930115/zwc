/******************************************************************** 
�ļ����� recvcmt319.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-04-28
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkcmt319.h"

using namespace ZFPT;

CRecvBkCmt319::CRecvBkCmt319()
{
    m_strMsgTp	  = "CMT319";
    memset(m_sOldMsgId, 0x00, sizeof(m_sOldMsgId));
}


CRecvBkCmt319::~CRecvBkCmt319()
{
	
}


void CRecvBkCmt319::UpdataOrgnBuss()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt319::UpdataOrgnBuss()");	

    string strType = m_cmt319.sOldpacktype;
	if(0 == strcmp("0", m_cmt319.sRebacktype))
	{
        if( "001" == strType || "005" == strType || "007" == strType || "008" == strType ||
            "003" == strType || "010" == strType || "011" == strType  )
        {
            string strSQL;
        	strSQL += "UPDATE bp_bcoutsndcl t SET t.PROCSTATE = '";
            strSQL += PR_HVBP_33;
            
        	strSQL += "', t.STATETIME = sysdate WHERE t.MSGID = '";
        	strSQL += m_sOldMsgId;
            strSQL += "' AND t.INSTGDRCTPTY = '";
        	strSQL += m_cmt319.sOldsendsapbk;								
        	strSQL += "'";
        	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());

        	SETCTX(m_cBpbcoutsndcl);
            int iRet = m_cBpbcoutsndcl.execsql(strSQL.c_str());
            if(iRet != RTN_SUCCESS)
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��iRet=%d, %s", iRet, m_cBpbcoutsndcl.GetSqlErr());
                PMTS_ThrowException(DB_UPDATE_FAIL);
            }   

            if(0 == strcmp("0", m_cmt319.sRebacktype))
        	{
        	}
        	
        }
        else if( "012" == strType)
        {
            string strSQL;
        	strSQL += "UPDATE bp_colltnchrgscl t SET t.PROCSTATE = '";
            strSQL += PR_HVBP_33;
            
        	strSQL += "', t.STATETIME = sysdate WHERE t.MSGID = '";
        	strSQL += m_sOldMsgId;
            strSQL += "' AND t.INSTGDRCTPTY = '";
        	strSQL += m_cmt319.sOldsendsapbk;								
        	strSQL += "'";
        	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());

        	SETCTX(m_colltnchrgscl);
            int iRet = m_colltnchrgscl.execsql(strSQL.c_str());
            if(iRet != RTN_SUCCESS)
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��iRet=%d, %s", iRet, m_colltnchrgscl.GetSqlErr());
                PMTS_ThrowException(DB_UPDATE_FAIL);
            }
        }
        else if("002" == strType || "006" == strType || "009" == strType || "004" == strType)
        {
            string strSQL;
        	strSQL += "UPDATE bp_bdsndcl t SET t.PROCSTATE = '";
            strSQL += PR_HVBP_33;
            
        	strSQL += "', t.STATETIME = sysdate WHERE t.MSGID = '";
        	strSQL += m_sOldMsgId;
            strSQL += "' AND t.INSTGDRCTPTY = '";
        	strSQL += m_cmt319.sOldsendsapbk;								
        	strSQL += "'";
        	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());

        	SETCTX(m_cBpbdsndcl);
            int iRet = m_cBpbdsndcl.execsql(strSQL.c_str());
            if(iRet != RTN_SUCCESS)
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��iRet=%d, %s", iRet, m_cBpbdsndcl.GetSqlErr());
                PMTS_ThrowException(DB_UPDATE_FAIL);
            }         
        }
        else
        {
            Trace(L_ERROR, __FILE__, __LINE__, NULL, "��֧�ֵı�������[%s]", m_cmt319.sOldpacktype);
            PMTS_ThrowException(ERR_NOT_FOUND_NO);
        }        
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt319::UpdataOrgnBuss()");	
}

INT32 CRecvBkCmt319::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt319::Work()");	

	// ��������
	unPack(sMsg);
    
	// ����ҵ������Ϣ��
	InsertDb(sMsg);

    //UpdataOrgnBuss();

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt319::work()");

	return RTN_SUCCESS;
}

INT32 CRecvBkCmt319::unPack(LPCSTR sMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt319::unPack");	

    int iRet = RTN_FAIL;
    char sMsgId[35 + 1] = { 0 };

    // �����Ƿ�Ϊ��
    if (NULL == sMsg || '\0' == sMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }

    // ��������
    iRet = m_cmt319.ParseCmt(sMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������,iRet[%d]", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
    }

    sprintf(m_sOldMsgId, "%8s%08s", m_cmt319.sOldpackdate, m_cmt319.sOldpackno);
    
    // ���ı�ʶ�š�ϵͳ���
    sprintf(sMsgId, "%8s%08s", m_cmt319.sConsigndate, m_cmt319.sOldmssno);
    m_strMsgID	  = sMsgId;

    ZFPTLOG.SetLogInfo("1319", sMsgId);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt319::unPack");	

    return RTN_SUCCESS;
}

INT32 CRecvBkCmt319::InsertDb(LPCSTR pchMsg)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt319::InsertDb");	
    
    m_cmpmtrtrcl.m_wrkdate = m_cmt319.sConsigndate ;    
    m_cmpmtrtrcl.m_consigndate = m_cmt319.sConsigndate ; 
    m_cmpmtrtrcl.m_sysid = "BEPS" ; 
    m_cmpmtrtrcl.m_msgtp = "CMT319" ; 
    m_cmpmtrtrcl.m_msgid = m_strMsgID ; 
    m_cmpmtrtrcl.m_instgdrctpty = m_cmt319.sOldsendsapbk; 
    if(strlen(m_cmt319.sOldsendbk))
    {
        m_cmpmtrtrcl.m_instgindrctpty = m_cmt319.sOldsendsapbk  ;
    }
    else
    {
        m_cmpmtrtrcl.m_instgindrctpty = m_cmt319.sOldsendbk  ;
    } 
    m_cmpmtrtrcl.m_instddrctpty = m_cmt319.sOldrecvsapbk; 
    
    if(strlen(m_cmt319.sOldrecvbk))
    {
        m_cmpmtrtrcl.m_instdindrctpty = m_cmt319.sOldrecvsapbk ; 
    }
    else
    {
        m_cmpmtrtrcl.m_instdindrctpty = m_cmt319.sOldrecvbk ; 
    }
    m_cmpmtrtrcl.m_rsflag = "1" ; 
    m_cmpmtrtrcl.m_rspflag = "0" ; 
    //m_cmpmtrtrcl.m_mbmsg = m_cmt319. ; 
    //m_cmpmtrtrcl.m_npcmsg = m_cmt319. ; 	
    m_cmpmtrtrcl.m_mesgid = m_cmt319.GetHeadMesgID() ; 
    m_cmpmtrtrcl.m_mesgrefid = m_cmt319.GetHeadMesgReqNo() ; 
    m_cmpmtrtrcl.m_procstate = PR_HVBP_08 ; 
    //m_cmpmtrtrcl.m_statetime = m_cmt319. ; 
    //m_cmpmtrtrcl.m_busistate = "PR23" ; 
    //m_cmpmtrtrcl.m_processcode = m_cmt319. ; 
    //m_cmpmtrtrcl.m_rjctinf = m_cmt319. ; 
    m_cmpmtrtrcl.m_orgninstgdrctpty = m_cmt319.sOldsendsapbk ; 
    m_cmpmtrtrcl.m_orgnlmsgid = m_sOldMsgId; 
    m_cmpmtrtrcl.m_orgnlmsgnmid = "PKG";
    m_cmpmtrtrcl.m_orgnlmsgnmid += m_cmt319.sOldpacktype; 
    m_cmpmtrtrcl.m_returntype = m_cmt319.sRebacktype; 
    m_cmpmtrtrcl.m_printno = atoi(m_cmt319.sRebacktype) ; 
    //m_cmpmtrtrcl.m_retunstat = m_cmt319.sReplyflag ; 
    //m_cmpmtrtrcl.m_rtinfo = m_cmt319.sRemark ; 
	SetGbkToUtf8(m_cmt319.sRemark, m_cmpmtrtrcl.m_rtinfo);

    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_orgnlmsgid=[%s]",  m_cmpmtrtrcl.m_orgnlmsgid.c_str());
    SETCTX(m_cmpmtrtrcl);
    int iRet = m_cmpmtrtrcl.insert();
    if(SQL_SUCCESS != iRet)
    {
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "������ʧ��[%d][%s]",
		    iRet, m_cmpmtrtrcl.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "������ʧ��");    
    }
    
	if(0 == strcmp("0", m_cmt319.sRebacktype))
	{
	    m_cmpmtrtrlist.m_ctgypurp = m_cmt319.sTradecode; 
	    m_cmpmtrtrlist.m_rsflag = "2";
	    m_cmpmtrtrlist.m_msgid = m_strMsgID ; 
	    m_cmpmtrtrlist.m_instgdrctpty = m_cmt319.sOldsendsapbk ;
	    m_cmpmtrtrlist.m_orgnlmsgid = m_sOldMsgId; 
	    m_cmpmtrtrlist.m_orgnltxid = m_cmt319.sOldconsigndate;
	    
	    char tmp[8+1]={0};
	    sprintf(tmp,"%08d",m_cmt319.iOldtxssno);
	    m_cmpmtrtrlist.m_orgnltxid += tmp;
	    
	    m_cmpmtrtrlist.m_orgninstgdrctpty = m_cmt319.sOldsendsapbk ; 
        m_cmpmtrtrlist.m_orgninstgindrctpty = m_cmt319.sOldsendbk ; 
        m_cmpmtrtrlist.m_orgninstddrctpty = m_cmt319.sOldrecvsapbk ; 
        m_cmpmtrtrlist.m_orgninstdindrctpty = m_cmt319.sOldrecvbk ; 
	    
        SETCTX(m_cmpmtrtrlist);
        int iRet = m_cmpmtrtrlist.insert();
        if(SQL_SUCCESS != iRet)
        {
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "������ʧ��[%d][%s]",
    		    iRet, m_cmpmtrtrlist.GetSqlErr());
    		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "������ʧ��");    
        }
	}

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt319::InsertDb");	

    return RTN_SUCCESS;
}

