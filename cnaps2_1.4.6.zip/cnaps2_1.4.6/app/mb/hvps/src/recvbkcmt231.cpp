/******************************************************************** 
�ļ����� recvcmt231.cpp
�����ˣ� aps-xcm
��  �ڣ� 2011-06-27
�޸��ˣ� 
��  �ڣ� 
��  ���� ������˴�����ʱת�˱���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkcmt231.h"

using namespace ZFPT;

CRecvBkCmt231::CRecvBkCmt231()
{
    m_strMsgTp = "CMT231";
}

CRecvBkCmt231::~CRecvBkCmt231()
{

}

INT32 CRecvBkCmt231::Work(LPCSTR sMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkCmt231::Work()");

    // 1.��������
    unPack(sMsg);
    
    // 2.��m_cHvtrofacsndlist�ĳ�Ա��ֵ
    SetData(sMsg);

    // 4.����������ʼ�ʱת�˱�hv_trofacrcvlist����������
    InsertData();

    AddMac();

    buildCmtMsg();
        
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkCmt231::Work()");

    return RTN_SUCCESS;
}

INT32 CRecvBkCmt231::unPack(LPCSTR sMsg)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvBkCmt231::unPack...");
    Trace(L_INFO, __FILE__, __LINE__, NULL, "receive sMsg[%s]", sMsg);
    // 1�������Ƿ�Ϊ��
    if(NULL == sMsg || '\0' == sMsg)
    {
        Trace(L_ERROR, __FILE__, __LINE__, m_strBizCode.c_str(), "����Ϊ��");
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");   
    }

    int iRet = RTN_FAIL;

    //2.��������

    iRet = m_cCmt231.ParseCmt(sMsg);

    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "���Ľ���ʧ��");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ���ʧ��");
    }

    char szTxssno[8 + 1] = {0};
    sprintf(szTxssno, "%08d", m_cCmt231.iTxssno);
    
    // ���ı�ʶ��,����д�����ļ�����
    m_strMsgID = m_cCmt231.sConsigndate;
    m_strMsgID += szTxssno;
    ZFPTLOG.SetLogInfo("231", m_strMsgID.c_str());

	/*
    //��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS,m_cCmt231.GetHeadDestAddr());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ȡ��������ʧ��");
        PMTS_ThrowException(OPT_GET_DATE_FAIL);
    }
    */
    m_strWorkDate = m_sWorkDate;

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvBkCmt231::unPack...");

    return RTN_SUCCESS;
}


INT32 CRecvBkCmt231::SetData(LPCSTR pchMsg)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvBkCmt231::SetData...");

    char DbSapBank[15] = {0};
    char CDSapBank[15] = {0};
    int iRet = GetSapBank(m_dbproc, m_cCmt231.sOsdficode, DbSapBank);
    int iRet1 = GetSapBank(m_dbproc, m_cCmt231.sIsdficode, CDSapBank); 
    if(iRet != 0 || iRet1 != 0)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, 
            "��ȡ��������Ϣʧ��m_cCmt231.sOsdficode[%s],iRet[%d],m_cCmt231.sIsdficode[%s],iRet1[%d]",
            m_cCmt231.sOsdficode,iRet,m_cCmt231.sIsdficode,iRet1);
        PMTS_ThrowException(PRM_FAIL);        
    }
    
    m_cHvtrofacrcvlist.m_cdtmmbid = CDSapBank ; 
    m_cHvtrofacrcvlist.m_cdtrnm = m_cCmt231.sPayeename ; 
    m_cHvtrofacrcvlist.m_cdtid = m_cCmt231.sIsdficode ; 
    m_cHvtrofacrcvlist.m_cdtracctid = m_cCmt231.sPayeeacc ; 
    m_cHvtrofacrcvlist.m_cdtrissr = m_cCmt231.sPayeeopenbk ; 

    char szTmp[30] = {0};
    m_cHvtrofacrcvlist.m_tranmunum = itoa(szTmp, m_cCmt231.iTxsbatno) ; 
    m_cHvtrofacrcvlist.m_currency = m_cCmt231.sCur; 
    m_cHvtrofacrcvlist.m_amount = m_cCmt231.dAmount ; 
    m_cHvtrofacrcvlist.m_ctgypurpprtry =  m_cCmt231.sOprttype[0]; 
    m_cHvtrofacrcvlist.m_purpprtry = m_cCmt231.sOprttype + 2 ; 
    m_cHvtrofacrcvlist.m_procstate = PR_HVBP_08 ; 
    //m_cHvtrofacrcvlist.m_finalstatedate = m_strWorkDate ; 
    m_cHvtrofacrcvlist.m_busistate = "" ; 
    //m_cHvtrofacrcvlist.m_processcode = m_cCmt231. ; 
    //m_cHvtrofacrcvlist.m_rjctinf = m_cCmt231. ; 
    //m_cHvtrofacrcvlist.m_acctstate = m_cCmt231. ; 
    //m_cHvtrofacrcvlist.m_acstatetime = m_cCmt231. ; 
    //m_cHvtrofacrcvlist.m_acctregnum = m_cCmt231. ; 
    //m_cHvtrofacrcvlist.m_dupacregnum = m_cCmt231. ; 
    m_cHvtrofacrcvlist.m_checkstate = PR_HVBP_00 ; 
    m_cHvtrofacrcvlist.m_mbcheckstate = PR_HVBP_00 ; 
    //m_cHvtrofacrcvlist.m_mbmsg = "" ; 
    //char m_sorimbmsg[32 + 1] = m_cCmt231. ; 
    //m_cHvtrofacrcvlist.m_npcmsg = m_cCmt231. ; 
    //char m_sorinpcmsg[32 + 1] = m_cCmt231. ; 
    //m_cHvtrofacrcvlist.m_reserve = m_cCmt231. ; 
    //m_cHvtrofacrcvlist.m_iststatetime = m_cCmt231. ; 
    //m_cHvtrofacrcvlist.m_dbtaddr = m_cCmt231. ; 
    //m_cHvtrofacrcvlist.m_cdtaddr = m_cCmt231. ; 
    //m_cHvtrofacrcvlist.m_isrbflg = m_cCmt231. ; 
    //m_cHvtrofacrcvlist.m_recvdest = m_cCmt231. ; 
    m_cHvtrofacrcvlist.m_srcflag = '0' ; 
    //m_cHvtrofacrcvlist.m_remark = m_cCmt231.sRemark ; 
	SetGbkToUtf8(m_cCmt231.sRemark, m_cHvtrofacrcvlist.m_remark);
    m_cHvtrofacrcvlist.m_workdate = m_strWorkDate ; 
    m_cHvtrofacrcvlist.m_consigndate = m_strWorkDate ; 
    m_cHvtrofacrcvlist.m_msgtp = "CMT231" ; 
    m_cHvtrofacrcvlist.m_mesgid = m_cCmt231.GetHeadMesgID() ; 
    m_cHvtrofacrcvlist.m_mesgrefid = m_cCmt231.GetHeadMesgReqNo() ; 
    m_cHvtrofacrcvlist.m_msgid = m_strMsgID ; 
    m_cHvtrofacrcvlist.m_cdcode = '0' ; 
    m_cHvtrofacrcvlist.m_instgdrctpty = DbSapBank ; 
    m_cHvtrofacrcvlist.m_instgindrctpty = m_cCmt231.sPayopenbk ; 
    m_cHvtrofacrcvlist.m_instddrctpty = CDSapBank ; 
    m_cHvtrofacrcvlist.m_instdindrctpty = m_cCmt231.sIsdficode ; 
    m_cHvtrofacrcvlist.m_spjoinmmbid = m_cCmt231.sBankcode ; 
    //m_cHvtrofacrcvlist.m_rmk = m_cCmt231.sRemark ; 
	SetGbkToUtf8(m_cCmt231.sRemark, m_cHvtrofacrcvlist.m_rmk);
    //m_cHvtrofacrcvlist.m_endtoendid = m_cCmt231. ; 
    //m_cHvtrofacrcvlist.m_sttlmprty = m_cCmt231.GetPayPRI() ; 
    m_cHvtrofacrcvlist.m_dbtmmbid = DbSapBank; 
    //m_cHvtrofacrcvlist.m_dbtnm = m_cCmt231.sPayername ; 
	SetGbkToUtf8(m_cCmt231.sPayername, m_cHvtrofacrcvlist.m_dbtnm);
    m_cHvtrofacrcvlist.m_dbtracctid = m_cCmt231.sPayeracc ; 
    m_cHvtrofacrcvlist.m_dbtid = m_cCmt231.sOsdficode ; 
    m_cHvtrofacrcvlist.m_dbtrissr = m_cCmt231.sPayopenbk ;     
    //m_cHvtrofacrcvlist.m_rmk = m_cCmt231.sRemark ;    

    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CF1:" + m_cCmt231.sBondcode+ ":";

    memset(szTmp, 0x00, sizeof(szTmp));
    ftoa(szTmp, m_cCmt231.dBondamount, 2);
    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CNM:" + szTmp + ":";

    memset(szTmp, 0x00, sizeof(szTmp));
    ftoa(szTmp, m_cCmt231.dSetamount, 2);
    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CNQ:" + szTmp + ":";
    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CJ8:" + m_cCmt231.sSetdate + ":";

    memset(szTmp, 0x00, sizeof(szTmp));
    ftoa(szTmp, m_cCmt231.dSetrate, 2);    
    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CNR:" + szTmp + ":";

    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CF2:" + m_cCmt231.sBondordercode + ":";

    memset(szTmp, 0x00, sizeof(szTmp));
    ftoa(szTmp, m_cCmt231.dNetamount, 2);   
    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CNN:" + szTmp + ":";

    memset(szTmp, 0x00, sizeof(szTmp));
    ftoa(szTmp, m_cCmt231.dBondrate, 2);       
    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CNP:" + szTmp + ":";

    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CCF:" + m_cCmt231.sOsdficodeccpc + ":";
    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CCG:" + m_cCmt231.sIsdficodeccpc + ":";
    
	Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvBkCmt231::SetData...");
    return RTN_SUCCESS;
    
}

INT32 CRecvBkCmt231::InsertData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvBkCmt231::InsertData...");

    SETCTX(m_cHvtrofacrcvlist);
    int iRet = m_cHvtrofacrcvlist.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "����������ϸ��ʧ��iRet[%d][%s]", iRet, m_cHvtrofacrcvlist.GetSqlErr());
        PMTS_ThrowException(DB_INSERT_FAIL);
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvBkCmt231::InsertData...");
    return RTN_SUCCESS;    
}

int CRecvBkCmt231::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkCmt231::FundSettle...");
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û�[%s]", m_szOprUser);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_cCmt231.GetHeadDestAddr());

	m_charge.m_amount = m_cCmt231.dAmount;	//ҵ����
	m_charge.m_iDCFlag = iCREDITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, MBVIRSUALNETID);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_cCmt231.GetHeadDestAddr());	//������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(RTN_SUCCESS != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FundSettle iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkCmt231::FundSettle..."); 
    
    return RTN_SUCCESS;
}

int CRecvBkCmt231::ChkMac()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkCmt231::ChkMac...");
	int iRet = -1;
	
	m_cCmt231.SetSeal();//��ȡ��Ѻ��

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt231.sRecvsapbk[%s]",m_cCmt231.sIsdficode);
	
    iRet = CheckMac(m_dbproc,m_cCmt231.GetMacStr(),m_cCmt231.m_Seal.c_str(),m_cCmt231.sIsdficode);
    if(0 != iRet)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ChkMac failed");
    	PMTS_ThrowException(OPT_CHECKSIGN_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]",m_cCmt231.m_szMacStr);
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkCmt231::ChkMac..."); 
    
    return RTN_SUCCESS;
}

int CRecvBkCmt231::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvbkCmt231::buildCmtMsg...");

    int iRet;// = m_cCmt231.CreateCmt("231", m_cHvtrofacrcvlist.m_instgdrctpty.c_str(), m_cHvtrofacrcvlist.m_instddrctpty.c_str(), m_strMsgID.c_str(), m_strMsgID.c_str(), m_cHvtrofacrcvlist.m_workdate.c_str(), m_cHvtrofacrcvlist.m_sttlmprty.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }

    m_bifmac = true;
    m_macMsg = m_cCmt231.m_strCmtmsg;
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvbkCmt231::buildCmtMsg...");
    return iRet;
}

int CRecvBkCmt231::AddMac()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbkCmt231::AddMac...");
	int iRet = -1;
	
	m_cCmt231.SetSeal();//获取密押串

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt231.sSendsapbk[%s]",m_cCmt231.sOsdficode);
	
    iRet = CodeMac(m_dbproc,m_cCmt231.m_Seal.c_str(),m_cCmt231.m_szMacStr);
    if(0 != iRet)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "AddMac failed");
    	PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]",m_cCmt231.m_szMacStr);
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbkCmt231::AddMac..."); 
    
    return RTN_SUCCESS;
}

