/******************************************************************** 
文件名： recvpkg012.h
创建人： handongfeng
日  期： 2011-04-14
修改人： 
日  期： 
描  述： 
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifndef __RECVPKG012_H__
#define __RECVPKG012_H__

#include "recvbepsbase.h"
#include "pkg012.h"
#include "bpcolltnchrgscl.h"
#include "bpcolltnchrgslist.h"
#include "bpbizpubntce.h"
#include "bpcstctrctmglist.h"
#include "cmcnotsgninfbiz.h"
#include "bpbcoutrecvlist.h"
#include "bpbcoutrcvcl.h"
#include "bpbcoutsendlist.h"
#include "bpbdsendlist.h"
#include "bpbdsndcl.h"
#include "bpbcoutrcvcl.h"
#include "pkg005.h"
#include "pkg006.h"
#include "bpbcoutsndcl.h"
#include "bpcstctrctmg.h"

class CRecvPkg012 : public CRecvBepsBase
{
public:
	CRecvPkg012();
	~CRecvPkg012();
	INT32 Work(LPCSTR szMsg);
    
private:
    INT32 GetOrgnMsg(string strBtchnb);
    INT32 unPack(LPCSTR szMsg);
    INT32 CheckValues();
    void  InsertDb(LPCSTR pchMsg);
    INT32 ChargeMb();
    void  InsertCollDb(LPCSTR pchMsg);
    void  InsertBizDb(LPCSTR pchMsg);
    void  InsertSignedDb(LPCSTR pchMsg);
    void  InsertUsualInfoDb(LPCSTR pchMsg);
    int  CheckMac012();	
    
	//一般 通用信息表
	void SetData_cminf(void);

	int InsertData_cminf(void);
	    
    INT32 CreatePkg006(const CBpcolltnchrgslist* m_colltnchrgslist, string dbtrissr, string cdtrissr, int reciptdate);
    INT32 CreatePkg005(const CBpcolltnchrgslist* m_colltnchrgslist, string dbtrissr, string cdtrissr);
    INT32 CreateRtn40506Msg();
    INT32 CreateRtn40503Msg(string dbtrbrnchid,string dbtrchid,
            string dbtrid,string dbtrnm,double amout,
            string endtoendid,string cdtrmmbid,
            string cdtrbrnchid,string cdtrnm,string txid);
    	//获取附加域中的字段值
    	void GetAddtlField(int iLen, string& strVal,
    			 bool bUtf8 = false, bool bAdd = false);
			             		                
    void Fill40503Msg(string strTxid,string strAcct,string strAmt,
                                string strStat);		                                                     
    void PackPkg005();
    void PackPkg006();

    /*通用信息业务 */
    void Fill40506Msg(string dbtrbrnchid, string cdtrbrnchid, string oriConsigndate, string oriTxssno, string oriTradetype);
    void InitValue();

    pkg012              m_pkg012;
    pkg012              m_rtnpkg012;
    pkg005				m_opkg005;
    pkg006              m_opkg006;

	CBpcolltnchrgscl	m_colltnchrgscl;
    CBpcolltnchrgslist	m_colltnchrgslist;
	CBpcolltnchrgslist	m_colltnchrgslistOrg;
	CBpbizpubntce       m_cBpbizpubntce;
	CCmcnotsgninfbiz    m_cminfbiz;  //一般通用信息表
    
    int					m_iTotalNum;//成功处理总笔数,创建借贷包时使用
    double				m_dTotalAmt;//成功处理总金额,创建借贷包时使用
    int					m_iTotalNumCL;//成功处理总笔数,填代收付汇总表时使用
    double				m_dTotalAmtCL;//成功处理总金额,填代收付汇总表时使用

    double              m_dFacAmt;//每个要素总金额
	double              m_dAllAmt;  //全部总金额
    double              m_dAllNum;  //全部总笔数
    int                 m_MaxDay;//最大回执期限
	
    //006
    CBpbdsndcl      m_Bpbdsndcl;
	CBpbdsendlist	m_cBpbdsndlist;
    string          m_msgid006;

    //005
	CBpbcoutsendlist  m_BpBcList;
    CBpbcoutsndcl m_cBpbcoutsndcl;
    string          m_msgid005;

    int m_iSuccessFlag;//标志检查明细是否成功过.
    int m_iFlag;//检查失败时,不加进要素集,但写进借贷记表,直接标志为已接收借贷记回执标志,便于批量回执处理.
    string m_strRtn;//因为按代收付通用回执包的附加域只有要素,没有要素下的附加明细来看,代收付要素里有一个明细检查失败的,那么这个要素就失败处理.
	int                m_iAddtlLen; //附加域长度
	char*              m_pszAddtl;
	char               m_szTblNm[64]; //表名
	int                m_iOffset;   //附加域字段偏移值
	char               m_szBuffer[1024 * 1024];
	CEntityBase*       m_pEntity;

    //协议管理
    CBpcstctrctmg m_Bpcstctrctmg;
    CBpcstctrctmglist m_Bpcstctrctmglist;
	string str40503AppData;
	string str40504AppData;
	string m_str40506;
    string m_cstrListStr;//要素附加域
    char m_sPkgNo[35 + 1];
	int m_DetailCnt;
    string m_strSendBank;
    string m_strRecvBank;
};

#endif


