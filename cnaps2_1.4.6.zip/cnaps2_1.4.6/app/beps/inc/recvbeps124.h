#ifndef RECVBEPS124_H
#define RECVBEPS124_H

#include "recvbepsbase.h"
#include "beps124.h"

#include "bpbdrecvlist.h" 
#include "bpbdrcvcl.h" 

#include "bpbcoutsendlist.h"


class CRecvBeps124 : public CRecvBepsBase
{
public:
	CRecvBeps124();

	~CRecvBeps124();

	INT32 Work(LPCSTR szMsg);

private:
	int  UnPack(const char* szmsg);

	int  QryOrgnlBiz(void);

	int  InsertData(void);

	int  InsertData_bd_cl(void);

	int  InsertData_bd_list(void);

	int  UpdateOrgnlBiz(void);

	void ChkSign124(void);

	int  CheckValues(void);

	int  FundSettle(void);

	int  ChargeMb(void);
	
	void InsertUserInfoTel(void);

private:
	CBpbdrcvcl       m_bdrcvcl;

	CBpbdrecvlist    m_bdrcvlist;

	CBpbcoutsendlist m_orgnlbiz;

	beps124          m_cBeps124;
	
	string           m_strNpcMsg;
};

#endif /*RECVBEPS124_H*/


