/*
 *  sendbeps385.h
 *  Description:
 *  Created on: 2012-06-25
 *  Author: __wsh
 */

#ifndef SENDBEPS385_H_
#define SENDBEPS385_H_

#include "beps385.h"
#include "sendbepsbase.h"

#include "bpcolltnchrgscl.h"
#include "bpcolltnchrgslist.h"

class CSendBeps385 : public CSendBepsBase
{
public:
    CSendBeps385(const stuMsgHead& Smsg);

    ~CSendBeps385();
    
    INT32  doWorkSelf(void);

private:
	int GetData(void);
	
	void SetData(void);

	void AddSign385(void);

	int BuildPmtsMsg(void);

	int UpdateState(void);

private:
	beps385  m_cBeps385;

	CBpcolltnchrgscl m_colltncl;

	CBpcolltnchrgslist m_colltnlist;

};

#endif



