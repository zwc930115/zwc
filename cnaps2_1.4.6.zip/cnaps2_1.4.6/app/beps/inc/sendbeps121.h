/******************************************************************** 
�ļ����� sendbeps121.h
�����ˣ� zwy
��  ��   �� 2011-03-07
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef __SENDBEPS121_H__
#define __SENDBEPS121_H__

#include "bpbcoutsendlist.h"
#include "sendbepsbase.h"

class CSendBeps121 : public CSendBepsBase
{
public:
    CSendBeps121(const stuMsgHead& Smsg);
    ~CSendBeps121();
    
    INT32  doWorkSelf();
private:
    
    int getData();

    INT32 CheckValues();

    INT32 UpdatePkg();
    INT32 UpdateSendList(LPCSTR sProcstate);
    INT32 SetErrACK(int iErrCode, LPCSTR pErrDesc);
    int ChargeMB();
	int FundSettle();

    CBpbcoutsendlist	m_cBpbcoutsendlist;
    char				m_sPkgNo[35 + 1];
};

#endif


