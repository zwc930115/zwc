/******************************************************************** 
�ļ����� sendbeps383.h
�����ˣ� handongfeng
��  ��   �� 2011-03-07
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __SENDBEPS383_H__
#define __SENDBEPS383_H__

#include "beps383.h"
#include "sendbepsbase.h"
#include "bpcolltnchrgscl.h"
#include "bpcolltnchrgslist.h"

class CSendBeps383 : public CSendBepsBase
{
public:
    CSendBeps383(const stuMsgHead& Smsg);
    ~CSendBeps383();
    
    INT32  doWorkSelf();
private:
    void SetDBKey();
    int GetData();
    void SetData();
    int UpdateState();
	int InsertSum();
    void AddSign383();
    int ChargeMB();
	int FundSettle();
	
    beps383			    m_beps383;
	CBpcolltnchrgscl	m_colltnchrgscl;
    CBpcolltnchrgslist	m_colltnchrgslist;
    int					m_iTotalNum;		//�ɹ�����
    double				m_dTotalAmt;		//�ɹ����
    string              m_Sign;
};

#endif



