/******************************************************************** 
�ļ����� sendbeps398.h
�����ˣ� handongfeng
��  ��   �� 2011-03-07
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __SENDBEPS398_H__
#define __SENDBEPS398_H__

#include "beps398.h"
#include "sendbepsbase.h"
#include "bpbktocstdcntfctn.h"

class CSendBeps398 : public CSendBepsBase
{
public:
	CSendBeps398(const stuMsgHead& Smsg);
	~CSendBeps398();
	
	INT32  doWorkSelf();
private:
	void AddSign398();
	void SetTag2ND(const string& Tag, const string& QryStr, int& iDepth);
	void SetDBKey();
	int GetData();
	void SetData();
	int UpdateState();
	int InsertSum();
	
	beps398				m_beps398;
	CBpbktocstdcntfctn	m_Bpbktocstdcntfctn;
};

#endif




