/*
 *  sendbeps392.h
 *  Description: ����ǩԼ����Э��beps.392.001.01����������
 *  Created on: 2012-06-13
 *  Author: __wsh
 */

#ifndef SENDBEPS392_H_
#define SENDBEPS392_H_

#include "beps392.h"
#include "sendbepsbase.h"

#include "bpcstctrctmgcl.h"
#include "bpcstctrctmglist.h"

class CSendBeps392 : public CSendBepsBase
{
public:
	CSendBeps392(const stuMsgHead& Smsg);

    ~CSendBeps392();

    INT32  doWorkSelf();

private:

    int GetData(void);

    int CheckValues(void);

    void AddSign392(void);

    void SetAgrmtDtls(void);

    int SetCcmInfo(void);

	int BuildPmtsMsg(void);

    int UpdateState(void);

private:

    beps392 m_cBeps392;

    CBpcstctrctmgcl m_ccmcl;

    CBpcstctrctmglist m_ccmlist;

};


#endif /* SENDBEPS392_H_ */
