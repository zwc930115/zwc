/******************************************************************** 
文件名： bepsckecksum.h
创建人： hq
日  期： 2011-05-31
修改人： 
日  期： 
描  述： 小额汇总对账类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef _BEPSCHECKSUM_H_
#define _BEPSCHECKSUM_H_

#include "basic.h"
#include "connectpool.h"
#include "bpcheckcl.h"
#include "checkaccount.h"
#include "beps722.h"
#include "mqagent.h"
#include "pubfunc.h"

class CBepsCheckSum
{
public:
    
    CBepsCheckSum();
    ~CBepsCheckSum();

    void doCheckSumWork(DBProc &dbProc,
                        int iChkTp, 
                        LPCSTR sChkDt, 
                        LPCSTR sBankCode, 
                        MQAgent &cMQAgent, 
                        LPCSTR sSendQueue);

public:

    void AddDetail(LPCSTR sSndRcvTp, LPCSTR sMsgTp);
    void UpdateSts();
    
    int    m_iPkgTtlCnt;   //业务包申请明细数目
    int    m_iMsgTtlCnt;   //信息报文申请明细数目
    int    m_iLocalMore;   //本地多的数目(不用下载明细)
    
    STRING m_szMT;         //报文编号
    STRING m_szTxNetgDt;   //轧差日期
    STRING m_szTxNetgRnd;  //轧差场次
    STRING m_szPrcSts;     //处理状态
    STRING m_szChkDt;      //对账日期
    STRING m_szBkCode;     //清算行号
    STRING m_szCcy;        //币种

    vector<stCheckSum> VCheckArray;
private:

    void SetAllCtx();
    void CountLocalInfo();
    void UpdateCheckCl(LPCSTR sSndTableNm, LPCSTR sRcvTableNm);
    void updateBkChkSt();
    void DeleteCheckList();
    void SndToNpcFor722(MQAgent &cMQAgent, LPCSTR sSendQueue);

    beps722       m_beps722;
    CBpcheckcl    m_bpcheckcl;
    CCheckAccount m_checkaccount;

    DBProc m_dbproc;
};

#endif


