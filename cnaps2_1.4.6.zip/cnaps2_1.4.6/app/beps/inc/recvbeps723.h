
#ifndef RECVBEPS723_H
#define RECVBEPS723_H

#include "recvbepsbase.h"
#include "beps723.h"
#include "beps720.h"
#include "beps724.h"

#include "bpchklstlist.h"
#include "bpchklstcl.h"
#include "bepschecklist.h"
#include "bpcheckcl.h"
#include "bpchkhelper.h"
#include "cmcheckqry.h" 

class CRecvBeps723 : public CRecvBepsBase
{
public:
	CRecvBeps723();
	
	~CRecvBeps723(); 
	
	int Work(LPCSTR szMsg);

private:
	int  UnPack(LPCSTR szMsg);

	void ChkSign723(void);

	int  InsertData_cl(void);

	int  InsertData_list(void);

	int  SetAndAddData(void);

	void GetDtlChckRspnDtls(int i = 0);

	void GetOrgnlPmtDtls(int i = 0, int j = 0);

	void GetDtlChckMsgRspnDtls(int i = 0);

	void GetOrgnlMsgDtls(int i = 0, int j = 0);

	void DoCompare(void);
	
	int  QueryLocalBiz(void);

	int  ToBizTable(int iMode, LPCSTR szMt);

	int  DoCheck(void);

	bool IsRecvAll(void);
	
	int  Send720(void);

	int  AdjustOrgnlBizSt(void);

	void AddDtls724(LPCSTR szSR = "SR01");

	void AddSign724(void);

	int  RequestBizDtls724(void);

	bool AmtEqual(double dAmt1, double dAmt2);

	int GetChklstCntByCondition(int iCondition);

	bool IsCriticalTimes(int max_times = 2);
	bool ChickIfContuine();

private:
	CBpchklstlist m_lstlist;
	CBpchklstcl   m_lstcl;
	CBpChkHelper  m_cChkHelper;
	CMcheckqry      m_checkqry;
	
	beps723       m_cBeps723;
	beps724       m_cBeps724;

	string        m_strChkSt;
	string        m_strCollSrcFlag; //代收付往来账标识
	bool          m_bIsPmt;         //是否业务类报文

	string        m_strLocalBizSt;  //本地业务状态
	double        m_dLocalCtrlSum;  //本地业务金额
	int           m_iLocalTtlCnt;   //本地报文明细笔数

	char          m_szTblNm[128];
	char          m_szSTblNm[128];
	char          m_szRTblNm[128];

	int           m_iLocalLess;

	int           m_iSndCnt724;

};

#endif


