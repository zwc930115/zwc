/*
 *  recvpkg012.h
 *  Description: һ��PKG012����������
 *  Created on: 2012-07-04
 *  Author: __wsh
 */

#ifndef __SENDPKG012_H__
#define __SENDPKG012_H__


#include "pkg012.h"
#include "sendbepsbase.h"

#include "bpcolltnchrgscl.h"
#include "bpcolltnchrgslist.h"
#include "cmcnotsgninfbiz.h"

class CSendPkg012 : public CSendBepsBase
{
public:
    CSendPkg012(const stuMsgHead& Smsg);

    ~CSendPkg012();
    
    INT32  doWorkSelf();
    
private:
    int GetData(void);

    int GetData_colltn(void);

    int GetData_cminfbiz(void);

    void AddAddtlField(string& strVal, int iFieldLen=0,
    		     const char* szFmt=NULL, bool bToGbk = false);

    void AddAddtlField(long lVal, 
                int iFieldLen, const char* szFmt);

    void FillAppendData(void);

    void FillAppendData_colltn_dtls(void);

    void FillAppendData_colltn_ans(void);

    void FillAppendData_common_info(void);

    void FillBizHead(void);

	void FillBizBody(void);

	void AddMac012(void);

	int CreateNpcMsg(void);

	int UpdateState(void);


private:

	pkg012 m_cPkg012;

	CBpcolltnchrgscl	m_colltncl;	 //���ո����ܱ�

	CBpcolltnchrgslist	m_colltnlist; //���ո���ϸ��

	CCmcnotsgninfbiz    m_cminfbiz;  //һ��ͨ����Ϣ��

	CEntityBase* m_pEntity;

	char m_szTblNm[64];

	char m_szBuffer[1024];

	string m_strAppendData;

	string m_strInstgdrctpty;

	string m_strInstddrctpty;

	string m_strInstgpty;

	string m_strInstdpty;

	string m_strWorkDate;

	string m_strRmk;

};

#endif


