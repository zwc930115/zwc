/******************************************************************** 
�ļ����� sendbeps128.h
�����ˣ� handongfeng
��  ��   �� 2011-03-07
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __SENDBEPS128_H__
#define __SENDBEPS128_H__

#include "sendbepsbase.h"
#include "beps128.h"
#include "bpbcoutsendlist.h"

class CSendBeps128 : public CSendBepsBase
{
public:
    CSendBeps128(const stuMsgHead& Smsg);
    ~CSendBeps128();
    
    INT32  doWorkSelf();
private:

    INT32 CheckValues();
    void  CreatPmtsMsg();
    INT32 UpdateStat(LPCSTR sProcstate,LPCSTR pMsgid);
    INT32 SetErrACK(int iErrCode, LPCSTR pErrDesc);
	int   UpdateOriStat(LPCSTR sProcstate,LPCSTR pMsgid);
    int ChargeMB();
	int FundSettle();
    
    void AddSign128();
    
    CBpbcoutsendlist	m_cBpbcoutsendlist;
    
    beps128				oBeps128;

};

#endif




