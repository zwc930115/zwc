/******************************************************************** 
�ļ����� sendpkg002.h
�����ˣ� handongfeng
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef __SENDPKG002_H__
#define __SENDPKG002_H__

#include "pkg002.h"
#include "bpbdsendlist.h"
#include "sendbepsbase.h"

#include <string.h>

using namespace std;

class CSendPkg002 : public CSendBepsBase
{
public:
    CSendPkg002(const stuMsgHead& Smsg);
    ~CSendPkg002();
    
    INT32  doWorkSelf();
    
private:
    
    INT32 GetData();
    INT32 CheckValues();
    INT32 CheckAcct();
    INT32 CreateNpcMsg();
    INT32 UpdatePkg();
    INT32 UpdateSndList(LPCSTR sProcstate);
    INT32 SetErrACK(int iErrCode, LPCSTR pErrDesc);
    
    //! ������4000Bytes���ַ�д��bp_bigdata����
    string getShortNpcMsg(const string& origNpcMsg);
   
    pkg002          m_pkg002;
    CBpbdsendlist	m_cBpbdsndlist;
    char			m_sPkgNo[35 + 1];
};

#endif


