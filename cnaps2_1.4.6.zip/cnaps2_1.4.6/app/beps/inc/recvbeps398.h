/******************************************************************** 
文件名： recvbeps398.h
创建人： handongfeng
日  期： 2011-02-23
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __RECVBEPS398_H__
#define __RECVBEPS398_H__

#include "recvbepsbase.h"
#include "beps398.h"
#include "bpbktocstdcntfctn.h"

class CRecvbeps398 : public CRecvBepsBase
{
public:
    CRecvbeps398();
    ~CRecvbeps398();
    int Work(LPCSTR szMsg);

private:

    void SetData();
    INT32 unPack(LPCSTR szMsg);
    beps398 m_beps398;
    CBpbktocstdcntfctn	m_Bptocstdcntfctn;
};

#endif

