/*
 * 	sendbeps413.h
 *	Description: ʵʱ��������beps.413.001.01������
 *  Created on: 2012-07-09
 *  Author: __wsh
 */

#ifndef SENDBEPS413_H
#define SENDBEPS413_H

#include "beps413.h"
#include "sendbepsbase.h"

#include "bpcstpmtcxl.h" 


class CSendBeps413 : public CSendBepsBase
{
public:
	CSendBeps413(const stuMsgHead& Smsg);

	~CSendBeps413();
	
	INT32  doWorkSelf();

private:
	int GetData(void);

	void SetData(void);

	void AddSign413(void);

	int BuildPmtsMsg(void);

	int UpdateState(void);

private:
	beps413       m_cBeps413;
	
	CBpcstpmtcxl  m_cpc;

};

#endif /*SENDBEPS413_H*/


