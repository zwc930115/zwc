/*
 * 	recvbeps415.cpp
 *	Description: ʵʱ����֪ͨ����beps.415.001.01������
 *  Created on: 2012-07-09
 *  Author: __wsh
 */

#ifndef RECVBEPS415_H
#define RECVBEPS415_H

#include "beps415.h"
#include "recvbepsbase.h"

#include "bpcstpmtcxl.h" 

class CRecvBeps415 : public CRecvBepsBase
{
public:
    CRecvBeps415();

    ~CRecvBeps415();

    INT32 Work(LPCSTR szMsg);
    
private:
    int UnPack(LPCSTR szMsg);

    void SetData(void);

    int InsertData(void);

    void  CheckSign415(void);

    int UpdateBusState(void);

    void  GetSql(const string strTableName,string &strSql);
	
private:
    beps415           m_cBeps415;
    
    CBpcstpmtcxl      m_cpc;
};

#endif /*RECVBEPS415_H*/


