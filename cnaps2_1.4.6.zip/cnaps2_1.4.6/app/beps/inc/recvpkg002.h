/******************************************************************** 
�ļ����� recvpkg002.h
�����ˣ� handongfeng
��  �ڣ� 2011-04-15
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifndef __RECVPKG002_H__
#define __RECVPKG002_H__

#include "recvbepsbase.h"
#include "pkg002.h"
#include "bpbdrecvlist.h"
#include "bpbdrcvcl.h"

class CRecvPkg002 : public CRecvBepsBase
{
public:
	CRecvPkg002();
	~CRecvPkg002();
	INT32 Work(LPCSTR szMsg);
    
private:
	INT32 unPack(LPCSTR szMsg);
	INT32 InsertDb(LPCSTR pchMsg);
    INT32 CheckAcct();
    INT32 CheckMac002();
	void ParserAppData(const char* szSrcAppData, string& szDstAppData);
    
	pkg002         m_pkg002;
	CBpbdrecvlist  m_BpBdList;
	CBpbdrcvcl     m_BpBdCl;
};

#endif


