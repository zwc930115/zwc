#ifndef RECVBEPS131_H
#define RECVBEPS131_H

#include "recvbepsbase.h"
#include "beps131.h"
#include "beps132.h"

#include "bpbdrecvlist.h" 
#include "bpbdrcvcl.h" 
#include "bpbcoutsendlist.h" 
#include "bpbcoutsndcl.h" 

class CRecvBeps131 : public CRecvBepsBase
{
public:
	CRecvBeps131();

	~CRecvBeps131();

	INT32 Work(LPCSTR szMsg);

private:
	int  UnPack(const char* szmsg);

	int  InsertData(void);

	int  InsertData_bc_cl(void);

	int  InsertData_bc_list(void);

	int  InsertData_bd_cl(void);

	int  InsertData_bd_list(void);

	void SetReply(void);

	int  BuildReplyMsg132(void);

	void ChkSign131(void);

	void AddSign132(void);

	int  DoReply(void);

private:
	beps131          m_cBeps131;

	beps132          m_cBeps132;

	CBpbcoutsndcl    m_bcsndcl;

	CBpbcoutsendlist m_bcsndlist;

	CBpbdrcvcl       m_bdrcvcl;

	CBpbdrecvlist    m_bdrcvlist;

	string           m_strNpcMsg;

	char             m_szRefId[32+1];

	char             m_szMsgId[32+1];

	char             m_szTxId[32+1];

};

#endif /*RECVBEPS131_H*/


