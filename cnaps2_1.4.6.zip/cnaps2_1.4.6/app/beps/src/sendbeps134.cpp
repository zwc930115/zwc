/******************************************************************** 
�ļ����� sendbeps134.cpp
�����ˣ� hq
��  �ڣ� 2011-04-12
�޸��ˣ� 
��  �ڣ� 
��  ���� ���ڽ��ҵ���ִ����< beps.134.001.01>���˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps134.h"
#include "bpbcoutsndcl.h" 

using namespace ZFPT;

CSendBeps134::CSendBeps134(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{

}

CSendBeps134::~CSendBeps134()
{

}

INT32 CSendBeps134::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps134::doWorkSelf");
    
    CreatPmtsMsg();
    
    //�޸�״̬/NPCMSG
    UpdateStat(PR_HVBP_08, m_sMsgId);

    //����Զ�̶���
    AddQueue();

    //�޸�ԭҵ��״̬
    //UpdateOriStat(PR_HVBP_07, m_cBpbcoutsendlist.m_orgnlmsgid.c_str());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps134::doWorkSelf"); 
    return 0;
}

INT32 CSendBeps134::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps134::CheckValues");

    int iRet = -1;
    
    //������޼��
    iRet = isOutOfLimit(m_dbproc, 
                        m_cBpbcoutsendlist.m_msgtp.c_str(), 
                        m_cBpbcoutsendlist.m_purpprtry.c_str(),
                        m_cBpbcoutsendlist.m_amount, 
                        m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_AMT_OUT_OF_LIMIT, m_sErrMsg);
    }
    
    //�����кż��
    iRet = isBankRight(m_dbproc, m_cBpbcoutsendlist.m_instddrctpty.c_str(), m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_RECVBANK_CHECK_FAIL, m_sErrMsg);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps134::CheckValues"); 
    return 0;
}

void CSendBeps134::CreatPmtsMsg()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendBeps134::CreatPmtsMsg()");

	beps134				oBeps134;
	char				sSqlStr[4000 + 1]  = {0};
	string				strWhereClause	= "";
	int					iRetCode		= RTN_FAIL;
	char				sTemp[255]		= { 0 };
	
	
	//ȡ��ϸ������ϸ
	SETCTX(m_cBpbcoutsendlist);

	strWhereClause = strWhereClause + "msgid = '" + m_sMsgId + "' " + "and procstate = " + PR_HVBP_95 + "  order by txid ";
	
	iRetCode = m_cBpbcoutsendlist.find(strWhereClause);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(m_sErrMsg, "oBpbdsndlist.find:��ѯ����¼��, [%d][%s]",
			iRetCode, m_cBpbcoutsendlist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);

        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_sErrMsg);
    }
	
	int nTotal = 0;
	int nTotalOk = 0;
	double dAmtOk = 0.0;

	while(SQL_SUCCESS == iRetCode)
	{
		iRetCode = m_cBpbcoutsendlist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
			break;
		if (SQL_SUCCESS != iRetCode) 
		{
		    //�ر��α�
            m_cBpbcoutsendlist.closeCursor();
            
			sprintf(m_sErrMsg, "m_cBpbcoutsendlist.fetch:��ѯ��ϸ����¼��, [%d][%s]",
				iRetCode, m_cBpbcoutsendlist.GetSqlErr()); 
			
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_sErrMsg);
	
			PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_sErrMsg);
		}

       
        memset(sTemp,0,sizeof(sTemp));
        oBeps134.StsId               = m_cBpbcoutsendlist.m_replystate;
        oBeps134.OrgnlTxId           = m_cBpbcoutsendlist.m_oritxid;
        oBeps134.RsnPrtry            = m_cBpbcoutsendlist.m_replyprocesscode ;
        oBeps134.TxInfAndStsAddtlInf = m_cBpbcoutsendlist.m_replyrjctinf;
        char szAmt[32] = {0};
        sprintf(szAmt, "%.02f", m_cBpbcoutsendlist.m_oriamount);
        oBeps134.IntrBkSttlmAmt      = szAmt;
        oBeps134.Ccy                 = m_cBpbcoutsendlist.m_currency;
        oBeps134.CtgyPurpPrtry       = m_cBpbcoutsendlist.m_pmttpprtry;
        oBeps134.OrgnlCdtrAgtMmbId   = m_cBpbcoutsendlist.m_instddrctpty ;
        oBeps134.OrgnlCdtrAgtId      = m_cBpbcoutsendlist.m_cdtrissr ;
        oBeps134.Ustrd               = m_cBpbcoutsendlist.m_addtlinf ;
        oBeps134.DbtrAgtMmbId        = m_cBpbcoutsendlist.m_instgdrctpty ;
        oBeps134.DbtrAgtId           = m_cBpbcoutsendlist.m_dbtrissr ;
        oBeps134.CdtrAgtMmbId        = m_cBpbcoutsendlist.m_instddrctpty ;
        oBeps134.CdtrAgtId           = m_cBpbcoutsendlist.m_cdtrissr;

        ++nTotal;
		if (m_cBpbcoutsendlist.m_replystate == "PR02"){
			++nTotalOk;
			dAmtOk += m_cBpbcoutsendlist.m_amount;
		}

        oBeps134.AddDetail();	        
    }
    
    //�ر��α�
    m_cBpbcoutsendlist.closeCursor();

    CBpbcoutsndcl oBpbcoutsndcl;
    oBpbcoutsndcl.m_msgid = m_sMsgId;
    oBpbcoutsndcl.m_instgdrctpty = m_sSendOrg;
    
    SETCTX(oBpbcoutsndcl);

    iRetCode = oBpbcoutsndcl.findByPK();
    if (SQLNOTFOUND == iRetCode)
	{
		sprintf(m_sErrMsg,"oBpbcoutsndcl.findByPK failed:[%s],[%s],[%d][%s]", 
            m_sSendOrg, m_sMsgId, iRet, oBpbcoutsndcl.GetSqlErr());
		
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);
		
	} 	
	else if (SQL_SUCCESS != iRetCode) 
	{
		sprintf(m_sErrMsg,"oBpbcoutsndcl.findByPK failed:[%d][%s]", iRet, oBpbcoutsndcl.GetSqlErr());
		
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}

    Trace(L_DEBUG, __FILE__, __LINE__, NULL,
    			"nTotal[%d], nTotalOk[%d], dAmtOk[%0.2f]", nTotal, nTotalOk, dAmtOk);

	
	oBeps134.MsgId                  =	m_sMsgId;
	oBeps134.CreDtTm                =	m_sIsoWorkDate;
    oBeps134.OrgnlMsgId             =   m_cBpbcoutsendlist.m_orgnlmsgid;
    oBeps134.OrgnlMsgNmId           =   m_cBpbcoutsendlist.m_orgnlmsgtp;
    memset(sTemp,0,sizeof(sTemp));
    oBeps134.OrgnlNbOfTxs           =   itoa(sTemp, nTotalOk);// ��ִ��ϸҵ��ɹ��ܱ���
    memset(sTemp,0,sizeof(sTemp));
    oBeps134.OrgnlCtrlSum           =   ftoa(sTemp, dAmtOk, 2);;//��ִ��ϸҵ��ɹ��ܽ��
    oBeps134.AddtlInf               =   m_cBpbcoutsendlist.m_rjctinf;
    memset(sTemp,0,sizeof(sTemp));
    oBeps134.DtldNbOfTxs            =   itoa(sTemp, nTotal);//��ִ��ϸҵ���ܱ���
    oBeps134.DtldSts                =   "ACCP"; //__wsh 2012-05-07 //m_cBpbcoutsendlist.m_busistate;		
	oBeps134.CtgyPurpPrtry          = 	m_cBpbcoutsendlist.m_pmttpprtry	;//ҵ�����ͱ���
	
	
	//��ȡ����ͨѶ���
	if(false == GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS))
	{
		Trace(L_INFO,  __FILE__,  __LINE__,NULL, "��ȡ����ͨѶ���ʧ�ܣ�");		
		PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_MESGREFID_FAIL, "��ȡ����ͨѶ���ʧ�ܣ�");
	}
    
	//�鱨��ͷ
	oBeps134.CreateXMlHeader("BEPS", 
								m_sWorkDate,
								m_cBpbcoutsendlist.m_instgdrctpty.c_str(),
								m_cBpbcoutsendlist.m_instddrctpty.c_str(),
				  				"beps.134.001.01",
				  				m_sMsgRefId);
	
	//��ǩ
	AddSign134(oBeps134);
	
	int iRet = oBeps134.CreateXml();
	if (0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��������beps.134.001.01����ʧ��[%d]", iRet);	
		PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, NULL);
	}
	
    m_sMsgTxt = oBeps134.m_sXMLBuff;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendBeps134::CreatPmtsMsg()");
}

int CSendBeps134::UpdateStat(LPCSTR sProcstate,LPCSTR pMsgid)
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps134::UpdateStat");

    SETCTX(m_cBpbcoutsendlist);

    //���»��ܱ�    
    sprintf(m_sSqlStr, "UPDATE BP_BCOUTSNDCL t SET "
            			" t.PROCSTATE = '%s', t.MESGID='%s', t.MESGREFID='%s'"
            			" WHERE t.MSGID = '%s' and t.INSTGDRCTPTY='%s'",/*�����*/
            			sProcstate,
            			m_sMsgRefId,
            			m_sMsgRefId,
            			pMsgid,
            			m_cBpbcoutsendlist.m_instgdrctpty.c_str());

    iRet = m_cBpbcoutsendlist.execsql(m_sSqlStr);
    if (iRet != SQL_SUCCESS)
    {
        sprintf(m_sErrMsg,  "update BP_BCOUTSNDCL  is error!iRet=[%d]", iRet);
        Trace(L_ERROR, __FILE__, __LINE__, pMsgid, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
    }

    //������ϸ��
    sprintf(m_sSqlStr, "UPDATE bp_bcoutsendlist t SET "
            			" t.PROCSTATE = '%s'"
            			" WHERE t.MSGID = '%s' and t.INSTGDRCTPTY='%s'",/*�����*/
            			sProcstate,
            			pMsgid,
            			m_cBpbcoutsendlist.m_instgdrctpty.c_str());

    iRet = m_cBpbcoutsendlist.execsql(m_sSqlStr);
    if (iRet != SQL_SUCCESS)
    {
        sprintf(m_sErrMsg,  "update bp_bcoutsendlist  is error!iRet=[%d]", iRet);
        Trace(L_ERROR, __FILE__, __LINE__, pMsgid, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps134::UpdateStat");
    return 0;
}

int CSendBeps134::UpdateOriStat(LPCSTR sProcstate,LPCSTR pMsgid)
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps134::UpdateOriStat");

    SETCTX(m_cBpbcoutsendlist);

    //���»��ܱ�    
    sprintf(m_sSqlStr, "UPDATE BP_BDRCVCL t SET t.STATETIME = sysdate,"
            			" t.PROCSTATE = '%s'"   
            			" WHERE t.MSGID = '%s'",/*�����*/
            			sProcstate,
            			pMsgid);

    iRet = m_cBpbcoutsendlist.execsql(m_sSqlStr);
    if (iRet != SQL_SUCCESS)
    {
        sprintf(m_sErrMsg,  "update BP_BDRCVCL  is error!iRet=[%d][%s]", iRet,m_cBpbcoutsendlist.GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, pMsgid, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
    }

    //������ϸ��
    sprintf(m_sSqlStr, "UPDATE BP_BDRECVLIST t SET t.STATETIME = sysdate,"
            			" t.PROCSTATE = '%s'"   
            			" WHERE t.MSGID = '%s'",/*�����*/
            			sProcstate,
            			pMsgid);

    iRet = m_cBpbcoutsendlist.execsql(m_sSqlStr);
    if (iRet != SQL_SUCCESS)
    {
        sprintf(m_sErrMsg,  "update BP_BDRECVLIST  is error!iRet=[%d] [%s]", iRet,m_cBpbcoutsendlist.GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, pMsgid, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps134::UpdateOriStat");
    return 0;
}

INT32 CSendBeps134::SetErrACK(int iErrCode, LPCSTR pErrDesc)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps134::SetErrACK");

	//�޸�״̬Ϊ"���޸�"
    UpdateStat(PR_HVBP_93,m_sMsgId);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps134::SetErrACK");
	return 0;
}

int CSendBeps134::ChargeMB()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBeps134::ChargeMB...");

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBeps134::ChargeMB..."); 
    
    return RTN_SUCCESS;
}

int CSendBeps134::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBeps134::FundSettle...");
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û�[%s]", m_szOprUser);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_sSendOrg);

	m_charge.m_amount = m_cBpbcoutsendlist.m_amount;	//ҵ����
	m_charge.m_iDCFlag = iDEBITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, m_szOprUserNetId);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_sSendOrg);	//������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(RTN_SUCCESS != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FundSettle iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBeps134::FundSettle..."); 
    
    return RTN_SUCCESS;
}

//__wsh 2012-05-07 ��ǩ
void CSendBeps134::AddSign134(beps134& xml134)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBeps134::AddSign134...");

	char   sSignedStr[4096 + 1] = {0};
	
	xml134.getOriSignStr();
	
	AddSign(xml134.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_cBpbcoutsendlist.m_instgdrctpty.c_str());
	
	xml134.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBeps134::AddSign134...");
}
