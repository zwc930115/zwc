/********************************************************************
文件名：sendbepsbase.cpp
创建人：zhj
日  期   ：2011-03-02
修改人：
日  期：
描  述：   beps往帐处理基类
版  本：
Copyright (c) 2011  YLINK
********************************************************************/
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbepsbase.h"
#include "bppkgassist.h" 
#include "bppkgassist1.h" 
#include "sysrecvfrommb.h"
#include "basicapi.h"

#include "md5.hpp"

using namespace ZFPT;

extern char			g_MQmgr[256];
extern char			g_MqTxtPath[256];
extern char			g_SendQueue[128];
extern char			g_ReturnQueue[128];
extern int          g_xmlpack;
extern int          g_pkgpack;
extern int			g_IsConnPlatm;
extern int      g_iCfcaSign;
extern CMutex g_Mutex;

CSendBepsBase::CSendBepsBase(const stuMsgHead& Smsg)
{
	memset(m_sErrMsg, '\0', sizeof(m_sErrMsg));
	memset(m_sSqlStr, '\0', sizeof(m_sSqlStr));
	memset(m_sSapBank, '\0', sizeof(m_sSapBank));
	memset(m_sWorkDate, '\0', sizeof(m_sWorkDate));
	memset(m_sIsoWorkDate, '\0', sizeof(m_sIsoWorkDate));
	memset(m_sMsgRefId, '\0', sizeof(m_sMsgRefId));
	memset(m_sMesgID, '\0', sizeof(m_sMesgID));
	memset(m_sPkgDtNSn, '\0', sizeof(m_sPkgDtNSn));
	memset(m_sPkgDest, '\0', sizeof(m_sPkgDest));
	memset(m_sSrcFlag, '\0', sizeof(m_sSrcFlag));

    memset(m_sSysName, '\0', sizeof(m_sSysName));
    memset(m_sMsgUse, '\0', sizeof(m_sMsgUse));
    memset(m_sMsgType, '\0', sizeof(m_sMsgType));
    memset(m_sMsgNo, '\0', sizeof(m_sMsgNo));
    memset(m_sMsgId, '\0', sizeof(m_sMsgId));
    memset(m_sSendOrg, '\0', sizeof(m_sSendOrg));
    memset(m_szConsignDate, '\0', sizeof(m_szConsignDate));
    memset(m_ISODateTime, '\0', sizeof(m_ISODateTime));
    memset(m_BusinessType, '\0', sizeof(m_BusinessType));
	memset(m_user, '\0', sizeof(m_user));
	memset(m_EndFlag, '\0', sizeof(m_EndFlag));
	memset(m_szOprUser, 0x00, sizeof(m_szOprUser));
	memset(m_szOprUserNetId, 0x00, sizeof(m_szOprUserNetId));
	memset(m_szReserve, 0x00, sizeof(m_szReserve));
	
	m_strSendMsg = "";
	
	strcpy(m_sSysName,Smsg.szSysType);
    StrUpperCase_ZFPT(m_sSysName);
	strcpy(m_sMsgUse,Smsg.szMsgUse);
	strcpy(m_sMsgType, Smsg.szMsgType);
	strcpy(m_sMsgNo,Smsg.szMsgTypeFlag);
	strcpy(m_sMsgId,Smsg.szMsgFlagNO);
	strcpy(m_sSendOrg,Smsg.szSndNO);
	strcpy(m_BusinessType, Smsg.szMsgKind);
	strcpy(m_szOprUser, Smsg.szOprUser);	//操作用户 
	strcpy(m_szOprUserNetId, Smsg.szOprUserNetId);

	
    //这里要做判断:区分是行内发起还是客户端发起
    if(0 == STRNCASECMP(SP_MB_USERID,m_szOprUser,strlen(SP_MB_USERID)))
	{
		strcpy(m_szSrcflg,SRC_FRMB);
	}
	else
	{
		strcpy(m_szSrcflg,SRC_FRCLIENT);
	}
	
	trim(m_sSendOrg);
	trim(m_sMsgId);
	Trim(m_szOprUser);
	Trim(m_szOprUserNetId);
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSysName       = [%s]",m_sSysName);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sMsgUse        = [%s]",m_sMsgUse);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sMsgType       = [%s]",m_sMsgType);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sMsgNo         = [%s]",m_sMsgNo);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sMsgId         = [%s]",m_sMsgId);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSendOrg       = [%s]",m_sSendOrg);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_BusinessType   = [%s]",m_BusinessType);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_user           = [%s]",m_user);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_EndFlag        = [%s]",m_EndFlag);
}


CSendBepsBase::~CSendBepsBase()
{
}

void CSendBepsBase::AddAppendData(const string& strSrcAppData, char* szBussType[], string& strAppData,int iCount, int iArraySize)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBepsBase::AddAppendData");
    
    int j = 0;
    int iNum = 0;
    int iFlag = 0;

    for(int i = 1; i <= iCount; i++)
    {
        if(0 == iFlag%iArraySize)
        {
            j = 0;
        }
        else
        {
            ++j;
        }

        string strTemp = "";
        GetTagVal(strTemp, strSrcAppData, "72C:", i);
        
        char szTmp[5024 + 1] = {0};
        if(0 != strstr(szBussType[j], "d"))//明细条数一定给"% d"
        {
            iNum = atoi(strTemp.c_str());
            sprintf(szTmp, szBussType[j], iNum);
            Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__%s__%d__", szBussType[j], iNum);
            ++iFlag;
            strAppData.append(szTmp);
            continue;
            
        }else if(0 != strstr(szBussType[j], "*s"))//循环体给"*s",默认循环体里全部是字符串前补空格,如果有需要前加0的要特殊处理
        {
            for(int n=1; n <= iNum; n++)
            {
                GetTagVal(strTemp, strSrcAppData, "72C:", i);
                Trace(L_DEBUG, __FILE__, __LINE__, NULL, "*____s_%d_%s", n, strTemp.c_str());
                strAppData.append(strTemp);
                ++i;
            }
            --i;
            j = 0;
            ++iFlag;
            continue;
        }
        else
        {
            if(strTemp.length() < sizeof(szTmp))
            {
                //Trace(L_DEBUG, __FILE__, __LINE__, NULL, "___before__strTemp=%s", strTemp.c_str());
                //附加域的金额字段不带RMB
                //modifed by _wsh 04/23/2012
                if(strstr(strTemp.c_str(), "RMB") != NULL){
            		sprintf(szTmp, szBussType[j], strTemp.c_str() + 3);
            	}
            	else{
                    sprintf(szTmp, szBussType[j], strTemp.c_str());
                }  
                ///Trace(L_DEBUG, __FILE__, __LINE__, NULL, "_____szTmp = %s", szTmp);     
            }
            else
            {
                char szTemp1[300000] = {0};
                sprintf(szTemp1, szBussType[j], strTemp.c_str());
                ++iFlag;
                Trace(L_DEBUG, __FILE__, __LINE__, NULL, "szTemp1 = %s", szTemp1);
                strAppData.append(szTemp1);       
                continue;
            }
        }
        
        ++iFlag;
        
        //if this field encodeed with utf-8, change to gbk
        //modifed by _wsh 04/23/2012
        if( IsUTF8(szTmp, strlen(szTmp)) )
        {
            char szGbk[sizeof(szTmp)] = {0};
            changeEncode(szTmp, szGbk, "UTF-8", "GB18030");
            memset(szTmp, 0x00, sizeof(szTmp));
            sprintf(szTmp, szBussType[j], szGbk);
        }
       
        strAppData.append(szTmp);
        
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "____szTmp=%s", szTmp);    
        
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leave CSendBepsBase::AddAppendData");    
}

void CSendBepsBase::Utf8ToGbk(char* szData, int nSize, const char* fmt)
{
	if( IsUTF8(szData, nSize)){
		char szGbk[5120 + 1] = {0};
		changeEncode(szData, szGbk, "UTF-8", "GB18030");
		memset(szData, 0x00, nSize);
		sprintf(szData, fmt, szGbk);
	}
}

//__wsh
void CSendBepsBase::FormatAppendData(string& strDest, const string& strSrc, int nCnt,
    		char* szBizFmts[], int nBfCnt, char* szDtlFmts[], int nDfCnt){

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leave CSendBepsBase::FormatAppendData");
    
	int nAdNo = 0;

	int nDtlNum = 0;

	const char* _tag = "72C:";

	string strTagVal = "";

	char szTmp[5120 + 1] = {0};

	for(int i = 0; i < nCnt; ++i){
		nAdNo = i + 1;

        strTagVal = "";
		GetTagVal(strTagVal, strSrc, _tag, nAdNo);

		memset(szTmp, 0x00, sizeof(szTmp));
		if(strstr(szBizFmts[i], "d") != NULL){
			
			nDtlNum = atoi(strTagVal.c_str());
			Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__%d_%s_%d", nDtlNum, szBizFmts[i], i);
			sprintf(szTmp, szBizFmts[i], nDtlNum);
			Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "_________szTmp=%s", szTmp);
			strDest.append(szTmp);

			for(int nCyCnt = 0; nCyCnt < nDtlNum; ++nCyCnt){
				for(int nDtlNo = 0; nDtlNo < nDfCnt; ++nDtlNo){
					++nAdNo;

					strTagVal = "";
					memset(szTmp, 0x00, sizeof(szTmp));

					GetTagVal(strTagVal, strSrc, _tag, nAdNo);
					if(strstr(strTagVal.c_str(), "RMB") != NULL){
					    memcpy(szTmp, strTagVal.c_str()+3, strTagVal.length()-3);
					}
					else{
					    memcpy(szTmp, strTagVal.c_str(), strTagVal.length());
					}
					Utf8ToGbk(szTmp, sizeof(szTmp), szDtlFmts[nDtlNo]);
					Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "____szTmp=%s", szTmp);
					strDest.append(szTmp);
				}
			}
			break;
		}
		else{
			if(strTagVal.length() < sizeof(szTmp)){
				if(strstr(strTagVal.c_str(), "RMB") != NULL){
				    memcpy(szTmp, strTagVal.c_str()+3, strTagVal.length()-3);
				}
				else{
				    memcpy(szTmp, strTagVal.c_str(), strTagVal.length());
				}
				Utf8ToGbk(szTmp, sizeof(szTmp), szBizFmts[i]);
				Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "__^^^^__szTmp=%s", szTmp);
				strDest.append(szTmp);
			}
			else{
				char szTmp1[300000+1] = {0};
				sprintf(szTmp1, szBizFmts[i], strTagVal.c_str());
				strDest.append(szTmp1);
			}
		}
	}//end for
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leave CSendBepsBase::FormatAppendData");
}

int CSendBepsBase::AddSign(const char *srcSign, char *dstSign, int iFlag, const char * pSendSapbank)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBepsBase::AddSign...");

    char *Str = new char[strlen(srcSign) + 1];
    ISNULL(Str);
    strcpy(Str, srcSign);
    int iRet = digitSign(m_dbproc, signTrim(Str), dstSign, SYS_BEPS, iFlag, pSendSapbank);
    DELPOINT(Str);
	if( RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "数字签名加签失败");
		PMTS_ThrowException(OPT_DIGITSIGN_FAIL);
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBepsBase::AddSign...");
    return RTN_SUCCESS;
}

INT32 CSendBepsBase::doWork()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendBepsBase::doWork()");	
	
	int iRet = 0;
    try
    {
		//2.获取Mq连接
		GetMqConn();
		
    	//3.获取数据库连接
        GetDBConnect();
	
		//4.初始化系统参数
    	InitSysParam();
    	
        //5.子业务入口
        int iRet = doWorkSelf();

        if(RTN_SUCCESS == iRet)
        {
            SETCTX(m_bprecv);
            m_bprecv.commit();
    		m_cMQAgent.Commit();
        }
        else
        {
            SETCTX(m_bprecv);
            m_bprecv.rollback();
    		m_cMQAgent.RollBack();
            Trace(L_ERROR, __FILE__, __LINE__, NULL, "子业务处理失败!iRet = [%d]",iRet);
        }

        g_Mutex.unLock();
    }
    catch(CException &e)
    {        
        g_Mutex.unLock();

        sprintf(m_sErrMsg, "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
		INT_SETCTX(m_bprecv);
		m_bprecv.rollback();

		SetErrACK(e.code(), e.what());

		m_bprecv.commit();
        
		iRet = e.code();
    }
    catch(...)
    {
        g_Mutex.unLock();
        
        Trace(L_ERROR, __FILE__, __LINE__, NULL,"Catch an unkown exception ");
		INT_SETCTX(m_bprecv);
		m_bprecv.rollback();

		SetErrACK(OTH_ERR, "Catch an unkown exception ");

		m_bprecv.commit();
		iRet = OTH_ERR;
    }

	stuSndMsg SndMsg;
    memset(&SndMsg, 0x00, sizeof(SndMsg));
    sprintf(SndMsg.szErrorCode, "%04d", iRet);
    GetErrDsc(iRet, SndMsg.szErrorDesc);
    
    SendToMB(SndMsg);
    
	//5.释放连接
    g_DBConnPool->PutConnect(m_dbproc);	
        
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendBepsBase::doWork()");	

	return iRet;
}


void CSendBepsBase::GetDBConnect(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendBepsBase::GetDBConnect()");	

    if(0 != g_DBConnPool->GetConnect(m_dbproc))
    {
        snprintf(m_sErrMsg, sizeof(m_sErrMsg), 
			"CRecvBepsBase::GetDBConnect():获取数据库连接失败");
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, m_sErrMsg);
    }

	m_charge.m_dbproc = m_dbproc;	//初始化记账类
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendBepsBase::GetDBConnect()");		
}

void CSendBepsBase::GetMqConn(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendBepsBase::GetMqConn()");	
	
	 //初始化MQ
    if(0 != m_cMQAgent.Init(g_MQmgr, g_MqTxtPath))
    {
    	snprintf(m_sErrMsg, sizeof(m_sErrMsg), 
			"CSendBepsBase::GetMqConn(),Init Thread MQ manager failed.");
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
        PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_MQ_CNNCT_FAIL, m_sErrMsg);
    }
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendBepsBase::GetMqConn()");		
}


int CSendBepsBase::InitSysParam()
{
	int iRet = GetSysParam(m_dbproc,"01", m_sSapBank);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取系统参数失败");
        PMTS_ThrowException(OPT_GET_SYS_PARA_FAIL);
    }
    
    iRet = GetWorkDate(m_dbproc,m_sWorkDate, SYS_BEPS, m_sSapBank);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败");
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    
    iRet = GetIsoDateTime(m_dbproc,SYS_BEPS,m_sIsoWorkDate);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败");
        PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }
    
    //hdf add
    m_iVersion = (strcmp(m_sMsgType, "XML")?MSG_VER_1ST:MSG_VER_2ND);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_sMsgType= [%s]",     m_sMsgType);
    if(MSG_VER_1ST == m_iVersion)
    {
        int Offset = 0;
        OffsetCpy(m_szConsignDate, m_sMsgId, Offset, 8, true);
        OffsetCpy(m_szMsgSerial, m_sMsgId, Offset, 20, true);
        trim(m_szConsignDate);
        trim(m_szMsgSerial);
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_szConsignDate[%s], m_szMsgSerial[%s]",m_szConsignDate, m_szMsgSerial);
    }
    
    strncpy(m_sSrcFlag,"0",sizeof(m_sSrcFlag)-1);
    return 0;	
}


int CSendBepsBase::UpPKGAssist(LPTSTR pMsgId)
{
    g_Mutex.lock();

    CBppkgassist m_pkgassist;

    char db_MsgId[35 + 1]   = {0};
    char szWrkDate[8 + 1]   = {0};
    char szSqlStr[4096 + 1] = {0};
    int  db_nCount          = 0;
    int  iRet               = 0;
    int  iChgTp             = -1;  //0查询无记录,1笔数小于,2笔数等于,3笔数大于,4更新未找到记录
    string whereClause      = "";
    char sMsgNo[3 + 1]      = {0};
    int  iMsgNo             = 0;
    char sIsRspn[1 + 1]     = {0};

    strcpy(sIsRspn, "0");
    
	memcpy(sMsgNo,    m_strAssist.sMsgType + 5, sizeof(sMsgNo) - 1);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strAssist.sMsgType[%s] sMsgNo[%s]", m_strAssist.sMsgType, sMsgNo);
	
	iMsgNo = atoi(sMsgNo);

    if ( 121 == iMsgNo || 122 == iMsgNo || 130 == iMsgNo ) /*客户/金融机构发起普通贷记/CIS通用回执*/
	{
        sprintf(szSqlStr, " SENDBANK = '%s' AND RECVBANK = '%s' "
                          " AND MSGTYPE = '%s' AND PROCSTATE = '00' ", 
                m_strAssist.sSendBank, 
                m_strAssist.sRecvBank, 
                m_strAssist.sMsgType);
    }
    else if ( 127 == iMsgNo ) /*普通借记*/
	{
        sprintf(szSqlStr, " SENDBANK = '%s' AND RECVBANK = '%s' AND MSGTYPE = '%s' "
                          " AND PKGRTRLTD = '%d' AND PROCSTATE = '00' ", 
                          m_strAssist.sSendBank, 
                          m_strAssist.sRecvBank, 
                          m_strAssist.sMsgType,
                          m_strAssist.iPkgRtrltd);
    }
    else if ( 125 == iMsgNo ) /*定期贷记*/
	{
        sprintf(szSqlStr, " SENDBANK = '%s' AND RECVBANK = '%s' AND MSGTYPE = '%s' "
                          " AND PMTTPPRTRY = '%s' AND  ISSR = '%s'  "
                          " AND ACCTID = '%s' AND PROCSTATE = '00' ", 
                          m_strAssist.sSendBank, 
                          m_strAssist.sRecvBank, 
                          m_strAssist.sMsgType,
                          m_strAssist.sPmttpPrtry,
                          m_strAssist.sIssr,
                          m_strAssist.sAcctId);
    }
    else if ( 133 == iMsgNo ) /*定期借记*/
	{
        sprintf(szSqlStr, " SENDBANK = '%s' AND RECVBANK = '%s' AND MSGTYPE = '%s' "
                          " AND PMTTPPRTRY = '%s' AND  ISSR = '%s'  "
                          " AND ACCTID = '%s' AND PKGRTRLTD = '%d' AND PROCSTATE = '00' ", 
                          m_strAssist.sSendBank, 
                          m_strAssist.sRecvBank, 
                          m_strAssist.sMsgType,
                          m_strAssist.sPmttpPrtry,
                          m_strAssist.sIssr,
                          m_strAssist.sAcctId,
                          m_strAssist.iPkgRtrltd);
    }
    else if ( 128 == iMsgNo || 134 == iMsgNo ) /*定期/普通借记回执*/
	{
        sprintf(szSqlStr, " SENDBANK = '%s' AND RECVBANK = '%s' AND MSGTYPE = '%s' "
                          " AND ORIMSGTP = '%s' AND  ORIMSGID = '%s' AND PROCSTATE = '00' ", 
                          m_strAssist.sSendBank, 
                          m_strAssist.sRecvBank, 
                          m_strAssist.sMsgType,
                          m_strAssist.sOriMsgTp,
                          m_strAssist.sOriMsgId);
       strcpy(sIsRspn, "1");
    }
    else
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "不支持的报文类型[%d]", iMsgNo);	
        return -1;
    }

    if (0 != m_pkgassist.setctx(m_dbproc))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
        return -1;
    }
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "szSqlStr = [%s]",szSqlStr);

    whereClause = szSqlStr;
    iRet = m_pkgassist.find(whereClause);
    if ( 0 != iRet )
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_pkgassist.find error [%d][%s]",iRet,m_pkgassist.GetSqlErr());	
        return iRet;
    }

    iRet = m_pkgassist.fetch();
    if ( SQLNOTFOUND == iRet )
    {
        iChgTp = 0; //没有记录,需要新增
    }
    else if (SQL_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Select Bp_Pkgassist Is ERROR[%d][%s]", 
            iRet, m_pkgassist.GetSqlErr()); 
            
        m_pkgassist.closeCursor();
        return iRet;
    }
    else
    {
        db_nCount = m_pkgassist.m_listcount;
        strcpy(pMsgId, m_pkgassist.m_msgid.c_str());
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "pMsgId[%s]", pMsgId);
    }

    m_pkgassist.closeCursor();
    
    if ( 0 != iChgTp)
    {
        //笔数小于打包笔数,只更新笔数,不新增
        if (db_nCount + 1 < g_xmlpack)
        {
            iChgTp = 1;
            sprintf(szSqlStr, "UPDATE bp_pkgassist SET LISTCOUNT = %d "
                              "WHERE RECVBANK = '%s' AND MSGTYPE = '%s' "
                              "AND MSGID = '%s' AND LISTCOUNT = %d "
                              "AND PROCSTATE = '00' ", 
                              db_nCount + 1, 
                              m_strAssist.sRecvBank, m_strAssist.sMsgType, pMsgId, db_nCount);
        }
        //笔数等于打包笔数,更新笔数和状态(预打包),不新增
        else if (db_nCount + 1 == g_xmlpack)
        {
            iChgTp = 2;
            sprintf(szSqlStr, "UPDATE bp_pkgassist SET LISTCOUNT = %d, PROCSTATE = '01' "
                              "WHERE RECVBANK = '%s' AND MSGTYPE = '%s' "
                              "AND MSGID = '%s' AND LISTCOUNT = %d "
                              "AND PROCSTATE = '00' ", 
                              db_nCount + 1, 
                              m_strAssist.sRecvBank, m_strAssist.sMsgType, pMsgId, db_nCount);            
        }
        //笔数大于打包笔数,更新状态(预打包),同时新增,这种情况一般不会出现,特殊情况用
        else if (db_nCount + 1 > g_xmlpack)
        {   
            iChgTp = 3; 
            sprintf(szSqlStr, "UPDATE bp_pkgassist SET PROCSTATE = '01' "
                              "WHERE RECVBANK = '%s' AND MSGTYPE = '%s' "
                              "AND MSGID = '%s' AND LISTCOUNT = %d "
                              "AND PROCSTATE = '00' ",  
                              m_strAssist.sRecvBank, m_strAssist.sMsgType, pMsgId, db_nCount);           
        }
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
            "iChgTp=[%d],szSqlStr=[%s]", iChgTp, szSqlStr);
            
        iRet = m_pkgassist.execsql(szSqlStr);
        if (SQLNOTFOUND == iRet )
        {
            iChgTp = 4; //如果查询有记录,更新没找到记录,需新增
        }
        else if (SQL_SUCCESS != iRet)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "UpDate Bp_Pkgassist Is ERROR, ErrorCode[%s], ErrorDesc[%s]", 
                iRet, m_pkgassist.GetSqlErr());

            return iRet;
        }
        
        if ( 1 == iChgTp || 2 == iChgTp )
        {
            return 0;//笔数小于或等于打包笔数,且更新成功,返回成功
        }
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iChgTp=[%d]", iChgTp);
            
    //新增一条记录
    //a.生成包序号/报文标识号
    memset(db_MsgId, 0, sizeof(db_MsgId));
    if ( !GetMsgIdValue(m_dbproc, db_MsgId, eMsgId, SYS_BEPS, m_strAssist.sSendBank, m_sErrMsg) )
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "GetMsgIdValue error"); 
        return -2;
    }
    memcpy(szWrkDate, db_MsgId, sizeof(szWrkDate) - 1);
    
    //b.赋值
    m_pkgassist.m_wrkdate      = szWrkDate;
    m_pkgassist.m_sendbank     = m_strAssist.sSendBank;
    m_pkgassist.m_recvbank     = m_strAssist.sRecvBank;
    m_pkgassist.m_msgtype      = m_strAssist.sMsgType;

    m_pkgassist.m_pkgrtrltd    = m_strAssist.iPkgRtrltd;
    m_pkgassist.m_pmttpprtry   = m_strAssist.sPmttpPrtry;
    m_pkgassist.m_issr         = m_strAssist.sIssr;
    m_pkgassist.m_acctid       = m_strAssist.sAcctId;
    m_pkgassist.m_orimsgtp     = m_strAssist.sOriMsgTp;
    m_pkgassist.m_orimsgid     = m_strAssist.sOriMsgId;
    
    m_pkgassist.m_msgid        = db_MsgId;
    m_pkgassist.m_listcount    = 1;
    
    m_pkgassist.m_handpackflag = "0";
    m_pkgassist.m_isrspn       = sIsRspn;
    m_pkgassist.m_isallrspn    = "0"; //这个如何填，在哪用到,需确认?

    if ( 0 == iChgTp && 1 == g_xmlpack)
        m_pkgassist.m_procstate    = "01";
    else
        m_pkgassist.m_procstate    = "00";
        
    //c.写入打包辅助表
    iRet = m_pkgassist.insert();
    if (DUPLICATE_KEY != iRet && SQL_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Insert Into Bp_Pkgassist Is ERROR[%d][%s]", 
            iRet, m_pkgassist.GetSqlErr());  
        return   iRet;     
    }

    memset(pMsgId, 0x00, sizeof(pMsgId));
    strcpy(pMsgId, db_MsgId);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "db_MsgId[%s]", db_MsgId);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "pMsgId[%s]", pMsgId);
    return 0;
}

int CSendBepsBase::UpPKGAssist1(LPTSTR pMsgId)
{
    g_Mutex.lock();

    CBppkgassist1 m_pkgassist1;

    char db_MsgId[35 + 1]   = {0};
    char szWrkDate[8 + 1]   = {0};
    char szSqlStr[4096 + 1] = {0};
    int  db_nCount          = 0;
    int  iRet               = 0;
    int  iChgTp             = -1;  //0查询无记录,1笔数小于,2笔数等于,3笔数大于,4更新未找到记录
    string whereClause      = "";
    char sMsgNo[3 + 1]      = {0};
    int  iMsgNo             = 0;
    char sIsRspn[1 + 1]     = {0};

    strcpy(sIsRspn, "0");
    
	memcpy(sMsgNo,    m_strAssist.sMsgType + 3, sizeof(sMsgNo) - 1);
	iMsgNo = atoi(sMsgNo);

	if ( 1 == iMsgNo || 7 == iMsgNo ) /*普通贷记/贷记退汇*/
	{
        sprintf(szSqlStr, " SENDBANK = '%s' AND RECVBANK = '%s' "
                          " AND MSGTYPE = '%s' AND PROCSTATE = '00' ", 
                m_strAssist.sSendBank, 
                m_strAssist.sRecvBank, 
                m_strAssist.sMsgType);
    }
    else if ( 2 == iMsgNo ) /*普通借记*/
	{
        sprintf(szSqlStr, " SENDBANK = '%s' AND RECVBANK = '%s' AND MSGTYPE = '%s' "
                          " AND PKGRTRLTD = '%d' AND PROCSTATE = '00' ", 
                          m_strAssist.sSendBank, 
                          m_strAssist.sRecvBank, 
                          m_strAssist.sMsgType,
                          m_strAssist.iPkgRtrltd);
    }
    else if ( 5 == iMsgNo ) /*定期贷记*/
	{
        sprintf(szSqlStr, " SENDBANK = '%s' AND RECVBANK = '%s' AND MSGTYPE = '%s' "
                          " AND PMTTPPRTRY = '%s' AND  ISSR = '%s'  "
                          " AND ACCTID = '%s' AND PROCSTATE = '00' ", 
                          m_strAssist.sSendBank, 
                          m_strAssist.sRecvBank, 
                          m_strAssist.sMsgType,
                          m_strAssist.sPmttpPrtry,
                          m_strAssist.sIssr,
                          m_strAssist.sAcctId);
    }
    else if ( 6 == iMsgNo ) /*定期借记*/
	{
        sprintf(szSqlStr, " SENDBANK = '%s' AND RECVBANK = '%s' AND MSGTYPE = '%s' "
                          " AND PMTTPPRTRY = '%s' AND  ISSR = '%s'  "
                          " AND ACCTID = '%s' AND PKGRTRLTD = '%d' AND PROCSTATE = '00' ", 
                          m_strAssist.sSendBank, 
                          m_strAssist.sRecvBank, 
                          m_strAssist.sMsgType,
                          m_strAssist.sPmttpPrtry,
                          m_strAssist.sIssr,
                          m_strAssist.sAcctId,
                          m_strAssist.iPkgRtrltd);
    }
    else if ( 8 == iMsgNo || 11 == iMsgNo ) /*定期/普通借记回执*/
	{
        sprintf(szSqlStr, " SENDBANK = '%s' AND RECVBANK = '%s' AND MSGTYPE = '%s' "
                          " AND ORIMSGTP = '%s' AND  ORIMSGID = '%s' AND PROCSTATE = '00' ", 
                          m_strAssist.sSendBank, 
                          m_strAssist.sRecvBank, 
                          m_strAssist.sMsgType,
                          m_strAssist.sOriMsgTp,
                          m_strAssist.sOriMsgId);
       strcpy(sIsRspn, "1");
    }
    else
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "不支持的报文类型[%d]", iMsgNo);	
        return -1;
    }
    
    if (0 != m_pkgassist1.setctx(m_dbproc))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
        return -1;
    }
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "szSqlStr = [%s]",szSqlStr); 

    whereClause = szSqlStr;
    iRet = m_pkgassist1.find(whereClause);
    if ( 0 != iRet )
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_pkgassist.find error [%d][%s]",iRet,m_pkgassist1.GetSqlErr());		
        return iRet;
    }

    iRet = m_pkgassist1.fetch();
    if ( SQLNOTFOUND == iRet )
    {
        iChgTp = 0; //没有记录,需要新增
    }
    else if (SQL_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Select Bp_Pkgassist1 Is ERROR[%d][%s]", 
            iRet, m_pkgassist1.GetSqlErr()); 
            
        m_pkgassist1.closeCursor();
        return iRet;
    }
    else
    {
        db_nCount = m_pkgassist1.m_listcount;
        strcpy(pMsgId, m_pkgassist1.m_msgid.c_str());
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "pMsgId[%s]", pMsgId);
    }

    m_pkgassist1.closeCursor();
    
    if ( 0 != iChgTp)
    {
        //笔数小于打包笔数,只更新笔数,不新增
        if (db_nCount + 1 < g_pkgpack)
        {
            iChgTp = 1;
            sprintf(szSqlStr, "UPDATE bp_pkgassist1 SET LISTCOUNT = %d "
                              "WHERE RECVBANK = '%s' AND MSGTYPE = '%s' "
                              "AND MSGID = '%s' AND LISTCOUNT = %d "
                              "AND PROCSTATE = '00' ", 
                              db_nCount + 1, 
                              m_strAssist.sRecvBank, m_strAssist.sMsgType, pMsgId, db_nCount);
        }
        //笔数等于打包笔数,更新笔数和状态(预打包),不新增
        else if (db_nCount + 1 == g_pkgpack)
        {
            iChgTp = 2;
            sprintf(szSqlStr, "UPDATE bp_pkgassist1 SET LISTCOUNT = %d, PROCSTATE = '01' "
                              "WHERE RECVBANK = '%s' AND MSGTYPE = '%s' "
                              "AND MSGID = '%s' AND LISTCOUNT = %d "
                              "AND PROCSTATE = '00' ", 
                              db_nCount + 1, 
                              m_strAssist.sRecvBank, m_strAssist.sMsgType, pMsgId, db_nCount);            
        }
        //笔数大于打包笔数,更新状态(预打包),同时新增,这种情况一般不会出现,特殊情况用
        else if (db_nCount + 1 > g_pkgpack)
        {   
            iChgTp = 3; 
            sprintf(szSqlStr, "UPDATE bp_pkgassist1 SET PROCSTATE = '01' "
                              "WHERE RECVBANK = '%s' AND MSGTYPE = '%s' "
                              "AND MSGID = '%s' AND LISTCOUNT = %d "
                              "AND PROCSTATE = '00' ", 
                              m_strAssist.sRecvBank, m_strAssist.sMsgType, pMsgId, db_nCount);            
        }
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
            "iChgTp=[%d],szSqlStr=[%s]", iChgTp, szSqlStr);
            
        iRet = m_pkgassist1.execsql(szSqlStr);
        if (SQLNOTFOUND == iRet )
        {
            iChgTp = 4; //如果查询有记录,更新没找到记录,需新增
        }
        else if (SQL_SUCCESS != iRet)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "UpDate Bp_Pkgassist1 Is ERROR, ErrorCode[%s], ErrorDesc[%s]", 
                iRet, m_pkgassist1.GetSqlErr());

            return iRet;
        }
        
        if ( 1 == iChgTp || 2 == iChgTp )
        {
            return 0;//笔数小于或等于打包笔数,且更新成功,返回成功
        }
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iChgTp=[%d]", iChgTp);
            
    //新增一条记录
    //a.生成包序号/报文标识号
    memset(db_MsgId, 0, sizeof(db_MsgId));
    if ( !GetMsgIdValue(m_dbproc, db_MsgId, eMsgId, SYS_BEPS, m_strAssist.sSendBank, m_sErrMsg) )
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "GetMsgIdValue error"); 
        return -2;
    }
    memcpy(szWrkDate, db_MsgId, sizeof(szWrkDate) - 1);
    
    //b.赋值
    m_pkgassist1.m_wrkdate      = szWrkDate;
    m_pkgassist1.m_sendbank     = m_strAssist.sSendBank;
    m_pkgassist1.m_recvbank     = m_strAssist.sRecvBank;
    m_pkgassist1.m_msgtype      = m_strAssist.sMsgType;
    
    m_pkgassist1.m_pkgrtrltd    = m_strAssist.iPkgRtrltd;
    m_pkgassist1.m_pmttpprtry   = m_strAssist.sPmttpPrtry;
    m_pkgassist1.m_issr         = m_strAssist.sIssr;
    m_pkgassist1.m_acctid       = m_strAssist.sAcctId;
    m_pkgassist1.m_orimsgtp     = m_strAssist.sOriMsgTp;
    m_pkgassist1.m_orimsgid     = m_strAssist.sOriMsgId;
    
    m_pkgassist1.m_msgid        = db_MsgId;
    m_pkgassist1.m_listcount    = 1;
    m_pkgassist1.m_handpackflag = "0";
    m_pkgassist1.m_isrspn       = sIsRspn;
    m_pkgassist1.m_isallrspn    = "0"; //这个如何填，在哪用到,需确认?
    
    if ( 0 == iChgTp && 1 == g_pkgpack)
        m_pkgassist1.m_procstate = "01";
    else
        m_pkgassist1.m_procstate = "00";

    //c.写入打包辅助表
    iRet = m_pkgassist1.insert();
    if (DUPLICATE_KEY != iRet && SQL_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Insert Into Bp_Pkgassist1 Is ERROR[%d][%s]", 
            iRet, m_pkgassist1.GetSqlErr());  
        return   iRet;     
    }

    memset(pMsgId, 0x00, sizeof(pMsgId));
    strcpy(pMsgId, db_MsgId);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "db_MsgId[%s]", db_MsgId);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "pMsgId[%s]", pMsgId);
    return 0;
}


int CSendBepsBase::AddQueue()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER 向远程队列[%s]发送往账报文",g_SendQueue);
	
	if( 1 == g_IsConnPlatm)   
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "已连接平台 g_IsConnPlatm = [%d]",g_IsConnPlatm);
		m_strSendMsg = "11                                        " + m_sMsgTxt;  //add by xlz  加通讯报文头
	}
	else   
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "未连接平台 g_IsConnPlatm = [%d]",g_IsConnPlatm);
		m_strSendMsg =  m_sMsgTxt;  
    }
    int i = m_strSendMsg.length() ;
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "消息内容:m_strSendMsg=[%s]  length=[%d]  g_SendQueue= [%s]", m_strSendMsg.c_str(), i ,g_SendQueue);
    
    iRet = m_cMQAgent.PutMsg(g_SendQueue, m_strSendMsg.c_str(), i);
    if(0 != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "向远程队列[%s]发送往账报文失败",g_SendQueue);
        PMTS_ThrowException(OPT_MQ_ADD_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE 向远程队列[%s]发送往账报文",g_SendQueue);
    return iRet;
}

void CSendBepsBase::SendToMB(stuSndMsg SndMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBepsBase::SendToMB...");
    int iRet;
    
    //后台发来报文处理,更新接收行内通讯表
    if (0 == strcmp(m_szSrcflg,SRC_FRMB))
    {
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "业务来自行内");
		/*string strSQL;
		CSysrecvfrommb Sysrecvfrommb;
		SETCTX(Sysrecvfrommb);
		iRet = -1;
		strSQL += "UPDATE SYS_RECVFROMMB t SET t.PROCSTATE = '";
		strSQL += strcmp(SndMsg.szErrorCode,"0000")==0?"00":"03";
		strSQL += "' WHERE t.MSGID = '";
		strSQL += m_sMsgId;
		strSQL += "' AND t.SENDBK = '";
		strSQL += m_sSendOrg;
		strSQL += "'";
		
		iRet = Sysrecvfrommb.execsql(strSQL.c_str());
		Sysrecvfrommb.commit();
		if (iRet != SQL_SUCCESS)
		{
		Sysrecvfrommb.rollback();
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "Update sys_recvfrommb failed, sqlcode=[%d]", iRet);
		}*/
    }
    else
    {
          //前台发来报文处理
      int iLen = sizeof(SndMsg.szErrorCode) -1     \
                  + sizeof(SndMsg.szErrorDesc) -1;

      char *strMsg = new char[iLen + 8 + 1];
      memset(strMsg, 0x00, iLen + 8 + 1);
      sprintf(strMsg,"%08d%04s%-60s", iLen, SndMsg.szErrorCode, SndMsg.szErrorDesc);

      STRING sMsgid = MbBinToHex((unsigned char*)m_MQMsgId,24);
      Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sMsgid=[%s] strMsg=[%s]", sMsgid.c_str(),strMsg);

      iRet = m_cMQAgent.PutMsg(g_ReturnQueue, strMsg, iLen, NULL, m_MQMsgId);
      if(iRet != RTN_SUCCESS)
      {
          Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "向MQ添加数据失败");

          DELPOINT(strMsg);

          PMTS_ThrowException(OPT_MQ_ADD_FAIL);
      }
      DELPOINT(strMsg);
      m_cMQAgent.Commit();
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBepsBase::SendToMB...");  
}

/*
 @Desc: 一代编押 pkg003 004, 008. 011 etc.
 @Params:
 IN strMacH      包头密押要素串
 IN strBody      业务明细串
 IN pszSendSapBk 发起清算行号
 OUT szMacOut    编押后密押串
 @Date: 2012/03/30
 */
int CSendBepsBase::GetMac(string& strMacH, string& strBody, 
                            const char* pszSendSapBk, char* szMacOut)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CSendBepsBase::GetMac");
    string strMac = strMacH;
    
    MD5 md5;
    //取报文体指纹
    md5.Hash_Start();
    md5.Hash_PatchBuffer((unsigned char*)strBody.c_str(), strBody.length());
    //整个加押串
    strMac += md5.Hash_End().GetBuffer(0);
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, 
                "_____密押要素串[sapbank=%s][strMac=%s]", pszSendSapBk, strMac.c_str());
    
    int nRet = CodeMac(m_dbproc, strMac.c_str(), pszSendSapBk, szMacOut);
    
    if(RTN_SUCCESS != nRet){
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "编押失败！");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_CODEMAC_FAIL, "编押失败！");   
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CSendBepsBase::GetMac");
    
    return nRet;
}

void CSendBepsBase::SetFieldAsGbk(const string& strVal, char* szField, int iLen)
{
    if(szField == NULL || iLen < 1 || strVal.length() < 1){
        return;
    }
    
    int iBufLen = strVal.length()+1;
    char* pBuffer = new char[iBufLen];
    if(pBuffer == NULL){
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "__Alloc Memory Failed!");
        return;
    }
    
    memset(pBuffer, 0x00, iBufLen);
    if(IsUTF8((char*)strVal.c_str(), strVal.length())){
        if(!changeEncode((char*)strVal.c_str(), pBuffer, "UTF-8", "GB18030")){
            Trace(L_ERROR, __FILE__, __LINE__, NULL, "__Encode Failed!");
        }
    }
    else{
        strncpy(pBuffer, strVal.c_str(), iBufLen-1);
    }
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__pBuffer=[%s]", pBuffer);
    strncpy(szField, pBuffer, iLen);
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__szField=[%s]", szField);
    delete[] pBuffer;
    pBuffer = NULL;
}

