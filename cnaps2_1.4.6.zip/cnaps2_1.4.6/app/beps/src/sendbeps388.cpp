/*
 *  sendbeps388.cpp
 *  Description: ���ո�ҵ��ܾ�֪ͨ����beps.388.001.01����������
 *  Created on: 2012-06-20
 *  Author: __wsh
 */

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps388.h"


CSendBeps388::CSendBeps388(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
}

CSendBeps388::~CSendBeps388()
{
}


INT32 CSendBeps388::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__,
    		m_sMsgId, "Enter CSendBeps388::doWorkSelf");

    int iRet = -1;

    //��ȡ����
    iRet = GetData();

    //����XML��������
    SetData();

    //����XML����
    iRet = BuildPmtsMsg();

    //�������ݿ�ҵ��״̬
    iRet = UpdateState();

    //���ͱ���
    iRet = AddQueue();

    Trace(L_INFO,  __FILE__,  __LINE__,
    		m_sMsgId, "Leave CSendBeps388::doWorkSelf");

    return iRet;
}

//__wsh 2012-06-20 ��ȡҵ������
int CSendBeps388::GetData(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
	    		m_sMsgId, "Enter CSendBeps388::GetData");

	int iRet = -1;

	SETCTX(m_bizpn);
	//ҵ������
	m_bizpn.m_msgid    = m_sMsgId;
	m_bizpn.m_instgpty = m_sSendOrg;
	Trace(L_DEBUG, __FILE__, __LINE__, m_sMsgId,
			"m_bizpn.m_msgid=[%s], m_bizpn.m_instgpty=[%s]",
			m_bizpn.m_msgid.c_str(), m_bizpn.m_instgpty.c_str());

	//����ҵ��
	iRet = m_bizpn.findByPK();
	if(iRet != SQL_SUCCESS){
		sprintf(m_sErrMsg, "����ҵ��ʧ�� iRet=%d, cause=%s",
				iRet, m_bizpn.GetSqlErr());

		Trace(L_DEBUG, __FILE__, __LINE__, m_sMsgId, "%s", m_sErrMsg);

		PMTS_ThrowException(DB_FIND_BY_PK_FAIL);
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
	    		m_sMsgId, "Leave CSendBeps388::GetData");

	return iRet;
}

//__wsh 2012-06-20 ���ý���XML����
void CSendBeps388::SetData(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
		    	m_sMsgId, "Enter CSendBeps388::SetData");

	int iRet = -1;

	//��ȡ���Ĵ�������ʱ��
	iRet = GetIsoDateTime(m_dbproc, SYS_BEPS, m_ISODateTime);
	if(iRet != RTN_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__,
					NULL, "��ȡiso datetimeʧ�ܣ�");
		PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
	}

	//ҵ��ͷ
	m_cBeps388.MsgId            = m_bizpn.m_msgid; 
	m_cBeps388.CreDtTm          = m_ISODateTime;
	
	m_cBeps388.InstgDrctPty     = m_bizpn.m_instgdrctpty;
	m_cBeps388.GrpHdrInstgPty   = m_bizpn.m_instgdrctpty;
	
	m_cBeps388.InstdDrctPty     = m_bizpn.m_instddrctpty;
	m_cBeps388.GrpHdrInstdPty   = m_bizpn.m_instddrctpty;
	
	m_cBeps388.SysCd            = "BEPS";
	m_cBeps388.Rmk              = m_bizpn.m_rmk;
	
	//ԭҵ����Ϣ
	m_cBeps388.OrgnlInstgPty    = m_bizpn.m_orgnlinstgpty;
	m_cBeps388.OrgnlMsgId       = m_bizpn.m_orgnlmsgid;
	char szTmp[32] = {0};
	sprintf(szTmp, "%d", m_bizpn.m_orgnlbtchnb);
	m_cBeps388.OrgnlBtchNb      = szTmp;
	
	//ҵ��Ӧ����Ϣ
	m_cBeps388.Sts              = "PR09"; //�̶�PR09
	m_cBeps388.RjctCd           = m_bizpn.m_rjctcd;
	m_cBeps388.RjctInf          = m_bizpn.m_rjctinf;
	m_cBeps388.PrcPty           = m_bizpn.m_rjcprcpty;

	m_cBeps388.AddtlInf         = m_bizpn.m_addtlinf;

	Trace(L_INFO,  __FILE__,  __LINE__,
			    m_sMsgId, "Leave CSendBeps388::SetData");
}

//__wsh 2012-06-20 ��ǩ
void CSendBeps388::AddSign388()
{
	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CSendBeps388::AddSign388");

	char   sSignedStr[4096 + 1] = {0};

	m_cBeps388.getOriSignStr();

	AddSign(m_cBeps388.m_sSignBuff.c_str(),
			sSignedStr,
			RAWSIGN,
			m_bizpn.m_instgdrctpty.c_str());

	m_cBeps388.m_szDigitSign = sSignedStr;

	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Leave CSendBeps388::AddSign388");
}

//__wsh 2012-06-20 ����XML����
int CSendBeps388::BuildPmtsMsg(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CSendBeps388::BuildPmtsMsg");

	int iRet = -1;

	//��ȡͨ�Ų����
	if( !GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS) ){
		Trace(L_ERROR, __FILE__, __LINE__,
				m_sMsgId, "��ȡͨ�Ų���ų���!");
		PMTS_ThrowException(PRM_FAIL);
	}

	//������Ϣͷ
	m_cBeps388.CreateXMlHeader(
				"BEPS",
				m_sWorkDate,
				m_sSendOrg,
				m_bizpn.m_instddrctpty.c_str(),
				"beps.388.001.01",
				m_sMsgRefId);

	//��ǩ
	AddSign388();

	//����XML����
	iRet = m_cBeps388.CreateXml();
	if(RTN_SUCCESS != iRet){
		Trace(L_ERROR,  __FILE__,  __LINE__,
				NULL, "��������ʧ��,iRet=%d", iRet);
		PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
	}

	m_sMsgTxt = m_cBeps388.m_sXMLBuff.c_str();

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendBeps388::BuildPmtsMsg");

	return iRet;
}

//__wsh 2012-06-20 ����ҵ��״̬
int CSendBeps388::UpdateState(void)
{
	int iRet = -1;

	Trace(L_INFO,  __FILE__,  __LINE__,
			    m_sMsgId, "Enter CSendBeps388::UpdateState");

	string strSql = "update bp_bizpubntce set procstate='";
	strSql += PR_HVBP_08;
	strSql += "', mesgid='";
	strSql += m_sMsgRefId;
	strSql += "', mesgrefid='";
	strSql += m_sMsgRefId;
	strSql += "', proctime=sysdate where msgid='";
	strSql += m_sMsgId;
	strSql += "' and instgpty='";
	strSql += m_bizpn.m_instgpty;
	strSql += "' ";
	Trace(L_DEBUG,  __FILE__,  __LINE__,
			m_sMsgId, "__strSql=[%s]", strSql.c_str());

	iRet = m_bizpn.execsql(strSql);
	if(iRet != SQL_SUCCESS){
		sprintf(m_sErrMsg, "����ҵ��ʧ�� iRet=%d, cause=%s",
				iRet, m_bizpn.GetSqlErr());

		Trace(L_DEBUG, __FILE__, __LINE__, m_sMsgId, "%s", m_sErrMsg);

		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
				m_sMsgId, "Leave CSendBeps388::UpdateState");

	return iRet;
}
