/******************************************************************** 
�ļ����� sendbeps398.cpp
�����ˣ� handongfeng
��  ��   �� 2011-03-07
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps398.h"


CSendBeps398::CSendBeps398(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{

}

CSendBeps398::~CSendBeps398()
{
}

void CSendBeps398::AddSign398()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms398::AddSign398");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_beps398.getOriSignStr();
	
	AddSign(m_beps398.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_Bpbktocstdcntfctn.m_instgdrctpty.c_str());
	
	m_beps398.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms398::AddSign398");
}

void CSendBeps398::SetDBKey()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBeps398::SetDBKey...");
	
	m_Bpbktocstdcntfctn.m_msgid = m_sMsgId; 
	m_Bpbktocstdcntfctn.m_dbtrbrnchid = m_sSendOrg; 
	m_Bpbktocstdcntfctn.m_rsflag = "1";
	
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Bpbktocstdcntfctn.m_msgid = %s", m_Bpbktocstdcntfctn.m_msgid.c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Bpbktocstdcntfctn.m_dbtrbrnchid = %s", m_Bpbktocstdcntfctn.m_dbtrbrnchid.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBeps398::SetDBKey...");        
}

int CSendBeps398::UpdateState()
{
	Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "ENTER CSendBeps398::UpdateState");
	
	SETCTX(m_Bpbktocstdcntfctn);
	SetDBKey();
	
	string strSQL;
	strSQL += "UPDATE bp_BkToCstDCNtfctn t SET t.PROCTIME = sysdate, t.PROCSTATE = '08'";
	strSQL += ", t.MESGID = '";
	strSQL += m_sMesgID;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMsgRefId;
	strSQL += "' ";
	
	strSQL += "WHERE t.MSGID = '";
	strSQL += m_Bpbktocstdcntfctn.m_msgid.c_str();
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_Bpbktocstdcntfctn.m_instgdrctpty.c_str();
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	int iRet = m_Bpbktocstdcntfctn.execsql(strSQL.c_str());
	if(RTN_SUCCESS != iRet)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��, iRet=%d, %s", iRet, m_Bpbktocstdcntfctn.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "LEAVE CSendBeps398::UpdateState");
	return iRet;
}

void CSendBeps398::SetTag2ND(const string& Tag, const string& QryStr, int& iDepth)
{
	string strTemp;
	strTemp = Tag + strTemp;
	m_beps398.SetTxRef(iDepth, strTemp.c_str());
	iDepth++;
}

void CSendBeps398::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "ENTER CSendBeps398::UpdateState");
    char sAmount[255] = {0};
        m_beps398.MsgId                                  = m_Bpbktocstdcntfctn.m_msgid;
        m_beps398.GrpHdrCreDtTm                          = m_sIsoWorkDate ;
        m_beps398.MsgRcptId                              = m_Bpbktocstdcntfctn.m_instddrctpty;
        m_beps398.MsgRcptIssr                            = m_Bpbktocstdcntfctn.m_instgdrctpty;
        m_beps398.NtfctnId                               = m_Bpbktocstdcntfctn.m_chrgid;
        m_beps398.NtfctnCreDtTm                          = m_sIsoWorkDate ;
        m_beps398.AcctId                                 = "1" ;
        m_beps398.NtryRef                                = m_Bpbktocstdcntfctn.m_purpprtry;
        m_beps398.Amt                                    = ftoa(sAmount, m_Bpbktocstdcntfctn.m_pmtamt,2);
        m_beps398.Ccy                                    = m_Bpbktocstdcntfctn.m_currency;
        m_beps398.CdtDbtInd                              = "DBIT" ;
        m_beps398.Sts                                    = "INFO" ;
        m_beps398.Cd                                     = "1" ;//??
        m_beps398.DbtrNm                                 = m_Bpbktocstdcntfctn.m_dbtrnm;
        m_beps398.DbtrId                                 = m_Bpbktocstdcntfctn.m_cusflag;
        m_beps398.DbtrAcctId                             = m_Bpbktocstdcntfctn.m_dbtrid;
        m_beps398.DbtrAcctIssr                           = m_Bpbktocstdcntfctn.m_dbtrissr;
        m_beps398.CdtrNm                                 = m_Bpbktocstdcntfctn.m_cdtrnm;
        m_beps398.CdtrId                                 = m_Bpbktocstdcntfctn.m_corprtnid;
        m_beps398.CdtrAcctId                             = m_Bpbktocstdcntfctn.m_cdtraccid;
        m_beps398.CdtrAcctIssr                           = m_Bpbktocstdcntfctn.m_cdtrissr;
        m_beps398.DbtrAgtMmbId                           = m_Bpbktocstdcntfctn.m_dbtrmmbid;
        m_beps398.DbtrAgtId                              = m_Bpbktocstdcntfctn.m_dbtrbrnchid;
        m_beps398.CdtrAgtMmbId                           = m_Bpbktocstdcntfctn.m_cdtrmmbid;
        m_beps398.CdtrAgtId                              = m_Bpbktocstdcntfctn.m_cdtrbrnchid;
        m_beps398.TradDt                                 = m_Bpbktocstdcntfctn.m_traddt;
        
        bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);
        if(false == bRet)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��������");
            PMTS_ThrowException(PRM_FAIL);
        }
        strcpy(m_sMesgID,m_sMsgRefId);
        
        // ���ļ�ͷ
        m_beps398.CreateXMlHeader("BEPS",                        \
                                    m_Bpbktocstdcntfctn.m_workdate.c_str(), \
                                    m_Bpbktocstdcntfctn.m_instgdrctpty.c_str(),\
                                    m_Bpbktocstdcntfctn.m_instddrctpty.c_str(),\
                                    "beps.398.001.01",              \
                                    m_sMsgRefId);

    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "LEAVE CSendBeps398::UpdateState");
    return ;
}

INT32 CSendBeps398::doWorkSelf()
{
	Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "ENTER CSendBeps398::doWorkSelf");
	
	/*��ҵ����л�ȡ����*/
	int iRet = 0;
	
	GetData();
	
	SetData();
	
	AddSign398();
	
	iRet = m_beps398.CreateXml();
	if(RTN_SUCCESS != iRet)        
	{            
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
		PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
	}
	
	/*�޸�״̬*/
	UpdateState();
	
	m_sMsgTxt = m_beps398.m_sXMLBuff.c_str();
	
	AddQueue();
	
	Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "LEAVE CSendBeps398::doWorkSelf"); 
	return 0;
}


int CSendBeps398::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "ENTER CSendBeps398::GetData");
    
	SETCTX(m_Bpbktocstdcntfctn);
	SetDBKey();
  	iRet = m_Bpbktocstdcntfctn.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��, iRet=%d, %s", iRet, m_Bpbktocstdcntfctn.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "LEAVE CSendBeps398::GetData"); 
	return iRet;
}



