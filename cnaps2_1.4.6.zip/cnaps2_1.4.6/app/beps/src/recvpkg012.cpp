/******************************************************************** 
文件名： recvpkg012.cpp
创建人： handongfeng
日  期： 2011-04-14
修改人： 
日  期： 
描  述： 
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvpkg012.h"

using namespace ZFPT;

CRecvPkg012::CRecvPkg012()
{
    m_iTotalNum = 0;
    m_dTotalAmt = 0.00;
    m_iTotalNumCL = 0;
    m_dTotalAmtCL = 0.00;
    m_dAllAmt   = 0.00;
    m_dFacAmt = 0.00;
    m_dAllNum = 0;
    m_iFlag = 0;
    m_iSuccessFlag = 1;
	m_iAddtlLen = 0;
	m_pszAddtl  = NULL;    
}

CRecvPkg012::~CRecvPkg012()
{
        delete[] m_pszAddtl;
	    m_pszAddtl = NULL;
}

INT32 CRecvPkg012::Work(LPCSTR szMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvPkg012::Work()");

	// 解析报文
	unPack(szMsg);
	
	//验核押
    CheckMac012();
    
    // 业务检查
    CheckValues();
    
	// 入库
	InsertDb(szMsg);

    // 记账,修改记账状态等
    ChargeMb();

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvPkg012::Work()");
    
	return OPERACT_SUCCESS;
}

INT32 CRecvPkg012::unPack(LPCSTR szMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvPkg012::unPack()");

	int  iRet = -1;
	char sMsgId[35 + 1] = {0};
	char sMsgType[35 + 1] = { 0 };

	// 报文是否为空
	if (NULL == szMsg || '\0' == szMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "报文为空");
	}

	// 解析报文
	iRet = m_pkg012.ParseMsg(szMsg);
	if (OPERACT_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错! iRet= %d", iRet);	
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文解析出错");
	}

    // 获取工作日期
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(RTN_SUCCESS != iRet)
    {
      Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");
      PMTS_ThrowException(OPT_GET_DATE_FAIL);
    }    
    m_strWorkDate   =   m_sWorkDate;

	// 报文标识号
	memset(sMsgId, 0x00, sizeof(sMsgId));
	printf("m_pkg012.stPkgHead012.szPkgCDate[%s]m_pkg012.stPkgHead012.szPkgserNo[%s]\n", m_pkg012.stPkgHead012.szPkgCDate,m_pkg012.stPkgHead012.szPkgserNo);
	sprintf(sMsgId, "%s%s", m_pkg012.stPkgHead012.szPkgCDate, m_pkg012.stPkgHead012.szPkgserNo);
	m_strMsgID = sMsgId;

    ZFPTLOG.SetLogInfo("012", m_strMsgID.c_str());
    
	// 报文类型
	sprintf(sMsgType, "PKG%s", m_pkg012.stPkgHead012.szPkgType);
	m_strMsgTp = sMsgType;
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvPkg012::unPack()");
	return OPERACT_SUCCESS;
}
void CRecvPkg012::GetAddtlField(int iFldLen,
              string& strVal, bool bUtf8, bool bAdd)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CRecvPkg012::GetAddtlField()");

	if(m_iAddtlLen < 1 || m_iOffset < 0 || iFldLen < 1){
		return;
	}
	if(m_iOffset > m_iAddtlLen || m_pszAddtl == NULL){
	    return;    
	}
	
	memset(m_szBuffer, 0x00, sizeof(m_szBuffer));
	memcpy(m_szBuffer, m_pszAddtl+m_iOffset, iFldLen);
	Trace(L_DEBUG, __FILE__, __LINE__, NULL,
	    "__Len:[%d]_Offset[%d]_FLD[%s]",
	    m_iAddtlLen, m_iOffset, m_szBuffer);

	Trim(m_szBuffer);
	//有汉字Gbk转Utf8
	if(bUtf8){
        if(!IsUTF8(m_szBuffer, iFldLen)){
            char szTmp[256] = {0};
    	    if(changeEncode(m_szBuffer, szTmp,"GB18030","UTF-8")){
    	        memset(m_szBuffer, 0x00, sizeof(m_szBuffer));
    	        strncpy(m_szBuffer, szTmp, sizeof(m_szBuffer)-1);
    	    }  
    	}
	}

	//
	if(bAdd){
		strVal += "72C:";
		strVal += m_szBuffer;
	}
	else{
		strVal = m_szBuffer;
	}
	m_iOffset += iFldLen;
    //Trim(m_szBuffer);
	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Leave CRecvPkg012::GetAddtlField()");
}
int CRecvPkg012::CheckMac012()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvPkg012::CheckMac012()");

    int iRet = -1;
    iRet = CheckPkgMac(m_pkg012,m_pkg012.stPkgHead012.szPkgDest,m_pkg012.stPkgHead012.szRdfiCode);
	if(0 != iRet)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CheckMac012 failed");
    	PMTS_ThrowException(__FILE__, __LINE__, OPT_CHECKMAC_FAIL, "CheckMac012 failed");
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvPkg012::CheckMac012()");
    
    return OPERACT_SUCCESS;
}

INT32 CRecvPkg012::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvPkg012::CheckValues");

    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CRecvPkg012::CheckValues");
    
    return 0;
}

INT32 CRecvPkg012::GetOrgnMsg(string strBtchnb)
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "ENTER CRecvPkg012::GetOrgnMsg");
    
	
	char sMsgid[35 + 1] = {0};
	memset(sMsgid, 0x00, sizeof(sMsgid));
	sprintf(sMsgid, "%s%s", m_pkg012.stPkgHead012.szPkgCDate, m_pkg012.stPkgHead012.szPkgserNo);
	m_colltnchrgslistOrg.m_msgid = sMsgid; 
	m_colltnchrgslistOrg.m_instgdrctpty = m_pkg012.stPkgHead012.szOdfiCode; 
    m_colltnchrgslistOrg.m_btchnb = strBtchnb;
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_colltnchrgslistOrg.m_msgid = %s", m_colltnchrgslistOrg.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_colltnchrgslistOrg.m_instgdrctpty = %s", m_colltnchrgslistOrg.m_instgdrctpty.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_colltnchrgslistOrg.m_btchnb = %s", m_colltnchrgslistOrg.m_btchnb.c_str());

    SETCTX(m_colltnchrgslistOrg);
  	iRet = m_colltnchrgslistOrg.findByPK();
  	Trace(L_INFO, __FILE__, __LINE__, NULL, "iRet[%d]", iRet);
  	if(SQLNOTFOUND == iRet)
  	{
  	    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "记录未找到");
  	}
    else if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
        "m_colltnchrgslistOrg.findByPK failed:[%d][%s]",iRet,m_colltnchrgslistOrg.GetSqlErr());
        PMTS_ThrowException(OPT_GET_DATE_FAIL);
    } 

    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "LEAVE CRecvPkg012::GetOrgnMsg"); 
    
    return iRet;
}

void CRecvPkg012::InsertDb(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvPkg012::InsertDb()");

    if(NULL != strstr(m_pkg012.stPkgHead012.szTradetype,"40501")||
       NULL != strstr(m_pkg012.stPkgHead012.szTradetype,"40502")||
       NULL != strstr(m_pkg012.stPkgHead012.szTradetype,"40503")||
       NULL != strstr(m_pkg012.stPkgHead012.szTradetype,"40504"))
    {
        InsertCollDb( pchMsg);
    }
    else if(NULL != strstr(m_pkg012.stPkgHead012.szTradetype,"40506"))//代收代付通用回执包
    {
        InsertBizDb(pchMsg);
    }
    else if(NULL != strstr(m_pkg012.stPkgHead012.szTradetype,"40507"))//签约关系变更通知
    {
        InsertBizDb(pchMsg);
    }
    else if(NULL != strstr(m_pkg012.stPkgHead012.szTradetype,"00500"))//一般通用信息业务
    {
  	    //一般通用信息
	    iRet = InsertData_cminf();
    }
    else
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "未知的业务类型!");	
        PMTS_ThrowException(OTH_ERR);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvPkg012::InsertDb()");	
}

void CRecvPkg012::SetData_cminf(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
			    NULL, "Enter CRecvPkg012::SetData_cminf");

    string strTmp = "";

    m_cminfbiz.m_workdate     = m_strWorkDate; //工作日期
    m_cminfbiz.m_msgtp        = m_strMsgTp; //一代代收付报文类型字段用于业务类型
    m_cminfbiz.m_mesgid       = m_pkg012.GetHeadMesgID();   //通信级标识号
    m_cminfbiz.m_mesgrefid    = m_pkg012.GetHeadMesgReqNo();//通信级参考号
    m_cminfbiz.m_msgid        = m_strMsgID;  //报文标识
	m_cminfbiz.m_instgdrctpty = m_pkg012.stPkgHead012.szOdfiCode; //发起直接参与机构
	m_cminfbiz.m_instgpty     = m_pkg012.stBizBody005.szOdfiCode; //发起参与机构
	m_cminfbiz.m_instddrctpty = m_pkg012.stPkgHead012.szRdfiCode; //接收直接参与机构
	m_cminfbiz.m_instdpty     = m_pkg012.stBizBody005.szRdfiCode; //接收参与机构
	m_cminfbiz.m_syscd        = "BEPS";   //系统编号
	SetFieldAsUtf8(m_pkg012.stPkgHead012.szAppData, m_cminfbiz.m_rmk);//备注
	m_cminfbiz.m_srcflag      = "2";
	m_cminfbiz.m_txtpcd       = m_pkg012.stPkgHead012.szTradetype; //业务类型码
	m_cminfbiz.m_procstate    = PR_HVBP_01; //业务状态
	//m_cminfbiz.m_bIfOptBigData= true;
	m_iAddtlLen = atoi(m_pkg012.stBizBody005.szAppLen);
	if(m_iAddtlLen <= 0){
		Trace(L_INFO, __FILE__, __LINE__, NULL, "__附加域无数据");
		return;
	}
	char* pszTmp = m_pkg012.stBizBody005.szAppData;
	m_pszAddtl = new char[m_iAddtlLen * 2 + 1];
	memset(m_pszAddtl, 0x00, m_iAddtlLen * 2 + 1);
	memcpy(m_pszAddtl, pszTmp, m_iAddtlLen);

	GetAddtlField(60,  m_cminfbiz.m_titl, true); //标题	M	60g
	GetAddtlField(255, m_cminfbiz.m_cntt, true); //正文内容	M	255g
	GetAddtlField(60,  m_cminfbiz.m_attchmtnm, true); //附件文件名	O	60g
	GetAddtlField(8, strTmp); //附件长度	M	8n
	m_cminfbiz.m_attchmtlen  = atoi(strTmp.c_str());
	GetAddtlField(m_cminfbiz.m_attchmtlen, m_cminfbiz.m_attchmtcntt, true); //m_附件内容	O	nE	见说明
	//m_cminfbiz.m_attchmtcntt = (m_pszAddtl+m_iOffset); //m_附件内容	O	nE	见说明


	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Leave CRecvPkg012::SetData_cminf");
}

int CRecvPkg012::InsertData_cminf(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
			    NULL, "Enter CRecvPkg012::InsertData_cminf");
    int iRet = -1;

    //设置实体类对象数据
    SETCTX(m_cminfbiz);
	strcpy(m_szTblNm, "cm_cnotsgninfbiz");
	m_pEntity = &m_cminfbiz;

    SetData_cminf();

    iRet = m_cminfbiz.insert();


    Trace(L_INFO,  __FILE__,  __LINE__,
			    NULL, "Leave CRecvPkg012::InsertData_cminf");

    return iRet;
}

void CRecvPkg012::InsertCollDb(LPCSTR pchMsg)//入代收付表
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvPkg012::InsertCollDb()");

	char sTemp[35 + 1] = {0};
	int iRet = RTN_FAIL;
    string strAppData = "";//明细串
    string strDetail = "";//每条子明细
    int iClycount = 0;//明细数目  		
	int iDetailLen = 0;//明细清单长度
	
    SETCTX(m_colltnchrgslist);
    printf("m_strWorkDate[%s]\n", m_strWorkDate.c_str());
    m_colltnchrgslist.m_workdate   = m_strWorkDate;
    m_colltnchrgslist.m_consigdate = m_pkg012.stPkgHead012.szPkgCDate;
    m_colltnchrgslist.m_msgtp      = "PKG012";
    m_colltnchrgslist.m_mesgid     = m_pkg012.GetHeadMesgID();//通信级标识号
    m_colltnchrgslist.m_mesgrefid  = m_pkg012.GetHeadMesgReqNo();//通信级参考号    
    m_colltnchrgslist.m_msgid        = m_strMsgID;

    Trace(L_INFO, __FILE__, __LINE__, NULL, "m_strMsgID[%s]", m_strMsgID.c_str());

    if(NULL != strstr(m_pkg012.stPkgHead012.szTradetype,"40501"))//代付业务
    {
        for(int n = 0; n < m_pkg012.m_iDetailCnt; n++)
        {
            m_pkg012.ParseBusinessData(n);
            char sSrc[1024*28] = {0};
            strcpy(sSrc, m_pkg012.stBizBody005.szAppData);
            SetFieldAsGbk(m_pkg012.stBizBody005.szAppData, sSrc, 1024*28-1);
            strAppData = sSrc;
            Trace(L_INFO, __FILE__, __LINE__, NULL, "strAppData[%s]", strAppData.c_str());

            //取msgid
            char szchMsgId[32 +1] = {0};
            bool bRet = GetMsgIdValue(m_dbproc, szchMsgId, eMsgId, SYS_BEPS);
            if(false == bRet)
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "参数错误");
                PMTS_ThrowException(PRM_FAIL);
            }
            m_msgid005 = szchMsgId;

            m_colltnchrgslist.m_instgdrctpty = m_pkg012.stPkgHead012.szOdfiCode;//发起直接参与机构 
            m_colltnchrgslist.m_instgpty     = m_pkg012.stBizBody005.szOdfiCode;//发起参与机构  
            m_colltnchrgslist.m_instddrctpty = m_pkg012.stPkgHead012.szRdfiCode;//接收直接参与机构 
            m_colltnchrgslist.m_instdpty     = m_pkg012.stBizBody005.szRdfiCode;//接收参与机构   
            m_colltnchrgslist.m_ctgyprtry    = m_pkg012.stPkgHead012.szTradetype; //业务类型  
            m_colltnchrgslist.m_syscd        = "BEPS";   //系统编号 
            m_colltnchrgslist.m_rmk          = m_pkg012.stPkgHead012.szAppData;//备注    
            m_colltnchrgslist.m_btchnb       = m_pkg012.stBizBody005.szTxssNo;  //批次序号 = 信息业务序号  
            m_colltnchrgslist.m_procstate    = PR_HVBP_07;   //因为是实时回执,所以这里改为已回执
            m_colltnchrgslist.m_srcflag = "2";  //业务来源 1：往帐 2：付款方来帐 3：收款方来帐
            m_colltnchrgslist.m_currency = "RMB"		 ;//货币符号    
            m_colltnchrgslist.m_dbtrmmbid = m_pkg012.stPkgHead012.szOdfiCode  ;//付款清算行行号 = 发起直接参与机构
            //m_colltnchrgslist.m_chckflg = m_cParser386.ChckFlg    ;//核验标识 
            strAppData.substr(0,8);//代收付中心工作日
            m_colltnchrgslist.m_endtoendid = strAppData.substr(8,60);//合同（协议）号
            m_colltnchrgslist.m_dbtrbrnchid =  strAppData.substr(8+60,12);//付款行行号

            //表里没有相关存储字段
            string dbtrissr = strAppData.substr(8+60+12,12);//付款人开户行行号 
            m_colltnchrgslist.m_dbtrid = strAppData.substr(8+60+12+12,32);//付款人账户
            string dbtrnm_GBK = strAppData.substr(8+60+12+12+32,60);//付款人名称;
            SetFieldAsUtf8(dbtrnm_GBK.c_str(), m_colltnchrgslist.m_dbtrnm);
            //strAppData.substr(8+60+12+12+32+60,60);//付款人地址
            m_colltnchrgslist.m_puryprtry = strAppData.substr(8+60+12+12+32+60+60,5);//业务种类
            m_dAllAmt =  atof(strAppData.substr(8+60+12+12+32+60+60+5,15).c_str())/100;//本条付款总金额
            m_colltnchrgslist.m_cdtrmmbid = strAppData.substr(8+60+12+12+32+60+60+5+15,12);//收款人清算行行号

            //循环次数      
            iClycount = atoi(strAppData.substr(8+60+12+12+32+60+60+5+15+12,8).c_str());//收款人数目
            m_dAllNum += iClycount;
            strDetail = strAppData.substr(284);

            //明细清单长度
            iDetailLen = 259;//(8+12+12+32+60+60+15+60)
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "要素[%s]附加域明细数目:[%d]",m_pkg012.stBizBody005.szTxssNo,iClycount); 
            for(int i = 0 ; i < iClycount ; i++ )
            {
                //因为目前表主键只有MSGID(包序号),TXID(附加域内明细号),但PKG012一个包头可以有多个要素集,
                //每个要素集里又可以有多个附加域明细,这样需要(包序号)+要素集(信息业务号)+附加域明细号来定位一条记录
                //所以表结构不能满足,因为附加域明细号只在每一要素集内不重复,为了插入数据库时不会因重复而失败所以在
                //不改动主键的情况下,用MSGID(包序号)+TXID(附加域内要素号+明细号)
                m_colltnchrgslist.m_txid = m_pkg012.stBizBody005.szConsignDate + strDetail.substr(0 + i*iDetailLen   , 8) + m_colltnchrgslist.m_btchnb;//明细序号;(附加域内要素号+明细号)
                m_colltnchrgslist.m_cdtrbrnchid = strDetail.substr(8 + i*iDetailLen   , 12 );//收款行行号
                string cdtrissr = strDetail.substr(20  , 12 );//收款人开户行行号
                m_colltnchrgslist.m_cdtrid      = strDetail.substr(32 + i*iDetailLen  , 32 );//收款人账号
                string cdtrnm_GBK = strDetail.substr(64 + i*iDetailLen  , 60 );//收款人名称
                SetFieldAsUtf8(cdtrnm_GBK.c_str(), m_colltnchrgslist.m_cdtrnm);
                //strDetail.substr(124 + i*iDetailLen , 60  );//收款人地址
                m_colltnchrgslist.m_amout       = atof(strDetail.substr(184 + i*iDetailLen , 15 ).c_str())/100;//金额 每条收款明细金额
                string addtlinf_GBK = strDetail.substr(199 + i*iDetailLen , 60 );
                SetFieldAsUtf8(addtlinf_GBK.c_str(), m_colltnchrgslist.m_addtlinf);//附言

                m_strRtn = "00";
                if(CheckAgreemet(m_colltnchrgslist.m_endtoendid,"CT01",m_colltnchrgslist.m_dbtrid,"AS01") &&
                    CheckUserState("PKG012",m_colltnchrgslist.m_dbtrid))
                {
                    m_iSuccessFlag = 0;
                    m_iFlag = 0;
                    m_colltnchrgslist.m_busistate = PROCESS_PR05;
                }
                else
                {
                    m_iFlag = 1;
                    m_strRtn = "90";
                    m_colltnchrgslist.m_busistate = PROCESS_PR09;
                }

                //明细表插入数据
                iRet = m_colltnchrgslist.insert();
                if(OPERACT_SUCCESS != iRet)
                {                       
                    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "insert() failed:[%d][%s]",iRet,m_colltnchrgslist.GetSqlErr());         
                    PMTS_ThrowException(PRM_FAIL);
                }

                //附加域明细
                CreatePkg005(&m_colltnchrgslist, dbtrissr, cdtrissr);
            }

            //1.填充报文
            Fill40506Msg(m_colltnchrgslist.m_dbtrbrnchid, m_colltnchrgslist.m_cdtrbrnchid, 
                         m_colltnchrgslist.m_consigdate, m_colltnchrgslist.m_btchnb, "40501");  

            //如果有检查成功的记录则组装报文
            if (0 == m_iSuccessFlag)
            {     
                //生成定期贷记报文
                PackPkg005();
            }

            InitValue();
        }
        CreateRtn40506Msg();

    }
    else if(NULL != strstr(m_pkg012.stPkgHead012.szTradetype,"40502"))//代收业务
    {
        for(int n = 0; n < m_pkg012.m_iDetailCnt; n++)
        {
            m_pkg012.ParseBusinessData(n);
            char sSrc[1024*28] = {0};
            strcpy(sSrc, m_pkg012.stBizBody005.szAppData);
            SetFieldAsGbk(m_pkg012.stBizBody005.szAppData, sSrc, 1024*28-1);
            strAppData = sSrc;
            Trace(L_INFO, __FILE__, __LINE__, NULL, "strAppData[%s]", strAppData.c_str());

            //取msgid
            char szchMsgId[32 +1] = {0};
            bool bRet = GetMsgIdValue(m_dbproc, szchMsgId, eMsgId, SYS_BEPS);
            if(false == bRet)
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "参数错误");
                PMTS_ThrowException(DB_INSERT_FAIL);
            }
            m_msgid006 = szchMsgId;
            m_colltnchrgslist.m_instgdrctpty = m_pkg012.stPkgHead012.szOdfiCode;//发起直接参与机构 
            m_colltnchrgslist.m_instgpty     = m_pkg012.stBizBody005.szOdfiCode;//发起参与机构  
            m_colltnchrgslist.m_instddrctpty = m_pkg012.stPkgHead012.szRdfiCode;//接收直接参与机构 
            m_colltnchrgslist.m_instdpty     = m_pkg012.stBizBody005.szRdfiCode;//接收参与机构   
            m_colltnchrgslist.m_ctgyprtry    = m_pkg012.stPkgHead012.szTradetype; //业务类型  
            m_colltnchrgslist.m_syscd        = "BEPS";   //系统编号 
            m_colltnchrgslist.m_rmk          = m_pkg012.stPkgHead012.szAppData;//备注    
            m_colltnchrgslist.m_btchnb       = m_pkg012.stBizBody005.szTxssNo;  //批次序号 = 信息业务序号  
            m_colltnchrgslist.m_procstate    = PR_HVBP_07;   //因为是实时回执,所以这里改为已回执
            m_colltnchrgslist.m_srcflag = "3";  //1：往帐 2：付款方来帐 3：收款方来帐
		    m_colltnchrgslist.m_cdtrmmbid = m_pkg012.stPkgHead012.szOdfiCode ;//收款清算行行号 = 发起直接参与机构	 
		    m_colltnchrgslist.m_currency = "RMB"		 ;//货币符号		 	 	 
		    //m_colltnchrgslist.m_chckflg = m_cParser386.ChckFlg	 ;//核验标识  

		    strAppData.substr(0,8);//代收付中心工作日
		    int reciptdate = atoi(strAppData.substr(8,2).c_str());//回执期限（天数）
            //m_MaxDay = m_MaxDay>reciptdate ?m_MaxDay:reciptdate;
		    m_colltnchrgslist.m_cdtrbrnchid =  strAppData.substr(10,12);//收款行行号
    		
		    //表里没有相关存储字段
		    string cdtrissr = strAppData.substr(22,12);//收款人开户行行号 
		    m_colltnchrgslist.m_cdtrid = strAppData.substr(34,32);//收款人账户
            string cdtrnm_GBK = strAppData.substr(66,60).c_str();//收款人名称
            SetFieldAsUtf8(cdtrnm_GBK.c_str(), m_colltnchrgslist.m_cdtrnm);
		    //strAppData.substr(126,60);//收款人地址
		    m_colltnchrgslist.m_puryprtry = strAppData.substr(186,5);//业务种类
		    m_dFacAmt = atof(strAppData.substr(191,15).c_str())/100;//本条收款总金额
            m_dAllAmt += m_dFacAmt;
		    m_colltnchrgslist.m_dbtrmmbid = strAppData.substr(206,12);//付款人清算行行号
    		
		    //循环次数		
		    iClycount = atoi(strAppData.substr(218,8).c_str());//付款人数目
            m_dAllNum += iClycount;
            strDetail = strAppData.substr(226);
    		
		    //明细清单长度
		    iDetailLen = 319;//((8+12+12+32+60+60+15+60+60)
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "要素[%s]附加域明细数目:[%d]",m_pkg012.stBizBody005.szTxssNo,iClycount); 
		    for(int i = 0 ; i < iClycount ; i++ )
		    {
                //因为目前表主键只有MSGID(包序号),TXID(附加域内明细号),但PKG012一个包头可以有多个要素集,
                //每个要素集里又可以有多个附加域明细,这样需要(包序号)+要素集(信息业务号)+附加域明细号来定位一条记录
                //所以表结构不能满足,因为附加域明细号只在每一要素集内不重复,为了插入数据库时不会因重复而失败所以在
                //不改动主键的情况下,用MSGID(包序号)+TXID(附加域内要素号+明细号)
			    m_colltnchrgslist.m_txid = m_pkg012.stBizBody005.szConsignDate + strDetail.substr(0 + i*iDetailLen   , 8  ) + m_colltnchrgslist.m_btchnb;//明细序号(附加域内要素号+明细号)
			    m_colltnchrgslist.m_dbtrbrnchid = strDetail.substr(8 + i*iDetailLen   , 12 );//付款行行号
			    string dbtrissr = strDetail.substr(20  , 12 );//付款人开户行行号
			    m_colltnchrgslist.m_dbtrid = strDetail.substr(32 + i*iDetailLen  , 32 );//付款人账号
                string dbtrnm_GBK = strDetail.substr(64 + i*iDetailLen  , 60 );//付款人名称
			    SetFieldAsUtf8(dbtrnm_GBK.c_str(), m_colltnchrgslist.m_dbtrnm);
			    //strDetail.substr(124 , 60 );//付款人地址
			    m_colltnchrgslist.m_amout = atof(strDetail.substr(184 + i*iDetailLen , 15 ).c_str())/100;//金额
			    m_colltnchrgslist.m_endtoendid = strDetail.substr(199 + i*iDetailLen , 60 );//合同（协议）号
                string addtlinf_GBK = strDetail.substr(259 + i*iDetailLen , 60 );
                SetFieldAsUtf8(addtlinf_GBK.c_str(), m_colltnchrgslist.m_addtlinf);//附言

                m_strRtn = "00";
                if(CheckAgreemet(m_colltnchrgslist.m_endtoendid,"CT00",m_colltnchrgslist.m_cdtrid,"AS01") &&
                   CheckUserState("PKG012",m_colltnchrgslist.m_cdtrid))
                {
                    m_iSuccessFlag = 0;
                    m_iFlag = 0;
                    m_colltnchrgslist.m_busistate = PROCESS_PR05;
                }
                else
                {
                    m_strRtn = "90";
                    m_iFlag = 1;
                    m_colltnchrgslist.m_busistate = PROCESS_PR09;
                }

                //明细表插入数据
                iRet = m_colltnchrgslist.insert();
                if(OPERACT_SUCCESS != iRet)
                {
                    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "insert() failed:[%d][%s]",iRet,m_colltnchrgslist.GetSqlErr());          
                    PMTS_ThrowException(DB_INSERT_FAIL);
                }

                //附加域明细
                CreatePkg006(&m_colltnchrgslist, dbtrissr, cdtrissr, reciptdate);
            }
            
            //填充通知报文
            Fill40506Msg(m_colltnchrgslist.m_dbtrbrnchid.c_str(),
                            m_colltnchrgslist.m_cdtrbrnchid.c_str(),
                            m_colltnchrgslist.m_consigdate.c_str(),
                            m_colltnchrgslist.m_btchnb.c_str(),
                            "40502");

            //如果有检查成功的记录则组装报文
            if (0 == m_iSuccessFlag)
            {            
                //生成定期借记报文
                PackPkg006();
            }

            InitValue();
        }
        CreateRtn40506Msg();
    }
    else if(NULL != strstr(m_pkg012.stPkgHead012.szTradetype,"40503"))//批量代付业务回执
    {
        m_colltnchrgslist.m_srcflag = "1";
        m_colltnchrgslist.m_procstate = PR_HVBP_01;
        m_colltnchrgslist.m_orgnlmsgid = strAppData.substr(0,8);//原交易委托日期
        m_colltnchrgslist.m_orgnlmsgid += strAppData.substr(8,8);//原交易信息业务序号 = 包序号
        m_colltnchrgslist.m_orgnlbtchnb = strAppData.substr(8,8);//原批次序号
        m_colltnchrgslist.m_dbtrbrnchid = strAppData.substr(8+8, 12 );//付款行行号
        //strAppData.substr(8+8+12, 12 );//付款人开户行行号
        m_colltnchrgslist.m_dbtrid = strAppData.substr(8+8+12+12, 32 );//付款人账号
        m_colltnchrgslist.m_cdtrmmbid = strAppData.substr(8+8+12+12+32,12);//收款人清算行行号
        m_dAllAmt = atof(strAppData.substr(8+8+12+12+32+12,15).c_str())/100;//原交易要求付款总金额
        m_dTotalAmtCL = atof(strAppData.substr(8+8+12+12+32+12+15,15).c_str())/100;//成功付款总金额
        m_iTotalNumCL = atoi(strAppData.substr(8+8+12+12+32+12+15+15,8).c_str());//成功笔数
        
        iClycount = atoi(strAppData.substr(8+8+12+12+32+12+15+15+8, 8).c_str());//原交易收款人数目
        m_dAllNum = iClycount;
        strDetail = strAppData.substr(138);

        //明细清单长度
		iDetailLen = 117;//((8+32+15+2+60)
		
        for(int i = 0; i < iClycount; i++)
        {
            m_colltnchrgslist.m_txid     = strAppData.substr(0,8);
            m_colltnchrgslist.m_txid    += strDetail.substr(0+ i*iDetailLen, 8);
   
            m_colltnchrgslist.m_dbtrnm = m_colltnchrgslistOrg.m_dbtrnm; 
            m_colltnchrgslist.m_cdtrid = strDetail.substr(8+ i*iDetailLen, 32); //收款人账号
            m_colltnchrgslist.m_amout = atof(strDetail.substr(8+32+ i*iDetailLen, 15).c_str())/100;//金额
               
            m_colltnchrgslist.m_busistate = strDetail.substr(8+32+15+ i*iDetailLen, 2);//回执状态

            string addtlinf_GBK = strDetail.substr(8+32+15+2+ i*iDetailLen,60);//附言
            SetFieldAsUtf8(addtlinf_GBK.c_str(), m_colltnchrgslist.m_addtlinf);

            //明细表插入数据
            iRet = m_colltnchrgslist.insert();
            if(OPERACT_SUCCESS != iRet)
            {
                 Trace(L_INFO,  __FILE__,  __LINE__, NULL, "insert() failed:[%d][%s]",iRet,m_colltnchrgslist.GetSqlErr());        
                 PMTS_ThrowException(DB_INSERT_FAIL);
            }            
        }
    }
    else//批量代收业务回执:40504
    {
        m_colltnchrgslist.m_srcflag = "1";
        m_colltnchrgslist.m_procstate = PR_HVBP_01;
        m_colltnchrgslist.m_orgnlmsgid = strAppData.substr(0,8);//原交易委托日期
        m_colltnchrgslist.m_orgnlmsgid += strAppData.substr(8,8);//原交易信息业务序号 = 包序号 = 批次序号
        m_colltnchrgslist.m_orgnlbtchnb = strAppData.substr(8,8);//原批次序号
        m_colltnchrgslist.m_dbtrbrnchid = strAppData.substr(8+8, 12 );//收款行行号
        //strAppData.substr(8+8+12, 12 );//收款人开户行行号
        m_colltnchrgslist.m_dbtrid = strAppData.substr(8+8+12+12, 32 );//收款人账号
        m_colltnchrgslist.m_cdtrmmbid = strAppData.substr(8+8+12+12+32,12);//付款人清算行行号
        m_dAllAmt = atof(strAppData.substr(8+8+12+12+32+12,15).c_str())/100;//原交易要求收款总金额
        m_dTotalAmtCL = atof(strAppData.substr(8+8+12+12+32+12+15,15).c_str())/100;//成功收款总金额
        m_iTotalNumCL = atoi(strAppData.substr(8+8+12+12+32+12+15+15,8).c_str());//成功笔数

        iClycount = atoi(strAppData.substr(8+8+12+12+32+12+15+15+8, 8).c_str());//原交易付款人数目
        m_dAllNum = iClycount;
        strDetail = strAppData.substr(8+8+12+12+32+12+15+15+8+8);//结果清单
        
        //明细清单长度
		iDetailLen = 117;//((8+32+15+2+60)
		
        for(int i = 0; i < iClycount; i++)
        {
            m_colltnchrgslist.m_txid     = strAppData.substr(0,8);
            m_colltnchrgslist.m_txid    += strDetail.substr(0+ i*iDetailLen, 8);
            m_colltnchrgslist.m_dbtrnm = m_colltnchrgslistOrg.m_dbtrnm; 
            m_colltnchrgslist.m_cdtrid = strDetail.substr(8+ i*iDetailLen, 32); //付款人账号
            m_colltnchrgslist.m_amout = atof(strDetail.substr(8+32+ i*iDetailLen, 15).c_str())/100;//金额               
            m_colltnchrgslist.m_busistate = strDetail.substr(8+32+15+ i*iDetailLen, 2);//回执状态

            string addtlinf_GBK = strDetail.substr(8+32+15+2+ i*iDetailLen,60);//附言
            SetFieldAsUtf8(addtlinf_GBK.c_str(), m_colltnchrgslist.m_addtlinf);
            
            //明细表插入数据
            iRet = m_colltnchrgslist.insert();
            if(OPERACT_SUCCESS != iRet)
            {
                 Trace(L_INFO,  __FILE__,  __LINE__, NULL, "insert() failed:[%d][%s]",iRet,m_colltnchrgslist.GetSqlErr());        
                 PMTS_ThrowException(DB_INSERT_FAIL);
            }            
        }
    }   

    //代收付汇总表
    m_colltnchrgscl.m_checkstate = PR_HVBP_00;//  对账状态
    m_colltnchrgscl.m_workdate = m_strWorkDate;//  工作日期
    m_colltnchrgscl.m_consigdate = m_pkg012.stPkgHead012.szPkgCDate;//  委托日期
    m_colltnchrgscl.m_msgtp = "PKG012";//  报文类型
    m_colltnchrgscl.m_mesgid = m_pkg012.GetHeadMesgID();//  通信级标识号
    m_colltnchrgscl.m_mesgrefid = m_pkg012.GetHeadMesgReqNo();//  通信级参考号
    m_colltnchrgscl.m_msgid = m_strMsgID;//  报文标识号
    m_colltnchrgscl.m_instgdrctpty = m_pkg012.stPkgHead012.szOdfiCode;//  发起直接参与机构
    m_colltnchrgscl.m_instgpty = m_pkg012.stBizBody005.szOdfiCode;//  发起参与机构
    m_colltnchrgscl.m_instddrctpty = m_pkg012.stPkgHead012.szRdfiCode;//  接收直接参与机构
    m_colltnchrgscl.m_instdpty = m_pkg012.stBizBody005.szRdfiCode;//  接收参与机构
    m_colltnchrgscl.m_syscd = m_colltnchrgslist.m_syscd;//  系统编号
    m_colltnchrgscl.m_rmk = m_colltnchrgslist.m_rmk;//  备注
    m_colltnchrgscl.m_srcflag = m_colltnchrgslist.m_srcflag;//  业务来源
    m_colltnchrgscl.m_btchnb = m_colltnchrgslist.m_btchnb;//  批次序号
    m_colltnchrgscl.m_dbtrmmbid = m_colltnchrgslist.m_dbtrmmbid;//  付款清算行行号
    m_colltnchrgscl.m_cdtrmmbid = m_colltnchrgslist.m_cdtrmmbid;//  收款清算行行号
    
    if(NULL != strstr(m_pkg012.stPkgHead012.szTradetype,"40501"))//代付业务
    {
        m_colltnchrgscl.m_cdbtrnm = m_colltnchrgslist.m_dbtrnm;//  收/付款人户名
        m_colltnchrgscl.m_cdbtrid = m_colltnchrgslist.m_dbtrid;//  收/付款人账号
        m_colltnchrgscl.m_cdbtrbrnchid = m_colltnchrgslist.m_dbtrbrnchid;//  收/付款行行号
    }
    else if(NULL != strstr(m_pkg012.stPkgHead012.szTradetype,"40502"))//代收业务
    {
        m_colltnchrgscl.m_cdbtrnm = m_colltnchrgslist.m_cdtrnm;//  收/付款人户名
        m_colltnchrgscl.m_cdbtrid = m_colltnchrgslist.m_cdtrid;//  收/付款人账号
        m_colltnchrgscl.m_cdbtrbrnchid = m_colltnchrgslist.m_cdtrbrnchid;//  收/付款行行号
    }
    else if(NULL != strstr(m_pkg012.stPkgHead012.szTradetype,"40503"))//批量代付业务回执
    {
        m_colltnchrgscl.m_cdbtrnm = m_colltnchrgslist.m_dbtrnm;//  收/付款人户名
        m_colltnchrgscl.m_cdbtrid = m_colltnchrgslist.m_dbtrid;//  收/付款人账号
        m_colltnchrgscl.m_cdbtrbrnchid = m_colltnchrgslist.m_dbtrbrnchid;//  收/付款行行号
    }
    else//批量代收业务回执:40504
    {
        m_colltnchrgscl.m_cdbtrnm = m_colltnchrgslist.m_cdtrnm;//  收/付款人户名
        m_colltnchrgscl.m_cdbtrid = m_colltnchrgslist.m_cdtrid;//  收/付款人账号
        m_colltnchrgscl.m_cdbtrbrnchid = m_colltnchrgslist.m_cdtrbrnchid;//  收/付款行行号    
    }
    m_colltnchrgscl.m_currency = m_colltnchrgslist.m_currency;//  货币符号
    m_colltnchrgscl.m_ttlamt = m_dAllAmt;//  总金额
    m_colltnchrgscl.m_cdbtrnb = m_dAllNum;//  收/付款人数目
    m_colltnchrgscl.m_ctgyprtry = m_colltnchrgslist.m_ctgyprtry;//  业务类型编码
//    m_colltnchrgscl.m_puryprtry = m_colltnchrgslist.m_puryprtry;//  业务种类编码
    m_colltnchrgscl.m_busistate = m_colltnchrgslist.m_busistate;//  业务状态
    m_colltnchrgscl.m_processcode = m_colltnchrgslist.m_processcode;//  业务处理码
    m_colltnchrgscl.m_procstate = m_colltnchrgslist.m_procstate;//  处理状态
//    m_colltnchrgscl.m_rcvgttlamt = m_dTotalAmtCL;//  成功收款总金额
//    m_colltnchrgscl.m_rcvgttlnb = m_iTotalNumCL;//  成功收款总笔数
    
	SETCTX(m_colltnchrgscl);	
    iRet = m_colltnchrgscl.insert();
    if(OPERACT_SUCCESS != iRet)
    {
         Trace(L_INFO,  __FILE__,  __LINE__, NULL, "insert() failed:[%d][%s]",iRet,m_colltnchrgscl.GetSqlErr());        
         PMTS_ThrowException(DB_INSERT_FAIL);
    }  
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvPkg012::InsertCollDb()");	
}

void CRecvPkg012::InsertBizDb(LPCSTR pchMsg)//代收付业务通用通知表
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvPkg012::InsertBizDb()");

    for(int n = 0; n < m_pkg012.m_iDetailCnt; n++)
    {
        m_pkg012.ParseBusinessData(n);

	    char szTemp[35 + 1] = {0};
	    int iRet = RTN_FAIL;
        string strAppData = "";//明细串

        m_cBpbizpubntce.m_workdate = m_strWorkDate;//  工作日期
        m_cBpbizpubntce.m_msgtp = "PKG012";//  报文类型
        m_cBpbizpubntce.m_mesgid = m_pkg012.GetHeadMesgID();//  通信级标识号
        m_cBpbizpubntce.m_mesgrefid = m_pkg012.GetHeadMesgReqNo();//  通信级参考号
        m_cBpbizpubntce.m_msgid = m_strMsgID;//  报文标识号
        m_cBpbizpubntce.m_instgdrctpty = m_pkg012.stPkgHead012.szOdfiCode;//  发起直接参与机构
        m_cBpbizpubntce.m_instgpty = m_pkg012.stBizBody005.szOdfiCode;//  发起参与机构
        m_cBpbizpubntce.m_instddrctpty = m_pkg012.stPkgHead012.szRdfiCode;//  接收直接参与机构
        m_cBpbizpubntce.m_instdpty = m_pkg012.stBizBody005.szRdfiCode;//  接收参与机构
        m_cBpbizpubntce.m_syscd = "PKG";//  系统编号
        m_cBpbizpubntce.m_rmk = m_pkg012.stPkgHead012.szAppData;// 备注

        //明细:原交易委托日期+原交易信息业务序号+原包业务类型+代收付中心工作日+业务回执状态+附言
        //[8+8+5+8+2+60]
        strAppData = m_pkg012.stBizBody005.szAppData;
        
        m_cBpbizpubntce.m_orgnlmsgid = strAppData.substr(0,16);
        string strOrgnType = strAppData.substr(16,5);
        string strRtnSts = strAppData.substr(8+8+5+8, 2);
        //m_cBpbizpubntce.m_orgnlinstgpty = m_pkg012.stPkgHead012.szRdfiCode;//  接收直接参与机构 = 原发起参与机构?
        m_cBpbizpubntce.m_orgnlbtchnb = atoi(strAppData.substr(8,8).c_str());
        m_cBpbizpubntce.m_addtlinf = strAppData.substr(8+8+5+8+2,60);
        //m_cBpbizpubntce.m_rjcprcpty = ;//  业务拒绝处理参与机构 
        m_cBpbizpubntce.m_procstate = PR_HVBP_01;//  处理状态
        //m_cBpbizpubntce.m_status = ;//  业务状态
        //m_cBpbizpubntce.m_rjctcd = ;//  业务拒绝处理码
        //m_cBpbizpubntce.m_rjctinf = ;//  业务拒绝信息

	    SETCTX(m_cBpbizpubntce);
	    iRet = m_cBpbizpubntce.insert();
        if(OPERACT_SUCCESS != iRet)
        {
             Trace(L_INFO,  __FILE__,  __LINE__, NULL,
                 "insert() failed:[%d][%s]",iRet,m_cBpbizpubntce.GetSqlErr());        
             PMTS_ThrowException(DB_INSERT_FAIL);
        } 
        
        //////////////////////////////////////////////////////////////////////////
        //这里如果原业务是协议管理的话那么要找原业务的增删改操作来做相应处理
        if ("40507" == strOrgnType)
        {
            //查找原操作
            SETCTX(m_Bpcstctrctmglist);
            string strSqlWhere = "";
            strSqlWhere += " msgid='";
            strSqlWhere += m_cBpbizpubntce.m_orgnlmsgid;
            strSqlWhere += "' and INSTGDRCTPTY='";
            strSqlWhere += m_pkg012.stPkgHead012.szRdfiCode;
            strSqlWhere += "'";
            Trace(L_INFO, __FILE__, __LINE__, NULL, "__strSqlWhere=%s", strSqlWhere.c_str());
            iRet = m_Bpcstctrctmglist.find(strSqlWhere.c_str());
            if(iRet != SQL_SUCCESS)
            {
                Trace(L_ERROR, __FILE__, __LINE__, NULL, "打开游标出错，iRet=%d cause=%s", iRet, m_Bpcstctrctmglist.GetSqlErr());
                PMTS_ThrowException(DB_NOT_FOUND);
            }
            iRet = m_Bpcstctrctmglist.fetch();
            if(iRet != SQL_SUCCESS)
            {
                Trace(L_ERROR, __FILE__, __LINE__, NULL, "获取批量签约汇总表数据出错，iRet=%d cause=%s", iRet, m_Bpcstctrctmglist.GetSqlErr());
                PMTS_ThrowException(DB_NOT_FOUND);
            }
            //关闭游标
            m_Bpcstctrctmglist.closeCursor();

            if ("00" == strRtnSts)//如果返回成功则进行增删改
            {
                SETCTX(m_Bpcstctrctmg);
                m_Bpcstctrctmg.m_agrmtnb = m_Bpcstctrctmglist.m_agrmtnb; 
                m_Bpcstctrctmg.m_ctrctagrmttp = m_Bpcstctrctmglist.m_ctrctagrmttp; 
                m_Bpcstctrctmg.m_srcflag = "1"; 
                m_Bpcstctrctmg.m_dbtrnm = m_Bpcstctrctmglist.m_dbtrnm; 
                m_Bpcstctrctmg.m_dbtrid = m_Bpcstctrctmglist.m_dbtrid; 
                m_Bpcstctrctmg.m_dbtrissr = m_Bpcstctrctmglist.m_dbtrissr; 
                m_Bpcstctrctmg.m_dbtrmmbid = m_Bpcstctrctmglist.m_dbtrmmbid; 
                m_Bpcstctrctmg.m_dbtrbrnchid = m_Bpcstctrctmglist.m_dbtrbrnchid; 
                m_Bpcstctrctmg.m_cdtrnm = m_Bpcstctrctmglist.m_cdtrnm; 
                m_Bpcstctrctmg.m_acctsts = strRtnSts; 
                m_Bpcstctrctmg.m_procstate = PR_HVBP_35;

                if ("1" == m_Bpcstctrctmglist.m_chngtpcd)//1：新增
                {
                    iRet = m_Bpcstctrctmg.insert();
                    if(OPERACT_SUCCESS != iRet)
                    {
                        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "insert() failed:[%d][%s]",iRet,m_Bpcstctrctmg.GetSqlErr());        
                        PMTS_ThrowException(DB_INSERT_FAIL);
                    } 
                } 
                else if("2" == m_Bpcstctrctmglist.m_chngtpcd)//2：修改 
                {
                    int iRet = m_Bpcstctrctmg.updatestate();
                    if(iRet != RTN_SUCCESS)
                    {
                        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "修改状态失败iRet=%d, %s", iRet, m_Bpcstctrctmg.GetSqlErr());
                        PMTS_ThrowException(DB_UPDATE_FAIL);
                    }   
                }
                else if ("0" == m_Bpcstctrctmglist.m_chngtpcd)//0：删除
                {
                    iRet = m_Bpcstctrctmg.remove();
                    if(OPERACT_SUCCESS != iRet)
                    {
                        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "insert() failed:[%d][%s]",iRet,m_Bpcstctrctmg.GetSqlErr());        
                        PMTS_ThrowException(DB_INSERT_FAIL);
                    } 
                }
            }
            else//如果被拒绝,则更新明细汇总应答标识,不更新管理表
            {
                string strSQL;
                strSQL += "UPDATE Bp_cstctrctmglist t SET t.PROCTIME = sysdate, t.RSPSNSTS = '";
                strSQL += strRtnSts;
                strSQL += "'";
                Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL[%s]",strSQL.c_str());        

                int iRet = m_Bpcstctrctmglist.execsql(strRtnSts);
                if(OPERACT_SUCCESS != iRet)
                {
                    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "insert() failed:[%d][%s]",iRet,m_Bpcstctrctmglist.GetSqlErr());        
                    PMTS_ThrowException(DB_INSERT_FAIL);
                } 
            }
            //////////////////////////////////////////////////////////////////////////
            
        }
    }
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvPkg012::InsertBizDb()");	
}

void CRecvPkg012::InsertSignedDb(LPCSTR pchMsg)//签约关系变更通知
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvPkg012::InsertSignedDb()");

	char szTemp[35 + 1] = {0};
	int iRet = RTN_FAIL;
    string strAppData = "";//明细串
    
    CBpcstctrctmglist oBpcstctrctmglist;

    oBpcstctrctmglist.m_workdate = m_strWorkDate;// 工作日期
    oBpcstctrctmglist.m_instgdrctpty = m_pkg012.stPkgHead012.szOdfiCode;// 发起直接参与机构
    oBpcstctrctmglist.m_msgid = m_strMsgID;// 报文标识号


    //明细:合同(协议)号+合同(协议)类型+变更方式+付款行行号+付款清算行行号
    //+付款人开户行行号+付款人账号+付款人名称+付款人地址+附言
    //[60+1+1+12+12+12+32+60+60+60]
    strAppData = m_pkg012.stBizBody005.szAppData;
    

    //oBpcstctrctmglist.m_qryoroprtp = ;// 协议查询或调整标识
    oBpcstctrctmglist.m_srcflag = "2";// 往来标志   1往 2来
    oBpcstctrctmglist.m_agrmtnb = strAppData.substr(0,60);// 协议号
    oBpcstctrctmglist.m_ctrctagrmttp = strAppData.substr(60,1);// 合同（协议）类型
    oBpcstctrctmglist.m_chngtpcd = strAppData.substr(60+1,1);// 变更类型
    oBpcstctrctmglist.m_dbtrbrnchid = strAppData.substr(60+1+1,12);// 付款行行号
    oBpcstctrctmglist.m_dbtrmmbid = strAppData.substr(60+1+1+12,12);// 付款清算行行号
    oBpcstctrctmglist.m_dbtrissr = strAppData.substr(60+1+1+12+12,12);// 付款人开户行行号
    oBpcstctrctmglist.m_dbtrid = strAppData.substr(60+1+1+12+12+12,32);//付款人账号
    oBpcstctrctmglist.m_dbtrnm = strAppData.substr(60+1+1+12+12+12+32,60);// 付款人名称    
    //oBpcstctrctmglist.m_cdtrnm = ;// 收款人名称
    //oBpcstctrctmglist.m_rspsnsts = ;// 应答标识
    //oBpcstctrctmglist.m_acctsts = ;// 付款人账户状态
    //oBpcstctrctmglist.m_procstate = ;// 处理状态


	SETCTX(oBpcstctrctmglist);
	iRet = oBpcstctrctmglist.insert();
    if(OPERACT_SUCCESS != iRet)
    {
         Trace(L_INFO,  __FILE__,  __LINE__, NULL,
             "insert() failed:[%d][%s]",iRet,oBpcstctrctmglist.GetSqlErr());        
         PMTS_ThrowException(DB_INSERT_FAIL);
    } 
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvPkg012::InsertSignedDb()");	
}

void CRecvPkg012::InsertUsualInfoDb(LPCSTR pchMsg)//入通用信息签名和非签名业务表
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvPkg012::InsertUsualInfoDb()");

	char szTemp[35 + 1] = {0};
	int iRet = RTN_FAIL;
    string strAppData = "";//明细串
    
    CCmcnotsgninfbiz oCmcnotsgninfbiz;

    oCmcnotsgninfbiz.m_workdate      = m_strWorkDate                        ; //工作日期
    oCmcnotsgninfbiz.m_msgtp         = "PKG012" ; //报文类型   
    oCmcnotsgninfbiz.m_mesgid        = m_pkg012.GetHeadMesgID()   ; //通信级标识号
    oCmcnotsgninfbiz.m_mesgrefid     = m_pkg012.GetHeadMesgReqNo(); //通信级参考号
    oCmcnotsgninfbiz.m_msgid         = m_strMsgID                      ; //报文标识号    
    oCmcnotsgninfbiz.m_instgdrctpty  = m_pkg012.stPkgHead012.szOdfiCode;//  发起直接参与机构
    oCmcnotsgninfbiz.m_instgpty      = m_pkg012.stBizBody005.szOdfiCode;//  发起参与机构
    oCmcnotsgninfbiz.m_instddrctpty  = m_pkg012.stPkgHead012.szRdfiCode;//  接收直接参与机构
    oCmcnotsgninfbiz.m_instdpty      = m_pkg012.stBizBody005.szRdfiCode;//  接收参与机构
    oCmcnotsgninfbiz.m_syscd         = "PKG"                      ; //系统编号
    oCmcnotsgninfbiz.m_rmk           = m_pkg012.stPkgHead012.szAppData      ; //备注
    oCmcnotsgninfbiz.m_txtpcd        = m_pkg012.stBizBody005.szTrxsType; //业务类型编码
    
    //明细:标题+正文内容+附件文件名+附件长度+附件内容
    //[60+255+60+8+nE]
    
    strAppData = m_pkg012.stBizBody005.szAppData;
    oCmcnotsgninfbiz.m_titl          = strAppData.substr(0,60)                      ; //信息标题
    oCmcnotsgninfbiz.m_cntt          = strAppData.substr(60,255)   ; //信息内容
    oCmcnotsgninfbiz.m_attchmtlen    = atoi(strAppData.substr(60+255,60).c_str())   ; //附件长度
    oCmcnotsgninfbiz.m_attchmtnm     = strAppData.substr(60+255+60,8)               ; //附件名称
    oCmcnotsgninfbiz.m_attchmtcntt   = strAppData.substr(60+255+60+8)             ; //附件内容
    oCmcnotsgninfbiz.m_procstate     = PR_HVBP_06;//PR_HVBP_06表待回执
    //oCmcnotsgninfbiz.m_proctime
    oCmcnotsgninfbiz.m_srcflag       = SRC_FRCNAPS;//往来标志
   

	SETCTX(oCmcnotsgninfbiz);
	iRet = oCmcnotsgninfbiz.insert();
    if(OPERACT_SUCCESS != iRet)
    {
         Trace(L_INFO,  __FILE__,  __LINE__, NULL,
             "insert() failed:[%d][%s]",iRet,oCmcnotsgninfbiz.GetSqlErr());        
         PMTS_ThrowException(DB_INSERT_FAIL);
    } 
	
	//判断间直连，如果是直连就入行内通讯表
    DirectInter(oCmcnotsgninfbiz.m_instgpty.c_str(), 
    			oCmcnotsgninfbiz.m_instddrctpty.c_str(), 
    			oCmcnotsgninfbiz.m_instdpty.c_str(), 
    			pchMsg, 
	    		oCmcnotsgninfbiz.m_syscd.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvPkg012::InsertUsualInfoDb()");	
}

INT32 CRecvPkg012::ChargeMb()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvPkg012::ChargeMb");
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CRecvPkg012::ChargeMb"); 
    
    return 0;
}

void CRecvPkg012::Fill40503Msg(string strTxid,string strAcct,string strAmt,
                                    string strStat)//通用信息业务
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvPkg012::Fill40503Msg");
    
    char szTemp[32] = {0};
    
    //标题+正文内容+附件文件名+附件长度+附件内容
    char szAppData[8+32+15+2+1] = {0};    

   sprintf(szAppData, "%-8s%-32s%015s%02s%",\
                        strTxid.c_str(),\
                        strAcct.c_str(),\
                        strAmt.c_str(),\
                        strStat.c_str());  
   
    str40503AppData += szAppData;
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "szAppData[%s]",szAppData);   
     

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CRecvPkg012::Fill40503Msg");
}

void CRecvPkg012::Fill40506Msg( string dbtrbrnchid, string cdtrbrnchid, string oriConsigndate, string oriTxssno, string oriTradetype ) /*通用信息业务 */
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvPkg012::Fill40506Msg");
    
    char szTemp[32] = {0};
    
    //标题+正文内容+附件文件名+附件长度+附件内容
    m_rtnpkg012.m_szCurElementNo = "005";
    strncpy(m_rtnpkg012.stBizBody005.szTrxsType,"40506",sizeof(m_rtnpkg012.stBizBody005.szTrxsType)-1); 
    strncpy(m_rtnpkg012.stBizBody005.szOdfiCode,m_pkg012.stPkgHead012.szRdfiCode,sizeof(m_rtnpkg012.stBizBody005.szOdfiCode)-1); 
    strncpy(m_rtnpkg012.stBizBody005.szRdfiCode,m_pkg012.stPkgHead012.szOdfiCode,sizeof(m_rtnpkg012.stBizBody005.szRdfiCode)-1); 
    strncpy(m_rtnpkg012.stBizBody005.szConsignDate,m_pkg012.stPkgHead012.szPkgCDate,sizeof(m_rtnpkg012.stBizBody005.szConsignDate)-1); 
    strncpy(m_rtnpkg012.stBizBody005.szTxssNo,oriTxssno.c_str(),sizeof(m_rtnpkg012.stBizBody005.szTxssNo)-1); 
    
    char szAppData[91+1] = {0};    
    sprintf(szAppData, "%-8s%-8s%-5s%08s%-2s%-60s",\
                        oriConsigndate.c_str(),\
                        oriTxssno.c_str(),\
                        oriTradetype.c_str(),\
                        "00000000",
                        m_strRtn.c_str(),
                        "");                       

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "szAppData[%s]",szAppData);   
     
    //业务头
    char szBuff[9] = {0};
    memset(szBuff, 0x00, sizeof(szBuff));                  
    itoa(szBuff, strlen(szAppData), 0);
    strncpy(m_rtnpkg012.stBizBody005.szAppLen,szBuff,sizeof(m_rtnpkg012.stBizBody005.szAppLen)-1); 
    strncpy(m_rtnpkg012.stBizBody005.szAppData,szAppData,sizeof(m_rtnpkg012.stBizBody005.szAppData)-1);     

    m_rtnpkg012.AddBussiness();

    //m_str40506 += m_rtnpkg012.m_szPkgBody;
    m_DetailCnt++;

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CRecvPkg012::Fill40506Msg");
}
INT32 CRecvPkg012::CreateRtn40503Msg(string dbtrbrnchid,string dbtrchid,
                string dbtrid,string dbtrnm,double amout,
                string endtoendid,string cdtrmmbid,
                string cdtrbrnchid,string cdtrnm,string txid)
{

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvPkg012::CreateRtn40503Msg");
    
    //取通信级标识号
    char m_sMsgRefId[256] = {0};
    if(!GetMsgIdValue(m_dbproc,m_sMsgRefId,eRefId,SYS_BEPS,m_pkg012.stPkgHead012.szRdfiCode))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取通信级标识号错误!");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_MESGREFID_FAIL, "获取通信级标识号错误!");
    }

	strncpy(m_rtnpkg012.stPkgHead012.szPkgType,"012",sizeof(m_rtnpkg012.stPkgHead012.szPkgType)-1); 
	strncpy(m_rtnpkg012.stPkgHead012.szOdfiCode,m_pkg012.stPkgHead012.szRdfiCode,sizeof(m_rtnpkg012.stPkgHead012.szOdfiCode)-1); 
	strncpy(m_rtnpkg012.stPkgHead012.szRdfiCode,m_pkg012.stPkgHead012.szOdfiCode,sizeof(m_rtnpkg012.stPkgHead012.szRdfiCode)-1); 
	strncpy(m_rtnpkg012.stPkgHead012.szPkgCDate, m_pkg012.stPkgHead012.szPkgCDate, sizeof(m_rtnpkg012.stPkgHead012.szPkgCDate) - 1);
	strncpy(m_rtnpkg012.stPkgHead012.szPkgserNo,m_pkg012.stPkgHead012.szPkgserNo,sizeof(m_rtnpkg012.stPkgHead012.szPkgserNo)-1);
	strncpy(m_rtnpkg012.stPkgHead012.szSoFlag,"0",sizeof(m_rtnpkg012.stPkgHead012.szSoFlag)-1); /*辖内分发标志		    1n*/     
	strncpy(m_rtnpkg012.stPkgHead012.szTradetype,"40503",sizeof(m_rtnpkg012.stPkgHead012.szTradetype)-1); /*业务类型号			    5n*/   
	strncpy(m_rtnpkg012.stPkgHead012.szDetailCnt,"1",sizeof(m_rtnpkg012.stPkgHead012.szDetailCnt)-1); 

    char szBuff[9] = {0};
    memset(szBuff, 0x00, sizeof(szBuff));                  
    itoa(szBuff, str40503AppData.length(), 0);
    strncpy(m_rtnpkg012.stBizBody005.szAppLen,szBuff,sizeof(m_rtnpkg012.stBizBody005.szAppLen)-1); 
    strncpy(m_rtnpkg012.stBizBody005.szAppData,str40503AppData.c_str(),sizeof(m_rtnpkg012.stBizBody005.szAppData)-1);     

    
    //2. 组报文头
    m_rtnpkg012.CreateMsgHeader("012",
                             m_pkg012.stPkgHead012.szRdfiCode,
                             m_pkg012.stPkgHead012.szOdfiCode,
                             m_sMsgRefId,
                             m_sMsgRefId,
                             m_strWorkDate.c_str(),
                             "1");
    
    //3. 组业务体
    m_rtnpkg012.AddBussiness();
    
    //4. 组报文尾
    m_rtnpkg012.CreateMsgTail();
    
    //5. 组报文
    m_rtnpkg012.CreateMsg();

    AddQueue(m_rtnpkg012.m_szMsgText, m_rtnpkg012.m_szMsgText.size());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CRecvPkg012::CreateRtn40503Msg"); 

    return iRet;
}

INT32 CRecvPkg012::CreateRtn40506Msg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvPkg012::CreateRtn40506Msg");
    
    //取通信级标识号
    char m_sMsgRefId[256] = {0};
    if(!GetMsgIdValue(m_dbproc,m_sMsgRefId,eRefId,SYS_BEPS,m_pkg012.stPkgHead012.szRdfiCode))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取通信级标识号错误!");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_MESGREFID_FAIL, "获取通信级标识号错误!");
    }

    //取msgid
    char szchMsgId[35] = {0};
    GetMsgIdValue(m_dbproc, szchMsgId, eMsgId, SYS_BEPS);
    string strTxid = szchMsgId + 8;

	strncpy(m_rtnpkg012.stPkgHead012.szPkgType,"012",sizeof(m_rtnpkg012.stPkgHead012.szPkgType)-1); 
	strncpy(m_rtnpkg012.stPkgHead012.szOdfiCode,m_pkg012.stPkgHead012.szRdfiCode,sizeof(m_rtnpkg012.stPkgHead012.szOdfiCode)-1); 
	strncpy(m_rtnpkg012.stPkgHead012.szRdfiCode,m_pkg012.stPkgHead012.szOdfiCode,sizeof(m_rtnpkg012.stPkgHead012.szRdfiCode)-1); 
	strncpy(m_rtnpkg012.stPkgHead012.szPkgCDate, m_pkg012.stPkgHead012.szPkgCDate, sizeof(m_rtnpkg012.stPkgHead012.szPkgCDate) - 1);
	strncpy(m_rtnpkg012.stPkgHead012.szPkgserNo,strTxid.c_str(),sizeof(m_rtnpkg012.stPkgHead012.szPkgserNo)-1);
	strncpy(m_rtnpkg012.stPkgHead012.szSoFlag,"0",sizeof(m_rtnpkg012.stPkgHead012.szSoFlag)-1); /*辖内分发标志		    1n*/     
	strncpy(m_rtnpkg012.stPkgHead012.szTradetype,"40506",sizeof(m_rtnpkg012.stPkgHead012.szTradetype)-1); /*业务类型号			    5n*/   
    //strncpy(m_rtnpkg012.stPkgHead012.szAppData,"",sizeof(m_rtnpkg012.stPkgHead012.szAppData)-1); /*包附言*/

    char szDetailCnt[5] = {0};
    sprintf(szDetailCnt, "%04d%",m_DetailCnt);    
    strncpy(m_rtnpkg012.stPkgHead012.szDetailCnt,szDetailCnt,sizeof(m_rtnpkg012.stPkgHead012.szDetailCnt)-1); 

    //2. 组报文头
    m_rtnpkg012.CreateMsgHeader("012",
                             m_pkg012.stPkgHead012.szRdfiCode,
                             m_pkg012.stPkgHead012.szOdfiCode,
                             m_sMsgRefId,
                             m_sMsgRefId,
                             m_strWorkDate.c_str(),
                             "1");
    
    //3. 组业务体
    
    //加押
    char szMac[40 + 1] = {0};
    string strCodeMac;//取加押串
    m_rtnpkg012.GetMacStr(m_rtnpkg012, strCodeMac);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "__strCodeMac = [%s]", strCodeMac.c_str());
    CodeMac(m_dbproc,strCodeMac.c_str(),szMac);
    //......
    memcpy(m_rtnpkg012.stPkgHead012.szPkgDest, szMac, sizeof(szMac)-1);

    //4. 组报文尾
    m_rtnpkg012.CreateMsgTail();
    
    //5. 组报文
    m_rtnpkg012.CreateMsg();

    AddQueue(m_rtnpkg012.m_szMsgText, m_rtnpkg012.m_szMsgText.size());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CRecvPkg012::CreateRtn40506Msg"); 
    return iRet;
}

INT32 CRecvPkg012::CreatePkg005( const CBpcolltnchrgslist* m_colltnchrgslist, string dbtrissr, string cdtrissr )
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvPkg012::CreatePkg005");

    //取txid
    char szchTxId[32 +1] = {0};
    bool bRet = GetMsgIdValue(m_dbproc, szchTxId, eMsgId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "参数错误");
        PMTS_ThrowException(PRM_FAIL);
    }

    char szBuffer[600] = {0};
    sprintf(szBuffer, "%08s%08s%12s%12s%-32s%-60s%-60s%015.0f%-60s%-60s%08d",
            szchTxId+8,
            szchTxId+8,
            m_colltnchrgslist->m_dbtrbrnchid.c_str(),
            m_colltnchrgslist->m_dbtrbrnchid.c_str(),
            m_colltnchrgslist->m_dbtrid.c_str(),
            m_colltnchrgslist->m_dbtrnm.c_str(),
            "",
            m_colltnchrgslist->m_amout*100,
            "",
            "",
            0);
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "szBuffer=[%s]\n", szBuffer);
    
    m_BpBcList.m_instgdrctpty   = m_pkg012.stPkgHead012.szRdfiCode;         //发起直接参与机构/代付业务接收清算行
    m_BpBcList.m_workdate       = m_sWorkDate;                           //工作日期
    m_BpBcList.m_msgtp          = "PKG005";                            //报文类型
    m_BpBcList.m_msgid          = m_msgid005;                            //报文标识卿
	m_BpBcList.m_instddrctpty   = m_colltnchrgslist->m_cdtrmmbid;        //接收直接参与机构/收款清算蟿
	m_BpBcList.m_currency       = "RMB";                                 //货币符号
	m_BpBcList.m_txid           = szchTxId;                              //明细标识卿
	m_BpBcList.m_consigdate     = m_pkg012.stBizBody005.szConsignDate;      //委托日期
	m_BpBcList.m_dbtnm          = m_colltnchrgslist->m_dbtrnm;        //付款人名祿
	m_BpBcList.m_dbtracctid     = m_colltnchrgslist->m_dbtrid;         //付款人帐卿
	m_BpBcList.m_dbtrissr       = dbtrissr; //付款人开户行行号
	m_BpBcList.m_dbtrbrnchid    = m_colltnchrgslist->m_dbtrbrnchid;         //付款行行号
	m_BpBcList.m_cdtrnm         = m_colltnchrgslist->m_cdtrnm;    //收款人名祿
	m_BpBcList.m_cdtracctid     = m_colltnchrgslist->m_cdtrid;     //收款人帐卿
	m_BpBcList.m_cdtrissr       = cdtrissr; //收款人开户行行号
	m_BpBcList.m_cdtrbrnchid    = m_colltnchrgslist->m_cdtrbrnchid;         //收款人行卿
	m_BpBcList.m_amount         = m_colltnchrgslist->m_amout;     //交易金额
	m_BpBcList.m_busistate      = "";                                    //业务状徿
	m_BpBcList.m_rjctinf        = "";                                    //业务拒绝信息
	m_BpBcList.m_procstate      = PR_HVBP_08;                          //处理状徿
	m_BpBcList.m_finalstatedate = "";                                    //清算日期/终态日暿
	m_BpBcList.m_remark2        = "PKG012";                                 //备注 这里表示原业务为代付业务
	m_BpBcList.m_isrbflg        = "0";                                   //是否退汇标彿
	m_BpBcList.m_acctstate      = BUS_INIT;                              //记账状徿00：初奿
	m_BpBcList.m_acctregnum     = "";                                    //记账流水卿
	m_BpBcList.m_reacregnum     = "";                                    //冲正流水卿
	m_BpBcList.m_netgdt         = "";                                     //NPC轧差日期
    m_BpBcList.m_netgrnd        = "";                                    //NPC轧差场次
    m_BpBcList.m_srcflag        = "1";                                   //客户端发起
    m_BpBcList.m_pmttpprtry     = m_pkg012.stBizBody005.szTrxsType;//业务类型编码
    m_BpBcList.m_purpprtry      = m_colltnchrgslist->m_puryprtry;//业务种类编码
    m_BpBcList.m_reserve        = "1";                                  //表示当前业务处理了几天,日切时要与最大退汇期限做对比
    m_BpBcList.m_orgnlmsgid     = m_strMsgID;                           //这里写包序号,表示为代付业务,以便于回执来的时候查询
    m_BpBcList.m_oritxid        = m_pkg012.stBizBody005.szTxssNo;       //这里做为代付业务的要素的信息业务序号用
    m_BpBcList.m_oriinstgdrctpty= m_colltnchrgslist->m_instgdrctpty;
    m_BpBcList.m_addtlinf2      = m_colltnchrgslist->m_txid;             //这里写每个要素循环里的明细号,这里赋值与代收不一样

    //判断检查是否成功来决定是否加入报文明细.
    if (0 == m_iFlag)
    {
        m_BpBcList.m_processcode    = "";                                      //业务处理瞿
        m_BpBcList.m_npcmsglen      = strlen(szBuffer);                        //NPC报文长度
        m_BpBcList.m_npcmsg         = szBuffer;                                //NPC报文
        ++m_iTotalNum;
        m_dTotalAmt += m_colltnchrgslist->m_amout; 
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "包号[%s]要素号[%s]创建的定期贷记包MSGID[%s]TXID[%s]\n", m_strMsgID.c_str(), m_pkg012.stBizBody005.szTxssNo, m_msgid005.c_str(), szchTxId);
    } 
    else
    {
        m_BpBcList.m_processcode    = "90";                                     //业务处理瞿
        m_BpBcList.m_npcmsglen      = 0;                                        //NPC报文长度
        m_BpBcList.m_npcmsg         = "";                                       //NPC报文
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "包号[%s]要素号[%s]明细号[%s]检查失败不组进报文\n", m_strMsgID.c_str(), m_pkg012.stBizBody005.szTxssNo, m_colltnchrgslist->m_txid.c_str());
    }

	SETCTX(m_BpBcList);
	iRet = m_BpBcList.insert();
    if(OPERACT_SUCCESS != iRet)
    {
         Trace(L_INFO,  __FILE__,  __LINE__, NULL, "insert() failed:[%d][%s]",iRet,m_BpBcList.GetSqlErr());        
         PMTS_ThrowException(DB_INSERT_FAIL);
    }     
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CRecvPkg012::CreatePkg005"); 
    return 0;
}

INT32 CRecvPkg012::CreatePkg006(const CBpcolltnchrgslist* m_colltnchrgslist, string dbtrissr, string cdtrissr, int reciptdate)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvPkg012::CreatePkg006");

    //取txid
    char szchTxId[32 +1] = {0};
    bool bRet = GetMsgIdValue(m_dbproc, szchTxId, eMsgId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "参数错误");
        PMTS_ThrowException(PRM_FAIL);
    }

    char szBuffer[600] = {0};
    sprintf(szBuffer, "%08s%08s%12s%12s%-32s%-60s%-60s%015.0f%-60s%-60s%08d",
            szchTxId+8,
            szchTxId+8,
            m_colltnchrgslist->m_dbtrbrnchid.c_str(),
            m_colltnchrgslist->m_dbtrbrnchid.c_str(),
            m_colltnchrgslist->m_dbtrid.c_str(),
            m_colltnchrgslist->m_dbtrnm.c_str(),
            "",
            m_colltnchrgslist->m_amout*100,
            "",
            "",
            0);
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "szBuffer=[%s]\n", szBuffer);
    
    m_cBpbdsndlist.m_instgdrctpty   = m_pkg012.stPkgHead012.szRdfiCode;         //发起直接参与机构/收款清算行
    m_cBpbdsndlist.m_workdate       = m_sWorkDate;                           //工作日期
    m_cBpbdsndlist.m_msgtp          = "PKG006";                            //报文类型
    m_cBpbdsndlist.m_msgid          = m_msgid006;                            //报文标识号
	m_cBpbdsndlist.m_instddrctpty   = m_colltnchrgslist->m_dbtrmmbid;         //接收直接参与机构/收款清算行
	m_cBpbdsndlist.m_currency       = "RMB";                                 //货币符号
    m_cBpbdsndlist.m_pkgrtrltd      = reciptdate;
	m_cBpbdsndlist.m_txid           = szchTxId;                             //明细标识号
	m_cBpbdsndlist.m_agrmtnb        = m_colltnchrgslist->m_endtoendid;
	m_cBpbdsndlist.m_consigdate     = m_pkg012.stBizBody005.szConsignDate;      //委托日期
	m_cBpbdsndlist.m_dbtnm          = m_colltnchrgslist->m_dbtrnm;        //付款人名称
	m_cBpbdsndlist.m_dbtracctid     = m_colltnchrgslist->m_dbtrbrnchid;         //付款人帐号
	m_cBpbdsndlist.m_dbtrissr       = dbtrissr; //付款人开户行行号
	m_cBpbdsndlist.m_dbtrbrnchid    = m_colltnchrgslist->m_dbtrbrnchid;         //付款行行号
	m_cBpbdsndlist.m_cdtrnm         = m_colltnchrgslist->m_cdtrnm;    //收款人名称
	m_cBpbdsndlist.m_cdtracctid     = m_colltnchrgslist->m_cdtrbrnchid;     //收款人帐号
	m_cBpbdsndlist.m_cdtrissr       = cdtrissr; //收款人开户行行号
	m_cBpbdsndlist.m_cdtrbrnchid    = m_colltnchrgslist->m_cdtrbrnchid;         //收款人行号
	m_cBpbdsndlist.m_amount         = m_colltnchrgslist->m_amout;     //交易金额
	m_cBpbdsndlist.m_busistate      = "";                                    //业务状态
	m_cBpbdsndlist.m_rjctinf        = "";                                    //业务拒绝信息
	m_cBpbdsndlist.m_procstate      = PR_HVBP_08;                          //处理状态
	m_cBpbdsndlist.m_finalstatedate = "";                                    //清算日期/终态日期
	m_cBpbdsndlist.m_rmk            = "";                                    //备注
	m_cBpbdsndlist.m_isrbflg        = "0";                                   //是否退汇标志
//    m_cBpbdsndlist.m_bizsource      = "1";                                   //客户端发起
	m_cBpbdsndlist.m_acctstate      = BUS_INIT;                              //记账状态(00：初始)
	m_cBpbdsndlist.m_acctregnum     = "";                                    //记账流水号
	m_cBpbdsndlist.m_reacregnum     = "";                                    //冲正流水号
	m_cBpbdsndlist.m_netgdt         = "";                                     //NPC轧差日期
    m_cBpbdsndlist.m_netgrnd        = "";                                   //NPC轧差场次    
    m_cBpbdsndlist.m_pmttpprtry     = m_pkg012.stBizBody005.szTrxsType;     //业务类型编码
    m_cBpbdsndlist.m_purpprtry      = m_colltnchrgslist->m_puryprtry;       //业务种类编码
    m_cBpbdsndlist.m_oritxid        = m_pkg012.stBizBody005.szTxssNo;       //这里做为代收业务的要素的信息业务序号用
    m_cBpbdsndlist.m_orgnlmsgid     = m_strMsgID;                           //这里写包序号,
    m_cBpbdsndlist.m_oriinstgdrctpty= m_colltnchrgslist->m_instgdrctpty;
    m_cBpbdsndlist.m_remark         = m_colltnchrgslist->m_txid;            //这里写每个要素循环里的明细号
    m_cBpbdsndlist.m_addinfo2       = "PKG012";                             //表示为代收业务,以便于回执来的时候查询
    m_cBpbdsndlist.m_addtlinf       = "1";                                  //回执累积天数

    //判断检查是否成功来决定是否加入报文明细.
    if (0 == m_iFlag)
    {
        m_cBpbdsndlist.m_processcode    = "";                                    //业务处理码
        m_cBpbdsndlist.m_npcmsglen      = strlen(szBuffer);                        //NPC报文长度
        m_cBpbdsndlist.m_npcmsg         = szBuffer;                                //NPC报文
        ++m_iTotalNum;
        m_dTotalAmt += m_colltnchrgslist->m_amout; 
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "包号[%s]要素号[%s]创建的定期借记包MSGID[%s]TXID[%s]\n", m_strMsgID.c_str(), m_pkg012.stBizBody005.szTxssNo, m_msgid006.c_str(), szchTxId);

    } 
    else
    {
        m_cBpbdsndlist.m_processcode    = "90";                                    //业务处理码
        m_cBpbdsndlist.m_npcmsglen      = 0;                                    //NPC报文长度
        m_cBpbdsndlist.m_npcmsg         = "";                                   //NPC报文
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "包号[%s]要素号[%s]明细号[%s]检查失败不组进报文\n", m_strMsgID.c_str(), m_pkg012.stBizBody005.szTxssNo, m_colltnchrgslist->m_txid.c_str());
    }


	SETCTX(m_cBpbdsndlist);
	iRet = m_cBpbdsndlist.insert();
    if(OPERACT_SUCCESS != iRet)
    {
         Trace(L_INFO,  __FILE__,  __LINE__, NULL, "insert() failed:[%d][%s]",iRet,m_cBpbdsndlist.GetSqlErr());        
         PMTS_ThrowException(DB_INSERT_FAIL);
    }     
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CRecvPkg012::CreatePkg006"); 
    return 0;
}

void CRecvPkg012::PackPkg005()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvPkg012::PackPkg005()");

    int iUpdCode		= RTN_FAIL;

    //取通信级标识号
    char m_sMsgRefId[256] = {0};
    if(!GetMsgIdValue(m_dbproc,m_sMsgRefId,eRefId,SYS_BEPS,m_pkg012.stPkgHead012.szRdfiCode))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取通信级标识号错误!");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_MESGREFID_FAIL, "获取通信级标识号错误!");
    }

    //1、组报文头
    int iRet = m_opkg005.CreateMsgHeader("005",
                                        m_BpBcList.m_instgdrctpty.c_str(),
                                        m_BpBcList.m_instddrctpty.c_str(),
                                        m_sMsgRefId,
                                        m_sMsgRefId,
                                        m_sWorkDate,
                                        "1"	
                                        )	;
    if (SQL_SUCCESS != iRet) 
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "创建报文头失败！");
        PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "创建报文头失败！");
    }

    //2、组批量包头｛P:
    strncpy(m_opkg005.stHead001.szPkgType , "005",                 sizeof(m_opkg005.stHead001.szPkgType )-1); //02C   包类型号
    strncpy(m_opkg005.stHead001.szOdfiCode, m_BpBcList.m_instgdrctpty.c_str(), sizeof(m_opkg005.stHead001.szOdfiCode)-1); //011   包发起清算行
    strncpy(m_opkg005.stHead001.szRdfiCode, m_BpBcList.m_instddrctpty.c_str(), sizeof(m_opkg005.stHead001.szRdfiCode)-1); //012   包接收清算行
    strncpy(m_opkg005.stHead001.szPkgCDate, m_msgid006.c_str(),    sizeof(m_opkg005.stHead001.szPkgCDate)-1); //30E   包委托日期
    strncpy(m_opkg005.stHead001.szPkgserNo, m_msgid006.c_str()+8,  sizeof(m_opkg005.stHead001.szPkgserNo)-1); //0BD   包序号   

    //要素集
    strncpy(m_opkg005.stBody003.szTrxsType,         m_BpBcList.m_pmttpprtry.c_str(), sizeof(m_opkg005.stBody003.szTrxsType)-1);
    strncpy(m_opkg005.stBody003.szOdfiCode,         m_BpBcList.m_dbtrbrnchid.c_str(),sizeof(m_opkg005.stBody003.szOdfiCode)-1);
    strncpy(m_opkg005.stBody003.szConsignDate,      m_BpBcList.m_consigdate.c_str(), sizeof(m_opkg005.stBody003.szConsignDate)-1);
    strncpy(m_opkg005.stBody003.szPayOpenAccBkCode, m_BpBcList.m_dbtrissr.c_str(),   sizeof(m_opkg005.stBody003.szPayOpenAccBkCode)-1);
    strncpy(m_opkg005.stBody003.szPayerAcc,         m_BpBcList.m_dbtracctid.c_str(), sizeof(m_opkg005.stBody003.szPayerAcc)-1);
    strncpy(m_opkg005.stBody003.szPayerName,        m_BpBcList.m_dbtnm.c_str(),      sizeof(m_opkg005.stBody003.szPayerName)-1);
    strncpy(m_opkg005.stBody003.szPayerAddr,        m_BpBcList.m_dbtaddr.c_str(),    sizeof(m_opkg005.stBody003.szPayerAddr)-1);
    sprintf(m_opkg005.stBody003.szTrxKind,          "%-12s",  m_BpBcList.m_purpprtry.c_str());
    sprintf(m_opkg005.stBody003.szListNum,          "%d",                           m_iTotalNum);
    m_opkg005.m_cstrListStr += m_BpBcList.m_npcmsg.c_str();
    m_opkg005.m_szCurElementNo = "003";
    m_opkg005.AddBussiness();

    sprintf(m_opkg005.stHead001.szDetailCnt, "%08d", m_iTotalNum);         //B63   明细业务总笔数,这里要填收款人的数目
    sprintf(m_opkg005.stHead001.szDetailAmt  , "RMB%015.0f", m_dTotalAmt*100);    //32B   明细业务总金额

    //加押
    char szMac[40 + 1] = {0};
    string strCodeMac;//取加押串
    m_opkg005.GetMacStr(m_opkg005, strCodeMac);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "__strCodeMac = [%s]", strCodeMac.c_str());
    //......
    memcpy(m_opkg005.stHead001.szPkgDest, szMac, sizeof(szMac)-1);

    //4、组报文尾
    m_opkg005.CreateMsgTail();

    //5、组报文
    m_opkg005.CreateMsg();

    //6、小额往帐贷记汇总表
    m_cBpbcoutsndcl.m_workdate      = m_sWorkDate;
    m_cBpbcoutsndcl.m_msgtp         = m_strMsgTp;
    m_cBpbcoutsndcl.m_dgtsign       = "NULL";                  //数值签名
    m_cBpbcoutsndcl.m_msgid         = m_msgid005;              //报文标识号/包序号
    m_cBpbcoutsndcl.m_mesgid        = m_sMsgRefId;              //通信级标识号
    m_cBpbcoutsndcl.m_mesgrefid     = m_sMsgRefId;              //通信级标识号参考号
    m_cBpbcoutsndcl.m_instgdrctpty  = m_BpBcList.m_instgdrctpty;           //发起直接参与机构/付款清算行
    m_cBpbcoutsndcl.m_instddrctpty  = m_BpBcList.m_instddrctpty;           //接收直接参与机构/收款清算行
    m_cBpbcoutsndcl.m_workdate      = m_sWorkDate;            //工作日期
    m_cBpbcoutsndcl.m_consigdate    = m_msgid005.substr(0,8);  //委托日期
    m_cBpbcoutsndcl.m_srcflag       = "0";                     //补发标志
    m_cBpbcoutsndcl.m_realtimeflag  = "0";                     //实时标志
    m_cBpbcoutsndcl.m_procstate     = PR_HVBP_08;              //处理状态
    m_cBpbcoutsndcl.m_checkstate    = "1";                     //对账状态
    m_cBpbcoutsndcl.m_ccy           = "RMB";                   //币种
    m_cBpbcoutsndcl.m_nboftxs       = m_iTotalNum;//明细业务总笔数    
    m_cBpbcoutsndcl.m_ctrlsum       = m_dTotalAmt;//明细业务总金额

    SETCTX(m_cBpbcoutsndcl);
    iRet = m_cBpbcoutsndcl.insert();
    if(SUCCESSED!=iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_cBpbcoutsndcl insert failed[%d][%s]", iRet,m_cBpbcoutsndcl.GetSqlErr());
        PMTS_ThrowException(DB_INSERT_FAIL);
    }

    //发送消息.
    AddQueue(m_opkg005.m_szMsgText, m_opkg005.m_szMsgText.size());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvPkg012::PackPkg005()");
}

void CRecvPkg012::PackPkg006()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvPkg012::PackPkg006()");

    //取通信级标识号
    char m_sMsgRefId[256] = {0};
    if(!GetMsgIdValue(m_dbproc,m_sMsgRefId,eRefId,SYS_BEPS,m_pkg012.stPkgHead012.szRdfiCode))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取通信级标识号错误!");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_MESGREFID_FAIL, "获取通信级标识号错误!");
    }

    //1、组报文头
    int iRet = m_opkg006.CreateMsgHeader("006",
                                        m_cBpbdsndlist.m_instgdrctpty.c_str(),
                                        m_cBpbdsndlist.m_instddrctpty.c_str(),
                                        m_sMsgRefId,
                                        m_sMsgRefId,
                                        m_sWorkDate,
                                        "1"	
                                        )	;
    if (SQL_SUCCESS != iRet) 
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "创建报文头失败！");
        PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "创建报文头失败！");
    }

    //2、组批量包头｛P:
    strncpy(m_opkg006.stHead002.szPkgType , "006",                 sizeof(m_opkg006.stHead002.szPkgType )-1); //02C   包类型号
    strncpy(m_opkg006.stHead002.szOdfiCode, m_cBpbdsndlist.m_instgdrctpty.c_str(), sizeof(m_opkg006.stHead002.szOdfiCode)-1); //011   包发起清算行
    strncpy(m_opkg006.stHead002.szRdfiCode, m_cBpbdsndlist.m_instddrctpty.c_str(), sizeof(m_opkg006.stHead002.szRdfiCode)-1); //012   包接收清算行
    strncpy(m_opkg006.stHead002.szPkgCDate, m_msgid006.c_str(),    sizeof(m_opkg006.stHead002.szPkgCDate)-1); //30E   包委托日期
    strncpy(m_opkg006.stHead002.szPkgserNo, m_msgid006.c_str()+8,  sizeof(m_opkg006.stHead002.szPkgserNo)-1); //0BD   包序号   
    sprintf(m_opkg006.stHead002.szRespdays, "%02d",                m_cBpbdsndlist.m_pkgrtrltd);                  //BS6   回执期限（天数）
    sprintf(m_opkg006.stHead002.szDetailCnt, "%08d", m_iTotalNum);         //B63   明细业务总笔数
    sprintf(m_opkg006.stHead002.szDetailAmt  , "RMB%015.0f", m_dTotalAmt*100);    //32B   明细业务总金额

    //3.组要素
    strncpy(m_opkg006.stBody004.szTrxsType,         m_cBpbdsndlist.m_pmttpprtry.c_str(), sizeof(m_opkg006.stBody004.szTrxsType)-1);
    strncpy(m_opkg006.stBody004.szOdfiCode,         m_cBpbdsndlist.m_instgdrctpty.c_str(),          sizeof(m_opkg006.stBody004.szOdfiCode)-1);
    strncpy(m_opkg006.stBody004.szConsignDate,      m_cBpbdsndlist.m_consigdate.c_str(), sizeof(m_opkg006.stBody004.szConsignDate)-1);
    strncpy(m_opkg006.stBody004.szRecOpenAccBkCode, m_cBpbdsndlist.m_cdtrissr.c_str(),   sizeof(m_opkg006.stBody004.szRecOpenAccBkCode)-1);
    strncpy(m_opkg006.stBody004.szRecipientAcc,     m_cBpbdsndlist.m_cdtracctid.c_str(), sizeof(m_opkg006.stBody004.szRecipientAcc)-1);
    strncpy(m_opkg006.stBody004.szRecipientName,    m_cBpbdsndlist.m_cdtrnm.c_str(),     sizeof(m_opkg006.stBody004.szRecipientName)-1);
    strncpy(m_opkg006.stBody004.szRecipientAddr,    m_cBpbdsndlist.m_cdtaddr.c_str(),    sizeof(m_opkg006.stBody004.szRecipientAddr)-1);
    sprintf(m_opkg006.stBody004.szTrxKind,		  "%-12s",        				  m_cBpbdsndlist.m_purpprtry.c_str());
    sprintf(m_opkg006.stBody004.szListNum,          "%08d",                           m_iTotalNum);

    m_opkg006.m_cstrListStr += m_cBpbdsndlist.m_npcmsg.c_str();
    m_opkg006.m_szCurElementNo = "004";
    m_opkg006.AddBussiness();

    //加押
    char szMac[40 + 1] = {0};
    string strCodeMac;//取加押串
    m_opkg006.GetMacStr(m_opkg006, strCodeMac);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strCodeMac = [%s]", strCodeMac.c_str());
    //......
    memcpy(m_opkg006.stHead002.szPkgDest, szMac, sizeof(szMac)-1); //C15   包密押

    //4、组报文尾
    m_opkg006.CreateMsgTail();

    //5、组报文
    m_opkg006.CreateMsg();

    //发送消息.
    AddQueue(m_opkg006.m_szMsgText, m_opkg006.m_szMsgText.size());

    //在这赋值入汇总表
    m_Bpbdsndcl.m_msgtp         = "PKG006";
    m_Bpbdsndcl.m_dgtsign       = "NULL";                 //数值签名
    m_Bpbdsndcl.m_msgid         = m_msgid006;             //报文标识号/包序号
    m_Bpbdsndcl.m_mesgid        = m_sMsgRefId;            //通信级标识号
    m_Bpbdsndcl.m_mesgrefid     = m_sMsgRefId;            //通信级标识号参考号
    m_Bpbdsndcl.m_instgdrctpty  = m_cBpbdsndlist.m_instgdrctpty;          //发起直接参与机构/付款清算行
    m_Bpbdsndcl.m_instddrctpty  = m_cBpbdsndlist.m_instddrctpty;          //接收直接参与机构/收款清算行
    m_Bpbdsndcl.m_workdate      = m_sWorkDate;           //工作日期
    m_Bpbdsndcl.m_consigdate    = m_msgid006.substr(0,8); //委托日期
    m_Bpbdsndcl.m_srcflag       = "0";                    //补发标志
    m_Bpbdsndcl.m_realtimeflag  = "0";                    //实时标志
    m_Bpbdsndcl.m_procstate     = PR_HVBP_08;           //处理状态
    m_Bpbdsndcl.m_ccy           = "RMB";                  //币种
    m_Bpbdsndcl.m_pkgrtrltd     = m_cBpbdsndlist.m_pkgrtrltd;  //回执期限
    m_Bpbdsndcl.m_checkstate    = "1";//对账状态
    m_Bpbdsndcl.m_nboftxs  = m_iTotalNum;//明细业务总笔数    
    m_Bpbdsndcl.m_ctrlsum  = m_dTotalAmt;//明细业务总金额
    
    SETCTX(m_Bpbdsndcl);
    iRet = m_Bpbdsndcl.insert();
    if(SUCCESSED!=iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_cBpbcoutsndcl insert failed[%d][%s]", iRet,m_Bpbdsndcl.GetSqlErr());
        PMTS_ThrowException(DB_INSERT_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvPkg012::PackPkg006()");
}

void CRecvPkg012::InitValue()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enteing CRecvPkg012::InitValue()");

    m_iTotalNumCL += m_iTotalNum;
    m_dTotalAmtCL += m_dTotalAmt;

    m_iTotalNum = 0;
    m_dTotalAmt = 0.00;

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvPkg012::InitValue()");
}