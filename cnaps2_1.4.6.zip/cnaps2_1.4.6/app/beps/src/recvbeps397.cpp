/******************************************************************** 
文件名： recvbeps397.cpp
创建人： handongfeng
日  期： 2011-02-23
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif
#include "recvbeps397.h"

CRecvbeps397::CRecvbeps397()
{
}

CRecvbeps397::~CRecvbeps397()
{

}

int CRecvbeps397::Work(LPCSTR szMsg)
{
    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps397::CRecvbeps397()");
    
     // 解析报文
    unPack(szMsg);

    SetData(szMsg);

     //核签
    CheckSign397();
    
    // 插入数据
    InsertData();
	
    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps397::CRecvbeps397()");
    return OPERACT_SUCCESS;
}

INT32 CRecvbeps397::GetParserObj(LPCSTR szMsg)
{
    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "entering CRecv397::GetParser397Obj");

    // 判断是第几代报文
    int iVer = JudgeMsgVer(szMsg);

    if (MSG_VER_2ND == iVer)
    {
        // 二代报文

    }
    else
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CRecv397::GetParser397Obj Failed");
        return OPERACT_FAILED;
    }

    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "leaving CRecv397::GetParser397Obj");

    return OPERACT_SUCCESS;
}

void CRecvbeps397::CheckSign397()
{
	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps397::CheckSign397()");
	
	m_beps397.getOriSignStr();
	
	CheckSign(m_beps397.m_sSignBuff.c_str(),
						m_beps397.m_szDigitSign.c_str(),
						m_beps397.InstgDrctPty.c_str());
	
	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps397::CheckSign397()");
}

INT32 CRecvbeps397::unPack(LPCSTR szMsg)
{
    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps397::unPack()");
    int iRet = -1;
    // 报文是否为空
    if (NULL == szMsg || '\0' == szMsg)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");	
    	PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "报文为空");
    }
    //获取工作日期
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(iRet != RTN_SUCCESS)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");	
    	PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;    

        m_Bpcstpmtqryrspn.m_msgtp = "beps.397.001.01";       
        iRet = m_beps397.ParseXml(szMsg);
    if (OPERACT_SUCCESS!= iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取解析对象失败");	
        PMTS_ThrowException(OPT_SET_VLU_FAIL);
    }
    
    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps397::unPack()");
    return OPERACT_SUCCESS;
}

INT32 CRecvbeps397::InsertData()
{
    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps397::InsertData()");
    
    SETCTX(m_Bpcstpmtqryrspn);
    int iRet = m_Bpcstpmtqryrspn.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
            " m_Bpcstpmtqryrspn insert fail:error code=[%d], error cause =[%s]", iRet, m_Bpcstpmtqryrspn.GetSqlErr());
        PMTS_ThrowException(DB_INSERT_FAIL);
    }
    
    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps397::InsertData()");
    return iRet;
}

INT32 CRecvbeps397::SetData(LPCSTR pchMsg)
{
    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps397::SetData()");
    
    SETCTX(m_Bpcstpmtqryrspn);

    //获取通信id
    char sMesgId[20 + 1] = {0};
    GetMsgIdValue(m_dbproc, sMesgId, eRefId,  SYS_BEPS);

    m_Bpcstpmtqryrspn.m_workdate = m_strWorkDate ; 
    m_Bpcstpmtqryrspn.m_mesgid= sMesgId ; 
    m_Bpcstpmtqryrspn.m_mesgrefid= sMesgId ; 
    m_Bpcstpmtqryrspn.m_msgid= m_beps397.MsgId; 
    m_Bpcstpmtqryrspn.m_instgdrctpty= m_beps397.InstgDrctPty; 
    m_Bpcstpmtqryrspn.m_instgpty= m_beps397.GrpHdrInstgPty ; 
    m_Bpcstpmtqryrspn.m_instddrctpty= m_beps397.InstdDrctPty; 
    m_Bpcstpmtqryrspn.m_instdpty= m_beps397.GrpHdrInstdPty ; 
    m_Bpcstpmtqryrspn.m_syscd= m_beps397.SysCd; 
    m_Bpcstpmtqryrspn.m_rmk= m_beps397.Rmk; 
    m_Bpcstpmtqryrspn.m_orgnlmsgid= m_beps397.OrgnlMsgId; 
    m_Bpcstpmtqryrspn.m_orgnlinstgpty= m_beps397.OrgnlInstgPty; 
    m_Bpcstpmtqryrspn.m_orgnlmt= m_beps397.OrgnlMT; 

    m_Bpcstpmtqryrspn.m_status= m_beps397.Sts; 
    m_Bpcstpmtqryrspn.m_rjctcd= m_beps397.RjctCd; 
    m_Bpcstpmtqryrspn.m_rjctinf= m_beps397.RjctInf; 
    m_Bpcstpmtqryrspn.m_rjcprcpty= m_beps397.PrcPty; 
    m_Bpcstpmtqryrspn.m_cdtrmmbid= m_beps397.MmbId; 
    m_Bpcstpmtqryrspn.m_cdtrid= m_beps397.BrnchIdId; 
    m_Bpcstpmtqryrspn.m_cdtrnm= m_beps397.Nm; 
    m_Bpcstpmtqryrspn.m_cdtraccid= m_beps397.OthrId; 
    m_Bpcstpmtqryrspn.m_cdtrissr= m_beps397.Issr; 
    m_Bpcstpmtqryrspn.m_currency= m_beps397.Ccy; 
    m_Bpcstpmtqryrspn.m_pmtamt= atof(m_beps397.PmtAmt.c_str()); 
	m_Bpcstpmtqryrspn.m_rsflag = "2";
	
    m_Bpgettx.m_msgid    = m_beps397.OrgnlMsgId;
    m_Bpgettx.m_instgpty = m_beps397.OrgnlInstgPty;
	m_Bpgettx.m_rsflag = "1";

    SETCTX(m_Bpgettx);
    int iRet = m_Bpgettx.findByPK();
    if(RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_Bpgettx.m_msgid[%s]", m_Bpgettx.m_msgid.c_str());
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_Bpgettx.m_instgpty[%s]", m_Bpgettx.m_instgpty.c_str());
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取数据失败, iRet = %d", iRet, m_Bpgettx.GetSqlErr());
		PMTS_ThrowException(DB_NOT_FOUND);
	}
	
	m_Bpcstpmtqryrspn.m_orgnlctgypurpcd = m_Bpgettx.m_purpprtry    ;
	m_Bpcstpmtqryrspn.m_orgnlchrgid = m_Bpgettx.m_chrgid    ;
	m_Bpcstpmtqryrspn.m_orgnlcorprtnid = m_Bpgettx.m_corprtnid    ;
	m_Bpcstpmtqryrspn.m_orgnlusrid = m_Bpgettx.m_cusflag    ;
	
	string strSQL;
	strSQL += "UPDATE bp_gettx t SET t.PROCSTATE = '07' ";	
	strSQL += " WHERE t.MSGID = '";
	strSQL += m_Bpgettx.m_msgid.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_Bpgettx.m_instgpty.c_str(); 									
	strSQL += "' AND t.RSFLAG = '1' ";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());
	
	iRet = m_Bpcstpmtqryrspn.execsql(strSQL.c_str());
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "修改发送状态失败iRet=%d, %s", iRet, m_Bpcstpmtqryrspn.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}  
	
    if (m_Bpgettx.m_mbmsgid.length() > 0)//发起方(1客户端2行内)
    {
        if (m_Bpgettx.m_mbmsgid[0] == '2')//表示原业务行内发起
        {
            m_IsSendMB = true;
        }
        else
        {
            m_IsSendMB = false;
        }
    }
    else
    {
        m_IsSendMB = false;
    }
    m_Bpcstpmtqryrspn.m_mbmsgid= m_Bpgettx.m_mbmsgid[0] ; 

    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps397::SetData()");
    return OPERACT_SUCCESS;
}


