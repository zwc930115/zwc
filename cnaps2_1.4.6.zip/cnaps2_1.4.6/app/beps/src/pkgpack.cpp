/********************************************************************
文件名：pkgback.cpp
创建人：lify
日  期   ：2011-05-24
修改人：
日  期   ：
描  述   ：PKG打包处理服务主控
版  本   ：
Copyright (c) 2011  YLINK
********************************************************************/

//#ifdef _LINUX_
//#define SQLCA_STORAGE_CLASS extern
//#include "sqlca.h"
//#endif
#include <sqlca.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <vector>
#include "exception.h"
#include "connectpool.h"
#include "configparser.h"
#include "thread.h"
#include "logger.h"
#include "cfg_obj.h"
#include "pubfunc.h"

#include "pkgpackwork.h"
#include "bppkgassist1.h"
#include "bpsapbankinfo.h" 

//#include "CNAPS2hsm.h"
//#include "assist.h"

using namespace ZFPT;


#define MQ_ERR_MAX_TIMES    20

CConnectPool                *g_DBConnPool;
CCfgObj                     pCfgFile;

char						g_MQmgr[256];
char						g_MqTxtPath[256];
char						g_SendQueue[128];
char                        g_SendCBSP[128];
int                         g_IsConnCBSP;
char                        g_IP[16];

int         	            g_iCfcaSign = 0;//是否加签名或加押

DBProc		m_dbproc					   ;

int LoadConfigFile(stuCfgInfo &CfgInfo);

bool IsPkgPack(DBProc &dbProc, int &iListSum);

void getPkgPackInfo(DBProc &dbProc, vector<stPkgTab> &array, int iCount);

bool isRunTime(const char* pDateTime, const char* pTimeOut, char* pNowDateTime);


//void SigLoad()
//{
//	unsigned char pReturnCode;
//	unsigned char ucMacAlgFlag='1';
//	unsigned int uiIndex = 511;
//	unsigned int uiTextLen = 128;
//	unsigned char pucText[512 + 1] = {0};
//	unsigned char pucMax[20] = {0};
//	
//	strcpy((char *)pucText, "KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK");
//	//uiTextLen = strlen((char *)pucText);    	
//	
//	CNAPS2_GenerateMac_ByKeyIndex(&pReturnCode, ucMacAlgFlag, uiIndex, uiTextLen, pucText, pucMax);
//	
//	if(pReturnCode == 0x00)
//	{
////			Trace(L_INFO, __FILE__, __LINE__, NULL, "加押成功。");
////			strcpy(pMacStr, MbBinToHex(pucMax, strlen((char *)pucMax)).c_str());
////			iRet = 0;
//		
//		printf("加押成功\n");
//	}
//	else
//	{
////			Trace(L_ERROR, __FILE__, __LINE__, NULL, "加押失败，错误代码[%02x]", ucReturnCode);
////			sprintf((char *)pucMax, "加押失败, 错误代码=[%02x]", ucReturnCode);
////			strcpy(pMacStr, (char *)pucMax);
////			iRet = -1;
//		printf("加押失败，错误代码[%02x]\n", pReturnCode);
//		printf("pucMax=[%s]\n", pucMax);
//	}
//}


int main(int argc, char **argv)
{
//	SigLoad();
	
	stuCfgInfo  CfgInfo					   ;
    char        szRecvMq[60]		= { 0 };
    char        sErrDesc[1024]		= { 0 };
    int         iRet				= 0    ;
	int			iCount				= 0	   ;
	
	vector<stPkgTab> VArray				   ;
	stPkgTab    PkgTab				       ;
	
	//屏蔽信号量
    signal(SIGINT , SIG_IGN);						//屏蔽中断信号
    signal(SIGQUIT, SIG_IGN);						//屏蔽终端退出信号
    signal(SIGALRM, SIG_IGN);						//屏蔽超时信号
    signal(SIGHUP , SIG_IGN);						//屏蔽连接断开信号
    signal(SIGSTOP, SIG_IGN);						//这些信号被忽略
    //signal(SIGCHLD, SIG_IGN);
	
    try
    {
        //1.加载配置文件
        LoadConfigFile(CfgInfo);

        //2.初始化日志
		ZFPTLOG.setCfgInfo(CfgInfo.szLogPath, "pkgpack", (LOG_LEVEL)CfgInfo.iLogLeave, CfgInfo.dLogMaxSize);
		
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化日志...");	

        //3.读XML配置文件
        iRet = pCfgFile.Init(CfgInfo.szXmlCtgPath);		//配置文件路径
        if(iRet != 0)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
                "Failed to Init the node Config Object: ErrCode = %d, ErrInfo = %s", 
                pCfgFile.GetLastErrCode(),pCfgFile.GetLastErrInfo());
			
            exit(0);
        }
		
        //4.创建连接池 
        g_DBConnPool = new CConnectPool(CfgInfo.iConPoolMinNum,CfgInfo.iConPoolMaxNum,CfgInfo.iNoConWaitTime);
		
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化数据库连接池...");    
	    
        iRet= g_DBConnPool->InitPool(CfgInfo.iConPoolSize,CfgInfo.DBUser,CfgInfo.DBKey,CfgInfo.DBName);
		
        if(iRet == RTN_SUCCESS)
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "数据库连接池创建成功");
        }
        else
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "数据库连接池创建失败");
            exit(0);
        }

    }
	catch(CException &e)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
			"Init environment Catch a exception from [%s]",  e.what());
		
        exit(0);
    }

    //初始化线程池
    CThreadPool<CPkgPackWork> cPool;
	
    cPool.start(CfgInfo.iThreadPoolSize, CfgInfo.iThreadPoolTaskSize);  
    
    CBppkgassist1    oCBppkgassist1;//用于数据库回滚
    
    //轮询查看满足条件的待打包数据
    while(1)
    {
        try
        {
        	iCount		= 0;
        	
        	// 获取数据库连接
		    if(0 != g_DBConnPool->GetConnect(m_dbproc))
		    {	
		    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取数据库连接失败, 进程退出");
				
		        exit(0);
		    }
			
        	//是否满足打包条件
			if( !IsPkgPack(m_dbproc, iCount) )
			{
				sleep(10);//为了测试使用10秒
				printf("..\n");
				
				//释放连接
    			g_DBConnPool->PutConnect(m_dbproc);
                continue;
			}

			//获取打包要素
			getPkgPackInfo(m_dbproc, VArray, iCount);

			for(int i = 0; i <  iCount; i++ )
			{
				memset(&PkgTab, 0x00, sizeof(PkgTab));

				strncpy(PkgTab.szWrkDate      , VArray[i].szWrkDate     , sizeof(PkgTab.szWrkDate      ) - 1);
				strncpy(PkgTab.szSendBank     , VArray[i].szSendBank    , sizeof(PkgTab.szSendBank     ) - 1);
				strncpy(PkgTab.szRecvBank     , VArray[i].szRecvBank    , sizeof(PkgTab.szRecvBank     ) - 1);
				strncpy(PkgTab.szMsgType      , VArray[i].szMsgType     , sizeof(PkgTab.szMsgType      ) - 1);
				strncpy(PkgTab.szMsgID        , VArray[i].szMsgID       , sizeof(PkgTab.szMsgID        ) - 1);
				PkgTab.iListCount = VArray[i].iListCount ;
				strncpy(PkgTab.szHandPackFlag , VArray[i].szHandPackFlag, sizeof(PkgTab.szHandPackFlag ) - 1);

				strncpy(PkgTab.szIsRspn       , VArray[i].szIsRspn      , sizeof(PkgTab.szIsRspn       ) - 1);
        		strncpy(PkgTab.szIsAllRspn    , VArray[i].szIsAllRspn   , sizeof(PkgTab.szIsAllRspn    ) - 1);
        		PkgTab.iPKGRtrltd = VArray[i].iPKGRtrltd;
        		strncpy(PkgTab.szPmttpPrtry   , VArray[i].szPmttpPrtry  , sizeof(PkgTab.szPmttpPrtry   ) - 1);
        		strncpy(PkgTab.szIssr         , VArray[i].szIssr        , sizeof(PkgTab.szIssr         ) - 1);
        		strncpy(PkgTab.szAcctId       , VArray[i].szAcctId      , sizeof(PkgTab.szAcctId       ) - 1);
        		strncpy(PkgTab.szOriMsgTp     , VArray[i].szOriMsgTp    , sizeof(PkgTab.szOriMsgTp     ) - 1);
        		strncpy(PkgTab.szOriMsgId     , VArray[i].szOriMsgId    , sizeof(PkgTab.szOriMsgId     ) - 1);
		
				strncpy(PkgTab.szProstate     , VArray[i].szProstate    , sizeof(PkgTab.szProstate     ) - 1);
				
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, "PkgTab.szWrkDate 	  =[%s]", PkgTab.szWrkDate	   );
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, "PkgTab.szSendBank	  =[%s]", PkgTab.szSendBank    );
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, "PkgTab.szRecvBank	  =[%s]", PkgTab.szRecvBank    );
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, "PkgTab.szMsgType 	  =[%s]", PkgTab.szMsgType	   );
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, "PkgTab.szMsgID		  =[%s]", PkgTab.szMsgID	   );
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, "PkgTab.iListCount	  =[%d]", PkgTab.iListCount    );
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, "PkgTab.szHandPackFlag  =[%s]", PkgTab.szHandPackFlag);
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, "PkgTab.szProstate	  =[%s]", PkgTab.szProstate    );				
			
				CPkgPackWork pCPkgPackWork;

				pCPkgPackWork.setData(PkgTab);
				pCPkgPackWork.doWork();

				/*
	            while(JOBPOOL_FULL == (iRet = cPool.push(pCPkgPackWork)))
	            {
					
	                Trace(L_INFO,  __FILE__,  __LINE__, NULL, "任务缓存写满");
				    
	                //注意，因为缓存可能会写满，这里需要等待一下
	                usleep(100);
	            }		

	            if(0 == iRet)
	            {
	                Trace(L_INFO,  __FILE__,  __LINE__, NULL, "添加任务成功");
	            }
	            */
	            
			}
			
			//释放连接
    		g_DBConnPool->PutConnect(m_dbproc);
			
        }
        catch(CException &e)
        {		
            sprintf(sErrDesc, "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());

            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);
            
			//事物回滚
			oCBppkgassist1.rollback();
                       
            sleep(3);
        }

    }


    setsid();  //退出前设置会话session组id,防止影响其子进程 

    return RTN_SUCCESS;
}


int LoadConfigFile(stuCfgInfo &CfgInfo)
{
    CConfigParser& cCfg = CConfigParser::getInstance();

    strcpy(CfgInfo.path, ZFPT_CFG_PATH);
    cCfg.loadConfig(CfgInfo.path);

	strncpy(CfgInfo.szXmlCtgPath, cCfg.getOption("XMLCTGPATH"), sizeof(CfgInfo.szXmlCtgPath)-1);
    strncpy(CfgInfo.szLogPath   , cCfg.getOption("LOGPATH")   , sizeof(CfgInfo.szLogPath)-1   );
    CfgInfo.iPort				= atoi(cCfg.getOption("BEPSPORT")  );
    CfgInfo.iLogLeave			= atoi(cCfg.getOption("LOGLVL")    );
	CfgInfo.dLogMaxSize			= atof(cCfg.getOption("LOGMAXSIZE"));

	memset(g_MQmgr    , 0x00, sizeof(g_MQmgr)    );
	memset(g_SendQueue, 0x00, sizeof(g_SendQueue));
	memset(g_MqTxtPath, 0x00, sizeof(g_MqTxtPath));
	strncpy(g_MQmgr    , cCfg.getOption("MQMGR")     , sizeof(g_MQmgr)-1    );
    //strncpy(g_SendQueue, cCfg.getOption("BEPSSENDMQ"), sizeof(g_SendQueue)-1);
    strncpy(g_SendQueue, cCfg.getOption("BEPSYALIMQ"), sizeof(g_SendQueue)-1);
    strncpy(g_MqTxtPath, cCfg.getOption("MQTEXTPATH"), sizeof(g_MqTxtPath)-1);
	
    CfgInfo.iConPoolMinNum		= atoi(cCfg.getOption("PKGCONNPOOLMINSIZE")   );
    CfgInfo.iConPoolMaxNum		= atoi(cCfg.getOption("PKGCONNPOOLMAXSIZE")   );
    CfgInfo.iNoConWaitTime		= atoi(cCfg.getOption("PKGNOCONNWAITTIME")    );
    CfgInfo.iConPoolSize		= atoi(cCfg.getOption("PKGCONNPOOLSIZE")      );
    CfgInfo.iThreadPoolSize		= atoi(cCfg.getOption("PKGTHREADPOOLSIZE")    );
    CfgInfo.iThreadPoolTaskSize	= atoi(cCfg.getOption("PKGTHREADPOOLTASKSIZE"));

    strncpy(CfgInfo.DBUser,		cCfg.getOption("DBUSER"),sizeof(CfgInfo.DBUser)-1);
    strncpy(CfgInfo.DBKey ,		cCfg.getOption("DBKEY"),sizeof(CfgInfo.DBKey)-1  );
    strncpy(CfgInfo.DBName,		cCfg.getOption("DBNAME"),sizeof(CfgInfo.DBName)-1);

    strncpy(CfgInfo.szMqServConn  , cCfg.getOption("MQSERVCONN")  , sizeof(CfgInfo.szMqServConn) - 1  );
    strncpy(CfgInfo.szPmInfoHdFlg1, cCfg.getOption("PMINFOHDFLG1"), sizeof(CfgInfo.szPmInfoHdFlg1) - 1);
    strncpy(CfgInfo.szPmInfoHdFlg2, cCfg.getOption("PMINFOHDFLG2"), sizeof(CfgInfo.szPmInfoHdFlg2) - 1);
    strncpy(CfgInfo.szCbspRecvMQ  , cCfg.getOption("CBSPRECVMQ")  , sizeof(CfgInfo.szCbspRecvMQ) - 1  );    
    CfgInfo.iMqListener         = atoi(cCfg.getOption("MQLISTENER"));
    CfgInfo.iConnPlatm          = atoi(cCfg.getOption("ISCONNPLATM"));
    
    //g_iCfcaSign = atoi(cCfg.getOption("CERTSIGN"));     
	
    return OPERACT_SUCCESS;
}


bool IsPkgPack(DBProc &dbProc, int &iListSum)
{
	CBppkgassist1	oCBppkgassist	;
	CBpsapbankinfo	oCBpsapbankinfo ;
	int iRetCode		= RTN_FAIL	;
	int iUpdCode		= RTN_FAIL	;
	string whereClause	= ""		; 
	char	sSqlStr[4000 + 1]  = {0};
	char	sErrDesc[1024 + 1] = {0};
	
	char	sSapBank[14 + 1]   = {0};
	char	sNowDateTime[20 + 1]= {0}; 
	bool	bTimeOut		= false;
	
	
	GetSysParam(dbProc, "01", sSapBank);
	
	//查找定时时间
	oCBpsapbankinfo.setctx(dbProc);
	oCBpsapbankinfo.m_sapbank = sSapBank;
	
	iRetCode = oCBpsapbankinfo.findByPK();
	if (SQLNOTFOUND == iRetCode) 
    {
        sprintf(sErrDesc,"小额清算行信息表无此记录,参数代码[%s], [%d][%s]", 
            oCBpsapbankinfo.m_sapbank.c_str(), iRetCode, oCBpsapbankinfo.GetSqlErr());	

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);		

        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, sErrDesc);
    }
    else if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(sErrDesc,"查询小额清算行信息表记录错误,参数代码[%s], [%d][%s]", 
            oCBpsapbankinfo.m_sapbank.c_str(), iRetCode, oCBpsapbankinfo.GetSqlErr());	

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);		

        PMTS_ThrowException(__FILE__, __LINE__, DB_FIND_BY_PK_FAIL, sErrDesc);
    }
	
	//1.判断是否到定时时间
	if( isRunTime(oCBpsapbankinfo.m_lasttimepack.c_str(), oCBpsapbankinfo.m_exppkgtimes.c_str(), sNowDateTime))
	{
		//更新小额清算行信息表打包时间
		sprintf(sSqlStr,"update bp_sapbankinfo set "
                			" lasttimepack = to_date('%s', 'yyyy-mm-dd hh24:mi:ss')"
                			" where sapbank = '%s' ",
                			sNowDateTime,
                			sSapBank);
		
		//Trace(L_INFO,	__FILE__,  __LINE__, NULL, "sSqlStr=[%s]", sSqlStr);
		
		oCBpsapbankinfo.setctx(dbProc);
		iUpdCode = oCBpsapbankinfo.execsql(sSqlStr);
		if (SQL_SUCCESS != iRetCode) 
	    {
	        sprintf(sErrDesc,"更新小额清算行信息表打包时间错,参数代码[%s], [%d]", 
	            oCBpsapbankinfo.m_sapbank.c_str(), iRetCode);	

	        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);		

	        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, sErrDesc);
	    }

		memset(sSqlStr, 0x00, sizeof(sSqlStr));
		sprintf(sSqlStr,"update bp_pkgassist1 set procstate ='02' "
                			" where procstate in ('00', '01') and listcount > 0 ");

		bTimeOut = true;
		
	}	
	//2. 有手动打包或达量打包
	else	
	{
		sprintf(sSqlStr,"update bp_pkgassist1 set procstate ='02' "
            			" where procstate = '01' and listcount > 0");

		bTimeOut = false;
	}

	//Trace(L_INFO,	__FILE__,  __LINE__, NULL, "sSqlStr=[%s]", sSqlStr);
	
	//更新处理状态
	oCBppkgassist.setctx(dbProc);
	iRetCode = oCBppkgassist.execsql(sSqlStr);
	if(SQLNOTFOUND == iRetCode)
	{
		oCBppkgassist.commit();
		return false;
	}
	else if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(sErrDesc, "oCBppkgassist1.findcount:查询打包辅助表记录错, [%d][%s]",
			iRetCode, oCBppkgassist.GetSqlErr());	
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);		

        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, sErrDesc);
    }

	//事物提交
	oCBppkgassist.commit();
	
	whereClause = "procstate ='02' ";
	iRetCode = oCBppkgassist.findcount(whereClause);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(sErrDesc, "oCBppkgassist.findcount:查询打包辅助表记录错, [%d][%s]",
			iRetCode, oCBppkgassist.GetSqlErr());	
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);		

        PMTS_ThrowException(__FILE__, __LINE__, DB_FIND_BY_PK_FAIL, sErrDesc);
    }
	
	iListSum = oCBppkgassist.m_iCount;

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "%s笔数, iListSum = [%d]", 
					bTimeOut?"定时打包":"达量或手动", iListSum);
	return true;
}


void getPkgPackInfo(DBProc &dbProc, vector<stPkgTab> &array, int iCount)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering getPkgPackInfo()");	
	
	CBppkgassist1 oCBppkgassist		;
	int iRetCode		= RTN_FAIL	;
	int iUpdCode		= RTN_FAIL	;
	int iIstCode		= RTN_FAIL	;
	string whereClause	= ""		; 
	stPkgTab    tmpPkgTab			;
	char	sErrDesc[1024 + 1] = {0};
	char	sSqlStr[4000 + 1]  = {0};
	char	sWorkDate[8 + 1]   = {0};
	char	sMsgId[35 + 1]	   = {0};

	//动态分配容器大小,清空容器
	array.resize(iCount);
	array.clear();
	
	whereClause = "procstate ='02' ";
	
	//查找出辅助表待打包记录并新增包记录
    iRetCode = oCBppkgassist.setctx(dbProc); 
    if(0 != iRetCode)                                                  
    {                                                                         
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "set connect failed!");     
        PMTS_ThrowException(DB_CNNCT_FAIL);                                   
    }
    
	iRetCode = oCBppkgassist.find(whereClause);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(sErrDesc, "oCBppkgassist.find:查询打包辅助表记录错, [%d][%s]",
			iRetCode, oCBppkgassist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);

        PMTS_ThrowException(__FILE__, __LINE__, DB_FIND_BY_PK_FAIL, sErrDesc);
    }

	while(SQL_SUCCESS == iRetCode)
	{
		memset(&tmpPkgTab, 0x00, sizeof(tmpPkgTab));
		
		iRetCode = oCBppkgassist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
			break;
		else if (SQL_SUCCESS != iRetCode) 
		{
			oCBppkgassist.closeCursor();
			
			sprintf(sErrDesc, "oCBppkgassist.fetch:查询打包辅助表记录错, [%d][%s]",
				iRetCode, oCBppkgassist.GetSqlErr()); 
			
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, sErrDesc);
	
			PMTS_ThrowException(__FILE__, __LINE__, DB_FIND_BY_PK_FAIL, sErrDesc);
		}

		strncpy(tmpPkgTab.szWrkDate      , oCBppkgassist.m_wrkdate     .c_str(), sizeof(tmpPkgTab.szWrkDate      ) - 1);
		strncpy(tmpPkgTab.szSendBank     , oCBppkgassist.m_sendbank    .c_str(), sizeof(tmpPkgTab.szSendBank     ) - 1);
		strncpy(tmpPkgTab.szRecvBank     , oCBppkgassist.m_recvbank    .c_str(), sizeof(tmpPkgTab.szRecvBank     ) - 1);
		strncpy(tmpPkgTab.szMsgType      , oCBppkgassist.m_msgtype     .c_str(), sizeof(tmpPkgTab.szMsgType      ) - 1);
		strncpy(tmpPkgTab.szMsgID        , oCBppkgassist.m_msgid       .c_str(), sizeof(tmpPkgTab.szMsgID        ) - 1);
		tmpPkgTab.iListCount    = oCBppkgassist.m_listcount;
		strncpy(tmpPkgTab.szHandPackFlag , oCBppkgassist.m_handpackflag.c_str(), sizeof(tmpPkgTab.szHandPackFlag ) - 1);

		strncpy(tmpPkgTab.szIsRspn       , oCBppkgassist.m_isrspn.c_str()      , sizeof(tmpPkgTab.szIsRspn       ) - 1);
		strncpy(tmpPkgTab.szIsAllRspn    , oCBppkgassist.m_isallrspn.c_str()   , sizeof(tmpPkgTab.szIsAllRspn    ) - 1);
		tmpPkgTab.iPKGRtrltd = oCBppkgassist.m_pkgrtrltd;
		strncpy(tmpPkgTab.szPmttpPrtry   , oCBppkgassist.m_pmttpprtry.c_str()  , sizeof(tmpPkgTab.szPmttpPrtry   ) - 1);
		strncpy(tmpPkgTab.szIssr         , oCBppkgassist.m_issr.c_str()        , sizeof(tmpPkgTab.szIssr         ) - 1);
		strncpy(tmpPkgTab.szAcctId       , oCBppkgassist.m_acctid.c_str()      , sizeof(tmpPkgTab.szAcctId       ) - 1);
		strncpy(tmpPkgTab.szOriMsgTp     , oCBppkgassist.m_orimsgtp.c_str()    , sizeof(tmpPkgTab.szOriMsgTp     ) - 1);
		strncpy(tmpPkgTab.szOriMsgId     , oCBppkgassist.m_orimsgid.c_str()    , sizeof(tmpPkgTab.szOriMsgId     ) - 1);
		
		strncpy(tmpPkgTab.szProstate     , oCBppkgassist.m_procstate   .c_str(), sizeof(tmpPkgTab.szProstate     ) - 1);
	
		array.push_back(tmpPkgTab);	
	}
	
	oCBppkgassist.closeCursor();
    
    //为避免第二次打包再将正在打包的业务再次打包
	sprintf(sSqlStr,"update bp_pkgassist1 set procstate ='03' where procstate = '02'");

	oCBppkgassist.setctx(dbProc);
	iRetCode = oCBppkgassist.execsql(sSqlStr);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(sErrDesc, "oCBppkgassist.findcount:更新打包辅助表处理状态错, [%d][%s]",
			iRetCode, oCBppkgassist.GetSqlErr());	
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);		

        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, sErrDesc);
    }

	//事物提交
	oCBppkgassist.commit();

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit getPkgPackInfo()");	
}


//将比较时间精确到分
bool isRunTime(const char* pDateTime, const char* pTimeOut, char* pNowDateTime)
{
	struct tm	*nowtime;
    time_t		longtime;
	
	char	sDay[2 + 1]		= {0};
	char	sHour[2 + 1]	= {0};
	char	sMin[2 + 1]		= {0};
	char	sSec[2 + 1]		= {0};

	int		iDay			=  0 ;
	int		iHour			=  0 ;
	int		iMin			=  0 ;
	int		iSec			=  0 ;

	int		iTotalMin		=  0 ;
	int		iTotalMin1		=  0 ;

	//日期格式110413143000
	memcpy(sDay , pDateTime + 4 , sizeof(sDay ) - 1);
	memcpy(sHour, pDateTime + 6 , sizeof(sHour) - 1);
	memcpy(sMin , pDateTime + 8 , sizeof(sMin ) - 1);
	memcpy(sSec , pDateTime + 10, sizeof(sSec ) - 1);
	
	iDay		= atoi(sDay );
	iHour		= atoi(sHour);
	iMin		= atoi(sMin );
	iSec		= atoi(sSec );
	
	//获取当前时间
    time(&longtime);
	nowtime		= localtime(&longtime);

	iTotalMin	= iHour*60 + iMin; // + atoi(pTimeOut);
	
	if(iDay == nowtime->tm_mday)//在同一日期内
	{
		iTotalMin1	= nowtime->tm_hour*60 + nowtime->tm_min;
	}
	else//不在同一日期内，最多认为为一天
	{
		iTotalMin1	= 24*60 + nowtime->tm_hour*60 + nowtime->tm_min;
	}
		
	if(iTotalMin > iTotalMin1)
	{
		return false;
	}
	else
	{
		sprintf(pNowDateTime, "%04d-%02d-%02d %02d:%02d:%02d", 
													nowtime->tm_year+1900,
													nowtime->tm_mon+1,
													nowtime->tm_mday, 
													nowtime->tm_hour,
													nowtime->tm_min,
													nowtime->tm_sec);
		return true;
	}
}


