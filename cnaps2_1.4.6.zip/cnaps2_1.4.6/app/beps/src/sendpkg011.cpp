/******************************************************************** 
�ļ����� sendpkg011.cpp
�����ˣ� hq
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ���� PKG011���ڽ�ǻ�ִ �����˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendpkg011.h"

using namespace ZFPT;

CSendPkg011::CSendPkg011(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
     memset(m_sPkgNo, 0x00, sizeof(m_sPkgNo));
}

CSendPkg011::~CSendPkg011()
{

}

INT32 CSendPkg011::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg011::doWorkSelf");
    
    // ��ҵ����л�ȡ����
    GetData();
    
    //ҵ����
    //CheckValues();

    //����
    ChargeMb();

    //FundSettle();
    
    // �鱨�ı�����
    CreateNpcMsg();
    
    //����������
    UpdatePkg();
    
    //�޸�״̬/NPCMSG
    UpdateSndList(PR_HVBP_95);


    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg011::doWorkSelf"); 
    return 0;
}

INT32 CSendPkg011::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg011::GetData");

    SETCTX(m_cBpbcsndlist);

    m_cBpbcsndlist.m_dbtrbrnchid = m_sSendOrg;
    m_cBpbcsndlist.m_txid        = m_sMsgId;

    iRet = m_cBpbcsndlist.findByPK();
    if (SQLNOTFOUND == iRet)
    {
        sprintf(m_sErrMsg, "С�����ʴ�����ϸ�����Ҳ���ָ��ҵ��[%s][%s]", 
            m_sSendOrg, m_sMsgId);

        Trace(L_INFO,  __FILE__,  __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    } 	
    else if (SQL_SUCCESS != iRet) 
    {
        sprintf(m_sErrMsg,"��ѯС�����ʴ�����ϸ����������[%d][%s]",
            iRet, m_cBpbcsndlist.GetSqlErr());

        Trace(L_INFO,  __FILE__,  __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CSendPkg011::GetData"); 

    return iRet;
}

INT32 CSendPkg011::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg011::CheckValues");

    int iRet = -1;
    
    //������޼��
    iRet = isOutOfLimit(m_dbproc, 
                        m_cBpbcsndlist.m_msgtp.c_str(), 
                        m_cBpbcsndlist.m_purpprtry.c_str(),
                        m_cBpbcsndlist.m_amount, 
                        m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_AMT_OUT_OF_LIMIT, m_sErrMsg);
    }
    
    //�����кż��
    iRet = isBankRight(m_dbproc, m_cBpbcsndlist.m_instddrctpty.c_str(), m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_RECVBANK_CHECK_FAIL, m_sErrMsg);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg011::CheckValues"); 
    return 0;
}

INT32 CSendPkg011::ChargeMb()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg011::ChargeMb");
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg011::ChargeMb"); 
    return 0;
}


INT32 CSendPkg011::CreateNpcMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg011::CreateNpcMsg");

    string              strTemp = "";
    pkg008				oPkg008;
	char				sSqlStr[4000 + 1]  = {0};
	string				strWhereClause	= "";
	int					iRet		    = RTN_FAIL;
	char				sTemp[32 + 1]   = {0};
	int 				iCount				;
	int 				iNbOfTxs		= 0;
	double				dCtrlSum		= 0.00;
	int 				iSuccNbOfTxs    = 0;
	double				dSuccCtrlSum	= 0.00;
    
    // Ʊ����ִҵ��Ҫ�ؼ�007
    if ( "30104" == m_cBpbcsndlist.m_pmttpprtry || "30105" == m_cBpbcsndlist.m_pmttpprtry )
    {
        oPkg008.m_szCurElementNo              = "007";
        
        strncpy(oPkg008.stBody007.szTrxsType, m_cBpbcsndlist.m_pmttpprtry.c_str(), sizeof(oPkg008.stBody007.szTrxsType) - 1);//ҵ�����ͱ��� 
        
        memset(sTemp, 0x00, sizeof(sTemp));
        strncpy(sTemp, m_cBpbcsndlist.m_txid.c_str(), 8);
        strncpy(oPkg008.stBody007.szConsignDate, sTemp, sizeof(oPkg008.stBody007.szConsignDate) - 1);//ί������        
        
        GetTagVal(strTemp, m_cBpbcsndlist.m_cstmrcdttrfaddtlinf, ":051:");
        strncpy(oPkg008.stBody007.szOriCISConsignDate, strTemp.c_str(), sizeof(oPkg008.stBody007.szOriCISConsignDate) - 1);//ԭƱ��ί������                    
        
        memset(sTemp, 0x00, sizeof(sTemp));
        strncpy(sTemp, m_cBpbcsndlist.m_txid.c_str() + 8, 8);
        strncpy(oPkg008.stBody007.szTxssNo, sTemp, sizeof(oPkg008.stBody007.szTxssNo) - 1);//�������                      
        
        GetTagVal(strTemp, m_cBpbcsndlist.m_cstmrcdttrfaddtlinf, ":005:");
        strncpy(oPkg008.stBody007.szOrigCISTxssNo, strTemp.c_str(), sizeof(oPkg008.stBody007.szOrigCISTxssNo) - 1);//ԭƱ���������                 
        
        GetTagVal(strTemp, m_cBpbcsndlist.m_cstmrcdttrfaddtlinf, ":CSH:");
        strncpy(oPkg008.stBody007.szChequeNo, strTemp.c_str(), sizeof(oPkg008.stBody007.szChequeNo) - 1);//֧Ʊ����                      
        
        strncpy(oPkg008.stBody007.szPayOpenAccBkCode, m_cBpbcsndlist.m_dbtrissr.c_str(), sizeof(oPkg008.stBody007.szPayOpenAccBkCode) - 1);//�����˿������к�
        strncpy(oPkg008.stBody007.szPayerAcc, m_cBpbcsndlist.m_dbtracctid.c_str(), sizeof(oPkg008.stBody007.szPayerAcc) - 1);//�������˺�      
        strncpy(oPkg008.stBody007.szPayerName, m_cBpbcsndlist.m_dbtnm.c_str(), sizeof(oPkg008.stBody007.szPayerName) - 1);//����������  
        strncpy(oPkg008.stBody007.szRecOpenAccBkCode, m_cBpbcsndlist.m_cdtrissr.c_str(), sizeof(oPkg008.stBody007.szRecOpenAccBkCode) - 1);//�տ��˿������к�  
        strncpy(oPkg008.stBody007.szRecipientAcc, m_cBpbcsndlist.m_cdtracctid.c_str(), sizeof(oPkg008.stBody007.szRecipientAcc) - 1);//�տ����˺�     
        strncpy(oPkg008.stBody007.szRecipientName, m_cBpbcsndlist.m_cdtrnm.c_str(), sizeof(oPkg008.stBody007.szRecipientName) - 1);//�տ�������
        strncpy(oPkg008.stBody007.szOdfiCode, m_cBpbcsndlist.m_instgdrctpty.c_str(), sizeof(oPkg008.stBody007.szOdfiCode) - 1);//�������к�
        strncpy(oPkg008.stBody007.szRdfiCode, m_cBpbcsndlist.m_instddrctpty.c_str(), sizeof(oPkg008.stBody007.szRdfiCode) - 1);//�������к�
        
        memset(sTemp, '\0', sizeof(sTemp));
        sprintf(sTemp,"%015.f", m_cBpbcsndlist.m_amount*100);
        strncpy(oPkg008.stBody007.szAmount, sTemp, sizeof(oPkg008.stBody007.szAmount) - 1);//���                      
        
        //GetTagVal(strTemp, m_cBpbcsndlist.m_busistate, ":CIA:");
        strncpy(oPkg008.stBody007.szReturnReceiptStatus, m_cBpbcsndlist.m_busistate.c_str(), sizeof(oPkg008.stBody007.szReturnReceiptStatus) - 1);//ҵ���ִ״̬                 
        
        //Trace(L_INFO,  __FILE__,  __LINE__,NULL, "strTemp:CIA:=[%s]",strTemp.c_str());	
        
        GetTagVal(strTemp, m_cBpbcsndlist.m_cstmrcdttrfaddtlinf, ":CCA:");
        strncpy(oPkg008.stBody007.szReturnCode, strTemp.c_str(), sizeof(oPkg008.stBody007.szReturnCode) - 1);//��Ʊ����                    
        
        GetTagVal(strTemp, m_cBpbcsndlist.m_cstmrcdttrfaddtlinf, ":72A:");
        strncpy(oPkg008.stBody007.szPost, strTemp.c_str(), sizeof(oPkg008.stBody007.szPost) - 1);//��Ʊ����˵��                     
        
        oPkg008.AddBussiness("007");
    }
    // ͨ�û�ִҵ��Ҫ�ؼ�006
    else
    {
        oPkg008.m_szCurElementNo                 = "006";
        
        memset(sTemp, 0x00, sizeof(sTemp));
        strncpy(sTemp, m_cBpbcsndlist.m_txid.c_str(), 8);
        strncpy(oPkg008.stBody006.szConsignDate, m_cBpbcsndlist.m_txid.c_str(), sizeof(oPkg008.stBody006.szConsignDate) - 1);//ί������
        
        memset(sTemp, 0x00, sizeof(sTemp));
        strncpy(sTemp, m_cBpbcsndlist.m_txid.c_str() + 8, 8);
        strncpy(oPkg008.stBody006.szTxssNo, sTemp, sizeof(oPkg008.stBody007.szTxssNo) - 1);//�������                      
        
        strncpy(oPkg008.stBody006.szOriTrxsType, m_cBpbcsndlist.m_pmttpprtry.c_str(), sizeof(oPkg008.stBody006.szOriTrxsType) - 1);//ԭҵ�����ͱ���
        strncpy(oPkg008.stBody006.szOriOdfiCode, m_cBpbcsndlist.m_cdtrbrnchid.c_str(), sizeof(oPkg008.stBody006.szOriOdfiCode) - 1);//ԭ�������к�=������
        strncpy(oPkg008.stBody006.szOriRdfiCode, m_cBpbcsndlist.m_dbtrbrnchid.c_str(), sizeof(oPkg008.stBody006.szOriRdfiCode) - 1);//ԭ�������к�=������
        
        memset(sTemp, 0x00, sizeof(sTemp));
        strncpy(sTemp, m_cBpbcsndlist.m_oritxid.c_str(), 8);
        strncpy(oPkg008.stBody006.szOriConsignDate, sTemp, sizeof(oPkg008.stBody006.szOriConsignDate) - 1);//ԭί������                       
        
        memset(sTemp, 0x00, sizeof(sTemp));
        strncpy(sTemp, m_cBpbcsndlist.m_oritxid.c_str() + 8, 8);
        strncpy(oPkg008.stBody006.szOriTxssNo, sTemp, sizeof(oPkg008.stBody006.szOriTxssNo) - 1);//ԭ�������                     
        
        memset(sTemp, '\0', sizeof(sTemp));
        sprintf(sTemp,"%015.f", m_cBpbcsndlist.m_oriamount*100);
        strncpy(oPkg008.stBody006.szOriAmount, sTemp, sizeof(oPkg008.stBody006.szOriAmount) - 1);//ԭ���                  
        
        //GetTagVal(strTemp, m_cBpbcsndlist.m_busistate, ":CIA:");
        strncpy(oPkg008.stBody006.szReturnReceiptStatus, m_cBpbcsndlist.m_busistate.c_str(), sizeof(oPkg008.stBody006.szReturnReceiptStatus) - 1);//ҵ���ִ״̬                    
        
        //Trace(L_INFO,  __FILE__,  __LINE__,NULL, "strTemp:CIA:=[%s]",strTemp.c_str());		
        
        GetTagVal(strTemp, m_cBpbcsndlist.m_cstmrcdttrfaddtlinf, ":BSE:");
        strncpy(oPkg008.stBody006.szDebitDate, strTemp.c_str(), sizeof(oPkg008.stBody006.szDebitDate) - 1);//�ۿ�����                     
        
        GetTagVal(strTemp, m_cBpbcsndlist.m_cstmrcdttrfaddtlinf, ":BSN:");
        strncpy(oPkg008.stBody006.szHandingChange, strTemp.c_str(), sizeof(oPkg008.stBody006.szHandingChange) - 1);//������������                     
        
        strncpy(oPkg008.stBody006.szPost, m_cBpbcsndlist.m_addtlinf.c_str(), sizeof(oPkg008.stBody006.szPost) - 1);//����                   
        
        oPkg008.AddBussiness("006");
    }
    
    m_sMsgTxt = oPkg008.m_szPkgBody;
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, " m_sMsgTxt = [%s]", m_sMsgTxt.c_str());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg011::CreateNpcMsg"); 

    return 0;
}


INT32 CSendPkg011::UpdatePkg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg011::UpdatePkg");

    strncpy(m_strAssist.sSendBank,   m_cBpbcsndlist.m_instgdrctpty.c_str(), sizeof(m_strAssist.sSendBank)   - 1);
    strncpy(m_strAssist.sRecvBank,   m_cBpbcsndlist.m_instddrctpty.c_str(), sizeof(m_strAssist.sRecvBank)   - 1);
    strncpy(m_strAssist.sMsgType,    m_cBpbcsndlist.m_msgtp.c_str(),        sizeof(m_strAssist.sMsgType)    - 1);
    strncpy(m_strAssist.sPmttpPrtry, m_cBpbcsndlist.m_pmttpprtry.c_str(),   sizeof(m_strAssist.sPmttpPrtry) - 1);
    strncpy(m_strAssist.sIssr,       m_cBpbcsndlist.m_dbtrissr.c_str(),     sizeof(m_strAssist.sIssr)       - 1);
    strncpy(m_strAssist.sAcctId,     m_cBpbcsndlist.m_dbtracctid.c_str(),   sizeof(m_strAssist.sAcctId)     - 1);
    
    m_strAssist.iPkgRtrltd = 0;
    strncpy(m_strAssist.sOriMsgTp,   "0", sizeof(m_strAssist.sOriMsgTp) - 1);
    strncpy(m_strAssist.sOriMsgId,   "0", sizeof(m_strAssist.sOriMsgId) - 1);
    
    iRet = UpPKGAssist1(m_sPkgNo);
    if (iRet != SQL_SUCCESS)
    {
        memcpy(m_sPkgNo, m_cBpbcsndlist.m_msgid.c_str(), sizeof(m_sPkgNo) - 1);
        sprintf(m_sErrMsg,  "UpPKGAssist1 is error,iRet=[%d][%s]", iRet, m_sPkgNo);
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg011::UpdatePkg");
    return 0;
}

INT32 CSendPkg011::UpdateSndList(LPCSTR sProcstate)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg011::UpdateSndList");

    memset(m_sSqlStr, 0x00, sizeof(m_sSqlStr));
    sprintf(m_sSqlStr, "UPDATE bp_bcoutsendlist t SET t.STATETIME = sysdate,"
                            "t.MSGID  = '%s', "
                			"t.NPCMSG = '%s', "
                			"t.PROCSTATE = '%s'"
                			" WHERE t.txid = '%s'",
                			m_sPkgNo,
                			m_sMsgTxt.c_str(),
                			sProcstate,
                			m_sMsgId);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sSqlStr=[%s]",m_sSqlStr);

    iRet = m_cBpbcsndlist.execsql(m_sSqlStr);
    if (iRet != SQL_SUCCESS)
    {
        sprintf(m_sErrMsg,  "update bp_bcoutsendlist  is error[%d][%s]", 
            iRet, m_cBpbcsndlist.GetSqlErr());
            
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        if ( 0 == strcmp(sProcstate, PR_HVBP_95))
        {
            //��������ʱ�����쳣,������쳣������״̬,���ﲻ���쳣
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
        }
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg011::UpdateSndList");
    return 0;
}



INT32 CSendPkg011::SetErrACK(int iErrCode, LPCSTR pErrDesc)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg011::SetErrACK");
    
	//�޸�״̬Ϊ"���޸�"
    UpdateSndList(PR_HVBP_93);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg011::SetErrACK");
	return 0;
}

int CSendPkg011::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendPkg011::FundSettle...");
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û�[%s]", m_szOprUser);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_sSendOrg);

	m_charge.m_amount = m_cBpbcsndlist.m_amount*100;	//ҵ����
	m_charge.m_iDCFlag = iDEBITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, MBVIRSUALNETID);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_sSendOrg);	//������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(RTN_SUCCESS != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FundSettle iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendPkg011::FundSettle..."); 
    
    return RTN_SUCCESS;
}


