/******************************************************************** 
�ļ����� sendbeps416.cpp
�����ˣ� zys
��  �ڣ� 2011-04-26
�޸��ˣ� 
��  �ڣ� 
��  ���� С��ʵʱ��Ϣ�����������뱨��beps.416������
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps416.h"

using namespace ZFPT;

CSendBeps416::CSendBeps416(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
    bCheck  = false;
}

CSendBeps416::~CSendBeps416()
{

}

INT32 CSendBeps416::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps416::doWorkSelf");

    //��ҵ����л�ȡ����
    getData();

    //ҵ����:������
    CheckValues();

    //�����ʧ��ʱ������Ҫ��֧��ϵͳ����
    if (!bCheck)
    {
        //��pmts����
        buildPmtsMsg();
        
        //����Զ�̶���
        AddQueue();
    }

    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps416::doWorkSelf"); 
    return 0;
}

int CSendBeps416::getData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps416::getData");
    
    SETCTX(m_cBpcstinfcxl);
    
    m_cBpcstinfcxl.m_instgdrctpty = m_sSendOrg;
    m_cBpcstinfcxl.m_msgid        = m_sMsgId;
    
    iRet = m_cBpcstinfcxl.findByPK();
    
    if (SQLNOTFOUND == iRet)
    {
        sprintf(m_sErrMsg, "ʵʱ��Ϣ���������Ҳ���ָ��ҵ��[%s], [%s], [%d][%s]", 
        m_sSendOrg, m_sMsgId, iRet, m_cBpcstinfcxl.GetSqlErr());
        
        Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);
    
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    }
    else if (SQL_SUCCESS != iRet) 
    {
        sprintf(m_sErrMsg, "��ѯʵʱ��Ϣ��������������[%s], [%s], [%d][%s]",
        m_sSendOrg, m_sMsgId, iRet, m_cBpcstinfcxl.GetSqlErr());
        
        Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);
        
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps416::getData"); 
    
    return iRet;
}


int CSendBeps416::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps416::CheckValues");

    //���ԭ���ҵ���Ƿ��Ѹ�����Ѹ������Ҫ����ֹ�����뽻��
	/*if (0 != m_cBpbdsndcl.setctx(m_dbproc))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, OTHER_ERR, "setctx error");
    }

    m_cBpbdsndcl.m_msgid        = m_cBpcstbdpcxlcl.m_orgnlmsgid;
    m_cBpbdsndcl.m_instgdrctpty = m_cBpcstbdpcxlcl.m_orgnlinstgpty;

    iRet = m_cBpbdsndcl.findByPK();
    if (SQL_SUCCESS != iRet)
    {
		sprintf(m_sErrMsg, "��ѯ������˻��ܱ���������[%s], [%s], [%d][%s]",
		    m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(), 
		    m_cBpcstbdpcxlcl.m_orgnlinstgpty.c_str(), 
		    iRet, m_cBpcstbdpcxllist.GetSqlErr());

		Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, MB_PFR0018, m_sErrMsg);         
    }
    else if (SQLNOTFOUND == iRet)
    {
		sprintf(m_sErrMsg, "��ѯ������˻��ܱ��޼�¼[%s], [%s], [%d][%s]",
		    m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(), 
		    m_cBpcstbdpcxlcl.m_orgnlinstgpty.c_str(), 
		    iRet, m_cBpcstbdpcxllist.GetSqlErr());

		Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, MB_OTR0103, m_sErrMsg);        
    }

    if (m_cBpbdsndcl.m_busistate == "PR02")
    {
        bCheck = true;

		sprintf(m_sErrMsg, "��ѯ�ñʽ�ǰ��Ѹ���, �޷�ֹ��[%s], [%s], [%s]",
		    m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(), 
		    m_cBpcstbdpcxlcl.m_orgnlinstgpty.c_str(), 
		    m_cBpbdsndcl.m_busistate.c_str());

		Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);

		return 0;
    }*/
    
    
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps416::CheckValues");
    return 0;
}

int CSendBeps416::buildPmtsMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps416::buildPmtsMsg");
    
    char sTemp[128]  = {0};
    string strTemp;
    
    SETCTX(m_cBpcstinfcxl);
    
    //��ֵ
	bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(PRM_FAIL);
    }

    //����ͷҪ������
    m_cBeps416.m_PMTSHeader.SetPMTSXMlHeader("BEPS", 
                                             m_cBpcstinfcxl.m_workdate.c_str(),
                                             m_cBpcstinfcxl.m_instgdrctpty.c_str(),
                                             m_cBpcstinfcxl.m_instddrctpty.c_str(),
                                             "beps.416.001.01",
                                             m_sMsgRefId);    

    //m_cBeps416��ֵ
    m_cBeps416.AssgnmtId      = m_cBpcstinfcxl.m_mesgid;           //���ı�ʶ��
    m_cBeps416.AssgnrMmbId    = m_cBpcstinfcxl.m_instgdrctpty;     //����ֱ�Ӳ������
    m_cBeps416.AssgneMmbId    = m_cBpcstinfcxl.m_instddrctpty;     //����ֱ�Ӳ������
    m_cBeps416.CreDtTm        = m_sIsoWorkDate;                    //���ķ���ʱ��
    m_cBeps416.CaseId         = "1";                               //�̶���
    m_cBeps416.CretrMmbId     = m_cBpcstinfcxl.m_oriinstgdrctpty;  //ԭ����ֱ�Ӳ������
    m_cBeps416.OrgnlMsgId     = m_cBpcstinfcxl.m_orimsgid;         //ԭ���ı�ʶ��
    m_cBeps416.OrgnlMsgNmId   = m_cBpcstinfcxl.m_orimsgtp;         //ԭ�������ͺ�
    m_cBeps416.AddtlInf       = m_cBpcstinfcxl.m_addtlinf;         //����


    //��ǩ
    AddSign416();

    //��������
    iRet = m_cBeps416.CreateXml();
    if (0 != iRet)
    {
        sprintf(m_sErrMsg, "Create beps.416.001.01 XML is Error!iRet[%d]", iRet);
        
        Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);
        
        PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, m_sErrMsg); 
    }
    
    m_sMsgTxt = m_cBeps416.m_sXMLBuff;
    
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps416::buildPmtsMsg");
    return 0;   
}

void CSendBeps416::AddSign416()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms416::AddSign416");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_cBeps416.getOriSignStr();
	
	AddSign(m_cBeps416.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_cBpcstinfcxl.m_instgdrctpty.c_str());
	
	m_cBeps416.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms416::AddSign416");
}


