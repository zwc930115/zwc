/******************************************************************** 
�ļ����� sendbeps127.cpp
�����ˣ� zwy
��  ��   �� 2011-03-07
�޸��ˣ� 
��  �ڣ� 
��  ���� С������beps.127���Ĵ�����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps127.h"

#include "md5.hpp"

CSendBeps127::CSendBeps127(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
}

CSendBeps127::~CSendBeps127()
{
}

INT32 CSendBeps127::ChargeMb()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps127::ChargeMb");
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps127::ChargeMb"); 
    return 0;
}

INT32 CSendBeps127::UpdatePkg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps127::UpdatePkg");

    strncpy(m_strAssist.sSendBank,   m_cBpbdsendlist.m_instgdrctpty.c_str(), sizeof(m_strAssist.sSendBank) - 1);
    strncpy(m_strAssist.sRecvBank,   m_cBpbdsendlist.m_instddrctpty.c_str(), sizeof(m_strAssist.sRecvBank) - 1);
    strncpy(m_strAssist.sMsgType,    m_cBpbdsendlist.m_msgtp.c_str(),        sizeof(m_strAssist.sMsgType)  - 1);
    m_strAssist.iPkgRtrltd = m_cBpbdsendlist.m_pkgrtrltd;
    
    strncpy(m_strAssist.sOriMsgTp,   "0",   sizeof(m_strAssist.sOriMsgTp) - 1);
    strncpy(m_strAssist.sOriMsgId,   "0",   sizeof(m_strAssist.sOriMsgId) - 1);
    strncpy(m_strAssist.sPmttpPrtry, "0",   sizeof(m_strAssist.sPmttpPrtry) - 1);
    strncpy(m_strAssist.sIssr,       "0",   sizeof(m_strAssist.sIssr)       - 1);
    strncpy(m_strAssist.sAcctId,     "0",   sizeof(m_strAssist.sAcctId)     - 1);
    
    iRet = UpPKGAssist(m_sPkgNo);
    if (iRet != SQL_SUCCESS)
    {
        memcpy(m_sPkgNo, m_cBpbdsendlist.m_msgid.c_str(), sizeof(m_sPkgNo) - 1);
        sprintf(m_sErrMsg,  "UpPKGAssist is error,iRet=[%d][%s]", iRet, m_sPkgNo);
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps127::UpdatePkg");
    return 0;
}

INT32 CSendBeps127::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps127::doWorkSelf");
    
    /*��ҵ����л�ȡ����*/
    getData();
    
    //__wsh 2012-05-12 B310 B311��B309����������ṹ��ͬ���ʷ���һ��ʵʱ����
    if( NULL != strstr(m_BusinessType, "B308") || 
        NULL != strstr(m_BusinessType, "B309") ||
        NULL != strstr(m_BusinessType, "B310") ||
        NULL != strstr(m_BusinessType, "B311"))
    {
        /*��pmts����*/
        CreatPmtsMsg();

        /*����һ������*/
        insertSum();

        /*����Զ�̶���*/
        AddQueue();

        /*�޸���ϸҵ��İ����*/
        updatePkgId();

        /*�޸�״̬*/
        updateState();
    }
    else
    {
        //����������
        UpdatePkg();

        /*�޸���ϸ��:��ʾ���������޸İ����;������һ������ʱ,�޸�NPC����*/
        UpdateSendList(PR_HVBP_03);
    }

    
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps127::doWorkSelf"); 
    return 0;
}

int CSendBeps127::getData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps127::getData");
    
	SETCTX(m_cBpbdsendlist);
    
  	m_cBpbdsendlist.m_cdtrbrnchid = m_sSendOrg;
  	m_cBpbdsendlist.m_txid = m_sMsgId;
  	
  	iRet = m_cBpbdsendlist.findByPK();
  	
  	if (SQLNOTFOUND == iRet)
	{
		sprintf(m_sErrMsg,"С�����ʴ�����ϸ�����Ҳ���ָ��ҵ��[%s],[%s],[%s]", 
		    m_sSendOrg, m_sMsgId, m_cBpbdsendlist.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	} 	
	else if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg,"��ѯС�����ʴ�����ϸ����������[%s]",
		    m_cBpbdsendlist.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps127::getData"); 
    
	return iRet;
}

int CSendBeps127::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps127::CheckValues");

    int iRet = -1;

    //������޼��
    iRet = isOutOfLimit(m_dbproc, 
                        m_cBpbdsendlist.m_msgtp.c_str(), 
                        m_cBpbdsendlist.m_purpprtry.c_str(),
                        m_cBpbdsendlist.m_amount, 
                        m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException( OPT_AMT_OUT_OF_LIMIT);
    }
    
    //�����кż��
    iRet = isBankRight(m_dbproc, m_cBpbdsendlist.m_instddrctpty.c_str(), m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(OPT_RECVBANK_CHECK_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps127::CheckValues");
    return 0;
}

int CSendBeps127::UpdateSendList(LPCSTR sProcstate)
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps127::UpdateSendList");

    //�������°����
    sprintf(m_sSqlStr, "UPDATE bp_bdsendlist t SET t.STATETIME = sysdate,"
            			"t.MSGID = '%s', t.PROCSTATE = '%s'"   /*�����*/
            			" WHERE t.txid = '%s'",
            			m_sPkgNo,
            			sProcstate,
            			m_sMsgId);

    iRet = m_cBpbdsendlist.execsql(m_sSqlStr);
    if (iRet != SQL_SUCCESS)
    {
        sprintf(m_sErrMsg,  "update bp_bdsendlist  failed![%d] [%s]", iRet,m_cBpbdsendlist.GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId, m_sErrMsg);
        PMTS_ThrowException(DB_OPT_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps127::UpdateSendList");
    return 0;
}

INT32 CSendBeps127::SetErrACK(int iErrCode, LPCSTR pErrDesc)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps127::SetErrACK");

	//�޸�״̬Ϊ"���޸�"
    UpdateSendList(PR_HVBP_93);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps127::SetErrACK");
	return 0;
}

int CSendBeps127::insertSum()
{
	Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps127::insertSum");
    
    SETCTX(m_cBpbdsndcl);
	
	m_cBpbdsndcl.m_workdate = m_sWorkDate;
	m_cBpbdsndcl.m_consigdate = m_sWorkDate;
  	m_cBpbdsndcl.m_msgtp = m_cBpbdsendlist.m_msgtp;
    m_cBpbdsndcl.m_mesgid = m_sMsgRefId;
    m_cBpbdsndcl.m_mesgrefid = m_sMsgRefId;
  	m_cBpbdsndcl.m_msgid = m_sPkgDtNSn;
  	m_cBpbdsndcl.m_instgdrctpty = m_cBpbdsendlist.m_instgdrctpty;
  	m_cBpbdsndcl.m_instddrctpty = m_cBpbdsendlist.m_instddrctpty;
  	m_cBpbdsndcl.m_srcflag = "0";
  	m_cBpbdsndcl.m_procstate = "95";
    m_cBpbdsndcl.m_checkstate = "1";
  	m_cBpbdsndcl.m_nboftxs = 1;
  	m_cBpbdsndcl.m_ctrlsum = m_cBpbdsendlist.m_amount;
  	m_cBpbdsndcl.m_sapsnboftxs = 1;
  	m_cBpbdsndcl.m_ctrlsapssum = m_cBpbdsendlist.m_amount;
  	m_cBpbdsndcl.m_realtimeflag = "1";
  	m_cBpbdsndcl.m_dgtsign = "DIGITSIGN";
  	m_cBpbdsndcl.m_npcmsg  = m_sMsgTxt;
  	
  	iRet = m_cBpbdsndcl.insert();
  	
  	if (DUPLICATE_KEY == iRet) 
	{
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "���������Ѵ���");
		
	}
	else if(SQL_SUCCESS != iRet)
	{
		sprintf(m_sErrMsg,"�������˻��ܱ���������ʧ��[%s]",m_cBpbdsndcl.GetSqlErr());
		
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_sErrMsg);
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps127::insertSum"); 
    
	return iRet;
}

int CSendBeps127::updatePkgId()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps127::updatePkgId");

    memset(m_sSqlStr, 0, sizeof(m_sSqlStr));

	sprintf(m_sSqlStr, "UPDATE bp_bdsendlist t SET t.STATETIME = sysdate,"
						"t.MSGID = '%s'"   /*�����*/
						" WHERE t.txid = '%s'",
						m_sPkgDtNSn,
						m_sMsgId);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sSqlStr = [%s]",m_sSqlStr);
    iRet = m_cBpbdsendlist.execsql(m_sSqlStr);
    if (iRet == SQLNOTFOUND)
    {
    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��bp_bdsendlist����û���ҵ�����[txid=%s]",m_sMsgId);
    }
    else if (iRet != SQL_SUCCESS)
    {
    	sprintf(m_sErrMsg,  "update bp_bdsendlist  failed![%d][%s]", iRet,m_cBpbdsendlist.GetSqlErr());
    	Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
    	PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps127::updatePkgId");
    return 0;
}

int CSendBeps127::CreatPmtsMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps127::CreatPmtsMsg");
    
    //ȡ����� = ���ı�ʶ��
	bool bRet = GetMsgIdValue(m_dbproc, m_sPkgDtNSn, eMsgId, SYS_BEPS, m_cBpbdsendlist.m_instgdrctpty.c_str());
	if ( !bRet )
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "GetMsgIdValue failed!");
		PMTS_ThrowException( OPT_GET_MSGID_FAIL);
	}
	//ȡ���Ĳο���
	bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS, m_cBpbdsendlist.m_instgdrctpty.c_str());
	if ( !bRet )
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "GetMsgIdValue failed!");
		PMTS_ThrowException(OPT_GET_MSGID_FAIL);
	}

	beps127 oBeps127;
    int iCount = 0;
    string strTemp = "";

    oBeps127.CreateXMlHeader("BEPS", 
					m_sWorkDate,
					m_cBpbdsendlist.m_instgdrctpty.c_str(),
					m_cBpbdsendlist.m_instddrctpty.c_str(),
					"beps.127.001.01",
					m_sMsgRefId);
					  				
	
	char sTemp[32] = {0};
	oBeps127.MsgId                  =	m_sPkgDtNSn;
	oBeps127.CreDtTm                =	m_sIsoWorkDate;
    
    memset(sTemp,'\0',sizeof(sTemp));
    sprintf(sTemp,"%d", m_cBpbdsendlist.m_pkgrtrltd);
	oBeps127.PKGRtrLtd              =   sTemp;
    
	oBeps127.PKGGrpHdrNbOfTxs       =	"1";
	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp,"%.2f", m_cBpbdsendlist.m_amount);
	oBeps127.CtrlSum                = sTemp;	
	oBeps127.CtgyPurpPrtry          = m_cBpbdsendlist.m_pmttpprtry	;//ҵ�����ͱ���
	oBeps127.InstgDrctPty           = m_cBpbdsendlist.m_instgdrctpty;
	oBeps127.InstdDrctPty           = m_cBpbdsendlist.m_instddrctpty;
	oBeps127.CtrlSumCcy             = m_cBpbdsendlist.m_currency;
	oBeps127.SysCd                  = "BEPS";//ע�⣬����û�д���ϵͳ��ʶ�ŵ��ֶ�
	oBeps127.Rmk                    = m_cBpbdsendlist.m_rmk;

    
	//��ҵ������Ϊ"B308:"��"B309"Ϊһ��һ�����͵�
    oBeps127.TxId                         =     m_cBpbdsendlist.m_txid        ;    
    oBeps127.AgrmtNb                      =     m_cBpbdsendlist.m_agrmtnb;
    oBeps127.DbtrNm                       =     m_cBpbdsendlist.m_dbtnm       ;
    oBeps127.DbtrAdrLine                  =     m_cBpbdsendlist.m_dbtaddr     ;
    oBeps127.DbtrAcctId                   =     m_cBpbdsendlist.m_dbtracctid      ;
    oBeps127.DbtrAcctIssr                 =     m_cBpbdsendlist.m_dbtrissr        ;
    oBeps127.DbtrAgtId                    =     m_cBpbdsendlist.m_dbtrbrnchid     ;
    oBeps127.CdtrAgtId                    =     m_cBpbdsendlist.m_cdtrbrnchid     ;
    oBeps127.CdtrNm                       =     m_cBpbdsendlist.m_cdtrnm      ;
    oBeps127.CdtrAdrLine                  =     m_cBpbdsendlist.m_cdtaddr     ;
    oBeps127.CdtrAcctId                   =     m_cBpbdsendlist.m_cdtracctid      ;
    oBeps127.CdtrAcctIssr                 =     m_cBpbdsendlist.m_cdtrissr        ;
    
    memset(sTemp,'\0',sizeof(sTemp));
    oBeps127.CstmrDrctDbtInfAmt         =   ftoa(sTemp, m_cBpbdsendlist.m_amount, 2);    
    oBeps127.CstmrDrctDbtInfCcy         =   m_cBpbdsendlist.m_currency;    
    oBeps127.CtgyPurpPrtry              =   m_cBpbdsendlist.m_pmttpprtry;    
    oBeps127.CstmrDrctDbtInfPrtry       =   m_cBpbdsendlist.m_purpprtry;    
    oBeps127.AddtlInf                   =   m_cBpbdsendlist.m_addtlinf;
    //Trace(L_DEBUG, __FILE__, __LINE__, NULL, "____@@_%s", oBeps127.AddtlInf.c_str());
    
    sprintf(sTemp,"%.2f",m_cBpbdsendlist.m_amount);
    
    oBeps127.CstmrDrctDbtInfAmt            =    sTemp       ;
    oBeps127.CstmrDrctDbtInfCcy            =    m_cBpbdsendlist.m_currency        ;
    oBeps127.CtgyPurpPrtry                =     m_cBpbdsendlist.m_pmttpprtry      ;
    oBeps127.CstmrDrctDbtInfPrtry         =     m_cBpbdsendlist.m_purpprtry       ;
    oBeps127.AddtlInf                     =     m_cBpbdsendlist.m_addtlinf        ;

			   
    /*ҵ������ΪС��֧��ϵͳ֧Ʊ����ҵ��*/
    if("B308" == m_cBpbdsendlist.m_pmttpprtry)
    { 
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "___m_cBpbdsendlist.m_cstmrcdttrfaddtlinf[%d]=%s",
            m_cBpbdsendlist.m_cstmrcdttrfaddtlinf.length(), m_cBpbdsendlist.m_cstmrcdttrfaddtlinf.c_str());
            
        Trace(L_DEBUG,  __FILE__,  __LINE__, m_sMsgId, "m_cBpbdsendlist.m_pmttpprtry = [%s]",m_cBpbdsendlist.m_pmttpprtry.c_str());
        GetTagVal(oBeps127.ChqInfIsseDt        ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/IsseDt/");  
        GetTagVal(oBeps127.ChqInfPayDT         ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/PayDT/"); 
        GetTagVal(oBeps127.ChqInfNb            ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Nb/"); 
        GetTagVal(oBeps127.ChqInfPmtPswd       ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/PmtPswd/"); 
        GetTagVal(oBeps127.ChqInfPurp          ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Purp/"); 
        GetTagVal(oBeps127.ChqInfNbOfEndrsr    ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/NbOfEndrsr/");
        
    	//��ȡ��ϸ����
		GetTagCount(m_cBpbdsendlist.m_cstmrcdttrfaddtlinf, "/Nm/",iCount);
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "icount = [%d]",iCount);
        //__wsh 2012-05-09 �ͻ���û�м�¼������������
        char szNbOfEr[8] = {0};
        sprintf(szNbOfEr, "%d", iCount);
        oBeps127.ChqInfNbOfEndrsr = szNbOfEr;
        
		for(int i = 1; i <=iCount; i++)
		{
			/*�����ֶ�Ϊѭ���е�ѭ��*/
            GetTagVal(strTemp      ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Nm/",i); 
			oBeps127.ChqInfNm                   = strTemp;//������������
			oBeps127.m_strTx2 += oBeps127.CHECKVALUE(strTemp);
			oBeps127.AddNodeToSubcycle("ChqInfNm",oBeps127.ChqInfNm.c_str());//������������			
			oBeps127.AddSubcycleToNode("EndrsrDtl");
		}   
        oBeps127.AddNodeToSubcycle("EndrsrDtl","EndrsrDtl",1);//��ע������ѭ���ڵ����ӵĸ��ڵ� 
        
        GetTagVal(oBeps127.ChqInfImgTp         ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ImgTp/"); 
        GetTagVal(oBeps127.ChqInfImgFrntLen    ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ImgFrntLen/"); 
        GetTagVal(oBeps127.ChqInfImgFrntData   ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ImgFrntData/"); 
        GetTagVal(oBeps127.ChqInfImgBckLen     ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ImgBckLen/"); 
        GetTagVal(oBeps127.ChqInfImgBckData    ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ImgBckData/");
        
        // __wsh 2012-05-11 ͼƬ�����MD5��ɢֵ��32λʮ������ĸ�ִ���Ϊ��ǩҪ�ء�
        doMd5(oBeps127.ChqInfImgFrntData, oBeps127.m_strFrtImgMd5);
        Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
                    "__^^^__oBeps127.m_strFrtImgMd5=%s", oBeps127.m_strFrtImgMd5.c_str());
        doMd5(oBeps127.ChqInfImgBckData, oBeps127.m_strBckImgMd5);
        Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
                    "__^^^__oBeps127.m_strBckImgMd5=%s", oBeps127.m_strBckImgMd5.c_str());
    } 
    /*ҵ������ΪС��֧��ϵͳͨ��Ʊ�ݽ���ҵ��*/
    else if("B309" == m_cBpbdsendlist.m_pmttpprtry ||
            "B310" == m_cBpbdsendlist.m_pmttpprtry ||
            "B311" == m_cBpbdsendlist.m_pmttpprtry)
    { 
        //__wsh 2012-05-12 B310 B311��B309����������ṹ��ͬ���ʷ���һ��ʵʱ����
        Trace(L_DEBUG,  __FILE__,  __LINE__,m_sMsgId, "m_cBpbdsendlist.m_pmttpprtry = [%s]",m_cBpbdsendlist.m_pmttpprtry.c_str());
        GetTagVal(oBeps127.BllInfIsseDt        ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/IsseDt/");
         
        //__wsh 2012-05-11 ������ĸ�ʽΪ/Amt/CNY0.00
        string strAmt = "";
        if(0 == GetTagVal(strAmt, m_cBpbdsendlist.m_cstmrcdttrfaddtlinf, "/Amt/"))
        {
            oBeps127.BllInfCcy = strAmt.substr(0, 3);
            oBeps127.BllInfAmt = strAmt.c_str() + 3; 
        }
        
        //GetTagVal(oBeps127.BllInfAmt           ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Amt/"); 
        //GetTagVal(oBeps127.BllInfCcy           ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Ccy/"); 
        GetTagVal(oBeps127.BllInfPayDT         ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/PayDT/"); 
        GetTagVal(oBeps127.BllInfNb            ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Nb/"); 
        GetTagVal(oBeps127.BllInfPmtPswd       ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/PmtPswd/"); 
        GetTagVal(oBeps127.MtrtyDt             ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/MtrtyDt/"); 
        GetTagVal(oBeps127.Seal                ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Seal/"); 
        GetTagVal(oBeps127.AccptncAgrmtNb      ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/AccptncAgrmtNb/"); 
        GetTagVal(oBeps127.AccptncDt           ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/AccptncDt/"); 
        GetTagVal(oBeps127.AccptncNm           ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/AccptncNm/"); 
        GetTagVal(oBeps127.ApplyNm             ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ApplyNm/"); 
        GetTagVal(oBeps127.ApplyAcct           ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ApplyAcct/"); 
        GetTagVal(oBeps127.DrwrNm              ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/DrwrNm/"); 
        GetTagVal(oBeps127.DrwrAcct            ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/DrwrAcct/"); 
        GetTagVal(oBeps127.TxlCtrctNb          ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/TxlCtrctNb/");
        GetTagVal(oBeps127.BllInfPurp          ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Purp/"); 
        GetTagVal(oBeps127.BllInfNbOfEndrsr    ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/NbOfEndrsr/"); 
        
        //��ȡ��ϸ����
		GetTagCount(m_cBpbdsendlist.m_cstmrcdttrfaddtlinf, "/Nm/",iCount);
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "icount = [%d]",iCount);

		for(int i = 1; i <=iCount; i++)
		{
			/*�����ֶ�Ϊѭ���е�ѭ��*/
            GetTagVal(strTemp      ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Nm/",i); 
			oBeps127.BllInfNm                   = strTemp;//������������
			oBeps127.m_strTx2 += oBeps127.CHECKVALUE(strTemp);
			oBeps127.AddNodeToSubcycle("BllInfNm",oBeps127.BllInfNm.c_str());//������������			
			oBeps127.AddSubcycleToNode("BllInfEndrsrDtl");
		}   
        oBeps127.AddNodeToSubcycle("BllInfEndrsrDtl","BllInfEndrsrDtl",1);//��ע������ѭ���ڵ����ӵĸ��ڵ� 
         
        GetTagVal(oBeps127.OrgnlCdtrNm         ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/OrgnlCdtrNm/"); 
        GetTagVal(oBeps127.BllInfImgTp         ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ImgTp/"); 
        GetTagVal(oBeps127.BllInfImgFrntLen    ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ImgFrntLen/"); 
        GetTagVal(oBeps127.BllInfImgFrntData   ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ImgFrntData/"); 
        GetTagVal(oBeps127.BllInfImgBckLen     ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ImgBckLen/"); 
        GetTagVal(oBeps127.BllInfImgBckData    ,m_cBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ImgBckData/"); 
        
        // __wsh 2012-05-11 
        doMd5(oBeps127.BllInfImgFrntData, oBeps127.m_strFrtImgMd5);
        Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
                    "__^^^__oBeps127.m_strFrtImgMd5=%s", oBeps127.m_strFrtImgMd5.c_str());
        doMd5(oBeps127.BllInfImgBckData, oBeps127.m_strBckImgMd5);
        Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
                    "__^^^__oBeps127.m_strBckImgMd5=%s", oBeps127.m_strBckImgMd5.c_str());

    }
    
    
    		
	oBeps127.AddDetail();
	
	//��ǩ
	AddSign127(oBeps127);
	
	int iRet = oBeps127.CreateXml();
	if (0 != iRet)
	{
		
		sprintf(m_sErrMsg,"�������˱���ʧ��[%d]",iRet);
		
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, m_sErrMsg);
	}
	
	m_sMsgTxt = oBeps127.m_sXMLBuff;
	
	Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, " m_sMsgTxt = [%s]",m_sMsgTxt.c_str());
	
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps127::CreatPmtsMsg"); 
    
	return iRet;
}

int CSendBeps127::updateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps127::updateState");
	  
    string strSQL;
    
	strSQL += "UPDATE BP_BDSNDCL t SET t.PROCSTATE = '08'";   
	strSQL += " WHERE t.MSGID = '";
	strSQL += m_cBpbdsndcl.m_msgid;							
	strSQL += "' AND t.INSTGDRCTPTY = '";
    strSQL += m_cBpbdsndcl.m_instgdrctpty + "'";	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());

    SETCTX(m_cBpbdsndcl);
    int iRet = m_cBpbdsndcl.execsql(strSQL.c_str());
    
    if (SQL_SUCCESS != iRet) 
	{
		
		sprintf(m_sErrMsg,"�޸Ľ�����˻���ҵ��״̬ʧ��[%s]",m_cBpbdsndcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_sErrMsg);
	}

    strSQL = "";
	strSQL += "UPDATE BP_BDSENDLIST t SET t.PROCSTATE = '08'";   
	strSQL += " WHERE t.MSGID = '";
	strSQL += m_cBpbdsndcl.m_msgid;							
	strSQL += "' AND t.INSTGDRCTPTY = '";
    strSQL += m_cBpbdsndcl.m_instgdrctpty + "'";	
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());

    SETCTX(m_cBpbdsendlist);
    iRet = m_cBpbdsendlist.execsql(strSQL.c_str());
    
    if (SQL_SUCCESS != iRet) 
	{
		
		sprintf(m_sErrMsg,"�޸Ľ��������ϸҵ��״̬ʧ��[%s]",m_cBpbdsendlist.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_sErrMsg);
	}

    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps127::updateState");
    return 0;
}

//__wsh 2012-05-09 B308 B309   ��ǩ
void CSendBeps127::AddSign127(beps127& xml127)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBeps127::AddSign127...");

	char   sSignedStr[4096 + 1] = {0};
	
	xml127.getOriSignStr();
	
	AddSign(xml127.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_cBpbdsendlist.m_instgdrctpty.c_str());
	
	xml127.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBeps127::AddSign127...");
}

//__wsh 2012-05-11 ����MD5ֵ������֧Ʊ������ҵ���ͼ��MD5ֵ����
/*
void CSendBeps127::doMd5(string& strSrc, string& strDst)
{
    MD5 md5;
    md5.Hash_Start();
    md5.Hash_PatchBuffer((unsigned char*)strSrc.c_str(), strSrc.length());
    strDst =  md5.Hash_End().GetBuffer(0);
}*/
