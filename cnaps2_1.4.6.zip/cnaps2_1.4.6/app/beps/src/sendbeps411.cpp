/******************************************************************** 
�ļ����� sendbeps411.cpp
�����ˣ� lpye
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ���� С����ֹ������beps.411���Ĵ�����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps411.h"

using namespace ZFPT;

CSendBeps411::CSendBeps411(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
    bCheck  = false;
}

CSendBeps411::~CSendBeps411()
{

}

INT32 CSendBeps411::doWorkSelf()
{
	Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps411::doWorkSelf");
	
	/*��ҵ����л�ȡ����*/
	getData();
	
	/*ҵ����:������*/
	CheckValues();
	
	//�����ʧ��ʱ������Ҫ��֧��ϵͳ����
	if (!bCheck)
	{
		/*��pmts����:��ʾ�����XML����;������ֻ��һ��������*/
		buildPmtsMsg();
		
		UpdateState();
		
	    AddQueue();
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps411::doWorkSelf"); 
	return 0;
}

int CSendBeps411::getData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps411::getData");

	SETCTX(m_cBpcstbdpcxlcl);

    
  	m_cBpcstbdpcxlcl.m_instgpty = m_sSendOrg;
  	m_cBpcstbdpcxlcl.m_msgid    = m_sMsgId;
  	m_cBpcstbdpcxlcl.m_rsflag   = "1";
  	
  	iRet = m_cBpcstbdpcxlcl.findByPK();

  	if (SQLNOTFOUND == iRet)
	{
		sprintf(m_sErrMsg, "��ѯ���ҵ��ֹ�����ܱ����Ҳ���ָ��ҵ��[%s], [%s], [%d][%s]", 
		    m_sSendOrg, m_sMsgId, iRet, m_cBpcstbdpcxlcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	} 	
	else if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg, "��ѯ���ҵ��ֹ�����ܱ���������[%s], [%s], [%d][%s]",
		    m_sSendOrg, m_sMsgId, iRet, m_cBpcstbdpcxlcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}

	Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps411::getData"); 
    
	return iRet;
}


int CSendBeps411::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps411::CheckValues");

    //���ԭ���ҵ���Ƿ��Ѹ�����Ѹ������Ҫ����ֹ�����뽻��
	if (0 != m_cBpbdsndcl.setctx(m_dbproc))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_AMT_OUT_OF_LIMIT, "setctx error");
    }

    m_cBpbdsndcl.m_msgid        = m_cBpcstbdpcxlcl.m_orgnlmsgid;
    m_cBpbdsndcl.m_instgdrctpty = m_cBpcstbdpcxlcl.m_orgnlinstgpty;

    iRet = m_cBpbdsndcl.findByPK();
    if (SQL_SUCCESS != iRet)
    {
		sprintf(m_sErrMsg, "��ѯ������˻��ܱ���������[%s], [%s], [%d][%s]",
		    m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(), 
		    m_cBpcstbdpcxlcl.m_orgnlinstgpty.c_str(), 
		    iRet, m_cBpcstbdpcxllist.GetSqlErr());

		Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);         
    }
    else if (SQLNOTFOUND == iRet)
    {
		sprintf(m_sErrMsg, "��ѯ������˻��ܱ��޼�¼[%s], [%s], [%d][%s]",
		    m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(), 
		    m_cBpcstbdpcxlcl.m_orgnlinstgpty.c_str(), 
		    iRet, m_cBpcstbdpcxllist.GetSqlErr());

		Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);        
    }

    if (m_cBpbdsndcl.m_busistate == "PR02")
    {
        bCheck = true;

		sprintf(m_sErrMsg, "��ѯ�ñʽ�ǰ��Ѹ���, �޷�ֹ��[%s], [%s], [%s]",
		    m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(), 
		    m_cBpcstbdpcxlcl.m_orgnlinstgpty.c_str(), 
		    m_cBpbdsndcl.m_busistate.c_str());

		Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);

		return 0;
    }
    
    
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps411::CheckValues");
    return 0;
}

int CSendBeps411::setBdPcxlList()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps411::setBdPcxlList");
    int iCount      = 0;
    STRING sSqlStr  = "";

	SETCTX(m_cBpcstbdpcxllist);
    
    sSqlStr = " 1=1 and msgid = '";
    sSqlStr += m_sMsgId;
    sSqlStr += "' and orgnlmsgId = '";
    sSqlStr += m_cBpcstbdpcxlcl.m_orgnlmsgid;
    sSqlStr += "' and rsflag = '1' ";
    
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "___@@__sSqlStr=%s", sSqlStr.c_str());

    iRet = m_cBpcstbdpcxllist.findcount(sSqlStr);
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "___Number of Record = %d", m_cBpcstbdpcxllist.m_iCount);
    iRet = m_cBpcstbdpcxllist.find(sSqlStr.c_str());
    if (SQL_SUCCESS != iRet)
    {
		sprintf(m_sErrMsg, "��ѯ���ҵ��ֹ����ϸ����������[%s], [%s], [%d][%s]",
		    m_sMsgId, m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(), iRet, m_cBpcstbdpcxllist.GetSqlErr());

		Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);    
    }

    while (1)
    {
        iRet = m_cBpcstbdpcxllist.fetch();
        
        Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
            "[SQLNOTFOUND:%d][SQL_SUCCESS:%d][iRet:%d]", SQLNOTFOUND, SQL_SUCCESS, iRet);
        
        //__wsh 2012-05-24 ���������߼�����
        //
        if(SQL_SUCCESS != iRet){
            if (SQLNOTFOUND == iRet){
                Trace(L_DEBUG, __FILE__, __LINE__, 
                        m_sMsgId, "��ǰ��ϸ��������ȡ��!");
                break;
            }
            else{
        		sprintf(m_sErrMsg, "Fetch���ҵ��ֹ����ϸ�����ݷ�������[%d][%s]",
        		    iRet, m_cBpcstbdpcxllist.GetSqlErr());
    
        		Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);
                m_cBpcstbdpcxllist.closeCursor();
        		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg); 
        	}              
        }
        
        iCount ++; 

        //__wsh 2012-05-24 ��������ֵ��ѭ����ǩ�º�ǩ��������
        m_oBeps411.AddNodeToSubcycle("OrgnlPmtInfId", 
                            m_cBpcstbdpcxllist.m_orgnlpmtinfid.c_str());
        m_oBeps411.OrgnlPmtInfId = m_cBpcstbdpcxllist.m_orgnlpmtinfid;
                            
        m_oBeps411.AddNodeToSubcycle("Prtry", 
                            m_cBpcstbdpcxllist.m_orgnlprtry.c_str());
        m_oBeps411.Prtry = m_cBpcstbdpcxllist.m_orgnlprtry;
                            
        //m_oBeps411.AddNodeToSubcycle("Ustrd", m_cBpcstbdpcxllist.m_rmtinf.c_str());
        m_oBeps411.SetUstrd(0, m_cBpcstbdpcxllist.m_rmtinf.c_str());
        char sUstrdName[32 + 1] = {0};
        sprintf(sUstrdName,"Ustrd%03d",iCount);
	    m_oBeps411.AddNodeToSubcycle("Ustrd", sUstrdName, 2);
	    
        m_oBeps411.AddNodeToSubcycle("DbtrAgtId", 
                        m_cBpcstbdpcxllist.m_orgdbtrbrnchid.c_str());
        m_oBeps411.DbtrAgtId = m_cBpcstbdpcxllist.m_orgdbtrbrnchid;
        
        m_oBeps411.AddNodeToSubcycle("CdtrAgtId",
                        m_cBpcstbdpcxllist.m_orgcdtrbrnchid.c_str());
		m_oBeps411.CdtrAgtId = m_cBpcstbdpcxllist.m_orgcdtrbrnchid;
		
		m_oBeps411.AddSubcycleToNode("OrgnlPmtInfAndCxl");
		
		// ѭ����ǩ
		m_oBeps411.getOrgnlPmtInfAndCxl();
    }

    m_cBpcstbdpcxllist.closeCursor();
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps411::setBdPcxlList");
    return 0;
}

int CSendBeps411::buildPmtsMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps411::buildPmtsMsg");

    char sTemp[128]  = {0};
    string strTemp;

	SETCTX(m_cBpcstbdpcxlcl);
	
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__@@_msgtype =%s", m_sMsgType);

    //��ֵ
	bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(PRM_FAIL);
    }
    m_oBeps411.m_PMTSHeader.SetPMTSXMlHeader(
                        "BEPS", 
                        m_cBpcstbdpcxlcl.m_workdate.c_str(),
                        m_cBpcstbdpcxlcl.m_instgdrctpty.c_str(),
                        m_cBpcstbdpcxlcl.m_instddrctpty.c_str(),
                        "beps.411.001.01",
                        m_sMsgRefId);

    m_oBeps411.AssgnmtId      = m_cBpcstbdpcxlcl.m_msgid;         //���ı�ʶ��
    m_oBeps411.AssgnrMmbId    = m_cBpcstbdpcxlcl.m_instgdrctpty;  //����ֱ�Ӳ������
    //change by huwei 
    //m_oBeps411.AssgnrId       = m_cBpcstbdpcxlcl.m_instgpty;      //�����Ӳ������
    m_oBeps411.AssgnrId  = m_oBeps411.AssgnrMmbId;// �����ĵ�Ҫ���� ������ ����ֱ�ӻ��� 
    //change end
    m_oBeps411.AssgneMmbId    = m_cBpcstbdpcxlcl.m_instddrctpty;  //����ֱ�Ӳ������
    m_oBeps411.AssgneId       = m_cBpcstbdpcxlcl.m_instdpty;      //���ռ�Ӳ������
	
    m_oBeps411.CreDtTm        = m_sIsoWorkDate;                   //���ķ���ʱ��

    m_oBeps411.GrpCxlId       = m_cBpcstbdpcxlcl.m_grpcxlid;      // ֹ�����ͱ�ʶ
    m_oBeps411.CaseId         = "1";                              //�̶���1
    m_oBeps411.CretrMmbId     = m_cBpcstbdpcxlcl.m_orgnlinstgpty; //ԭ����ֱ�Ӳ������
    m_oBeps411.OrgnlMsgId     = m_cBpcstbdpcxlcl.m_orgnlmsgid;    //ԭ���ı�ʶ��
    m_oBeps411.OrgnlMsgNmId   = m_cBpcstbdpcxlcl.m_orgnmsgtp;     //ԭ�������ͺ�

    if (m_cBpcstbdpcxlcl.m_grpcxlid == GRPCXLID_PRT)
    {
        Trace(L_DEBUG,  __FILE__,  __LINE__, m_sMsgId, "�鲿��ֹ����ϸ");
        setBdPcxlList();
    }

	//��ǩ
	AddSign411();

    iRet = m_oBeps411.CreateXml();
    if (0 != iRet)
    {
		sprintf(m_sErrMsg, "Create beps.411.001.01 XML is Error!iRet[%d]", iRet);

		Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, m_sErrMsg); 
    }

    m_sMsgTxt = m_oBeps411.m_sXMLBuff;
    //Trace(L_DEBUG, __FILE__, __LINE__, NULL, "MSG: %s", m_oBeps411.m_sXMLBuff.c_str());

	

    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps411::buildPmtsMsg");
    return 0;   
}

void CSendBeps411::AddSign411()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms411::AddSign411");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_oBeps411.getOriSignStr();
	
	AddSign(m_oBeps411.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_cBpcstbdpcxlcl.m_instgdrctpty.c_str());
	
	m_oBeps411.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms411::AddSign411");
}
//__wsh 2012-05-21 ����ԭ����״̬
INT32 CSendBeps411::UpdateState()
{
    int iRet = -1;
    char szErr[1024] = {0};
    
    //����ԭ���뱨��״̬
    string strSqlCxl = "update bp_cstbdpcxlcl set mesgid = '";
    strSqlCxl += m_sMsgRefId;
    strSqlCxl += "', mesgrefid = '";
    strSqlCxl += m_sMsgRefId;
    strSqlCxl += "', procstate = '";
    strSqlCxl += PR_HVBP_08;
    //change by huwei , 2013-07-08 ԭ��Ϊֱ�Ӳ������
    strSqlCxl += "' where INSTGPTY = '";
    strSqlCxl += m_sSendOrg;
    strSqlCxl += "' and msgid = '";
    strSqlCxl += m_sMsgId;
    strSqlCxl += "' and rsflag = '1' ";
    Trace(L_DEBUG, __FILE__, __LINE__, 
            NULL, "__@@__strSqlCxl=%s", strSqlCxl.c_str());
    iRet = m_cBpcstbdpcxlcl.execsql(strSqlCxl.c_str());
    if(RTN_SUCCESS != iRet){
		sprintf(szErr,"��ֹ�����ܱ�����, error code =[%d],error cause = [%s]",
		        iRet, m_cBpcstbdpcxlcl.GetSqlErr());
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, szErr);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErr);

    } 
    
    return iRet;
}

