/******************************************************************** 
�ļ����� sendcmt327.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ���� С����ֹ������327���Ĵ�����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt327.h"

using namespace ZFPT;

CSendCmt327::CSendCmt327(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
}

CSendCmt327::~CSendCmt327()
{
}

INT32 CSendCmt327::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt327::doWorkSelf");

    // ��ȡ����
    GetData();

    // �鱨��
    CreateNpcMsg();

    // ����״̬
    UpdateState();

    // ���ͱ���
    AddQueue();

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt327::doWorkSelf"); 
    return 0;
}

int CSendCmt327::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt327::getData");

	SETCTX(m_cBpcstbdpcxlcl);
    
    // INSTGPTY MSGID
  	m_cBpcstbdpcxlcl.m_instgpty = m_sSendOrg;
  	m_cBpcstbdpcxlcl.m_msgid   = m_sMsgId;
  	m_cBpcstbdpcxlcl.m_rsflag   = '1';
  	int iRet = m_cBpcstbdpcxlcl.findByPK();

  	if (SQLNOTFOUND == iRet)
	{
		sprintf(m_sErrMsg, "�Ҳ���ָ��ҵ��[%s], [%s], [%d][%s]", 
		    m_sSendOrg, m_sMsgId, iRet, m_cBpcstbdpcxlcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	} 	
	else if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg, "��ѯ���ܱ���������[%s], [%s], [%d][%s]",
		    m_sSendOrg, m_sMsgId, iRet, m_cBpcstbdpcxlcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}

    if("0" == m_cBpcstbdpcxlcl.m_grpcxlid)
    {
        SETCTX(m_cBpcstbdpcxllist);        
        m_cBpcstbdpcxllist.m_msgid = m_cBpcstbdpcxlcl.m_msgid;
        m_cBpcstbdpcxllist.m_instgpty = m_cBpcstbdpcxlcl.m_instgdrctpty;

        string strSQL = "MSGID = '" + m_cBpcstbdpcxlcl.m_msgid + "' and INSTGPTY  = '" + m_cBpcstbdpcxlcl.m_instgdrctpty + "'";
        iRet = m_cBpcstbdpcxllist.find(strSQL);
	
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "[SQL]%s", strSQL.c_str()); 
        if (SQL_SUCCESS != iRet)
    	{
    		sprintf(m_sErrMsg, "�Ҳ���ָ��ҵ��[%s], [%s], [%d][%s]", m_cBpcstbdpcxllist.m_msgid.c_str(), m_cBpcstbdpcxllist.m_instgpty.c_str(), iRet, m_cBpcstbdpcxllist.GetSqlErr());
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);

    		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    	}
    	
		int iRetCode = m_cBpcstbdpcxllist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
		{
    		sprintf(m_sErrMsg, "�Ҳ���ָ��ҵ��[%s], [%s], [%d][%s]", m_cBpcstbdpcxllist.m_msgid.c_str(), m_cBpcstbdpcxllist.m_instgpty.c_str(), iRet, m_cBpcstbdpcxllist.GetSqlErr());
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
    		
    		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);		
		}
	}
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt327::getData"); 
    
	return iRet;
}

INT32 CSendCmt327::CreateNpcMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt327::CreateNpcMsg");
	
    strcpy(m_cmt327.sConsigndate , m_cBpcstbdpcxlcl.m_consigdate.c_str());        //ί������   8n         M
    strcpy(m_cmt327.sOldsendsapbk , m_cBpcstbdpcxlcl.m_instgdrctpty.c_str());     //�������������� , ԭ������������     12n        M
    strcpy(m_cmt327.sOldsendbank , m_cBpcstbdpcxlcl.m_instgpty.c_str());          //ֹ�������� , ԭ��������     12n       O
    strcpy(m_cmt327.sRevctmssno , m_szMsgSerial);                                 //�����������       8n         M
    strcpy(m_cmt327.sOldrecvsapbk , m_cBpcstbdpcxlcl.m_instddrctpty.c_str());     //ֹ��Ӧ�������� , ԭ������������     12n        M
    strcpy(m_cmt327.sOldrecvbank , m_cBpcstbdpcxlcl.m_instdpty.c_str());          //ֹ��Ӧ���� , ԭ��������     12n        O
    strcpy(m_cmt327.sFlag , m_cBpcstbdpcxlcl.m_grpcxlid.c_str());                 //ֹ������           1n         M
    
    if (m_cBpcstbdpcxlcl.m_orgnmsgtp.length()>=6)
        strcpy(m_cmt327.sOldpacktype , m_cBpcstbdpcxlcl.m_orgnmsgtp.c_str()+3);    //ԭ�����ͺ�         3n 	       O
    
    if (m_cBpcstbdpcxlcl.m_orgnlmsgid.length()>=16)
    {
        string tmpStr = m_cBpcstbdpcxlcl.m_orgnlmsgid.substr(0,8);
        strcpy(m_cmt327.sOldpackdate , tmpStr.c_str());                            //ԭ��ί������       8n         O
       
        tmpStr = m_cBpcstbdpcxlcl.m_orgnlmsgid.substr(8,8);
        strcpy(m_cmt327.sOldpackno , tmpStr.c_str());                              //ԭ�����           8n         O    
    }
    
    if("0" == m_cBpcstbdpcxlcl.m_grpcxlid)
    {
                                                                                       
        strcpy(m_cmt327.sOldtradetpno   , m_cBpcstbdpcxllist.m_orgnlprtry.c_str()); //ԭҵ�����ͺ�       5n         O
        
        char szOrgConsigdate[8+1]={0};
        strncpy(szOrgConsigdate, m_cBpcstbdpcxllist.m_orgnlpmtinfid.c_str(), sizeof(szOrgConsigdate)-1);
        strcpy(m_cmt327.sOldconsigndate , szOrgConsigdate);                         //ԭί������        8n          O

        if (m_cBpcstbdpcxllist.m_orgnlmsgid.length()>=16)
        {
            // ԭ֧���������         NUMBER(8)      O 
            string tmpStr = m_cBpcstbdpcxllist.m_orgnlpmtinfid.substr(8, 8);
            m_cmt327.iOldtxssno = atoi(tmpStr.c_str());
        }
    }

    //strcpy(m_cmt327.sTextkey , );           //��Ѻ               40x        O                              
    strcpy(m_cmt327.sRemark , m_cBpcstbdpcxllist.m_rmtinf.c_str());            //ֹ�����븽��           60g        O        

	bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ȡ���Ĳο���ʧ��!");
	    PMTS_ThrowException(PRM_FAIL);
    }

    int iRet = m_cmt327.CreateCmt("327",
                           	  m_cBpcstbdpcxlcl.m_instgdrctpty.c_str(),
                           	  m_cBpcstbdpcxlcl.m_instddrctpty.c_str(),
                           	  m_sMsgRefId,
                           	  m_sMsgRefId, 
                           	  m_cBpcstbdpcxlcl.m_workdate.c_str(),
                           	  "0");
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
	
    m_sMsgTxt = m_cmt327.m_strCmtmsg ;
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt327::CreateNpcMsg"); 
    return 0;
}

int CSendCmt327::UpdateState(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendCmt327::UpdateDb");

	string strSQL;
	strSQL += "UPDATE bp_CstBdPCxlCl t SET t.Procstate = '";
    strSQL += PR_HVBP_08;
    strSQL += "', t.mesgid='";
    strSQL += m_sMsgRefId;
    strSQL += "', t.mesgrefid='";
    strSQL += m_sMsgRefId;
	strSQL += "', t.STATETIME = sysdate WHERE t.msgid = '";
	strSQL += m_cBpcstbdpcxlcl.m_msgid;
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_cBpcstbdpcxlcl.m_instgdrctpty; 
	strSQL += "' and rsflag = '1' ";
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, strSQL.c_str());
	
    SETCTX(m_cBpcstbdpcxlcl);
	int iRet = m_cBpcstbdpcxlcl.execsql(strSQL.c_str());
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL, "Update failed, sqlcode=[%d]", iRet);
	}
	else if (iRet != SQL_SUCCESS)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]",
		    iRet, m_cBpcstbdpcxlcl.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
	}
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendCmt327::UpdateDb");
    return RTN_SUCCESS;
}

