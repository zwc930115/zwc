/******************************************************************** 
�ļ����� sendbeps404.cpp
�����ˣ� aps-lel	
��  �ڣ� 2011-04-07
�޸��ˣ� __wsh
��  �ڣ� 2011-06-28
��  ���� С������beps.404���Ĵ�����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps404.h"


CSendBeps404::CSendBeps404(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{

}

CSendBeps404::~CSendBeps404()
{

}

INT32 CSendBeps404::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__,
            m_sMsgId, "enter CSendBeps404::doWorkSelf");
    
    /*��ҵ����л�ȡ����*/   
    GetData();      
    
    /*��pmts����*/
    CreatePmtsMsg();  
    
    /*�޸�״̬*/
    updateState();
    
    /*����Զ�̶���*/
    AddQueue();

    Trace(L_INFO,  __FILE__,  __LINE__,
            m_sMsgId, "leave CSendBeps404::doWorkSelf..."); 
    return 0;
}

int CSendBeps404::GetDtlVal(string& strVal, 
            string& strSrc, const string& strTag, int& iCount)
{
    int iRet = -1;
    iRet = GetTagVal(strVal, strSrc, strTag, iCount);
    ++iCount;
    
    return iRet;
}
int CSendBeps404::updateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__,
            m_sMsgId, "enter CSendBeps404::updateState...");

	SETCTX(m_cBpinvcprtrspn);
    string strSQL;
	strSQL += "UPDATE bp_invcprtrspn  t SET t.PROCTIME = sysdate, t.PROCSTATE = '08'"; 
	strSQL += ", t.mesgid='";
	strSQL += m_sMsgRefId;
	strSQL += "', t.mesgrefid='";
	strSQL += m_sMsgRefId; 
	strSQL += "' WHERE t.MSGID = '";
	strSQL += m_cBpinvcprtrspn.m_msgid.c_str();
	strSQL += "' AND t.instgpty = '";
	strSQL += m_cBpinvcprtrspn.m_instgpty.c_str(); 
	strSQL += "' and t.rsflag='1' ";	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());

	iRet = m_cBpinvcprtrspn.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
		sprintf(m_sErrMsg,"execsql() error,error code = [%d],error cause = [%s]",
		        iRet,m_cBpinvcprtrspn.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_sErrMsg);

    }

    Trace(L_INFO,  __FILE__,  __LINE__,
                m_sMsgId, "leave CSendBeps404::updateState...");
    return 0;
}

int CSendBeps404::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, 
            m_sMsgId, "enter CSendBeps404::GetData...");
	
	SETCTX(m_cBpinvcprtrspn);
	
  	m_cBpinvcprtrspn.m_instgpty = m_sSendOrg;//���������
  	m_cBpinvcprtrspn.m_msgid    = m_sMsgId;      
  	m_cBpinvcprtrspn.m_rsflag   = "1"; 
  	
  	iRet = m_cBpinvcprtrspn.findByPK();
  	
	if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg,"findByPK() error,error code = [%d],error cause = [%s]",
		        iRet,m_cBpinvcprtrspn.GetSqlErr());
		
		Trace(L_INFO,  __FILE__,  __LINE__,NULL, m_sErrMsg);
		
		PMTS_ThrowException(DB_FIND_FAIL);
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "leave CSendBeps404::GetData..."); 
    
	return iRet;
}

int CSendBeps404::CreatePmtsMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, 
            m_sMsgId, "enter CSendBeps404::CreatePmtsMsg...");
    
    //��ȡͨ�ż���ʶ
	bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(PRM_FAIL);
    }
    //__wsh 2012-07-03
    //������ͷ
	m_beps404.CreateXMlHeader(
                "BEPS", 
				m_sWorkDate,
				m_sSendOrg,
				m_cBpinvcprtrspn.m_instdpty.c_str(),
  				"beps.404.001.01",
  				m_sMsgRefId);
	//����ͷ���			  					
	m_beps404.MsgId			  = m_cBpinvcprtrspn.m_msgid ;
	m_beps404.CreDtTm 		  = m_sIsoWorkDate ;
	m_beps404.InstgDrctPty	  = m_cBpinvcprtrspn.m_instgdrctpty ;
	m_beps404.GrpHdrInstgPty  = m_cBpinvcprtrspn.m_instgdrctpty ;
	m_beps404.InstdDrctPty	  = m_cBpinvcprtrspn.m_instddrctpty ;
	m_beps404.GrpHdrInstdPty  = m_cBpinvcprtrspn.m_instddrctpty ;
	m_beps404.SysCd			  = "BEPS" ;
	m_beps404.GrpHdrRmk 	  = m_cBpinvcprtrspn.m_rmk ;
	
	//ԭҵ����Ϣ
	m_beps404.OrgnlMsgId	  = m_cBpinvcprtrspn.m_orgnlmsgid;//ԭ���ı�ʶ��
	m_beps404.OrgnlInstgPty	  = m_cBpinvcprtrspn.m_orgnlinstgpty;//ԭ����������
	m_beps404.OrgnlMT         = m_cBpinvcprtrspn.m_orgnlmt;//ԭ��������
	
	//ҵ��Ӧ����Ϣ
	m_beps404.Sts 	          = m_cBpinvcprtrspn.m_status;//ҵ��״̬
	m_beps404.RjctCd 	      = m_cBpinvcprtrspn.m_rjctcd;//ҵ��ܾ�������
	m_beps404.RjctInf 	      = m_cBpinvcprtrspn.m_rjctinf;//ҵ��ܾ���Ϣ
	m_beps404.PrcPty 	      = m_cBpinvcprtrspn.m_rjcprcpty;//ҵ�����������
	
	//��Ʊ��Ϣ
	char szTmp[32] = {0};
	m_beps404.StartTm         = m_cBpinvcprtrspn.m_starttm;//ҵ����ʼʱ��
	m_beps404.EndTm           = m_cBpinvcprtrspn.m_endtm;  //ҵ����ֹʱ��
	
	sprintf(szTmp, "%d", m_cBpinvcprtrspn.m_prtcnt);   //��Ʊ��ӡ����
	m_beps404.PrtCnt          = szTmp;  
	
	int ret = -1;
	string strVal = "";
	string strSrc = "";
	//�տ��б���ϸ
	strSrc = m_cBpinvcprtrspn.m_itmdtls;
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
	        "m_cBpinvcprtrspn.m_nbofitms=[%s]strsrc=[%s]", 
	        m_cBpinvcprtrspn.m_itmdtls.c_str(), strSrc.c_str());
	        
	if(0 == (ret = GetTagVal(strVal, strSrc, "/NbOfItms/"))){
	    
	    int iNbOfItems = atoi(strVal.c_str());
	    m_beps404.NbOfItms = strVal.c_str();
	    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strVal=[%s]", strVal.c_str());
	    
	    for(int i = 0; i < iNbOfItems; ++i){
	        GetTagVal(strVal, strSrc, "/Nm/", i+1);
	        Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strVal=[%s]", strVal.c_str());
	        
	        m_beps404.ItmDtlsNm = strVal.c_str();
	        GetTagVal(strVal, strSrc, "/Amt/", i+1);
	        if(NULL == strstr(strVal.c_str(), "+") && NULL == strstr(strVal.c_str(), "-")){
	            strVal = strVal.substr(0, 3) + "+" + strVal.substr(3);  
	        }
	        Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strVal=[%s]", strVal.c_str());
	        
	        m_beps404.Amt = strVal.c_str();
	           
	        m_beps404.AddNodeToSubcycle(
	            "ItmDtlsNm", m_beps404.ItmDtlsNm.c_str());	            
			m_beps404.AddNodeToSubcycle(
			    "Amt", m_beps404.Amt.c_str());
			m_beps404.AddSubcycleToNode("ItmDtls");
			
	    }// end for	
	        
	}// end if
	else{
	    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "No NbOfItms Found ret=%d", ret);
	}
	
	//��Ʊ�ֶ���Ŀ��ϸ
	strSrc = m_cBpinvcprtrspn.m_flditmdtls;
	if(0 == GetTagVal(strVal, strSrc, "/NbOfFldItms/")){
	    
	    int iNbOfItems = atoi(strVal.c_str());
	    m_beps404.NbOfFldItms = strVal.c_str();
	    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strVal=[%s]", strVal.c_str());
	    
	    for(int i = 0; i < iNbOfItems; ++i){
	        GetTagVal(strVal, strSrc, "/Nm/", i+1);
	        Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strVal=[%s]", strVal.c_str());
	        
	        m_beps404.FldItmDtlsNm = strVal.c_str();
	        GetTagVal(strVal, strSrc, "/Val/", i+1);
	        Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strVal=[%s]", strVal.c_str());
	        
	        m_beps404.Val = strVal.c_str(); 
	        
	        m_beps404.AddNodeToSubcycle(
	                "FldItmDtlsNm", m_beps404.FldItmDtlsNm.c_str());
			m_beps404.AddNodeToSubcycle(
			        "Val", m_beps404.Val.c_str());
            m_beps404.AddSubcycleToNode("FldItmDtls");    
	          
	    }// end for
	    
	}// end if
	else{
	    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "No NbOfFldItms Found");
	}
	
	m_beps404.InvcInfRmk   = m_cBpinvcprtrspn.m_addinf;//��ע
	
	int iRet = m_beps404.CreateXml();
	
	if (0 != iRet)
	{
		
		sprintf(m_sErrMsg,"�������˱���ʧ��iRet = [%d]! ",iRet);
		
		Trace(L_INFO,  __FILE__,  __LINE__,NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, m_sErrMsg);
	}
	
	
	m_sMsgTxt = m_beps404.m_sXMLBuff ;
	
	
    Trace(L_INFO,  __FILE__,  __LINE__, 
            NULL, "leave CSendBeps404::CreatePmtsMsg..."); 
    
	return iRet;
}

/******************************************************************************
*  Function:   GetSubstrBySeparat
*  Description:���ַ���strOristr�л�ȡ���ַ���
*  Input:      chSep      �ָ���
*              strOristr  Դ�ַ���
*  Output:     strLeft    �ָ�����ߵ��Ӵ�
*			   strRight   �ָ����ұߵ��Ӵ�
*  Return:     ��
*  Others:     ��
*  Author:     aps-lel
*  Date:       2011-04-15
*******************************************************************************/
void CSendBeps404::GetSubstrBySeparat(const string & strOristr, 
                string &strLeft, string &strRight, const char chSep )
{
	strLeft = "";
	strRight = "";
	string::size_type posBegin  = 0;
	int iPosRet = 0;

	iPosRet  = strOristr.find(chSep,posBegin);

	if (-1 ==iPosRet)//û���ҵ��ָ�������ԭʼ������strLeft
	{
		strLeft = strOristr;
		strRight = "";
		return ;
	}

	strLeft = strOristr.substr(posBegin,iPosRet);
	strRight = strOristr.substr(iPosRet+1);
}


