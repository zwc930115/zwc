/******************************************************************** 
�ļ����� sendbeps123.cpp
�����ˣ� zwy
��  �ڣ� 2011-03-07
�޸��ˣ� 
��  �ڣ� 
��  ���� С������beps.123���Ĵ�����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps123.h"


CSendBeps123::CSendBeps123(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{

}

CSendBeps123::~CSendBeps123()
{

}

INT32 CSendBeps123::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps123::doWorkSelf");
    
    //��ҵ����л�ȡ����    
    getData();
    
    //��pmts����
    buildPmtsMsg();

    //����һ������
    insertSum();
    
    //�޸���ϸҵ��İ����
    UpdateSndList(PR_HVBP_08);
    
    //����Զ�̶���
    AddQueue();
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps123::doWorkSelf"); 
    
    return 0;
}


int CSendBeps123::getData()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps123::getData");
    
	SETCTX(m_cBpbcoutsendlist);

  	m_cBpbcoutsendlist.m_dbtrbrnchid  = m_sSendOrg;
  	m_cBpbcoutsendlist.m_txid         = m_sMsgId;
  	
  	iRet = m_cBpbcoutsendlist.findByPK();
  	
  	if (SQLNOTFOUND == iRet)
	{
		sprintf(m_sErrMsg,"С�����ʽ����ϸ�����Ҳ���ָ��ҵ��[%s],[%s],[%d][%s]", 
            m_sSendOrg, m_sMsgId, iRet, m_cBpbcoutsendlist.GetSqlErr());
		
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);
		
	} 	
	else if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg,"��ѯС�����ʽ����ϸ����������[%d][%s]", iRet, m_cBpbcoutsendlist.GetSqlErr());
		
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}
	
  	bool bRet = GetMsgIdValue(m_dbproc, m_sPkgDtNSn, eMsgId, SYS_BEPS);
	if(false == bRet)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get PkgDtNSn fail");
		PMTS_ThrowException(PRM_FAIL);
	}
		
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps123::getData"); 
    
	return iRet;
}

int CSendBeps123::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps123::CheckValues");

    int iRet = -1;

    //������޼��
    iRet = isOutOfLimit(m_dbproc, 
                        m_cBpbcoutsendlist.m_msgtp.c_str(), 
                        m_cBpbcoutsendlist.m_purpprtry.c_str(),
                        m_cBpbcoutsendlist.m_amount, 
                        m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_AMT_OUT_OF_LIMIT, m_sErrMsg);
    }
    
    //�����кż��
    iRet = isBankRight(m_dbproc, m_cBpbcoutsendlist.m_instddrctpty.c_str(), m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_RECVBANK_CHECK_FAIL, m_sErrMsg);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps123::CheckValues"); 
    return 0;
}

int CSendBeps123::insertSum()
{
	Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps123::insertSum");

	SETCTX(m_cBpbcoutsndcl);
	
	m_cBpbcoutsndcl.m_workdate     = m_sWorkDate;
	m_cBpbcoutsndcl.m_consigdate   = m_sWorkDate;
  	m_cBpbcoutsndcl.m_msgtp        = m_cBpbcoutsendlist.m_msgtp;
  	m_cBpbcoutsndcl.m_msgid        = m_sPkgDtNSn;
  	m_cBpbcoutsndcl.m_mesgid       = m_sMsgRefId;
  	m_cBpbcoutsndcl.m_mesgrefid    = m_sMsgRefId;
  	m_cBpbcoutsndcl.m_instgdrctpty = m_cBpbcoutsendlist.m_instgdrctpty;
  	m_cBpbcoutsndcl.m_instddrctpty = m_cBpbcoutsendlist.m_instddrctpty;
  	m_cBpbcoutsndcl.m_srcflag      = "1";
  	m_cBpbcoutsndcl.m_checkstate   = PR_CNCH_00;
  	m_cBpbcoutsndcl.m_procstate    = PR_HVBP_08;
  	m_cBpbcoutsndcl.m_nboftxs      = 1;
  	m_cBpbcoutsndcl.m_ctrlsum      = m_cBpbcoutsendlist.m_amount;
  	m_cBpbcoutsndcl.m_sapsnboftxs  = 0;
  	m_cBpbcoutsndcl.m_ctrlsapssum  = 0;
  	m_cBpbcoutsndcl.m_realtimeflag = "1";
  	m_cBpbcoutsndcl.m_dgtsign      = "DIGITSIGN";
  	m_cBpbcoutsndcl.m_npcmsg       = m_sMsgTxt;
  	
  	iRet = m_cBpbcoutsndcl.insert();
  	
  	if (DUPLICATE_KEY == iRet) 
	{
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "���������Ѵ���");
		
	}
	else if(SQL_SUCCESS != iRet)
	{
		sprintf(m_sErrMsg,"�������˻��ܱ���������ʧ��[%d][%s]", iRet, m_cBpbcoutsndcl.GetSqlErr());
		
		Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_sErrMsg);
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps123::insertSum"); 
    
	return iRet;
}

void CSendBeps123::GetTag2ND(const string& QryVal, const string& QryStr, int& iDepth)
{
    string strTemp = "";
    // if( RTN_SUCCESS == GetTagVal(strTemp, QryStr, QryVal))
    {
        strTemp = QryVal + QryStr;
        m_oBeps123.SetUstrd(iDepth, strTemp.c_str());
        iDepth++;
    }
}

void CSendBeps123::AddSign123()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBeps123::DigitSign123...");

	char   sSignedStr[4096 + 1] = {0};
	
	m_oBeps123.getOriSignStr();
	
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
	    "m_oBeps123.m_sSignBuff=[%s]", m_oBeps123.m_sSignBuff.c_str());
	    
	AddSign(m_oBeps123.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_cBpbcoutsendlist.m_instgdrctpty.c_str());
	
	m_oBeps123.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBeps123::DigitSign123...");
}

 int CSendBeps123::buildPmtsMsg()
 {
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps123::buildPmtsMsg");

	int     iDepth = 0;
    int     iRet = -1;iDepth = 0;

    //���ñ���ͷҪ��
	bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get MsgRefId fail");
	    PMTS_ThrowException(PRM_FAIL);
    }
	m_oBeps123.m_PMTSHeader.SetPMTSXMlHeader("BEPS", 
							m_sWorkDate,
							m_cBpbcoutsendlist.m_instgdrctpty.c_str(),
							m_cBpbcoutsendlist.m_instddrctpty.c_str(),
			  				"beps.123.001.01",
			  				m_sMsgRefId);

    //�ֶθ�ֵ
	char sTemp[32] = {0};
	m_oBeps123.MsgId                        = m_sPkgDtNSn;
	m_oBeps123.CreDtTm                      = m_sIsoWorkDate;
	m_oBeps123.NbOfTxs                      = "1";	
	m_oBeps123.EndToEndId                   = m_cBpbcoutsendlist.m_txid;
	m_oBeps123.TxId						    = m_cBpbcoutsendlist.m_txid		;
	m_oBeps123.ChrgBr                       = "DEBT";
    m_oBeps123.SttlmMtd                     = "CLRG";//�̶���дCLRG
	m_oBeps123.CtgyPurpPrtry 				= m_cBpbcoutsendlist.m_pmttpprtry ;
	m_oBeps123.DbtrNm                       = m_cBpbcoutsendlist.m_dbtnm		;
	m_oBeps123.DbtrAdrLine                  = m_cBpbcoutsendlist.m_dbtaddr		;
	m_oBeps123.DbtrAcctId                   = m_cBpbcoutsendlist.m_dbtracctid		;
	m_oBeps123.DbtrAcctIssr                 = m_cBpbcoutsendlist.m_dbtrissr		;
	m_oBeps123.DbtrAgtId                    = m_cBpbcoutsendlist.m_dbtrbrnchid		;
	m_oBeps123.DbtrAgtMmbId                 = m_cBpbcoutsendlist.m_instgdrctpty;
	m_oBeps123.CdtrAgtMmbId                 = m_cBpbcoutsendlist.m_instddrctpty;
	m_oBeps123.CdtrAgtId                    = m_cBpbcoutsendlist.m_cdtrbrnchid		;
	m_oBeps123.CdtrNm                       = m_cBpbcoutsendlist.m_cdtrnm		;
	m_oBeps123.CdtrAdrLine                  = m_cBpbcoutsendlist.m_cdtaddr		;
	m_oBeps123.CdtrAcctId                   = m_cBpbcoutsendlist.m_cdtracctid		;
	m_oBeps123.CdtrAcctIssr                 = m_cBpbcoutsendlist.m_cdtrissr	;
	sprintf(sTemp,"%.2f",m_cBpbcoutsendlist.m_amount);
	m_oBeps123.CtrlSum                      = sTemp;//��ϸҵ���ܽ��
    m_oBeps123.IntrBkSttlmAmt               = sTemp;//������
	m_oBeps123.PurpPrtry                    = m_cBpbcoutsendlist.m_purpprtry		;
	m_oBeps123.Ccy                          = m_cBpbcoutsendlist.m_currency;
    m_oBeps123.DbtrAcctIssrNm               = m_cBpbcoutsendlist.m_dbtrissrnm;
    m_oBeps123.CdtrAcctIssrNm               = m_cBpbcoutsendlist.m_cdtrissrnm;
    

    GetTag2ND("/H01/", m_cBpbcoutsendlist.m_addtlinf, iDepth);//����
    GetTag2ND("/H02/", m_cBpbcoutsendlist.m_addtlinf2, iDepth);//����2
    GetTag2ND("/HA1/", m_cBpbcoutsendlist.m_remark, iDepth);//��ע
    GetTag2ND("/HA2/", m_cBpbcoutsendlist.m_remark2, iDepth);//��ע2
    	
    AddSign123();
    
    //�鱨��
	iRet = m_oBeps123.CreateXml();
	if (0 != iRet)
	{
        sprintf(m_sErrMsg,"�������˱���ʧ��[%d]",iRet);
        
        Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);        
        PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, m_sErrMsg);
	}

    m_sMsgTxt = m_oBeps123.m_sXMLBuff;
    
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "[%s]", m_sMsgTxt.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps123::buildPmtsMsg"); 

    return iRet;
 }
 
 int CSendBeps123::UpdateSndList(LPCSTR sProcstate)
 {
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CSendBeps123::UpdateSndList");

    sprintf(m_sSqlStr, "UPDATE BP_BCOUTSENDLIST t SET t.STATETIME = sysdate,"
                 "t.MSGID = '%s' ," \
                 "t.PROCSTATE = '%s'"  \
                 " WHERE  t.txid = '%s' " , \
                 m_sPkgDtNSn,
                 sProcstate,
                 m_sMsgId);
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sSqlStr = [%s]",m_sSqlStr);
    iRet = m_cBpbcoutsendlist.execsql(m_sSqlStr);
    if (iRet == SQLNOTFOUND)
    {
     sprintf(m_sErrMsg,  "��m_cBpbcoutsendlist����û���ҵ�����[txid=%s],[%d][%s]", m_sMsgId, iRet, m_cBpbcoutsendlist.GetSqlErr());
     Trace(L_ERROR, __FILE__, __LINE__, NULL,m_sErrMsg);

    }
    else if (iRet != SQL_SUCCESS)
    {
     sprintf(m_sErrMsg,  "update m_cBpbcoutsendlist  is error![%d][%s]", iRet, m_cBpbcoutsendlist.GetSqlErr());
     Trace(L_ERROR, __FILE__, __LINE__, NULL,m_sErrMsg);
     PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps123::UpdateSndList");
    return 0;
 }
 

