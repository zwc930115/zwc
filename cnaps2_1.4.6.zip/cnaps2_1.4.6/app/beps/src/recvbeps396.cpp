/******************************************************************** 
文件名： recvbeps396.cpp
创建人： handongfeng
日  期   ： 2011-03-07
修改人： 
日  期： 
描  述： 
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbeps396.h"

CRecvbeps396::CRecvbeps396()
{

}

CRecvbeps396::~CRecvbeps396()
{
}

void CRecvbeps396::GetTag2ND(int& iDepth, string& DbStr, const string& Tag)
{
    string strTmp;
    strTmp = m_beps396.GetTxRef(iDepth);
    GetTagVal(DbStr, strTmp, Tag);
    iDepth++;
}

void CRecvbeps396::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "ENTER CRecvbeps396::SetData");

    m_Bpgettx.m_msgid = m_beps396.Id; 
    m_Bpgettx.m_workdate = m_beps396.Id.substr(0, 7); 
    m_Bpgettx.m_msgtp = "beps.396.001.01";
    m_Bpgettx.m_mesgid = m_beps396.m_PMTSHeader.getMesgID();
    m_Bpgettx.m_mesgrefid = m_beps396.m_PMTSHeader.getMesgRefID();
    m_Bpgettx.m_procstate = PR_HVBP_01;
    m_Bpgettx.m_mbmsgid = "2";//表示行内发起
    m_Bpgettx.m_rsflag  = "2";

    int i = 0;
    GetTag2ND(i, m_Bpgettx.m_instgdrctpty, "/A00/" );
    GetTag2ND(i, m_Bpgettx.m_instgpty, "/A22/");
    GetTag2ND(i, m_Bpgettx.m_instddrctpty, "/A01/");
    GetTag2ND(i, m_Bpgettx.m_purpprtry, "/FA5/");
    GetTag2ND(i, m_Bpgettx.m_chrgid, "/K35/");
    GetTag2ND(i, m_Bpgettx.m_corprtnid, "/K37/");
    GetTag2ND(i, m_Bpgettx.m_cusflag, "/K36/");

    SETCTX(m_Bpgettx);
    iRet = m_Bpgettx.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg,"insert error[%d][%s]", iRet,m_Bpgettx.GetSqlErr());
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);		
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "LEAVE CRecvbeps396::SetData");
    return ;
}

int CRecvbeps396::Work(LPCSTR szMsg)
{
    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps396::Work()");

    // 解析报文
    unPack(szMsg);

    SetData();

    //核签
    //CheckSign396();

    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps396::Work()");
    return OPERACT_SUCCESS;
}

INT32 CRecvbeps396::unPack(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps396::unPack()...");
    // 报文是否为空
    if (NULL == szMsg || '\0' == szMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空"); 
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "报文为空");
    }
    //获取工作日期
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;    

    // 解析报文
    if (OPERACT_SUCCESS != m_beps396.ParseXml(szMsg))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错! ");	
        PMTS_ThrowException(OPT_PRS_MSG_FAIL);
        return OPERACT_FAILED;
    }

    m_strMsgID = m_beps396.Id;
    ZFPTLOG.SetLogInfo("396", m_strMsgID.c_str());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps396::unPack()...");
    return OPERACT_SUCCESS;
}

