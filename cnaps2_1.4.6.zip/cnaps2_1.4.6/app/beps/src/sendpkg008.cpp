
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendpkg008.h"
using namespace ZFPT;

CSendPkg008::CSendPkg008(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
    m_fTtlAmt   = 0.0;
    m_fTtlAmtOk = 0.0;
    m_iTtlCnt   = 0;
    m_iTtlCntOk = 0;
    m_iBizTp    = 0;
    memset(m_szPkgNo, 0x00, sizeof(m_szPkgNo));
}

CSendPkg008::~CSendPkg008()
{
}


//__wsh 2012-08-16 ҵ�������
INT32 CSendPkg008::doWorkSelf(void)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CSendPkg008::doWorkSelf");
	int iRet = -1;

	//��ȡҵ������
	GetData();

	//����NPC����
	CreateNpcMsg();

	//����ҵ��״̬
	UpdateState();

	//��¼����
	InsertData_cl();

	//���ͱ���
	iRet = AddQueue();

	Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CSendPkg008::doWorkSelf");

	return iRet;
}

//__wsh 2012-08-16 ��ȡҵ�����ݣ�
int CSendPkg008::GetData(void)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CSendPkg008::GetData");

	int iRet = -1;

	SETCTX(m_bpsndlist);

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__ҵ������=[%s]", m_BusinessType);

	m_iBizTp = atoi(m_BusinessType);

	if(m_iBizTp == 30104 || m_iBizTp == 30105){//Ʊ��
		m_bpsndlist.m_dbtrbrnchid = m_sSendOrg;
		m_bpsndlist.m_txid        = m_sMsgId;
		iRet = m_bpsndlist.findByPK();

		m_strPkgTp = "008";
		m_strElNo  = "007";
	}
	else{//��ǻ�ִ
		string strSql = " msgid='";
		strSql += m_sMsgId;
		strSql += "' and (instgdrctpty='";
		strSql += m_sSendOrg;
		strSql += "' or dbtrbrnchid='";
		strSql += m_sSendOrg;
		strSql += "') ";
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strSql=[%s]", strSql.c_str());
		iRet = m_bpsndlist.find(strSql);

		m_strPkgTp = m_sMsgType;
		m_strElNo  = "006";
	}
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "m_strPkgTp=[%s]", m_strPkgTp.c_str());
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "m_strElNo=[%s]", m_strElNo.c_str());

	if(iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
			"[bp_bcoutsendlist][%s][%s]���ҳ���:%s",
			m_sSendOrg, m_sMsgId, m_bpsndlist.GetSqlErr());
		PMTS_ThrowException(DB_FIND_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CSendPkg008::GetData");

	return iRet;
}

//__wsh 2012-08-16 ���ҵ��ͷ Ҫ��FillBizbody�����
void CSendPkg008::FillBizHead(void)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CSendPkg008::FillBizHead");

	strncpy(m_cPkg008.stHead008.szPkgType,
			m_strPkgTp.c_str(),
			sizeof(m_cPkg008.stHead008.szPkgType)-1); //�����ͺ�

	strncpy(m_cPkg008.stHead008.szOdfiCode,
			m_bpsndlist.m_instgdrctpty.c_str(),
			sizeof(m_cPkg008.stHead008.szOdfiCode)-1); //�����������к�

	strncpy(m_cPkg008.stHead008.szRdfiCode,
			m_bpsndlist.m_instddrctpty.c_str(),
			sizeof(m_cPkg008.stHead008.szRdfiCode)-1); //�����������к�

	strncpy(m_cPkg008.stHead008.szPkgCDate,
			m_szPkgNo,
			sizeof(m_cPkg008.stHead008.szPkgCDate)-1); //��ί������

	strncpy(m_cPkg008.stHead008.szPkgserNo,
			m_szPkgNo + 8,
			sizeof(m_cPkg008.stHead008.szPkgserNo)-1); //�����

	snprintf(m_cPkg008.stHead008.szDetailCnt,
			sizeof(m_cPkg008.stHead008.szDetailCnt),
			"%08d", m_iTtlCnt);                        //��ϸ�ܱ���

	snprintf(m_cPkg008.stHead008.szDetailAmt,
			sizeof(m_cPkg008.stHead008.szDetailAmt),
			"RMB%015.0f", m_fTtlAmt * 100.0);          //��ϸ�ܽ��

	snprintf(m_cPkg008.stHead008.szDetailSuccCnt,
			sizeof(m_cPkg008.stHead008.szDetailSuccCnt),
			"%08d", m_iTtlCntOk);                      //�ɹ���ϸ�ܱ���

	snprintf(m_cPkg008.stHead008.szDetailSuccAmt,
			sizeof(m_cPkg008.stHead008.szDetailSuccAmt),
			"RMB%015.0f", m_fTtlAmtOk * 100.0);        //�ɹ���ϸ�ܽ��

	if(m_iBizTp == 30104 || m_iBizTp == 30105){//Ʊ��
		strncpy(m_cPkg008.stHead008.szOldPkgType,
				"999",
				sizeof(m_cPkg008.stHead008.szOldPkgType)-1);  //ԭ�����ͺ�

		strncpy(m_cPkg008.stHead008.szOldOdfiCode,
				m_bpsndlist.m_instddrctpty.c_str(),
				sizeof(m_cPkg008.stHead008.szOldOdfiCode)-1);  //ԭ������������

		strncpy(m_cPkg008.stHead008.szOldPkgCDate,
				m_bpsndlist.m_workdate.c_str(),
				sizeof(m_cPkg008.stHead008.szOldPkgCDate)-1);  //ԭ��ί������

		strncpy(m_cPkg008.stHead008.szOldPkgserNo,
				"99999999",
				sizeof(m_cPkg008.stHead008.szOldPkgserNo)-1);  //ԭ�����
	}
	else{//��ǻ�ִ
		strncpy(m_cPkg008.stHead008.szOldPkgType,
				m_bpsndlist.m_orgnlmsgtp.c_str()+3,
				sizeof(m_cPkg008.stHead008.szOldPkgType)-1);  //ԭ�����ͺ�

		strncpy(m_cPkg008.stHead008.szOldOdfiCode,
				m_bpsndlist.m_oriinstgdrctpty.c_str(),
				sizeof(m_cPkg008.stHead008.szOldOdfiCode)-1);  //ԭ������������

		strncpy(m_cPkg008.stHead008.szOldPkgCDate,
				m_bpsndlist.m_orgnlmsgid.c_str(),
				sizeof(m_cPkg008.stHead008.szOldPkgCDate)-1);  //ԭ��ί������

		strncpy(m_cPkg008.stHead008.szOldPkgserNo,
				m_bpsndlist.m_orgnlmsgid.c_str()+8,
				sizeof(m_cPkg008.stHead008.szOldPkgserNo)-1);  //ԭ�����
	}

	Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CSendPkg008::FillBizHead");
}

//__wsh 2012-08-16 ����Ԫ�ؼ�
void CSendPkg008::FillBizBody(void)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CSendPkg008::FillBizBody");

	m_cPkg008.m_szCurElementNo = m_strElNo;
	m_strElNo == "006" ? SetEl_006() : SetEl_007();

	Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CSendPkg008::FillBizBody");
}

//__wsh 2012-08-16 ���ý�ǻ�ִ006Ԫ�ؼ�
void CSendPkg008::SetEl_006(void)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CSendPkg008::SetEl_006");

	int iRet = -1;

	while(true){
		iRet = m_bpsndlist.fetch();
		if(iRet != SQL_SUCCESS){
			if(iRet == SQLNOTFOUND){
				Trace(L_DEBUG, __FILE__, __LINE__,
								NULL, "__No More Data!!");
				break;
			}
			else{
				Trace(L_ERROR, __FILE__, __LINE__, NULL,
				   "[bp_bcoutsendlist]���ҳ���:%s", m_bpsndlist.GetSqlErr());
				m_bpsndlist.closeCursor();
				PMTS_ThrowException(DB_OPT_FAIL);
			}
		}
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "[%s]msgtp[%s]msgid[%s]txid[%s]",
				m_bpsndlist.m_instgdrctpty.c_str(), m_bpsndlist.m_msgtp.c_str(),
				m_bpsndlist.m_msgid.c_str(), m_bpsndlist.m_txid.c_str());

		++m_iTtlCnt;
		m_fTtlAmt += m_bpsndlist.m_oriamount;

		m_cPkg008.m_szCurElementNo = m_strElNo; //Ҫ�ؼ�����

		strncpy(m_cPkg008.stBody006.szConsignDate,
				m_bpsndlist.m_txid.c_str(),
				sizeof(m_cPkg008.stBody006.szConsignDate) - 1); //ί������

		strncpy(m_cPkg008.stBody006.szTxssNo,
				m_bpsndlist.m_txid.c_str() + 8,
				sizeof(m_cPkg008.stBody006.szTxssNo) - 1);      //֧�����

		strncpy(m_cPkg008.stBody006.szOriTrxsType,
				m_bpsndlist.m_pmttpprtry.c_str(),
				sizeof(m_cPkg008.stBody006.szOriTrxsType) - 1); //ԭҵ������

		strncpy(m_cPkg008.stBody006.szOriOdfiCode,
				m_bpsndlist.m_cdtrbrnchid.c_str(),
				sizeof(m_cPkg008.stBody006.szOriOdfiCode) - 1); //ԭ������

		strncpy(m_cPkg008.stBody006.szOriRdfiCode,
				m_bpsndlist.m_dbtrbrnchid.c_str(),
				sizeof(m_cPkg008.stBody006.szOriRdfiCode) - 1); //ԭ������

		strncpy(m_cPkg008.stBody006.szOriConsignDate,
				m_bpsndlist.m_oritxid.c_str(),
				sizeof(m_cPkg008.stBody006.szOriConsignDate) - 1); //ԭί������

		strncpy(m_cPkg008.stBody006.szOriTxssNo,
				m_bpsndlist.m_oritxid.c_str() + 8,
				sizeof(m_cPkg008.stBody006.szOriTxssNo) - 1);   //ԭ�������

		snprintf(m_cPkg008.stBody006.szOriAmount,
				sizeof(m_cPkg008.stBody006.szOriAmount),
				"%015.0f", m_bpsndlist.m_oriamount * 100.0);    //ԭ���׽��

		strncpy(m_cPkg008.stBody006.szReturnReceiptStatus,
				m_bpsndlist.m_replystate.c_str(),
				sizeof(m_cPkg008.stBody006.szReturnReceiptStatus) - 1);//ҵ���ִ״̬
		if(m_bpsndlist.m_replystate == "00"){
			//�ɹ��ܽ��ɹ�����
			m_fTtlAmtOk += m_bpsndlist.m_amount;
			++m_iTtlCntOk;
		}

		//�ۿ�����
		//������
		//����
		m_cPkg008.AddBussiness(m_strElNo.c_str());

	}//end while
	//�ر��α�
	m_bpsndlist.closeCursor();

	Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CSendPkg008::SetEl_006");
}

//__wsh 2012-08-16 ����Ʊ��007Ԫ�ؼ�
void CSendPkg008::SetEl_007(void)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CSendPkg008::SetEl_007");

	strncpy(m_cPkg008.stBody007.szTrxsType,
			m_bpsndlist.m_pmttpprtry.c_str(),
			sizeof(m_cPkg008.stBody007.szTrxsType)-1); //ҵ������

	strncpy(m_cPkg008.stBody007.szConsignDate,
			m_bpsndlist.m_consigdate.c_str(),
			sizeof(m_cPkg008.stBody007.szConsignDate)-1); //ί������

    //���ݿ�洢˳��
	//72C:֧Ʊ����:72C:ԭƱ��ί������:72C:ԭƱ���������
	//:72C:��ִ״̬:72C:��Ʊ����:72C:��Ʊ����˵��

	string strVal = "";

	GetTagVal(strVal, m_bpsndlist.m_cstmrcdttrfaddtlinf, "72C:", 2);
	strncpy(m_cPkg008.stBody007.szOriCISConsignDate,
			strVal.c_str(),
			sizeof(m_cPkg008.stBody007.szOriCISConsignDate)-1); //ԭƱ��ί������

	strncpy(m_cPkg008.stBody007.szTxssNo,
			m_bpsndlist.m_txid.c_str()+8,
			sizeof(m_cPkg008.stBody007.szTxssNo)-1); //�������

	strVal.clear();
	GetTagVal(strVal, m_bpsndlist.m_cstmrcdttrfaddtlinf, "72C:", 3);
	snprintf(m_cPkg008.stBody007.szOrigCISTxssNo,
	        sizeof(m_cPkg008.stBody007.szOrigCISTxssNo),
			"%08s", strVal.c_str()); //ԭƱ���������

	strVal.clear();
	GetTagVal(strVal, m_bpsndlist.m_cstmrcdttrfaddtlinf, "72C:", 1);
	Trim(strVal);
	snprintf(m_cPkg008.stBody007.szChequeNo,
	        sizeof(m_cPkg008.stBody007.szChequeNo),
			"%012s", strVal.c_str()); //֧Ʊ����

	strncpy(m_cPkg008.stBody007.szPayOpenAccBkCode,
			m_bpsndlist.m_dbtrissr.c_str(),
			sizeof(m_cPkg008.stBody007.szPayOpenAccBkCode)-1); //�����˿����к�

	strncpy(m_cPkg008.stBody007.szPayerAcc,
			m_bpsndlist.m_dbtracctid.c_str(),
			sizeof(m_cPkg008.stBody007.szPayerAcc)-1); //�������˺�

	SetFieldAsGbk(m_bpsndlist.m_dbtnm,
			m_cPkg008.stBody007.szPayerName,
			sizeof(m_cPkg008.stBody007.szPayerName)-1); //����������

	strncpy(m_cPkg008.stBody007.szRecOpenAccBkCode,
			m_bpsndlist.m_cdtrissr.c_str(),
			sizeof(m_cPkg008.stBody007.szRecOpenAccBkCode)-1); //�տ��˿����к�

	strncpy(m_cPkg008.stBody007.szRecipientAcc,
			m_bpsndlist.m_cdtracctid.c_str(),
			sizeof(m_cPkg008.stBody007.szRecipientAcc)-1); //�տ����˺�

	SetFieldAsGbk(m_bpsndlist.m_cdtrnm,
			m_cPkg008.stBody007.szRecipientName,
			sizeof(m_cPkg008.stBody007.szRecipientName)-1); //�տ�������

	strncpy(m_cPkg008.stBody007.szOdfiCode,
			m_bpsndlist.m_dbtrbrnchid.c_str(),
			sizeof(m_cPkg008.stBody007.szOdfiCode)-1); //�������к�

	strncpy(m_cPkg008.stBody007.szRdfiCode,
			m_bpsndlist.m_cdtrbrnchid.c_str(),
			sizeof(m_cPkg008.stBody007.szRdfiCode)-1); //�������к�

	snprintf(m_cPkg008.stBody007.szAmount,
			sizeof(m_cPkg008.stBody007.szAmount),
			"%015.0f", m_bpsndlist.m_amount * 100.0); //���

	m_iTtlCnt = 1;
	m_fTtlAmt = m_bpsndlist.m_amount;

	strVal.clear();
	GetTagVal(strVal, m_bpsndlist.m_cstmrcdttrfaddtlinf, "72C:", 4);
	strncpy(m_cPkg008.stBody007.szReturnReceiptStatus,
			strVal.c_str(),
			sizeof(m_cPkg008.stBody007.szReturnReceiptStatus)-1); //��ִ״̬

	if(strVal == "09"){//״̬Ϊ��Ʊʱ�� ��Ʊ����Ϊǿ����
		strVal.clear();
		GetTagVal(strVal, m_bpsndlist.m_cstmrcdttrfaddtlinf, "72C:", 5);
		snprintf(m_cPkg008.stBody007.szReturnCode,
				sizeof(m_cPkg008.stBody007.szReturnCode),
				"%-10s", strVal.c_str()); //��Ʊ����

		strVal.clear();
		GetTagVal(strVal, m_bpsndlist.m_cstmrcdttrfaddtlinf, "72C:", 6);
		SetFieldAsGbk(strVal,
				m_cPkg008.stBody007.szPost,
				sizeof(m_cPkg008.stBody007.szPost)-1);
	}
	else{
		m_iTtlCntOk = 1;
		m_fTtlAmtOk = m_bpsndlist.m_amount;
	}

	m_cPkg008.AddBussiness(m_strElNo.c_str());

	Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CSendPkg008::SetEl_007");
}

//__wsh 2012-08-16 ��Ѻ
void CSendPkg008::AddMac008(void) 
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CSendPkg008::AddMac008");

	char szMac[40 + 1] = {0};
	string strCodeMac;//ȡ��Ѻ��
	m_cPkg008.GetMacStr(m_cPkg008, strCodeMac);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL,
				"__strCodeMac = [%s]", strCodeMac.c_str());

	int iRetCode = CodeMac(m_dbproc, strCodeMac.c_str(),
								m_bpsndlist.m_instgdrctpty.c_str(), szMac);
	if (RTN_SUCCESS != iRetCode) {
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "��Ѻʧ��");
		PMTS_ThrowException(__FILE__, __LINE__, OPT_CODEMAC_FAIL, "��Ѻʧ��");
	}
	memcpy(m_cPkg008.stHead008.szPkgDest, szMac, sizeof(szMac)-1);

	//string src = "{2:006         }{3::30A:20130610:0BC:00007839:0BH:00114:CC1:402584009991:CC2:503290000007:051:20130610:005:00034760:33S:000000000000111:CIA:00:BSE::BSN::72A:}{2:006         }{3::30A:20130610:0BC:00007840:0BH:00114:CC1:402584009991:CC2:503290000007:051:20130610:005:00034762:33S:000000000000122:CIA:00:BSE::BSN::72A:}{2:006         }{3::30A:20130610:0BC:00007841:0BH:00114:CC1:402584009991:CC2:503290000007:051:20130610:005:00034763:33S:000000000000133:CIA:00:BSE::BSN::72A:}{2:006         }{3::30A:20130610:0BC:00007842:0BH:00114:CC1:402584009991:CC2:503290000007:051:20130610:005:00034764:33S:000000000000144:CIA:00:BSE::BSN::72A:}";
	//string dst = "";
	//doMd5(src, dst);
	//Trace(L_INFO,  __FILE__,  __LINE__, NULL, "dst=[%s]", dst.c_str());

	Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CSendPkg008::AddMac008");
}

//__wsh 2012-08-16 ����NPC����
int CSendPkg008::CreateNpcMsg(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CSendPkg008::CreateNpcMsg");

	int iRet = -1;
	
	//���ҵ����Ҫ��
	FillBizBody();

	//��ȡͨ�ż���ʶ
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
	       "__INSTGDRCTPTY[%s]", m_bpsndlist.m_instgdrctpty.c_str());
	if(!GetMsgIdValue(m_dbproc, m_sMsgRefId,
				eRefId, SYS_BEPS, m_bpsndlist.m_instgdrctpty.c_str())){
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ȡͨ�ű�ʶʧ��!");
		PMTS_ThrowException(OPT_GET_MESGREFID_FAIL);
	}
	
	//��ȡ���ı�ʶ
	if(m_iBizTp == 30104 || m_iBizTp == 30105){
	    if(!GetMsgIdValue(m_dbproc, m_szPkgNo,
			    eMsgId, SYS_BEPS, m_bpsndlist.m_instgdrctpty.c_str())){
    		Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ȡ���ı�ʶʧ��!");
    		PMTS_ThrowException(OPT_GET_MESGREFID_FAIL);
    	}
    	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__m_szPkgNo=[%s]", m_szPkgNo);
	}
	else{
		strncpy(m_szPkgNo, m_sMsgId, sizeof(m_szPkgNo)-1);
	}

	//�鱨ͷ
	iRet = m_cPkg008.CreateMsgHeader(
			m_strPkgTp.c_str(),
			m_bpsndlist.m_instgdrctpty.c_str(),
			m_bpsndlist.m_instddrctpty.c_str(),
		    m_sMsgRefId,
		    m_sMsgRefId,
		    m_bpsndlist.m_workdate.c_str(),
		    "1");

	Trace(L_DEBUG, __FILE__, __LINE__, NULL,
					"__%s", m_cPkg008.m_szMsgHead.c_str());

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "m_BusinessType=%s", m_BusinessType);

	//���ҵ��ͷ
	FillBizHead();

	Trace(L_DEBUG, __FILE__, __LINE__, NULL,
					"__%s", m_cPkg008.m_szPkgBody.c_str());
	//��Ѻ
	AddMac008();

	//�鱨��β
	m_cPkg008.CreateMsgTail();

	//�鱨��
	iRet = m_cPkg008.CreateMsg();

	m_sMsgTxt = m_cPkg008.m_szMsgText;

	Trace(L_INFO,  __FILE__,  __LINE__,
				 NULL, "__m_sMsgTxt=%s", m_sMsgTxt.c_str());

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendPkg008::CreateNpcMsg");

	return iRet;
}

//__wsh 2012-08-16 ����ҵ��״̬
int CSendPkg008::UpdateState(void)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CSendPkg008::UpdateState");

	int iRet = -1;

	string strSql = "";

	//���»��ܱ�,��ǻ�ִ���£� Ʊ��������
	if(m_iBizTp != 30104 && m_iBizTp != 30105){
		string strSql = "update bp_bcoutsndcl set procstate='";
		strSql += PR_HVBP_08;
		strSql += "', mesgid='";
		strSql += m_sMsgRefId;
		strSql += "', mesgrefid='";
		strSql += m_sMsgRefId;
		strSql += "', statetime=sysdate where instgdrctpty='";
		strSql += m_bpsndlist.m_instgdrctpty;
		strSql += "' and msgid='";
		strSql += m_sMsgId;
		strSql += "' ";

		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strSql=[%s]", strSql.c_str());

		SETCTX(m_bpsndcl);
		iRet = m_bpsndcl.execsql(strSql);
		if(iRet != SQL_SUCCESS){
			Trace(L_ERROR, __FILE__, __LINE__, NULL,
					"[bp_bcoutsndcl]���³���:%s", m_bpsndcl.GetSqlErr());
			PMTS_ThrowException(DB_UPDATE_FAIL);
		}
	}

	//������ϸ
	strSql.clear();
	strSql = "update bp_bcoutsendlist set procstate='";
	strSql += PR_HVBP_08;
	if(m_iBizTp==30104 || m_iBizTp==30105){
	    strSql += "', msgid='";
	    strSql += m_szPkgNo;
	}
	strSql += "', statetime=sysdate where ";
	strSql += (m_iBizTp==30104 || m_iBizTp==30105 ? "dbtrbrnchid='" : "instgdrctpty='");
	strSql += m_sSendOrg;
	strSql += (m_iBizTp==30104 || m_iBizTp==30105 ? "' and txid='" : "' and msgid='");
	strSql += m_sMsgId;
	strSql += "' ";

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strSql=[%s]", strSql.c_str());

	iRet = m_bpsndlist.execsql(strSql);
	if(iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[bp_bcoutsendlist]���³���:%s", m_bpsndlist.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CSendPkg008::UpdateState");

	return iRet;
}

//__wsh 2012-08-16 ������ܱ�
int CSendPkg008::InsertData_cl(void)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CSendPkg008::InsertData_cl");

	int iRet = -1;

	//��ǻ�ִ��������ܱ�
	if(m_iBizTp != 30104 && m_iBizTp != 30105){
		return 0;
	}

    m_bpsndcl.m_checkstate  = PR_CNCH_00 ;
	m_bpsndcl.m_workdate    = m_bpsndlist.m_workdate;
	m_bpsndcl.m_consigdate  = m_bpsndlist.m_consigdate;
	m_bpsndcl.m_msgtp       = m_bpsndlist.m_msgtp;
	m_bpsndcl.m_mesgid      = m_sMsgRefId;
	m_bpsndcl.m_mesgrefid   = m_sMsgRefId;
	m_bpsndcl.m_msgid       = m_szPkgNo;
	m_bpsndcl.m_instgdrctpty= m_bpsndlist.m_instgdrctpty ;
	m_bpsndcl.m_instddrctpty= m_bpsndlist.m_instddrctpty ;
	m_bpsndcl.m_npcmsglen   = m_bpsndlist.m_npcmsglen;
	m_bpsndcl.m_npcfilename = m_bpsndlist.m_npcmsg;
	m_bpsndcl.m_busistate   = m_bpsndlist.m_busistate;
	m_bpsndcl.m_rjctinf     = m_bpsndlist.m_rjctinf;
	m_bpsndcl.m_procstate   = PR_HVBP_08;
	m_bpsndcl.m_netgdt      = m_bpsndlist.m_netgdt;
	m_bpsndcl.m_netgrnd     = m_bpsndlist.m_netgrnd;
	m_bpsndcl.m_statetime   = m_bpsndlist.m_statetime;
	m_bpsndcl.m_srcflag     = m_bpsndlist.m_srcflag ;
	m_bpsndcl.m_rmk         = m_bpsndlist.m_remark;
	m_bpsndcl.m_ccy         = m_bpsndlist.m_currency;
	m_bpsndcl.m_nboftxs     = m_iTtlCntOk ;
	m_bpsndcl.m_sapsnboftxs = 0 ;
	m_bpsndcl.m_ctrlsapssum = 0.00;
	m_bpsndcl.m_ctrlsum     = m_fTtlAmtOk;
	m_bpsndcl.m_realtimeflag= "0" ;
	m_bpsndcl.m_isrbflg     = m_bpsndlist.m_isrbflg;
	m_bpsndcl.m_dgtsign     = "MAC SIGN";
	
	SETCTX(m_bpsndcl);
	iRet = m_bpsndcl.insert();
	if(iRet != SQL_SUCCESS){
	    Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[bp_bcoutsndcl]�������:%s", m_bpsndcl.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CSendPkg008::InsertData_cl");

	return iRet;
}
