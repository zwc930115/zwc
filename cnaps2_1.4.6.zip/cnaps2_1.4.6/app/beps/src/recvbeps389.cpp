/******************************************************************** 
文件名： recvbeps389.cpp
创建人： handongfeng
日  期： 2011-02-23
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif
#include "recvbeps389.h"

CRecvbeps389::CRecvbeps389()
{
    m_colltnchrgscl.m_msgtp = "beps.389.001.01";
    m_colltnchrgslist.m_msgtp = "beps.389.001.01";

}

CRecvbeps389::~CRecvbeps389()
{

}

int CRecvbeps389::Work(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps389::Work()");

    // 解析报文
    unPack(szMsg);

    SetData(szMsg);

    // 插入数据
    InsertData();
    
    CheckSign389();
/*
    // 设置返回消息
    SetRtuMsg();
    
    // 添加队列
    AddQueue(,)
*/
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps389::Work()");
    return OPERACT_SUCCESS;
}

INT32 CRecvbeps389::unPack(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps389::unPack()");
    int iRet = -1;
    
    // 报文是否为空
    if (NULL == szMsg || '\0' == szMsg)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");	
    	PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文为空");
    }
    
    //获取工作日期
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(iRet != RTN_SUCCESS)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");	
    	PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;    

    // 解析报文
    #if 0
    if (OPERACT_SUCCESS != m_beps389.ParseMsg(szMsg))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错! iRet= %d", iRet);	
        return iRet;
    }
    #endif
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps389::unPack()");
    return OPERACT_SUCCESS;
}

INT32 CRecvbeps389::InsertData()
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps389::InsertData()");
    
    SETCTX(m_colltnchrgscl);
    int iRet = m_colltnchrgscl.insert();
    if (OPERACT_SUCCESS != iRet)
    { 
	  sprintf(m_szErrMsg,"insert() error,error code = [%d],error cause = [%s]",iRet,m_colltnchrgscl.GetSqlErr());	  
	  Trace(L_INFO,  __FILE__,	__LINE__, NULL, m_szErrMsg);	  
	  PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL,m_szErrMsg);
    }

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps389::InsertData()  iRet=%d", iRet);
    return iRet;
}

INT32 CRecvbeps389::SetData(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps389::SetData()");
    
    SETCTX(m_colltnchrgslist);
    
    int iNum = 0;//m_beps389.GetDetailCnt();
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iNum[%d]",iNum);
    for(int i = 0; i < iNum; i++)
    {
       // m_beps389.ParseDetail(i);

        //明细表插入数据
        if(OPERACT_SUCCESS != m_colltnchrgslist.insert())
        {
            sprintf(m_szErrMsg,"insert() error,error code = [%d],error cause = [%s]",iRet,m_colltnchrgslist.GetSqlErr());     
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);      
            PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL,m_szErrMsg);
         }        
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps389::SetData()");
    return OPERACT_SUCCESS;
}

void CRecvbeps389::CheckSign389()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms389::CheckSign389");

    m_beps389.getOriSignStr();
	
	CheckSign(m_beps389.m_sSignBuff.c_str(),
			m_beps389.m_szDigitSign.c_str(),
			m_beps389.InstgDrctPty.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms389::CheckSign389");
}


