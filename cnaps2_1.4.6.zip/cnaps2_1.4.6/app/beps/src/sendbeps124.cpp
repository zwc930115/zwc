/******************************************************************** 
�ļ����� sendbeps124.cpp
�����ˣ� zys
��  �ڣ� 2011-04-14
�޸��ˣ� 
��  �ڣ� 
��  ���� С������beps.124���Ĵ�����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps124.h"


CSendBeps124::CSendBeps124(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
    m_strProcessCode = "";
    m_strNetgDate    = "";
    m_strNetgRnd     = "";
    m_strDate        = "";
}

CSendBeps124::~CSendBeps124()
{
}

int CSendBeps124::UpdateSndList(LPCSTR sProcstate)
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps124::updatePkgId");

    sprintf(m_sSqlStr, "UPDATE BP_BDSENDLIST t SET "
            "t.MSGID = '%s'"  \
            "t.PROCSTATE = '%s'"  \
            " WHERE t.MSGID = '0' "  \
            " and t.txid = '%s'",
            m_sPkgDtNSn,
            sProcstate,
            m_sMsgId);
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sSqlStr = [%s]",m_sSqlStr);
    iRet = m_cbpbdsendlist.execsql(m_sSqlStr);
    if (iRet == SQLNOTFOUND)
    {
        Trace(eError, __FILE__, __LINE__, NULL,"��m_cbpbdsendlist����û���ҵ�����[txid=%s]",m_sMsgId);
    }
    else if (iRet != SQL_SUCCESS)
    {
        sprintf(m_sErrMsg,  "update m_cbpbdsendlist  is error!iRet=[%s]", iRet);
        Trace(eError, __FILE__, __LINE__, NULL,m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps124::updatePkgId");
    return 0;
}


int CSendBeps124::updateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps124::updateState");

    m_cbpbdsndcl.setctx(m_dbproc);

    m_cbpbdsndcl.m_procstate = "03";
    
    iRet = m_cbpbdsndcl.updatestate();
    
    if (SQL_SUCCESS != iRet) 
    {   
        sprintf(m_sErrMsg,"�޸Ľ�����˻���ҵ��״̬ʧ��[%s]",m_cbpbdsndcl.GetSqlErr());        
        Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);        
        PMTS_ThrowException(__FILE__, __LINE__, MB_OTR0103, m_sErrMsg);
    }

    m_cbpbdsndcl.commit();

    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps124::updateState");
    return 0;
}

INT32 CSendBeps124::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps124::doWorkSelf");
    
    //��ҵ����л�ȡ����    
    getData();
    
    //����һ������
    insertSum();    
    
    //��pmts����
    buildPmtsMsg();
    
    //����Զ�̶���
    AddQueue();
    
    //�޸���ϸҵ��İ����
    UpdateSndList(OPR_SENDND04);
    
    //�޸�״̬
    //updateState();
    
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps124::doWorkSelf"); 
    return 0;
}


int CSendBeps124::getData()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps124::getData");
    
    m_cbpbdsendlist.setctx(m_dbproc);    
    if (0 != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, "setctx error");
        PMTS_ThrowException(__FILE__, __LINE__, OTHER_ERR, "setctx error");
    }
    
    m_cbpbdsendlist.m_instgdrctpty = m_sSendOrg;
    m_cbpbdsendlist.m_msgid = "0";
    m_cbpbdsendlist.m_txid = m_sMsgId;
    
    iRet = m_cbpbdsendlist.findByPK();
    
    if (SQLNOTFOUND == iRet)
    {
        sprintf(m_sErrMsg,"С�����ʽ����ϸ�����Ҳ���ָ��ҵ��[%s],[%s],[%s]", 
            m_sSendOrg,m_sMsgId,m_cbpbdsendlist.GetSqlErr());    
        Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);    
        PMTS_ThrowException(__FILE__, __LINE__, MB_OTR0103, m_sErrMsg);
    } 
    else if (SQL_SUCCESS != iRet) 
    {
        sprintf(m_sErrMsg,"��ѯС�����ʽ����ϸ����������[%s]",m_cbpbdsendlist.GetSqlErr());    
        Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);    
        PMTS_ThrowException(__FILE__, __LINE__, MB_PFR0018, m_sErrMsg);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "m_dbtnm = [%s]",m_cbpbdsendlist.m_dbtnm.c_str());    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps124::getData"); 
    
    return iRet;
}

int CSendBeps124::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps124::CheckValues");

    //������޼��
    iRet = isOutOfLimit(m_dbproc, 
                        m_cbpbdsendlist.m_msgtp.c_str(), 
                        m_cbpbdsendlist.m_purpprtry.c_str(),
                        m_cbpbdsendlist.m_amount, 
                        m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OTHER_ERR, m_sErrMsg);
    }
    
    //�����кż��
    iRet = isBankRight(m_dbproc, m_cbpbdsendlist.m_instddrctpty.c_str(), m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OTHER_ERR, m_sErrMsg);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps124::CheckValues"); 
    return 0;
}

int CSendBeps124::insertSum()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps124::insertSum");
    
    GetMsgIdValue(m_dbproc,m_sPkgDtNSn,15,SYS_BEPS);
    
    m_cbpbdsndcl.setctx(m_dbproc);
    if (0 != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, "setctx error");
        PMTS_ThrowException(__FILE__, __LINE__, OTHER_ERR, "setctx error");
    }
    
    m_cbpbdsndcl.m_workdate = m_sWorkDate;
    m_cbpbdsndcl.m_consigdate = m_sWorkDate;
    m_cbpbdsndcl.m_msgtp = m_cbpbdsendlist.m_msgtp;
    m_cbpbdsndcl.m_msgid = m_sPkgDtNSn;
    m_cbpbdsndcl.m_instgdrctpty = m_cbpbdsendlist.m_instgdrctpty;
    m_cbpbdsndcl.m_instddrctpty = m_cbpbdsendlist.m_instddrctpty;
    m_cbpbdsndcl.m_srcflag = "0";
    //m_cbpbdsndcl.m_checkstate = "1";
    m_cbpbdsndcl.m_procstate = "02";
    m_cbpbdsndcl.m_nboftxs = 1;
    m_cbpbdsndcl.m_ctrlsum = m_cbpbdsendlist.m_amount;
    m_cbpbdsndcl.m_sapsnboftxs = 1;
    m_cbpbdsndcl.m_ctrlsapssum = m_cbpbdsendlist.m_amount;
    m_cbpbdsndcl.m_realtimeflag = "1";
    m_cbpbdsndcl.m_dgtsign = "DIGITSIGN";
    
    iRet = m_cbpbdsndcl.insert();
    
    if (DUPLICATE_KEY == iRet) 
    {
        Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "���������Ѵ���");
    
    }
    else if(SQL_SUCCESS != iRet)
    {
        sprintf(m_sErrMsg,"�������˻��ܱ���������ʧ��[%s]",m_cbpbdsndcl.GetSqlErr());    
        Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);    
        PMTS_ThrowException(__FILE__, __LINE__, MB_PFR0018, m_sErrMsg);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps124::insertSum"); 
    
    return iRet;
}


int CSendBeps124::buildPmtsMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps124::buildPmtsMsg");
    
    if(0 == strcmp("XML", m_sMsgType))
    {
        CreateXml();
    }
    else
    {
        CreateCmt();
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps124::buildPmtsMsg"); 
    
    return iRet;
}

void CSendBeps124::GetTag2ND(const string& QryVal, const string& QryStr, int& iDepth)
{
    string strTemp;
    GetTagVal(strTemp, QryStr, QryVal);
    strTemp = QryVal + strTemp;
    beps124.SetUstrd(iDepth, strTemp.c_str());
    iDepth++;
}

void CSendBeps124::AddSign124()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBeps124::DigitSign124...");

	char   sSignedStr[4096 + 1] = {0};
	
	m_xml124.getOriSignStr();
	
	AddSign(m_xml124.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_cbpbdsendlist.m_instgdrctpty.c_str());
	
	m_xml124.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBeps124::DigitSign124...");
}

void CSendBeps124::CreateXml()
{
    cout << "enter CSendBeps124::CreateXml" << endl;
    
    int iDepth = 0;
    int iRet   = -1;
    
    //==============================���ñ���ͷҪ��==============================    
    GetMsgIdValue(m_dbproc,m_sMsgRefId,6,SYS_BEPS);
    
    m_xml124.m_PMTSHeader.SetPMTSXMlHeader("BEPS", 
                                           m_sWorkDate,
                                           m_sSendOrg,
                                           m_cbpbdsndcl.m_instddrctpty.c_str(),
                                           "beps.124.001.01",
                                           m_sMsgRefId);
    //==========================================================================
    
    //Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps124::CreateXml 1111");
    cout << "enter CSendBeps124::CreateXml 1111" << endl;
    
    //==============================ȡAddtlInf��ֵ==============================
    GetTagVal(m_strProcessCode, m_cbpbdsendlist.m_addtlinf, "/F61/");
    GetTagVal(m_strProcessCode, m_cbpbdsendlist.m_addtlinf, "/C01/");
    GetTagVal(m_strProcessCode, m_cbpbdsendlist.m_addtlinf, "/E05/");
    GetTagVal(m_strProcessCode, m_cbpbdsendlist.m_addtlinf, "/C00/");
    //==========================================================================
    
    //===================================��ǩ===================================
    AddSign124();
    
    //==========================================================================
    
    //=================================�ֶθ�ֵ=================================
    char sTemp[32] = {0};
    m_xml124.MsgId                        = m_sPkgDtNSn;
    m_xml124.CreDtTm                      = m_sIsoWorkDate;
    m_xml124.OrgnlMsgId                   = "1";	
    m_xml124.OrgnlMsgNmId                 = m_cbpbdsendlist.m_txid;
    m_xml124.OrgnlGrpInfAndStsAddtlInf    = m_cbpbdsendlist.m_txid;
    m_xml124.StsId                        = "DEBT";
    m_xml124.OrgnlTxId                    = m_cbpbdsendlist.m_pmttpprtry ;
    m_xml124.RsnPrtry                     = m_cbpbdsendlist.m_dbtnm;
    m_xml124.AddtlInf                     = m_cbpbdsendlist.m_dbtaddr;
    sprintf(sTemp,"%.2f",m_cbpbdsendlist.m_amount);
    m_xml124.IntrBkSttlmAmt               = sTemp;
    m_xml124.CtgyPurpPrtry                = m_cbpbdsendlist.m_dbtrissr;
    m_xml124.OrgnlDbtrAgtMmbId            = m_cbpbdsendlist.m_dbtrbrnchid;
    m_xml124.OrgnlDbtrAgtId               = m_cbpbdsendlist.m_instgdrctpty;
    m_xml124.Ustrd                        = m_cbpbdsendlist.m_instddrctpty;
    m_xml124.DbtrAgtMmbId                 = m_cbpbdsendlist.m_cdtrbrnchid;
    m_xml124.DbtrAgtId                    = m_cbpbdsendlist.m_cdtrnm;
    m_xml124.CdtrAgtMmbId                 = m_cbpbdsendlist.m_cdtaddr;
    m_xml124.CdtrAgtId                    = m_cbpbdsendlist.m_cdtracctid;
    
    GetTag2ND("/F61/", m_cbpbdsendlist.m_addtlinf, iDepth);
    GetTag2ND("/C01/", m_cbpbdsendlist.m_addtlinf, iDepth);
    GetTag2ND("/E05/", m_cbpbdsendlist.m_addtlinf, iDepth);
    GetTag2ND("/C00/", m_cbpbdsendlist.m_addtlinf, iDepth); 
    //==========================================================================
    
    //================================= �鱨�� =================================
    iRet = m_xml124.CreateXml();
    if (0 != iRet)
    {
        sprintf(m_sErrMsg,"�������˱���ʧ��[%d]",iRet);        
        //Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);        
        PMTS_ThrowException(__FILE__, __LINE__, MB_PFR0018, m_sErrMsg);
    }
    //==========================================================================
    
    m_sMsgTxt = m_xml124.m_MsgTxt;
    
    Trace(L_ERROR, __FILE__, __LINE__, NULL, "[%s]", m_sMsgTxt);
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps124::Createxml"); 
}
 
 void CSendBeps124::CreateCmt()
 {
	Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps124::Createcmt");
	/*PARSER124 oParser124;
	char sTemp[32] = {0};
	oParser124.Init(VERSION_CMT,1);
		
		oParser124.CreateCMTHeader("003",
				  		m_sSendOrg,
				  		m_cbpbdsendlist.m_instddrctpty.c_str(),
				  		m_sMsgId,
				  		m_sMsgId,
				  		m_sWorkDate,
				  		"1"
				  )	;
		
		oParser124.m_szWorkDate			  =	m_sWorkDate;
		
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "m_sPkgDtNSn = [%s]",m_sPkgDtNSn);
		oParser124.m_szPkgSn			  =	m_sPkgDtNSn+8;
		oParser124.m_szPkgDest			  = m_sPkgDest;
		oParser124.m_szSrcFlag			  = m_sSrcFlag;
		
		
		pkg003 cPkg003;
		strcpy(cPkg003.stPkgHead003.szPkgType,"003");
		strncpy(cPkg003.stPkgHead003.szOdfiCode,m_cbpbdsendlist.m_instgdrctpty.c_str(),sizeof(cPkg003.stPkgHead003.szOdfiCode)-1);
		strncpy(cPkg003.stPkgHead003.szRdfiCode,m_cbpbdsendlist.m_instddrctpty.c_str(),sizeof(cPkg003.stPkgHead003.szRdfiCode)-1);
		strcpy(cPkg003.stPkgHead003.szPkgCDate,m_cbpbdsendlist.m_consigdate.c_str());
		memcpy(cPkg003.stPkgHead003.szPkgserNo,m_sPkgDtNSn+8,sizeof(cPkg003.stPkgHead003.szPkgserNo));
		strcpy(cPkg003.stPkgHead003.szPkgDest,"1111111111111111111");
		strcpy(cPkg003.stPkgHead003.szDetailCnt,"1");	
	    sprintf(sTemp,"%012.f",m_cbpbdsendlist.m_amount*100);	
		strcpy(cPkg003.stPkgHead003.szDetailAmt,sTemp);
		//
	    strcpy(cPkg003.stBizBody003.szTrxsType,m_cbpbdsendlist.m_pmttpprtry.c_str());
	    strcpy(cPkg003.stBizBody003.szOdfiCode,m_cbpbdsendlist.m_dbtrbrnchid.c_str());
	    strcpy(cPkg003.stBizBody003.szRdfiCode,m_cbpbdsendlist.m_cdtrbrnchid.c_str());
	    strcpy(cPkg003.stBizBody003.szConsignDate,m_cbpbdsendlist.m_consigdate.c_str());
	    strcpy(cPkg003.stBizBody003.szTxssNo,m_cbpbdsendlist.m_txid.c_str());
	    strcpy(cPkg003.stBizBody003.szAmount,sTemp);
	    strcpy(cPkg003.stBizBody003.szPayOpenAccBkCode,m_cbpbdsendlist.m_dbtrissr.c_str());
	    strcpy(cPkg003.stBizBody003.szPayerAcc,m_cbpbdsendlist.m_dbtracctid.c_str());
	    strcpy(cPkg003.stBizBody003.szPayerName,m_cbpbdsendlist.m_dbtnm.c_str());
	    strcpy(cPkg003.stBizBody003.szPayerAddr,m_cbpbdsendlist.m_dbtaddr.c_str());
	    strcpy(cPkg003.stBizBody003.szRecOpenAccBkCode,m_cbpbdsendlist.m_cdtrissr.c_str());
	    strcpy(cPkg003.stBizBody003.szRecipientAcc,m_cbpbdsendlist.m_cdtracctid.c_str());
	    strcpy(cPkg003.stBizBody003.szRecipientName,m_cbpbdsendlist.m_cdtrnm.c_str());
	    strcpy(cPkg003.stBizBody003.szTrxKind,m_cbpbdsendlist.m_purpprtry.c_str());
	    strcpy(cPkg003.stBizBody003.szPost,m_cbpbdsendlist.m_addtlinf.c_str());
	    strcpy(cPkg003.stBizBody003.szPost,"00000000");

		int iRet = cPkg003.CreateMsg();
		if(0 == iRet)
		{
			m_sMsgTxt = cPkg003.m_szMsgText;
		}*/
		
		
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps124::Createcmt");
 }
 