/******************************************************************** 
文件名： recvbeps385.cpp
创建人： aps-lel
日  期： 2011-04-09
修改人： 
日  期： 
描  述：小额来帐beps.384报文处理类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbeps385.h"


CRecvbeps385::CRecvbeps385()
{
    m_cBpcolltnchrgscl.m_msgtp = "beps.385.001.01";
    m_cBpcolltnchrgslist.m_msgtp = "beps.385.001.01";
    memset(m_sMsgRefId389, 0x00, sizeof(m_sMsgRefId389));
}

CRecvbeps385::~CRecvbeps385()
{

}

int CRecvbeps385::Work(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps385::Work()...");
    m_IsSendMB = false;
    // 解析报文
    unPack(szMsg);

	//数字核签
	CheckSign385();

    CheckArgeeAndUser();

    SetData(szMsg);
	
    // 插入数据
    InsertData();


	//实时回执一个报文
	SendRtuMsg();
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps385::Work()...");
    return OPERACT_SUCCESS;
}

INT32 CRecvbeps385::unPack(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps385::unPack()...");
    
    int iRet = -1;
    
    // 报文是否为空
    if (NULL == szMsg || '\0' == szMsg)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");	
    	PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "报文为空");
    }
    
    //获取工作日期
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(iRet != RTN_SUCCESS)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");	
    	PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;    

    // 解析报文
    if (OPERACT_SUCCESS != m_cBeps385.ParseXml(szMsg))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错! iRet= [%d]", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文解析出错!");
    }
	
	m_strMsgID = m_cBeps385.MsgId;
	
	//ZFPTLOG.SetLogInfo("385", m_strMsgID.c_str());
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps385::unPack()...");
	
    return OPERACT_SUCCESS;
}

INT32 CRecvbeps385::SetData(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps385::SetData()");
   
	m_cBpcolltnchrgslist.m_msgid = m_cBeps385.MsgId		  ;//报文标识号 
	m_cBpcolltnchrgslist.m_workdate =  m_sWorkDate 	  ;//报文工作日期
	m_cBpcolltnchrgslist.m_consigdate = m_sWorkDate;
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.MsgId = [%s]",m_cBeps385.MsgId.c_str());
	//m_cBpcolltnchrgslist.m_c = m_cBeps385.CreDtTm 	  ;//报文发送时间	  
	m_cBpcolltnchrgslist.m_instgdrctpty= m_cBeps385.InstgDrctPty  ;//发起直接参与机构 
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.InstgDrctPty = [%s]",m_cBeps385.InstgDrctPty.c_str());
	m_cBpcolltnchrgslist.m_instgpty = m_cBeps385.GrpHdrInstgPty;//发起参与机构	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.GrpHdrInstgPty = [%s]",m_cBeps385.GrpHdrInstgPty.c_str());
	m_cBpcolltnchrgslist.m_instddrctpty = m_cBeps385.InstdDrctPty  ;//接收直接参与机构 
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.InstdDrctPty = [%s]",m_cBeps385.InstdDrctPty.c_str());
	m_cBpcolltnchrgslist.m_instdpty = m_cBeps385.GrpHdrInstdPty;//接收参与机构	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.GrpHdrInstdPty = [%s]",m_cBeps385.GrpHdrInstdPty.c_str());
	m_cBpcolltnchrgslist.m_syscd = m_cBeps385.SysCd		  ;//系统编号		  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.SysCd = [%s]",m_cBeps385.SysCd.c_str());
	m_cBpcolltnchrgslist.m_rmk = m_cBeps385.Rmk 		  ;//备注	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.Rmk = [%s]",m_cBeps385.Rmk.c_str());
	m_cBpcolltnchrgslist.m_srcflag = "3";//1：往帐 2：付款方来帐 3：收款方来帐
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.m_srcflag = [%s]",m_cBpcolltnchrgslist.m_srcflag.c_str());
	m_cBpcolltnchrgslist.m_btchnb = m_cBeps385.OrgnlBtchNb		  ;//批次序号		  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.OrgnlBtchNb = [%s]",m_cBeps385.OrgnlBtchNb.c_str());
	m_cBpcolltnchrgslist.m_txid = m_cBeps385.TxId		  ;//明细标识号 	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.TxId = [%s]",m_cBeps385.TxId.c_str());
	m_cBpcolltnchrgslist.m_dbtrnm = m_cBeps385.DbtrNm		  ;//付款人户名 	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.DbtrNm = [%s]",m_cBeps385.DbtrNm.c_str());
	m_cBpcolltnchrgslist.m_dbtrid = m_cBeps385.DbtrAcctId	  ;//付款人账号 	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.DbtrAcctId = [%s]",m_cBeps385.DbtrAcctId.c_str());
	m_cBpcolltnchrgslist.m_dbtrmmbid = m_cBeps385.DbtrAgtId  ;//付款清算行行号   
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.DbtrAgtMmbId = [%s]",m_cBeps385.DbtrAgtId.c_str());
	m_cBpcolltnchrgslist.m_dbtrbrnchid = m_cBeps385.DbtrAgtId	  ;//付款行行号 	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.DbtrAgtId = [%s]",m_cBeps385.DbtrAgtId.c_str());
	m_cBpcolltnchrgslist.m_cdtrmmbid = m_cBeps385.CdtrAgtId  ;//收款清算行行号   
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.CdtrAgtMmbId = [%s]",m_cBeps385.CdtrAgtId.c_str());
	m_cBpcolltnchrgslist.m_cdtrbrnchid = m_cBeps385.CdtrAgtId	  ;//收款行行号 	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.CdtrAgtId = [%s]",m_cBeps385.CdtrAgtId.c_str());
	m_cBpcolltnchrgslist.m_cdtrnm = m_cBeps385.CdtrNm		  ;//收款人名称 	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.CdtrNm = [%s]",m_cBeps385.CdtrNm.c_str());
	m_cBpcolltnchrgslist.m_cdtrid = m_cBeps385.CdtrAcctId	  ;//收款人账号 
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.CdtrAcctId = [%s]",m_cBeps385.CdtrAcctId.c_str());
	m_cBpcolltnchrgslist.m_amout = atof(m_cBeps385.Amt.c_str()) 	;//货币金额		  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.m_amout = [%s]",m_cBeps385.Amt.c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.MsgId = [%s]",m_cBeps385.MsgId.c_str());
	m_cBpcolltnchrgslist.m_currency = m_cBeps385.Ccy 		  ;//货币符号		  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.Ccy = [%s]",m_cBeps385.Ccy.c_str());
	m_cBpcolltnchrgslist.m_ctgyprtry = m_cBeps385.CtgyPurpPrtry ;//业务类型编码	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.CtgyPurpPrtry = [%s]",m_cBeps385.CtgyPurpPrtry.c_str());
	m_cBpcolltnchrgslist.m_puryprtry = m_cBeps385.PurpPrtry	  ;//业务种类编码	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.PurpPrtry = [%s]",m_cBeps385.PurpPrtry.c_str());
	//m_cBpcolltnchrgslist.m_endtoendid = m_cBeps385.EndToEndId	  ;//合同（协议）号
	//Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBeps385.EndToEndId = [%s]",m_cBeps385.EndToEndId.c_str());
	m_cBpcolltnchrgslist.m_procstate = PR_HVBP_01;//表示已收妥
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps385.MsgId = [%s]",m_cBeps385.MsgId.c_str());
	//m_cBpcolltnchrgslist.m_chckflg = m_cBeps385.ChckFlg 	  ;//核验标识	
	//Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBeps385.ChckFlg = [%s]",m_cBeps385.ChckFlg.c_str());

  m_cBpcolltnchrgslist.m_orgnlmsgid = m_cBeps385.OrgnlMsgId;
  m_cBpcolltnchrgslist.m_orgnlinstgpty = m_cBeps385.OrgnlInstgPty;
  m_cBpcolltnchrgslist.m_orgnlbtchnb = m_cBeps385.OrgnlBtchNb;
	//明细表插入数据
	SETCTX(m_cBpcolltnchrgslist);
	iRet = m_cBpcolltnchrgslist.insert();
	
	if(OPERACT_SUCCESS != iRet)
	{
		sprintf(m_szErrMsg,"insert() error,error code = [%d],error cause = [%s]",iRet,m_cBpcolltnchrgslist.GetSqlErr());
		
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, m_szErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL,m_szErrMsg);
				
	}

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps385::SetData()");
	
    return OPERACT_SUCCESS;
}

INT32 CRecvbeps385::InsertData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps385::InsertData()...");
    
	SETCTX(m_cBpcolltnchrgscl);
	m_cBpcolltnchrgscl.m_busistate = PROCESS_PR00;	
	m_cBpcolltnchrgscl.m_instgdrctpty = m_cBeps385.InstgDrctPty  ;//发起直接参与机构 
	m_cBpcolltnchrgscl.m_instgpty = m_cBeps385.GrpHdrInstgPty ;//发起参与机构
	m_cBpcolltnchrgscl.m_workdate = m_sWorkDate;
	m_cBpcolltnchrgscl.m_btchnb = m_cBeps385.OrgnlBtchNb		  ;//批次序号	
	m_cBpcolltnchrgscl.m_instddrctpty = m_cBeps385.InstdDrctPty  ;//接收直接参与机构 
	m_cBpcolltnchrgscl.m_instdpty = m_cBeps385.GrpHdrInstdPty;//接收参与机构
	m_cBpcolltnchrgscl.m_consigdate = m_sWorkDate;//委托日期
	//m_cBpcolltnchrgscl.m_dbtrnm = m_cBeps385.DbtrNm		  ;//付款人户名 	  
	//m_cBpcolltnchrgscl.m_dbtrid = m_cBeps385.DbtrAcctId	  ;//付款人账号 	  
	m_cBpcolltnchrgscl.m_dbtrmmbid = m_cBeps385.DbtrAgtId;//付款清算行行号   
	//m_cBpcolltnchrgscl.m_dbtrbrnchid = m_cBeps385.DbtrAgtId	  ;//付款行行号 	  
	m_cBpcolltnchrgscl.m_cdtrmmbid = m_cBeps385.CdtrAgtId;//收款清算行行号   
	m_cBpcolltnchrgscl.m_cdbtrbrnchid = m_cBeps385.CdtrAgtId	  ;//收款行行号 
	m_cBpcolltnchrgscl.m_cdbtrnm= m_cBeps385.CdtrNm		  ;//收款人名称 	  
	m_cBpcolltnchrgscl.m_cdbtrid = m_cBeps385.CdtrAcctId	  ;//收款人账号 	  
	m_cBpcolltnchrgscl.m_ttlamt = atof(m_cBeps385.Amt.c_str()) ;//货币金额		  
	m_cBpcolltnchrgscl.m_currency = m_cBeps385.Ccy 		  ;//货币符号		  
	m_cBpcolltnchrgscl.m_ctgyprtry = m_cBeps385.CtgyPurpPrtry ;//业务类型编码	  
	//m_cBpcolltnchrgscl.m_puryprtry = m_cBeps385.PurpPrtry	  ;//业务种类编码	  
	//m_cBpcolltnchrgscl.m_endtoendid = m_cBeps385.EndToEndId	  ;//合同（协议）号 
	m_cBpcolltnchrgscl.m_rmk = m_cBeps385.Rmk 		  ;//备注
	m_cBpcolltnchrgscl.m_srcflag = m_cBpcolltnchrgslist.m_srcflag;
	m_cBpcolltnchrgscl.m_currency = "CNY";
	m_cBpcolltnchrgscl.m_procstate = m_cBpcolltnchrgslist.m_procstate;//因为是实时回复,所以这里直接返回最终状态 //"01";//已收妥
	
	m_cBpcolltnchrgscl.m_msgid = m_cBeps385.MsgId		  ;//报文标识号
	m_cBpcolltnchrgscl.m_syscd = "BEPS"		  ;//系统编号
	m_cBpcolltnchrgscl.m_checkstate= "1";
	
	m_cBpcolltnchrgscl.m_orgnlttlnb = 1;
	m_cBpcolltnchrgscl.m_orgnlttlam = atof(m_cBeps385.Amt.c_str());
	m_cBpcolltnchrgscl.m_rcvsndgttlamt = atof(m_cBeps385.Amt.c_str());
	m_cBpcolltnchrgscl.m_rcvsndgttlnb = 1; 
	
    m_cBpcolltnchrgscl.m_orgnlmsgid = m_cBeps385.OrgnlMsgId;
    m_cBpcolltnchrgscl.m_orgnlinstgpty = m_cBeps385.OrgnlInstgPty;
    m_cBpcolltnchrgscl.m_orgnlbtchnb = m_cBeps385.OrgnlBtchNb;	

    if(m_agreeanduser)
    {
        m_cBpcolltnchrgscl.m_npcprcsts = "PR10";//业务状态
    }
    else
    {
        m_cBpcolltnchrgscl.m_npcprcsts             = "PR09";//业务状态
        m_cBpcolltnchrgscl.m_npcprccd              = "RJ90";
        m_cBpcolltnchrgscl.m_npcrjctinf            = "其他";        
    }
	
    iRet = m_cBpcolltnchrgscl.insert();
	
    if (OPERACT_SUCCESS != iRet)
    {
      	
		sprintf(m_szErrMsg,"insert() error ,error code = [%d] error cause = [%s]",iRet,m_cBpcolltnchrgscl.GetSqlErr());		
		Trace(L_ERROR ,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL,m_szErrMsg);

    }
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps385::InsertData()...");

	return OPERACT_SUCCESS;
}

void CRecvbeps385::CheckSign385()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbeps385::CheckSign384...");

	m_cBeps385.getOriSignStr();
	
	CheckSign(m_cBeps385.m_sSignBuff.c_str(),
			m_cBeps385.m_szDigitSign.c_str(),
			m_cBeps385.InstgDrctPty.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbeps385::CheckSign384...");
}

int CRecvbeps385::CheckArgeeAndUser()
{

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBeps385::CheckArgeeAndUser()");

    if(!CheckUserState("beps.385.001.01",m_cBeps385.CdtrAcctId))
    {
        m_agreeanduser = false;
        return OPERACT_FAILED;
    } 

    return OPERACT_SUCCESS;

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBeps385::CheckArgeeAndUser()");	
}

void CRecvbeps385::SendRtuMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "ENTER CRecvbeps385::SetRtuMsg");

   char szISOchDate[12 + 1]  = {0};
   char szchMsgId[128 +1] = {0};
   
   //获取ISOworkdate
   GetIsoDateTime(m_dbproc, SYS_BEPS, szISOchDate);
   
   //取msgid
   GetMsgIdValue(m_dbproc, szchMsgId, eMsgId, SYS_BEPS);
   
    m_cBeps389.MsgId           = szchMsgId;//报文标识号	
    m_cBeps389.CreDtTm         = szISOchDate;//报文发送时间
    m_cBeps389.InstgDrctPty    = m_cBeps385.InstdDrctPty;//发起直接参与机构
    m_cBeps389.GrpHdrInstgPty  = m_cBeps385.InstdDrctPty;//间接发起参与机构
    m_cBeps389.InstdDrctPty    = "0000";//接收直接参与机构
    m_cBeps389.GrpHdrInstdPty  = "0000";//间接接收参与机构
    m_cBeps389.SysCd           = m_cBeps385.SysCd;//系统编号
    //m_cBeps389.Rmk             = m_colltnchrgscl.m_rmk;//备注
    m_cBeps389.OrgnlMsgId      = m_cBeps385.MsgId;//原报文标识号
    m_cBeps389.OrgnlInstgPty   = m_cBeps385.InstgDrctPty;//原发起参与机构
    m_cBeps389.OrgnlMT         = "beps.385.001.01";//原报文类型


    if(m_agreeanduser)
    {
        m_cBeps389.Sts             = "PR10";//业务状态
    }
    else
    {
        m_cBeps389.Sts             = "PR09";//业务状态
    m_cBeps389.RjctCd          = "RJ90";
    m_cBeps389.RjctInf         = "其他";        
    }
    //m_cBeps389.PrcPty          = m_colltnchrgscl.m_rjctprcpty;//业务处理参与机构

    bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId389, eRefId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "参数错误");
	    PMTS_ThrowException(PRM_FAIL);
    }

    // 组文件头
    m_cBeps389.CreateXMlHeader("BEPS",                        \
                                m_cBeps389.MsgId.substr(0, 8).c_str(), \
                                m_cBeps389.InstgDrctPty.c_str(),\
                                m_cBeps389.InstdDrctPty.c_str(),\                                
                                "beps.389.001.01",              \
                                m_sMsgRefId389);

    char   sSignedStr[10240 + 1] = {0};
    m_cBeps389.getOriSignStr();
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSignBuff = [%s]", m_cBeps389.m_sSignBuff.c_str());
    AddSign(m_cBeps389.m_sSignBuff.c_str(), sSignedStr, RAWSIGN,m_cBeps389.InstgDrctPty.c_str());	
    m_cBeps389.m_szDigitSign = sSignedStr;

    m_cBeps389.CreateXml();
    
    
    AddQueue(m_cBeps389.m_sXMLBuff, m_cBeps389.m_sXMLBuff.size());
    Insert389Data();

    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "LEAVE CRecvbeps385::SetRtuMsg");
    return ;
}

void CRecvbeps385::Insert389Data()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbeps385::Insert389Data()");

    m_Bpbizpubntce.m_workdate = m_cBeps389.MsgId.substr(0, 8); 
    m_Bpbizpubntce.m_msgtp = "beps.389.001.01"; 
    m_Bpbizpubntce.m_mesgid = m_sMsgRefId389; 
    m_Bpbizpubntce.m_mesgrefid = m_sMsgRefId389; 
    m_Bpbizpubntce.m_msgid = m_cBeps389.MsgId; 
    m_Bpbizpubntce.m_instgdrctpty = m_cBeps385.InstdDrctPty; 
    m_Bpbizpubntce.m_instgpty = m_cBeps385.GrpHdrInstdPty; 
    m_Bpbizpubntce.m_instddrctpty = "0000"; 
    m_Bpbizpubntce.m_instdpty = "0000"; 
    m_Bpbizpubntce.m_syscd = "BEPS"; 
    //m_Bpbizpubntce.m_rmk = ; 
    m_Bpbizpubntce.m_orgnlmsgid = m_cBeps385.MsgId; 
    m_Bpbizpubntce.m_orgnlinstgpty = m_cBeps385.InstgDrctPty; 
	m_Bpbizpubntce.m_orgnlmt = "beps.385.001.01";
    m_Bpbizpubntce.m_orgnlbtchnb = atoi(m_cBeps385.OrgnlBtchNb.c_str()); 
    m_Bpbizpubntce.m_status = m_cBeps389.Sts; 
    m_Bpbizpubntce.m_rjctcd = m_cBeps389.RjctCd; 
    m_Bpbizpubntce.m_rjctinf = m_cBeps389.RjctInf; 
    //m_Bpbizpubntce.m_rjcprcpty = ; 
    m_Bpbizpubntce.m_procstate = PR_HVBP_08; //已回执
    m_Bpbizpubntce.m_proctime = ""; 
    m_Bpbizpubntce.m_addtlinf = ""; 

    SETCTX(m_Bpbizpubntce);
    int iRet = m_Bpbizpubntce.insert();
    if (OPERACT_SUCCESS != iRet)
    { 
        sprintf(m_szErrMsg,"insert() error,error code = [%d],error cause = [%s]",iRet,m_Bpbizpubntce.GetSqlErr());	  
        Trace(L_INFO,  __FILE__,	__LINE__, NULL, m_szErrMsg);	  
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL,m_szErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbeps385::Insert389Data()");

}

