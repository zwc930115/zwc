/******************************************************************** 
�ļ����� sendpkg.cpp
�����ˣ� zhj
��  ��   �� 2011-03-03
�޸��ˣ� 
��  �ڣ� 
��  ����    PKG��������� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/

#include "sendpkg.h"


using namespace ZFPT;

extern CCategory			g_LogObj;
extern CConnectPool			*g_DBConnPool;
extern MQAgent              g_MQAgent;

extern char					g_SendQueue[128];


CSendPkg::CSendPkg()
{
	memset(m_szErrMsg, 0, sizeof(m_szErrMsg));
	memset(m_sSapBank, 0, sizeof(m_sSapBank));
	memset(m_sWorkDate, 0, sizeof(m_sWorkDate));
	memset(m_sIsoWorkDate, 0, sizeof(m_sIsoWorkDate));
	memset(m_sMsgRefId, 0, sizeof(m_sMsgRefId));
	
	m_strWrkDate	= "";
	m_strSendBank	= "";
	m_strRecvBank	= "";
	m_strMsgType	= "";
	m_strMsgID		= "";
	m_strMsgTxt		= "";

	m_iMsgNo		= 0 ;
}

CSendPkg::~CSendPkg()
{
}

void CSendPkg::setData(LPCSTR pWrkDate, LPCSTR pSendBank, LPCSTR pRecvBank, LPCSTR pMsgTp, LPCSTR pMsgId)
{
	char sMsgNo[3 + 1] = { 0 };
	
	m_strWrkDate	= pWrkDate;
	m_strSendBank	= pSendBank;
	m_strRecvBank	= pRecvBank;
	m_strMsgType	= pMsgTp;
	m_strMsgID		= pMsgId;

	memcpy(sMsgNo, pMsgTp + 5, sizeof(sMsgNo) - 1);
	m_iMsgNo = atoi(sMsgNo);
	
	GetSysParam(m_dbproc,"01", m_sSapBank);
    GetWorkDate(m_dbproc,m_sWorkDate, SYS_BEPS, m_sSapBank);
    GetIsoDateTime(m_dbproc,SYS_BEPS,m_sIsoWorkDate);
	GetMsgIdValue(m_dbproc, m_sMsgRefId, 6, SYS_BEPS);
}


INT32 CSendPkg::Work()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendPkg::Work()");	
	
    int		iRet			= RTN_FAIL;
	char	sMsgNo[3 + 1]	= { 0 };
	
    try
    {
        //��ȡ����
        GetDBConnect();
		
		//ҵ����
		switch(m_iMsgNo)
	    {
	        case 121:
	        {
				DoPkg001();
	            break;
	        }
	        case 122:
	        {
	            break;
	        }
			case 125:
	        {
	            break;
	        }
	        case 127:
	        {
	            break;
	        }
	        case 128:
	        {
	            break;
	        }        
	        default:
	            return RTN_FAIL;
	    }
		
		iRet = AddQueue(m_strMsgTxt.c_str(), m_strMsgTxt.length());

		//дMQʧ��
		if(0 != iRet)
		{
			//����NPCͨѶ��
		}
        
        //�ͷ�����
        g_DBConnPool->PutConnect(m_dbproc);	

    }
    catch(CException &e)
    {        
        Trace(L_ERROR, __FILE__, __LINE__, NULL, 
            "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());

		
        	
        // �ͷ�����
        g_DBConnPool->PutConnect(m_dbproc);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendPkg::Work()");	

    return 0;
}


/******************************************************************************
*  Function:   GetDBConnect
*  Description:��ȡ���ݿ�����
*  Input:      ��
*  Output:     ��
*  Return:     ��
*  Others:     ��
*  Author:     zys
*  Date:       2011-03-01
*******************************************************************************/
void CSendPkg::GetDBConnect(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendPkg::GetDBConnect()");	

    if(0 != g_DBConnPool->GetConnect(m_dbproc))
    {
        snprintf(m_szErrMsg, sizeof(m_szErrMsg), 
			"CSendPkg::GetDBConnect():��ȡ���ݿ�����ʧ��");
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		
        PMTS_ThrowException(__FILE__, __LINE__, MB_PFR0020, m_szErrMsg);
    }
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendPkg::GetDBConnect()");		
}


int CSendPkg::AddQueue(LPCSTR pMsgText, int iLength)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendPkg::AddQueue...");
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "��Ϣ����:pMsgText=[%s], iLength=[%d]", pMsgText, iLength);
    
    int iRet = g_MQAgent.PutMsg(g_SendQueue, pMsgText, iLength, NULL, NULL);
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendPkg::AddQueue...");
    return iRet;
}


void CSendPkg::DoPkg001()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendPkg::DoPkg001()");
	PARSER121			oParser121;

	CBpbcoutsendlist	oCBpbcoutsendlist   ;
	string				strWhereClause	= "";
	int					iRetCode		= RTN_FAIL;
	int					iUpdCode		= RTN_FAIL;
	char				sTemp[32]		= { 0 };
	string				strTemp				;
	int 				iCount				;
	int 				iNbOfTxs		= 0;
	double				dCtrlSum		= 0.00;

	//�鱨��ͷ
	oParser121.Init(VERSION_XML, m_iMsgNo);
		
	oParser121.CreateXMlHeader("BEPS", 
								m_sWorkDate,
								m_sSapBank,
								m_strRecvBank.c_str(),
				  				"beps.121.001.01",
				  				m_sMsgRefId);
	//ȡ��ϸ������ϸ
	oCBpbcoutsendlist.setctx(m_dbproc);

	strWhereClause = "where msgid = '" + m_strMsgID + "' " ;
	
	iRetCode = oCBpbcoutsendlist.find(strWhereClause);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(m_szErrMsg, "oCBpbcoutsendlist.find:��ѯС�����ʴ�����ϸ����¼��, [%d][%s]",
			iRetCode, oCBpbcoutsendlist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);

        PMTS_ThrowException(__FILE__, __LINE__, MB_PFR0018, m_szErrMsg);
    }

	while(SQL_SUCCESS == iRetCode)
	{
		iRetCode = oCBpbcoutsendlist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
			break;
		if (SQL_SUCCESS != iRetCode) 
		{
			sprintf(m_szErrMsg, "oCBppkgassist.fetch:��ѯС�����ʴ�����ϸ����¼��, [%d][%s]",
				iRetCode, oCBpbcoutsendlist.GetSqlErr()); 
			
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
	
			PMTS_ThrowException(__FILE__, __LINE__, MB_PFR0018, m_szErrMsg);
		}

		/**************************************************************/
		
		oParser121.TxId              = oCBpbcoutsendlist.m_txid			;//��ϸ��ʶ��	
		oParser121.DbtrNm            = oCBpbcoutsendlist.m_dbtnm		;//����������
		oParser121.DbtrAdrLine       = oCBpbcoutsendlist.m_dbtaddr		;//�����˵�ַ
		oParser121.DbtrAcctId        = oCBpbcoutsendlist.m_dbtracctid	;//�������˺�
		oParser121.DbtrAcctIssr      = oCBpbcoutsendlist.m_dbtrissr		;//�����˿������к�
		oParser121.DbtrAgtId         = oCBpbcoutsendlist.m_dbtrbrnchid	;//�������к�
		oParser121.CdtrAgtId         = oCBpbcoutsendlist.m_cdtrbrnchid	;//�տ����к�
		oParser121.CdtrNm            = oCBpbcoutsendlist.m_cdtrnm		;//�տ�������
		oParser121.CdtrAdrLine       = oCBpbcoutsendlist.m_cdtaddr		;//�տ��˵�ַ
		oParser121.CdtrAcctId        = oCBpbcoutsendlist.m_cdtracctid	;//�տ����˺�
		oParser121.CdtrAcctIssr      = oCBpbcoutsendlist.m_cdtrissr		;//�տ��˿������к�

		memset(sTemp,'\0',sizeof(sTemp));
		sprintf(sTemp, "%.2f", oCBpbcoutsendlist.m_amount)				;
		oParser121.CstmrCdtTrfInfAmt = 	sTemp		                    ;//���
		
		oParser121.CstmrCdtTrfInfCcy = 	oCBpbcoutsendlist.m_currency	;//���ҷ���
		oParser121.CtgyPurpPrtry     = 	oCBpbcoutsendlist.m_pmttpprtry	;//ҵ�����ͱ���
		oParser121.PurpPrtry         = 	oCBpbcoutsendlist.m_purpprtry	;//ҵ���������
		oParser121.AddtlInf          = 	oCBpbcoutsendlist.m_addtlinf	;//����
		
		/*ҵ������Ϊ���ҵ��ҵ������Ϊί���տ��*/
		if(oCBpbcoutsendlist.m_pmttpprtry == "A100" && oCBpbcoutsendlist.m_purpprtry == "02106")
		{
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":Tp:");
			oParser121.ColltnInfTp            = strTemp;//Ʊ������
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":Dt:");
			oParser121.ColltnInfDt            = strTemp;//Ʊ������
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":Nb:");
			oParser121.ColltnInfNb            = strTemp;//Ʊ�ݺ���
		}
		/*ҵ������Ϊ���ҵ��ҵ������Ϊ���ճи�����*/
		else if(oCBpbcoutsendlist.m_pmttpprtry == "A100" && oCBpbcoutsendlist.m_purpprtry == "02107")
		{
		    GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":Dt:");
			oParser121.ColltnWthAccptncInfDt  = strTemp;//Ʊ������
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":Nb:");
			oParser121.ColltnWthAccptncInfNb  = strTemp;//Ʊ�ݺ���
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":AmdsAmt:");
			oParser121.AmdsAmt                = strTemp;//�⳥����
			oParser121.AmdsAmtCcy             = "CNY";
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":RctAmt:");
			oParser121.RctAmt                 = strTemp;//�ܸ����
			oParser121.RctAmtCcy              = "CNY";
		}
		/*ҵ������Ϊ�����ʽ��ծ�Ҹ����ǻ���*/
		else if(oCBpbcoutsendlist.m_pmttpprtry == "A307" )
		{
		    GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":FlowNb:");
			oParser121.FslInfFlowNb           = strTemp;//��Ϣ��ˮ��
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":Amt:");
			oParser121.FslInfAmt              = strTemp;//��ϸ���ܽ��
			oParser121.FslInfCcy              = "CNY";//
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":RptCd:");
			oParser121.RptCd                  = strTemp;//�ϱ��������
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":RcvCd:");
			oParser121.RcvCd                  = strTemp;//���չ������
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":RptFrms:");
			oParser121.RptFrms                = strTemp;//��������
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":RptNb:");
			oParser121.RptNb                  = strTemp;//�������

			iCount = 0;
			memset(sTemp,'\0',sizeof(sTemp));
			//��ȡ��ϸ����
			GetTagCount(oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":TpCd:", iCount);		
			sprintf(sTemp, "%d", iCount);
			oParser121.NtlTrsrInfNbOfTxs      = sTemp; //��ϸ����

			for(int i = 0; i < iCount; i++)
			{
				/*�����ֶ�Ϊѭ���е�ѭ��*/
				GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":TpCd:", i);
				oParser121.TpCd                   = strTemp;//�Ҹ���ծ���д���
				GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":CptlCd:", i);
				oParser121.CptlCd                 = strTemp;//�������
				GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":CptlAmt:", i);
				oParser121.CptlAmt                = strTemp;//������
				oParser121.CptlAmtCcy             = "CNY";
				GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":AcrlCd:", i);
				oParser121.AcrlCd                 = strTemp;//��Ϣ����
				GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":AcrlAmt:", i);
				oParser121.AcrlAmt                = strTemp;//��Ϣ���
				oParser121.AcrlAmtCcy             = "CNY";
			}
		}
		/*ҵ������Ϊ�ɷ�ҵ��*/
		else if(oCBpbcoutsendlist.m_pmttpprtry == "A301" )
		{   
		    GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":FlowNb:");
			oParser121.PmtInfFlowNb           = strTemp;//�շѵ�λ��ˮ��
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":Term:");
			oParser121.Term                   = strTemp;//�����ڼ�
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":Tp:");
			oParser121.PmtInfTp               = strTemp;//�ɷ�����
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":Rmk:");
			oParser121.PmtInfRmk              = strTemp;//�շѸ���
		}
		/*�˻�ҵ�񸽼�����*/
		else if(oCBpbcoutsendlist.m_pmttpprtry == "A105" )
		{
		    GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":OrgnlMsgId:");
			oParser121.OrgnlMsgId             = strTemp;//ԭ���ı�ʶ��
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":OrgnlInstgPty:");
			oParser121.OrgnlInstgPty          = strTemp;//ԭ����������
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":OrgnlMT:");
			oParser121.OrgnlMT                = strTemp;//ԭ��������
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":InstgIndrctPty:");
			oParser121.InstgIndrctPty         = strTemp;//ԭ�����Ӳ������
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":InstdIndrctPty:");
			oParser121.InstdIndrctPty         = strTemp;//ԭ���ռ�Ӳ������
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":OrgnlTxId:");
			oParser121.OrgnlTxId              = strTemp;//ԭ��ϸ��ʶ��
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":OrgnlTxTpCd:");
			oParser121.OrgnlTxTpCd            = strTemp;//ԭҵ�����ͱ���
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, ":Cntt:");
			oParser121.Cntt                   = strTemp;//�˻�ԭ��
		}
		
		oParser121.AddDetail();

		/**************************************************************/

		//�����´���״̬Ϊ"���ڴ��"
		iUpdCode = oCBpbcoutsendlist.setstate("15");
		if (SQL_SUCCESS != iUpdCode) 
		{
			sprintf(m_szErrMsg, "oCBppkgassist.setstate:����С�����ʴ�����ϸ����¼��, [%d][%s]",
				iUpdCode, oCBpbcoutsendlist.GetSqlErr()); 
			
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
	
			PMTS_ThrowException(__FILE__, __LINE__, MB_PFR0018, m_szErrMsg);
		}

		iNbOfTxs++;
		dCtrlSum += oCBpbcoutsendlist.m_amount;
	}

	oParser121.MsgId                  =	m_strMsgID;
	oParser121.CreDtTm                =	m_sIsoWorkDate;
	oParser121.InstgDrctPty           =	m_sSapBank;
	oParser121.InstdDrctPty           =	m_strRecvBank;
	
	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp,"%d", iNbOfTxs);
	oParser121.PKGGrpHdrNbOfTxs       =	sTemp;
	
	
	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp,"%.2f", dCtrlSum);
	oParser121.CtrlSum                =	sTemp;
	
	oParser121.CtrlSumCcy             =	oCBpbcoutsendlist.m_currency;
	oParser121.SysCd                  =	"beps";
	oParser121.PKGGrpHdrRmk           =	"";
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendPkg::DoPkg001()");
}



