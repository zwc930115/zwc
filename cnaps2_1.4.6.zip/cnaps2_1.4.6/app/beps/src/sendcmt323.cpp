/******************************************************************** 
�ļ����� sendcmt323.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt323.h"

using namespace ZFPT;

CSendCmt323::CSendCmt323(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
}

CSendCmt323::~CSendCmt323()
{
}

INT32 CSendCmt323::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt323::doWorkSelf");

    GetData();
    
    SetData();

    buildCmtMsg();
    
    UpdateState();

    m_sMsgTxt = m_cmt323.m_strCmtmsg ;
    AddQueue();
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt323::doWorkSelf"); 
    return 0;
}

INT32 CSendCmt323::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt323::SetData");

	bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(PRM_FAIL);
    }
    
    //��ͷ
    /*
	char sCMTheader[138 + 1] = { 0 };
	CT_CMTMsgHeader oCT_CMTMsgHeader;
	oCT_CMTMsgHeader.m_strCMTCode	= "323";
	oCT_CMTMsgHeader.m_strSender	= m_cBpcstpmtcxl.m_instgdrctpty.c_str();
	oCT_CMTMsgHeader.m_strReceiver	= m_cBpcstpmtcxl.m_instddrctpty.c_str();
	oCT_CMTMsgHeader.m_strMsgId		= m_sMsgId;
	oCT_CMTMsgHeader.m_strRequestId	= m_sMsgRefId;
	oCT_CMTMsgHeader.m_strRequestId	= m_sMsgRefId;
	oCT_CMTMsgHeader.m_strValidDate	= m_cBpcstpmtcxl.m_workdate.c_str();
	
	oCT_CMTMsgHeader.ToString(sCMTheader);
	memcpy(&m_cmt323.m_CMTHeaderMap, sCMTheader, strlen(sCMTheader));
	memcpy(m_cmt323.m_CMTHeaderMap.mesgPRI     , "3", sizeof(m_cmt323.m_CMTHeaderMap.mesgPRI    ));
	*/
    strcpy(m_cmt323.sConsigndate , m_cBpcstpmtcxl.m_workdate.c_str());        //ί������   8n         M
    strcpy(m_cmt323.sOldsendsapbk , m_cBpcstpmtcxl.m_instgdrctpty.c_str());      //�������������� , ԭ������������     12n        M
    strcpy(m_cmt323.sRevctmssno , m_szMsgSerial);         //�����������       8n         M
    strcpy(m_cmt323.sOldpacktype , m_cBpcstpmtcxl.m_orimsgtp.c_str());        //ԭ�����ͺ�         3n 	       O

    char szOrgConsigdate[8+1]={0};
    strncpy(szOrgConsigdate, m_cBpcstpmtcxl.m_orimsgid.c_str(), sizeof(szOrgConsigdate)-1);
    strcpy(m_cmt323.sOldpackdate , szOrgConsigdate);        //ԭ��ί������       8n         O

    char szOrgSeril[8+1]={0};
    strncpy(szOrgSeril, m_cBpcstpmtcxl.m_orimsgid.c_str()+8, sizeof(szOrgSeril)-1);    
    strcpy(m_cmt323.sOldpackno , szOrgSeril);          //ԭ�����           8n         O
    
    strcpy(m_cmt323.sRemark , m_cBpcstpmtcxl.m_addtlinf.c_str());            //����           60g        O        

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt323::SetData"); 
    return 0;
}

int CSendCmt323::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt323::getData");

	SETCTX(m_cBpcstpmtcxl);
    
  	m_cBpcstpmtcxl.m_instgdrctpty = m_sSendOrg;
  	m_cBpcstpmtcxl.m_msgid        = m_sMsgId;
  	
  	int iRet = m_cBpcstpmtcxl.findByPK();
  	if (SQLNOTFOUND == iRet)
	{
		sprintf(m_sErrMsg, "�Ҳ���ָ��ҵ��[%s], [%s], [%d][%s]", 
		    m_sSendOrg, m_sMsgId, iRet, m_cBpcstpmtcxl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	} 	
	else if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg, "��ѯ���ܱ���������[%s], [%s], [%d][%s]",
		    m_sSendOrg, m_sMsgId, iRet, m_cBpcstpmtcxl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt323::getData"); 
    
	return iRet;
}
int CSendCmt323::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt123::buildCmtMsg...");

    int iRet = m_cmt323.CreateCmt("323", m_sSendOrg, m_cBpcstpmtcxl.m_instddrctpty.c_str(), m_sMsgId, m_sMsgId, m_cBpcstpmtcxl.m_workdate.c_str(), "3");
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt323::buildCmtMsg...");
    return iRet;
}
int CSendCmt323::UpdateState(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendCmt323::UpdateDb");

	string strSQL;
	strSQL += "UPDATE BP_CSTPMTCXL t SET t.PROCTIME = sysdate, t.Procstate = '08'";
	strSQL += " WHERE t.msgid = '";
	strSQL += m_cBpcstpmtcxl.m_msgid;
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_cBpcstpmtcxl.m_instgdrctpty; 
	strSQL += "'";
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, strSQL.c_str());
	
    SETCTX(m_cBpcstpmtcxl);
	int iRet = m_cBpcstpmtcxl.execsql(strSQL.c_str());
	if (iRet != SQL_SUCCESS)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]",
		    iRet, m_cBpcstpmtcxl.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
	}
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendCmt323::UpdateDb");
    return RTN_SUCCESS;
}



