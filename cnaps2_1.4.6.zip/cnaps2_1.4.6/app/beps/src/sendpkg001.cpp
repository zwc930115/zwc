/******************************************************************** 
�ļ����� sendpkg001.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendpkg001.h"

using namespace ZFPT;

CSendPkg001::CSendPkg001(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
    memset(m_sPkgNo, 0x00, sizeof(m_sPkgNo));
}

CSendPkg001::~CSendPkg001()
{

}

INT32 CSendPkg001::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, 
            NULL, "Enter CSendPkg001::doWorkSelf");

    // ��ҵ����л�ȡ����
    GetData();
    
    // �鱨�ı�����
    CreateNpcMsg();

    //�޸Ĵ��������
    UpdatePkg();
    
    //�޸�״̬/NPCMSG
    UpdateSndList("95");

    Trace(L_INFO,  __FILE__,  __LINE__, 
            NULL, "Leave CSendPkg001::doWorkSelf"); 
    return 0;
}

//��ȡҵ������
INT32 CSendPkg001::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__,
                 NULL, "Enter CSendPkg001::GetData");

    SETCTX(m_cBpbcsndlist);

    m_cBpbcsndlist.m_dbtrbrnchid = m_sSendOrg;
    m_cBpbcsndlist.m_txid        = m_sMsgId;

    iRet = m_cBpbcsndlist.findByPK();
    if (SQLNOTFOUND == iRet)
    {
        sprintf(m_sErrMsg, "С�����ʴ�����ϸ�����Ҳ���ָ��ҵ��[%s][%s]", 
            m_sSendOrg, m_sMsgId);

        Trace(L_INFO,  __FILE__,  __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    } 	
    else if (SQL_SUCCESS != iRet) 
    {
        sprintf(m_sErrMsg,"��ѯС�����ʴ�����ϸ����������[%d][%s]",
            iRet, m_cBpbcsndlist.GetSqlErr());

        Trace(L_INFO,  __FILE__,  __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, 
                    NULL, "Leave CSendPkg001::GetData"); 

    return iRet;
}

//������ݺϷ���
INT32 CSendPkg001::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CSendPkg001::CheckValues");

    int iRet = -1;

    //������޼��
    iRet = isOutOfLimit(m_dbproc, 
                        m_cBpbcsndlist.m_msgtp.c_str(), 
                        m_cBpbcsndlist.m_purpprtry.c_str(),
                        m_cBpbcsndlist.m_amount, 
                        m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_AMT_OUT_OF_LIMIT, m_sErrMsg);
    }
    
    //�����кż��
    iRet = isBankRight(m_dbproc, m_cBpbcsndlist.m_instddrctpty.c_str(), m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_RECVBANK_CHECK_FAIL, m_sErrMsg);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendPkg001::CheckValues"); 
    return 0;
}

//����
INT32 CSendPkg001::ChargeMb()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg001::ChargeMb");
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg001::ChargeMb"); 
    return 0;
}

//����NPC����
INT32 CSendPkg001::CreateNpcMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg001::CreateNpcMsg");

    //__wsh 2012-07-16 ���������м������и�ֵ������������
    char sTemp[32 + 1] ={0};
    char sMsgText[512 + 1] ={0};
    //Ҫ�ؼ�����
    m_pkg001.m_szCurElementNo = "001"; 
    //ҵ������
    strncpy(m_pkg001.stBizBody001.szTrxsType , 
            m_cBpbcsndlist.m_pmttpprtry.c_str(), 
            sizeof(m_pkg001.stBizBody001.szTrxsType)-1);
            
    //�������к�        
    strncpy(m_pkg001.stBizBody001.szOdfiCode , 
            m_cBpbcsndlist.m_dbtrbrnchid.c_str(), 
            sizeof(m_pkg001.stBizBody001.szOdfiCode)-1);
            
    //�������к�       
    strncpy(m_pkg001.stBizBody001.szRdfiCode , 
            m_cBpbcsndlist.m_cdtrbrnchid.c_str(), 
            sizeof(m_pkg001.stBizBody001.szRdfiCode)-1);
            
    //ί������        
    strncpy(m_pkg001.stBizBody001.szConsignDate , 
            m_cBpbcsndlist.m_consigdate.c_str(), 
            sizeof(m_pkg001.stBizBody001.szConsignDate)-1);
            
    //����֧�����        
    strncpy(m_pkg001.stBizBody001.szTxssNo, 
            m_szMsgSerial, 
            sizeof(m_pkg001.stBizBody001.szTxssNo)-1);
            
    //���׽��
    memset(sTemp, '\0', sizeof(sTemp));
    snprintf(sTemp, 15+1, "%015.0f", m_cBpbcsndlist.m_amount*100.0);    
    strncpy(m_pkg001.stBizBody001.szAmount, 
            sTemp, 
            sizeof(m_pkg001.stBizBody001.szAmount)-1);
            
    //�����˿������к�        
    strncpy(m_pkg001.stBizBody001.szPayOpenAccBkCode , 
            m_cBpbcsndlist.m_dbtrissr.c_str(), 
            sizeof(m_pkg001.stBizBody001.szPayOpenAccBkCode)-1);
            
    //�������˺�        
    strncpy(m_pkg001.stBizBody001.szPayerAcc , 
            m_cBpbcsndlist.m_dbtracctid.c_str(), 
            sizeof(m_pkg001.stBizBody001.szPayerAcc)-1);
    
    //����������        
    SetFieldAsGbk(m_cBpbcsndlist.m_dbtnm, 
            m_pkg001.stBizBody001.szPayerName,
            sizeof(m_pkg001.stBizBody001.szPayerName)-1);        
    
    //�����˵�ַ        
    SetFieldAsGbk(m_cBpbcsndlist.m_dbtaddr, 
            m_pkg001.stBizBody001.szPayerAddr,
            sizeof(m_pkg001.stBizBody001.szPayerAddr)-1);         
    
    //�տ��˿����к�        
    strncpy(m_pkg001.stBizBody001.szRecOpenAccBkCode, 
            m_cBpbcsndlist.m_cdtrissr.c_str(), 
            sizeof(m_pkg001.stBizBody001.szRecOpenAccBkCode)-1);
    
    //�տ����˺�        
    strncpy(m_pkg001.stBizBody001.szRecipientAcc, 
            m_cBpbcsndlist.m_cdtracctid.c_str(), 
            sizeof(m_pkg001.stBizBody001.szRecipientAcc)-1);
    
    //�տ�������        
    SetFieldAsGbk(m_cBpbcsndlist.m_cdtrnm, 
            m_pkg001.stBizBody001.szRecipientName,
            sizeof(m_pkg001.stBizBody001.szRecipientName)-1); 
    
    //�տ��˵�ַ        
    SetFieldAsGbk(m_cBpbcsndlist.m_cdtaddr, 
            m_pkg001.stBizBody001.szRecipientAddr,
            sizeof(m_pkg001.stBizBody001.szRecipientAddr)-1); 
    //ҵ������        
    strncpy(m_pkg001.stBizBody001.szTrxKind, 
            m_cBpbcsndlist.m_purpprtry.c_str(), 
            sizeof(m_pkg001.stBizBody001.szTrxKind)-1);
    
            
    //����
    SetFieldAsGbk(m_cBpbcsndlist.m_addtlinf, 
            m_pkg001.stBizBody001.szPost,
            sizeof(m_pkg001.stBizBody001.szPost)-1);   
    
    string strAppData;
    int iCount = 0;
    int iRet = GetTagCount(m_cBpbcsndlist.m_cstmrcdttrfaddtlinf, "72C:", iCount);
    if( (RTN_SUCCESS == iRet) && (iCount > 0) )
    {
        if("00101" == m_cBpbcsndlist.m_pmttpprtry)//6.2	ί���տ���أ�ҵ��
        {
            //__wsh 2012-08-27
            char* szBizFmts[3] = {"%08s", "%08s", "%02s"};
            FormatAppendData(strAppData, m_cBpbcsndlist.m_cstmrcdttrfaddtlinf, iCount, 
                szBizFmts, 3, NULL, 0);
        }
        else if("00102" == m_cBpbcsndlist.m_pmttpprtry)//6.3	���ճи������أ�ҵ��
        {
           //__wsh 2012-08-27
            char* szBizFmts[7] = {"%08s", "%08s", "%015s", "%015s", "%015s", "%015s", "%015s"};
            FormatAppendData(strAppData, m_cBpbcsndlist.m_cstmrcdttrfaddtlinf, iCount, 
                szBizFmts, 7, NULL, 0);
        }
        else if("00103" == m_cBpbcsndlist.m_pmttpprtry)//6.4	�����ʽ���ǻ���ҵ��
        {

            //_wsh_2012.04.25
            char* szBizFmts[10] = {"%08s", "%018s", "%010s", "%010s", "%01s", "%01s", "%01s", "%08s","%03s","%03d"};
            char* szDtlFmts[3]  = {"%010s", "%-20s", "%018s"};
            FormatAppendData(strAppData, m_cBpbcsndlist.m_cstmrcdttrfaddtlinf, iCount, 
                szBizFmts, 10, szDtlFmts, 3);
        }
        else if("20002" == m_cBpbcsndlist.m_pmttpprtry)//��˰����
        {
            char* szBizFmts[3] = {"%-60s", "%016s", "%02s"};
            FormatAppendData(strAppData, m_cBpbcsndlist.m_cstmrcdttrfaddtlinf, iCount, 
                szBizFmts, 3, NULL, 0);
        }  
        else if( ("20003" == m_cBpbcsndlist.m_pmttpprtry) || ("20004" == m_cBpbcsndlist.m_pmttpprtry))//����ֱ��֧���˻�,������Ȩ֧���˻�
        {
            //_wsh_2012.04.25
            char* szBizFmts[10] = {"%010s", "%-32s", "%-12s", "%01s", "%01s", "%018s", "%018s", "%08s", "%08s", "%03d"};
            char* szDtlFmts[5]  = {"%-15s", "%-20s", "%-20s", "%01s", "%018s"};
            FormatAppendData(strAppData, m_cBpbcsndlist.m_cstmrcdttrfaddtlinf, iCount, 
                szBizFmts, 10, szDtlFmts, 5);
        }  
        else if("20005" == m_cBpbcsndlist.m_pmttpprtry)//�����ʽ��ծ�Ҹ����ǻ���
        {
            //_wsh_2012.04.25
            char* szBizFmts[7] = {"%08s", "%018s", "%010s", "%010s", "%08s", "%03s", "%03d"};
            char* szDtlFmts[5]  = {"%012s", "%-12s", "%018s", "%-12s", "%018s"};
            FormatAppendData(strAppData, m_cBpbcsndlist.m_cstmrcdttrfaddtlinf, iCount, 
                szBizFmts, 10, szDtlFmts, 5);
        }
        else if("30002" == m_cBpbcsndlist.m_pmttpprtry)//�ɷ�
        {
            char* szBizFmts[4] = {"%-20s", "%016s", "%01s", "%60s"};
            FormatAppendData(strAppData, m_cBpbcsndlist.m_cstmrcdttrfaddtlinf, iCount, 
                szBizFmts, 4, NULL, 0);
        }
        else if( ("00100" == m_cBpbcsndlist.m_pmttpprtry) || ("00106" == m_cBpbcsndlist.m_pmttpprtry) || ("20001" == m_cBpbcsndlist.m_pmttpprtry) )//���.��������ҵ��.��˰
        {
            m_cBpbcsndlist.m_cstmrcdttrfaddtlinf = "";
        }
        else
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "û���ҵ���Ӧ����ҵ������");
            PMTS_ThrowException(OPT_TRADE_NOTFOUND__FAIL);
        }
    }

    char szBuff[128] = {0};
    itoa(szBuff, strAppData.length(), 0);
    strncpy(m_pkg001.stBizBody001.szAppLen ,szBuff,sizeof(m_pkg001.stBizBody001.szAppLen)-1);
    strcpy(m_pkg001.stBizBody001.szAppData, strAppData.c_str());

    m_pkg001.AddBussiness();
    m_sMsgTxt = m_pkg001.m_szPkgBody;
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, " m_sMsgTxt = [%s]", m_sMsgTxt.c_str());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg001::CreateNpcMsg"); 

    return 0;
}

INT32 CSendPkg001::UpdatePkg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg001::UpdatePkg");

    strncpy(m_strAssist.sSendBank, 
            m_cBpbcsndlist.m_instgdrctpty.c_str(), 
            sizeof(m_strAssist.sSendBank) - 1);
            
    strncpy(m_strAssist.sRecvBank, 
            m_cBpbcsndlist.m_instddrctpty.c_str(), 
            sizeof(m_strAssist.sRecvBank) - 1);
            
    strncpy(m_strAssist.sMsgType,  
            m_cBpbcsndlist.m_msgtp.c_str(),        
            sizeof(m_strAssist.sMsgType)  - 1);
    
    m_strAssist.iPkgRtrltd = 0;
    strncpy(m_strAssist.sPmttpPrtry, "0", sizeof(m_strAssist.sPmttpPrtry) - 1);
    strncpy(m_strAssist.sIssr,       "0", sizeof(m_strAssist.sIssr)       - 1);
    strncpy(m_strAssist.sAcctId,     "0", sizeof(m_strAssist.sAcctId)     - 1);
    strncpy(m_strAssist.sOriMsgTp,   "0", sizeof(m_strAssist.sOriMsgTp)   - 1);
    strncpy(m_strAssist.sOriMsgId,   "0", sizeof(m_strAssist.sOriMsgId)   - 1);
    
    iRet = UpPKGAssist1(m_sPkgNo);
    if (iRet != SQL_SUCCESS)
    {
        memcpy(m_sPkgNo, m_cBpbcsndlist.m_msgid.c_str(), sizeof(m_sPkgNo) - 1);
        sprintf(m_sErrMsg,  "UpPKGAssist1 is error,iRet=[%d][%s]", iRet, m_sPkgNo);
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg001::UpdatePkg");
    return 0;
}

INT32 CSendPkg001::UpdateSndList(LPCSTR sProcstate)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Enter CSendPkg001::UpdateSndList");

    memset(m_sSqlStr, 0x00, sizeof(m_sSqlStr));

    string strSql = "update bp_bcoutsendlist set statetime=sysdate, msgid='";
    strSql += m_sPkgNo;
    strSql += "', procstate='";
    strSql += sProcstate;
    strSql += "', npcmsg='";
    strSql += m_sMsgTxt;
    strSql += "' where txid='";
    strSql += m_sMsgId;
    strSql += "' and dbtrbrnchid='";
    strSql += m_sSendOrg;
    strSql += "' ";
                			
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "__strSql=[%s]", strSql.c_str());

    iRet = m_cBpbcsndlist.execsql(strSql);
    if (iRet != SQL_SUCCESS)
    {
        snprintf(m_sErrMsg, sizeof(m_sErrMsg), 
            "[bp_bcoutsendlist]Update Failed! %s", m_cBpbcsndlist.GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        if ( 0 == strcmp(sProcstate, PR_HVBP_95))
        {
            //��������ʱ�����쳣,������쳣������״̬,���ﲻ���쳣
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
        }
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Leave CSendPkg001::UpdateSndList");
    return 0;
}

INT32 CSendPkg001::SetErrACK(int iErrCode, LPCSTR pErrDesc)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Enter CSendPkg001::SetErrACK");

	//�޸�״̬Ϊ"���޸�"
    UpdateSndList(PR_HVBP_93);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Leave CSendPkg001::SetErrACK");
	return 0;
}

int CSendPkg001::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Enter CSendPkg001::FundSettle...");
	
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û�[%s]", m_szOprUser);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_sSendOrg);

	m_charge.m_amount = m_cBpbcsndlist.m_amount*100;	//ҵ����
	m_charge.m_iDCFlag = iDEBITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, MBVIRSUALNETID);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_sSendOrg);	//������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(RTN_SUCCESS != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FundSettle iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Leave CSendPkg001::FundSettle..."); 
    
    return RTN_SUCCESS;
}

