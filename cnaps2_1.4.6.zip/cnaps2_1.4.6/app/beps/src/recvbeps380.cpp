/******************************************************************** 
文件名： recvbeps380.cpp
创建人： handongfeng
日  期： 2011-02-23
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbeps380.h"

CRecvbeps380::CRecvbeps380()
{
    m_iChgTp = 1;
    m_iTotalNum = 0;
    m_iTotalAmt = 0.00;
    m_colltnchrgscl.m_msgtp = "beps.380.001.01";
    m_colltnchrgslist.m_msgtp = "beps.380.001.01";
}

CRecvbeps380::~CRecvbeps380()
{

}

void CRecvbeps380::CheckSign380()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms380::CheckSign380");

    m_beps380.getOriSignStr();
	
	CheckSign(m_beps380.m_sSignBuff.c_str(),
			m_beps380.m_szDigitSign.c_str(),
			m_beps380.InstgDrctPty.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms380::CheckSign380");
}

int CRecvbeps380::Work(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps380::Work()");
    
    // 解析报文
    unPack(szMsg);
 
    //填充数据
    SetData(szMsg);
    
    //核签
  
    CheckSign380();

    
    // 插入来帐数据
    InsertData();
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps380::Work()");
    return OPERACT_SUCCESS;
}

INT32 CRecvbeps380::unPack(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps380::unPack()");
    int iRet = -1;
    
	// 报文是否为空
	if (NULL == szMsg || '\0' == szMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "报文为空");
	}
    
	//获取工作日期
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");	
		PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
	}
    m_strWorkDate = m_sWorkDate;    

    // 解析报文
    if (OPERACT_SUCCESS != m_beps380.ParseXml(szMsg))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错! iRet= %d", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "获取解析对象失败");
    }

    //ZFPTLOG.SetLogInfo("380", m_beps380.MsgId.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps380::unPack()");
    return OPERACT_SUCCESS;
}

INT32 CRecvbeps380::InsertData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps380::InsertData()");

    m_colltnchrgscl.m_procstate = "01" ; 
	m_colltnchrgscl.m_busistate = PROCESS_PR00;
    m_colltnchrgscl.m_workdate = m_strWorkDate ; 
    m_colltnchrgscl.m_trnsmtdt = m_beps380.TrnsmtDt ;   
	m_colltnchrgscl.m_finalstatedate = m_beps380.TrnsmtDt;  
    m_colltnchrgscl.m_consigdate = m_strWorkDate ; 
    m_colltnchrgscl.m_mesgid = m_beps380.m_PMTSHeader.getMesgID(); 
    m_colltnchrgscl.m_mesgrefid = m_beps380.m_PMTSHeader.getMesgRefID();
    m_colltnchrgscl.m_syscd = "BEPS" ; 
    m_colltnchrgscl.m_srcflag = '2' ; 
                
    //以下注释内容为数据库中不需要填的字段

    //m_colltnchrgscl.m_rjctinf = m_beps380. ; 
    //m_colltnchrgscl.m_rjctprcpty = m_beps380. ; 
    //m_colltnchrgscl.m_npcprcsts = m_beps380. ; 
    //m_colltnchrgscl.m_npcprccd = m_beps380. ; 
    //m_colltnchrgscl.m_npcrjctinf = m_beps380. ; 
    //m_colltnchrgscl.m_netgdt = m_beps380.NetgDt ; 
    //m_colltnchrgscl.m_netgrnd = m_beps380.NetgRnd ; 
    //m_colltnchrgscl.m_statetime = m_beps380. ; 实体类赋值
    //m_colltnchrgscl.m_finalstatedate = m_beps380. ; 
    //m_colltnchrgscl.m_orgnlmsgid = m_beps380. ; 
    //m_colltnchrgscl.m_orgnlinstgpty = m_beps380. ; 
    //m_colltnchrgscl.m_orgnlbtchnb = m_beps380. ; 
    //m_colltnchrgscl.m_rcvgttlamt = m_beps380. ; 
    //m_colltnchrgscl.m_rcvgttlnb = m_beps380. ; 

    m_colltnchrgscl.m_msgid = m_beps380.MsgId; 
    m_colltnchrgscl.m_checkstate = "1"; 
    m_colltnchrgscl.m_instgdrctpty = m_beps380.InstgDrctPty; 
    m_colltnchrgscl.m_instgpty = m_beps380.GrpHdrInstgPty; 
    m_colltnchrgscl.m_instddrctpty = m_beps380.InstdDrctPty; 
    m_colltnchrgscl.m_instdpty = m_beps380.GrpHdrInstdPty; 
    m_colltnchrgscl.m_rmk = m_beps380.Rmk; 
    m_colltnchrgscl.m_btchnb = m_beps380.BtchNb; 
    m_colltnchrgscl.m_dbtrmmbid = m_beps380.DbtrAgtMmbId; 
    m_colltnchrgscl.m_cdtrmmbid = m_beps380.CdtrAgtMmbId; 
    m_colltnchrgscl.m_cdbtrnm = m_beps380.CdtrNm; 
    m_colltnchrgscl.m_cdbtrid = m_beps380.CdtrAcctId; 
    m_colltnchrgscl.m_cdbtrbrnchid = m_beps380.CdtrAgtId; 
    m_colltnchrgscl.m_currency = m_beps380.TtlAmtCcy; 
    m_colltnchrgscl.m_ttlamt = atof(m_beps380.TtlAmt.c_str()); 
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_beps380.TtlAmt=%s", m_beps380.TtlAmt.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_beps380.TtlAmt=%f", m_colltnchrgscl.m_ttlamt);
	
    m_colltnchrgscl.m_cdbtrnb = atoi(m_beps380.DbtrNb.c_str()) ; 
    m_colltnchrgscl.m_ctgyprtry = m_beps380.CtgyPurpPrtry ; 
    //m_colltnchrgscl.m_puryprtry = m_beps380.PurpPrtry ; 
	m_colltnchrgscl.m_rtrltd = atoi(m_beps380.RtrLtd.c_str());
    //m_colltnchrgscl.m_busistate = m_beps380. ; 
    //m_colltnchrgscl.m_processcode = m_beps380. ; 
    
    SETCTX(m_colltnchrgscl);
    int iRet = m_colltnchrgscl.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__,  __LINE__, NULL, 
            "m_BpBcList.insert() failed:error code =[%d],error cause =[%s]", iRet,m_colltnchrgscl.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "新增明细表失败");
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps380::InsertData()  iRet=%d", iRet);
    return iRet;
}

INT32 CRecvbeps380::SetData(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps380::SetData()");

    SETCTX(m_colltnchrgslist);

    //获取通信id
    char sMesgId[20 + 1] = {0};
    
    GetMsgIdValue(m_dbproc, sMesgId, eRefId,  SYS_BEPS);
    
    m_colltnchrgslist.m_instgdrctpty = m_beps380.InstgDrctPty;//发起直接参与机构
    m_colltnchrgslist.m_instgpty = m_beps380.GrpHdrInstgPty;//间接发起参与机构
    m_colltnchrgslist.m_instddrctpty = m_beps380.InstdDrctPty;//接收直接参与机构
    m_colltnchrgslist.m_instdpty = m_beps380.GrpHdrInstdPty;//间接发起参与机构
    m_colltnchrgslist.m_syscd = "BEPS"           ;//系统编号
    
    int iNum = m_beps380.GetNodeCountByName("DbtrDtls");
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iNum[%d]",iNum);

    for(int i = 0; i < iNum; i++)
    {
        m_beps380.ParseDetail(i);

        m_colltnchrgslist.m_workdate = m_strWorkDate;
        m_colltnchrgslist.m_consigdate = m_strWorkDate;
        m_colltnchrgslist.m_msgtp = "beps.380.001.01";
        m_colltnchrgslist.m_mesgid = sMesgId;
        m_colltnchrgslist.m_mesgrefid = sMesgId;
        m_colltnchrgslist.m_msgid = m_beps380.MsgId;//报文标识号	
        m_colltnchrgslist.m_rmk = m_beps380.Rmk;//备注
        m_colltnchrgslist.m_srcflag = "2";
        m_colltnchrgslist.m_btchnb = m_beps380.BtchNb;
        m_colltnchrgslist.m_txid = m_beps380.TxId;
        m_colltnchrgslist.m_dbtrnm = m_beps380.DbtrNm           ;//付款人户名
        m_colltnchrgslist.m_dbtrid = m_beps380.DbtrAcctId           ;//付款人账号
        m_colltnchrgslist.m_dbtrmmbid = m_beps380.DbtrAgtMmbId;
        m_colltnchrgslist.m_dbtrbrnchid = m_beps380.DbtrDtlsBrnchId           ;//付款行行号
        m_colltnchrgslist.m_cdtrmmbid = m_beps380.CdtrAgtMmbId;
        m_colltnchrgslist.m_cdtrbrnchid = m_beps380.CdtrAgtId           ;//收款行行号
        m_colltnchrgslist.m_cdtrnm = m_beps380.CdtrNm;//收款人名称
        m_colltnchrgslist.m_cdtrid = m_beps380.CdtrAcctId;//收款人账号
        m_colltnchrgslist.m_currency = m_beps380.AmtCcy;//货币符号
        m_colltnchrgslist.m_currency = "CNY";//测试用
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_colltnchrgslist.m_currency=%s", m_colltnchrgslist.m_currency.c_str());
        m_colltnchrgslist.m_amout = atof(m_beps380.Amt.c_str());//金额
        m_colltnchrgslist.m_ctgyprtry = m_beps380.CtgyPurpPrtry;
        m_colltnchrgslist.m_puryprtry = m_beps380.PurpPrtry;
        m_colltnchrgslist.m_endtoendid = m_beps380.EndToEndId;
        m_colltnchrgslist.m_chckflg = m_beps380.ChckFlg;
        //m_colltnchrgslist.m_busistate = m_beps380.           ;//业务状态
        //m_colltnchrgslist.m_processcode  = m_beps380.p           ;//业务拒绝处理码
        //m_colltnchrgslist.m_rjctinf  = m_beps380.           ;//业务拒绝信息
        //m_colltnchrgslist.m_rjctprcpty = m_beps380.           ;//业务处理参与机构

        m_colltnchrgslist.m_procstate = "01";
        //m_colltnchrgslist.m_npcprcsts = 
        //m_colltnchrgslist.m_npcprccd
        //m_colltnchrgslist.m_npcrjctinf
        //m_colltnchrgslist.m_netgdt = m_beps380.           ;//NPC轧差日期
        //m_colltnchrgslist.m_netgrnd = m_beps380.           ;//NPC轧差场次
        //m_colltnchrgslist.m_finalstatedate = m_beps380.           ;//NPC清算日期/终态日期

        //m_colltnchrgslist.m_orgnlmsgid = m_beps380.           ;//原报文标识号
        //m_colltnchrgslist.m_orgnlinstgpty = m_beps380.           ;//原发起参与机构
        //m_colltnchrgslist.m_orgnlbtchnb = m_beps380.           ;//原批次序号
        
        m_colltnchrgslist.m_addtlinf = m_beps380.GetAddtlInf(i);//附言
        printf("m_colltnchrgslist.m_addtlinf[%s]\n", m_colltnchrgslist.m_addtlinf.c_str());
        //m_colltnchrgslist.m_mbmsgid = m_beps380.;
        
        //明细表插入数据
        if(OPERACT_SUCCESS != m_colltnchrgslist.insert())
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "插入明细表失败,回滚汇总表, ERROR = %s", m_colltnchrgslist.GetSqlErr());
            break; //return OPERACT_FAILED;  回执这里不能直接返回
        }
        
        // 循环加签要素
        //m_beps380.AddTxStr();  

        ++m_iTotalNum;
        m_iTotalAmt += m_colltnchrgslist.m_amout;
    }


    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps380::SetData()");
    return OPERACT_SUCCESS;
}



