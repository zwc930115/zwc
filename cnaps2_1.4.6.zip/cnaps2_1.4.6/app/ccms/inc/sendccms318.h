/********************************************************************
�ļ�����sendccms318.h
�����ˣ�aps-lel
��  �ڣ�2011.04.02
��  ����
��  ����
Copyright (c) 2011  YLINK
********************************************************************/

#ifndef __SENDCCMS318_H__
#define __SENDCCMS318_H__

#include "sendccmsbase.h"
#include "ccms318.h"
#include "cmpmtrtrcl.h"
#include "cmpmtrtrlist.h"


class CSendCcms318 : public CSendCcmsBase
{
public:
	CSendCcms318(const stuMsgHead& Smsg);
	~CSendCcms318();
	int doWorkSelf();
private:
	void SetData();
	
	int  GetData();
	
	int  UpdateState();
	
	void AddDetail();
	
	void SetDBKey();
	
	void AddSign318();

private:
	CCmpmtrtrcl m_cmpmtrtrcl;
	CCmpmtrtrlist m_cmpmtrtrlist;
	ccms318 m_ccms318;
};

#endif


