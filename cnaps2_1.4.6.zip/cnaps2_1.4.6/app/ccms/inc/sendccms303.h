/********************************************************************
�ļ�����send303.h
�����ˣ�handongfeng
��  �ڣ�2011.01.14
��  ����
��  ����
Copyright (c) 2009  YLINK
********************************************************************/

#ifndef __SENDCCMS303_H__
#define __SENDCCMS303_H__

#include "sendccmsbase.h"
#include "ccms303.h"
#include "cmfreeinfo.h"

class CSendCcms303 : public CSendCcmsBase
{
public:
    CSendCcms303(const stuMsgHead& Smsg);
    ~CSendCcms303();
    int doWorkSelf();
private:
    void SetData();
    int GetData();
    int UpdateState();
    void SetDBKey();
private:
    CCmfreeinfo m_Cmfreeinfo;
    ccms303     m_ccms303;
};

#endif


