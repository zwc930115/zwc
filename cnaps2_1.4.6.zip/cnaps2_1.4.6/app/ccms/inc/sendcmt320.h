/******************************************************************** 
�ļ����� sendcmt320.h
�����ˣ� handonfeng
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef __SENDCMT320_H__
#define __SENDCMT320_H__

#include "cmt320.h"
#include "cmpmtrtrcl.h"
#include "cmpmtrtrlist.h"
#include "bpbcoutrcvclhis.h"
#include "bpbcoutrecvlisthis.h"
#include "bpbcoutrcvcl.h"
#include "bpbcoutrecvlist.h"
#include "sendccmsbase.h"

class CSendCmt320 : public CSendCcmsBase
{
public:
    CSendCmt320(const stuMsgHead& Smsg);
    ~CSendCmt320();
    
    int  doWorkSelf();
    
private:
    int buildCmtMsg();
	int GetData();
	INT32 SetData();
    int UpdateState();
    int CreateSql(const char *sTableName,const char *sMsgid,const char *sMsgTp,const char *sSendBank,const char *txid=0,bool sFlag=false);

    cmt320              m_cmt320;
    CCmpmtrtrcl         m_cmpmtrtrcl;
	CCmpmtrtrcl         m_Orgncmpmtrtrcl;
	CCmpmtrtrlist       m_cmpmtrtrlist;
	
	CBpbcoutrcvcl       m_bpbcoutrcvcl;
	CBpbcoutrcvclhis    m_bpbcoutrcvclhis;
	CBpbcoutrecvlist    m_bpbcoutrecvlist;
	CBpbcoutrecvlisthis m_bpbcoutrecvlisthis;

	string              m_orgnltxid;
	string              m_strSql;
};

#endif


