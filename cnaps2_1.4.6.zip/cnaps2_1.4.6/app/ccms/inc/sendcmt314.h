/********************************************************************
�ļ�����sendcmt314.h
�����ˣ�xiaocuiming
��  �ڣ�2011.07.04
��  �����������ҵ���˻�Ӧ����
��  ����
Copyright (c) 2011  YLINK
********************************************************************/

#ifndef __SENDCMT314_H__
#define __SENDCMT314_H__


#include "sendccmsbase.h"
#include "cmt314.h"
#include "cmpmtrtrcl.h"
#include "cmpmtrtrlist.h"


class CSendCmt314 : public CSendCcmsBase
{
public:
    CSendCmt314(const stuMsgHead& Smsg);
    ~CSendCmt314();
    int doWorkSelf();
private:

    int buildCmtMsg();
    void SetData();
	
    int  GetData();
	
    int  UpdateState();

	void SetDBKey();

private:
    CCmpmtrtrcl   m_cmpmtrtrcl;
    CCmpmtrtrcl   m_Oricmpmtrtrcl;
	CCmpmtrtrlist m_cmpmtrtrlist;
    cmt314       m_cCmt314;
};

#endif



