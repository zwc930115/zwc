/********************************************************************
�ļ�����send307.h
�����ˣ�handongfeng
��  �ڣ�2011.01.14
��  ����
��  ����
Copyright (c) 2009  YLINK
********************************************************************/
#ifndef __SENDCCMS307_H__
#define __SENDCCMS307_H__

#include "sendccmsbase.h"
#include "ccms307.h"
#include "cmtransrepeal.h"

class CSendCcms307 : public CSendCcmsBase
{
public:
	CSendCcms307(const stuMsgHead& Smsg);
	~CSendCcms307();
	int doWorkSelf();
private:
	void SetDBKey();
	void SetData();
	int GetData();
	int UpdateState();
	void  AddSign307();

private:
	CCmtransrepeal m_CmTrRepeal;
	ccms307        m_ccms307;
};

#endif


