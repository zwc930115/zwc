/******************************************************************** 
文件名： bepschangeday.h
创建人： hq
日  期： 2011-05-09
修改人： 
日  期： 
描  述： 小额日切类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef _BEPSCHANGEDAY_H__
#define _BEPSCHANGEDAY_H__

#include "bpbdrcvcl.h"
#include "recvccmsbase.h"
//#include "bpbchkstate.h"
#include "cmbclsstpmglist.h"
#include "syssysparm.h"
#include "cmsysparam.h"
#include "cmmsgtype.h"
#include "cmsyspamntfctnlist.h"
#include "cmbkcdchgntfctnlist.h"
#include "cmbankinfo.h"
#include "cmccpcchng.h"
#include "cmcitychng.h"
#include "cmbktpchng.h"
#include "cmbktype.h"
#include "cmcity.h"
#include "cmccpc.h"
#include "cmcisagent.h"
#include "cmcisagchgntfctnlist.h"
#include "bpsapbankinfo.h"

class CBepsChangeDay
{
public:	
	
	CBepsChangeDay();
	~CBepsChangeDay(){};

	int     doChangeWork(DBProc &dbproc, int iFun, LPCSTR sBankNo, LPCSTR sOrgnlSysDt, LPCSTR sCurSysDt);
private:
    void    GetData();
    void    InsertMsgType(const CCmbclsstpmglist* cmlist);
    void    changcmlist();
    void    InsertSysparm(const CCmsyspamntfctnlist* bclsstpmslist);
    void    changbclsstpmslist();
    void    Insertbankinfo(const CCmbkcdchgntfctnlist* citychng);
    void    changBankinfo();
    void    Insertccpc(const CCmccpcchng* citychng);
    void    changccpcchng();
    void    InsertCity(const CCmcitychng* citychng);
    void    changCitychng();
    void    InsertBktype(const CCmbktpchng* bktpchng);
    void    changBktpchng();
    void    ChangTableState(CEntityBase* BaseListObj, int iTableFlag, string sSQLHead);
    void    InsertCIS(const CCmcisagchgntfctnlist* m_cisagchgntfctnlist);
    void    changCISlist();
    
	void    changEffect();   //2.生效变更
	void    resetSerialNo(); //3.序号重置
    void    upLastLimited(); //4.回执期限
    
    void    MoveTransToHistory(LPCSTR pBankNo, LPCSTR pOriSysDt);

    void    MoveCrdtToHistory(CEntityBase& entity, LPCSTR pBankNo, LPCSTR pOriSysDt);

    void    MoveDbetToHistory(CEntityBase& entity, LPCSTR pBankNo, LPCSTR pOriSysDt);

    int     DoExecute(CEntityBase& entity, LPCSTR szSql, LPCSTR szTitle);

    void    DeleteHistoryTrans(LPCSTR pBankNo, LPCSTR pOriSysDt);
    CBpsapbankinfo          m_Bpsapbankinfo;

    CCmmsgtype              m_cmmsgtype;
    CCmbclsstpmglist        m_cmlist;

    CCmsysparam             m_cmsysparm;
    CCmsyspamntfctnlist     m_Cmsyspamntfctnlist;

    CCmcisagent             m_cisagent;
    CCmcisagchgntfctnlist   m_cisagchgntfctnlist;
    
    CCmbankinfo             m_Cmbankinfo;
    CCmbkcdchgntfctnlist    m_Cmbkcdchgntfctnlist;

    CCmccpc                 m_ccpc;
    CCmccpcchng             m_ccpcchng;

    CCmcity                 m_city;
    CCmcitychng             m_citychng;

    CCmbktype               m_bktype;
    CCmbktpchng             m_bktpchng;
    
    CBpbdrcvcl              m_CBpbdrcvcl;

    DBProc	                m_dbproc;
	char	                m_sOrgnlSysDt[8 + 1];   //原系统日期
	char	                m_sCurSysDt[8 + 1];     //系统当前日期
	char                    m_szNextSysDt[8 + 1];   //下一工作日期   
	char                    m_sBankNo[14 + 1];      //清算行号
	string                  m_szFeastFlg;           //节假日标志:0非假日 1节假日

	//add begin by jienjun 2017/06/19 SRS-HUB-001
	string					m_vBnkChgInfo;
	int 					m_Icount;	
	//add end by jienjun 2017/06/19 SRS-HUB-001
	
	
};

#endif

