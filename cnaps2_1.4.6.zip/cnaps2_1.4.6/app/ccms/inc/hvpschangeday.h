/******************************************************************** 
文件名： hvpschangeday.h
创建人： handongfeng
日  期： 2011-05-09
修改人： 
日  期： 
描  述： 大额日切类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef _HVPSCHANGEDAY_H__
#define _HVPSCHANGEDAY_H__

#include "recvccmsbase.h"
#include "hvsapwtchgedt.h"
#include "hvbkchkst.h"
#include "hvsapbankinfo.h"
#include "cmmsgtype.h"
#include "cmbclsstpmglist.h"
#include "syssysparm.h"
#include "cmsyspamntfctnlist.h"
#include "cmbkcdchgntfctnlist.h"
#include "cmbankinfo.h"
#include "cmccpcchng.h"
#include "cmcitychng.h"
#include "cmbktpchng.h"
#include "cmbktype.h"
#include "cmcity.h"
#include "cmccpc.h"
#include "cmsysparam.h"

class CHvpsChangeDay
{
public:	
	
	CHvpsChangeDay();
	~CHvpsChangeDay(){};

	int doChangeWork(DBProc &dbproc, int iFun, int iDayCutType, LPCSTR sBankNo, LPCSTR sOrgnlSysDt, LPCSTR sCurSysDt);

private:
    void    GetData();   
    void    CompareCheckState();    
	void    changEffect();          //2.生效变更
	void    resetSerialNo();        //3.序号重置
    void    upLastLimited();        //4.回执期限

    void    InsertMsgType(const CCmbclsstpmglist* cmlist);
    void    changcmlist();
    void    InsertSysparm(const CCmsyspamntfctnlist* bclsstpmslist);
    void    changbclsstpmslist();
    void    Insertbankinfo(const CCmbkcdchgntfctnlist* citychng);
    void    changBankinfo();
    void    Insertccpc(const CCmccpcchng* citychng);
    void    changccpcchng();
    void    InsertCity(const CCmcitychng* citychng);
    void    changCitychng();
    void    InsertBktype(const CCmbktpchng* bktpchng);
    void    changBktpchng();
    void    ChangTableState(CEntityBase* BaseListObj, int iTableFlag, string sSQLHead);
    void    UpdateState();
    void    MoveData();
    
	char	m_sOrgnlSysDt[8 + 1];   //原系统日期
	char	m_sCurSysDt[8 + 1];     //系统当前日期
	char    m_szNextSysDt[8 + 1];   //下一工作日期   
	char    m_sBankNo[14 + 1];      //清算行号
	string  m_szFeastFlg;           //节假日标志:0非假日 1节假日
    DBProc	m_dbproc;
    
    
    CHvsapbankinfo      m_Hvsapbankinfo;
    
    CHvsapwtchgedt      m_Hvsapwtchgedt;
    CHvbkchkst          m_Hvbkchkst;

    CCmmsgtype          m_cmmsgtype;
    CCmbclsstpmglist    m_cmlist;

    CCmsysparam         m_cmsysparm;
    CCmsyspamntfctnlist m_Cmsyspamntfctnlist;

    CCmbankinfo         m_Cmbankinfo;
    CCmbkcdchgntfctnlist m_Cmbkcdchgntfctnlist;

    CCmccpc             m_ccpc;
    CCmccpcchng         m_ccpcchng;

    CCmcity             m_city;
    CCmcitychng         m_citychng;

    CCmbktype           m_bktype;
    CCmbktpchng         m_bktpchng;
};

#endif

