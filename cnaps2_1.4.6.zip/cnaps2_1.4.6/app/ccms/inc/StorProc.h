/********************************************************************
文件名：StorProc.cpp
创建人：hdf
日  期：2011.01.14
修改人：hdf
日  期：
描  述：
版  本：
Copyright (c) 2009  YLINK
********************************************************************/
#ifndef __STORPROC_H__
#define __STORPROC_H__

#include "entitybase.h"
#include "hvtrofacsndlist.h"
#include "hvtrofacsndlisthis.h"
#include "hvsndexchglist.h"
#include "hvsndexchglisthis.h"
#include "hvtrofacrcvlist.h"
#include "hvtrofacrcvlisthis.h"
#include "hvrcvexchglist.h"
#include "hvrcvexchglisthis.h"
#include "bpbdsendlist.h"
#include "bpbdsendlisthis.h"
#include "bpbdsndcl.h"
#include "bpbdsndclhis.h"
#include "bpbcoutsendlist.h"
#include "bpbcoutsendlisthis.h"
#include "bpbcoutsndcl.h"
#include "bpbcoutsndclhis.h"
#include "bpbdrcvcl.h"
#include "bpbdrcvclhis.h"
#include "bpbcoutrecvlist.h"
#include "bpbcoutrecvlisthis.h"
#include "bpbcoutrcvcl.h"
#include "bpbcoutrcvclhis.h"
/*#include ""
#include ""
#include ""
#include ""
#include ""
#include ""
#include ""
#include ""
#include ""*/

class CStorProc
{
    public:

        CStorProc();

        ~CStorProc();

        int doWork();

    private:

        DBProc	m_dbproc;
        
        void GetDBConnect(void);

        int SqlProccess(string SrcTable, string DstTable);
        
        CEntityBase m_BaseSql;
};

#endif

