/******************************************************************** 
文件名： sendcmt327.h
创建人： handonfeng
日  期： 2011-04-18
修改人： 
日  期： 
描  述：小额借记止付往帐327报文处理类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef __SENDCMT327_H__
#define __SENDCMT327_H__

#include "cmt327.h"
#include "bpcstbdpcxlcl.h"
#include "bpcstbdpcxllist.h"
#include "sendccmsbase.h"

class CSendCmt327 : public CSendCcmsBase
{
public:
    CSendCmt327(const stuMsgHead& Smsg);
    ~CSendCmt327();
    
    INT32  doWorkSelf();
    
private:

	int  GetData();
	int  CreateNpcMsg();
    int  UpdateState();
    
    cmt327              m_cmt327;
    CBpcstbdpcxlcl		m_cBpcstbdpcxlcl;
    CBpcstbdpcxllist	m_cBpcstbdpcxllist;
};

#endif


