/******************************************************************** 
文件名： bepschangeday.cpp
创建人： hq
modify:  handongfeng
日  期： 2011-05-09
修改人： 
日  期： 
描  述： 小额日切类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "bepschangeday.h"
#include "exception.h"


extern CConnectPool *g_DBConnPool;
using namespace ZFPT;

CBepsChangeDay::CBepsChangeDay()
{
	memset(m_sCurSysDt  , NULL_CHAR, sizeof(m_sCurSysDt     ));
	memset(m_sOrgnlSysDt, NULL_CHAR, sizeof(m_sOrgnlSysDt   ));
	memset(m_szNextSysDt, NULL_CHAR, sizeof(m_szNextSysDt   ));
	memset(m_sBankNo    , NULL_CHAR, sizeof(m_sBankNo       ));
	m_szFeastFlg = "";
}

void CBepsChangeDay::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsChangeDay::GetData()");

    SETCTX(m_Bpsapbankinfo);
    
    m_Bpsapbankinfo.m_sapbank = m_sBankNo;
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_Bpsapbankinfo.m_sapbank = [%s]", m_Bpsapbankinfo.m_sapbank.c_str());
    
	int iRet = m_Bpsapbankinfo.findByPK();
	if ( SQL_SUCCESS != iRet)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL,  "获取对账状态表记录出错,iRet=[%d] %s", iRet, m_Bpsapbankinfo.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, "获取对账状态表记录出错");
	}
    
    m_szFeastFlg = m_Bpsapbankinfo.m_feastflag;
    strncpy(m_szNextSysDt, m_Bpsapbankinfo.m_nextdate.c_str(), sizeof(m_szNextSysDt));
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsChangeDay::GetData()");
}

int CBepsChangeDay::doChangeWork(DBProc &dbproc, int iFun, LPCSTR sBankNo, LPCSTR sOrgnlSysDt, LPCSTR sCurSysDt)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsChangeDay::doChangeWork()");
	
	if (NULL == sOrgnlSysDt || '\0' == sOrgnlSysDt || 8 != strlen(sOrgnlSysDt)) 
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "_pOrgnlSysDt error");
		return PRM_FAIL;
	}
	
    strncpy(m_sOrgnlSysDt   , sOrgnlSysDt   , sizeof(m_sOrgnlSysDt  ) - 1);
	strncpy(m_sCurSysDt     , sCurSysDt     , sizeof(m_sCurSysDt    ) - 1);
	strncpy(m_sBankNo       , sBankNo       , sizeof(m_sBankNo      ) - 1);
	m_dbproc = dbproc;
	
    // 日切处理
	try
	{
	    GetData();
	    switch(iFun)
	    {
	        case 0:
	        {
	            upLastLimited();        //1.回执期限
	            
	            changEffect();			//2.生效变更
	            
	            MoveTransToHistory(sBankNo, sOrgnlSysDt); //迁移历史数据

	            //DeleteHistoryTrans(sBankNo, sOrgnlSysDt); //清除历史数据
				resetSerialNo();		//3.序号重置
	            
	            break;
	        }
	        case 1:
	        {
	            upLastLimited();        //2.回执期限
                break;
	        }
	        case 2:
	        {
	            changEffect();			//3.生效变更
                break;
	        }
	        case 3:
	        {
	            resetSerialNo();		//4.序号重置
                break;
	        }
	        default:
	        {
	            Trace(L_ERROR, __FILE__, __LINE__, NULL, "没有匹配的函数入口标志iFun=%d", iFun);
	            return RTN_FAIL;
	        }
    	}
	}
	catch (CException &e)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, 
        	"Catch a exception from [%s][%d][%s]", e.file(), e.line(), e.what());
		
		return e.code();
	}

    // 客户通知信息
    string sTellInfo = "";
    sTellInfo += "小额日切成功,当前工作日期:";
    sTellInfo += m_sCurSysDt;
	//NotifyOprUser(m_dbproc,"0", "02", sTellInfo.c_str(), m_sBankNo);
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsChangeDay::doChangeWork()");
	return RTN_SUCCESS;
}

void CBepsChangeDay::upLastLimited()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsChangeDay::upLastLimited()");

    if (m_szFeastFlg == "1")
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "节假日,不处理回执期限");
        return;
    }
    
    int iRet = -1;
    string whereStr     = "";
    string updateStr    = "";
    
    //1、是否存在剩余回执期限小于等于1天的借记业务 
    whereStr =" INSTGDRCTPTY = '";
    whereStr += m_sBankNo;
    whereStr += "' AND PROCSTATE = '";
    whereStr += PR_HVBP_21;
    whereStr += "' AND PKGRTRLTD <= 1";
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "whereStr = [%s]", whereStr.c_str());

    SETCTX(m_CBpbdrcvcl);
    
	iRet = m_CBpbdrcvcl.findcount(whereStr);
	if ( SQL_SUCCESS != iRet )
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "查询BP_BDRCVCL表失败[%d][%s]",
            iRet, m_CBpbdrcvcl.GetSqlErr());

        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, "查询BP_BDRCVCL表失败");
	}
    
	if (m_CBpbdrcvcl.m_iCount >= 1)
	{
	    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "存在剩余回执期限只剩一天的借记业务，请尽快回执!");
		//NotifyOprUser(m_dbproc, "2", "02", "存在剩余回执期限只剩一天的借记业务，请尽快回执!", m_sBankNo);
	}
    
    //2、修改回执期限
    updateStr =  "UPDATE BP_BDRCVCL SET PKGRTRLTD = PKGRTRLTD - 1 ";
    updateStr += "where INSTGDRCTPTY = '";
    updateStr += m_sBankNo;
    updateStr += "' AND PROCSTATE = '";
    updateStr += PR_HVBP_21;
    updateStr += "' AND PKGRTRLTD >= 1";
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "updateStr = [%s]", updateStr.c_str());
    
	iRet = m_CBpbdrcvcl.execsql(updateStr);
	if(SQLNOTFOUND == iRet)
	{
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "未找到记录.(正常)");
	    return;
	}
	else if (SQL_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新BP_BDRCVCL表失败[%d][%s]",
            iRet, m_CBpbdrcvcl.GetSqlErr());

        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "更新BP_BDRCVCL表失败");
	}

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsChangeDay::upLastLimited()");
}

void CBepsChangeDay::changEffect()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsChangeDay::changEffect()");

	changcmlist();			    //1.1 业务种类与类型管理<ccms.906.001.01>
    changbclsstpmslist();
    changCISlist();
    changBankinfo();
    changccpcchng();
    changCitychng();
    changBktpchng();
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsChangeDay::changEffect()");
}

/*********************************************/
void CBepsChangeDay::InsertMsgType(const CCmbclsstpmglist* cmlist)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsChangeDay::InsertMsgType()");

    SETCTX(m_cmmsgtype);

    m_cmmsgtype.m_msgtype           = cmlist->m_mt;         
    m_cmmsgtype.m_biztype           = cmlist->m_txtpcd;     
    m_cmmsgtype.m_bizdtltypepurpose = cmlist->m_ctgypurpcd; 
    m_cmmsgtype.m_syscode = "BEPS";
    //删除原有记录
    int iRet = m_cmmsgtype.remove();
	if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "删除表记录失败[%d][%s]",
		    iRet, m_cmmsgtype.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_DEL_FAIL, "删除表记录失败");
	}

    //如果变更类型是新增/变更，则新增记录
    if ( "CC00" == cmlist->m_chngtp || "CC01" == cmlist->m_chngtp)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "1111111111111111111");
        int iValue = m_cmmsgtype.insert();
        if(RTN_SUCCESS != iValue)
        {
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "插入表失败[%d][%s]", iValue, m_cmmsgtype.GetSqlErr());	
    		PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, "插入表失败");
        }
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsChangeDay::InsertMsgType()");
}

void CBepsChangeDay::changcmlist()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsChangeDay::changcmlist()");

    try
    {
        string sSQLHead = "UPDATE cm_bclsstpmglist t SET t.PROCSTATE = '";
        ChangTableState(&m_cmlist, 1, sSQLHead);
    }
    catch(CException &e)
    {
        m_cmlist.closeCursor();
        PMTS_ThrowException(UNKNOWN_ERR);
    }
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsChangeDay::changcmlist()");
}
/*********************************************/

/*********************************************/
void CBepsChangeDay::InsertCIS(const CCmcisagchgntfctnlist* m_cisagchgntfctnlist)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsChangeDay::InsertCIS()");

    SETCTX(m_cisagent);

    m_cisagent.m_bankcode = m_cisagchgntfctnlist->m_bankcode;         
    m_cisagent.m_bbnkcode = m_cisagchgntfctnlist->m_bbnkcode;     
    m_cisagent.m_status = m_cisagchgntfctnlist->m_procstate; 

    //删除原有记录
    int iRet = m_cisagent.remove();
	if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "删除表记录失败[%d][%s]",
		    iRet, m_cisagent.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_DEL_FAIL, "删除表记录失败");
	}

    //如果变更类型是新增/变更，则新增记录
    if ( "CC00" == m_cisagchgntfctnlist->m_chngtp || "CC01" == m_cisagchgntfctnlist->m_chngtp)
    {
        int iValue = m_cisagent.insert();
        if(RTN_SUCCESS != iValue)
        {
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "插入表失败[%d][%s]", iValue, m_cisagent.GetSqlErr());	
    		PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, "插入表失败");
        }
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsChangeDay::InsertCIS()");
}

void CBepsChangeDay::changCISlist()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsChangeDay::changCISlist()");

    try
    {
        string sSQLHead = "UPDATE cm_CISAgChgNtfctnlist t SET t.PROCSTATE = '";
        ChangTableState(&m_cisagchgntfctnlist, 7, sSQLHead);
    }
    catch(CException &e)
    {
        m_cisagchgntfctnlist.closeCursor();
        PMTS_ThrowException(UNKNOWN_ERR);
    }
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsChangeDay::changCISlist()");
}
/*********************************************/

/*********************************************/
void CBepsChangeDay::InsertSysparm(const CCmsyspamntfctnlist* bclsstpmslist)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsChangeDay::InsertSysparm()");

    SETCTX(m_cmsysparm);

    m_cmsysparm.m_syscode= bclsstpmslist->m_sysid  ; 
    m_cmsysparm.m_datatype= bclsstpmslist->m_cmondatatp  ; 
    m_cmsysparm.m_datacode= bclsstpmslist->m_cmondatacd  ; 
    m_cmsysparm.m_datachgtype= bclsstpmslist->m_chgtp  ; 
    m_cmsysparm.m_dataname= bclsstpmslist->m_cmondatanm  ; 
    m_cmsysparm.m_datavalue= bclsstpmslist->m_cmondataval  ; 

    //删除原有记录
    int iRet = m_cmsysparm.remove();
	if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "删除表记录失败[%d][%s]",
		    iRet, m_cmsysparm.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_DEL_FAIL, "删除表记录失败");
	}

    //如果变更类型是新增/变更，则新增记录
    if ( "CC00" == bclsstpmslist->m_chgtp || "CC01" == bclsstpmslist->m_chgtp)
    {
        int iValue = m_cmsysparm.insert();
        if(RTN_SUCCESS != iValue)
        {
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "插入表失败[%d][%s]", iValue, m_cmsysparm.GetSqlErr());	
    		PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, "插入表失败");
        }
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsChangeDay::InsertSysparm()");
}

void CBepsChangeDay::changbclsstpmslist()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsChangeDay::changbclsstpmslist()");
	
    try
    {
        string sSQLHead = "UPDATE cm_bclsstpmglist t SET t.PROCSTATE = '";
        ChangTableState(&m_Cmsyspamntfctnlist, 2, sSQLHead);
    }
    catch(CException &e)
    {
        m_Cmsyspamntfctnlist.closeCursor();
        PMTS_ThrowException(UNKNOWN_ERR);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsChangeDay::changbclsstpmslist()");
}
/*********************************************/

/*********************************************/
void CBepsChangeDay::Insertbankinfo(const CCmbkcdchgntfctnlist* bankinfo)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsChangeDay::Insertbankinfo()");

    SETCTX(m_Cmbankinfo);

    m_Cmbankinfo.m_bankcode = bankinfo->m_bankcode;
    m_Cmbankinfo.m_bankname = bankinfo->m_bankname;
    m_Cmbankinfo.m_bankcatalog= bankinfo->m_bankcatalog;
    m_Cmbankinfo.m_banktype = bankinfo->m_banktype;
    m_Cmbankinfo.m_pbccode = bankinfo->m_pbccode;
    m_Cmbankinfo.m_bankcenter = bankinfo->m_bankcenter;
    m_Cmbankinfo.m_bankagent = bankinfo->m_drctbkcd;
    m_Cmbankinfo.m_agentsettbank = "";//代理清算参与机构号
    m_Cmbankinfo.m_dreccode = bankinfo->m_dreccode;
    m_Cmbankinfo.m_syscode = bankinfo->m_sysid;
    m_Cmbankinfo.m_addr = bankinfo->m_addr;
    m_Cmbankinfo.m_postcode = bankinfo->m_postcode;
    m_Cmbankinfo.m_tel = bankinfo->m_tel;
    m_Cmbankinfo.m_email = bankinfo->m_email;
    m_Cmbankinfo.m_effectdate = bankinfo->m_fctvdt;
    m_Cmbankinfo.m_expdate = bankinfo->m_ifctvdt;
    m_Cmbankinfo.m_sbstitnbk = bankinfo->m_sbstitnbk;
    m_Cmbankinfo.m_debtorcity = bankinfo->m_debtorcity;
    m_Cmbankinfo.m_bankaliasname = bankinfo->m_bankaliasname;
    m_Cmbankinfo.m_procstate = bankinfo->m_procstate;
    m_Cmbankinfo.m_proctime = bankinfo->m_proctime;

	//add begin by jienjun 2017/06/19 SRS-HUB-001
	char strTemp[512] = {0};
	
    if ( "CC00" == bankinfo->m_chngtp )//add
    {		
	    sprintf(strTemp,"D %-34s/%-34s\n",m_Cmbankinfo.m_bankcode.c_str(),m_Cmbankinfo.m_bankagent.c_str());		
		m_vBnkChgInfo += strTemp;
		m_Icount ++;
	}
	else if ("CC01" == bankinfo->m_chngtp)//change
	{
	    sprintf(strTemp,"DD%34s/%-34s\n",m_Cmbankinfo.m_bankcode.c_str(),m_Cmbankinfo.m_bankagent.c_str());	
		m_vBnkChgInfo += strTemp;
		sprintf(strTemp,"D %-34s/%-34s\n",m_Cmbankinfo.m_bankcode.c_str(),m_Cmbankinfo.m_bankagent.c_str());	
		m_vBnkChgInfo += strTemp;		
		m_Icount += 2;
	}
	else if ("CC02" == bankinfo->m_chngtp)//delete
    {	
	    sprintf(strTemp,"DD%-34s/%-34s\n",m_Cmbankinfo.m_bankcode.c_str(),m_Cmbankinfo.m_bankagent.c_str());		
		m_vBnkChgInfo += strTemp;		
		m_Icount ++;
    }
	else
	{
		//do nothing
	}
	//add end   by jienjun 2017/06/19 SRS-HUB-001

    //删除原有记录
    int iRet = m_Cmbankinfo.remove();
	if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "删除表记录失败[%d][%s]",
		    iRet, m_Cmbankinfo.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_DEL_FAIL, "删除表记录失败");
	}

    //如果变更类型是新增/变更，则新增记录
    if ( "CC00" == bankinfo->m_chngtp || "CC01" == bankinfo->m_chngtp)
    {
        int iValue = m_Cmbankinfo.insert();
        if(RTN_SUCCESS != iValue)
        {
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "插入表失败[%d][%s]", 
    			                                                iValue, m_Cmbankinfo.GetSqlErr());	
    		PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, "插入表失败");
        }
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsChangeDay::Insertbankinfo()");
}

void CBepsChangeDay::changBankinfo()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsChangeDay::changBankinfo()");
	
    try
    {

	
		//add begin by jienjun 2017/06/19 SRS-HUB-001
		//clear the parmter befor do the ChangTableState
		m_vBnkChgInfo = "";
		m_Icount = 0;
		//add end by jienjun 2017/06/19 SRS-HUB-001

        string sSQLHead = "UPDATE CM_BKCDCHGNTFCTNLIST t SET t.PROCSTATE = '";
        ChangTableState(&m_Cmbkcdchgntfctnlist, 3, sSQLHead);

		//add begin by jienjun 2017/06/19 SRS-HUB-001
		//create the upload file ()
	    char szFileName[gc_nMaxPathLen] = {0};
		char szHead[512] = {0};
		char szTail[512] = {0};
	    char sCmd[512] = {0};
		
		time_t timep;
		struct tm *p;
		time(&timep);
		p = gmtime(&timep);
		FILE* msgFile = NULL;		
		
		sprintf(szFileName, "../sftp/BANKINFO_%d_%d_%d", p->tm_year + 1900, p->tm_mon + 1, p->tm_mday);
		
		sprintf(szHead, "HCN1GPS%d%02d%02d%02u%02u%02u\n", 
			    p->tm_year + 1900, 
			    p->tm_mon + 1, 
			    p->tm_mday,
			    p->tm_hour, 
			    p->tm_min, 
			    p->tm_sec);
		
		sprintf(szTail, "T%07d", m_Icount);
	
	 
		m_vBnkChgInfo = szHead + m_vBnkChgInfo;
		m_vBnkChgInfo = m_vBnkChgInfo + szTail;
		
	    if (NULL != (msgFile = fopen(szFileName, "w+")))
	    {
	        fprintf(msgFile, "%s", m_vBnkChgInfo.c_str());
	        fclose(msgFile);
	    }
	    else
	    {
	    	// write file error,not affect the beps date change,just write log
	        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "写异常文件失败");
	    }	

		sprintf(sCmd, "./sftp.sh %s", szFileName);

		int ret = -1;
		ret = system(sCmd);
		if(ret == -1)
		{
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "system(cmd) error!");
		}
		else
		{
			if(WIFEXITED(ret))
			{
				if(0 == WEXITSTATUS(ret))
				{
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "执行脚本成功!");
				}
				else
				{
					Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "执行脚本失败，错误码:%d.",WEXITSTATUS(ret));
				}
			}
			else
			{
				Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "exit,ret = %d.",WIFEXITED(ret));
			}
		}
		//add end by jienjun 2017/06/19 SRS-HUB-001
		
    }
    catch(CException &e)
    {
        m_Cmbkcdchgntfctnlist.closeCursor();
        PMTS_ThrowException(UNKNOWN_ERR);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsChangeDay::changBankinfo()");
}
/*********************************************/

/*********************************************/
void CBepsChangeDay::Insertccpc(const CCmccpcchng* ccpc)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsChangeDay::Insertccpc()");

    SETCTX(m_ccpc);
    m_ccpc.m_nodecode = ccpc->m_nodecode; 
    m_ccpc.m_ndname = ccpc->m_ndname; 
    m_ccpc.m_nodetype = ccpc->m_nodetype; 
    m_ccpc.m_citycd = ccpc->m_citycd; 
    m_ccpc.m_procstate = ccpc->m_procstate; 

    //删除原有记录
    int iRet = m_ccpc.remove();
	if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "删除表记录失败[%d][%s]",
		    iRet, m_ccpc.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_DEL_FAIL, "删除表记录失败");
	}

    //如果变更类型是新增/变更，则新增记录
    if ( "CC00" == ccpc->m_chngtp || "CC01" == ccpc->m_chngtp)
    {
        int iValue = m_ccpc.insert();
        if(RTN_SUCCESS != iValue)
        {
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "插入表失败[%d][%s]", iValue, m_ccpc.GetSqlErr());	
    		PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, "插入表失败");
        }
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsChangeDay::Insertccpc()");
}

void CBepsChangeDay::changccpcchng()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsChangeDay::changccpcchng()");

    try
    {
        string sSQLHead = "UPDATE cm_ccpcchng t SET t.PROCSTATE = '";
        ChangTableState(&m_ccpcchng, 4, sSQLHead);
    }
    catch(CException &e)
    {
        m_ccpcchng.closeCursor();
        PMTS_ThrowException(UNKNOWN_ERR);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsChangeDay::changccpcchng()");
}
/*********************************************/

/*********************************************/
void CBepsChangeDay::InsertCity(const CCmcitychng* citychng)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsChangeDay::InsertCity()");

    SETCTX(m_city);

    m_city.m_citycode = citychng->m_citycode; 
    m_city.m_cityname = citychng->m_cityname; 
    m_city.m_nodecode = citychng->m_nodecode; 
    m_city.m_citytp = citychng->m_citytp; 

    //删除原有记录
    int iRet = m_city.remove();
	if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "删除表记录失败[%d][%s]",
		    iRet, m_city.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_DEL_FAIL, "删除表记录失败");
	}

    //如果变更类型是新增/变更，则新增记录
    if ( "CC00" == citychng->m_chngtp || "CC01" == citychng->m_chngtp)
    {
        int iValue = m_city.insert();
        if(RTN_SUCCESS != iValue)
        {
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "插入表失败[%d][%s]", iValue, m_city.GetSqlErr());	
    		PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, "插入表失败");
        }
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsChangeDay::InsertCity()");
}

void CBepsChangeDay::changCitychng()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsChangeDay::changCitychng()");

    try
    {
        string sSQLHead = "UPDATE cm_citychng t SET t.PROCSTATE = '";
        ChangTableState(&m_citychng, 5, sSQLHead);
    }
    catch(CException &e)
    {
        m_citychng.closeCursor();
        PMTS_ThrowException(UNKNOWN_ERR);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsChangeDay::changCitychng()");
}
/*********************************************/

/*********************************************/
void CBepsChangeDay::InsertBktype(const CCmbktpchng* bktpchng)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsChangeDay::InsertBktype()");

    SETCTX(m_bktype);

    char szBuff[128]                 = {0};
    m_bktype.m_clscode = bktpchng->m_banktype; 
    m_bktype.m_clsname = bktpchng->m_banktypename; 
    m_bktype.m_catgno = itoa(szBuff, bktpchng->m_tpcd, 0); 
    m_bktype.m_catgname = bktpchng->m_tpnm ; 
    m_bktype.m_bankstatus = bktpchng->m_procstate; 

    //删除原有记录
    int iRet = m_bktype.remove();
	if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "删除表记录失败[%d][%s]",
		    iRet, m_bktype.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_DEL_FAIL, "删除表记录失败");
	}

    //如果变更类型是新增/变更，则新增记录
    if ( "CC00" == bktpchng->m_chngtp || "CC01" == bktpchng->m_chngtp)
    {
        int iValue = 0;
        iValue = m_bktype.insert();
        if(OPERACT_SUCCESS != iRet)
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "插入表失败, iValue=%d, %s", iValue,m_bktype.GetSqlErr());
            PMTS_ThrowException(DB_INSERT_FAIL);          
        }
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsChangeDay::InsertBktype()");
}

void CBepsChangeDay::changBktpchng()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsChangeDay::changBktpchng()");

    try
    {
        string sSQLHead = "UPDATE cm_bktpchng t SET t.PROCSTATE = '";
        ChangTableState(&m_bktpchng, 6, sSQLHead);
    }
    catch(CException &e)
    {
        m_bktpchng.closeCursor();
        PMTS_ThrowException(UNKNOWN_ERR);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsChangeDay::changBktpchng()");
}
/*********************************************/

void CBepsChangeDay::ChangTableState(CEntityBase* BaseListObj, int iTableFlag, string sSQLHead)
{
    if(0 != BaseListObj->setctx(m_dbproc))  
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "set connect failed!");
        PMTS_ThrowException(DB_CNNCT_FAIL); 
    }
    
    int     iRetCode = -1;
    string  sUpdateStr   = "";
    string  whereStr     = "";
    
    if(3 == iTableFlag)
    {
		    whereStr =" (FCTVDT <= '";
		    whereStr += m_sCurSysDt;

		    whereStr +="' OR IFCTVDT <= '";
		    whereStr += m_sCurSysDt;
		    		    
		    whereStr += "') AND PROCSTATE = '";
		    whereStr += PR_HVBP_34;
		    
		    whereStr += "' AND FctvTp = '";
		    whereStr += "EF01";
		    whereStr += "' ";    		
    }
    else
    {
		    whereStr =" FCTVDT <= '";
		    whereStr += m_sCurSysDt;
		    whereStr += "' AND PROCSTATE = '";
		    whereStr += PR_HVBP_34;
		    
		    whereStr += "' AND SysId = '";
		    whereStr += "BEPS";
		    whereStr += "' AND FctvTp = '";
		    whereStr += "EF01";
		    whereStr += "' ";    		
    }
    
	Trace(L_INFO, __FILE__, __LINE__, NULL, "whereStr = [%s]", whereStr.c_str());

	iRetCode = BaseListObj->find(whereStr);
	if (SQL_SUCCESS != iRetCode) 
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
		    "查询表失败[%d][%s]", iRetCode, BaseListObj->GetSqlErr());	
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, "查询表失败");
	}
	
    while ( SQL_SUCCESS == iRetCode ) 
	{
	    iRetCode = BaseListObj->fetch();
	    if( SQLNOTFOUND == iRetCode )
        {
            break;
        }
	    else if(SQL_SUCCESS != iRetCode)
	    {
	        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
		        "fetch表失败[%d][%s]", iRetCode, BaseListObj->GetSqlErr());
		    
    		BaseListObj->closeCursor();
    		PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, "fetch查询表失败");
	    }
    
        switch(iTableFlag)
        {
            case 1:
            {
                InsertMsgType(&m_cmlist);
                break;
            }
            case 2:
            {
                InsertSysparm(&m_Cmsyspamntfctnlist);
                break;
            }
            case 3:
            {
                Insertbankinfo(&m_Cmbkcdchgntfctnlist);
                break;
            }
            case 4:
            {
                Insertccpc(&m_ccpcchng);
                break;
            }
            case 5:
            {
                InsertCity(&m_citychng);
                break;
            }
            case 6:
            {
                InsertBktype(&m_bktpchng);
                break;
            }
            case 7:
            {
                InsertCIS(&m_cisagchgntfctnlist);
                break;
            }            
        }    
    }
    
	BaseListObj->closeCursor();

	sUpdateStr += sSQLHead;
	sUpdateStr += PR_HVBP_35;
	sUpdateStr += "' where ";
	sUpdateStr += whereStr;
	
	Trace(L_INFO, __FILE__, __LINE__, NULL, "sUpdateStr = [%s]", sUpdateStr.c_str());
	
	iRetCode = BaseListObj->execsql(sUpdateStr);
	if (iRetCode != SQLNOTFOUND && iRetCode != SQL_SUCCESS)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL,"更新失败[%d][%s]", 
		    iRetCode, BaseListObj->GetSqlErr());
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "更新失败");
	}
}

void CBepsChangeDay::resetSerialNo()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsChangeDay::resetSerialNo()");
	
	int iRet = -1;
	string strSQL = "";

	// 小额序列序号表
	strSQL = "update BP_SERIALNO set SNVALUE = MINVALUE where RESETFLG = '1' and SENDBANKCODE='";
	strSQL += m_sBankNo;
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL = [%s]", strSQL.c_str());
	
    SETCTX(m_Bpsapbankinfo);	
    iRet = m_Bpsapbankinfo.execsql(strSQL);
    if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新BP_SERIALNO表失败[%d][%s]",
            iRet, m_Bpsapbankinfo.GetSqlErr());

        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "更新BP_SERIALNO表失败");
    }

    #if 0
    // 系统序列序号表
    strSQL = "update SYS_SERIALNO set SNVALUE = MINVALUE where RESETFLG = '1' and SENDBANKCODE='";
    strSQL += m_sBankNo;
    strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL[%s]", strSQL.c_str());
    
    iRet = m_Bpsapbankinfo.execsql(strSQL);
    if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新SYS_SERIALNO表失败[%d][%s]",
            iRet, m_Bpsapbankinfo.GetSqlErr());

        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "更新SYS_SERIALNO表失败");
    }
    #endif

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsChangeDay::resetSerialNo()");
}

//__wsh 2012-10-26 数据迁移到历史表
void CBepsChangeDay::MoveTransToHistory(LPCSTR pBankNo, LPCSTR pOriSysDt)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL,
				"Enter CBepsChangeDay::MoveTransToHistory");
	CEntityBase entity;
	SETCTX(entity);

	MoveCrdtToHistory(entity, pBankNo, pOriSysDt);
	MoveDbetToHistory(entity, pBankNo, pOriSysDt);

	entity.commit();

	Trace(L_INFO, __FILE__, __LINE__, NULL,
				"Leave CBepsChangeDay::MoveTransToHistory");
}

//__wsh 2012-10-26 贷记往来账历史数据迁移
void CBepsChangeDay::MoveCrdtToHistory(CEntityBase& entity, LPCSTR pBankNo, LPCSTR pOriSysDt)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL,
			"Enter CBepsChangeDay::MoveCrdtToHistory");

	char szSql[1024] = {0};

	int iRet = 0;
    CEntityBase entitybase;
    char szErrMsg[1024] = {0};
        
    string strSql="";

    char szHvSaveDay[255 + 1] = {0};
    GetSysParam(m_dbproc, "11", szHvSaveDay);

	//贷记
	//往账历史数据迁移
	strSql = (string)" insert into bp_bcoutsndclhis"			
		"(WORKDATE,CONSIGDATE,MSGTP,MESGID,MESGREFID,MSGID,"
		"INSTGDRCTPTY,INSTDDRCTPTY,NPCMSGLEN,NPCFILENAME,CCY,SRCFLAG,CHECKSTATE,BUSISTATE,PROCESSCODE,RJCTINF,PROCSTATE,STATETIME,"
		"NETGDT,NETGRND,FINALSTATEDATE,RMK,NBOFTXS,CTRLSUM,SAPSNBOFTXS,CTRLSAPSSUM,SUCCNBOFTXS,CTRLSUCCSUM,REALTIMEFLAG,DGTSIGN,ISRBFLG,RMKALL,NPCMSG) "
        " select "
		"WORKDATE,CONSIGDATE,MSGTP,MESGID,MESGREFID,MSGID,"
		"INSTGDRCTPTY,INSTDDRCTPTY,NPCMSGLEN,NPCFILENAME,CCY,SRCFLAG,CHECKSTATE,BUSISTATE,PROCESSCODE,RJCTINF,PROCSTATE,STATETIME,"
		"NETGDT,NETGRND,FINALSTATEDATE,RMK,NBOFTXS,CTRLSUM,SAPSNBOFTXS,CTRLSAPSSUM,SUCCNBOFTXS,CTRLSUCCSUM,REALTIMEFLAG,DGTSIGN,ISRBFLG,RMKALL,NPCMSG "
        "from bp_bcoutsndcl t "
		" where to_date(t.CONSIGDATE, 'yyyymmdd') < (to_date('" + pOriSysDt +"', 'yyyymmdd')-to_number('"+ szHvSaveDay + "')) ";
		//pOriSysDt, szHvSaveDay);
	//DoExecute(entity, szSql, "贷记往报汇总历史数据迁移");
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql=[%s]", strSql.c_str());
		
		SETCTX(entitybase);
		iRet = entitybase.execsql(strSql);
		if (iRet == SQLNOTFOUND)
		{
			Trace(L_INFO, __FILE__, __LINE__, NULL,"NOT FOUND");
		}
		else if(iRet != SQL_SUCCESS)
		{
			sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
				iRet, entitybase.GetSqlErr());
				
			Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
		}

		strSql = (string)" delete from bp_bcoutsndcl t "
				" where to_date(t.CONSIGDATE, 'yyyymmdd') < (to_date('" + pOriSysDt +"', 'yyyymmdd')-to_number('"+ szHvSaveDay + "')) ";

		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql=[%s]", strSql.c_str());
		
		SETCTX(entitybase);
		iRet = entitybase.execsql(strSql);
		if (iRet == SQLNOTFOUND)
		{
			Trace(L_INFO, __FILE__, __LINE__, NULL,"NOT FOUND");
		}
		else if(iRet != SQL_SUCCESS)
		{
			sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
				iRet, entitybase.GetSqlErr());
				
			Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
		}

		strSql =  (string)" insert into bp_bcoutsendlisthis"
			"(WORKDATE,CONSIGDATE,MSGTP,MSGID,INSTGDRCTPTY,INSTDDRCTPTY,TXID,ENDTOENDID,DBTNM,DBTRACCTID,"
			"DBTRISSR,DBTRBRNCHID,CDTRNM,CDTRACCTID,CDTRISSR,CDTRBRNCHID,CURRENCY,AMOUNT,PMTTPPRTRY,PURPPRTRY,ADDTLINF,CSTMRCDTTRFADDTLINF,"
			"ORGNLMSGID,ORGNLMSGTP,ORIINSTGPTY,ORIINSTGDRCTPTY,ORITXID,ORIPKGNUM,ORIAMOUNT,NPCMSGLEN,NPCMSG,MBMSG,SRCFLAG,CHECKSTATE,"
			"BUSISTATE,PROCESSCODE,RJCTINF,PROCSTATE,STATETIME,FINALSTATEDATE,ACCTSTATE,ACSTATETIME,ACCTREGNUM,REACREGNUM,NETGDT,NETGRND,"
			"ISTSTATETIME,INPUTTIME,CHECKTIME,GRANTTIME,INPUTOPER,CHECKOPER,GRANTOPER,PRINTNO,ISRBFLG,DBTADDR,CDTADDR,MBMSGID,MBINSTPTY,MBPROCSTATE,"
			"MBAMOUNT,MBCHECKSTATE,REMARK,CLRSYSREF,DBTRISSRNM,CDTRISSRNM,REISSUEFLAG,RESERVE,TRANSFLAG,TRANSTIMES,OUTSENDBANK,"
			"OUTTXSSNO,OUTCONSIGNDATE,INSENDBANK,INTTXSSNO,INCONSIGNDATE,DBTNMALL,DBTADDRALL,CDTRNMALL,CDTADDRALL,ADDINFOALL,ADDTLINF2,"
			"REMARK2,BATCHNO,STATUSIDENTIFICATION,NBOFTXS,CTRLSUM,SAPSNBOFTXS,CTRLSAPSSUM,BCMTNO,REPLYRJCTINF,REPLYPROCESSCODE,REPLYSTATE) "
			" select "
			"WORKDATE,CONSIGDATE,MSGTP,MSGID,INSTGDRCTPTY,INSTDDRCTPTY,TXID,ENDTOENDID,DBTNM,DBTRACCTID,"
			"DBTRISSR,DBTRBRNCHID,CDTRNM,CDTRACCTID,CDTRISSR,CDTRBRNCHID,CURRENCY,AMOUNT,PMTTPPRTRY,PURPPRTRY,ADDTLINF,CSTMRCDTTRFADDTLINF,"
			"ORGNLMSGID,ORGNLMSGTP,ORIINSTGPTY,ORIINSTGDRCTPTY,ORITXID,ORIPKGNUM,ORIAMOUNT,NPCMSGLEN,NPCMSG,MBMSG,SRCFLAG,CHECKSTATE,"
			"BUSISTATE,PROCESSCODE,RJCTINF,PROCSTATE,STATETIME,FINALSTATEDATE,ACCTSTATE,ACSTATETIME,ACCTREGNUM,REACREGNUM,NETGDT,NETGRND,"
			"ISTSTATETIME,INPUTTIME,CHECKTIME,GRANTTIME,INPUTOPER,CHECKOPER,GRANTOPER,PRINTNO,ISRBFLG,DBTADDR,CDTADDR,MBMSGID,MBINSTPTY,MBPROCSTATE,"
			"MBAMOUNT,MBCHECKSTATE,REMARK,CLRSYSREF,DBTRISSRNM,CDTRISSRNM,REISSUEFLAG,RESERVE,TRANSFLAG,TRANSTIMES,OUTSENDBANK,"
			"OUTTXSSNO,OUTCONSIGNDATE,INSENDBANK,INTTXSSNO,INCONSIGNDATE,DBTNMALL,DBTADDRALL,CDTRNMALL,CDTADDRALL,ADDINFOALL,ADDTLINF2,"
			"REMARK2,BATCHNO,STATUSIDENTIFICATION,NBOFTXS,CTRLSUM,SAPSNBOFTXS,CTRLSAPSSUM,BCMTNO,REPLYRJCTINF,REPLYPROCESSCODE,REPLYSTATE"			
			" from bp_bcoutsendlist tt "
			" where to_date(tt.CONSIGDATE, 'yyyymmdd') < (to_date('" + pOriSysDt +"', 'yyyymmdd')-to_number('"+ szHvSaveDay + "')) ";

		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql=[%s]", strSql.c_str());
		
		SETCTX(entitybase);
		iRet = entitybase.execsql(strSql);
		if (iRet == SQLNOTFOUND)
		{
			Trace(L_INFO, __FILE__, __LINE__, NULL,"NOT FOUND");
		}
		else if(iRet != SQL_SUCCESS)
		{
			sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
				iRet, entitybase.GetSqlErr());
				
			Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
		}

		strSql =  (string)" delete from bp_bcoutsendlist t"
			" where to_date(t.CONSIGDATE, 'yyyymmdd') < (to_date('" + pOriSysDt +"', 'yyyymmdd')-to_number('"+ szHvSaveDay + "')) ";

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql=[%s]", strSql.c_str());
	
	SETCTX(entitybase);
	iRet = entitybase.execsql(strSql);
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"NOT FOUND");
	}
	else if(iRet != SQL_SUCCESS)
	{
		sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
			iRet, entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
	}

	//来账历史数据迁移
		strSql =  (string)" insert into bp_bcoutrcvclhis"
			"(WORKDATE,CONSIGDATE,MSGTP,MSGID,"
			"INSTGDRCTPTY,INSTDDRCTPTY,CCY,RMK,SRCFLAG,CHECKSTATE,BUSISTATE,PROCESSCODE,RJCTINF,PROCSTATE,STATETIME,"
			"NETGDT,NETGRND,FINALSTATEDATE,NBOFTXS,CTRLSUM,SAPSNBOFTXS,CTRLSAPSSUM,SUCCNBOFTXS,CTRLSUCCSUM,REALTIMEFLAG,DGTSIGN,ISRBFLG,RECVDEST) "
		" select "
			"WORKDATE,CONSIGDATE,MSGTP,MSGID,"
			"INSTGDRCTPTY,INSTDDRCTPTY,CCY,RMK,SRCFLAG,CHECKSTATE,BUSISTATE,PROCESSCODE,RJCTINF,PROCSTATE,STATETIME,"
			"NETGDT,NETGRND,FINALSTATEDATE,NBOFTXS,CTRLSUM,SAPSNBOFTXS,CTRLSAPSSUM,SUCCNBOFTXS,CTRLSUCCSUM,REALTIMEFLAG,DGTSIGN,ISRBFLG,RECVDEST "
	   " from bp_bcoutrcvcl tt "
		" where to_date(tt.CONSIGDATE, 'yyyymmdd') < (to_date('" + pOriSysDt +"', 'yyyymmdd')-to_number('"+ szHvSaveDay + "')) ";

		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql=[%s]", strSql.c_str());
		
		SETCTX(entitybase);
		iRet = entitybase.execsql(strSql);
		if (iRet == SQLNOTFOUND)
		{
			Trace(L_INFO, __FILE__, __LINE__, NULL,"NOT FOUND");
		}
		else if(iRet != SQL_SUCCESS)
		{
			sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
				iRet, entitybase.GetSqlErr());
				
			Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
		}

		strSql =  (string)" delete from bp_bcoutrcvcl tt"
			" where to_date(tt.CONSIGDATE, 'yyyymmdd') < (to_date('" + pOriSysDt +"', 'yyyymmdd')-to_number('"+ szHvSaveDay + "')) ";
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql=[%s]", strSql.c_str());
		
		SETCTX(entitybase);
		iRet = entitybase.execsql(strSql);
		if (iRet == SQLNOTFOUND)
		{
			Trace(L_INFO, __FILE__, __LINE__, NULL,"NOT FOUND");
		}
		else if(iRet != SQL_SUCCESS)
		{
			sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
				iRet, entitybase.GetSqlErr());
				
			Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
		}


	strSql =  (string)" insert into bp_bcoutrecvlisthis"
		"(WORKDATE,"
		"CONSIGDATE,MSGTP,MSGID,INSTGDRCTPTY,INSTDDRCTPTY,TXID,ENDTOENDID,DBTNM,DBTRACCTID,DBTRISSR,DBTRBRNCHID,"
		"CDTRNM,CDTRACCTID,CDTRISSR,CDTRBRNCHID,CURRENCY,AMOUNT,PMTTPPRTRY,PURPPRTRY,ADDTLINF,CSTMRCDTTRFADDTLINF,"
		"ORGNLMSGID,ORGNLMSGTP,ORIINSTGPTY,ORIINSTGDRCTPTY,ORITXID,ORIAMOUNT,NPCMSG,MBMSG,SRCFLAG,CHECKSTATE,"
		"BUSISTATE,PROCESSCODE,RJCTINF,PROCSTATE,STATETIME,NETGDT,NETGRND,FINALSTATEDATE,RECVDEST,ISRBFLG,DBTADDR,"
		"CDTADDR,ACCTSTATE,ACSTATETIME,ACCTREGNUM,REACREGNUM,REMARK,CLRSYSREF,DBTRISSRNM,CDTRISSRNM,MBPROCSTATE,"
		"MBAMOUNT,MBCHECKSTATE,MBMSGID,RESERVE,MBRECVBK,ADDTLINF2,REMARK2,ORIINSTDPTY,ORIINSTDDRCTPTY,ORIPMTTPPRTRY,"
		"STATUSIDENTIFICATION,NBOFTXS,CTRLSUM,SAPSNBOFTXS,CTRLSAPSSUM,REPLYRJCTINF,REPLYPROCESSCODE,REPLYSTATE,PRINTNO)"
	" select "
		" WORKDATE,"
		"CONSIGDATE,MSGTP,MSGID,INSTGDRCTPTY,INSTDDRCTPTY,TXID,ENDTOENDID,DBTNM,DBTRACCTID,DBTRISSR,DBTRBRNCHID,"
		"CDTRNM,CDTRACCTID,CDTRISSR,CDTRBRNCHID,CURRENCY,AMOUNT,PMTTPPRTRY,PURPPRTRY,ADDTLINF,CSTMRCDTTRFADDTLINF,"
		"ORGNLMSGID,ORGNLMSGTP,ORIINSTGPTY,ORIINSTGDRCTPTY,ORITXID,ORIAMOUNT,NPCMSG,MBMSG,SRCFLAG,CHECKSTATE,"
		"BUSISTATE,PROCESSCODE,RJCTINF,PROCSTATE,STATETIME,NETGDT,NETGRND,FINALSTATEDATE,RECVDEST,ISRBFLG,DBTADDR,"
		"CDTADDR,ACCTSTATE,ACSTATETIME,ACCTREGNUM,REACREGNUM,REMARK,CLRSYSREF,DBTRISSRNM,CDTRISSRNM,MBPROCSTATE,"
		"MBAMOUNT,MBCHECKSTATE,MBMSGID,RESERVE,MBRECVBK,ADDTLINF2,REMARK2,ORIINSTDPTY,ORIINSTDDRCTPTY,ORIPMTTPPRTRY,"
		"STATUSIDENTIFICATION,NBOFTXS,CTRLSUM,SAPSNBOFTXS,CTRLSAPSSUM,REPLYRJCTINF,REPLYPROCESSCODE,REPLYSTATE,PRINTNO "
	" from bp_bcoutrecvlist tt "
		" where to_date(tt.CONSIGDATE, 'yyyymmdd') < (to_date('" + pOriSysDt +"', 'yyyymmdd')-to_number('"+ szHvSaveDay + "')) ";
		
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql=[%s]", strSql.c_str());
		
		SETCTX(entitybase);
		iRet = entitybase.execsql(strSql);
		if (iRet == SQLNOTFOUND)
		{
			Trace(L_INFO, __FILE__, __LINE__, NULL,"NOT FOUND");
		}
		else if(iRet != SQL_SUCCESS)
		{
			sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
				iRet, entitybase.GetSqlErr());
				
			Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
		}

		strSql =  (string)" delete from bp_bcoutrecvlist tt"
			" where to_date(tt.CONSIGDATE, 'yyyymmdd') < (to_date('" + pOriSysDt +"', 'yyyymmdd')-to_number('"+ szHvSaveDay + "')) ";

		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql=[%s]", strSql.c_str());
		
		SETCTX(entitybase);
		iRet = entitybase.execsql(strSql);
		if (iRet == SQLNOTFOUND)
		{
			Trace(L_INFO, __FILE__, __LINE__, NULL,"NOT FOUND");
		}
		else if(iRet != SQL_SUCCESS)
		{
			sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
				iRet, entitybase.GetSqlErr());
				
			Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
		}

		Trace(L_INFO, __FILE__, __LINE__, NULL,
				"Leave CBepsChangeDay::MoveCrdtToHistory");
}

//__wsh 2012-10-26 借记往来账历史数据迁移
void CBepsChangeDay::MoveDbetToHistory(CEntityBase& entity, LPCSTR pBankNo, LPCSTR pOriSysDt)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL,
			"Enter CBepsChangeDay::MoveCrdtToHistory");

	char szSql[4000] = {0};
    CEntityBase entitybase;
    char szErrMsg[1024] = {0};
        
    string strSql="";

	int iRet = 0;
    char szHvSaveDay[255 + 1] = {0};
    GetSysParam(m_dbproc, "11", szHvSaveDay);

	//往账历史数据迁移
	strSql = (string)" insert into bp_bdsndclhis"
			"(WORKDATE,CONSIGDATE,MSGTP,MESGID,MESGREFID,MSGID,INSTGDRCTPTY,INSTDDRCTPTY,NPCMSGLEN,"
			"NPCFILENAME,BUSISTATE,PROCESSCODE,RJCTINF,PROCSTATE,NETGDT,NETGRND,STATETIME,FINALSTATEDATE,SRCFLAG,RMK,CCY,"
			"NBOFTXS,SAPSNBOFTXS,CTRLSAPSSUM,CTRLSUM,DGTSIGN,PKGRTRLTD,REALTIMEFLAG,ISRBFLG,CHECKSTATE,RMKALL,NPCMSG)"
	   " select "
			"WORKDATE,CONSIGDATE,MSGTP,MESGID,MESGREFID,MSGID,INSTGDRCTPTY,INSTDDRCTPTY,NPCMSGLEN,"
			"NPCFILENAME,BUSISTATE,PROCESSCODE,RJCTINF,PROCSTATE,NETGDT,NETGRND,STATETIME,FINALSTATEDATE,SRCFLAG,RMK,CCY,"
			"NBOFTXS,SAPSNBOFTXS,CTRLSAPSSUM,CTRLSUM,DGTSIGN,PKGRTRLTD,REALTIMEFLAG,ISRBFLG,CHECKSTATE,RMKALL,NPCMSG "
	" from bp_bdsndcl tt "
		" where to_date(tt.CONSIGDATE, 'yyyymmdd') < (to_date('" + pOriSysDt +"', 'yyyymmdd')-to_number('"+ szHvSaveDay + "')) ";

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql=[%s]", strSql.c_str());
	
	SETCTX(entitybase);
	iRet = entitybase.execsql(strSql);
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"NOT FOUND");
	}
	else if(iRet != SQL_SUCCESS)
	{
		sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
			iRet, entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
	}

	strSql = (string)" delete from bp_bdsndcl tt"
		" where to_date(tt.CONSIGDATE, 'yyyymmdd') < (to_date('" + pOriSysDt +"', 'yyyymmdd')-to_number('"+ szHvSaveDay + "')) ";

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql=[%s]", strSql.c_str());
	
	SETCTX(entitybase);
	iRet = entitybase.execsql(strSql);
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"NOT FOUND");
	}
	else if(iRet != SQL_SUCCESS)
	{
		sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
			iRet, entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
	}

	strSql = (string)" insert into bp_bdsendlisthis"
		"(WORKDATE,CONSIGDATE,MSGTP,MSGID,INSTGDRCTPTY,INSTDDRCTPTY,TXID,CLRSYSREF,AGRMTNB,DBTNM,DBTRACCTID,DBTRISSR,DBTRLSSRNM,"
		"DBTRBRNCHID,CDTRNM,CDTRACCTID,CDTRISSR,CDTRLSSRNM,CDTRBRNCHID,CURRENCY,AMOUNT,PMTTPPRTRY,PURPPRTRY,BUSISTATE,PROCESSCODE,RJCTINF,PROCSTATE,"
		"STATETIME,FINALSTATEDATE,ACCTSTATE,ACSTATETIME,ACCTREGNUM,REACREGNUM,CSTMRCDTTRFADDTLINF,NPCMSGLEN,NPCMSG,MBMSG,RMK,ADDTLINF,"
		"ISTSTATETIME,INPUTTIME,CHECKTIME,GRANTTIME,INPUTOPER,CHECKOPER,GRANTOPER,PRINTNO,ISRBFLG,DBTADDR,CDTADDR,NETGDT,NETGRND,MBMSGID,"
		"MBINSTPTY,PKGRTRLTD,CHECKSTATE,ORGNLMSGID,ORGNLMSGTP,ORIINSTGPTY,ORIINSTGDRCTPTY,ORITXID,ORIPKGNUM,ORIAMOUNT,REMARK,"
		"ADDINFO2,DBTNMALL,DBTADDRALL,CDTRNMALL,CDTADDRALL,ADDINFOALL,BIZSOURCE,BCMTNO,REPLYSTATE,REPLYPROCESSCODE,REPLYRJCTINF) "
	" select "
		" WORKDATE,CONSIGDATE,MSGTP,MSGID,INSTGDRCTPTY,INSTDDRCTPTY,TXID,CLRSYSREF,AGRMTNB,DBTNM,DBTRACCTID,DBTRISSR,DBTRLSSRNM,"
		"DBTRBRNCHID,CDTRNM,CDTRACCTID,CDTRISSR,CDTRLSSRNM,CDTRBRNCHID,CURRENCY,AMOUNT,PMTTPPRTRY,PURPPRTRY,BUSISTATE,PROCESSCODE,RJCTINF,PROCSTATE,"
		"STATETIME,FINALSTATEDATE,ACCTSTATE,ACSTATETIME,ACCTREGNUM,REACREGNUM,CSTMRCDTTRFADDTLINF,NPCMSGLEN,NPCMSG,MBMSG,RMK,ADDTLINF,"
		"ISTSTATETIME,INPUTTIME,CHECKTIME,GRANTTIME,INPUTOPER,CHECKOPER,GRANTOPER,PRINTNO,ISRBFLG,DBTADDR,CDTADDR,NETGDT,NETGRND,MBMSGID,"
		"MBINSTPTY,PKGRTRLTD,CHECKSTATE,ORGNLMSGID,ORGNLMSGTP,ORIINSTGPTY,ORIINSTGDRCTPTY,ORITXID,ORIPKGNUM,ORIAMOUNT,REMARK,"
		"ADDINFO2,DBTNMALL,DBTADDRALL,CDTRNMALL,CDTADDRALL,ADDINFOALL,BIZSOURCE,BCMTNO,REPLYSTATE,REPLYPROCESSCODE,REPLYRJCTINF "
	" from bp_bdsendlist tt "
		" where to_date(tt.CONSIGDATE, 'yyyymmdd') < (to_date('" + pOriSysDt +"', 'yyyymmdd')-to_number('"+ szHvSaveDay + "')) ";

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql=[%s]", strSql.c_str());
	
	SETCTX(entitybase);
	iRet = entitybase.execsql(strSql);
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"NOT FOUND");
	}
	else if(iRet != SQL_SUCCESS)
	{
		sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
			iRet, entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
	}

	strSql = (string)" delete from bp_bdsendlist tt"
		" where to_date(tt.CONSIGDATE, 'yyyymmdd') < (to_date('" + pOriSysDt +"', 'yyyymmdd')-to_number('"+ szHvSaveDay + "')) ";
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql=[%s]", strSql.c_str());
	
	SETCTX(entitybase);
	iRet = entitybase.execsql(strSql);
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"NOT FOUND");
	}
	else if(iRet != SQL_SUCCESS)
	{
		sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
			iRet, entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
	}

	strSql = (string)" insert into bp_bdrcvclhis"
			"(WORKDATE,CONSIGDATE,"
			"MSGTP,MESGID,MESGREFID,MSGID,INSTGDRCTPTY,INSTDDRCTPTY,NPCMSGLEN,NPCFILENAME,BUSISTATE,"
			"PROCESSCODE,RJCTINF,PROCSTATE,STATETIME,FINALSTATEDATE,RMK,NBOFTXS,SAPSNBOFTXS,CTRLSAPSSUM,"
			"CTRLSUM,DGTSIGN,PKGRTRLTD,REALTIMEFLAG,ISRBFLG,SRCFLAG,CCY,RECVDEST,NETGDT,NETGRND,CHECKSTATE)"
		" select "
			"WORKDATE,CONSIGDATE,"
			"MSGTP,MESGID,MESGREFID,MSGID,INSTGDRCTPTY,INSTDDRCTPTY,NPCMSGLEN,NPCFILENAME,BUSISTATE,"
			"PROCESSCODE,RJCTINF,PROCSTATE,STATETIME,FINALSTATEDATE,RMK,NBOFTXS,SAPSNBOFTXS,CTRLSAPSSUM,"
			"CTRLSUM,DGTSIGN,PKGRTRLTD,REALTIMEFLAG,ISRBFLG,SRCFLAG,CCY,RECVDEST,NETGDT,NETGRND,CHECKSTATE "
	" from bp_bdrcvcl tt "
		" where to_date(tt.CONSIGDATE, 'yyyymmdd') < (to_date('" + pOriSysDt +"', 'yyyymmdd')-to_number('"+ szHvSaveDay + "')) ";

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql=[%s]", strSql.c_str());
	
	SETCTX(entitybase);
	iRet = entitybase.execsql(strSql);
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"NOT FOUND");
	}
	else if(iRet != SQL_SUCCESS)
	{
		sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
			iRet, entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
	}

	strSql = (string)" delete from bp_bdrcvcl tt"
		" where to_date(tt.CONSIGDATE, 'yyyymmdd') < (to_date('" + pOriSysDt +"', 'yyyymmdd')-to_number('"+ szHvSaveDay + "')) ";

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql=[%s]", strSql.c_str());
	
	SETCTX(entitybase);
	iRet = entitybase.execsql(strSql);
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"NOT FOUND");
	}
	else if(iRet != SQL_SUCCESS)
	{
		sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
			iRet, entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
	}

	strSql = (string)" insert into bp_bdrecvlisthis"
			"(WORKDATE,CONSIGDATE,MSGTP,MSGID,INSTGDRCTPTY,INSTDDRCTPTY,TXID,CLRSYSREF,AGRMTNB,"
			"DBTNM,DBTRACCTID,DBTRISSR,DBTRLSSRNM,DBTRBRNCHID,CDTRNM,CDTRACCTID,CDTRISSR,CDTRLSSRNM,CDTRBRNCHID,CURRENCY,AMOUNT,"
			"PMTTPPRTRY,PURPPRTRY,CSTMRCDTTRFADDTLINF,NPCMSGLEN,NPCMSG,MBMSG,BUSISTATE,PROCESSCODE,RJCTINF,PROCSTATE,STATETIME,"
			"FINALSTATEDATE,RMK,ADDTLINF,ISTSTATETIME,ISRBFLG,RECVDEST,DBTADDR,CDTADDR,ACCTSTATE,ACSTATETIME,ACCTREGNUM,"
			"REACREGNUM,NETGDT,NETGRND,CHECKSTATE,ORGNLMSGID,ORGNLMSGTP,ORIINSTGPTY,ORIINSTGDRCTPTY,ORITXID,ORIPKGNUM,"
			"ORIAMOUNT,REMARK,ADDINFO2,MBRECVBK,REPLYRJCTINF,REPLYPROCESSCODE,REPLYSTATE,PKGRTRLTD,MBMSGID,PRINTNO)"
	     " select "
			" WORKDATE,CONSIGDATE,MSGTP,MSGID,INSTGDRCTPTY,INSTDDRCTPTY,TXID,CLRSYSREF,AGRMTNB,"
			"DBTNM,DBTRACCTID,DBTRISSR,DBTRLSSRNM,DBTRBRNCHID,CDTRNM,CDTRACCTID,CDTRISSR,CDTRLSSRNM,CDTRBRNCHID,CURRENCY,AMOUNT,"
			"PMTTPPRTRY,PURPPRTRY,CSTMRCDTTRFADDTLINF,NPCMSGLEN,NPCMSG,MBMSG,BUSISTATE,PROCESSCODE,RJCTINF,PROCSTATE,STATETIME,"
			"FINALSTATEDATE,RMK,ADDTLINF,ISTSTATETIME,ISRBFLG,RECVDEST,DBTADDR,CDTADDR,ACCTSTATE,ACSTATETIME,ACCTREGNUM,"
			"REACREGNUM,NETGDT,NETGRND,CHECKSTATE,ORGNLMSGID,ORGNLMSGTP,ORIINSTGPTY,ORIINSTGDRCTPTY,ORITXID,ORIPKGNUM,"
			"ORIAMOUNT,REMARK,ADDINFO2,MBRECVBK,REPLYRJCTINF,REPLYPROCESSCODE,REPLYSTATE,PKGRTRLTD,MBMSGID,PRINTNO "
	" from bp_bdrecvlist tt "
		" where to_date(tt.CONSIGDATE, 'yyyymmdd') < (to_date('" + pOriSysDt +"', 'yyyymmdd')-to_number('"+ szHvSaveDay + "')) ";

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql=[%s]", strSql.c_str());
	
	SETCTX(entitybase);
	iRet = entitybase.execsql(strSql);
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"NOT FOUND");
	}
	else if(iRet != SQL_SUCCESS)
	{
		sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
			iRet, entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
	}

	strSql = (string)" delete from bp_bdrecvlist tt"
		" where to_date(tt.CONSIGDATE, 'yyyymmdd') < (to_date('" + pOriSysDt +"', 'yyyymmdd')-to_number('"+ szHvSaveDay + "')) ";
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql=[%s]", strSql.c_str());
	
	SETCTX(entitybase);
	iRet = entitybase.execsql(strSql);
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"NOT FOUND");
	}
	else if(iRet != SQL_SUCCESS)
	{
		sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
			iRet, entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
	}

	Trace(L_INFO, __FILE__, __LINE__, NULL,
			"Leave CBepsChangeDay::MoveCrdtToHistory");
}

//__wsh 2012-10-26
int CBepsChangeDay::DoExecute(CEntityBase& entity, LPCSTR szSql, LPCSTR szTitle)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL,
				"Enter CBepsChangeDay::DoExecute");
	int iRet = -1;

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__szSql=[%s]", szSql);
	iRet = entity.execsql(szSql);
	if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND){
		Trace(L_ERROR, __FILE__, __LINE__,
				NULL, "%s失败:%s", szTitle, entity.GetSqlErr());
		PMTS_ThrowException(DB_OPT_FAIL);
	}
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "%s操作结果返回码:[%d]", szTitle, iRet);

	Trace(L_INFO, __FILE__, __LINE__, NULL,
				"Leave CBepsChangeDay::DoExecute");
	return iRet;
}

//__wsh 2012-10-27 清除历史表数据
void CBepsChangeDay::DeleteHistoryTrans(LPCSTR pBankNo, LPCSTR pOriSysDt)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL,
					"Enter CBepsChangeDay::DoExecute");

	CEntityBase entity;
	SETCTX(entity);
	
	int iHisDay = 0;
	
	CSyssysparm param;
	SETCTX(param);
	string strSql = " code='13' ";
	int iRet = param.find(strSql);
	if(iRet != SQL_SUCCESS || param.fetch() != SQL_SUCCESS){
	    Trace(L_ERROR, __FILE__, __LINE__, NULL, 
	        "[sys_sysparm]查询出错:%s", param.GetSqlErr());
	    PMTS_ThrowException(DB_FIND_FAIL);
	}
	
	iHisDay = atoi(param.m_parmvalue.c_str());

	char szSql[512] = {0};
//__MACRO START__删除历史宏，
#define DELETE_HISTORY(TABLE, _DTFIELD, FIELD, TITLE) snprintf(szSql, sizeof(szSql), "delete from %s where "\
	"to_date(%s, 'yyyymmdd') <= (to_date('%s', 'yyyymmdd') - to_number('%d'))"\
	"and %s = '%s'", TABLE, _DTFIELD, pOriSysDt, iHisDay, FIELD, pBankNo);\
	DoExecute(entity, szSql, TITLE)
//__MACRO END__

	DELETE_HISTORY("BP_BCOUTSNDCLHIS",    "CONSIGDATE", "INSTGDRCTPTY", "删除贷记往报汇总历史表");

	DELETE_HISTORY("BP_BCOUTSENDLISTHIS", "CONSIGDATE", "INSTGDRCTPTY", "删除贷记往报明细历史表");

	DELETE_HISTORY("BP_BCOUTRCVCLHIS",    "CONSIGDATE", "INSTDDRCTPTY", "删除贷记来报汇总历史表");

	DELETE_HISTORY("BP_BCOUTRECVLISTHIS", "CONSIGDATE", "INSTDDRCTPTY", "删除贷记来报明细历史表");

	DELETE_HISTORY("BP_BDSNDCLHIS",       "CONSIGDATE", "INSTGDRCTPTY", "删除借记往报汇总历史表");

	DELETE_HISTORY("BP_BDSENDLISTHIS",    "CONSIGDATE", "INSTGDRCTPTY", "删除借记往报明细历史表");

	DELETE_HISTORY("BP_BDRCVCLHIS",       "CONSIGDATE", "INSTDDRCTPTY", "删除借记来报汇总历史表");

	DELETE_HISTORY("BP_BDRECVLISTHIS",    "CONSIGDATE", "INSTDDRCTPTY", "删除借记来报明细历史表");

	DELETE_HISTORY("BP_CHECKCL", "WORKDATE",  "INSTDDRCTPTY", "删除对账汇总历史数据");

	DELETE_HISTORY("BP_CHKLSTCL", "WORKDATE", "INSTDDRCTPTY", "删除对账汇总明细辅助表历史数据");

	DELETE_HISTORY("BP_CHKLSTLIST", "WORKDATE", "INSTDDRCTPTY", "删除对账汇总明细表历史数据");

	DELETE_HISTORY("BP_PKGASSIST", "WRKDATE", "SENDBANK", "删除二代打包辅助表历史数据");

	DELETE_HISTORY("BP_PKGASSIST1", "WRKDATE", "SENDBANK", "删除二代打包辅助表历史数据");


	Trace(L_INFO, __FILE__, __LINE__, NULL,
					"Leave CBepsChangeDay::DoExecute");
}



