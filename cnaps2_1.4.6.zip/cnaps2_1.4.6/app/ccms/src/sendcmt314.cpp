/********************************************************************
�ļ�����sendcmt314.cpp
�����ˣ�xiaocuiming
��  �ڣ�2011.07.04
��  �����������ҵ���˻�Ӧ����
��  ����
Copyright (c) 2011  YLINK
********************************************************************/


#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt314.h"

using namespace ZFPT;


CSendCmt314::CSendCmt314(const stuMsgHead & Smsg):CSendCcmsBase(Smsg)
{

}


CSendCmt314::~ CSendCmt314()
{

}



int CSendCmt314::doWorkSelf()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt314::doWorkSelf...");

    GetData();

    SetData();

    buildCmtMsg();
    
    UpdateState();

    AddQueue(m_cCmt314.m_strCmtmsg, m_cCmt314.m_strCmtmsg.length());
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt314::doWorkSelf...");

    return SUCCESSED;
}


void CSendCmt314::SetDBKey()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt314::SetDBKey...");

    m_cmpmtrtrcl.m_sysid = m_szSysFlagNO;
    m_cmpmtrtrcl.m_msgid = m_szMsgFlagNO;
    m_cmpmtrtrcl.m_instgindrctpty = m_szSndNO;
    m_cmpmtrtrcl.m_rsflag = "1";

    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "m_szSysFlagNO = [%s]", m_szSysFlagNO);//ϵͳ��ʶ��
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "m_szMsgFlagNO = [%s]", m_szMsgFlagNO);//���ı�ʶ��
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "m_szSndNO = [%s]", m_szSndNO);//����������

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt314::SetDBKey...");
}


int CSendCmt314::GetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt314::GetData...");

    SETCTX(m_cmpmtrtrcl);

    SetDBKey();
    
    int iRet = m_cmpmtrtrcl.findByPK();

    if(RTN_SUCCESS != iRet)
    {
        sprintf(m_sErrMsg, "findByPK() erro, erro code[%d], erro cause[%s]", iRet, m_cmpmtrtrcl.GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt314::GetData...");

    return iRet;
}



void CSendCmt314::SetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt314::SetData...");

    snprintf(m_cCmt314.sSendbank, sizeof(m_cCmt314.sSendbank), m_cmpmtrtrcl.m_instgindrctpty.c_str());
    snprintf(m_cCmt314.sSendsapbk, sizeof(m_cCmt314.sSendsapbk), m_cmpmtrtrcl.m_instgdrctpty.c_str());
    snprintf(m_cCmt314.sConsigndate, sizeof(m_cCmt314.sConsigndate), m_cmpmtrtrcl.m_consigndate.c_str());
    string strTemp;
    strTemp = m_cmpmtrtrcl.m_orgnlmsgid.substr(0, 8);
    snprintf(m_cCmt314.sOldconsigndate, sizeof(m_cCmt314.sOldconsigndate), strTemp.c_str());//ԭί������
    
    strTemp = m_cmpmtrtrcl.m_orgnlmsgid.substr(8, 8);
    m_cCmt314.iOldmssno = atoi(strTemp.c_str());//ԭ�˻������
    
    snprintf(m_cCmt314.sRecvsapbk, sizeof(m_cCmt314.sRecvsapbk), m_cmpmtrtrcl.m_instddrctpty.c_str());
    snprintf(m_cCmt314.sRecvbank, sizeof(m_cCmt314.sRecvbank), m_cmpmtrtrcl.m_instdindrctpty.c_str());
    char SndCCPCNode[4 + 1] 	= {0};	
	char RcvCCPCNode[4 + 1] 	= {0};
    GetSapBkToCCPC(m_dbproc, m_cmpmtrtrcl.m_instgdrctpty, SndCCPCNode);
	GetSapBkToCCPC(m_dbproc, m_cmpmtrtrcl.m_instddrctpty, RcvCCPCNode);
	snprintf(m_cCmt314.sSendcenter, sizeof(m_cCmt314.sSendcenter), SndCCPCNode);
	snprintf(m_cCmt314.sRecvcenter, sizeof(m_cCmt314.sRecvcenter), RcvCCPCNode);

    
    
    snprintf(m_cCmt314.sRemark, sizeof(m_cCmt314.sRemark), m_cmpmtrtrcl.m_rtinfo.c_str());
    
    snprintf(m_cCmt314.sRespflag, sizeof(m_cCmt314.sRespflag), m_cmpmtrtrcl.m_rsflag.c_str());
    
    snprintf(m_cCmt314.sReturnstat, sizeof(m_cCmt314.sReturnstat), m_cmpmtrtrcl.m_retunstat.c_str());
    
    
    //����ԭҵ��
    m_Oricmpmtrtrcl.m_sysid = "HVPS";
    m_Oricmpmtrtrcl.m_msgid = m_cmpmtrtrcl.m_orgnlmsgid;
    m_Oricmpmtrtrcl.m_instgindrctpty = m_cmpmtrtrcl.m_orgninstgdrctpty;
    m_Oricmpmtrtrcl.m_rsflag = "2";
    
    int iRet = m_Oricmpmtrtrcl.findByPK();

    if(RTN_SUCCESS != iRet)
    {
        sprintf(m_sErrMsg, "����ԭҵ��ʧ��, erro code[%d], erro cause[%s]", iRet, m_cmpmtrtrcl.GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(DB_NOT_FOUND);
    }
    
    snprintf(m_cCmt314.sOldtradeconsigndate, sizeof(m_cCmt314.sOldtradeconsigndate), m_Oricmpmtrtrcl.m_orgnlmsgid.c_str());
    snprintf(m_cCmt314.sOldcur, sizeof(m_cCmt314.sOldcur), m_Oricmpmtrtrcl.m_orgcurrency.c_str());//ԭ���ҷ���
    m_cCmt314.dOldamount = m_Oricmpmtrtrcl.m_orgamt;//ԭ���
    strTemp.erase();
    strTemp = m_Oricmpmtrtrcl.m_orgnlmsgid.substr(8, 8);
    m_cCmt314.iOldtxssno = atoi(strTemp.c_str());
    snprintf(m_cCmt314.sOldtradetype, sizeof(m_cCmt314.sOldtradetype), m_Oricmpmtrtrcl.m_otrantype.c_str());
    
    
    
	Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt314::SetData...");

}

int CSendCmt314::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt314::buildCmtMsg...");

    int iRet = m_cCmt314.CreateCmt("314", m_cmpmtrtrcl.m_instgdrctpty.c_str(), m_cmpmtrtrcl.m_instddrctpty.c_str(), m_sMesgId.c_str(), m_sMesgId.c_str(), m_cmpmtrtrcl.m_wrkdate.c_str(), "3");//��Ϣ���ȼ�Ϊ
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "���ɱ���ʧ��iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }

    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt314::buildCmtMsg...");
    return iRet;
}

int CSendCmt314::UpdateState()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt314::UpdateState...");

    string strSQL;
	strSQL += "UPDATE CM_PMTRTRCL t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_08;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
    strSQL += "' , t.STATETIME = sysdate ";
    
	strSQL += " WHERE t.SYSID = '";
	strSQL += m_szSysFlagNO;
    strSQL += "' AND t.MSGID = '";
	strSQL += m_cmpmtrtrcl.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_cmpmtrtrcl.m_instgindrctpty.c_str(); 	
	strSQL += "' AND t.RSFLAG = '";
	strSQL += m_cmpmtrtrcl.m_rsflag.c_str();								
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	
	SETCTX(m_cmpmtrtrcl);
	int iRet = m_cmpmtrtrcl.execsql(strSQL.c_str());
	
    if(RTN_SUCCESS != iRet)
    {	  
	   sprintf( m_sErrMsg,"execsql() error,error code =[%d] error cause = [%s]",iRet,m_cmpmtrtrcl.GetSqlErr());
	   Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_sErrMsg);
	   PMTS_ThrowException(__FILE__,__LINE__,DB_UPDATE_FAIL,m_sErrMsg);

    }
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt314::UpdateState...");

    return iRet;
    
}



