/******************************************************************** 
�ļ����� sendccms919.cpp
�����ˣ� hq
��  �ڣ� 2011.04.06
�޸��ˣ� 
��  �ڣ� 
��  ���� ����֤���������뱨��<ccms.919.001.01>���˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendccms919.h"

using namespace ZFPT;

CSendCcms919::CSendCcms919(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{
    m_szOriSign = "";
}

CSendCcms919::~CSendCcms919()
{

}

INT32 CSendCcms919::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms919::doWorkSelf...");

    int iRet = RTN_FAIL;

    // ��ȡ����
    GetData();

    // �鱨��
    CreateMsg();

    // ���ͱ���
    AddQueue(m_ccms919.m_sXMLBuff.c_str(), m_ccms919.m_sXMLBuff.length());

    // ��������״̬
    UpdateState();

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms919::doWorkSelf..."); 
    return RTN_SUCCESS;
}

INT32 CSendCcms919::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms919::GetData...");

    SETCTX(m_cmbndcert)

    m_cmbndcert.m_msgid = m_szMsgFlagNO; 
    m_cmbndcert.m_instgindrctpty = m_szSndNO;
    m_cmbndcert.m_rsflag = "1";

    int iRet = m_cmbndcert.findByPK();
    if (0 != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "findByPK error[%d][%s]", 
            iRet, m_cmbndcert.GetSqlErr());	
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms919::GetData...");
    return iRet;
}

INT32 CSendCcms919::CreateMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms919::CreateMsg...");
    
    int iSysflg = -1;
    int iRet = -1;
    chgSysCd(m_szSysFlagNO,iSysflg); 
    iRet = GetIsoDateTime(m_dbproc, iSysflg, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }


    // ������
    m_ccms919.MsgId          = m_cmbndcert.m_msgid;        //���ı�ʶ��
    m_ccms919.CreDtTm        = m_ISODateTime;              //���ķ���ʱ��
    m_ccms919.InstgDrctPty   = m_cmbndcert.m_instgdrctpty; //����ֱ�Ӳ������
    m_ccms919.GrpHdrInstgPty = m_cmbndcert.m_instgdrctpty; //����������=����ֱ�Ӳ������
    m_ccms919.InstdDrctPty   = m_cmbndcert.m_instddrctpty; //����ֱ�Ӳ������
    m_ccms919.GrpHdrInstdPty = m_cmbndcert.m_instddrctpty; //���ղ������=����ֱ�Ӳ������
    m_ccms919.SysCd          = "CCMS";                     //ϵͳ���
    m_ccms919.Rmk            = m_cmbndcert.m_rmkinf;       //��ע

    string strTemp;
    int iTimes = 0;
    while (true)
    {  
        iTimes++;
        if (0 == GetTagVal(strTemp, m_cmbndcert.m_mmbcdlist, "/MmbCd/", iTimes))
        {
            Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iTimes:[%d]strtemp[%s]", 
                iTimes, strTemp.c_str());
                
            m_ccms919.SetMmbCd(iTimes - 1, strTemp.c_str());

			m_ccms919.MmbCd = strTemp;			
            m_ccms919.AddTxStr();
            
        }
        else
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iTimes:[%d]", iTimes);
            break;
        }
    }
    

    // �鱨��ͷ
    m_ccms919.CreateXMlHeader("CCMS", 
                            m_cmbndcert.m_wrkdate.c_str(),
                            m_cmbndcert.m_instgdrctpty.c_str(),
                            m_cmbndcert.m_instddrctpty.c_str(),
                            "ccms.919.001.01",
                            m_sMesgId.c_str());

    // ��ǩ
    AddSign919();
    
    // �鱨��
    iRet = m_ccms919.CreateXml();
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CreateMsg error,iRet[%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sXMLBuff=[%s]", m_ccms919.m_sXMLBuff.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms919::CreateMsg...");
    return RTN_SUCCESS;
}

void CSendCcms919::AddSign919()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms919::AddSign919...");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_ccms919.getOriSignStr();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSignBuff:[%s]", m_ccms919.m_sSignBuff.c_str());
	
	AddSign(m_ccms919.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN,
			m_ccms919.InstgDrctPty.c_str());
	
	m_ccms919.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms919::AddSign919...");
}

INT32 CSendCcms919::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms919::UpdateState...");

    string strSQL;

    strSQL += "UPDATE CM_BNDDIGCERT t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_08;
    strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
    strSQL += "', t.MESGREFID = '";
    strSQL += m_sMesgId;
    strSQL += "', t.STATETIME = sysdate";

    strSQL += " WHERE t.MSGID = '";
    strSQL += m_szMsgFlagNO;									
    strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL[%s]", strSQL.c_str());

    int iRet = m_cmbndcert.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����CM_BNDDIGCERT��ʧ��[%d][%s]", 
            iRet, m_cmbndcert.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms919::UpdateState...");
    return RTN_SUCCESS;
}



