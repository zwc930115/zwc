/******************************************************************** 
文件名： recvccms921.h
创建人： handongfeng
日  期： 2011-04-02
修改人： 
日  期： 
描  述： 数字证书绑定通知报文<ccms.921.001.01>来账处理
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif
#include "recvccms921.h"

CRecvCcms921::CRecvCcms921()
{
	m_strMsgTp = "ccms.921.001.01";
	m_iChgTp   = 0;
}


CRecvCcms921::~CRecvCcms921()
{

}

void CRecvCcms921::UpdateState() 
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms921::UpdateState()");

    string strSQL;
    strSQL += "UPDATE cm_bnddigcert t SET t.STATETIME = sysdate, t.PROCSTATE = '74'";

    strSQL += " WHERE t.MSGID = '";
    strSQL += m_ccms921.OrgnlMsgId;
    strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());

    SETCTX(m_CCmbnddigcert);
    int iRet = m_CCmbnddigcert.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "修改状态失败iRet=%d, %s", iRet, m_CCmbnddigcert.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }   

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms921::UpdateState()");
}

/*void CRecvCcms921::UpdataCertData() 
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms921::UpdataCertData()");

    SETCTX(m_CCmbankcertinfo);
    int iRet = m_CCmbankcertinfo.findByPK();
    if (SQLNOTFOUND == iRet)
    {
        m_CCmbankcertinfo.m_bankcode = m_ccms921.MmbCd;
        m_CCmbankcertinfo.m_certbody = m_ccms921.DgtlSgntr;
        m_CCmbankcertinfo.m_status = "35";
        int iIn = m_CCmbankcertinfo.insert();
        if (iIn != OPERACT_SUCCESS)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "增加证书失败,继续增加其它证书iRet=%d, %s", iRet, m_CCmbankcertinfo.GetSqlErr());
            return;
        }
    } 
    else
    {
        string strSQL;
        strSQL += "UPDATE cm_bankcertinfo t SET ";
        strSQL += " t.CERTBODY = '";
        strSQL += m_ccms921.DgtlSgntr;
        strSQL += "' ";

        strSQL += " WHERE t.bankcode = '";
        strSQL += m_ccms921.MmbCd;
        strSQL += "'";
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());

        int iRet = m_CCmbankcertinfo.execsql(strSQL.c_str());
        if(iRet != RTN_SUCCESS)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "修改状态失败iRet=%d, %s", iRet, m_CCmbankcertinfo.GetSqlErr());
            return;
        }   
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms921::UpdataCertData()");
}*/

void CRecvCcms921::ParserCert(const char *pCert)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms921::ParserCert()");
    return 0;
    string strMsg903;
    textBase64Decode(pCert, strMsg903);
	printf("strMsg903[%s]\n", strMsg903.c_str());

    // 报文是否为空
    if (strMsg903.empty())
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");	
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "报文为空");
    }

		Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"strMsg903[%s]", strMsg903.c_str());
    // 解析报文
    ccms903 Pccms903;
    int iRet = Pccms903.ParseXml(strMsg903.c_str());
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错! iRet= %d", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文解析出错");	
    }
    
    Pccms903.getOriSignStr();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_ccms903.m_sSignBuff[%s]",Pccms903.m_sSignBuff.c_str());
	char szSndSapBank[14+1] = {0};
	strcpy(szSndSapBank,Pccms903.InstgDrctPty.c_str());
	
    char *pStr = new char[strlen(Pccms903.m_sSignBuff.c_str()) + 1];
    
    ISNULL(pStr);
    
    strcpy(pStr, Pccms903.m_sSignBuff.c_str());
    
    //903核签特殊处理
    iRet = checkSignDetached(m_dbproc,
							    signTrim(pStr),
							    (char*)Pccms903.m_szDigitSign.c_str(), 
							    Trim(szSndSapBank),
							    m_iChgTp);
	//内存释放
    DELPOINT(pStr);
    if( RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__,NULL, "数字签名验证未通过!");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_CHECKSIGN_FAIL, "数字签名验证未通过");
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms921::ParserCert()");
}

INT32 CRecvCcms921::Work(LPCSTR sMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms921::Work()");

    //1、解析报文
    unPack(sMsg);

    //2、给m_CCmbnddigcert的成员赋值
	SetData(sMsg);
    
    m_ccms921.getOriSignStr();
    
    CheckSign(m_ccms921.m_sSignBuff.c_str(),
			m_ccms921.m_szDigitSign.c_str(),
			m_ccms921.InstgDrctPty.c_str());

    UpdateState();

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms921::work()");

    return RTN_SUCCESS;
}

INT32 CRecvCcms921::unPack(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms921::unPack");	

	int iRet = RTN_FAIL;

	// 报文是否为空
	if (NULL == sMsg || '\0' == sMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "报文为空");
	}
	
	// 解析报文
	iRet = m_ccms921.ParseXml(sMsg);
	if (RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错! iRet= %d", iRet);	
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文解析出错");	
	}

    ZFPTLOG.SetLogInfo("921", m_ccms921.MsgId.c_str());
	
    // 用于写错误文件名用
	m_strMsgID	=	m_ccms921.MsgId;
	
	// 获取工作日期
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;      
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms921::unPack");	

	return RTN_SUCCESS;
}

INT32 CRecvCcms921::SetData(LPCSTR pchMsg)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms921::SetData");	

    int iBegin = atoi(m_ccms921.StartNb.c_str());
    int iEnd = atoi(m_ccms921.EndNb.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iBegin[%d]--->iEnd[%d]", iBegin, iEnd);	

    for (int i = iBegin; i < iEnd+1; i++)
    {
        m_ccms921.MmbCd = m_ccms921.GetMmbCd(i - 1);
        m_ccms921.DgtlSgntr = m_ccms921.GetDgtlSgntr(i - 1);
        m_ccms921.AddTxStr();

		char szSrc1[10240] = {0};
		char szSrc2[10240] = {0};
		strcpy(szSrc2, m_ccms921.DgtlSgntr.c_str());
		strcpy(szSrc1, removeChar13_10(szSrc2));
        ParserCert(szSrc1);

        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "i=[%d],bankcode=[%s] process success", i, m_ccms921.MmbCd.c_str());	
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms921::SetData");	

    return RTN_SUCCESS;
}

/*INT32 CRecvCcms921::SetData(LPCSTR pchMsg)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms921::SetData");	

    m_CCmbnddigcert.m_msgid         = m_ccms921.MsgId;	                    //报文标识号
    m_CCmbnddigcert.m_chgtp         = "CC00";	                    //操作类型
    m_CCmbnddigcert.m_wrkdate       = m_strWorkDate;	                    //工作日期
    m_CCmbnddigcert.m_msgtp         = m_strMsgTp;	                        //报文类型

    m_CCmbnddigcert.m_instgdrctpty  = m_ccms921.InstgDrctPty;	            //发起直接参与机构
    m_CCmbnddigcert.m_instgindrctpty= m_ccms921.GrpHdrInstgPty;	            //发起参与机构
    m_CCmbnddigcert.m_instddrctpty	= m_ccms921.InstdDrctPty;	            //接收直接参与机构
    m_CCmbnddigcert.m_instdindrctpty= m_ccms921.GrpHdrInstdPty;	            //接收参与机构

    m_CCmbnddigcert.m_rsflag        = SRC_FRCNAPS;	                        //往来标志:1-往，2-来

    m_CCmbnddigcert.m_mesgid        = m_ccms921.m_PMTSHeader.getMesgID();	//通信级标识号
    m_CCmbnddigcert.m_mesgrefid     = m_ccms921.m_PMTSHeader.getMesgRefID();//通信级参考号
    m_CCmbnddigcert.m_rmkinf        = m_ccms921.Rmk;		                //备注

    m_CCmbnddigcert.m_procstate     = PR_HVBP_01;		                    //处理状态
    m_CCmbnddigcert.m_certtxt       = "";	                                //证书

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms921::SetData");	

    return RTN_SUCCESS;
}

INT32 CRecvCcms921::InsertData(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms921::InsertData");
	
    SETCTX(m_CCmbnddigcert);
    int iRet = m_CCmbnddigcert.insert();
    
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "插入Cm_bnddigcert表失败, iRet=%d, %s", iRet,m_CCmbnddigcert.GetSqlErr());
        PMTS_ThrowException(DB_INSERT_FAIL);          
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms921::InsertData");

	return iRet;
}*/
