/********************************************************************
文件名：sendccms316.cpp
创建人：aps-lel
日  期：2011.03.31
描  述：
版  本：
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendccms316.h"


CSendCcms316::CSendCcms316(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{

}

CSendCcms316::~CSendCcms316()
{

}

int CSendCcms316::doWorkSelf()
{
   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms316::doWork...");

    int iRet = 0;

    GetData();

    SetData();
	
    iRet = m_ccms316.CreateXml();
	
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    AddQueue( m_ccms316.m_sXMLBuff.c_str(), m_ccms316.m_sXMLBuff.length());
    
    UpdateState();

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms316::doWork..."); 
	
    return RTN_SUCCESS;
}

void CSendCcms316::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms316::SetDBKey...");
    
	m_Cmtransstqry.m_msgid = m_szMsgFlagNO; //报文标识号
	m_Cmtransstqry.m_instgindrctpty = m_szSndNO; //原发起参与机构=发起参与机构
    m_Cmtransstqry.m_sysid = m_szSysFlagNO;//系统标识号

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgFlagNO = %s", m_szMsgFlagNO);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndNO = %s", m_szSndNO);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSysFlagNO = %s", m_szSysFlagNO);
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms316::SetDBKey...");
    return;
}

void CSendCcms316::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms316::SetData...");
    string strOrisndbk,strOriMsgTp;
    
    // 组文件头
    m_ccms316.CreateXMlHeader(m_Cmtransstqry.m_sysid.c_str(),                        \
                                m_Cmtransstqry.m_wrkdate.c_str(), \
                                m_Cmtransstqry.m_instgdrctpty.c_str(),\
                                m_Cmtransstqry.m_instddrctpty.c_str(),\
                                "ccms.316.001.01",              \
                                m_sMesgId.c_str()); 


	m_ccms316.msgid= m_Cmtransstqry.m_msgid;      //报文标识号
	m_ccms316.oriMsgid= m_Cmtransstqry.m_rptmsgid;//原报文标识号

    strOrisndbk = "/A70/" + m_Cmtransstqry.m_rptid;//查询原业务的发起参与机构号
    strOriMsgTp = "/F26/" + m_Cmtransstqry.m_orimsgtp;
    //printf("strOrisndbk[%s]\n", strOrisndbk.c_str());
    //printf("strOriMsgTp[%s]\n", strOriMsgTp.c_str());
	//m_ccms316.SetPrtryRef(0,strOrisndbk.c_str());//原发起参与机构 格式/A70/308581000106
    //m_ccms316.SetPrtryRef(1,strOriMsgTp.c_str());//原报文类型编码 格式/F26/beps.125.001.01

    //m_ccms316.AddNodeToSubcycle("PmtInstrRef"                    ,m_ccms316.PmtInstrRef.c_str());
    //m_ccms316.AddSubcycleToNode("PrtryRefType");
    m_ccms316.AddNodeToSubcycle("PrtryRef"                    ,strOrisndbk.c_str());
    m_ccms316.AddSubcycleToNode("InstrRef");
    m_ccms316.AddNodeToSubcycle("PrtryRef"                    ,strOriMsgTp.c_str());
	m_ccms316.AddSubcycleToNode("InstrRef");    
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms316::SetData...");
    return;
}

int CSendCcms316::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms316::GetData...");
    m_Cmtransstqry.setctx(m_dbproc);

    SetDBKey();
	
    int iRet = m_Cmtransstqry.findByPK();
	
	if(RTN_SUCCESS != iRet)
	{
	   sprintf( m_sErrMsg,"findByPK() error,error code =[%d] error cause = [%s]",iRet,m_Cmtransstqry.GetSqlErr());
	   Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_sErrMsg);
	   PMTS_ThrowException(__FILE__,__LINE__,DB_NOT_FOUND,m_sErrMsg);
			
	}
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms316::GetData...");
	
    return iRet;
}

int CSendCcms316::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms316::UpdateState...");
	
    SetDBKey();
	
    string strSQL;
	
	strSQL += "UPDATE CM_TRANSSTQRY t SET t.PROCSTATE = '";
	strSQL += PR_HVBP_08;//已转发
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
    strSQL += "', t.STATETIME = sysdate ";
    
	strSQL += " WHERE t.SYSID = '";
	strSQL += m_Cmtransstqry.m_sysid.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_Cmtransstqry.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Cmtransstqry.m_instgindrctpty.c_str(); 									
	strSQL += "'";
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL = %s", strSQL.c_str());
	
	int iRet = m_Cmtransstqry.execsql(strSQL.c_str());
	
    if(RTN_SUCCESS != iRet)
    {	  
	   sprintf( m_sErrMsg,"execsql() error,error code =[%d] error cause = [%s]",iRet,m_Cmtransstqry.GetSqlErr());
	   Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_sErrMsg);
	   PMTS_ThrowException(__FILE__,__LINE__,DB_UPDATE_FAIL,m_sErrMsg);

    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms316::UpdateState...");
	
    return RTN_SUCCESS;
}





