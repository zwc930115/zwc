/********************************************************************
�ļ�����send805.cpp
�����ˣ�handongfeng
��  �ڣ�2011.01.14
��  ����
��  ����
Copyright (c) 2009  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendccms805.h"

CSendCcms805::CSendCcms805(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{
}

CSendCcms805::~CSendCcms805()
{

}

void CSendCcms805::AddSign805()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms805::AddSign805");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_ccms805.getOriSignStr();
	
	AddSign(m_ccms805.m_sSignBuff.c_str(), 
					sSignedStr, 
					RAWSIGN,
					m_ccms805.InstgDrctPty.c_str());
	
	m_ccms805.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms805::AddSign805");
}

void CSendCcms805::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms805::SetDBKey...");

	oCCmlogon.m_sysid = m_szSysFlagNO;
	oCCmlogon.m_msgid = m_szMsgFlagNO;
	oCCmlogon.m_instgdrctpty = m_szSndNO;
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "oCCmlogon.m_sysid = [%s]", oCCmlogon.m_sysid.c_str());  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "oCCmlogon.m_msgid = [%s]", oCCmlogon.m_msgid.c_str());  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "oCCmlogon.m_instgdrctpty = [%s]", oCCmlogon.m_instgdrctpty.c_str());  
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms805::SetDBKey...");
    return;
}

void CSendCcms805::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms805::SetData...");

    GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);

    // ���ļ�ͷ
    m_ccms805.CreateXMlHeader(oCCmlogon.m_sysid.c_str(),\
                                m_sWorkDate, \
                                oCCmlogon.m_instgdrctpty.c_str(),\
                                oCCmlogon.m_instddrctpty.c_str(),\
                                "ccms.805.001.02",              \
                                m_sMesgId.c_str()); 

	m_ccms805.LoginOprTp = oCCmlogon.m_optype;//��������
	m_ccms805.Rmk = "";//��ע
	
    int iSysflg = -1;
    int iRet = -1;
    chgSysCd(m_szSysFlagNO,iSysflg); 
    iRet = GetIsoDateTime(m_dbproc, iSysflg, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }

    m_ccms805.CreDtTm = m_ISODateTime;//���ķ���ʱ��  
	m_ccms805.MsgId = oCCmlogon.m_msgid;//���ı�ʶ��
	m_ccms805.SysCd = m_szSysFlagNO;//ϵͳ���	
	m_ccms805.GrpHdrInstgPty = oCCmlogon.m_instgdrctpty;//�����Ӳ������
	m_ccms805.InstdDrctPty = oCCmlogon.m_instddrctpty;//����ֱ�Ӳ������
	m_ccms805.GrpHdrInstdPty = oCCmlogon.m_instddrctpty;//���ռ�Ӳ������
	m_ccms805.InstgDrctPty = oCCmlogon.m_instgdrctpty;//����ֱ�Ӳ������    

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms805::SetData...");
    return;
}

int CSendCcms805::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms805::GetData...");

    SETCTX(oCCmlogon);
    SetDBKey();
    int iRet = oCCmlogon.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��,iRet=%d, %s", iRet, oCCmlogon.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms805::GetData...");
    return iRet;
}

int CSendCcms805::UpdateState()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms05::UpdateState...");
    SetDBKey();
    string strSQL;
	strSQL += "UPDATE CM_LOGON  t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_08;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
    strSQL += "' , t.PROCTIME = sysdate ";   
	strSQL += " WHERE t.MSGID = '";
	strSQL += oCCmlogon.m_msgid.c_str();
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += oCCmlogon.m_instgdrctpty.c_str(); 									
	strSQL += "' ";
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	
	int iRet = oCCmlogon.execsql(strSQL.c_str());
	
    if(RTN_SUCCESS != iRet)
    {	  
	   sprintf( m_sErrMsg,"execsql() error,error code =[%d] error cause = [%s]",iRet,oCCmlogon.GetSqlErr());
	   Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_sErrMsg);
	   PMTS_ThrowException(__FILE__,__LINE__,DB_UPDATE_FAIL,m_sErrMsg);

    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms805::UpdateState...");
    return RTN_SUCCESS;
    
}

/*int CSendCcms805::CheckWork()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms805::doWork...");

    int iRet = 0;
    if(0 == strcpy(m_szSysFlagNO, "hvps"))
    {
        iRet = m_Hvsapbankinfo.findByPK();
        if(RTN_SUCCESS != iRet)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��,iRet=%d, %s", iRet, m_Hvsapbankinfo.GetSqlErr());
            PMTS_ThrowException(DB_NOT_FOUND);
        }
        if("02" == m_Hvsapbankinfo.m_chgstate)
        {
            iRet = -1;
        }
        else
        {
            iRet = 0;
        }
    }
    else
    {
        iRet = m_Bpsapbankinfo.findByPK();
        if(RTN_SUCCESS != iRet)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��,iRet=%d, %s", iRet, m_Bpsapbankinfo.GetSqlErr());
            PMTS_ThrowException(DB_NOT_FOUND);
        }
        if("02" == m_Bpsapbankinfo.m_chgstate)
        {
            iRet = -1;
        }
        else
        {
            iRet = 0;
        }        
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms805::doWork...");
    return iRet;
}*/

int CSendCcms805::doWorkSelf()
{
   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms805::doWork...");

    int iRet = 0;

    /*iRet = CheckWork();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ϵͳ�ѵ�¼");
        PMTS_ThrowException(OPT_LOGON);
    }*/
    
    GetData();
    
    SetData();

    //��ǩ
    AddSign805();

    iRet = m_ccms805.CreateXml();
    if(0 != iRet)
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    AddQueue(m_ccms805.m_sXMLBuff.c_str(), m_ccms805.m_sXMLBuff.length());
	UpdateState();
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms805::doWork..."); 
    return RTN_SUCCESS;
}


