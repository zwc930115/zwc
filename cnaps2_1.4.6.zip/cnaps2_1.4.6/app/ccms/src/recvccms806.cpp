/********************************************************************
�ļ�����recvccms806.cpp
�����ˣ�handongfeng
��  �ڣ�2011.03.29
�޸��ˣ�
��  �ڣ�
��  ����
��  ����
Copyright (c) 2009  YLINK
********************************************************************/
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvccms806.h"


CRecvCcms806::CRecvCcms806()
{
	
}

/*****************************************************************
*  Function:    Work
*  Description: ҵ��������
*  Input:       ��
*  Output:      ��
*  Return:      ��
*  Others:      ��
*  Author:      handongfeng
*  Date:        2011.03.29
*****************************************************************/
INT32 CRecvCcms806::Work(LPCSTR szMsg)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms806::Work():��ʼ����ccms.806.001.01ҵ��");
    
    //1������ҵ����
    UnPack(szMsg);

    SetData(szMsg);

    InsertData();
    
	//2��ҵ����
	//CheckValues();
	
    //3���޸�ϵͳ������
    UpdateSate();
        
    Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms806::Work():����ccms.806.001.01ҵ�����."); 
    
    return OPERACT_SUCCESS;
}

INT32 CRecvCcms806::SetData(LPCSTR pchMsg)
{
    return OPERACT_SUCCESS;
}

INT32 CRecvCcms806::InsertData(void)
{
    return OPERACT_SUCCESS;
}

void CRecvCcms806::SetLogOnKey()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms806::UnPack().Begin!");
    
    oCmlogon.m_sysid = occms806.SysCd;
    oCmlogon.m_msgid = occms806.MsgId;
    oCmlogon.m_instgdrctpty = occms806.InstgDrctPty;
    Trace(L_INFO, __FILE__, __LINE__, NULL, "oCmlogon.m_sysid=%s", oCmlogon.m_sysid.c_str());
    Trace(L_INFO, __FILE__, __LINE__, NULL, "oCmlogon.m_msgid=%s", oCmlogon.m_msgid.c_str());
    Trace(L_INFO, __FILE__, __LINE__, NULL, "oCmlogon.m_instgdrctpty=%s", oCmlogon.m_instgdrctpty.c_str());
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms806::UnPack().END!");
    return;
}

int CRecvCcms806::GetLogOn()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms806::GetLogOn().Begin!");

    SetLogOnKey();

    SETCTX(oCmlogon);
    
    int iRet = oCmlogon.findByPK();

    Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms806::GetLogOn().Begin!");
    return iRet;
}

void CRecvCcms806::UnPack(LPCSTR szMsg)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms806::UnPack().Begin!");

	int iRet = occms806.ParseXml(szMsg);

	if (iRet != SQL_SUCCESS)
	{
		sprintf(m_szErrMsg, "CRecvCcms806::UnPack():���Ľ�������!iRet=[%d]", iRet);
		
		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);

        PMTS_ThrowException(__FILE__, __LINE__,  OPT_PRS_MSG_FAIL, m_szErrMsg); 
	}

	ZFPTLOG.SetLogInfo("806", occms806.MsgId.c_str());
	m_strMsgID	=	occms806.MsgId;
	
	Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms806::UnPack().End!");
	
	return;          	       
}

/*void CRecvCcms806::CheckValues()
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms806::CheckValues().Begin!");

	char sRecver[12+1];
	memset(sRecver,NULL_CHAR,sizeof(sRecver));
	
	//����������:�Ƿ��Ǳ���:������013
	getSysParam("013", sRecver);
	if (strcmp(Trim(occms806.InstdDrctPty).c_str(),sRecver) != 0)
    {
		sprintf(m_szErrMsg, "���ղ��������[%s]�����ڵ�ǰ�к�[%s]", occms806.InstdDrctPty.c_str(),sRecver);
		
		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__,  m_szErrMsg);
    }
	
	Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms806::CheckValues().End!");
	
	return;          	       
}*/


void CRecvCcms806::UpdateSate()
{   
	Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms806::UpdateSate() Begin");
	
    SETCTX(m_Hvsapbankinfo);
    SETCTX(m_Bpsapbankinfo);
    SETCTX(oCmlogon);

    string strSQL;
    
	//NPC�����ɹ�ʱ,�޸�ϵͳ������
	Trace(L_INFO, __FILE__, __LINE__, NULL, "occms806.PrcSts=%s", occms806.PrcSts.c_str());
	if (strcmp(occms806.PrcSts.c_str(),"PR07") == 0) 
	{
		//����������� = OT00��¼���޸�״̬ = 02 ����; 
		//����������� = OT01�˳����޸�״̬ = 03�˳�;
		if(strcmp(occms806.LoginOprTp.c_str(),"OT00") ==0)
		{
	        if(!STRNCASECMP(occms806.SysCd.c_str(), "HVPS", 4))
	        {
	            strSQL = "";
	        	strSQL += "UPDATE hv_sapbankinfo t SET ";
	        	strSQL += "t.chgstate = '";
	            strSQL += "02";          //����½
	            strSQL += "' ";
	        	strSQL += " WHERE t.sapbank = '";
	        	strSQL += occms806.InstdDrctPty.c_str();								
	        	strSQL += "'";
	        	
	            Trace(L_INFO, __FILE__, __LINE__, NULL, "strSQl=%s", strSQL.c_str());
	         	int iRet = m_Hvsapbankinfo.execsql(strSQL.c_str());
	    		if(OPERACT_SUCCESS != iRet)
	    		{
	    			sprintf(m_szErrMsg, "CRecvCcms806::UpdateSate():�޸ı�����ʧ��!iRet=[%d], %s", iRet,m_Hvsapbankinfo.GetSqlErr() );
	    			
	    			Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
	
	    	        PMTS_ThrowException(__FILE__, __LINE__,  DB_UPDATE_FAIL, m_szErrMsg); 
	    		}
	        	
	    	}
	        else if(!STRNCASECMP(occms806.SysCd.c_str(), "BEPS", 4))
	        {
	            strSQL = "";
	        	strSQL += "UPDATE bp_sapbankinfo t SET ";
	        	strSQL += "t.chgstate = '";
	            strSQL += "02";             //����½
	            strSQL += "' ";
	        	strSQL += " WHERE t.sapbank = '";
	        	strSQL += occms806.InstdDrctPty.c_str();								
	        	strSQL += "'";
	        	
	            Trace(L_INFO, __FILE__, __LINE__, NULL, "strSQl=%s", strSQL.c_str());
	         	int iRet = m_Bpsapbankinfo.execsql(strSQL.c_str());
	    		if(OPERACT_SUCCESS != iRet)
	    		{
	    			sprintf(m_szErrMsg, "CRecvCcms806::UpdateSate():�޸ı�����ʧ��!iRet=[%d], %s", iRet,m_Bpsapbankinfo.GetSqlErr() );
	    			
	    			Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
	
	    	        PMTS_ThrowException(__FILE__, __LINE__,  DB_UPDATE_FAIL, m_szErrMsg); 
	    		}
	        }
	        else
	        {
	            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "δ�ҵ���Ӧϵͳ��occms806.SysCd=%s", occms806.SysCd.c_str());
	            return ;
	        }
    	}
    	if(strcmp(occms806.LoginOprTp.c_str(),"OT01") ==0)
		{
	        if(!STRNCASECMP(occms806.SysCd.c_str(), "HVPS", 4))
	        {
	            strSQL = "";
	        	strSQL += "UPDATE hv_sapbankinfo t SET ";
	        	strSQL += "t.chgstate = '";
	            strSQL += "03";          //���˳�
	            strSQL += "'"; 
	        	strSQL += " WHERE t.sapbank = '";
	        	strSQL += occms806.InstdDrctPty.c_str();								
	        	strSQL += "'";
	        	
	            Trace(L_INFO, __FILE__, __LINE__, NULL, "strSQl=%s", strSQL.c_str());
	         	int iRet = m_Hvsapbankinfo.execsql(strSQL.c_str());
	    		if(OPERACT_SUCCESS != iRet)
	    		{
	    			sprintf(m_szErrMsg, "CRecvCcms806::UpdateSate():�޸ı�����ʧ��!iRet=[%d], %s", iRet,m_Hvsapbankinfo.GetSqlErr() );
	    			
	    			Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
	
	    	        PMTS_ThrowException(__FILE__, __LINE__,  DB_UPDATE_FAIL, m_szErrMsg); 
	    		}
	        	
	    	}
	        else if(!STRNCASECMP(occms806.SysCd.c_str(), "BEPS", 4))
	        {
	        	//����״̬Ϊ���˳�
	            strSQL = "";
	        	strSQL += "UPDATE bp_sapbankinfo t SET ";
	        	strSQL += "t.chgstate = '03' WHERE t.sapbank = '";
	        	strSQL += occms806.InstdDrctPty.c_str();								
	        	strSQL += "'";
	        	
	            Trace(L_INFO, __FILE__, __LINE__, NULL, "strSQl=%s", strSQL.c_str());
	         	int iRet = m_Bpsapbankinfo.execsql(strSQL.c_str());
	    		if(OPERACT_SUCCESS != iRet)
	    		{
	    			sprintf(m_szErrMsg, "CRecvCcms806::UpdateSate():�޸ı�����ʧ��!iRet=[%d], %s",
	    					iRet,m_Bpsapbankinfo.GetSqlErr() );
	    			
	    			Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
	
	    	        PMTS_ThrowException(__FILE__, __LINE__,  DB_UPDATE_FAIL, m_szErrMsg); 
	    		}
	        }
	        else
	        {
	            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "δ�ҵ���Ӧϵͳ��occms806.SysCd=%s", occms806.SysCd.c_str());
	            return ;
	        }
    	}
        strSQL = "";
    	strSQL += "UPDATE cm_logon t SET ";
    	strSQL += "t.PROCSTATE = '";
        strSQL += PR_HVBP_74;
    	strSQL += "',t.NPCPRCSTS = 'PR07'";   //������
        //strSQL += occms806.PrcSts.c_str();     
        //strSQL += "' ";
        
    	strSQL += " WHERE t.sysid = '";
    	strSQL += occms806.SysCd.c_str();	
        strSQL += "' AND t.msgid = '";
        strSQL += occms806.OrgnlMsgId.c_str(); 	
        strSQL += "' AND t.INSTGDRCTPTY = '";
        strSQL += occms806.InstdDrctPty.c_str(); 	
    	strSQL += "'";

    	Trace(L_INFO, __FILE__, __LINE__, NULL, "strSQl=%s", strSQL.c_str());
    	
    	int iRet = oCmlogon.execsql(strSQL.c_str());
		if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "CRecvCcms806::UpdateSate():�޸�logon������ʧ��!iRet=[%d], %s", iRet,oCmlogon.GetSqlErr() );
			
			Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);

	        PMTS_ThrowException(__FILE__, __LINE__,  DB_UPDATE_FAIL, m_szErrMsg); 
		}			
		
	}
    else
    {
        strSQL = "";
    	strSQL += "UPDATE cm_logon t SET ";
    	strSQL += "t.PROCSTATE = '";
        strSQL += PR_HVBP_24;
    	strSQL += "', t.npcPrcSts = 'PR09"; //���ܾ�
        //strSQL += occms806.PrcSts.c_str();
    	strSQL += "', t.PrcCd = '";
        strSQL += occms806.PrcCd.c_str();  
    	strSQL += "', t.RjctInf  = '";
        strSQL += occms806.RjctInf.c_str();          
        strSQL += "' ";
        Trace(L_DEBUG, __FILE__, __LINE__, NULL, "occms806.RjctInf[%s]",occms806.RjctInf.c_str());
        Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSQL[%s]",strSQL.c_str());
        
    	strSQL += " WHERE t.sysid = '";
    	strSQL += occms806.SysCd.c_str();	
        strSQL += "' AND t.msgid = '";
        strSQL += occms806.OrgnlMsgId.c_str(); 	
        strSQL += "' AND t.INSTGDRCTPTY = '";
        strSQL += occms806.InstdDrctPty.c_str(); 	
    	strSQL += "'";
    	Trace(L_INFO, __FILE__, __LINE__, NULL, "strSQl=%s", strSQL.c_str());
    	
    	int iRet = oCmlogon.execsql(strSQL.c_str());
		if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "CRecvCcms806::UpdateSate():�޸�logon������ʧ��!iRet=[%d], %s", iRet,oCmlogon.GetSqlErr() );
			
			Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);

	        PMTS_ThrowException(__FILE__, __LINE__,  DB_UPDATE_FAIL, m_szErrMsg); 
		}
    }
	
    Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms806::UpdateSate() End");
	
    return ;
	
}



