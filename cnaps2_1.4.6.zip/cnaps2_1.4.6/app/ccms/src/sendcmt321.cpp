/******************************************************************** 
�ļ����� sendcmt321.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt321.h"

using namespace ZFPT;

CSendCmt321::CSendCmt321(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{
}

CSendCmt321::~CSendCmt321()
{
}

INT32 CSendCmt321::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt321::doWorkSelf");

    GetData();
    
    SetData();

    buildCmtMsg();
    
    UpdateState();

    // ���ͱ���
    AddQueue(m_cmt321.m_strCmtmsg.c_str(), m_cmt321.m_strCmtmsg.length());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt321::doWorkSelf"); 
    return 0;
}

INT32 CSendCmt321::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt321::SetData");
    
    strncpy(m_cmt321.sConsigndate, m_CmTrRepeal.m_consigndate.c_str(),  sizeof(m_cmt321.sConsigndate)-1);        //ί������         8n         M
    strncpy(m_cmt321.sApplysapbk, m_CmTrRepeal.m_instgdrctpty.c_str(),  sizeof(m_cmt321.sApplysapbk)-1);        //��������������   12n        M
    strncpy(m_cmt321.sApplymssno, m_CmTrRepeal.m_msgid.c_str(),         sizeof(m_cmt321.sApplymssno)-1);         //�����������     8n         M
    strncpy(m_cmt321.sOldpacktype, m_CmTrRepeal.m_orgnlmsgtp.c_str() + 3,sizeof(m_cmt321.sOldpacktype)-1);        //ԭ�����ͺ�       3n 	      M
    strncpy(m_cmt321.sOldpackdate, m_CmTrRepeal.m_orgnlmsgid.c_str(),           sizeof(m_cmt321.sOldpackdate)-1);        //ԭ��ί������     8n         M
    strncpy(m_cmt321.sOldpackno, m_CmTrRepeal.m_orgnlmsgid.c_str()+8,   sizeof(m_cmt321.sOldpackno)-1);          //ԭ�����         8n         M
    //strncpy(m_cmt321.sTextkey, m_CmTrRepeal.,sizeof()-1);           //��Ѻ             40x        O                
    strncpy(m_cmt321.sRemark, m_CmTrRepeal.m_rmkinf.c_str(),                    sizeof(m_cmt321.sRemark)-1);            //��������         60g        O        

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt321::SetData"); 
    return 0;
}

int CSendCmt321::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt321::getData");

	SETCTX(m_CmTrRepeal);
    
  	m_CmTrRepeal.m_instgdrctpty = m_szSndNO;
  	m_CmTrRepeal.m_msgid        = m_szMsgFlagNO;
  	
  	int iRet = m_CmTrRepeal.findByPK();
  	if (SQLNOTFOUND == iRet)
	{
		sprintf(m_sErrMsg, "�Ҳ���ָ��ҵ��[%s], [%s], [%d][%s]", 
		    m_szSndNO, m_szMsgFlagNO, iRet, m_CmTrRepeal.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	} 	
	else if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg, "��ѯ���ܱ���������[%s], [%s], [%d][%s]",
		    m_szSndNO, m_szMsgFlagNO, iRet, m_CmTrRepeal.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt321::getData"); 
    
	return iRet;
}
int CSendCmt321::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt123::buildCmtMsg...");

    int iRet = m_cmt321.CreateCmt("321", m_szSndNO, m_CmTrRepeal.m_instddrctpty.c_str(), m_sMesgId.c_str(), m_sMesgId.c_str(), m_CmTrRepeal.m_wrkdate.c_str(), "3");
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt321::buildCmtMsg...");
    return iRet;
}
int CSendCmt321::UpdateState(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendCmt321::UpdateDb");

	string strSQL;
	strSQL += "UPDATE CM_TRANSREPEAL t SET t.Procstate = '";
    strSQL += PR_HVBP_08;
	strSQL += "', t.STATETIME = sysdate WHERE t.msgid = '";
	strSQL += m_CmTrRepeal.m_msgid;
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_CmTrRepeal.m_instgdrctpty; 
	strSQL += "'";
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, strSQL.c_str());
	
    SETCTX(m_CmTrRepeal);
	int iRet = m_CmTrRepeal.execsql(strSQL.c_str());
	if (iRet != SQL_SUCCESS)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]",
		    iRet, m_CmTrRepeal.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
	}
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendCmt321::UpdateDb");
    return RTN_SUCCESS;
}




