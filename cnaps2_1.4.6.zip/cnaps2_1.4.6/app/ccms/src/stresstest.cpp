#include <string.h>
#include "mqagent.h"
#include "mutex.h"
using namespace std;

string strErrMsg;
string g_strTestFile;
string g_strRCVMQ;
int gTimes;		//来账测试笔数
int gFlag;
int gBeps;

#define SECOND_SEND 1
#define FIRST_SEND 2
#define SECOND_RECV 3
#define FIRST_RECV 4
#define SECOND_BEPS 5
#define FIRST_BEPS 6

void GetXMLTag(string XML, string BeginTag, string EndTag, string& Val, int iFlag = 0)
{
    int iBegin = XML.find(BeginTag);
    if (string::npos == iBegin)
    {
        printf("1没有找到此Tag[%s]\n", BeginTag.c_str());
        return;
    } 

    int iEnd = 0;
    if (2 == iFlag)
    {
        iEnd = XML.find(EndTag, iBegin);
    }
    else
    {
        iEnd = XML.find(EndTag);
    }

    if (string::npos == iBegin)
    {
        printf("2没有找到此Tag[%s]\n", EndTag.c_str());
        return;
    } 

    iBegin = iBegin + BeginTag.length();
    Val = XML.substr(iBegin, iEnd - iBegin);

    if (1 == iFlag)
    {
        if (Val.length() < 16)
        {
            printf("此MSGID错误[%s]\n", Val.c_str());
            return;
        }

        string s1 = Val.substr(0, 8);
        string s2 = Val.substr(8);
        int iVal = atoi(s2.c_str());
        ++iVal;
        char sMsgid[17] = {0};
        sprintf(sMsgid, "%s%08d", s1.c_str(), iVal);
        Val = sMsgid;
    }

    if (2 == iFlag)
    {
        if (Val.length() < 8)
        {
            printf("此MSGID错误[%s]\n", Val.c_str());
            return;
        }

        int iVal = atoi(Val.c_str());
        ++iVal;
        char sMsgid[9] = {0};
        sprintf(sMsgid, "%08d", iVal);
        Val = sMsgid;
    }

    return;
}

void SetXMLTag(string& XML, string BeginTag, string EndTag, string Val, int iFlag = 0)
{
    int iBegin = XML.find(BeginTag);
    if (string::npos == iBegin)
    {
        printf("3没有找到此Tag[%s]\n", BeginTag.c_str());
        return;
    } 

    int iEnd = 0;
    if (2 == iFlag)
    {
        iEnd = XML.find(EndTag, iBegin);
    } 
    else
    {
        iEnd = XML.find(EndTag);
    }
    
    if (string::npos == iBegin)
    {
        printf("4没有找到此Tag[%s]\n", EndTag.c_str());
        return;
    } 

    iBegin = iBegin + BeginTag.length();
    XML.replace(iBegin, iEnd - iBegin, Val);
    return;
}

void ReadMsgTxt(string& strMsgTxt, string strTxtName)
{
    //循环读取数据并处理
    FILE *fp = NULL; 

    fp = fopen(strTxtName.c_str(), "r");

    if ( fp == NULL )
    {
        strErrMsg = "打开文件出错";
        throw strErrMsg;
    }

    char sMsg[1024*1024] = {0};
    char sBuff[1024*1024] = {0};

    int rendlen = 0;
    int iTotalLen = 0;
    while ( 1 )
    {
        memset(sBuff, 0, sizeof(sBuff));
        fgets(sBuff, sizeof(sBuff), fp)	;

        rendlen = strlen(sBuff);
        if (rendlen == 0)
            break;
        strcpy(sMsg+iTotalLen ,sBuff);
        iTotalLen += rendlen;
    }

    strMsgTxt = sMsg;
}

void SaveMsgTxt(string Srcmsg, string FileName)
{
	FILE* fp=fopen(FileName.c_str(), "w");
	if( fp == NULL)
	{
		printf("FileName[%s]\n", FileName.c_str());
		strErrMsg = "打开文件失败";
		throw strErrMsg;
	}
	
	int iRet = fputs(Srcmsg.c_str(), fp);
	if(iRet == EOF)
	{
		strErrMsg = "写入文件失败";
		throw strErrMsg;
	}
}

void SetMsg(string& saps604Xml, string hvps111Xml, string BeginTag, string EndTag, string BeginTag1="", string EndTag1="")
{
    string strVal;
    GetXMLTag(hvps111Xml, BeginTag, EndTag, strVal);
    if(BeginTag1=="" && EndTag1=="")
    {
        SetXMLTag(saps604Xml, BeginTag, EndTag, strVal);
    }
    else
    {
        SetXMLTag(saps604Xml, BeginTag1, EndTag1, strVal);
    }
    
}

void TestRecv(MQAgent &pMQAgent)
{
    string strMsg, strMsgid, strTxid, str0BD, str0BC;
    ReadMsgTxt(strMsg, g_strTestFile);
    for(int i=1;i<=gTimes;i++)
    {
        int iRetcode = pMQAgent.PutMsg(g_strRCVMQ.c_str() ,strMsg.c_str(), strMsg.length());
        if(iRetcode!=0)
        {
            printf("g_strRCVMQ[%s]\n", g_strRCVMQ.c_str());
            printf("line: %d, function %s: Put MQ msg fail:[%s]\n", __LINE__, __FUNCTION__, pMQAgent.GetErrorInfo());
            exit(0);
        }
        pMQAgent.Commit();

        if ((SECOND_SEND == gFlag) || (SECOND_RECV == gFlag))
        {
            GetXMLTag(strMsg, "<MsgId>", "</MsgId>", strMsgid, 1);
            SetXMLTag(strMsg, "<MsgId>", "</MsgId>", strMsgid);
            if (SECOND_BEPS == gBeps)
            {
                GetXMLTag(strMsg, "<TxId>", "</TxId>", strTxid, 1);
                SetXMLTag(strMsg, "<TxId>", "</TxId>", strTxid);
            }
        }
        else
        {
            GetXMLTag(strMsg, "0BC", ":", str0BC, 2);
            SetXMLTag(strMsg, "0BC", ":", str0BC);
            if (FIRST_BEPS == gBeps)
            {
                GetXMLTag(strMsg, "0BD", ":", str0BD, 2);
                SetXMLTag(strMsg, "0BD", ":", str0BD);
            }
        }

        //打印次数
        /*char strTimes[7] = {0};
        sprintf(strTimes, "%06d ", i);
        printf("[%s]",strTimes);*/
    }

		SaveMsgTxt(strMsg, g_strTestFile);
    printf("end 二代:msgid=[%s]Txid[%s]  一代:0BD[%s]0BC[%s]\n",strMsgid.c_str(), strTxid.c_str(), str0BD.c_str(), str0BC.c_str());
}


int main(int argc, char * argv[])
{
    if (argc < 4)
    {
        printf("测试往帐请输入:./stresstest send beps.121.001.01.xml 100  测试来帐请输入:./stresstest recv beps.121.001.01.xml 100 \n");
		return -1;
    }

    gTimes = atoi(argv[3]);
    if (0 == gTimes)
    {
        printf("请输入正确的测试笔数.如:./stresstest recv beps.121.001.01.xml 100 \n");
    }
    try
    {
        //初始化MQ
        MQAgent cAgent;
        if(cAgent.Init("CMIAQ02", "/home/cnaps2/mq") != 0)
        {
            printf("Init MQ manager failed.\n");
            exit(0);
        }

        if (!strcmp(argv[1], "send"))
        {
            if ((strstr(argv[2], "beps")) || (strstr(argv[2], "hvps")) || (strstr(argv[2], "ccms")) || (strstr(argv[2], "saps")) || (strstr(argv[2], "nets")) || (strstr(argv[2], "pbcs")))
            {
                gFlag = SECOND_SEND;
            }
            else if((strstr(argv[2], "cmt")) || (strstr(argv[2], "pkg")))
            {
                gFlag = FIRST_SEND;
            }
            else
            {
                printf("文件名没有符合要求,请小写,并用人行的报文用例名称命名");
                exit(0);
            }

            if ((strstr(argv[2], "hvps")) || (strstr(argv[2], "cmt")))//假定CMT全部为大额
            {
                g_strRCVMQ = "TOPS_MBFE_HVPS";
            }
            else if ((strstr(argv[2], "beps")) || (strstr(argv[2], "pkg")))
            {
                if ((strstr(argv[2], "beps")))
                {
                    gBeps = SECOND_BEPS;
                }
                else
                {
                    gBeps = FIRST_BEPS;
                }
                g_strRCVMQ = "TOPS_MBFE_BEPS";
            }
            else if ((strstr(argv[2], "ccms")))
            {
                g_strRCVMQ = "TOPS_MBFE_CCMS";
            }            
            else if ((strstr(argv[2], "saps")) || (strstr(argv[2], "nets")) || (strstr(argv[2], "pbcs")))
            {
                g_strRCVMQ = "TOPS_MBFE_SAPS";
            }

        } 
        else if (!strcmp(argv[1], "recv"))
        {
            if ((strstr(argv[2], "beps")) || (strstr(argv[2], "hvps")) || (strstr(argv[2], "ccms")) || (strstr(argv[2], "saps")) || (strstr(argv[2], "nets")) || (strstr(argv[2], "pbcs")))
            {
                gFlag = SECOND_RECV;
            }
            else if((strstr(argv[2], "cmt")) || (strstr(argv[2], "pkg")))
            {
                gFlag = FIRST_RECV;
            }
            else
            {
                printf("文件名没有符合要求,请小写,并用人行的报文用例名称命名");
                exit(0);
            }

            if ((strstr(argv[2], "hvps")) || (strstr(argv[2], "cmt")))//假定CMT全部为大额
            {
                g_strRCVMQ = "RCVPMTS_HVPS";
            }
            else if ((strstr(argv[2], "beps")) || (strstr(argv[2], "pkg")))
            {
                if ((strstr(argv[2], "beps")))
                {
                    gBeps = SECOND_BEPS;
                }
                else
                {
                    gBeps = FIRST_BEPS;
                }
                g_strRCVMQ = "RCVPMTS_BEPS";
            }
            else if ((strstr(argv[2], "ccms")))
            {
                g_strRCVMQ = "RCVPMTS_CCMS";
            }            
            else if ((strstr(argv[2], "saps")) || (strstr(argv[2], "nets")) || (strstr(argv[2], "pbcs")))
            {
                g_strRCVMQ = "RCVPMTS_SAPS";
            }
        }
        else
        {
            printf("请输入正确的RECV或SEND,如:./stresstest recv beps.121.001.01.xml 100 \n");
            exit(0);
        }
        g_strTestFile = argv[2];
        TestRecv(cAgent);
    }
    catch (...)
    {
        printf("%s\n", strErrMsg.c_str());
    }
    return 0;
}