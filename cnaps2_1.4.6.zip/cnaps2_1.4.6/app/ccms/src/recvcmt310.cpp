/******************************************************************** 
文件名： recvcmt310.cpp
创建人： handongfeng
日  期： 2011-04-28
修改人： 
日  期： 
描  述： 
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvcmt310.h"

using namespace ZFPT;

CRecvCmt310::CRecvCmt310()
{
    m_strMsgTp	  = "CMT310";
}


CRecvCmt310::~CRecvCmt310()
{
	
}

INT32 CRecvCmt310::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt310::Work()");	

	// 解析报文
	unPack(sMsg);

    UpdateOrgnBuss();

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt310::work()");

	return RTN_SUCCESS;
}

INT32 CRecvCmt310::unPack(LPCSTR sMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt310::unPack");	

    int iRet = RTN_FAIL;
    char sMsgId[35 + 1] = { 0 };

    // 报文是否为空
    if (NULL == sMsg || '\0' == sMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");	
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "报文为空");
    }

    // 解析报文
    iRet = m_cmt310.ParseCmt(sMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错,iRet[%d]", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文解析出错");	
    }

    // ���ı�ʶ��/ϵͳ���
    sprintf(sMsgId, "%8s%020s", m_cmt310.sReplydate, m_cmt310.GetHeadMesgID());
	m_strMsgID	=	sMsgId;
    ZFPTLOG.SetLogInfo("1310", sMsgId);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt310::unPack");	

    return RTN_SUCCESS;
}

void CRecvCmt310::UpdateOrgnBuss()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt310::UpdataOrgnBuss()");	
    string strSQL = "";
    
    int i = atoi(m_cmt310.sReplyno);
    memset(m_cmt310.sReplyno, 0x00, sizeof(m_cmt310.sReplyno));
    sprintf(m_cmt310.sReplyno, "%2d", i);
    
	strSQL += "UPDATE HV_SEALERR t SET RSPFLAG = '1',BUSISTATE = 'PR05',PROCSTATE = '31', t.RSPNDATE = '";
    strSQL += m_cmt310.sReplydate;
	strSQL += "', t.QRYRSPNBANK = '";
	strSQL += m_cmt310.sReplybank;
	strSQL += "', t.RSPNMSSNO = '";
	strSQL += m_cmt310.sReplyno;
	strSQL += "', t.RSPNRMK = '";
	strSQL += m_cmt310.sRemark;
	strSQL += "' WHERE t.ORICONSIGDATE = '";
	strSQL += m_cmt310.sOldconsigndate;
    strSQL += "' AND t.ORISENDBANK = '";
	strSQL += m_cmt310.sOldsendbank;
	strSQL += "' AND t.ORITXSSNO = '";
	//strSQL += m_cmt310.sOldconsigndate;
	strSQL += m_cmt310.sOldtxssno;
	strSQL += "' AND t.QRYMSSNO = '";
	strSQL += m_cmt310.sReplyno;
	strSQL += "' ";
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= [%s]", strSQL.c_str());

	SETCTX(m_hvsealerr);
    int iRet = m_hvsealerr.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "修改发送状态失败iRet=[%d], [%s]", iRet, m_hvsealerr.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt310::UpdataOrgnBuss()");	
}
