/******************************************************************** 
文件名： sendcmt327.cpp
创建人： handongfeng
日  期： 2011-04-18
修改人： 
日  期： 
描  述： 小额借记止付往帐327报文处理类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt327.h"

using namespace ZFPT;

CSendCmt327::CSendCmt327(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{
}

CSendCmt327::~CSendCmt327()
{
}

INT32 CSendCmt327::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt327::doWorkSelf");

    // 获取数据
    GetData();

    // 组报文
    CreateNpcMsg();

    // 更新状态
    UpdateState();
    
    // 发送报文
    AddQueue(m_cmt327.m_strCmtmsg.c_str(), m_cmt327.m_strCmtmsg.length());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt327::doWorkSelf"); 
    return 0;
}

int CSendCmt327::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt327::getData");

	SETCTX(m_cBpcstbdpcxlcl);
    
  	m_cBpcstbdpcxlcl.m_instgpty     = m_szSndNO;
  	m_cBpcstbdpcxlcl.m_msgid        = m_szMsgFlagNO;
  	
  	int iRet = m_cBpcstbdpcxlcl.findByPK();

  	if (SQLNOTFOUND == iRet)
	{
		sprintf(m_sErrMsg, "找不到指定业务[%s], [%s], [%d][%s]", 
		    m_szSndNO, m_szMsgFlagNO, iRet, m_cBpcstbdpcxlcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	} 	
	else if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg, "查询汇总表发生错误[%s], [%s], [%d][%s]",
		    m_szSndNO, m_szMsgFlagNO, iRet, m_cBpcstbdpcxlcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}

    if("0" == m_cBpcstbdpcxlcl.m_grpcxlid)
    {
        SETCTX(m_cBpcstbdpcxllist);        
        m_cBpcstbdpcxllist.m_msgid      = m_cBpcstbdpcxlcl.m_msgid;
        m_cBpcstbdpcxllist.m_instgpty   = m_cBpcstbdpcxlcl.m_instgdrctpty;

        string strSQL = "MSGID = '" + m_cBpcstbdpcxlcl.m_msgid + "' and INSTGDRCTPTY = '" + m_cBpcstbdpcxlcl.m_instgdrctpty + "'";
        iRet = m_cBpcstbdpcxllist.find(strSQL);
      	if (SQL_SUCCESS != iRet)
    	{
    		sprintf(m_sErrMsg, "找不到指定业务[%s], [%s], [%d][%s]", m_cBpcstbdpcxllist.m_msgid.c_str(), m_cBpcstbdpcxllist.m_instgpty.c_str(), iRet, m_cBpcstbdpcxllist.GetSqlErr());
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
    		
    		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    	}
    	
		int iRetCode = m_cBpcstbdpcxllist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
		{
    		sprintf(m_sErrMsg, "找不到指定业务[%s], [%s], [%d][%s]", m_cBpcstbdpcxllist.m_msgid.c_str(), m_cBpcstbdpcxllist.m_instgpty.c_str(), iRet, m_cBpcstbdpcxllist.GetSqlErr());
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
    		
    		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);		
		}
	}
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt327::getData"); 
    
	return iRet;
}

INT32 CSendCmt327::CreateNpcMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt327::CreateNpcMsg");
	
    char szOrgConsigdate[8+1]   =   { 0 };
    char cOldtxssno[8 + 1]      =   { 0 };
    
    strncpy(szOrgConsigdate, m_cBpcstbdpcxllist.m_orgnlmsgid.c_str(), sizeof(szOrgConsigdate)-1);
    
    strcpy(m_cmt327.sConsigndate ,	 	m_cBpcstbdpcxlcl.m_consigdate.c_str());       						//委托日期   8n         M
    strcpy(m_cmt327.sOldsendsapbk , 	m_cBpcstbdpcxlcl.m_instgdrctpty.c_str());     						//冲正申请清算行 , 原包发起清算行     12n        M
    strcpy(m_cmt327.sOldsendbank , 		m_cBpcstbdpcxlcl.m_instgpty.c_str());          						//止付申请行 , 原包发起行     12n       O
    strcpy(m_cmt327.sRevctmssno , 		m_szMsgSerial);                                 					//冲正申请序号       8n         M
    strcpy(m_cmt327.sOldrecvsapbk , 	m_cBpcstbdpcxlcl.m_instddrctpty.c_str());     						//止付应答清算行 , 原包接收清算行     12n        M
    strcpy(m_cmt327.sOldrecvbank , 		m_cBpcstbdpcxlcl.m_instdpty.c_str());          						//止付应答行 , 原包接收行     12n        O
    strcpy(m_cmt327.sFlag , 					m_cBpcstbdpcxlcl.m_grpcxlid.c_str());                		  //止付类型           1n         M
    strncpy(m_cmt327.sOldpacktype , 	m_cBpcstbdpcxlcl.m_orgnmsgtp.c_str() + 3, sizeof(m_cmt327.sOldpacktype) - 1);         //原包类型号         3n 	       O
    memcpy(m_cmt327.sOldpackdate , 		m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(), sizeof(m_cmt327.sOldpackdate)-1); 			//原包委托日期       8n         O
    memcpy(m_cmt327.sOldpackno , 			m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str()+8, sizeof(m_cmt327.sOldpackno)-1);   			//原包序号           8n         O    
    strcpy(m_cmt327.sOldtradetpno , 	m_cBpcstbdpcxllist.m_orgnlprtry.c_str());     						//原业务类型号       5n         O  
    
    if(m_cBpcstbdpcxllist.m_orgnlpmtinfid.length() != 0)
    {
    	memcpy(m_cmt327.sOldconsigndate , m_cBpcstbdpcxllist.m_orgnlpmtinfid.c_str(), sizeof(m_cmt327.sOldconsigndate) -1);    //原委托日期        8n          O
    	memcpy(cOldtxssno , m_cBpcstbdpcxllist.m_orgnlpmtinfid.c_str()+8, sizeof(cOldtxssno)-1);                                // 原支付交易序号         NUMBER(8)      O 
    	m_cmt327.iOldtxssno = atoi(cOldtxssno);    
    }
        
    //strcpy(m_cmt327.sTextkey , );           //密押               40x        O                              
    if("0" == m_cBpcstbdpcxlcl.m_grpcxlid)  //单笔时至明细表取附言
    {
        strcpy(m_cmt327.sRemark , m_cBpcstbdpcxllist.m_rmtinf.c_str());            //止付申请附言           60g        O        
    }
    else
    {
        strcpy(m_cmt327.sRemark , m_cBpcstbdpcxlcl.m_rmtinf.c_str());               //止付申请附言           60g        O        
    }
    
    int iRet = m_cmt327.CreateCmt("327",
                           	  m_cBpcstbdpcxlcl.m_instgdrctpty.c_str(),
                           	  m_cBpcstbdpcxlcl.m_instddrctpty.c_str(),
                           	  m_sMesgId.c_str(),
                           	  m_sMesgId.c_str(), 
                           	  m_cBpcstbdpcxlcl.m_workdate.c_str(),
                           	  "0");
    if(0 != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt327::CreateNpcMsg"); 
    return 0;
}

int CSendCmt327::UpdateState(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendCmt327::UpdateDb");

	string strSQL = "";
	
	strSQL += "UPDATE bp_CstBdPCxlCl t SET t.Procstate = '";
    strSQL += PR_HVBP_08;
    strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
    strSQL += "', t.MESGREFID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.STATETIME = sysdate WHERE t.msgid = '";
	strSQL += m_cBpcstbdpcxlcl.m_msgid;
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_cBpcstbdpcxlcl.m_instgdrctpty; 
	strSQL += "'";
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	
    SETCTX(m_cBpcstbdpcxlcl);
	int iRet = m_cBpcstbdpcxlcl.execsql(strSQL.c_str());
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL, "Update failed, sqlcode=[%d]", iRet);
	}
	else if (iRet != SQL_SUCCESS)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "更新表失败[%d][%s]",
		    iRet, m_cBpcstbdpcxlcl.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "更新表失败");
	}
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendCmt327::UpdateDb");
    return RTN_SUCCESS;
}

