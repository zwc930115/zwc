/********************************************************************
�ļ�����send303.cpp
�����ˣ�handongfeng
��  �ڣ�2011.01.14
��  ����
��  ����
Copyright (c) 2009  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendccms303.h"

CSendCcms303::CSendCcms303(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{
}

CSendCcms303::~CSendCcms303()
{
}

void CSendCcms303::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms303::SetDBKey...");
    
    m_Cmfreeinfo.m_sysid = m_szSysFlagNO;
	m_Cmfreeinfo.m_msgid = m_szMsgFlagNO; 
	m_Cmfreeinfo.m_instgindrctpty = m_szSndNO; 
    m_Cmfreeinfo.m_rsflag = "1";
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Cmfreeinfo.m_sysid = %s", m_Cmfreeinfo.m_sysid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Cmfreeinfo.m_msgid = %s", m_Cmfreeinfo.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Cmfreeinfo.m_instgindrctpty = %s", m_Cmfreeinfo.m_instgindrctpty.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms303::SetDBKey...");
    return;
}

void CSendCcms303::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms303::SetData...");
    
	char szSyscd[4+1] = {0};
    m_ccms303.MsgId				= m_szMsgFlagNO;
    int iSysflg = -1;
    int iRet = -1;
    chgSysCd(m_szSysFlagNO,iSysflg);
    
    iRet = GetIsoDateTime(m_dbproc, iSysflg, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }
        
	m_ccms303.CreDtTm			= m_ISODateTime;
	m_ccms303.InstgDrctPty      = m_Cmfreeinfo.m_instgdrctpty;
	m_ccms303.GrpHdrInstgPty	= m_Cmfreeinfo.m_instgindrctpty;
	m_ccms303.InstdDrctPty      = m_Cmfreeinfo.m_instddrctpty;
	m_ccms303.GrpHdrInstdPty	= m_Cmfreeinfo.m_instdindrctpty;
    strcpy(szSyscd,m_Cmfreeinfo.m_syscd.c_str());
    StrUpperCase_ZFPT(szSyscd);
	m_ccms303.SysCd				= szSyscd;
	m_ccms303.Rmk				= m_Cmfreeinfo.m_rmk;
	m_ccms303.MsgCntt		    = m_Cmfreeinfo.m_msgcnt;
	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgFlagNO = %s",m_szMsgFlagNO);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSysFlagNO = %s",m_szSysFlagNO);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgTypeFlag = %s",m_szMsgTypeFlag);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgType = %s",m_szMsgType);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndNO = %s",m_szSndNO);              
    // ���ļ�ͷ
    m_ccms303.CreateXMlHeader(szSyscd,                        \
                                m_Cmfreeinfo.m_wrkdate.c_str(), \
                                m_Cmfreeinfo.m_instgdrctpty.c_str(),\
                                m_Cmfreeinfo.m_instddrctpty.c_str(),\
                                "ccms.303.001.02",              \
                                m_sMesgId.c_str()); 
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms303::SetData...");
    return;
}

int CSendCcms303::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms303::GetData...");
    
    SETCTX(m_Cmfreeinfo);
    SetDBKey();
    int iRet = m_Cmfreeinfo.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��,iRet=%d, %s", iRet, m_Cmfreeinfo.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms303::GetData...");
    return iRet;
}

int CSendCcms303::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms303::UpdateState...");
    
    string strSQL;
	strSQL += "UPDATE cm_freeinfo t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_08;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
    strSQL += "', t.STATETIME = sysdate ";
    
	strSQL += " WHERE t.MSGTP = '";
	strSQL += m_Cmfreeinfo.m_msgtp.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_Cmfreeinfo.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Cmfreeinfo.m_instgindrctpty.c_str(); 									
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    int iRet = m_Cmfreeinfo.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��,iRet=%d, %s", iRet, m_Cmfreeinfo.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms303::UpdateState...");
    return iRet;
}

int CSendCcms303::doWorkSelf()
{
   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms303::doWork...");

	//��ȡҵ��Ҫ��
    int iRet = 0;

    GetData();
    
    SetData();

    iRet = m_ccms303.CreateXml();
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��303����ʧ��,iRet[%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    UpdateState();

    AddQueue(m_ccms303.m_sXMLBuff.c_str(), m_ccms303.m_sXMLBuff.length());

  #if 0
	ccms303 m_ccms3032;
	char szSyscd[4+1] = {0};
    m_ccms3032.MsgId				= m_szMsgFlagNO;
    int iSysflg = -1;
    chgSysCd(m_szSysFlagNO,iSysflg);
    
    iRet = GetIsoDateTime(m_dbproc, iSysflg, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }
        
	m_ccms3032.CreDtTm			= m_ISODateTime;
	m_ccms3032.InstgDrctPty      = "501290000012";
	m_ccms3032.GrpHdrInstgPty	= "501290000012";
	m_ccms3032.InstdDrctPty      = "501290000012";
	m_ccms3032.GrpHdrInstdPty	= "501290000012";
    strcpy(szSyscd,m_Cmfreeinfo.m_syscd.c_str());
    StrUpperCase_ZFPT(szSyscd);
	m_ccms3032.SysCd				= szSyscd;
	m_ccms3032.Rmk				= m_Cmfreeinfo.m_rmk;
	m_ccms3032.MsgCntt		    = m_Cmfreeinfo.m_msgcnt;
	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgFlagNO = %s",m_szMsgFlagNO);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSysFlagNO = %s",m_szSysFlagNO);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgTypeFlag = %s",m_szMsgTypeFlag);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgType = %s",m_szMsgType);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndNO = %s",m_szSndNO);              
    // ���ļ�ͷ
    m_ccms3032.CreateXMlHeader(szSyscd,                        \
                                m_Cmfreeinfo.m_wrkdate.c_str(), \
                                m_Cmfreeinfo.m_instgdrctpty.c_str(),\
                                m_Cmfreeinfo.m_instddrctpty.c_str(),\
                                "ccms.303.001.02",              \
                                m_sMesgId.c_str()); 


    iRet = m_ccms3032.CreateXml();
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��303����ʧ��,iRet[%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    

    AddQueue(m_ccms3032.m_sXMLBuff.c_str(), m_ccms3032.m_sXMLBuff.length());
    #endif
    return RTN_SUCCESS;
}


