/******************************************************************** 
�ļ����� sendcmt303.cpp
�����ˣ� hq
��  �ڣ� 2011-07-01
�޸��ˣ� 
��  �ڣ� 
��  ���� CMT303���ɸ�ʽ���˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt303.h"

using namespace ZFPT;

CSendCmt303::CSendCmt303(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{
}

CSendCmt303::~CSendCmt303()
{
}

int CSendCmt303::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt303::doWork...");

    // ��ȡҵ��Ҫ��
    GetData();

    // �鱨��
    CreateNpcMsg();

    // �޸�״̬
    UpdateState();

    // ���ͱ���
    AddQueue(m_cmt303.m_strCmtmsg, m_cmt303.m_strCmtmsg.length());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt303::doWork..."); 
    return RTN_SUCCESS;
}

int CSendCmt303::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt303::GetData...");
    
    SETCTX(m_Cmfreeinfo);
    SetDBKey();
    int iRet = m_Cmfreeinfo.findByPK();
    if( RTN_SUCCESS != iRet )
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��[%d][%s]",
            iRet, m_Cmfreeinfo.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND, "��ȡ����ʧ��");
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt303::GetData...");
    return iRet;
}

void CSendCmt303::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt303::SetDBKey...");
    
    m_Cmfreeinfo.m_sysid        = m_szSysFlagNO;
	m_Cmfreeinfo.m_msgid        = m_szMsgFlagNO; 
	m_Cmfreeinfo.m_instgindrctpty = m_szSndNO; 
    m_Cmfreeinfo.m_rsflag       = "1";
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Cmfreeinfo.m_sysid = %s", m_Cmfreeinfo.m_sysid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Cmfreeinfo.m_msgid = %s", m_Cmfreeinfo.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Cmfreeinfo.m_instgindrctpty = %s", m_Cmfreeinfo.m_instgindrctpty.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt303::SetDBKey...");
}

void CSendCmt303::CreateNpcMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt303::CreateNpcMsg...");

    char SndCCPCNode[4 + 1] = {0};	
	char RcvCCPCNode[4 + 1] = {0};
	int  iSysCd = 1;
	int  iRet   = -1;
	
    strncpy(m_cmt303.sConsigndate, m_Cmfreeinfo.m_consigndate.c_str(),    sizeof(m_cmt303.sConsigndate) - 1);
    strncpy(m_cmt303.sSendbank,    m_Cmfreeinfo.m_instgindrctpty.c_str(), sizeof(m_cmt303.sSendbank) - 1);
    strncpy(m_cmt303.sSendsapbk,   m_Cmfreeinfo.m_instgdrctpty.c_str(),   sizeof(m_cmt303.sSendsapbk) - 1);
    strncpy(m_cmt303.sRecvbank,    m_Cmfreeinfo.m_instdindrctpty.c_str(), sizeof(m_cmt303.sRecvbank) - 1);
    strncpy(m_cmt303.sRecvsapbk,   m_Cmfreeinfo.m_instddrctpty.c_str(),   sizeof(m_cmt303.sRecvsapbk) - 1);
    strncpy(m_cmt303.sRemark,      m_Cmfreeinfo.m_msgcnt.c_str(),         sizeof(m_cmt303.sRemark) - 1);

    GetSapBkToCCPC(m_dbproc, m_cmt303.sSendsapbk, SndCCPCNode);
	GetSapBkToCCPC(m_dbproc, m_cmt303.sRecvsapbk, RcvCCPCNode);

	strncpy(m_cmt303.sSendcenter,  SndCCPCNode,                           sizeof(m_cmt303.sSendcenter) - 1);
	strncpy(m_cmt303.sRecvcenter,  RcvCCPCNode,                           sizeof(m_cmt303.sRecvcenter) - 1);

    chgSysCd(m_Cmfreeinfo.m_syscd.c_str(), iSysCd);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iSysCd[%d]", iSysCd);
    
	iRet = m_cmt303.CreateCmt("303",
                           	  m_cmt303.sSendsapbk,
                           	  m_cmt303.sRecvsapbk,
                           	  m_sMesgId.c_str(),
                           	  m_sMesgId.c_str(), 
                           	  m_Cmfreeinfo.m_wrkdate.c_str(),
                           	  "0",
                           	  iSysCd);
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�鱨��ʧ��,iRet[%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt303::CreateNpcMsg...");
    return;
}

int CSendCmt303::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt303::UpdateState...");
    
    string strSQL;
    
	strSQL += "UPDATE cm_freeinfo t SET t.PROCSTATE = '";
	strSQL += PR_HVBP_08;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
    strSQL += "', t.STATETIME = sysdate ";
    
	strSQL += " WHERE t.MSGTP = '";        // t.rsflag = '1' AND
	strSQL += m_Cmfreeinfo.m_msgtp.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_Cmfreeinfo.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Cmfreeinfo.m_instgindrctpty.c_str(); 									
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	
    int iRet = m_Cmfreeinfo.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��[%d][%s]", 
            iRet, m_Cmfreeinfo.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt303::UpdateState...");
    return iRet;
}


