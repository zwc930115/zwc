/********************************************************************
�ļ�����sendcmt651.cpp
�����ˣ�aps-xcm
��  �ڣ�2011.07.13
��  �����������֧��ҵ���ѯ������
��  ����
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt651.h"

CSendCmt651::CSendCmt651(const stuMsgHead & Smsg):CSendCcmsBase(Smsg)
{

}

CSendCmt651::~CSendCmt651()
{

}


int CSendCmt651::doWorkSelf()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt651::doWorkSelf...");

    GetData();

    SetData();

    buildCmtMsg();

    AddQueue(m_cCmt651.m_strCmtmsg, m_cCmt651.m_strCmtmsg.length());

    UpdateState();

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt651::doWorkSelf...");
    return RTN_SUCCESS;
}


void CSendCmt651::SetDBKey()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt651::SetDBKey...");
    
    m_Cmtransstqry.m_msgid = m_szMsgFlagNO; //���ı�ʶ��
	m_Cmtransstqry.m_instgindrctpty = m_szSndNO; //ԭ����������=����������
    m_Cmtransstqry.m_sysid = m_szSysFlagNO;//ϵͳ��ʶ��

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgFlagNO = %s", m_szMsgFlagNO);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndNO = %s", m_szSndNO);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSysFlagNO = %s", m_szSysFlagNO);

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt651::SetDBKey...");
}


int CSendCmt651::GetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt651::GetData...");

    SETCTX(m_Cmtransstqry);

    SetDBKey();

    int iRet = m_Cmtransstqry.findByPK();

    if(RTN_SUCCESS != iRet)
    {
        sprintf(m_sErrMsg, "findByPK() error, error code[%d], error msg[%s]", iRet, m_Cmtransstqry.GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__,__LINE__,DB_NOT_FOUND,m_sErrMsg);
    }

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt651::GetData...");

    return iRet;
}



void CSendCmt651::SetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt651::SetData...");

    strncpy(m_cCmt651.sConsigndate, m_Cmtransstqry.m_consigndate.c_str(), sizeof(m_cCmt651.sConsigndate) -1);
    Trace(L_INFO, __FILE__, __LINE__, NULL, "m_cCmt651.sConsigndate[%s]", m_cCmt651.sConsigndate);
    strncpy(m_cCmt651.sQuerybank, m_Cmtransstqry.m_instgdrctpty.c_str(), sizeof(m_cCmt651.sQuerybank) - 1);//��ѯ���к� = ������
    Trace(L_INFO, __FILE__, __LINE__, NULL, "m_cCmt651.sQuerybank[%s]", m_cCmt651.sQuerybank);
    strncpy(m_cCmt651.sOldsendbk, m_Cmtransstqry.m_rptid.c_str(), sizeof(m_cCmt651.sOldsendbk) -1);//ԭ������ = ��ѯԭҵ��ķ����������� 
    Trace(L_INFO, __FILE__, __LINE__, NULL, "m_cCmt651.sOldsendbk[%s]", m_cCmt651.sOldsendbk);
    string strTemp;
    strTemp = m_Cmtransstqry.m_rptmsgid.substr(0, 8);
    strncpy(m_cCmt651.sOldconsigndate, strTemp.c_str(), sizeof(m_cCmt651.sOldconsigndate) - 1);
    Trace(L_INFO, __FILE__, __LINE__, NULL, "m_cCmt651.sOldconsigndate[%s]", m_cCmt651.sOldconsigndate);
    strTemp.erase();
    strTemp = m_Cmtransstqry.m_rptmsgid.substr(8, 8);
    m_cCmt651.iOldtxssno = atoi(strTemp.c_str());
    Trace(L_INFO, __FILE__, __LINE__, NULL, "m_cCmt651.iOldtxssno[%d]",m_cCmt651.iOldtxssno);
    strcpy(m_cCmt651.sOldtradetype, "1");//ԭ�������� 1:���
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt651::SetData...");
}


int CSendCmt651::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt651::buildCmtMsg...");

    int iRet = m_cCmt651.CreateCmt("651", m_szSndNO, m_Cmtransstqry.m_instddrctpty.c_str(), m_sMesgId.c_str(), m_sMesgId.c_str(), m_Cmtransstqry.m_wrkdate.c_str(), "1");//ҵ�����ȼ��� һ��ҵ��
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt651::buildCmtMsg...");
    
    return iRet;
}



int CSendCmt651::UpdateState()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt651::UpdateState...");

    string strSQL;

    strSQL += "UPDATE CM_TRANSSTQRY t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_08;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
    strSQL += "', t.STATETIME = sysdate ";
    
	strSQL += " WHERE t.SYSID = '";
	strSQL += m_szSysFlagNO;
    strSQL += "' AND t.MSGID = '";
	strSQL += m_Cmtransstqry.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Cmtransstqry.m_instgindrctpty.c_str(); 									
	strSQL += "'";
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());

    int iRet = m_Cmtransstqry.execsql(strSQL.c_str());

    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "����ʧ��iRet[%d][%s]", iRet, m_Cmtransstqry.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt651::UpdateState...");

    return iRet;
    
}


