/******************************************************************** 
文件名： sendcmt309.cpp
创建人： aps-xcm
日  期： 2011-06-23
修改人： 
日  期： 
描  述： 一代大额往账银行汇票支付报文
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt309.h"

using namespace ZFPT;

CSendCmt309::CSendCmt309(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{
   
}

CSendCmt309::~CSendCmt309()
{
    
}

int CSendCmt309::doWorkSelf()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt309::doworkSelf...");
    //1)获得数据
    GetData();
    
    //2)赋值
    SetData();
    
    buildCmtMsg();

    UpdateState();
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt309::doworkSelf...");
    return RTN_SUCCESS;
}

int CSendCmt309::GetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt309::GetData...");
    char szOriConsigdate[8 + 1]   = { 0 };
	char szOriTxssno[8 + 1]   = { 0 };
	char szQryNo[2 + 1]   = { 0 };
    
    memcpy(szOriConsigdate, m_szMsgFlagNO, 8);
    memcpy(szOriTxssno, m_szMsgFlagNO+8, 8);
    memcpy(szQryNo, m_szMsgFlagNO+16, 2);

    
    SETCTX(m_Hvsealerr);
    
    m_Hvsealerr.m_qrydate   = szOriConsigdate;
    m_Hvsealerr.m_qrybank   = m_szSndNO;
    m_Hvsealerr.m_qryno   = szOriConsigdate;
    m_Hvsealerr.m_qryno   += szOriTxssno;
    //m_Hvsealerr.m_qrymssno     = atoi(szQryNo);
  
 
    Trace(L_INFO, __FILE__, __LINE__, NULL, "m_qrydate=[%s]", m_Hvsealerr.m_qrydate.c_str());
    Trace(L_INFO, __FILE__, __LINE__, NULL, "m_qrybank=[%s]", m_Hvsealerr.m_qrybank.c_str());
    Trace(L_INFO, __FILE__, __LINE__, NULL, "m_qryno=[%s]", m_Hvsealerr.m_qryno.c_str());
    //Trace(L_INFO, __FILE__, __LINE__, NULL, "m_qrymssno=[%d]", m_Hvsealerr.m_qrymssno); 

    int iRet = m_Hvsealerr.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "获取数据失败, iRet = [%d]", iRet);
        PMTS_ThrowException(DB_NOT_FOUND);
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt309::GetData...");
    return iRet;
    
}

void CSendCmt309::SetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt309::SetData...");
    char temp[2 + 1] = { 0 };
    
    strncpy(m_cCmt309.sQuerydate, m_Hvsealerr.m_qrydate.c_str(), sizeof(m_cCmt309.sQuerydate) - 1);
    strncpy(m_cCmt309.sQuerybank, m_Hvsealerr.m_qrybank.c_str(), sizeof(m_cCmt309.sQuerybank) - 1);
    strncpy(m_cCmt309.sReplybank, m_Hvsealerr.m_qryrspnbank.c_str(), sizeof(m_cCmt309.sReplybank)-1);
    strncpy(m_cCmt309.sOldconsigndate, m_Hvsealerr.m_oriconsigdate.c_str(), sizeof(m_cCmt309.sOldconsigndate) - 1);
    strncpy(m_cCmt309.sOldsendbank, m_Hvsealerr.m_orisendbank.c_str(), sizeof(m_cCmt309.sOldsendbank) - 1);
    strncpy(m_cCmt309.sOldtradetype, m_Hvsealerr.m_oritrantype.c_str(), sizeof(m_cCmt309.sOldtradetype) - 1);
    strncpy(m_cCmt309.sOldtxssno, m_Hvsealerr.m_oritxssno.c_str(), sizeof(m_cCmt309.sOldtxssno) - 1);
    strncpy(m_cCmt309.sOldcur, m_Hvsealerr.m_oricur.c_str(), sizeof(m_cCmt309.sOldcur) - 1);
	m_cCmt309.dOldamount = m_Hvsealerr.m_oriamont;
	sprintf(temp,"%02d",m_Hvsealerr.m_qrymssno);
    strncpy(m_cCmt309.sQueryno,temp,sizeof(m_cCmt309.sQueryno)-1);
	strncpy(m_cCmt309.sReplyflg, m_Hvsealerr.m_returnflag.c_str(),sizeof(m_cCmt309.sReplyflg)-1);
    strncpy(m_cCmt309.sRemark, m_Hvsealerr.m_qryrmk.c_str(), sizeof(m_cCmt309.sRemark) - 1);
 
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt309::SetData..."); 
}

int CSendCmt309::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt309::buildCmtMsg...");

    int iRet = m_cCmt309.CreateCmt("309",  
                                m_Hvsealerr.m_qrybank.c_str(), 
                                m_Hvsealerr.m_qryrspnbank.c_str(), 
                                m_sMesgId.c_str(), 
                                m_sMesgId.c_str(), 
                                m_Hvsealerr.m_qrydate.c_str(), 
                                "0");
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    AddQueue(m_cCmt309.m_strCmtmsg, m_cCmt309.m_strCmtmsg.length());
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt309::buildCmtMsg...");
    return iRet;
}
int CSendCmt309::UpdateState()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt309::UpdateState...");
    char temp[3] = { 0 };
    
    SETCTX(m_Hvsealerr);
    
    string strSQL = "";
    strSQL += "UPDATE HV_SEALERR t SET t.PROCSTATE = '";
	strSQL += PR_HVBP_08;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
    strSQL += "', t.STATETIME = sysdate ";
    
	strSQL += " WHERE t.ORICONSIGDATE = '";
	strSQL += m_Hvsealerr.m_oriconsigdate.c_str();
    strSQL += "' AND t.ORISENDBANK = '";
	strSQL += m_Hvsealerr.m_orisendbank.c_str();
    strSQL += "' AND t.ORITXSSNO = '";
	strSQL += m_Hvsealerr.m_oritxssno.c_str();
	strSQL += "' AND t.QRYMSSNO = ";
	strSQL += m_cCmt309.sQueryno;
	strSQL += " ";
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "strSQL=[%s]", strSQL.c_str());
    
    int iRet = m_Hvsealerr.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
                "修改发送状态失败iRet=[%d], [%s]", iRet, m_Hvsealerr.GetSqlErr());
        
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt309::UpdateState...");
    return iRet;
}


