/******************************************************************** 
�ļ����� recvccms807.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-03-03
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvccms807.h"


CRecvCcms807::CRecvCcms807()
{
	
}


CRecvCcms807::~CRecvCcms807()
{
	
}

INT32 CRecvCcms807::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms807::Work()");

	//1����������
	unPack(sMsg);

    UpdataState();
    
	//2����Ա��ֵ
	//SetData(sMsg);

	//3���������ɸ�ʽ��  ����ſ���Ҫ���в������ by modify zql 2012 -6-21
	InsertData();
	

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms807::work()");

	return RTN_SUCCESS;
}


INT32 CRecvCcms807::unPack(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms807::unPack");	

	int iRet = RTN_FAIL;

	//1�������Ƿ�Ϊ��
	if (NULL == sMsg || '\0' == sMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
	}
	
    m_strMsgTp	=	"ccms.807.001.02";
	//3����������
	iRet = m_cParser807.ParseXml(sMsg);
	if (RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= %d", iRet);	
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
	}

    ZFPTLOG.SetLogInfo("807", m_cParser807.MsgId.c_str());
    
    //����д�����ļ�����
	m_strMsgID	=	m_cParser807.MsgId;
	
	//4����ȡ��������
	iRet = GetWorkDate(m_dbproc, m_sWorkDate,
			SYS_HVPS, m_cParser807.InstdDrctPty.c_str());
    if(iRet != RTN_SUCCESS)
    {
         Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
         PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;      
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms807::unPack");	

	return RTN_SUCCESS;
}

/*INT32 CRecvCcms807::GetParserObj(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms807::GetParserObj");

	char	sMsgTp[35 + 1];
	memset(sMsgTp, 0x00, sizeof(sMsgTp));
	
	// �ж��ǵڼ�������
	m_iMsgVer = JudgeMsgVer(sMsg);
	if (MSG_VER_2ND == m_iMsgVer)
	{
		// ��������
		m_cParser807.Init(MSG_VER_2ND, 807);
		m_strMsgTp	=	"ccms.807.001.02";
	}
	else if (MSG_VER_1ST == m_iMsgVer)
	{
		// һ������
		int iMsgCode = GetMsgCode(sMsg);
		if (HV_1ST_FAIL != iMsgCode)
		{
			m_cParser807.Init(MSG_VER_1ST, iMsgCode);
			
			sprintf(sMsgTp, "CMT%d", iMsgCode);
			m_strMsgTp	=	sMsgTp;
		}
		else
		{
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "GetMsgCode error:%d", iMsgCode);
			return RTN_FAIL;
		}
	}
	else
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "JudgeMsgVer iVer=[%d]", m_iMsgVer);
		return RTN_FAIL;
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms807::GetParserObj");

	return RTN_SUCCESS;
}*/

INT32 CRecvCcms807::UpdataState()
{    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms807::UpdataState");
	
    SETCTX(m_Hvsapbankinfo);
     SETCTX(m_Bpsapbankinfo);
    string strSQL = "";
   if(!STRNCASECMP(m_cParser807.SysCd.c_str(), "HVPS", 4))
	{
	    strSQL = "";
		strSQL += "UPDATE hv_sapbankinfo t SET ";
		strSQL += "t.chgstate = '03'";//���˳�
		strSQL += " WHERE t.sapbank = '";
		strSQL += m_cParser807.InstdDrctPty.c_str();								
		strSQL += "'";
		
	    Trace(L_INFO, __FILE__, __LINE__, NULL, "strSQl=%s", strSQL.c_str());
	 	int iRet = m_Hvsapbankinfo.execsql(strSQL.c_str());
		if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "CRecvCcms807::UpdateSate():�޸ı�����ʧ��!iRet=[%d], %s", iRet,m_Hvsapbankinfo.GetSqlErr() );
			
			Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
	
	        PMTS_ThrowException(__FILE__, __LINE__,  DB_UPDATE_FAIL, m_szErrMsg); 
		}
	        	
	}
    else if(!STRNCASECMP(m_cParser807.SysCd.c_str(), "BEPS", 4))
    {
        strSQL = "";
    	strSQL += "UPDATE bp_sapbankinfo t SET ";
    	strSQL += "t.chgstate = '03'"; //���˳�
    	strSQL += " WHERE t.sapbank = '";
    	strSQL += m_cParser807.InstdDrctPty.c_str();								
    	strSQL += "'";
    	
        Trace(L_INFO, __FILE__, __LINE__, NULL, "strSQl=%s", strSQL.c_str());
     	int iRet = m_Bpsapbankinfo.execsql(strSQL.c_str());
		if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "CRecvCcms807::UpdateSate():�޸ı�����ʧ��!iRet=[%d], %s", iRet,m_Bpsapbankinfo.GetSqlErr() );
			
			Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);

	        PMTS_ThrowException(__FILE__, __LINE__,  DB_UPDATE_FAIL, m_szErrMsg); 
		}
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms807::UpdataState");	
	return RTN_SUCCESS;
}

INT32 CRecvCcms807::SetData(LPCSTR pchMsg)
{    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms807::SetData");	


	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms807::SetData");	

	return RTN_SUCCESS;
}

INT32 CRecvCcms807::InsertData(void)
{	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms807::InsertData");
	oCmlogon.m_workdate = m_strWorkDate;
	oCmlogon.m_sysid    = m_cParser807.SysCd;
	oCmlogon.m_msgid    = m_cParser807.MsgId;
	oCmlogon.m_instgdrctpty = m_cParser807.InstgDrctPty;
	oCmlogon.m_instddrctpty =m_cParser807.InstdDrctPty;
	SETCTX(oCmlogon);
	int iRet = oCmlogon.insert();
	if(0!= iRet)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL, "����CM_LOGON��ʧ��!");
		//PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "����CM_LOGON��ʧ��");
	}
	
	return RTN_SUCCESS;
}
	
