/********************************************************************
文件名：recvccmswork.cpp
创建人：zhj
日  期：2011-03-03
修改人：
日  期：
描  述：ccms来帐线程工作类
版  本：
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif


#include "pubfunc.h"
#include "logger.h"
#include "recvccmswork.h"
#include "cmrecvmsg.h"
#include "recvccmsbase.h"
#include "recvccms303.h"
#include "recvccms314.h"
#include "recvccms315.h"
#include "recvccms308.h"
#include "recvccms310.h"
#include "recvccms311.h"
#include "recvccms312.h"
#include "recvccms313.h"
#include "recvccms317.h"
#include "recvccms318.h"
#include "recvccms319.h"
#include "recvccms806.h"
#include "recvccms807.h"
#include "recvccms809.h"
#include "recvccms913.h"
#include "recvccms915.h"
#include "recvccms916.h"
#include "recvccms917.h"
#include "recvccms921.h"
#include "recvccms926.h"
#include "recvccms900.h"
#include "recvccms903.h"
#include "recvccms906.h"
#include "recvccms907.h"
#include "recvccms801.h"
#include "recvccms803.h"
#include "recvccms911.h"
#include "recvccms990.h"
#include "recvccms992.h"
#include "recvcmt301.h"
#include "recvcmt302.h"
#include "recvcmt303.h"
#include "recvcmt310.h"
#include "recvcmt312.h"
#include "recvcmt322.h"
#include "recvcmt920.h"
#include "recvcmt313.h"
#include "recvcmt314.h"
#include "recvcmt319.h"
#include "recvcmt320.h"
#include "recvcmt681.h"
#include "recvcmt910.h"
#include "recvcmt911.h"
#include "recvcmt920.h"
#include "recvcmt327.h"
#include "recvcmt328.h"

using namespace ZFPT;

extern CConnectPool *g_DBConnPool;
extern int		g_IsConnPlatm;

CRecvCcmsWork::CRecvCcmsWork()
{
	m_sTrsCode = "";
    m_sMsgFile = "";
    m_strMsgID = "";		
}

CRecvCcmsWork::~CRecvCcmsWork()
{	
}

void CRecvCcmsWork::setData(LPTSTR lpMsgID, int iErrMsgFlag, UINT32 len, LPCSTR data, LPCSTR lpTrsCode, LPCSTR lpMsgFile)
{
    
    if(NULL != data && 0 != len)
    {
        m_vData.resize(len + 1, 0);
    
        memset(&m_vData[0], 0, len * sizeof(char));
        memcpy(&m_vData[0], data, len);
    }
    
    if(lpTrsCode != NULL)
    {
        m_sTrsCode = lpTrsCode;
    }
    
    if(lpMsgFile != NULL)
    {
        m_sMsgFile = lpMsgFile;
    }
    
    if (NULL != lpMsgID)
    {
        m_strMsgID = lpMsgID;
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgID = %s", m_strMsgID.c_str());	
    }

    m_iErrMsgFlag = iErrMsgFlag;
}

void CRecvCcmsWork::clear()
{
	
}

INT32 CRecvCcmsWork::doWork()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcmsWork::doWork()");	

    // 大报文消息没传过来，需要从来帐通讯表取消息
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_vData.size() = %d", m_vData.size());	

	int iRet        = -1;
	int iBizCode	= -1; 
	int iVersion	= -1;

// 	if (0 == m_vData.size()) //当报文长度大于2000时,work从表里取;小于2000时,通过setdata设置
//     {
//         Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "0 == m_vData.size()");	
// 
// 		iRet = GetMsg();
//         if (0 != iRet)
//         {
//             Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "来帐通迅表取消息失败");
//             return RTN_FAIL;
//         }
// 
//         Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "GetMsg() success");	
//     }   
    

		//取业务码   
	    iBizCode = GetBizCode(&m_vData[0], iVersion);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iBizCode = %d", iBizCode);
    
    char szchBizCode[4 + 1] = {0};  // 业务码
    sprintf(szchBizCode, "%d", iBizCode);

	CRecvCcmsBase *PRecvCcms = NULL;
		
    switch( iBizCode )
    {
        case HV_2ND_303:
        {
            PRecvCcms = new CRecvCcms303;
            break;
        }
        case HV_2ND_314:
        {
            PRecvCcms = new CRecvCcms314;
            break;
        }
        case HV_2ND_315:
        {
            PRecvCcms = new CRecvCcms315;
            break;
        }
        case CM_2ND_801:
        {
            PRecvCcms = new CRecvCcms801;
            break;
        }
        case CM_2ND_803:
        {
            PRecvCcms = new CRecvCcms803;
            break;
        }
        case CM_2ND_308:
        {
            PRecvCcms = new CRecvCcms308;
            break;
        }
        case CM_2ND_310:
        {
            PRecvCcms = new CRecvCcms310;
            break;
        }
        case CM_2ND_311:
        {
            PRecvCcms = new CRecvCcms311;
            break;
        }
        case CM_2ND_312:
        {
            PRecvCcms = new CRecvCcms312;
            break;
        }
        case CM_2ND_313:
        {
            PRecvCcms = new CRecvCcms313;
            break;
        }
        case CM_2ND_317:
        {
            PRecvCcms = new CRecvCcms317;
            break;
        }
        case CM_2ND_318:
        {
            PRecvCcms = new CRecvCcms318;
            break;
        }
        case CM_2ND_319:
        {
            PRecvCcms = new CRecvCcms319;
            break;
        }
        case CM_1ST_320:
        {
            PRecvCcms = new CRecvCmt320;
            break;
        }
        case CM_1ST_327:
        {
            PRecvCcms = new CRecvCmt327;
            break;
        }
        case CM_1ST_328:
        {
            PRecvCcms = new CRecvCmt328;
            break;
        }    
         case CM_2ND_806:
        {
            PRecvCcms = new CRecvCcms806;
            break;
        }
         case CM_2ND_807:
        {
            PRecvCcms = new CRecvCcms807;
            break;
        }
         case CM_2ND_809:
        {
            PRecvCcms = new CRecvCcms809;
            break;
        } 
         case CM_2ND_913:
        {
            PRecvCcms = new CRecvCcms913;
            break;
        }
         case CM_2ND_915:
        {
            PRecvCcms = new CRecvCcms915;
            break;
        }
         case CM_2ND_916:
        {
            PRecvCcms = new CRecvCcms916;
            break;
        } 
         case CM_2ND_917:
        {
            PRecvCcms = new CRecvCcms917;
            break;
        }
         case CM_2ND_921:
        {
            PRecvCcms = new CRecvCcms921;
            break;
        }
         case CM_2ND_926:
        {
            PRecvCcms = new CRecvCcms926;
            break;
        }        
        case CM_2ND_900:
        {
            PRecvCcms = new CRecvCcms900;
            break;
        }
        case CM_2ND_903:
        {
            PRecvCcms = new CRecvCcms903;
            break;
        }
        case CM_2ND_906:
        {
            PRecvCcms = new CRecvCcms906;
            break;
        }
        case CM_2ND_907:
        {
            PRecvCcms = new CRecvCcms907;
            break;
        }
        case CM_2ND_911:
        {
            PRecvCcms = new CRecvCcms911;
            break;
        }
        case CM_2ND_990:
        {
            PRecvCcms = new CRecvCcms990;
            break;
        }
        case 922:
        {
            PRecvCcms = new CRecvCcms992;
            break;
        }        
        case CM_1ST_303:
        {
            PRecvCcms = new CRecvCmt303;
            break;
        }
        case CM_1ST_301:
        {
            PRecvCcms = new CRecvCmt301;
            break;
        }
        case CM_1ST_302:
        {
            PRecvCcms = new CRecvCmt302;
            break;
        }
        case 1310:
        {
            PRecvCcms = new CRecvCmt310;
            break;
        }
        case CM_1ST_312:
        {
            PRecvCcms = new CRecvCmt312;
            break;
        }
        case CM_1ST_313:
        {   
            PRecvCcms = new CRecvCmt313;
            break;    
        }
        case CM_1ST_314:
        {   
            PRecvCcms = new CRecvCmt314;
            break;    
        }
        case CM_1ST_319:
        {   
            PRecvCcms = new CRecvCmt319;
            break;    
        }        
        case CM_1ST_322:
        {
            PRecvCcms = new CRecvCmt322;
            break;
        }
        case CM_1ST_681:
        {
            PRecvCcms = new CRecvCmt681;
            break;
        }
        case CM_1ST_910:
        {
            PRecvCcms = new CRecvCmt910;
            break;
        }       
		case CM_1ST_911:
        {
            PRecvCcms = new CRecvCmt911;
            break;
        }       
		case CM_1ST_920:
        {
            PRecvCcms = new CRecvCmt920;
            break;
        }     
		case 992:
        {
            PRecvCcms = new CRecvCcms992;
            break;
        }           
        default:
            return RTN_FAIL;
    }

	PRecvCcms->m_strBizCode  = szchBizCode;
	PRecvCcms->m_strRcvMsgID = m_strMsgID;
    PRecvCcms->m_iErrMsgFlag = m_iErrMsgFlag;
    PRecvCcms->m_iMsgVer	 = iVersion;
    
	ZFPTLOG.SetLogInfo(szchBizCode, NULL);

	PRecvCcms->doWork(&m_vData[0]);
	
	if (NULL != PRecvCcms)
	{
		delete PRecvCcms;
		PRecvCcms = NULL;
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcmsWork::doWork()");

    return RTN_SUCCESS;
}

/******************************************************************************
*  Function:   GetMsg
*  Description:从来帐通讯表取消息
*  Input:	   无
*  Output:	   
*  Return:	   0   : 操作成功,
			   其他: 操作失败
*  Others:	   无
*  Author:	   zys
*  Date:	   2011-02-21
*******************************************************************************/
INT32 CRecvCcmsWork::GetMsg(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcmsWork::GetMsg");	

	int    iRet = RTN_FAIL;
	DBProc cDBProc;

	// 获取数据库连接
	iRet = g_DBConnPool->GetConnect(cDBProc);
	if(0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "GetConnect failed");
		return iRet;	
	}

	CCmrecvmsg cCmrecvmsg;
	iRet= cCmrecvmsg.setctx(cDBProc);
	if (0 != iRet)
	{
		g_DBConnPool->PutConnect(cDBProc);//释放连接
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "cCmrecvmsg.setctx error[%d]", iRet);	
		return iRet;
	}

	cCmrecvmsg.m_msgid  = m_strMsgID;
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_strMsgID = %s", m_strMsgID.c_str());	
	
	// 从来帐通讯表取消息
	iRet = cCmrecvmsg.findByPK();
	if (RTN_SUCCESS == iRet)
	{
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "cCmrecvmsg.findByPK success");	
		m_vData.resize(cCmrecvmsg.m_msgtext.length() + 1, 0);	
		memset(&m_vData[0], 0, cCmrecvmsg.m_msgtext.length() * sizeof(char));
		memcpy(&m_vData[0], cCmrecvmsg.m_msgtext.c_str(), cCmrecvmsg.m_msgtext.length());
	}
	else
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "cCmrecvmsg.findByPKfailed[%d]", iRet);
	}

	//释放连接
	g_DBConnPool->PutConnect(cDBProc);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcmsWork::GetMsg");

	return iRet;
}


