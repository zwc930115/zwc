/******************************************************************** 
�ļ����� recvccms916.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-03-05
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvccms916.h"
CRecvCcms916::CRecvCcms916()
{
    m_strMsgTp = "ccms.916.001.01";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms916::CRecvCcms916()");	
}


CRecvCcms916::~CRecvCcms916()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms916::~CRecvCcms916()");		
}

INT32 CRecvCcms916::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms916::Work()");

	//1����������
	unPack(sMsg);
	
	//2����Ա��ֵ
	SetData(sMsg);
	
					  
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms916::work()");

	return RTN_SUCCESS;
}

INT32 CRecvCcms916::unPack(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms916::unPack");	

	int iRet = RTN_FAIL;

	//1�������Ƿ�Ϊ��
	if (NULL == sMsg || '\0' == sMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
	}

	/*//2����ȡ���������
	if (RTN_SUCCESS != GetParserObj(sMsg))
	{
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRSMSG_FAIL, "��ȡ���������ʧ��");
	}*/

    //m_bkcdchgntfctnlist.m_msgtp = m_cParser916.m_PMTSHeader.getMesgType();
    
	//3����������
	iRet = m_cParser916.ParseXml(sMsg);
	if (RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= %d", iRet);	
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
	}
	
	iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;

    ZFPTLOG.SetLogInfo("916", m_cParser916.MsgId.c_str());
	
	m_strMsgID	=	m_cParser916.MsgId;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms916::unPack");	

	return RTN_SUCCESS;
}


/*INT32 CRecvCcms916::GetParserObj(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms916::GetParserObj");

	// �ж��ǵڼ������� ����ֻ�ж���
	int iVer = JudgeMsgVer(sMsg);
	if (MSG_VER_2ND == iVer)
	{
		// ��������
		m_cParser916.Init(MSG_VER_2ND, 916);
		m_bkcdchgntfctncl.m_msgtp = "ccms.916.001.01";
	}
	else
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "JudgeMsgVer iVer=[%d]", iVer);
		return RTN_FAIL;
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms916::GetParserObj");

	return RTN_SUCCESS;
}*/


INT32 CRecvCcms916::SetData(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms916::SetData");

	char m_sTempDate[8+1];

    m_bkcdchgntfctnlist.m_sysid = m_cParser916.SysCd; 
    m_bkcdchgntfctnlist.m_msgid = m_cParser916.MsgId; 
    m_bkcdchgntfctnlist.m_chngnb = m_cParser916.ChngNb; 
    
    int iNum = m_cParser916.GetNodeCountByName("ChngInf");
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iNum[%d]",iNum);
    for(int i = 0; i < iNum; i++)
    {
		memset(m_sTempDate, 0x00, sizeof(m_sTempDate));
        //��ϸ��
        m_bkcdchgntfctnlist.m_listid = i;
        m_bkcdchgntfctnlist.m_bankcode = m_cParser916.GetValueFromCycle("ChngInf", "BkCd", i); //m_cParser916.BkCd;
        m_bkcdchgntfctnlist.m_bankcatalog = m_cParser916.GetValueFromCycle("ChngInf", "PtcptTp", i); //m_cParser916.PtcptTp;
        m_bkcdchgntfctnlist.m_banktype = m_cParser916.GetValueFromCycle("ChngInf", "BkCtgyCd", i); //m_cParser916.BkCtgyCd;
        m_bkcdchgntfctnlist.m_drctbkcd = m_cParser916.GetValueFromCycle("ChngInf", "DrctBkCd", i); //m_cParser916.DrctBkCd;
        m_bkcdchgntfctnlist.m_lglprsn =m_cParser916.GetValueFromCycle("ChngInf", "LglPrsn", i); // m_cParser916.LglPrsn;
        m_bkcdchgntfctnlist.m_dreccode = m_cParser916.GetValueFromCycle("ChngInf", "HghPtcpt", i); //m_cParser916.HghPtcpt;
        m_bkcdchgntfctnlist.m_sbstitnbk = m_cParser916.GetValueFromCycle("ChngInf", "BrBkCd", i); //m_cParser916.BrBkCd;
        m_bkcdchgntfctnlist.m_pbccode = m_cParser916.GetValueFromCycle("ChngInf", "ChrgBkCd", i); //m_cParser916.ChrgBkCd;
        m_bkcdchgntfctnlist.m_bankcenter = m_cParser916.GetValueFromCycle("ChngInf", "NdCd", i); //m_cParser916.NdCd;
        m_bkcdchgntfctnlist.m_debtorcity = m_cParser916.GetValueFromCycle("ChngInf", "CityCd", i); //m_cParser916.CityCd;
        m_bkcdchgntfctnlist.m_bankname = m_cParser916.GetValueFromCycle("ChngInf", "PtcptNm", i); //m_cParser916.PtcptNm;
        m_bkcdchgntfctnlist.m_syscode = m_cParser916.GetValueFromCycle("ChngInf", "Sgn", i); //m_cParser916.Sgn;
        m_bkcdchgntfctnlist.m_tel = m_cParser916.GetValueFromCycle("ChngInf", "Tel", i); //m_cParser916.Tel;
        m_bkcdchgntfctnlist.m_chngtp = m_cParser916.GetValueFromCycle("ChngInf", "ChngTp", i);//m_cParser916.ChngTp;
        m_bkcdchgntfctnlist.m_fctvtp = m_cParser916.GetValueFromCycle("ChngInf", "FctvTp", i); //m_cParser916.FctvTp;

        m_bkcdchgntfctnlist.m_fctvdt = m_cParser916.GetValueFromCycle("ChngInf", "FctvDt", i); //m_cParser916.fctvdt;//��Ч����
		chgToDate(m_bkcdchgntfctnlist.m_fctvdt.c_str()	, m_sTempDate);
		m_bkcdchgntfctnlist.m_fctvdt = m_sTempDate;

		memset(m_sTempDate, 0x00, sizeof(m_sTempDate));
        m_bkcdchgntfctnlist.m_ifctvdt = m_cParser916.GetValueFromCycle("ChngInf", "IfctvDt", i); //m_cParser916.ifctvdt;//ʧЧ����     
		chgToDate(m_bkcdchgntfctnlist.m_ifctvdt.c_str()	, m_sTempDate);
		m_bkcdchgntfctnlist.m_ifctvdt = m_sTempDate;

        m_bkcdchgntfctnlist.m_procstate = "34"; //��Ϊ������д�˶�Ϊ��ʱ����,��������дδ��Ч
        m_bkcdchgntfctnlist.m_msgid = m_cParser916.MsgId;
                
        /*
        CC00������
        CC01�����
        CC02������
        EF00��������Ч
        EF01��ָ��������Ч
        */
        int iRet = 0;

        iRet = InsertData();
        if(OPERACT_SUCCESS != iRet)
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "�����ʧ��iRet=%d, %s", iRet , m_bkcdchgntfctnlist.GetSqlErr());
            PMTS_ThrowException(DB_INSERT_FAIL);
        }
    }    
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCcms916::SetData");
	return RTN_SUCCESS;
}

//�����ϸ ���ܱ��͹�ϵ����ִ�в������
INT32 CRecvCcms916::InsertData(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms916::InsertData");
	
	int iRet = RTN_FAIL;
	
	/*SETCTX(m_bkcdchgntfctncl);
    iRet = m_bkcdchgntfctncl.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "����cm_bkcdchgntfctncl��ʧ��, iRet=%d, %s", iRet , m_bkcdchgntfctncl.GetSqlErr());
        PMTS_ThrowException(DB_INSERT_FAIL);
    }*/
    
    SETCTX(m_bkcdchgntfctnlist);
    
	iRet = m_bkcdchgntfctnlist.remove();
	if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
		    "ɾ��cm_bkcdchgntfctnlist��ʧ��[%d][%s]", iRet, m_bkcdchgntfctnlist.GetSqlErr());

		PMTS_ThrowException(__FILE__, __LINE__, DB_DEL_FAIL, "ɾ��cm_bkcdchgntfctnlist��ʧ��"); 
	}
	
    iRet = m_bkcdchgntfctnlist.insert();
    if(SQL_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "����cm_bkcdchgntfctnlist��ʧ��, iRet=%d, %s", iRet , m_bkcdchgntfctnlist.GetSqlErr());
        PMTS_ThrowException(DB_INSERT_FAIL);            
    }

    /*SETCTX_INT(m_bankinfo);
    iRet = m_bankinfo.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "����cisagent��ʧ��, iRet=%d", iRet);
        return iRet;            
    }*/
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms916::InsertData");
	
	return RTN_SUCCESS;
}

/*************************************************
//��Чʱ�䵽ʱ���õ�
//�����ϸ ���ܱ�ִ�в������,��ϵ��ִ�и��²���
INT32 CRecvCcms916::UpdateState(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms916::UpdateState");

	SETCTX_INT(m_bkcdchgntfctncl);
    int iRet = m_bkcdchgntfctncl.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "�����ʧ��, iRet=%d", iRet);
        return iRet;
    }
    
    SETCTX_INT(m_bkcdchgntfctnlist);
    int iRet = m_bkcdchgntfctnlist.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "��������ʧ��, iRet=%d", iRet);
        return iRet;            
    }

    SETCTX_INT(m_bankinfo);
    string strSQL;
	strSQL += "UPDATE cm_bankinfo t SET ";
	strSQL += "' t.BBNKCODE = '";
    strSQL += m_bankinfo.m_bbnkcode;
	strSQL += "' t.PROCSTATE = '";
	strSQL += m_bankinfo.m_procstate;   //��Ϊ������д�˶�Ϊ��ʱ����,��������дδ��Ч
	strSQL += "' t.PROCTIME = '";
    strSQL += m_bankinfo.m_proctime;              //���ݿ�������洢����ʵ��,����д�ϵ�ǰ�Ĺ���ʱ��
    strSQL += "' ";
    
	strSQL += " WHERE t.BANKCODE = '";
	strSQL += m_bankinfo.m_bankcode;
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	
    iRet = m_bankinfo.execsql(strSQL.c_str());
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "���±�ʧ��, iRet=%d", iRet);
        return iRet;            
    }
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms916::UpdateState");

	return RTN_SUCCESS;
}
*******************************/


