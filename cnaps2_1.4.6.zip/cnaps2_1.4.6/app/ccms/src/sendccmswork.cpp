/********************************************************************
文件名：sendcmwork.cpp
创建人：zhj
日  期：2011-03-03
修改人：
日  期：
描  述：ccms往帐线程工作类
版  本：
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif


#include "sendccmswork.h"
#include "tsocket.h"
#include "exception.h"
#include "sendccms303.h"
#include "sendccms307.h"
#include "sendccms314.h"
#include "sendccms315.h"
#include "sendccms310.h"
#include "sendccms311.h"
#include "sendccms312.h"
#include "sendccms313.h"
#include "sendccms316.h"
#include "sendccms318.h"
#include "sendccms319.h"
#include "sendccms805.h"
#include "sendccms903.h"
#include "sendccms919.h"
#include "sendcmt301.h"
#include "sendcmt302.h"
#include "sendcmt303.h"
#include "sendcmt309.h"
#include "sendcmt313.h"
#include "sendcmt314.h"
#include "sendcmt311.h"
#include "sendcmt319.h"
#include "sendcmt320.h"
#include "sendcmt321.h"
#include "sendcmt519.h"
#include "sendcmt651.h"
#include "sendcmt327.h"
#include "sendcmt328.h"

using namespace ZFPT;

CSendCcmsWork::CSendCcmsWork()
{
	ClientSocket	= INVALID_SOCKET;
	m_sTrsCode		= "";
    memset(&m_MsgHead, 0x00, sizeof(m_MsgHead));
}

CSendCcmsWork::CSendCcmsWork(const CSendCcmsWork &e)
{
    if(this != &e)
    {
        m_sTrsCode = e.m_sTrsCode;
        ClientSocket = e.ClientSocket;
        memcpy(&m_MsgHead, &e.m_MsgHead, sizeof(e.m_MsgHead));
        memcpy(m_MQMsgId , e.m_MQMsgId, sizeof(e.m_MQMsgId));
    }
} 

CSendCcmsWork::~CSendCcmsWork()
{
}

void CSendCcmsWork::clear()
{
	
}

void CSendCcmsWork::UnpackMsgHead(const char* strMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Enter CSendCcmsWork::UnpackMsgHead...");
    memset(m_MsgHead.szMsgFlagNO, ' ', 28);
    memset(m_MsgHead.szSndNO, ' ', 14);
	int offset = 0;
	OffsetCpy(m_MsgHead.szSysType, strMsg, offset, 4);
	OffsetCpy(m_MsgHead.szMsgUse, strMsg, offset, 1);
	OffsetCpy(m_MsgHead.szMsgTypeFlag, strMsg, offset, 3);
	OffsetCpy(m_MsgHead.szMsgType, strMsg, offset, 3);
	OffsetCpy(m_MsgHead.szMsgFlagNO, strMsg, offset, 28);
	OffsetCpy(m_MsgHead.szSndNO, strMsg, offset, 14);	
	OffsetCpy(m_MsgHead.szOprUser,strMsg, offset, 20);
	OffsetCpy(m_MsgHead.szOprUserNetId,strMsg, offset, 20);	
	OffsetCpy(m_MsgHead.szMsgKind,strMsg, offset, 5);
	OffsetCpy(m_MsgHead.szReserve,strMsg, offset, 43);
	
	Trim(m_MsgHead.szMsgFlagNO);
	Trim(m_MsgHead.szSndNO);
	Trim(m_MsgHead.szOprUser);
	Trim(m_MsgHead.szOprUserNetId);
	Trim(m_MsgHead.szMsgKind);
	
	m_sTrsCode = m_MsgHead.szMsgFlagNO;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_sTrsCode= [%s]",     m_sTrsCode.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_MsgHead.szSysType= [%s]",     m_MsgHead.szSysType);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_MsgHead.szMsgUse= [%s]",     m_MsgHead.szMsgUse); 
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_MsgHead.szMsgType= [%s]",     m_MsgHead.szMsgType);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_MsgHead.szMsgTypeFlag =[%s]",  m_MsgHead.szMsgTypeFlag);  
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_MsgHead.szMsgFlagNO= [%s]",   m_MsgHead.szMsgFlagNO);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_MsgHead.szSndNO =[%s]",  m_MsgHead.szSndNO);  
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leave CSendCcmsWork::UnpackMsgHead...");
	return;
}

INT32 CSendCcmsWork::doWork()
{
    if ( 0 == strcmp(m_MsgHead.szMsgTypeFlag, "CMT") )
    {
        char sTmpMsgTp[4 + 1];
        sprintf(sTmpMsgTp, "1%s", m_MsgHead.szMsgType);
        ZFPTLOG.SetLogInfo(sTmpMsgTp, m_MsgHead.szMsgFlagNO);
    }
    else
    {
        ZFPTLOG.SetLogInfo(m_MsgHead.szMsgType, m_MsgHead.szMsgFlagNO);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcmsWork::doWork..."); 
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "收到交易:[%s]", m_sTrsCode.c_str());

    int iMsgNO = atoi(m_MsgHead.szMsgType);
    if(0 == iMsgNO)
    {
        Trace(L_INFO, __FILE__,  __LINE__, NULL, "转换报文号失败,m_MsgHead.szMsgType = %s", m_MsgHead.szMsgType);
    }

    int iRet = 0;
    CSendCcmsBase* SendBse = NULL;
    stuSndMsg SndMsg;
    memset(&SndMsg, 0x00, sizeof(SndMsg));
  
    switch(iMsgNO)
    {
        case 303:
        {
            if ( 0 == strcmp(m_MsgHead.szMsgTypeFlag, "CMT") )
            {
                SendBse = new CSendCmt303(m_MsgHead);
            }
            else
            {
                SendBse = new CSendCcms303(m_MsgHead);
            }
            break;
        }
        case 307:
        {
            SendBse = new CSendCcms307(m_MsgHead);
            break;
        }
        case 309:
        {
            SendBse = new CSendCmt309(m_MsgHead);
            break;
        }        
		case 310:
        {
            SendBse = new CSendCcms310(m_MsgHead);
            break;
        }
		case 311:
        {   
            if ( 0 == strcmp(m_MsgHead.szMsgTypeFlag, "CMT") )
            {
                SendBse = new CSendCmt311(m_MsgHead);
            }
            else
            {
                SendBse = new CSendCcms311(m_MsgHead);
            }
            break;
        }
		case 312:
        {
            SendBse = new CSendCcms312(m_MsgHead);
            break;
        }
		case 313:
        {
            if ( 0 == strcmp(m_MsgHead.szMsgTypeFlag, "CMT") )
            {
                SendBse = new CSendCmt313(m_MsgHead);
            }
            else
            {
                SendBse = new CSendCcms313(m_MsgHead);
            }
            break;
        }
		case 316:
        {
            SendBse = new CSendCcms316(m_MsgHead);
            break;
        }
		case 318:
        {
            SendBse = new CSendCcms318(m_MsgHead);
            break;
        }
		case 319:
        {
            if ( 0 == strcmp(m_MsgHead.szMsgTypeFlag, "CMT") )
            {
                SendBse = new CSendCmt319(m_MsgHead);
            }
            else
            {
                SendBse = new CSendCcms319(m_MsgHead);
            }
            break;
        }
 		case 320:
        {
            SendBse = new CSendCmt320(m_MsgHead);
            break;
        }        
 		case 321:
        {
            SendBse = new CSendCmt321(m_MsgHead);
            break;
        } 
        case 328:
        {
            SendBse = new CSendCmt328(m_MsgHead);
            break;
        }       
        case 519:
        {
            SendBse = new CSendCmt519(m_MsgHead);
            break;
        }
        case 651:
        {
            SendBse = new CSendCmt651(m_MsgHead);
            break;
        }
		case 805:
        {
            SendBse = new CSendCcms805(m_MsgHead);
            break;
        }        
        case 903:
        {
            SendBse = new CSendCcms903(m_MsgHead);
            break;
        }
        case 919:
        {
            SendBse = new CSendCcms919(m_MsgHead);
            break;
        }
        default:
        {
            Trace(L_INFO, __FILE__,  __LINE__, NULL, "没有找到相应的报文号!");
            iRet = ERR_NOT_FOUND_NO;

            return RTN_FAIL;
        }
    }

    memcpy(SendBse->m_MQMsgId , m_MQMsgId, sizeof(m_MQMsgId));
    iRet = SendBse->doWork();
    DELPOINT_VOID(SendBse);
    
    Trace(L_INFO, __FILE__,  __LINE__, NULL, "报文处理结束,iMsgNO = %d!", iMsgNO);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Leave CSendCcmsWork::doWork..."); 
    return RTN_SUCCESS;
}



