/********************************************************************
�ļ�����recvccms803.cpp
�����ˣ�handongfeng
��  �ڣ�2010.07.08
�޸��ˣ�
��  �ڣ�
��  �����������״̬���֪ͨ����
��  ����
Copyright (c) 2010  YLINK
********************************************************************/
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif
#include "recvccms803.h"


CRecvCcms803::CRecvCcms803()
{

}

INT32 CRecvCcms803::InsertData()
{
    return OPERACT_SUCCESS;
}

INT32 CRecvCcms803::Work(LPCSTR szMsg)
{   
	Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms803::DoWork() begin");
  
    //��������
	UnPack(szMsg);

	//���²�����״̬
	SetData(szMsg);
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms803::DoWork() end");
    return OPERACT_SUCCESS;
}

void CRecvCcms803::UnPack(LPCSTR  szMsg)
{	
	Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms803::UnPack() Begin");
	
	//1�������Ƿ�Ϊ��
	if (NULL == szMsg || '\0' == szMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��! ");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��! ");
	}
	int iRet = oCcms803.ParseXml(szMsg);
	if ( 0 != iRet )
	{
		sprintf(m_szErrMsg, "CRecvCcms803::UnPack():���Ľ�������!iRet=[%d]", iRet);
		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__,  OPT_PRS_MSG_FAIL, m_szErrMsg); 
	}

	ZFPTLOG.SetLogInfo("803", oCcms803.MsgId.c_str());
	m_strMsgID	=	oCcms803.MsgId;
	
	Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms803::UnPack() End");
	return;
}   

char* CRecvCcms803::chgBankStatus(char const * _pIBankStatus, char* pOBankStatus)
{	
	//ƽ̨״̬����: 0 �˳�,1 ����,2 ���� 
	if(0==memcmp(_pIBankStatus,"ST00",4)) //ST00���ù���
    {
    	strcpy(pOBankStatus, "2"); 
    }
    else if(0==memcmp(_pIBankStatus,"ST01",4)) //ST01�ָ�����
    {
    	strcpy(pOBankStatus, "1");
    }
    /*  ccms803���Ĺ��ܱ������½���˳�ʱ��ʹ�ñ�����֪ͨ������  by modify zql 2012-6-11
	else if(0==memcmp(_pIBankStatus,"ST02",4)) //ST02�ѵ�¼
    {
    	strcpy(pOBankStatus, "1");
    }
    else if (0==memcmp(_pIBankStatus,"ST03",4))//ST03���˳�
    {
    	strcpy(pOBankStatus, "0");
    }
    */
    else if (0==memcmp(_pIBankStatus,"ST04",4))//ST04����ά��
    {
    	strcpy(pOBankStatus, "3");
    }
    
	if(0 == strlen(pOBankStatus))
		strcpy(pOBankStatus, "9");

	return pOBankStatus;
}

int CRecvCcms803::SetBankStat(string &strBankCode)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms803::SetBankStat() Begin");

    SETCTX(oCBankstat);
    
	char   sBankStatus[1+1] = {0};
	memset(sBankStatus,NULL_CHAR,sizeof(sBankStatus));
	
	oCBankstat.m_syscode =oCcms803.SysCd;      //ϵͳ��  by add zql 2012-06-21
    oCBankstat.m_bankcode = oCcms803.PtyId;   //  ���������
    strBankCode = oCcms803.PtyId;
    int iRet = oCBankstat.findByPK();//���Ҳ��������Ϣ
    if (SQLNOTFOUND == iRet) 
	{
		sprintf(m_szErrMsg, "���������[%s]������,����������¼", oCcms803.PtyId.c_str());	
		Trace(L_INFO, __FILE__, __LINE__, NULL, m_szErrMsg);
		
    	//�������״̬ת��
        chgBankStatus(oCcms803.Tp.c_str(),sBankStatus);
    	if (0 == memcmp(sBankStatus, "9", 1))//ת������
    	{
    		sprintf(m_szErrMsg, "�������״̬[%s]ת��ʧ��",oCcms803.Tp.c_str());	
    		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
    		PMTS_ThrowException(__FILE__, __LINE__,  OTH_ERR, m_szErrMsg);
    	}
    	
        oCBankstat.m_syscode = oCcms803.SysCd; 
        oCBankstat.m_bankcode = oCcms803.PtyId; 
        oCBankstat.m_runstat  = sBankStatus;

        char CCPCNode[5] = {0};
        iRet = TranSapBkToCCPCCode(m_dbproc, oCBankstat.m_bankcode.c_str(), CCPCNode);
        if(RTN_SUCCESS != iRet)
        {
            Trace(L_INFO, __FILE__, __LINE__, NULL, "ȡccpc�ڵ�ʧ��,����");
            return 2;
        }
        oCBankstat.m_ccpc = CCPCNode; 
        
		iRet = oCBankstat.insert();
		if(RTN_SUCCESS != iRet)
		{
    		Trace(L_ERROR, __FILE__, __LINE__, NULL, "�����ʧ��[%d][%s]", iRet, oCBankstat.GetSqlErr());

    		PMTS_ThrowException(__FILE__, __LINE__,  DB_INSERT_FAIL, m_szErrMsg);
		}

		return 2;
	}

    if (RTN_SUCCESS != iRet) 
	{
		sprintf(m_szErrMsg, "��ѯ���������[%s]ʧ��[%s]",oCcms803.PtyId.c_str(), oCBankstat.GetSqlErr());	
		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__,  DB_FIND_BY_PK_FAIL, m_szErrMsg);
	}  
    Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms803::SetBankStat() END");

    return RTN_SUCCESS;
}

void CRecvCcms803::SetNodeStat(string strBankCode)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms803::SetNodeStat() Begin");

    SETCTX(oCmnodestat);
	char   sBankStatus[1+1] = {0};
	memset(sBankStatus,NULL_CHAR,sizeof(sBankStatus));

    char CCPCNode[5] = {0};
    int iRet = TranSapBkToCCPCCode(m_dbproc, strBankCode.c_str(), CCPCNode);
    if(RTN_SUCCESS != iRet)
    {
		sprintf(m_szErrMsg,"ȡccpc�ڵ�ʧ��[%s][%d][%s]", strBankCode.c_str(), iRet, oCmnodestat.GetSqlErr());	
		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__,  DB_UPDATE_FAIL, m_szErrMsg);        
    }

    oCmnodestat.m_nodecode = CCPCNode;
    oCmnodestat.m_syscode  = oCcms803.SysCd;
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "CCPCNode[%s]", CCPCNode);
    
    iRet = oCmnodestat.findByPK();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ѯ�ڵ�ʧ��[%d][%s][%s]", iRet, oCmnodestat.m_nodecode.c_str(), oCmnodestat.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
    }
    
    chgBankStatus(oCcms803.Tp.c_str(),sBankStatus);
	if (0 == memcmp(sBankStatus, "9", 1))//ת������
	{
		sprintf(m_szErrMsg, "�������״̬[%s]ת��ʧ��",oCcms803.Tp.c_str());	
		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__,  OTH_ERR, m_szErrMsg);
	}

    string strSQL;
	strSQL += "UPDATE cm_nodestat t SET ";
	strSQL += "t.NODESTAT = '";
    strSQL += oCcms803.Tp;
    strSQL += "', t.PROCSTATE = '";
    strSQL += PR_HVBP_35;
	strSQL += "', t.STATTIME = sysdate WHERE t.NODECODE = '";
	strSQL += oCmnodestat.m_nodecode;	
	strSQL += "' and t.syscode='";
	strSQL += oCcms803.SysCd;
	strSQL += "' ";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
	if(OPERACT_SUCCESS != oCmnodestat.execsql(strSQL.c_str()))
	{
		sprintf(m_szErrMsg,"����CCPC[%s]״̬ʧ��[%d][%s]", oCmnodestat.m_nodecode.c_str(), iRet, oCmnodestat.GetSqlErr());	
		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__,  DB_UPDATE_FAIL, m_szErrMsg);
	}

	Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms803::SetNodeStat() END");
}

INT32 CRecvCcms803::SetData(LPCSTR szMsg)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms803::SetData() Begin");

	int    iRet = 0;
    int    iSize = 0;
	char   sBankStatus[1+1] = {0};
    STRING sBankCode = " ";
	memset(sBankStatus,NULL_CHAR,sizeof(sBankStatus));
	
    iSize = oCcms803.m_pXMLProc.m_PMTSSpecilDataMap.size();
    if(iSize <= 0)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "���Ĵ���,�˳�");
        return OPERACT_FAILED;
    }

    sBankCode = "(";
    int iFlag = 0;
    for (int i=0; i<iSize; i++)
    {
        string strBankcode;
        oCcms803.PtyId = " ";
        oCcms803.PtyId = oCcms803.GetPtyId(i);
        Trace(L_DEBUG, __FILE__, __LINE__, NULL,"oCcms803.PtyId[%s]", oCcms803.PtyId.c_str());
        if(("NT01" == oCcms803.PtyTp) && (0 == i))
        {
            SetNodeStat(oCcms803.PtyId);
        }

        iRet = SetBankStat(strBankcode);
        if(2 == iRet)
        {
            continue;
        }        

        iFlag = 1;//��ֹ��¼����������,�Ͳ���Ҫ������
        sBankCode += "'" + strBankcode + ((iSize-1 == i) ? "'" : "', ");
    }
    
    sBankCode += ")";

    if(1 == iFlag)
    {
    	//�������״̬ת��
        chgBankStatus(oCcms803.Tp.c_str(), sBankStatus);
    	if (0 == memcmp(sBankStatus, "9", 1))//ת������
    	{
    		sprintf(m_szErrMsg, "�������״̬[%s]ת��ʧ��",oCcms803.Tp.c_str());	
    		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
    		PMTS_ThrowException(__FILE__, __LINE__,  OTH_ERR, m_szErrMsg);
    	}
    	oCBankstat.m_runstat  = sBankStatus;

        string strSQL;
    	strSQL += "UPDATE cm_bankstat t SET ";
    	strSQL += "t.RUNSTAT = '";
        strSQL += oCBankstat.m_runstat.c_str();
        strSQL += "' ";
        
    	strSQL += " WHERE t.BANKCODE in";
    	strSQL += sBankCode.c_str();	
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
        
    	if(OPERACT_SUCCESS != oCBankstat.execsql(strSQL.c_str()))
    	{
    		sprintf(m_szErrMsg,"���²������[%s]״̬ʧ��[%d][%s]", oCBankstat.m_bankcode.c_str(), iRet, oCBankstat.GetSqlErr());	
    		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
    		PMTS_ThrowException(__FILE__, __LINE__,  DB_UPDATE_FAIL, m_szErrMsg);
    	}
    }	
    
	Trace(L_INFO, __FILE__, __LINE__, NULL, "CRecvCcms803::SetData() End");
	return OPERACT_SUCCESS;
}

