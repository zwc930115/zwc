#include "mbpubfunc.h"
#include "syssapbankinfo.h"
#include "cmbankinfo.h"


/******************************************************************************
*  Function:   CheckCbbaCode 
*  Description:检查CBBA行号是否合法
*  Input:      sCbbaCode(CBBA行号)
*  Output:     sBankCode(参与者行号)  sSapBankCode(直接参与者行号)  sBankName(行名)
*  Return:     是否合法: true合法   false不合法
*  Others:     无
*  Author:     aps-yzx
*  Date:       2011-09-21
*******************************************************************************/
int CheckCbbaCode(DBProc &dbproc,const char * sCbbaCode,char * sBankCode,char * sSapBankCode,char * sBankName)
{
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "Enter CheckCbbaCode()");
	
	int iRet = 0;
	CSyscbbabankcode oCSyscbbabankcode(dbproc);

	oCSyscbbabankcode.m_cbbabkbh = sCbbaCode;
	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "oCSyscbbabankcode.m_cbbabkbh[%s]",oCSyscbbabankcode.m_cbbabkbh.c_str());
    
	iRet = oCSyscbbabankcode.findByPK();
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "验证CBBA行号失败,iRet=%d, %s", iRet, oCSyscbbabankcode.GetSqlErr());
		return RTN_FAIL;
    }

	strcpy(sBankCode,oCSyscbbabankcode.m_bankcode.c_str());
	strcpy(sSapBankCode,oCSyscbbabankcode.m_sapbankcode.c_str());
	strcpy(sBankName,oCSyscbbabankcode.m_cbbabkname.c_str());

	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "Leave CheckCbbaCode()");
	
	return RTN_SUCCESS;
}

/******************************************************************************
*  Function:    GetMbMsgSn
*  Description: 行内用于获取报文序号
*  Input:		sSapBankCode：发起清算行行号
*  Output:	   sRtnValue：8位序号
*  Return:	   
*  Others:	   
*  Author:	   
*  Date:	   
*******************************************************************************/
int GetMbMsgSn(DBProc &dbproc,const char * sSapBankCode,char * sRtnValue)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "Enter GetMbMsgSn()");
	
    CSyssysparm cSysparm(dbproc);

	//行内获取的报文序号固定取大额的报文序号
	long lSn = cSysparm.get_serialno(eMsgId, SYS_HVPS, sSapBankCode); 
	
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "lSn[%ld]",  lSn); 
	  
    if(-1 == lSn)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "get_serialno failed!,%s",  cSysparm.GetSqlErr());
        return RTN_FAIL;
    }

	sprintf(sRtnValue, "%08d",lSn);
	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "leave GetMbMsgSn()");	
	
    return RTN_SUCCESS;
}

/******************************************************************************
*  Function:    StrUpperCase
*  Description: 字符大写转换
*  Input:		sSrcStr:原字符串
*  Output:	     sSrcStr:转换后的字符串
*  Return:	   
*  Others:	   
*  Author:	   
*  Date:	   
*******************************************************************************/
char * StrUpperCase(char* sSrcStr)
{
    if ((sSrcStr==NULL)||(sSrcStr[0]==0)) return sSrcStr;
    char * p = sSrcStr;
    while(*p != 0) 
    {
        if (*p >= 'a' && *p <='z') *p = *p + 'A' - 'a';
        p ++;
    }
    return sSrcStr;
}

/******************************************************************************
*  Function:    DelBankCodeNAR
*  Description: 用于掉帐号开头的NRA
*  Input:		sSapBankCode:帐号  
*  Output:	  
*  Return:	   
*  Others:	   
*  Author:	   
*  Date:	   
*******************************************************************************/
char * DelBankCodeNAR(char * sSapBankCode)
{
	//去除左空格
	while (*sSapBankCode == ' ')
	{
		sSapBankCode++;
	}
	
	//字母大写转换
	StrUpperCase(sSapBankCode);

	if (strncmp(sSapBankCode, "NRA", 3) == 0)
	{
		strcpy(sSapBankCode, sSapBankCode+3);
	}

	return sSapBankCode;
}

/******************************************************************************
*  Function:    CleanBankCode
*  Description: 用于去掉帐号 两头的空格，去掉"-"
				和"/"符号，去掉NRA
*  Input:		sSapBankCode:帐号  
*  Output:	  
*  Return:	   
*  Others:	   
*  Author:	   
*  Date:	   
*******************************************************************************/
char * CleanBankCode(char  *sSapBankCode)
{
	Trace(L_DEBUG,	__FILE__,  __LINE__, NULL, "Enter CleanBankCode()");

	int  i,j,len;
	char sTemp[1 + 1] = {0};
	char *inPut;
	bool bFlag = false;

	sSapBankCode = DelBankCodeNAR(sSapBankCode);
	inPut = sSapBankCode;

	//去除右边空格、'-'、'/'
	len=strlen(inPut);
	for(i=len-1;i>=0 && ((inPut[i]==' ') || (inPut[i]=='-') || (inPut[i]=='/'));i--);
	inPut[i+1]=0;

	len = strlen(inPut);
	for (i=0; i<len; i++)
	{
		sTemp[0] = inPut[i];
		if ((strcmp(sTemp, "-")==0) || (strcmp(sTemp, "/")==0))
		{
			bFlag = true;
			for (j=i; (j+1)<len; j++)
			{
				inPut[j] = inPut[j+1];
				if (bFlag)
				{
					bFlag = false;
					i--;
				}
			}
		}
	}

	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "leave CleanBankCode()");

	return sSapBankCode;
}

int code_convert(char* from_charset, char* to_charset, char* inbuf,int inlen, char* outbuf, int outlen)
{
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "Enter code_convert()");
	
    iconv_t cd;
    char** pin = &inbuf;
    char** pout = &outbuf;

    cd = iconv_open(to_charset,from_charset);
    if(cd == 0)
	{
    	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iconv_open error");		
		return -1;
    }

    memset(outbuf,0,outlen);
    if(iconv(cd, pin, (size_t *)&inlen, pout, (size_t *)&outlen) == -1)
	{
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iconv() error");		
		return -1;
    }

    iconv_close(cd);

	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "leave code_convert()");
	
    return 0;
}

void g2i(char *inbuf,char *oubuf)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "Enter g2i()");
	
    if (-1 == code_convert("GB18030","IBM-935",inbuf,strlen(inbuf), oubuf, sizeof(oubuf)))
    {
    	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "error in convert GB18030 to IBM-935");		
    }

	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "leave g2i()");
}

bool i2u(char *inbuf)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "Enter i2u()");		
    
    int nOutLen = 2 * strlen(inbuf) - 1;
    if(nOutLen <= 0)
    {
        nOutLen = 100;
    }

    char* szOut = (char*)malloc(nOutLen);
    if (-1 == code_convert("IBM-935","UTF-8",inbuf,strlen(inbuf), szOut, nOutLen))
    {
    	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "内容包含繁体字[error in convert IBM-935 to UTF-8]");		
	    free(szOut);
			return false;
    }
    free(szOut);

	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "leave i2u()");
	
    return true;
}

void g2u(char *inbuf,char *outbuf)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "Enter g2u()");		
    
    if (-1 == code_convert("GB18030","UTF-8",inbuf,strlen(inbuf), outbuf, sizeof(outbuf)))
    {
    	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "error in convert GB18030 to UTF-8");		
    }

	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "leave g2u()");
}

int GetBrcdBy4Cd(DBProc &dbproc,const char* pcInCd,char* pOBrcd)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter GetBrcdBy4Cd()...");	
    
	int iRet = 0;
	
	CSyscodelistbank oSyscodelistbank(dbproc);

	oSyscodelistbank.m_listcode = pcInCd;

	iRet = oSyscodelistbank.findByPK();
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "%d, %s",
              iRet, oSyscodelistbank.GetSqlErr());
		return iRet;
    }

	strcpy(pOBrcd,oSyscodelistbank.m_bankcode.c_str());

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leave GetBrcdBy4Cd()...");
	
	return iRet;
}

/******************************************************************************
*  Function:    GetAcDate
*  Description: 获取行内会计日期
*  Input:		pcSapCd:清算行号
*  Output:	    pRacdt：会计日期
*  Return:	    成功则返回0;其它失败   
*  Author:	    aps-lel
*  Date:	    2011-11-02
*******************************************************************************/
int GetAcDate(DBProc &dbproc,const char* pcSapCd,char* pRacdt)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter GetAcDate()...");	
    
	int iRet = 0;
	CSyssapbankinfo oSyssapbankinfo(dbproc);

	oSyssapbankinfo.m_sapbank = pcSapCd;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "oSyssapbankinfo.m_sapbank[%s]",oSyssapbankinfo.m_sapbank.c_str());	
	
	iRet = oSyssapbankinfo.findByPK();
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "%d, %s",
              iRet, oSyssapbankinfo.GetSqlErr());
		return iRet;
    }

	strcpy(pRacdt,oSyssapbankinfo.m_mbacdt.c_str());

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leave GetBrcdBy4Cd()...");
	
	return iRet;
}

/******************************************************************************
*  Function:    GetTransactTm
*  Description: 获取交易时间
*  Input:		pRtm:6位交易时间
*  Output:	    pRtm:交易时间
*  Return:	    pRtm:交易时间
*  Author:	    aps-lel
*  Date:	    2011-11-02
*******************************************************************************/
char * GetTransactTm(char * pRtm)
{
    struct tm *nowtime;
    time_t longtime;
    time(&longtime);

    nowtime=localtime(&longtime);

    sprintf(pRtm,"%02d%02d%02d",nowtime->tm_hour,nowtime->tm_min,nowtime->tm_sec);
    
    return pRtm;

}

/******************************************************************************
*  Function:    EBCDIC_2_ASC
*  Description: EBCD碼轉ASC碼
*  Input:
*  Output:
*  Return:
*  Author:	    aps-yzx
*  Date:	    2011-11-17
*******************************************************************************/
char* EBCDIC_2_ASC(char* strIn, int nInLen, int nOutLen)
{
	if(strIn == NULL)
	{
		return NULL;
	}

	int nMemSize = MAX(nInLen, nOutLen);
	nMemSize = nMemSize * 5/3 + 1;
	if(nMemSize < 10)
	{
		nMemSize = 10;
	}

	char *strOut = new char[nMemSize];
	if(strOut == NULL)
	{
		delete strOut;
		strOut = NULL;
		return NULL;
	}

	memset(strOut, 0x00, nMemSize);
	tran_ascebcdic(DT_BACKWARD, strIn, strOut, nOutLen);

	return strOut ;
}

/******************************************************************************
*  Function:    GetTime
*  Description: 取系統時間，格式YYYYMMDDHHMMSS
*  Input:
*  Output:
*  Return:
*  Author:	    aps-yzx
*  Date:	    2011-12-01
*******************************************************************************/
CString GetTime(LPCSTR pFormat)
{
	CString sRet;
	char pBuff[20] = {0};
	tm* pCurTime;
	time_t t;
	time(&t);
	pCurTime = localtime(&t);
	CString sFormat = pFormat;
	sFormat.MakeUpper();
	BOOL bDate = FALSE;
	int iPos = 0, iPosStart = 0;
	iPos = sFormat.Find("YYYY");
	if (iPos >= 0) {
		//sRet += sFormat.Left(iPos);
		sprintf(pBuff, "%4d", pCurTime->tm_year + 1900);
		sRet += pBuff;
		bDate = TRUE;
		iPosStart = iPos + 4;
	} else {
		iPos = sFormat.Find("YY");
		if (iPos >= 0) {
			//sRet += sFormat.Left(iPos);
			sprintf(pBuff, "%02d", pCurTime->tm_year - 100);
			sRet += pBuff;
			bDate = TRUE;
			iPosStart = iPos + 2;
		}
	}
	if (bDate)  {
		iPos = sFormat.Find("MM", iPosStart);
		if (iPos > 0) {
			memset(pBuff, 0X00, sizeof(pBuff));
			//sRet += sFormat.Mid(iPosStart,  iPos - iPosStart);
			sprintf(pBuff, "%02d", pCurTime->tm_mon + 1);
			sRet += pBuff;
			iPosStart = iPos + 2;
		}
		iPos = sFormat.Find("DD", iPosStart);
		if (iPos > 0) {
			memset(pBuff, 0X00, sizeof(pBuff));
			//sRet += sFormat.Mid(iPosStart,  iPos - iPosStart);
			sprintf(pBuff, "%02d", pCurTime->tm_mday);
			sRet += pBuff;
			iPosStart = iPos + 2;
		}
	}

	iPos = sFormat.Find("HH", iPosStart);
	if (iPos >= 0) {
		memset(pBuff, 0X00, sizeof(pBuff));
		//sRet += sFormat.Mid(iPosStart,  iPos - iPosStart);
		sprintf(pBuff, "%02d", pCurTime->tm_hour);
		sRet += pBuff;
		iPosStart = iPos + 2;
	}

	iPos = sFormat.Find("MM", iPosStart);
	if (iPos >= 0) {
		memset(pBuff, 0X00, sizeof(pBuff));
		//sRet += sFormat.Mid(iPosStart,  iPos - iPosStart);
		sprintf(pBuff, "%02d", pCurTime->tm_min);
		sRet += pBuff;
		iPosStart = iPos + 2;
	}

	iPos = sFormat.Find("SS", iPosStart);
	if (iPos >= 0) {
		memset(pBuff, 0X00, sizeof(pBuff));
		//sRet += sFormat.Mid(iPosStart,  iPos - iPosStart);
		sprintf(pBuff, "%02d", pCurTime->tm_sec);
		sRet += pBuff;
		iPosStart = iPos + 2;
		//sRet += sFormat.Mid(iPosStart);
	}
	return sRet;
}

/******************************************************************************
*  Function:    GetDate
*  Description: 取系統日期，格式YYYYMMDD
*  Input:
*  Output:
*  Return:
*  Author:	    aps-yzx
*  Date:	    2011-12-01
*******************************************************************************/
void GetDate(char * sysdate)
{
    struct tm *nowtime;
    time_t longtime;

    time(&longtime);
    nowtime=localtime(&longtime);

    sprintf(sysdate,"%04d",nowtime->tm_year+1900);
    sprintf(&sysdate[4],"%02d",nowtime->tm_mon+1);
    sprintf(&sysdate[6],"%02d",nowtime->tm_mday);
}

/******************************************************************************
*  Function:    ParseEaiXml
*  Description: 解析EAI報文中的某個標簽
*  Input: sOriSource 報文，sTagName 標簽名稱
*  Output: sBuff 標簽内容
*  Return:
*  Author:	    aps-yzx
*  Date:	    2011-12-12
*******************************************************************************/
bool ParseEaiXml(const char* sOriSource, const char* sTagName, char* sBuff)
{
	char sBLabel[30] = "\0";
	char sELabel[30] = "\0";

	sprintf(sBLabel, "<%s>", sTagName);
	sprintf(sELabel, "</%s>", sTagName);

	char* pBeginPos = strstr(sOriSource, sBLabel);
	char* pEndPos = strstr(sOriSource, sELabel);

	if(!pBeginPos || !pEndPos)
	{
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "OriSource can't find pBeginPos or pEndPos");
		return false;
	}

	memset(sBuff, 0x00, sizeof(sBuff));
	memcpy(sBuff, pBeginPos+strlen(sBLabel), pEndPos - (pBeginPos + strlen(sBLabel)));
	
	trim(sBuff);
		
	if(0 >= strlen(sBuff))
	{
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "sBuff is NULL");
		return false;
	}
	
	return true;
}

/******************************************************************************
*  Function:    GetTarAppId
*  Description: 获取应用编号
*  Input:		pAppSys:应用系统
*               pMsgno：报文编号
*               pBusiType:行内业务类型
*  Output:	    pAppid:应用编号
*  Return:	    pAppid:应用编号
*  Author:	    aps-lel
*  Date:	    2011-12-19
*******************************************************************************/
char * GetTarAppId(const char *pAppSys,const char *pMsgno,char * pAppid,const char* pBusiType)
{
	char szAppNo[5+1] = {0}; 
	if(0 == strcmp(pAppSys,"IBC"))
	{	
		strcpy(szAppNo,"60456");
		if(0 == strcmp(pMsgno,"111")||0 == strcmp(pMsgno,"121")||
		   0 == strcmp(pMsgno,"112")||0 == strcmp(pMsgno,"122")||
		   0 == strcmp(pMsgno,"141")||0 == strcmp(pMsgno,"142")||
		   0 == strcmp(pMsgno,"144")||0 == strcmp(pMsgno,"303")||
		   0 == strcmp(pMsgno,"310")||0 == strcmp(pMsgno,"311")||
		   0 == strcmp(pMsgno,"312")||0 == strcmp(pMsgno,"313")||
		   0 == strcmp(pMsgno,"314")||0 == strcmp(pMsgno,"315")||
		   0 == strcmp(pMsgno,"900")||0 == strcmp(pMsgno,"911")||
		   0 == strcmp(pMsgno,"994")||
		   0 == strcmp(pMsgno,"603")||0 == strcmp(pMsgno,"604"))
		{
			sprintf(pAppid,"%s%s%s",szAppNo,pMsgno,pBusiType);
		}
		else if(0 == strcmp(pMsgno,"995"))
		{
			sprintf(pAppid,"IBDCMSQ001");
		}
		else
		{
			sprintf(pAppid,"%s  %s",szAppNo,pMsgno);
		}
		
	}
	else if(0 == strcmp(pAppSys,"REM"))
	{
		strcpy(szAppNo,"91413");
		if(0 == strcmp(pMsgno,"111")||0 == strcmp(pMsgno,"121")||
		   0 == strcmp(pMsgno,"112")||0 == strcmp(pMsgno,"122")||
		   0 == strcmp(pMsgno,"125")||
		   0 == strcmp(pMsgno,"310")||0 == strcmp(pMsgno,"311")||
		   0 == strcmp(pMsgno,"312")||0 == strcmp(pMsgno,"313")||
		   0 == strcmp(pMsgno,"314")||0 == strcmp(pMsgno,"315")||
		   0 == strcmp(pMsgno,"900")||0 == strcmp(pMsgno,"911")||
		   0 == strcmp(pMsgno,"994")||
		   0 == strcmp(pMsgno,"603")||0 == strcmp(pMsgno,"604"))
		{
			sprintf(pAppid,"%s%s%s",szAppNo,pMsgno,pBusiType);
		}
		else if(0 == strcmp(pMsgno,"995"))
		{
			sprintf(pAppid,"RTDCMSQ001");
		}
		else
		{
			sprintf(pAppid,"%s  %s",szAppNo,pMsgno);
		}

	}
	else if(0 == strcmp(pAppSys,"BEM"))
	{
		strcpy(szAppNo,"91413");
		sprintf(pAppid,"%s  %s",szAppNo,pMsgno);
	}
	else if(0 == strcmp(pAppSys,"TSS"))
	{
		if(0 == strcmp(pMsgno,"994"))
		{
			strcpy(szAppNo,"61011");
		}
		else if(0 == strcmp(pMsgno,"995"))
		{
			strcpy(szAppNo,"61012");
		}
		else
		{
			strcpy(szAppNo,"61010");
		}
		sprintf(pAppid,"%s",szAppNo);
	}
	else 
	{
		strcpy(szAppNo,"91413");
		sprintf(pAppid,"%s  %s",szAppNo,pMsgno);
	}
			
	return 	pAppid;			
}

char* CharAmtToStr(string & strAmt,char * szAmt ,int iLen )
{
	char szTemt[22] = {0};
	if(iLen > 0)
	{
		strcpy(szTemt,"%0");
		sprintf(szTemt+2,"%d",iLen);
		strcat(szTemt,".0f");
		sprintf(szAmt,szTemt,atof(strAmt.c_str())*100);
	}
	else
	{
		sprintf(szAmt,"%.0f",atof(strAmt.c_str())*100); 	
	}
	
	return szAmt;
}

char* DouAmtToStr(double dAmt,char * szAmt ,int iLen )
{	
	
	char szTemt[22] = {0};
	if(iLen > 0)
	{
		strcpy(szTemt,"%0");
		sprintf(szTemt+2,"%d",iLen);
		strcat(szTemt,".0f");
		sprintf(szAmt,szTemt,dAmt);
	}
	else
	{
		sprintf(szAmt,"%.0f",dAmt*100); 	
	}


	return szAmt;
}

/******************************************************************************
*  Function:    GetBankNmByCd
*  Description: 根据行号取行名
*  Input:		cpBankcode:行号
*  Output:	    pBankNm:行名
*  Return:	    
*  Author:	    aps-lel
*  Date:	    2011-12-19
*******************************************************************************/
int GetBankNmByCd(DBProc &dbproc,const char * cpBankcode,char * pBankNm)
{

	int iRet = 0;
	CCmbankinfo oCmbankinfo(dbproc);

	oCmbankinfo.m_bankcode = cpBankcode;
	    
	iRet = oCmbankinfo.findByPK();
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "取参与者行名失败,iRet=%d, %s", iRet, oCmbankinfo.GetSqlErr());
		return RTN_FAIL;
    }

	strcpy(pBankNm,oCmbankinfo.m_bankname.c_str());


	return RTN_SUCCESS;
}


const char * TransPrty(string & strSrc)
{
	
	if(strSrc == "0")
	{
		return "NORM";
	}
	else if(strSrc == "1")
	{
		return "URGT";
	}
	else if(strSrc == "2")
	{
		return "HIGH";
	}
	else 
	{
		return "NORM";
	}
}

/******************************************************************************
*  Function:   TranBankCodeToCBBACode
*  Description:根据分支行号获取CBBA行号
*  Input:      sBankCode 分支行号
*  output:     sCBBACode CBBA行号
*  Return:     操作结果：true操作成功,false操作失败
*  Others:     无
*  Author:     hhc
*  Date:       2012-01-12
*******************************************************************************/
int TranBankCodeToCBBACode(DBProc &dbproc, const char * sBankCode, char* sCBBACode)
{
    int    iRet = 0;
    int    iRetCode = 0;
    char   sErrorDescTmp[1024+1] = {0};
    string strWhere = "";
    CSyscbbabankcode cSyscbbabankcode(dbproc);
    
    strWhere = strWhere + " BANKCODE='" + sBankCode + "'";
    
    iRetCode = cSyscbbabankcode.find(strWhere);
    while (SQL_SUCCESS == iRetCode) 
    {
        iRet = cSyscbbabankcode.fetch();
        if (SQLNOTFOUND == iRet) 
	    {
	    	iRetCode = iRet;
	        sprintf(sErrorDescTmp,"CBBA行名行号表无记录,参数代码[%s], [%d][%s]", 
	            sBankCode, iRetCode, cSyscbbabankcode.GetSqlErr());	
	
	        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "%s", sErrorDescTmp);
	    	cSyscbbabankcode.closeCursor();
	    	break;
	    }
	    else if (SQL_SUCCESS != iRet) 
	    {
	        iRetCode = iRet;
	        sprintf(sErrorDescTmp, "CBBA行名行号表无记录,参数代码[%s], [%d][%s]", 
	            sBankCode, iRetCode, cSyscbbabankcode.GetSqlErr());	
	
	        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "%s", sErrorDescTmp);
	    }
	    // 找到第一条,赋值之后退出
	    iRetCode = iRet;
	    strcpy(sCBBACode, cSyscbbabankcode.m_cbbabkbh.c_str());
    	cSyscbbabankcode.closeCursor();
    	break;
    }

    return iRetCode;
}

/******************************************************************************
*  Function:    chgSysCd
*  Description: 转换系统编号(人行-->本地)
*  Input:       pBusiType  行内系统编号//0.
*  Output:      pSysCd：本地系统编号//HVPS..
*  Return:      0成功，其它：失败
*  Others:
*  Author:      
*  Date:        2011-04-28
*******************************************************************************/
int MbChgSysCd(const char* pBusiType, char* pSysCd)
{
	if(!pBusiType || !pSysCd)
	{
		return RTN_FAIL;
	}
	
	if(0 == strcmp(pBusiType,"0"))
	{
		strcpy(pSysCd,"HVPS");
	}
	else if(0 == strcmp(pBusiType,"1"))
	{
		strcpy(pSysCd,"BEPS");
	}
	else if(0 == strcmp(pBusiType,"2"))
	{
		strcpy(pSysCd,"IBPS");
	}
	else
	{
		strcpy(pSysCd,"HVPS");
	}	
	return RTN_SUCCESS;
}

/******************************************************************************
*  Function:    NYMB_Trace
*  Description: 记录南洋商行的ECC日志
*  Input:           
    int nLevel：级别(0:ERRO 1:WARN 2:INFO)
    char *pSysFlg: 系统标识（CMIMB:公共應用，CMIHV:大额，CMIBP:小额，CMICC:公共控制，CMISA:清算系統）
    char* pErrMsg：错误信息
*  Output:
*  Return:
*  Others:
*  Author:      yzx
*  Date:        2012-02-09
*******************************************************************************/
void NYMB_Trace(int nLevel,char *pSysFlg,char* pErrMsg)
{   
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "Enter NYMB_Trace()");
    char systime[10] = {0};
    char sysdate[10] = {0};
    char szLevel[10] = {0};
    CString strTime;
    if(opendir("/LOG/ECC/") == NULL) 
	{
		printf("ECC日志路径不存在，建立!\n");
		mkdir("/LOG/ECC/", 0777);
	}
	
	FILE * logfile = NULL;
    logfile = fopen("/LOG/ECC/ecc.log","a+");
    if (NULL == logfile)
    {
        printf("打开文件/LOG/ECC/ecc.log 失败!\n");
    }
    else
    {
        switch(nLevel)
        {
            case 0: strcpy(szLevel,"ERRO");
                    break;
            case 1: strcpy(szLevel,"WARN");
                    break;
            case 2: strcpy(szLevel,"INFO");
                    break;
            default:strcpy(szLevel,"INFO");
        }
        GetDate(sysdate);
        strTime = GetTime("HHMMSS");
        strncpy(systime,strTime.GetBuffer(0),6);
        fprintf(logfile, "[%s] [%4.4s/%2.2s/%2.2s %2.2s:%2.2s:%2.2s] [%s] [%s]\n"  \
            ,szLevel,sysdate,sysdate+4,sysdate+6,systime,systime+2,systime+4,pSysFlg,pErrMsg);
        fclose(logfile);
    }
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "Leave NYMB_Trace()");
}


/******************************************************************************
*  Function:    ChangeAmtType
*  Description: 将货币金额组合成AmountText形式 例如：CNY650000.00
*  Input:           
    string & strCcy：货币符号
    string & strAmt: 金额
*  Output:
	char * szDstAmt: 目标AmountText形式
*  Return: szDstAmt
*  Others:
*  Author:      hhc
*  Date:        2012-04-24
*******************************************************************************/
char * ChangeAmtType(string & strCcy, string & strAmt, char * szDstAmt)
{
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "Enter ChangeAmtType()");
	
	sprintf(szDstAmt, "%s%.2f", strCcy.c_str(), atof(strAmt.c_str())/100);
	
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "Leave ChangeAmtType()");
	
	return szDstAmt;
}

/******************************************************************************
*  Function:    CutTagValue
*  Description: 截取指定字符串的长度并返回
*  Input:           
    string & strSrcTag: 源字符串
    int nCutLen: 指定长度
*  Output:
	char * szDstTag: 目标字符串
*  Return: szDstTag
*  Others:
*  Author:      hhc
*  Date:        2012-04-25
*******************************************************************************/
char * CutTagValue(string & strSrcTag, int nCutLen, char * szDstTag)
{
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "Enter CutTagValue()");
	
	int nTemp = nCutLen/3*2;
	
	strncpy(szDstTag, strSrcTag.c_str(), nTemp);
	
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "Leave CutTagValue()");
	
	return szDstTag;
}

