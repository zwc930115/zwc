/******************************************************************** 
文件名： hvpsckecklist.h
创建人： hq
日  期： 2011-05-16
修改人： 
日  期： 
描  述： 大额明细对账类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef _HVPSCHECKLIST_H_
#define _HVPSCHECKLIST_H_

#include "basic.h"
#include "connectpool.h"
#include "checkaccount.h"
#include "hvpschecksum.h"
#include "hvchklstlist.h"
#include "hvps714.h"
#include "mqagent.h"

class CHvpsCheckList
{
public:
    
    CHvpsCheckList();
    ~CHvpsCheckList();

    void doCheckListWork(DBProc &dbProc,
                        int iChkTp, 
                        LPCSTR sChkDt, 
                        LPCSTR sBankCode, 
                        MQAgent &cMQAgent, 
                        LPCSTR sSendQueue);

public:

    int    m_iTtlCnt;      //714明细数目
    
    bool m_bSndExChgList;  //是否有汇兑往账
    bool m_bRcvExChgList;  //是否有汇兑来账
    bool m_bSndTroFacList; //是否有即时转账往账
    bool m_bRcvTroFacList; //是否有即时转账来账
    bool m_bTransInfoQry;  //是否有查询查复
    bool m_bMnetstlNtc;    //是否有多边轧差净额结算借贷通知
private:

    void UpdateState();
    void IsSend714(MQAgent &cMQAgent, LPCSTR sSendQueue);
    void AddDetail714();
    void updateBkChkSt(LPCSTR _sChkSt);
    void CreateHvps714(MQAgent &cMQAgent, LPCSTR sSendQueue);
    void SetAllCtx();
    
    //将本地数据与核对明细表中数据比较 得到对账状态
    void ComparState(double dLamt, string &sLstate, string &sOutState);
    
    //查找原业务,并传出得到的对帐状态.
    INT32 FindOriInfo(string &sTablename, string &sOutState ) ;
    
    //将本地多的数据找出来 并插入明细核对表
    void FindLocalMore();
    
    //将本地多的数据插入明细核对表中
    void InsertLocalMore(LPCSTR orgnlmsgtp,
									 LPCSTR orgnlmsgid,
									 LPCSTR orgnlinstgpty,
									 LPCSTR txtpcd,
									 LPCSTR sndrcvtp,
									 LPCSTR prcsts,
									 LPCSTR ccy,
									 double amt );
    
    //通过报文类型，得到原业务存放的表
    void TransTable(string &msgtp, string &sndrcvtp, string &tablename);
    
    
    hvps714         m_hvps714;
    CCheckAccount   m_checkaccount;
    CHvchklstlist   m_hvchklstlist;
    CHvpsCheckSum   m_hvchecksum;

    DBProc m_dbproc;
    
    STRING m_szChkDt;      //对账日期
    STRING m_szBkCode;     //清算行号
    STRING m_sCycleDigntr; //循环体数字加签串
};

#endif


