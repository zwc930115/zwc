/******************************************************************** 
�ļ����� send111.h
�����ˣ� ������
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __SENDHVPS111_H__
#define __SENDHVPS111_H__

#include "sendhvpsbase.h"
#include "hvps111.h"
#include "hvsndexchglist.h"

#include "syssapbankinfo.h"

class CSendHvps111 : public CSendHvpsBase
{
public:
	CSendHvps111(const stuMsgHead& Smsg);
	~CSendHvps111();
	int doWorkSelf();
private:
	void AddSign111();
	void SetData();
	int GetData();
	int ChargeMB();
	int FundSettle();
	int UpdateState();
	void SetDBKey();
	string GetTag2ND(const string& QryVal, const string& QryStr, int& iDepth);
	
private:
	CHvsndexchglist m_Hvsndlist;
	CSyssapbankinfo m_Syssapbankinfo;
	hvps111 m_cParser111;
};

#endif


