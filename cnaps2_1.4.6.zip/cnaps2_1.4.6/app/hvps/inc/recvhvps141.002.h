#ifndef _RECVHVPS141_002_H_
#define _RECVHVPS141_002_H_

#include "recvhvpsbase.h"
#include "hvps141.002.h"
#include "hvps132.h"
#include "hvtrofacrcvlist.h"
//#include "hvimmedaacctautorsp.h"

class CRecvHvps141_002 : public CRecvHvpsBase
{
	
public:
	CRecvHvps141_002();
	~CRecvHvps141_002();
	
	// 业务入口函数
	INT32 Work(LPCSTR sMsg);
	
	// 解析报文串
	INT32 unPack(LPCSTR sMsg);
	
	// 实体类赋值
	INT32 SetData(LPCSTR pchMsg);
	
	// 新增数据库
	INT32 InsertData(void);
	
	// 核签
	void  CheckSign141();

private:
	char m_ISODateTime[19+1];
	hvps141_002      m_cParser141_002;
	hvps132			 m_hvps132;
	CHvtrofacrcvlist m_cHvtrofacrcvlist; 
	//CHvimdeaacctautorsp m_cHvautoRsp;
};

#endif

