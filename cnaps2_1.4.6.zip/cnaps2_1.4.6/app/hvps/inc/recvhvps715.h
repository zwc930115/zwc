/******************************************************************** 
 �ļ����� recvhvps715.h
 �����ˣ� hq
 ��  �ڣ� 2011-05-17
 �޸��ˣ� 
 ��  �ڣ� 
 ��  ���� ���ҵ������Ӧ����<hvps.715.001.01>
 ��  ���� 
 Copyright (c) 2011  YLINK 
 ********************************************************************/

#ifndef _RECVHVPS715_H_
#define _RECVHVPS715_H_

#include "recvhvpsbase.h"
#include "hvps715.h"
#include "hvchklstlist.h"
#include "hvpschecksum.h"
#include "hvsapbankinfo.h"
#include "hvbkchkst.h"
#include "hvps111.h"
#include "hvps710.h"
#include "hvps112.h"
#include "hvps141.h"
#include "ccms314.h"
#include "ccms315.h"
#include "cmt100.h"
#include "cmt101.h"
#include "cmt102.h"
#include "cmt108.h"
#include "cmt121.h"
#include "cmt122.h"
#include "cmt123.h"
#include "cmt124.h"
#include "cmt103.h"
#include "cmt105.h"
#include "cmt232.h"
#include "cmt407.h"
#include "cmt408.h"
#include "cmt301.h"
#include "cmt302.h"
#include "cmtransinfoqry.h"
#include "hvsndexchglist.h"
#include "hvrcvexchglist.h"
#include "hvtrofacsndlist.h"
#include "hvtrofacrcvlist.h"
#include "cmtransinfoqry.h"
#include "hvmnetstlntc.h"
#include "checkaccount.h"
#include "cmcheckqry.h" 
#include "recvhvpswork.h"
#include "recvhvpsbase.h"
#include "recvhvps111.h"
#include "recvhvps112.h"
#include "recvhvps141.h"
#include "recvhvps142.h"
#include "recvhvps144.h"
#include "recvhvps152.h"
#include "recvhvps154.h"
#include "recvhvps632.h"
#include "recvhvps633.h"
#include "recvhvps635.h"
#include "hvrecvmsg.h"
#include "recvhvps711.h"
#include "recvhvps713.h"
#include "recvhvps715.h"
#include "recvhvps716.h"
#include "recvcmt100.h"
#include "recvcmt101.h"
#include "recvcmt102.h"
#include "recvcmt103.h"
#include "recvcmt105.h"
#include "recvcmt108.h"
#include "recvcmt110.h"
#include "recvcmt121.h"
#include "recvcmt122.h"
#include "recvcmt123.h"
#include "recvcmt124.h"
#include "recvcmt253.h"
#include "recvcmt231.h"
#include "recvcmt232.h"
#include "recvcmt233.h"
#include "recvcmt234.h"
#include "recvcmt725.h"
#include "recvcmt841.h"

class CRecvHvps715 : public CRecvHvpsBase
{
public:
	CRecvHvps715();
	~CRecvHvps715();
	
	int Work(LPCSTR szMsg);
	
private:
	
	void UnPack(LPCSTR szMsg);
	void CheckSign715();
	void GetCheckDt();
	void updateBkChkSt(LPCSTR _sChkSt);
	int DetailProc(const char *szMsg);
	
	int Do302Work(const char* sMsg);
	int unPack302(const char* sMsg);
	int InsertDb302(LPCSTR pchMsg);	
	int UpdateDb302();

	int Do301Work(LPCSTR sMsg);
	int unPack301(LPCSTR sMsg);
	int InsertDb301(LPCSTR pchMsg);	

	int Do314Work(LPCSTR sMsg);
	int unPack314(LPCSTR sMsg);
	int SetData314(LPCSTR pchMsg);
	int InsertData314(void);

	int Do315Work(LPCSTR sMsg);
	int unPack315(LPCSTR sMsg);
	int SetData315(LPCSTR pchMsg);
	int InsertData315(void);
	int UpdateDb315(void);
	bool ChickIfContuine();

	bool CheckIfSend710();
	void Send710(void);
	hvps715         m_hvps715;
    hvps710         m_hvps710;	
	
	CHvpsCheckSum   m_hvchecksum;
	CHvchklstlist   m_hvchklstlist;
	CHvsapbankinfo  m_hvsapbankinfo;
	CHvbkchkst      m_hvbkchkst;
	CMcheckqry      m_checkqry;

	
	hvps111       m_hvps111;
	hvps112       m_hvps112;
	hvps141       m_hvps141;
	ccms314       m_ccms314;
	ccms315       m_ccms315;
	cmt100        m_cmt100;
	cmt101        m_cmt101;
	cmt102        m_cmt102;
	cmt103        m_cmt103;
	cmt105        m_cmt105;
	cmt108        m_cmt108;
	cmt121        m_cmt121;
	cmt122        m_cmt122;
	cmt123        m_cmt123;
	cmt124        m_cmt124;
	cmt232        m_cmt232;
	cmt407        m_cmt407;
	cmt408        m_cmt408;
	cmt301        m_cmt301;
	cmt302        m_cmt302;
	
	CHvsndexchglist  m_sndexchglist;
	CHvrcvexchglist  m_rcvexchglist;
	CHvtrofacsndlist m_trofacsndlist;
	CHvtrofacrcvlist m_trofacrcvlist;
	CCmtransinfoqry  m_transinfoqry;
	CHvmnetstlntc    m_mnetstlntc;
	CCmtransinfoqry	m_Cmtransqry;
	CCmtransinfoqry	m_cCmtransqry;
	
	string          m_strSysCd;
	char            m_sOldMsgId[35 + 1];
		
	char m_sMsgCode[3 + 1]; 
	bool m_bLast715;
	
	STRING m_szCheckDt;  //��������
	STRING m_szCntt;     //��������ԭ��
	STRING m_szSndRcvTp; //������־:SR00��,SR01��
	STRING m_szChkSt;    //����״̬
	STRING m_szBusiState;//ԭҵ��״̬
	
	double m_dAmount;    //ԭ���
};

#endif

