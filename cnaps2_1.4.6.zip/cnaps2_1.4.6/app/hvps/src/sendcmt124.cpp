/******************************************************************** 
�ļ����� sendcmt124.cpp
�����ˣ� aps-xcm
��  �ڣ� 2011-06-23
�޸��ˣ� 
��  �ڣ� 
��  ���� һ������������л�Ʊδ���˻��ʽ���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt124.h"

CSendCmt124::CSendCmt124(const stuMsgHead& Smsg):CSendHvpsBase(Smsg)
{
   
}

CSendCmt124::~CSendCmt124()
{
    
}


void CSendCmt124::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt124::SetDBKey...");

    m_Hvsndlist.m_msgtp = "CMT";
    m_Hvsndlist.m_msgtp = m_Hvsndlist.m_msgtp + m_szMsgType;
    
	m_Hvsndlist.m_msgid = m_szMsgFlagNO; 
	m_Hvsndlist.m_instgindrctpty = m_szSndNO; 

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_msgtp = %s", m_Hvsndlist.m_msgtp.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_msgid = %s", m_Hvsndlist.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_instgindrctpty = %s", m_Hvsndlist.m_instgindrctpty.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt124::SetDBKey...");
}

int CSendCmt124::GetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt124::GetData...");

    SETCTX(m_Hvsndlist);
    SetDBKey();
    int iRet = m_Hvsndlist.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ȡ����ʧ�ܣ� iRet = [%d]", iRet);
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    if(!m_Hvsndlist.m_endtoendid.empty())
    {
        m_sEndtoEnd = m_Hvsndlist.m_endtoendid;
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sEndtoEnd = %s", m_sEndtoEnd.c_str());
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt124::GetData...");
    return iRet;
    
}


void CSendCmt124::SetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt124::SetData...");
    
    strncpy(m_cCmt124.sConsigndate, m_Hvsndlist.m_workdate.c_str(), sizeof(m_cCmt124.sConsigndate) - 1);
    m_cCmt124.iTxssno = atoi(m_szMsgSerial);
    
    strncpy(m_cCmt124.sCur, m_Hvsndlist.m_currency.c_str(), sizeof(m_cCmt124.sCur) - 1);
    m_cCmt124.dAmount = m_Hvsndlist.m_amount;
    strncpy(m_cCmt124.sSendsapbk, m_Hvsndlist.m_dbtmmbid.c_str(), sizeof(m_cCmt124.sSendsapbk) - 1);
    strncpy(m_cCmt124.sSendbank, m_Hvsndlist.m_dbtid.c_str(), sizeof(m_cCmt124.sSendbank) - 1);
    strncpy(m_cCmt124.sRecvsapbk, m_Hvsndlist.m_cdtmmbid.c_str(), sizeof(m_cCmt124.sRecvsapbk) - 1);
    strncpy(m_cCmt124.sRecvbank, m_Hvsndlist.m_cdtid.c_str(), sizeof(m_cCmt124.sRecvbank) - 1);
    //strncpy(m_cCmt124.sPayeeopenbk, m_Hvsndlist.m_cdtrissr.c_str(), sizeof(m_cCmt124.sPayeeopenbk) - 1);
    strncpy(m_cCmt124.sPayopenbk, m_Hvsndlist.m_dbtrissr.c_str(), sizeof(m_cCmt124.sPayopenbk) - 1);

    //���ĸ�ʽ��û��
    //GetTag1ST("59E:", m_cCmt124.sLastholdno, m_Hvsndlist.m_ustrdstr);
    //GetTag1ST("59D:", m_cCmt124.sLastholdname, m_Hvsndlist.m_ustrdstr);
    string strTemp;
    GetTag1ST("30B:", strTemp, m_Hvsndlist.m_ustrdstr);
    strncpy(m_cCmt124.sBilldate, strTemp.c_str(), sizeof(m_cCmt124.sBilldate) -1);
    strTemp.erase();
    GetTag1ST("21A:", strTemp, m_Hvsndlist.m_ustrdstr);
    strncpy(m_cCmt124.sBillno, strTemp.c_str(), sizeof(m_cCmt124.sBillno) -1);
    strTemp.erase();
    GetTag1ST("C10:", strTemp, m_Hvsndlist.m_ustrdstr);
    strncpy(m_cCmt124.sDraftmac, strTemp.c_str(), sizeof(m_cCmt124.sDraftmac) -1);
    strTemp.erase();
    GetTag1ST("C33:", strTemp, m_Hvsndlist.m_ustrdstr);
    strncpy(m_cCmt124.sBillpaymentbk, strTemp.c_str(), sizeof(m_cCmt124.sBillpaymentbk) -1);
    
    strncpy(m_cCmt124.sPayeracc, m_Hvsndlist.m_dbtracctid.c_str(), sizeof(m_cCmt124.sPayeracc) - 1);
    strncpy(m_cCmt124.sPayername, m_Hvsndlist.m_dbtnm.c_str(), sizeof(m_cCmt124.sPayername) - 1);
    strncpy(m_cCmt124.sPayeraddr, m_Hvsndlist.m_dbtaddr.c_str(), sizeof(m_cCmt124.sPayeraddr) - 1);
    strncpy(m_cCmt124.sPayeename, m_Hvsndlist.m_cdtrnm.c_str(), sizeof(m_cCmt124.sPayeename) - 1);

    char SndCCPCNode[4 + 1] 	= {0};	
	char RcvCCPCNode[4 + 1] 	= {0};
    GetSapBkToCCPC(m_dbproc, m_Hvsndlist.m_instgindrctpty, SndCCPCNode);
	GetSapBkToCCPC(m_dbproc, m_Hvsndlist.m_instdindrctpty, RcvCCPCNode);
	strncpy(m_cCmt124.sSendsenter, SndCCPCNode, sizeof(m_cCmt124.sSendsenter) - 1);
	strncpy(m_cCmt124.sRecvsenter, RcvCCPCNode, sizeof(m_cCmt124.sRecvsenter) - 1);

	strncpy(m_cCmt124.sRemark, m_Hvsndlist.m_addinfo.c_str(), sizeof(m_cCmt124.sRemark) - 1);

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt124::SetData...");
    
}

int CSendCmt124::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt124::buildCmtMsg...");

    int iRet = m_cCmt124.CreateCmt("124", m_Hvsndlist.m_instgdrctpty.c_str(), m_Hvsndlist.m_instddrctpty.c_str(), m_sMesgId.c_str(), m_sMesgId.c_str(), m_Hvsndlist.m_workdate.c_str(), m_Hvsndlist.m_sttlmprty.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt124::buildCmtMsg...");
    return iRet;
}
int CSendCmt124::UpdateState()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt124::UpdateState...");

    SETCTX(m_Hvsndlist);

    string strSQL;

    strSQL += "UPDATE hv_sndexchglist t SET t.STATETIME = sysdate, t.PROCSTATE = '08'";
	strSQL += ", t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
	strSQL += "', t.endtoendid = '";
	strSQL += m_sEndtoEnd;
    strSQL += "' ";
    
	strSQL += " WHERE t.MSGTP = '";
	strSQL += m_Hvsndlist.m_msgtp.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_Hvsndlist.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Hvsndlist.m_instgindrctpty.c_str(); 									
	strSQL += "'";
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "strSQL=[%s]", strSQL.c_str());
    int iRet = m_Hvsndlist.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��iRet=[%d], [%s]", iRet, m_Hvsndlist.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
        
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt124::UpdateState...");
    return iRet;
}

int CSendCmt124::doWorkSelf()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt124::doworkSelf...");
    //1)�������
    GetData();

    //2)��ֵ
    SetData();

	AddMac();
    
    buildCmtMsg();
    
    //3)	ҵ���飨�ͻ������룩
    //.......
    //4)	���������ͻ������룩


    UpdateState();

    AddQueue(m_cCmt124.m_strCmtmsg, m_cCmt124.m_strCmtmsg.length());
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt124::doworkSelf...");
    return RTN_SUCCESS;
    
}

int CSendCmt124::AddMac()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt124::AddMac...");
	int iRet = -1;
	
	m_cCmt124.SetSeal();//��ȡ��Ѻ��

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt124.sSendsapbk[%s]",m_cCmt124.sSendsapbk);
	
    iRet = CodeMac(m_dbproc,m_cCmt124.m_Seal.c_str(),m_cCmt124.sSendsapbk,m_cCmt124.m_szMacStr);
    if(0 != iRet)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "AddMac failed");
    	PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]",m_cCmt124.m_szMacStr);
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt124::AddMac..."); 
    
    return RTN_SUCCESS;
}

