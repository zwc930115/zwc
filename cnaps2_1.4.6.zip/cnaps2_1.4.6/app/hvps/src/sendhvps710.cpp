/******************************************************************** 
�ļ����� send710.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
    
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendhvps710.h"

CSendHvps710::CSendHvps710(const stuMsgHead& Smsg):CSendHvpsBase(Smsg)
{
   
}

CSendHvps710::~CSendHvps710()
{
    
}

void CSendHvps710::AddSign710()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendHvps710::AddSign710");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_hvps710.getOriSignStr();
	
	AddSign(m_hvps710.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_hvps710.InstgDrctPty.c_str());
	
	m_hvps710.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendHvps710::AddSign710");
}

void CSendHvps710::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps710::SetData...");

    // ��ȡ��������
    char	m_sWorkDate[8 + 1] = {0};
    int iRet = FAILED;
    iRet  = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS, m_szSndNO);
  
    if(RTN_SUCCESS != iRet)
    {
      Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");
      PMTS_ThrowException(OPT_GET_DATE_FAIL);
    }

    iRet = GetIsoDateTime(m_dbproc, SYS_HVPS, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get ISODateTime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }

    char MsgID[40] = {0};
    bool bRet = GetMsgIdValue(m_dbproc, MsgID, eMsgId,  SYS_HVPS, m_szSndNO);
    if(true != bRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get Msgid fail");
	    PMTS_ThrowException(OPT_GET_MSGID_FAIL);
    }
    m_hvps710.MsgId = MsgID;
    m_hvps710.CreDtTm = m_ISODateTime;
    m_hvps710.InstgDrctPty = m_szSndNO;
    m_hvps710.GrpHdrInstgPty = m_szSndNO;
    m_hvps710.InstdDrctPty = "0000";
    m_hvps710.GrpHdrInstdPty = "0000";
    m_hvps710.SysCd = "HVPS";
    m_hvps710.ChckngDt = m_strISOData;
    
    // ���ļ�ͷ
    m_hvps710.CreateXMlHeader("HVPS",                        \
                                m_sWorkDate, \
                                m_szSndNO,\
                                "0000",\
                                "hvps.710.001.01",              \
                                m_sMesgId.c_str());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps710::SetData...");
    return;
}

int CSendHvps710::GetData()
{
    return RTN_SUCCESS;
}

int CSendHvps710::UpdateState()
{
    return RTN_SUCCESS;
}

void CSendHvps710::InsertDB()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps710::InsertDB...");

    string strWhere = "CHECKDATE = '" + m_strISOData + "' and SAPBANK = '" + m_szSndNO + "'";
    SETCTX(m_Hvbkchkst);
    int iRet = m_Hvbkchkst.findcount(strWhere);
    if( iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ѯ��ʧ��[%d][%s]", iRet, m_Hvbkchkst.GetSqlErr());
        PMTS_ThrowException(DB_OPT_FAIL);
    }

    if (m_Hvbkchkst.m_iCount > 0) 
    {
        Trace(L_INFO, __FILE__, __LINE__, NULL, "��¼��Ϊ:[%d]", m_Hvbkchkst.m_iCount);
        return ;
    }
    
    m_Hvbkchkst.m_sapbank = m_szSndNO;
    m_Hvbkchkst.m_checkdate = m_strISOData;
    m_Hvbkchkst.m_checkstate = "00";
    
    iRet = m_Hvbkchkst.insert();
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ѯ��ʧ��[%d][%s]", iRet, m_Hvbkchkst.GetSqlErr());
        PMTS_ThrowException(DB_INSERT_FAIL);    
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps710::InsertDB...");
}

int CSendHvps710::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps710::doWork...");

    m_strISOData = m_szMsgFlagNO;
    
    InsertDB();
    
    SetData();

    AddSign710();

    int iRet = m_hvps710.CreateXml();
    if(RTN_SUCCESS != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }

    //3)	ҵ���飨�ͻ������룩
    //.......
    //4)	���������ͻ������룩
    //.....


	CMcheckqry m_checkqry;
	m_checkqry.m_msgid = m_hvps710.MsgId;
	m_checkqry.m_msgtype = "hvps.710.001.01";
	m_checkqry.m_sapbank = m_hvps710.InstgDrctPty;
	m_checkqry.m_checkdate = m_hvps710.ChckngDt;
	SETCTX(m_checkqry);
	iRet = m_checkqry.insert();
	if( 0 != iRet)
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "INSERT CM_CHECKQRY FILED[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "INSERT CM_CHECKQRY FILED!");
	}
	
    AddQueue(m_hvps710.m_sXMLBuff.c_str(), m_hvps710.m_sXMLBuff.length());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps710::doWork..."); 

    return RTN_SUCCESS;
}


