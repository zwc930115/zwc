/******************************************************************** 
文件名： send111.cpp
创建人： handongfeng
日  期： 2011-02-23
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2017  YLINK 
********************************************************************/ 
    
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendhvps132.h"


CSendHvps132::CSendHvps132(const stuMsgHead& Smsg):CSendHvpsBase(Smsg), m_rspway(Smsg.szReserve)
{
   
}

CSendHvps132::~CSendHvps132()
{
    
}

void CSendHvps132::AddSign132()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendHvps132::AddSign111");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_hvps132.getOriSignStr();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSignBuff = [%s]", m_hvps132.m_sSignBuff.c_str());
	
	AddSign(m_hvps132.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_cHvtrofacrcvlist.m_instgdrctpty.c_str());
	
	m_hvps132.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendHvps132::AddSign132");
}

void CSendHvps132::SetData()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps132::SetData...");
		
    char		szchAmt[64+1]		= {0};
    char		szchDate[32+1]		= {0};
    int			iDepth				= 0;

 	//取msgid
    char szchMsgId[128 +1] = {0};
    GetMsgIdValue(m_dbproc, szchMsgId, eMsgId, SYS_HVPS);
    m_hvps132.MsgId  = szchMsgId;                  //报文标识号

    //GetIsoDateTimeByWorkDate(m_sWorkDate,szchDate);
    m_hvps132.CreDtTm           = szchDate;                   //报文发送时间
    
    m_hvps132.MmbId      		= m_cHvtrofacrcvlist.m_instdindrctpty;   //发起直接参与者行号
    m_hvps132.OrgnlMsgId        = m_cHvtrofacrcvlist.m_msgid;         //原报文标识号
    m_hvps132.OrgnlMsgNmId		=  m_cHvtrofacrcvlist.m_msgtp ;// 原报文类型代码

	m_hvps132.DtldNbOfTxs	= "1"; //回执明细业务总笔数,固定写1
	m_hvps132.DtldSts       	= "ACCP";
	m_hvps132.OrgnlTxId         = m_cHvtrofacrcvlist.m_msgid;  //原明细标识号
	m_hvps132.AddtlInf1			= m_cHvtrofacrcvlist.m_instgdrctpty; //原业务发起直接参与者行号
	if (m_rspway == "00") //回执成功
	{
	    m_hvps132.OrgnlNbOfTxs    	= "1" ;        //回执明细业务成功总笔数
	    m_hvps132.OrgnlCtrlSum     	= m_cHvtrofacrcvlist.m_amount;    //回执明细业务成功总金额
	    m_hvps132.StsId      		= "PR02";   //业务回执状态(PR02-已付款; PR09-已拒绝)
	}else //回执拒绝
	{
		m_hvps132.OrgnlNbOfTxs    	= "0" ;    //回执明细业务成功总笔数
	    m_hvps132.OrgnlCtrlSum     	= "0";    //回执明细业务成功总金额
	    m_hvps132.StsId      		= "PR09";   //业务回执状态(PR02-已付款; PR09-已拒绝)
	    m_hvps132.Prtry				= "REJECT";		//业务拒绝处理码，固定填写REJECT
		m_hvps132.AddtlInf1			= "摩根银行不接受此笔交易"; //业务拒绝原因
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps132::SetData...");
	return;
}

int CSendHvps132::GetData()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps132::GetData...");
	
    char		szchAmt[64+1]		= {0};
    char		szchDate[32+1]		= {0};
    int			iDepth				= 0;

 	//取msgid
    char szchMsgId[128 +1] = {0};
    GetMsgIdValue(m_dbproc, szchMsgId, eMsgId, SYS_HVPS);
    m_hvps132.MsgId  = szchMsgId;                  //报文标识号

    //GetIsoDateTimeByWorkDate(m_sWorkDate,szchDate);
    m_hvps132.CreDtTm           = szchDate;                   //报文发送时间

	SETCTX(m_cHvtrofacrcvlist);
	m_cHvtrofacrcvlist.m_msgid = m_szMsgFlagNO;  
	string sql = "msgid = '" + string(m_szMsgFlagNO) + "'";
	if (SQL_SUCCESS == m_cHvtrofacrcvlist.find(sql) && SQL_SUCCESS ==  m_cHvtrofacrcvlist.fetch())
	{
		m_hvps132.MmbId 			= m_cHvtrofacrcvlist.m_instdindrctpty;	 //发起直接参与者行号
		m_hvps132.OrgnlMsgId		= m_cHvtrofacrcvlist.m_msgid;		  //原报文标识号
		m_hvps132.OrgnlMsgNmId		=  m_cHvtrofacrcvlist.m_msgtp ;// 原报文类型代码
		
		m_hvps132.DtldNbOfTxs		= "1"; //回执明细业务总笔数,固定写1
		m_hvps132.DtldSts			= "ACCP";
		m_hvps132.OrgnlTxId 		= m_cHvtrofacrcvlist.m_msgid;  //原明细标识号
		m_hvps132.AddtlInf1 		= m_cHvtrofacrcvlist.m_instgdrctpty; //原业务发起直接参与者行号
		if (m_rspway == "00") //回执成功
		{
			m_hvps132.OrgnlNbOfTxs		= "1" ; 	   //回执明细业务成功总笔数
			m_hvps132.OrgnlCtrlSum		= m_cHvtrofacrcvlist.m_amount;	  //回执明细业务成功总金额
			m_hvps132.StsId 			= "PR02";	//业务回执状态(PR02-已付款; PR09-已拒绝)
		}else //回执拒绝
		{
			m_hvps132.OrgnlNbOfTxs		= "0" ; 	  //回执明细业务成功总笔数
			m_hvps132.OrgnlCtrlSum		= "0";	  //回执明细业务成功总金额
			m_hvps132.StsId 			= "PR09";	//业务回执状态(PR02-已付款; PR09-已拒绝)
			m_hvps132.Prtry 			= "REJECT";		//业务拒绝处理码，固定填写REJECT
			m_hvps132.AddtlInf1 		= "摩根银行不接受此笔交易"; //业务拒绝原因
		}

	} else {
			PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}
	
	m_cHvtrofacrcvlist.closeCursor();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Exit CSendHvps132::GetData");
    return 0;

}

int CSendHvps132::UpdateState()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps132::UpdateState...");
	m_cHvtrofacrcvlist.m_rspmsgtp 		  = "hvps.132.001.01";
	m_cHvtrofacrcvlist.m_procstate		  = PR_HVBP_07; 			  //处理状态: 07 已回执
	m_cHvtrofacrcvlist.m_busistate		  = PROCESS_PR04;			   // 业务状态:PR04：已清算
	m_cHvtrofacrcvlist.m_msgid			  = m_hvps132.MsgId;
	m_cHvtrofacrcvlist.m_rspway 		  = m_rspway;
	m_cHvtrofacrcvlist.m_rejectcode 	  = m_hvps132.Prtry;
	
	int iRet = m_cHvtrofacrcvlist.setctx(m_dbproc);
	if (RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR,	__FILE__,  __LINE__, m_hvps132.MsgId.c_str(), "setctx error");	
		PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
	}
	GetIsoDateTime(m_dbproc, "HVPS", m_ISODateTime);
	m_cHvtrofacrcvlist.m_rspdate = m_ISODateTime;
	iRet = m_cHvtrofacrcvlist.updatestate();
	if (RTN_SUCCESS != iRet)
	{
		memset(m_szErrMsg, 0, sizeof(m_szErrMsg));
		sprintf(m_szErrMsg, "大额及时转账业务表hv_trofacrcvlist更新数据失败[%s], [%d][%s]", 
			m_hvps132.MsgId.c_str(), iRet, m_cHvtrofacrcvlist.GetSqlErr());
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps132::UpdateState...");
	m_cHvtrofacrcvlist.commit();
	return iRet;
}

int CSendHvps132::doWorkSelf()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps132::doWork...");
	
	GetData();	
	SetData();	
	AddSign132();	
	int iRet = m_hvps132.CreateXml();
	if(RTN_SUCCESS != iRet)        
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CreateXml iRet=%d", iRet);
		    #if 0
        memset(m_szNotify, 0, sizeof(m_szNotify));
        sprintf(m_szNotify, "处理异常:往帐,[%s]", "Create Xml failed");
        InsertUserInfoTel(
					  m_cHvtrofacrcvlist.m_rspmsgid.c_str(),
					  m_cHvtrofacrcvlist.m_instdindrctpty.c_str(),
					  m_cHvtrofacrcvlist.m_instddrctpty.c_str(),
					  m_cHvtrofacrcvlist.m_instgindrctpty.c_str(),
					  m_cHvtrofacrcvlist.m_instgdrctpty.c_str(),
					  "HVPS",
					  "hvps.132.001.01",
					  "2",
					  m_szNotify);
					  #endif
		PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
	}
	
	UpdateState();	
	if (AddQueue(m_hvps132.m_sXMLBuff.c_str(), m_hvps132.m_sXMLBuff.length()))
	{

	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps132::doWork..."); 
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "报文标识号[%s]处理成功", m_hvps132.MsgId.c_str()); 
	
	return RTN_SUCCESS;
}





