/******************************************************************** 
�ļ����� sendcmt105.cpp
�����ˣ� aps-xcm
��  �ڣ� 2011-06-21
�޸��ˣ� 
��  �ڣ� 
��  ���� һ������������м�ͬҵ���֧������
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt105.h"

CSendCmt105::CSendCmt105(const stuMsgHead& Smsg):CSendHvpsBase(Smsg)
{
   
}

CSendCmt105::~CSendCmt105()
{
    
}

void CSendCmt105::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt105::SetDBKey...");

    m_Hvsndlist.m_msgtp = "CMT";
    m_Hvsndlist.m_msgtp = m_Hvsndlist.m_msgtp + m_szMsgType;
    
	m_Hvsndlist.m_msgid = m_szMsgFlagNO; 
	m_Hvsndlist.m_instgindrctpty = m_szSndNO; 

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_msgtp = %s", m_Hvsndlist.m_msgtp.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_msgid = %s", m_Hvsndlist.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_instgindrctpty = %s", m_Hvsndlist.m_instgindrctpty.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt105::SetDBKey...");

}

int CSendCmt105::GetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt105::GetData...");

    SETCTX(m_Hvsndlist);
    SetDBKey();
    int iRet = m_Hvsndlist.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ȡ����ʧ�ܣ� iRet = [%d]", iRet);
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    if(!m_Hvsndlist.m_endtoendid.empty())
    {
        m_sEndtoEnd = m_Hvsndlist.m_endtoendid;
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sEndtoEnd = %s", m_sEndtoEnd.c_str());
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt105::GetData...");
    return iRet;
}


void CSendCmt105::SetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt105::SetData...");

    snprintf(m_cCmt105.sConsigndate, sizeof(m_cCmt105.sConsigndate), m_Hvsndlist.m_consigndate.c_str());

    snprintf(m_cCmt105.sCur, sizeof(m_cCmt105.sCur), m_Hvsndlist.m_currency.c_str());

    m_cCmt105.dAmount = m_Hvsndlist.m_amount;

    snprintf(m_cCmt105.sSendsapbk, sizeof(m_cCmt105.sSendsapbk), m_Hvsndlist.m_dbtmmbid.c_str());

    snprintf(m_cCmt105.sSendbank, sizeof(m_cCmt105.sSendbank), m_Hvsndlist.m_dbtid.c_str());

    snprintf(m_cCmt105.sRecvsapbk, sizeof(m_cCmt105.sRecvsapbk), m_Hvsndlist.m_cdtmmbid.c_str());

    snprintf(m_cCmt105.sRecvbank, sizeof(m_cCmt105.sRecvbank), m_Hvsndlist.m_cdtid.c_str());

    m_cCmt105.iTxssno = atoi(m_szMsgSerial);

    char SndCCPCNode[4 + 1] 	= {0};	
	char RcvCCPCNode[4 + 1] 	= {0};
    GetSapBkToCCPC(m_dbproc, m_Hvsndlist.m_instgdrctpty, SndCCPCNode);
	GetSapBkToCCPC(m_dbproc, m_Hvsndlist.m_instddrctpty, RcvCCPCNode);

	snprintf(m_cCmt105.sSendsenter, sizeof(m_cCmt105.sSendsenter), SndCCPCNode);

	snprintf(m_cCmt105.sRecvsenter, sizeof(m_cCmt105.sRecvsenter), RcvCCPCNode);

    snprintf(m_cCmt105.sTradetype,  sizeof(m_cCmt105.sTradetype), m_Hvsndlist.m_purpprtry.c_str());
    /*
    strncpy(m_cCmt105.sRemark, m_Hvsndlist.m_addinfo.c_str(), sizeof(m_cCmt105.sRemark) - 1);
    */
    SetFieldAsGbk(m_Hvsndlist.m_addinfo, m_cCmt105.sRemark, sizeof(m_cCmt105.sRemark) - 1);

    string strTemp="";

    GetTag1ST("CF3:", strTemp,  m_Hvsndlist.m_ustrdstr); 
    Trace(L_INFO, __FILE__, __LINE__, NULL, "strTemp=[%s]",strTemp.c_str());
    snprintf(m_cCmt105.sInterbankrate,
    		sizeof(m_cCmt105.sInterbankrate), "%07d", atoi(strTemp.c_str()));

    Trace(L_INFO, __FILE__, __LINE__, NULL,
    		"m_cCmt105.sInterbankrate=[%s]",m_cCmt105.sInterbankrate);

    strTemp = "";
    GetTag1ST("CF4:", strTemp,  m_Hvsndlist.m_ustrdstr); 
    snprintf(m_cCmt105.sInterbankdate,
    		sizeof(m_cCmt105.sInterbankdate), strTemp.c_str());

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt105::SetData...");
}
int CSendCmt105::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt105::buildCmtMsg...");

    int iRet = m_cCmt105.CreateCmt("105", m_Hvsndlist.m_instgdrctpty.c_str(), m_Hvsndlist.m_instddrctpty.c_str(), m_sMesgId.c_str(), m_sMesgId.c_str(), m_Hvsndlist.m_workdate.c_str(), m_Hvsndlist.m_sttlmprty.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt105::buildCmtMsg...");
    return iRet;
}
int CSendCmt105::UpdateState()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt105::UpdateState...");

    SETCTX(m_Hvsndlist);

    string strSQL;

    string strNpcMsg = "";
	if(!m_Hvsndlist.write_blob(m_cCmt105.m_strCmtmsg.c_str(), strNpcMsg, SYS_HVPS)){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"д���ֶα�����:[%s]", m_Hvsndlist.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}

    strSQL += "UPDATE hv_sndexchglist t SET t.STATETIME = sysdate, t.PROCSTATE = '";
    strSQL += m_szProState;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
	strSQL += "', t.endtoendid = '";
	strSQL += m_sEndtoEnd;
    strSQL += "', t.npcmsg='";
    strSQL += strNpcMsg;
	strSQL += "' WHERE t.MSGTP = '";
	strSQL += m_Hvsndlist.m_msgtp.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_Hvsndlist.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Hvsndlist.m_instgindrctpty.c_str(); 									
	strSQL += "'";
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "strSQL=[%s]", strSQL.c_str());
    int iRet = m_Hvsndlist.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��iRet=[%d], [%s]", iRet, m_Hvsndlist.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
        
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt105::UpdateState...");
    return iRet;
}
int CSendCmt105::doWorkSelf()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt105::dowork...");
    //1)�������
    GetData();

    //2)��ֵ
    SetData();

    AddMac();
	
    buildCmtMsg();

    
    //3)	ҵ���飨�ͻ������룩
    //.......
    //4)	���������ͻ������룩
    
    strcpy(m_szProState,PR_HVBP_08);//���ҵ��û���Ŷӣ�����״̬����08�ѷ���
    
    FundSettle();

    UpdateState();
    if(strcmp(m_szProState,PR_HVBP_08) == 0)//�������״̬Ϊ�ѷ��ͣ�����Խ�����дMQ
    {
    	AddQueue(m_cCmt105.m_strCmtmsg, m_cCmt105.m_strCmtmsg.length());
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt105::dowork...");
    return RTN_SUCCESS;
    
}

int CSendCmt105::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt105::FundSettle...");
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û�[%s]", m_szOprUser);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_cCmt105.sSendbank);

	m_charge.m_amount = m_cCmt105.dAmount;	//ҵ����
	m_charge.m_iDCFlag = iDEBITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, MBVIRSUALNETID);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_cCmt105.sSendbank);	//������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(iRet == 1)//���ö�Ȳ��㣬ҵ���Ŷ�
	{
		strcpy(m_szProState,PR_HVBP_55); //ҵ���Ŷ�
		iRet = m_charge.IntoPurpList(m_szOprUserNetId,m_Hvsndlist.m_workdate.c_str(),m_Hvsndlist.m_amount,m_Hvsndlist.m_msgid.c_str(),m_Hvsndlist.m_instgindrctpty.c_str(),m_Hvsndlist.m_msgtp.c_str(),"HVPS");
		if(iRet != RTN_SUCCESS)
		{
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�۳������ʽ�ʧ�ܣ�iRet=%d", iRet);
			PMTS_ThrowException(DB_INSERT_FAIL);
		}

		//�ͻ���Ϣ֪ͨ��ҵ���Ŷ�
		InsertUserInfoTel(m_Hvsndlist.m_msgid.c_str(),
			      m_Hvsndlist.m_instgindrctpty.c_str(),
			      m_Hvsndlist.m_instgdrctpty.c_str(),
			      m_Hvsndlist.m_instdindrctpty.c_str(),       
			      m_Hvsndlist.m_instddrctpty.c_str(),       						      
			      "HVPS",
			      m_Hvsndlist.m_msgtp.c_str(),
				  NT_CMIPUR,
				  " ");
	}
	else if(iRet == 2)//���ö�Ȳ��㣬ҵ����Ҫ�Ŷӣ�Ԥ��֪ͨ�ͻ�
	{
		InsertUserInfoTel(m_Hvsndlist.m_msgid.c_str(),
			      m_Hvsndlist.m_instgindrctpty.c_str(),
			      m_Hvsndlist.m_instgdrctpty.c_str(),
			      m_Hvsndlist.m_instdindrctpty.c_str(),       
			      m_Hvsndlist.m_instddrctpty.c_str(),       						      
			      "HVPS",
			      m_Hvsndlist.m_msgtp.c_str(),
				  NT_CMIQUE,
				  " ");
	}
	else if(iRet == -1)        
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�۳������ʽ�ʧ�ܣ�iRet=%d", iRet);
		PMTS_ThrowException(DATA_FAIL);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt105::FundSettle..."); 
    
    return RTN_SUCCESS;
}

int CSendCmt105::AddMac()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt105::AddMac...");
	int iRet = -1;
	
	m_cCmt105.SetSeal();//��ȡ��Ѻ��

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt105.sSendsapbk[%s]",m_cCmt105.sSendsapbk);
	
    iRet = CodeMac(m_dbproc,m_cCmt105.m_Seal.c_str(),m_cCmt105.sSendsapbk,m_cCmt105.m_szMacStr);
    if(0 != iRet)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "AddMac failed");
    	PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]",m_cCmt105.m_szMacStr);
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt105::AddMac..."); 
    
    return RTN_SUCCESS;
}

