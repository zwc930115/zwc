/******************************************************************** 
�ļ����� sendcmt108.cpp
�����ˣ� aps-xcm
��  �ڣ� 2011-06-21
�޸��ˣ� 
��  �ڣ� 
��  ���� һ����������˻�֧������
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt108.h"

CSendCmt108::CSendCmt108(const stuMsgHead& Smsg):CSendHvpsBase(Smsg)
{
   
}

CSendCmt108::~CSendCmt108()
{
    
}

void CSendCmt108::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt108::SetDBKey...");

    m_Hvsndlist.m_msgtp = "CMT";
    m_Hvsndlist.m_msgtp = m_Hvsndlist.m_msgtp + m_szMsgType;
    
	m_Hvsndlist.m_msgid = m_szMsgFlagNO; 
	m_Hvsndlist.m_instgindrctpty = m_szSndNO; 

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_msgtp = %s", m_Hvsndlist.m_msgtp.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_msgid = %s", m_Hvsndlist.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_instgindrctpty = %s", m_Hvsndlist.m_instgindrctpty.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt108::SetDBKey...");
}

int CSendCmt108::GetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt108::GetData...");

    SETCTX(m_Hvsndlist);
    SetDBKey();
    int iRet = m_Hvsndlist.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ȡ����ʧ�ܣ� iRet = [%d]", iRet);
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    if(!m_Hvsndlist.m_endtoendid.empty())
    {
        m_sEndtoEnd = m_Hvsndlist.m_endtoendid;
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sEndtoEnd = %s", m_sEndtoEnd.c_str());
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt108::GetData...");
    return iRet;
    
}

void CSendCmt108::SetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt108::SetData...");

    strncpy(m_cCmt108.sConsigndate, m_Hvsndlist.m_consigndate.c_str(), sizeof(m_cCmt108.sConsigndate) - 1);

    strncpy(m_cCmt108.sCur,         m_Hvsndlist.m_currency.c_str(),    sizeof(m_cCmt108.sCur) - 1);

    m_cCmt108.dAmount = m_Hvsndlist.m_amount;

    strncpy(m_cCmt108.sSendsapbk, m_Hvsndlist.m_dbtmmbid.c_str(), sizeof(m_cCmt108.sSendsapbk) - 1);

    strncpy(m_cCmt108.sSendbank,  m_Hvsndlist.m_dbtid.c_str(),    sizeof(m_cCmt108.sSendbank) - 1);

    strncpy(m_cCmt108.sRecvsapbk, m_Hvsndlist.m_cdtmmbid.c_str(), sizeof(m_cCmt108.sRecvsapbk) - 1);

    strncpy(m_cCmt108.sRecvbank,  m_Hvsndlist.m_cdtid.c_str(),    sizeof(m_cCmt108.sRecvbank) - 1);

    m_cCmt108.iTxssno = atoi(m_szMsgSerial);

    char SndCCPCNode[4 + 1] 	= {0};	

	char RcvCCPCNode[4 + 1] 	= {0};

    GetSapBkToCCPC(m_dbproc, m_Hvsndlist.m_instgdrctpty, SndCCPCNode);

	GetSapBkToCCPC(m_dbproc, m_Hvsndlist.m_instddrctpty, RcvCCPCNode);

	strncpy(m_cCmt108.sSendcenter, SndCCPCNode, sizeof(m_cCmt108.sSendcenter) - 1);

	strncpy(m_cCmt108.sRecvcenter, RcvCCPCNode, sizeof(m_cCmt108.sRecvcenter) - 1);
    
    SetFieldAsGbk(m_Hvsndlist.m_addinfo, m_cCmt108.sRemark, sizeof(m_cCmt108.sRemark) - 1);

    string strTemp="";
    GetTag1ST("051:", strTemp, m_Hvsndlist.m_ustrdstr);
    snprintf(m_cCmt108.sOldconsigndate, sizeof(m_cCmt108.sOldconsigndate), strTemp.c_str());

    strTemp = "";
    GetTag1ST("02B:", strTemp, m_Hvsndlist.m_ustrdstr);
    snprintf(m_cCmt108.sOldcmtno, sizeof(m_cCmt108.sOldcmtno), strTemp.c_str());

    string strOldTxss;
    GetTag1ST("005:", strOldTxss,  m_Hvsndlist.m_ustrdstr);
    m_cCmt108.iOldtxssno = atoi(strOldTxss.substr(8).c_str());

    strTemp = "";
    GetTag1ST("CQ1:", strTemp,  m_Hvsndlist.m_ustrdstr);
    snprintf(m_cCmt108.sOldpayeracc, sizeof(m_cCmt108.sOldpayeracc), strTemp.c_str());

    strTemp = "";
    GetTag1ST("CR1:", strTemp,  m_Hvsndlist.m_ustrdstr); 
    SetFieldAsGbk(strTemp, m_cCmt108.sOldpayername, sizeof(m_cCmt108.sOldpayername) -1);

    strTemp = "";
    GetTag1ST("CQ2:", strTemp,  m_Hvsndlist.m_ustrdstr);
    snprintf(m_cCmt108.sOldpayeeacc, sizeof(m_cCmt108.sOldpayeeacc), strTemp.c_str());

    strTemp = "";
    GetTag1ST("CR2:", strTemp,  m_Hvsndlist.m_ustrdstr); 
    SetFieldAsGbk(strTemp, m_cCmt108.sOldpayeename, sizeof(m_cCmt108.sOldpayeename) -1);
    
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "lLEAVE CSendCmt108::SetData...");
    
}
int CSendCmt108::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt108::buildCmtMsg...");

    int iRet = m_cCmt108.CreateCmt("108", m_Hvsndlist.m_instgdrctpty.c_str(), m_Hvsndlist.m_instddrctpty.c_str(), m_sMesgId.c_str(), m_sMesgId.c_str(), m_Hvsndlist.m_workdate.c_str(), m_Hvsndlist.m_sttlmprty.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt108::buildCmtMsg...");
    return iRet;
}
int CSendCmt108::UpdateState()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt108::UpdateState...");

    SETCTX(m_Hvsndlist);

    string strSQL;

    string strNpcMsg = "";
	if(!m_Hvsndlist.write_blob(m_cCmt108.m_strCmtmsg.c_str(), strNpcMsg, SYS_HVPS)){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"д���ֶα�����:[%s]", m_Hvsndlist.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}

    strSQL += "UPDATE hv_sndexchglist t SET t.STATETIME = sysdate, t.PROCSTATE = '";
    strSQL += m_szProState;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
	strSQL += "', t.endtoendid = '";
	strSQL += m_sEndtoEnd;
    strSQL += "', t.npcmsg='";
    strSQL += strNpcMsg;
	strSQL += "' WHERE t.MSGTP = '";
	strSQL += m_Hvsndlist.m_msgtp.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_Hvsndlist.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Hvsndlist.m_instgindrctpty.c_str(); 									
	strSQL += "'";
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "strSQL=[%s]", strSQL.c_str());
    int iRet = m_Hvsndlist.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��iRet=[%d], [%s]", iRet, m_Hvsndlist.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
        
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt108::UpdateState...");
    return iRet;
}
int CSendCmt108::doWorkSelf()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt108::doworkSelf...");
    //1)�������
    GetData();

    //2)��ֵ
    SetData();

    AddMac();
	
    buildCmtMsg();

    
    //3)	ҵ���飨�ͻ������룩
    //.......
    //4)	���������ͻ������룩
    
    strcpy(m_szProState,PR_HVBP_08);//���ҵ��û���Ŷӣ�����״̬����08�ѷ���
    
    FundSettle();

    UpdateState();

    if(strcmp(m_szProState,PR_HVBP_08) == 0)//�������״̬Ϊ�ѷ��ͣ�����Խ�����дMQ
    {
    	AddQueue(m_cCmt108.m_strCmtmsg, m_cCmt108.m_strCmtmsg.length());
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt108::doworkSelf...");
    return RTN_SUCCESS;
    
}

int CSendCmt108::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt108::FundSettle...");
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û�[%s]", m_szOprUser);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_cCmt108.sSendbank);

	m_charge.m_amount = m_cCmt108.dAmount;	//ҵ����
	m_charge.m_iDCFlag = iDEBITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, MBVIRSUALNETID);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_cCmt108.sSendbank);	//������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(iRet == 1)//���ö�Ȳ��㣬ҵ���Ŷ�
	{
		strcpy(m_szProState,PR_HVBP_55); //ҵ���Ŷ�
		iRet = m_charge.IntoPurpList(m_szOprUserNetId,m_Hvsndlist.m_workdate.c_str(),m_Hvsndlist.m_amount,m_Hvsndlist.m_msgid.c_str(),m_Hvsndlist.m_instgindrctpty.c_str(),m_Hvsndlist.m_msgtp.c_str(),"HVPS");
		if(iRet != RTN_SUCCESS)
		{
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�۳������ʽ�ʧ�ܣ�iRet=%d", iRet);
			PMTS_ThrowException(DB_INSERT_FAIL);
		}

		//�ͻ���Ϣ֪ͨ��ҵ���Ŷ�
		InsertUserInfoTel(m_Hvsndlist.m_msgid.c_str(),
			      m_Hvsndlist.m_instgindrctpty.c_str(),
			      m_Hvsndlist.m_instgdrctpty.c_str(),
			      m_Hvsndlist.m_instdindrctpty.c_str(),       
			      m_Hvsndlist.m_instddrctpty.c_str(),       						      
			      "HVPS",
			      m_Hvsndlist.m_msgtp.c_str(),
				  NT_CMIPUR,
				  " ");
	}
	else if(iRet == 2)//���ö�Ȳ��㣬ҵ����Ҫ�Ŷӣ�Ԥ��֪ͨ�ͻ�
	{
		InsertUserInfoTel(m_Hvsndlist.m_msgid.c_str(),
			      m_Hvsndlist.m_instgindrctpty.c_str(),
			      m_Hvsndlist.m_instgdrctpty.c_str(),
			      m_Hvsndlist.m_instdindrctpty.c_str(),       
			      m_Hvsndlist.m_instddrctpty.c_str(),       						      
			      "HVPS",
			      m_Hvsndlist.m_msgtp.c_str(),
				  NT_CMIQUE,
				  " ");
	}
	else if(iRet == -1)        
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�۳������ʽ�ʧ�ܣ�iRet=%d", iRet);
		PMTS_ThrowException(DATA_FAIL);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt108::FundSettle..."); 
    
    return RTN_SUCCESS;
}

int CSendCmt108::AddMac()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt108::AddMac...");
	int iRet = -1;
	
	m_cCmt108.SetSeal();//��ȡ��Ѻ��

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt108.sSendsapbk[%s]",m_cCmt108.sSendsapbk);
	
    iRet = CodeMac(m_dbproc,m_cCmt108.m_Seal.c_str(),m_cCmt108.sSendsapbk,m_cCmt108.m_szMacStr);
    if(0 != iRet)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "AddMac failed");
    	PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]",m_cCmt108.m_szMacStr);
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt108::AddMac..."); 
    
    return RTN_SUCCESS;
}
