/******************************************************************** 
�ļ����� sendhvps153.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
    
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendhvps153.h"

CSendHvps153::CSendHvps153(const stuMsgHead& Smsg):CSendHvpsBase(Smsg)
{

}

CSendHvps153::~CSendHvps153()
{
}

void CSendHvps153::AddSign153()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendHvps153::AddSign153");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_cParser153.getOriSignStr();
	
	AddSign(m_cParser153.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_cParser153.InstgDrctPty.c_str());
	
	m_cParser153.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendHvps153::AddSign153");
}

int CSendHvps153::doWorkSelf()
{
   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps153::doWork...");
    int iRet = 0;
    
    GetData();
    
    SetData();

    //��ǩ
    if(2 == m_iVersion)
    {
        AddSign153();
    }
    
    iRet = m_cParser153.CreateXml();
    if(RTN_SUCCESS != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }

    //3)	ҵ���飨�ͻ������룩
    //.......
    //4)	���������ͻ������룩
    //.....    
    UpdateState();
    
    AddQueue(m_cParser153.m_sXMLBuff.c_str(), m_cParser153.m_sXMLBuff.length());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps153::doWork..."); 
    return RTN_SUCCESS;
}


void CSendHvps153::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps153::SetData...");
    
	char szBuff[128]                 = {0};
    int iRet = GetIsoDateTime(m_dbproc, SYS_HVPS, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }

    m_cParser153.MsgId = m_cHvdraft.m_msgid;
    m_cParser153.CreDtTm = m_ISODateTime ;
    m_cParser153.InstgDrctPty = m_cHvdraft.m_instgdrctpty ;
    m_cParser153.GrpHdrInstgPty = m_cHvdraft.m_instgindrctpty;
    m_cParser153.InstdDrctPty = m_cHvdraft.m_instddrctpty ;
    m_cParser153.GrpHdrInstdPty = m_cHvdraft.m_instdindrctpty;
    m_cParser153.SysCd = "HVPS" ;
    m_cParser153.Rmk = m_cHvdraft.m_reserve;
    m_cParser153.Dt  = m_cHvdraft.m_drftdt;
    m_cParser153.Nb  = m_cHvdraft.m_drftnb;
    m_cParser153.TstCd = itoa(szBuff, m_cHvdraft.m_drfttstcd, 0); ;
    m_cParser153.Tp  = m_cHvdraft.m_drfttp ;
    memset(szBuff, 0, sizeof(szBuff));
    m_cParser153.Amt = ftoa(szBuff, m_cHvdraft.m_amount, 2) ;
    m_cParser153.Ccy = m_cHvdraft.m_ccy ;
    m_cParser153.IssrBk  = m_cHvdraft.m_drftissrbk ;
    m_cParser153.OrgnlPmtBk = m_cHvdraft.m_ocashdfpty;//ԭ�ֽ��Ʊ�Ҹ���
    m_cParser153.RcvrNm  = m_cHvdraft.m_drftrcvrnm ;

    m_cParser153.CreateXMlHeader("HVPS",                        \
                                m_cHvdraft.m_wrkdate.c_str(), \
                                m_cHvdraft.m_instgdrctpty.c_str(),\
                                m_cHvdraft.m_instddrctpty.c_str(),\
                                "hvps.153.001.01",\
                                m_sMesgId.c_str()); 

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps153::SetData...");
    return;
}

void CSendHvps153::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps153::SetDBKey...");

	m_cHvdraft.m_msgid = m_szMsgFlagNO; 
	m_cHvdraft.m_instgindrctpty = m_szSndNO; 
    m_cHvdraft.m_msgtp= "hvps.153.001.01";

    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_msgid = %s", m_cHvdraft.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_instgindrctpty = %s", m_cHvdraft.m_instgindrctpty.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_msgtp = %s", m_cHvdraft.m_msgtp.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps153::SetDBKey...");
    return;
}

int CSendHvps153::GetData()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps153::GetData...");

	SetDBKey();
	
	SETCTX(m_cHvdraft);
	int iRet = m_cHvdraft.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ�� iRet = %d, %s", iRet, m_cHvdraft.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps153::GetData...");
	return iRet;
}

int CSendHvps153::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps153::UpdateState...");
    
    SetDBKey();
    string strSQL;
	strSQL += "UPDATE hv_draft t SET t.STATETIME = sysdate, t.PROCSTATE = '";
    strSQL += PR_HVBP_08;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
    strSQL += "' ";
    
	strSQL += " WHERE t.MSGTP = '";
	strSQL += m_cHvdraft.m_msgtp.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_cHvdraft.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_cHvdraft.m_instgindrctpty.c_str(); 									
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	
    SETCTX(m_cHvdraft);
    int iRet = m_cHvdraft.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ�� iRet = %d, %s", iRet, m_cHvdraft.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps153::UpdateState...");
    return iRet;
}



