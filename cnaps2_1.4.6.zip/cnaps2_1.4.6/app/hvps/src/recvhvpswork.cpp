
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "pubfunc.h"
#include "logger.h"
#include "recvhvpswork.h"
#include "recvhvpsbase.h"
#include "recvhvps111.h"
#include "recvhvps112.h"
//add by zwc 20171108
#include "recvhvps115.h" 
#include "recvhvps116.h"
#include "recvhvps117.h"
#include "recvhvps118.h" 
//add end 
#include "recvhvps141.h"
#include "recvhvps141.002.h"
#include "recvhvps142.h"
#include "recvhvps144.h"
#include "recvhvps152.h"
#include "recvhvps151.h"
#include "recvhvps153.h"
#include "recvhvps154.h"
#include "recvhvps632.h"
#include "recvhvps633.h"
#include "recvhvps635.h"
#include "hvrecvmsg.h"
#include "recvhvps711.h"
#include "recvhvps713.h"
#include "recvhvps715.h"
#include "recvhvps716.h"
#include "recvcmt100.h"
#include "recvcmt101.h"
#include "recvcmt102.h"
#include "recvcmt103.h"
#include "recvcmt105.h"
#include "recvcmt108.h"
#include "recvcmt110.h"
#include "recvcmt121.h"
#include "recvcmt122.h"
#include "recvcmt123.h"
#include "recvcmt124.h"
#include "recvcmt253.h"
#include "recvcmt231.h"
#include "recvcmt232.h"
#include "recvcmt233.h"
#include "recvcmt234.h"
#include "recvcmt725.h"
#include "recvcmt841.h"

using namespace ZFPT;

extern CConnectPool *g_DBConnPool;
extern int		g_IsConnPlatm;

CRecvHvpsWork::CRecvHvpsWork()
{
    m_sTrsCode    = "";
    m_sMsgFile    = "";
    m_strRcvMsgID = "";
}

CRecvHvpsWork::~CRecvHvpsWork()
{

}

void CRecvHvpsWork::setData(LPTSTR lpMsgID, int iErrMsgFlag, UINT32 len, LPCSTR data, LPCSTR lpTrsCode, LPCSTR lpMsgFile)
{    
    if(NULL != data && 0 != len)
    {
        m_vData.resize(len + 1, 0);
    
        memset(&m_vData[0], 0, len * sizeof(char));
        memcpy(&m_vData[0], data, len);
    }
    
    if(lpTrsCode != NULL)
    {
        m_sTrsCode = lpTrsCode;
    }
    
    if(lpMsgFile != NULL)
    {
        m_sMsgFile = lpMsgFile;
    }
    
    if (NULL != lpMsgID)
    {
        m_strRcvMsgID = lpMsgID;
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_strRcvMsgID = %s", m_strRcvMsgID.c_str());
    }

    m_iErrMsgFlag = iErrMsgFlag;
    
}

void CRecvHvpsWork::clear()
{

}

INT32 CRecvHvpsWork::doWork()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvpsWork::doWork()");

    // 大报文消息没传过来，需要从来帐通讯表取消息
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_vData.size() = %d ", m_vData.size());
    int iRet		= -1;
	int iBizCode	= -1; 
	int iBizSubCode = -1;
	int iBizVersion = -1;
	int iVersion	= -1;
	
//     if (0 == m_vData.size())
//     {
//         Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "0 == m_vData.size()");
// 
//         iRet = GetMsg();
//         if (0 != iRet)
//         {
//             return RTN_FAIL;
//         }
// 
//         Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "GetMsg()success");
//     }     
//     

    //取业务码   
	iBizCode = GetBizCodeEx(&m_vData[0], iBizSubCode, iBizVersion, iVersion);
    if (-1 == iBizCode)
    {
        return RTN_FAIL;
    }
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iBizCode = %d/%d/%d[%d]", iBizCode, iBizSubCode, iBizVersion, iVersion);

    char szchBizCode[MAX_BIZ_CODE_LEN + 1] = {0};  // 业务码
    sprintf(szchBizCode, "%d", iBizCode);

    CRecvHvpsBase *pRecvHvps = NULL;

    switch( iBizCode )
    {
        case HV_1ST_100:               
            {
                pRecvHvps = new CRecvCmt100;
				break;
            }
        case HV_1ST_101:               
            {
                pRecvHvps = new CRecvCmt101;
				break;
            }           
        case HV_1ST_102:               
            {
                pRecvHvps = new CRecvCmt102;
				break;
            }     
        case HV_1ST_103:               
            {
                pRecvHvps = new CRecvCmt103;
				break;
            }  
        case HV_1ST_105:               
            {
                pRecvHvps = new CRecvCmt105;
				break;
            } 
        case HV_1ST_108:               
            {
                pRecvHvps = new CRecvCmt108;
				break;
            }
        case HV_1ST_110:
            {
                pRecvHvps = new CRecvCmt110;
				break;
            }
        case HV_1ST_121:
            {
                pRecvHvps = new CRecvCmt121;
				break;
            }
        case HV_1ST_122:
            {
                pRecvHvps = new CRecvCmt122;
				break;
            }
        case HV_1ST_123:
            {
                pRecvHvps = new CRecvCmt123;
				break;
            }
        case HV_1ST_124:
            {
                pRecvHvps = new CRecvCmt124;
				break;
            }
        case HV_1ST_231:
            {
                pRecvHvps = new CRecvCmt231;
				break;
            }
        case HV_1ST_232:
            {
                pRecvHvps = new CRecvCmt232;
				break;
            }
        case HV_1ST_233:
            {
                pRecvHvps = new CRecvCmt233;
				break;
            }
        case HV_1ST_234:
            {
                pRecvHvps = new CRecvCmt234;
				break;
            }
        case SP_1ST_253:               
            {
                pRecvHvps = new CRecvCmt253;
								break;
            }           
        case HV_2ND_111:
            {
                pRecvHvps = new CRecvHvps111;
				break;
            }  
        case HV_2ND_112:
            {
                pRecvHvps = new CRecvHvps112;
				break;
            } 
		//add by zwc 20171108
		case HV_2ND_115:
            {
                pRecvHvps = new CRecvHvps115;
				break;
            } 
		case HV_2ND_116:
            {
                pRecvHvps = new CRecvHvps116;
				break;
            } 
		case HV_2ND_118:
            {
                pRecvHvps = new CRecvHvps118;
				break;
            } 
		//add end
        case HV_2ND_141:
            {
            	if (iBizSubCode == 1)
                	pRecvHvps = new CRecvHvps141;
				else if (iBizSubCode == 2)
					pRecvHvps = new CRecvHvps141_002;
				else
            		return RTN_FAIL;
				break;
            }           
        case HV_2ND_142:
            {
                pRecvHvps = new CRecvHvps142;
				break;
            }            
        case HV_2ND_144:
            {
                pRecvHvps = new CRecvHvps144;
				break;
            }       
        case HV_2ND_151:
            {
                pRecvHvps = new CRecvHvps151;
				break;
            } 		
		case HV_2ND_152:
            {
                pRecvHvps = new CRecvHvps152;
				break;
            }
		case HV_2ND_153:
            {
                pRecvHvps = new CRecvHvps153;
				break;
            }		
		case HV_2ND_154:
            {
                pRecvHvps = new CRecvHvps154;
				break;
            }
        case HV_2ND_632:
            {
                pRecvHvps = new CRecvHvps632;
				break;
            }
        case HV_2ND_633:
            {
                pRecvHvps = new CRecvHvps633;
				break;
            }
        case HV_2ND_635:
            {
                pRecvHvps = new CRecvHvps635;
				break;
            }
        case HV_2ND_711:
            {
                pRecvHvps = new CRecvHvps711;
				break;
            }
        case HV_2ND_713:
            {
                pRecvHvps = new CRecvHvps713;
				break;
            }
        case HV_2ND_715:
            {
                pRecvHvps = new CRecvHvps715;
				break;
            }
        case HV_2ND_716:
            {
                pRecvHvps = new CRecvHvps716;
                break;
            }
        case HV_1ST_725:
            {
                pRecvHvps = new CRecvCmt725;
				break;
            }
        case HV_1ST_841:
            {
                pRecvHvps = new CRecvCmt841;
				break;
            }            
        default:
            return RTN_FAIL;
    }

    pRecvHvps->m_strBizCode  = szchBizCode;
    pRecvHvps->m_strRcvMsgID = m_strRcvMsgID;
    pRecvHvps->m_iErrMsgFlag = m_iErrMsgFlag;
    pRecvHvps->m_iMsgVer	 = iVersion;

    if (iBizCode == HV_2ND_141 && iBizSubCode == 2)
        ZFPTLOG.SetLogInfo("141.002", "");
    else
        ZFPTLOG.SetLogInfo(pRecvHvps->m_strBizCode.c_str(), "");

    pRecvHvps->doWork(&m_vData[0]);
    if (NULL != pRecvHvps)
    {
        delete pRecvHvps;
        pRecvHvps = NULL;
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecv::doWork()");

    return RTN_SUCCESS;
}

/******************************************************************************
*  Function:   GetMsg
*  Description:从来帐通讯表取消息
*  Input:	   无
*  Output:	   
*  Return:	   0   : 操作成功,
			   其他: 操作失败
*  Others:	   无
*  Author:	   zys
*  Date:	   2011-02-21
*******************************************************************************/
INT32 CRecvHvpsWork::GetMsg(void)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "entering CRecvHvpsWork::GetMsg()");

    int    iRet = RTN_FAIL;
    DBProc cDBProc;
    
    // 获取数据库连接
    iRet = g_DBConnPool->GetConnect(cDBProc);
    if(0 != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "GetConnect failed");
    
        return iRet;
    }

    CHvrecvmsg cHvrecvmsg;
    iRet= cHvrecvmsg.setctx(cDBProc);
    if (0 != iRet)
    {
        g_DBConnPool->PutConnect(cDBProc);//释放连接
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "cHvrecvmsg.setctx error[%d]", iRet);
        return iRet;
    }

    cHvrecvmsg.m_msgid  = m_strRcvMsgID;
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_strRcvMsgID = %s", m_strRcvMsgID.c_str());

    // 从来帐通讯表取消息
    iRet = cHvrecvmsg.findByPK();
    if (RTN_SUCCESS == iRet)
    {
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "pRecvmsg->findByPK() 成功");	
    	m_vData.resize(cHvrecvmsg.m_msgtext.length() + 1, 0);	
    	memset(&m_vData[0], 0, cHvrecvmsg.m_msgtext.length() * sizeof(char));
        memcpy(&m_vData[0], cHvrecvmsg.m_msgtext.c_str(), cHvrecvmsg.m_msgtext.length());
    }
    else
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "cHvrecvmsg.findByPKfailed[%d]", iRet);
    }

    //释放连接
    g_DBConnPool->PutConnect(cDBProc);

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "leaving CRecvHvpsWork::GetMsg()");

    return iRet;
}


