/******************************************************************** 
�ļ����� send151.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
    
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendhvps151.h"

CSendHvps151::CSendHvps151(const stuMsgHead& Smsg):CSendHvpsBase(Smsg)
{
 
}

CSendHvps151::~CSendHvps151()
{
    
}

void CSendHvps151::AddSign151()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendHvps151::AddSign151");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_cParser151.getOriSignStr();
	
	AddSign(m_cParser151.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_cParser151.InstgDrctPty.c_str());
	
	m_cParser151.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendHvps151::AddSign151");
}

void CSendHvps151::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps151::SetData...");
    
    char szBuff[128]                 = {0};
    m_cParser151.MsgId    = m_CHvdraft.m_msgid;
    m_cParser151.SysCd    = "HVPS";
    m_cParser151.ActlSttlmAmtCcy    = m_CHvdraft.m_ccy;
    m_cParser151.InstdDrctPty    = m_CHvdraft.m_instddrctpty;
    m_cParser151.RmngAmt    = ftoa(szBuff, m_CHvdraft.m_rmngamt, 2);
    m_cParser151.GrpHdrInstdPty = m_CHvdraft.m_instdindrctpty;
    m_cParser151.HldrBk    = m_CHvdraft.m_drfthldrbk;
    m_cParser151.RmngAmtCcy    = m_CHvdraft.m_ccy;
    m_cParser151.InstgDrctPty    = m_CHvdraft.m_instgdrctpty;
    memset(szBuff, 0, sizeof(szBuff));
    m_cParser151.ActlSttlmAmt    = ftoa(szBuff, m_CHvdraft.m_actlsttlmamt, 2);
    m_cParser151.GrpHdrInstgPty = m_CHvdraft.m_instgindrctpty;
    memset(szBuff, 0, sizeof(szBuff));
    m_cParser151.TstCd    = itoa(szBuff, m_CHvdraft.m_drfttstcd, 0);
    m_cParser151.Nb    = m_CHvdraft.m_drftnb;
    memset(szBuff, 0, sizeof(szBuff));
    m_cParser151.Amt    = ftoa(szBuff, m_CHvdraft.m_amount, 2);
    m_cParser151.Tp    = m_CHvdraft.m_drfttp;
    m_cParser151.IssrBk    = m_CHvdraft.m_drftissrbk;
    m_cParser151.HldrAcct    = m_CHvdraft.m_drfthldracct;
    m_cParser151.Dt    = m_CHvdraft.m_drftdt;
    //m_cParser151.IssrAcct    = m_CHvdraft.m_drftissracct;
    m_cParser151.HldrNm    = m_CHvdraft.m_drfthldrnm;
    m_cParser151.AmtCcy    = m_CHvdraft.m_ccy;
    m_cParser151.Rmk    = m_CHvdraft.m_reserve;
    
    int iRet = GetIsoDateTime(m_dbproc, SYS_HVPS, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }
    
    m_cParser151.CreDtTm    = m_ISODateTime;
    m_cParser151.RmndDtPmt    = m_CHvdraft.m_rmnddtpmt;
    //m_cParser151.IssrNm    = m_CHvdraft.m_drftissrnm;
    m_cParser151.RcvrNm    = m_CHvdraft.m_drftrcvrnm;   
    
    // ���ļ�ͷ
    m_cParser151.CreateXMlHeader("HVPS",                        \
                                m_CHvdraft.m_wrkdate.c_str(), \
                                m_CHvdraft.m_instgdrctpty.c_str(),\
                                m_CHvdraft.m_instddrctpty.c_str(),\
                                "hvps.151.001.01",              \
                                m_sMesgId.c_str());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps151::SetData...");
    return;
}

void CSendHvps151::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps151::SetDBKey...");

    m_CHvdraft.m_msgtp= "hvps.151.001.01";

	m_CHvdraft.m_msgid = m_szMsgFlagNO; 
	m_CHvdraft.m_instgindrctpty = m_szSndNO; 

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_CHvdraft.m_msgtp = %s", m_CHvdraft.m_msgtp.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_CHvdraft.m_msgid = %s", m_CHvdraft.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_CHvdraft.m_instgindrctpty = %s", m_CHvdraft.m_instgindrctpty.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps151::SetDBKey...");
    return;
}

int CSendHvps151::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps151::GetData...");
    
    SETCTX(m_CHvdraft);
    SetDBKey();
    int iRet = m_CHvdraft.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ�� iRet = %d, %s", iRet, m_CHvdraft.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps151::GetData...");
    return iRet;
}

int CSendHvps151::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps151::UpdateState...");
    
    if(0 != m_CHvdraft.setctx(m_dbproc))
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��");    
        return DB_GET_DATA_FAIL;
    }
    SetDBKey();
   
    string strSQL;
	strSQL += "UPDATE hv_draft t SET t.STATETIME = sysdate, t.PROCSTATE = '";
	strSQL += PR_HVBP_08;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
    strSQL += "' ";
    
	strSQL += " WHERE t.MSGTP = '";
	strSQL += m_CHvdraft.m_msgtp.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_CHvdraft.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_CHvdraft.m_instgindrctpty.c_str(); 									
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	
    int iRet = m_CHvdraft.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ�� iRet = %d, %s", iRet, m_CHvdraft.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps151::UpdateState...");
    return iRet;
}

int CSendHvps151::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps151::doWork...");
    
    GetData();
    
    SetData();

    //��ǩ
    if(2 == m_iVersion)
    {
        AddSign151();
    }
    
    int iRet = m_cParser151.CreateXml();
    if(RTN_SUCCESS != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    //3)	ҵ���飨�ͻ������룩
    //.......
    //4)	���������ͻ������룩
    //.....    
    UpdateState();
    
    AddQueue(m_cParser151.m_sXMLBuff.c_str(), m_cParser151.m_sXMLBuff.length());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps151::doWork..."); 
    return RTN_SUCCESS;
}


