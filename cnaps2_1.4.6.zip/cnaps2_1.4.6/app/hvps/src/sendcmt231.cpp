/******************************************************************** 
�ļ����� sendcmt231.cpp
�����ˣ� aps-xcm
��  �ڣ� 2011-06-27
�޸��ˣ� 
��  �ڣ� 
��  ���� һ��������˼�ʱת�˱���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/


#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt231.h"

CSendCmt231::CSendCmt231(const stuMsgHead& Smsg):CSendHvpsBase(Smsg)
{
   
}

CSendCmt231::~CSendCmt231()
{
    
}

void CSendCmt231::SetDBKey()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt231::SetDBKey...");

    m_Hvtrofacsndlist.m_msgid = m_szMsgFlagNO;
    m_Hvtrofacsndlist.m_instgindrctpty = m_szSndNO;

    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "m_Hvtrofacsndlist.m_msgid = [%s]", m_Hvtrofacsndlist.m_msgid.c_str());
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "m_Hvtrofacsndlist.m_instgdrctpty = [%s]", m_Hvtrofacsndlist.m_instgindrctpty.c_str());

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt231::SetDBKey...");
}


int CSendCmt231::GetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt231::GetData...");

    SETCTX(m_Hvtrofacsndlist);
    SetDBKey();

    int iRet = m_Hvtrofacsndlist.findByPK();

    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ȡ����ʧ��iRet[%d][%s]", iRet, m_Hvtrofacsndlist.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    return iRet;
}


void CSendCmt231::SetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt231::SetData...");
    
    strncpy(m_cCmt231.sConsigndate, m_Hvtrofacsndlist.m_consigndate.c_str(), sizeof(m_cCmt231.sConsigndate) - 1);
    strncpy(m_cCmt231.sBankcode, m_Hvtrofacsndlist.m_spjoinmmbid.c_str(), sizeof(m_cCmt231.sBankcode) - 1);
    m_cCmt231.iTxsbatno = atoi(m_Hvtrofacsndlist.m_tranmunum.c_str());
    strncpy(m_cCmt231.sOprttype, m_Hvtrofacsndlist.m_purpprtry.c_str(), sizeof(m_cCmt231.sOprttype) - 1);
    strncpy(m_cCmt231.sCur, m_Hvtrofacsndlist.m_currency.c_str(), sizeof(m_cCmt231.sCur) - 1);
    m_cCmt231.dAmount = m_Hvtrofacsndlist.m_amount;
    strncpy(m_cCmt231.sOsdficode, m_Hvtrofacsndlist.m_dbtid.c_str(), sizeof(m_cCmt231.sOsdficode) -1);//������к� �?= �������к�
    strncpy(m_cCmt231.sPayopenbk, m_Hvtrofacsndlist.m_dbtrissr.c_str(), sizeof(m_cCmt231.sPayopenbk) - 1);
    strncpy(m_cCmt231.sPayeracc, m_Hvtrofacsndlist.m_dbtracctid.c_str(), sizeof(m_cCmt231.sPayeracc) - 1);
    strncpy(m_cCmt231.sPayername, m_Hvtrofacsndlist.m_dbtnm.c_str(), sizeof(m_cCmt231.sPayername) - 1);
    strncpy(m_cCmt231.sIsdficode, m_Hvtrofacsndlist.m_cdtid.c_str(), sizeof(m_cCmt231.sIsdficode) - 1);//���������к��?=�տ��к�
    strncpy(m_cCmt231.sPayeeacc, m_Hvtrofacsndlist.m_cdtracctid.c_str(), sizeof(m_cCmt231.sPayeeacc) -1);
    strncpy(m_cCmt231.sPayeename, m_Hvtrofacsndlist.m_cdtrnm.c_str(), sizeof(m_cCmt231.sPayeename) - 1);
    strncpy(m_cCmt231.sPayeeopenbk, m_Hvtrofacsndlist.m_cdtrissr.c_str(), sizeof(m_cCmt231.sPayeeopenbk) - 1);
    m_cCmt231.iTxssno = atoi(m_szMsgSerial);

    string strTemp;
    GetTag1ST("CCF:", strTemp, m_Hvtrofacsndlist.m_ustrdstr);
    strncpy(m_cCmt231.sOsdficodeccpc, strTemp.c_str(), sizeof(m_cCmt231.sOsdficodeccpc) -1);
    strTemp.erase();
    GetTag1ST("CCG:", strTemp, m_Hvtrofacsndlist.m_ustrdstr);
    strncpy(m_cCmt231.sIsdficodeccpc, strTemp.c_str(), sizeof(m_cCmt231.sIsdficodeccpc) -1);
    strTemp.erase();
    GetTag1ST("CF1:", strTemp, m_Hvtrofacsndlist.m_ustrdstr);
    strncpy(m_cCmt231.sBondcode, strTemp.c_str(), sizeof(m_cCmt231.sBondcode) -1);
    strTemp.erase();
    GetTag1ST("CNM:", strTemp, m_Hvtrofacsndlist.m_ustrdstr);
    m_cCmt231.dBondamount = atoi(strTemp.c_str());
    strTemp.erase();
    GetTag1ST("CNQ:", strTemp, m_Hvtrofacsndlist.m_ustrdstr);
    m_cCmt231.dSetamount = atoi(strTemp.c_str());
    strTemp.erase();
    GetTag1ST("CJ8:", strTemp, m_Hvtrofacsndlist.m_ustrdstr);
    strncpy(m_cCmt231.sSetdate, strTemp.c_str(), sizeof(m_cCmt231.sSetdate) - 1);
    strTemp.erase();
    GetTag1ST("CNR:", strTemp, m_Hvtrofacsndlist.m_ustrdstr);
    m_cCmt231.dSetrate = atoi(strTemp.c_str());
    strTemp.erase();
    GetTag1ST("CF2:", strTemp, m_Hvtrofacsndlist.m_ustrdstr);
    strncpy(m_cCmt231.sBondordercode, strTemp.c_str(), sizeof(m_cCmt231.sBondordercode) -1);
    strTemp.erase();
    GetTag1ST("CNN:", strTemp, m_Hvtrofacsndlist.m_ustrdstr);
    m_cCmt231.dNetamount = atoi(strTemp.c_str());
    strTemp.erase();
    GetTag1ST("CNP:", strTemp, m_Hvtrofacsndlist.m_ustrdstr);
    m_cCmt231.dBondrate = atoi(strTemp.c_str());

    strncpy(m_cCmt231.sRemark, m_Hvtrofacsndlist.m_reserve.c_str(), sizeof(m_cCmt231.sRemark) -1);
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt231::SetData...");
    
}

int CSendCmt231::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt231::buildCmtMsg...");

    int iRet = m_cCmt231.CreateCmt("231", m_Hvtrofacsndlist.m_instgdrctpty.c_str(), m_Hvtrofacsndlist.m_instddrctpty.c_str(), m_sMesgId.c_str(), m_sMesgId.c_str(), m_Hvtrofacsndlist.m_workdate.c_str(), "0");
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt231::buildCmtMsg...");
    return iRet;
}
int CSendCmt231::UpdateState()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt231::UpdateState...");

    SETCTX(m_Hvtrofacsndlist);

    string strSQL;

    strSQL += "UPDATE hv_trofacsndlist t SET t.STATETIME = sysdate, t.PROCSTATE = '08'";
	strSQL += ", t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
	strSQL += "', t.endtoendid = '";
	strSQL += m_sEndtoEnd;
    strSQL += "' ";
    
    strSQL += " WHERE t.MSGID = '";
	strSQL += m_Hvtrofacsndlist.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Hvtrofacsndlist.m_instgindrctpty.c_str(); 									
	strSQL += "'";
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "strSQL=[%s]", strSQL.c_str());
    int iRet = m_Hvtrofacsndlist.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��iRet=[%d], [%s]", iRet, m_Hvtrofacsndlist.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
        
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt231::UpdateState...");
    return iRet;
}


int CSendCmt231::doWorkSelf()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt231::doworkSelf...");
    //1)�������
    GetData();

    //2)��ֵ
    SetData();

    AddMac();
	
    buildCmtMsg();
    
    //3)	ҵ���飨�ͻ������룩
    //.......
    //4)	���������ͻ������룩
    FundSettle();

    UpdateState();

    AddQueue(m_cCmt231.m_strCmtmsg, m_cCmt231.m_strCmtmsg.length());
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt231::doworkSelf...");
    return RTN_SUCCESS;
    
}

int CSendCmt231::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt231::FundSettle...");
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û�[%s]", m_szOprUser);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_cCmt231.GetHeadStartAddr());

	m_charge.m_amount = m_cCmt231.dAmount;	//ҵ����
	m_charge.m_iDCFlag = iDEBITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, MBVIRSUALNETID);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_cCmt231.GetHeadStartAddr());	//������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(RTN_SUCCESS != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FundSettle iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt231::FundSettle..."); 
    
    return RTN_SUCCESS;
}


int CSendCmt231::AddMac()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt231::AddMac...");
	int iRet = -1;
	
	m_cCmt231.SetSeal();//��ȡ��Ѻ��

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt231.sSendsapbk[%s]",m_cCmt231.sOsdficode);
	
    iRet = CodeMac(m_dbproc,m_cCmt231.m_Seal.c_str(),m_cCmt231.sOsdficode,m_cCmt231.m_szMacStr);
    if(0 != iRet)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "AddMac failed");
    	PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]",m_cCmt231.m_szMacStr);
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt231::AddMac..."); 
    
    return RTN_SUCCESS;
}

