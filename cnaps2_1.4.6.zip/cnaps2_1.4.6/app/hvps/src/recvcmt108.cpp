/******************************************************************** 
�ļ����� recvcmt108.cpp
�����ˣ� aps-lel
��  �ڣ� 2011-05-20
�޸��ˣ� 
��  �ڣ� 
��  ���� ������˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvcmt108.h"

using namespace ZFPT;

CRecvCmt108::CRecvCmt108()
{
    m_strMsgTp = "CMT108";
    m_strMsgDirect = "";
}


CRecvCmt108::~CRecvCmt108()
{

}

INT32 CRecvCmt108::Work(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt108::doWork()");

    // 1.��������
    unPack(pchMsg);
    
    // 2.��m_cHvrcvexchglist�ĳ�Ա��ֵ
    SetData(pchMsg);

	//��Ѻ
	ChkMac();

    // 3.����������ʻ����ϸ��hv_rcvexchglist����������
    InsertData();


    if(m_cHvrcvexchglist.m_procstate == PR_HVBP_19)
    {
		UpdateOrgData();
	}
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt108::doWork()");

    return RTN_SUCCESS;
}

INT32 CRecvCmt108::unPack(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt108::unPack()");
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "receive msg = [%s]",pchMsg);
    // 1�������Ƿ�Ϊ��
    if (NULL == pchMsg || '\0' == pchMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_strBizCode.c_str(), "����Ϊ��");
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }
    
    int iRet = RTN_FAIL;
    
    // 3����������
    iRet = m_cCmt108.ParseCmt(pchMsg);

    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CRecvCmt108::Work(): ��������ʧ��");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������!");
    }
    
    char szTxssno[9] = {0};
    sprintf(szTxssno,"%08d",m_cCmt108.iTxssno);    
    // ���ı�ʶ��,����д�����ļ�����
    m_strMsgID = m_cCmt108.sConsigndate;
    m_strMsgID += szTxssno;
    //ZFPTLOG.SetLogInfo("108",m_strMsgID.c_str());
   
    // ��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS, m_cCmt108.sRecvsapbk);
  
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");
        PMTS_ThrowException(OPT_GET_DATE_FAIL);
    }
    m_strWorkDate   =   m_sWorkDate;
     
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt108::unPack()");	
    
    return RTN_SUCCESS;
}


INT32 CRecvCmt108::SetData(LPCSTR pchMsg)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt108::SetData()");
    
	m_cHvrcvexchglist.m_workdate       = m_strWorkDate;//��������
    m_cHvrcvexchglist.m_consigndate    = m_cCmt108.sConsigndate;//ί������
    m_cHvrcvexchglist.m_msgtp          = m_strMsgTp;//��������
	m_cHvrcvexchglist.m_mesgid         = m_cCmt108.GetHeadMesgID();
	m_cHvrcvexchglist.m_mesgrefid      = m_cCmt108.GetHeadMesgReqNo();
    m_cHvrcvexchglist.m_msgid          = m_strMsgID;//���ı�ʶ��
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgID= [%s]",m_strMsgID.c_str());

    //m_cHvrcvexchglist.m_endtoendid     = ;//�˵��˱�ʶ��
    m_cHvrcvexchglist.m_instgdrctpty   = m_cCmt108.sSendsapbk;//����ֱ�Ӳ������
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSendsapbk= [%s]",m_cCmt108.sSendsapbk);

    m_cHvrcvexchglist.m_instgindrctpty = m_cCmt108.sSendbank;//����������
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSendbank= [%s]",m_cCmt108.sSendbank);

    m_cHvrcvexchglist.m_instddrctpty   = m_cCmt108.sRecvsapbk;//����ֱ�Ӳ������
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sRecvsapbk= [%s]",m_cCmt108.sRecvsapbk);

    m_cHvrcvexchglist.m_instdindrctpty = m_cCmt108.sRecvbank;//���ղ������
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sRecvbank= [%s]",m_cCmt108.sRecvbank);

    m_cHvrcvexchglist.m_sttlmprty      = m_cCmt108.GetPayPRI();//ҵ�����ȼ�
    m_cHvrcvexchglist.m_dbtrmmbid      = m_cCmt108.sSendsapbk;//�����������к�
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSendsapbk= [%s]",m_cCmt108.sSendsapbk);

    //m_cHvrcvexchglist.m_dbtnm          = m_cCmt108.sOldpayername;//����������
    SetGbkToUtf8(m_cCmt108.sOldpayeename, m_cHvrcvexchglist.m_dbtnm);
    m_cHvrcvexchglist.m_dbtracctid     = m_cCmt108.sOldpayeeacc;//�������ʺ�

    m_cHvrcvexchglist.m_dbtid          = m_cCmt108.sSendbank;//�������к�
    //m_cHvrcvexchglist.m_dbtrissr       = ;//�����˿������к�
    m_cHvrcvexchglist.m_cdtrmmbid      = m_cCmt108.sRecvsapbk;//�տ��������к�
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sRecvsapbk= [%s]",m_cCmt108.sRecvsapbk);

    //m_cHvrcvexchglist.m_cdtrnm         = m_cCmt108.sOldpayeename;//�տ��˻���
    SetGbkToUtf8(m_cCmt108.sOldpayername, m_cHvrcvexchglist.m_cdtrnm);

    m_cHvrcvexchglist.m_cdtracctid     = m_cCmt108.sOldpayeracc;//�տ����ʺ�
    m_cHvrcvexchglist.m_cdtid          = m_cCmt108.sRecvbank;//�տ����к�
    //m_cHvrcvexchglist.m_cdtrissr       = ;//�տ��˿������к�   
    m_cHvrcvexchglist.m_procstate      = PR_HVBP_19;//����״̬
    m_cHvrcvexchglist.m_amount         = m_cCmt108.dAmount;//���׽��
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "dAmount= [%f]",m_cCmt108.dAmount);

    m_cHvrcvexchglist.m_currency       = m_cCmt108.sCur;//���ҷ���
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sCur= [%s]",m_cCmt108.sCur);

    //m_cHvrcvexchglist.m_ctgypurpprtry  = ;//ҵ�����ͱ���
    char isodate[10+1] = {0};
    chgToISODate(m_cHvrcvexchglist.m_consigndate.c_str(), isodate);
    m_cHvrcvexchglist.m_finalstatedate = isodate ;//��������
    m_cHvrcvexchglist.m_purpprtry      = "00";//ҵ���������:������ݿⲻ��Ϊ�յ�
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sRecvcenter= [%s]",m_cCmt108.sRecvcenter);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSendcenter= [%s]",m_cCmt108.sSendcenter);
    m_cHvrcvexchglist.m_busistate      = PROCESS_PR04;//ҵ��״̬
    //m_cHvrcvexchglist.m_processcode    = ;//ҵ������
    //m_cHvrcvexchglist.m_rjctinf        = ;//ҵ��ܾ���Ϣ
    //m_cHvrcvexchglist.m_acctstate      = ;//����״̬
    //m_cHvrcvexchglist.m_statetime      = ;//����״̬���ʱ��
    //m_cHvrcvexchglist.m_acstatetime    = ;//����״̬���ʱ��
    //m_cHvrcvexchglist.m_acctregnum     = ;//������ˮ��
    //m_cHvrcvexchglist.m_checkstate     = ;//��NPC����״̬
    //m_cHvrcvexchglist.m_mbcheckstate   = ;//�����ڶ���״̬
    
    char sOldtxssno[10] = {0};
    sprintf(sOldtxssno, "%08d", m_cCmt108.iOldtxssno);
    
    string strVal = "";

    m_cHvrcvexchglist.m_ustrdstr       = "051:";//������
    m_cHvrcvexchglist.m_ustrdstr       += m_cCmt108.sOldconsigndate;
    m_cHvrcvexchglist.m_ustrdstr       += ":02B:";
    m_cHvrcvexchglist.m_ustrdstr       += m_cCmt108.sOldcmtno;
    m_cHvrcvexchglist.m_ustrdstr       += ":005:";
    m_cHvrcvexchglist.m_ustrdstr       += sOldtxssno;
    m_cHvrcvexchglist.m_ustrdstr       += ":CQ1:";
    m_cHvrcvexchglist.m_ustrdstr       += m_cCmt108.sOldpayeracc;
    m_cHvrcvexchglist.m_ustrdstr       += ":CR1:";
    SetGbkToUtf8(m_cCmt108.sOldpayername, strVal);
    m_cHvrcvexchglist.m_ustrdstr       += strVal;
    m_cHvrcvexchglist.m_ustrdstr       += ":CQ2:";
    m_cHvrcvexchglist.m_ustrdstr       += m_cCmt108.sOldpayeeacc;
    m_cHvrcvexchglist.m_ustrdstr       += ":CR2:";
    SetGbkToUtf8(m_cCmt108.sOldpayeename, strVal);
    m_cHvrcvexchglist.m_ustrdstr       += strVal;
    
    //m_cHvrcvexchglist.m_addinfo            = m_cCmt108.sRemark;//��ע
    SetGbkToUtf8(m_cCmt108.sRemark, m_cHvrcvexchglist.m_addinfo);
    //m_cHvrcvexchglist.m_reserve        = ;//������
    //m_cHvrcvexchglist.m_npcmsg         = ;//NPC����
    //m_cHvrcvexchglist.m_mbmsg          = ;//MB����
    //int m_printno                      = ;//��ӡ����
    //m_cHvrcvexchglist.m_iststatetime   = ;//���ʱ��
    //m_cHvrcvexchglist.m_isrbflg        = ;//�Ƿ��˻��־
    //m_cHvrcvexchglist.m_recvdest       = ;//����Ŀ��
    //m_cHvrcvexchglist.m_dbtaddr        = ;//�����˵�ַ
    //m_cHvrcvexchglist.m_cdtaddr        = ;//�տ��˵�ַ
    m_cHvrcvexchglist.m_srcflag        = "0";//������־ 0:���� 1:���˲���    
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt108::SetData()");

    return RTN_SUCCESS;
}

INT32 CRecvCmt108::InsertData(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt108::InsertData()");

    int iRet = RTN_FAIL;


	//1����������
    iRet = m_cHvrcvexchglist.setctx(m_dbproc);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_strMsgID.c_str(), "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }

	//2���������ݿ�
	iRet = m_cHvrcvexchglist.insert();
    if (RTN_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg, "������ʻ����ϸ��hv_rcvexchglist��������ʧ��[%s], [%d][%s]", 
            m_strMsgID.c_str(), iRet, m_cHvrcvexchglist.GetSqlErr());
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt108::InsertData()");

    return RTN_SUCCESS;
}

/*void CRecvCmt108::UpdateOldTrade()
{
    
}
*/

int CRecvCmt108::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvCmt108::FundSettle...");
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û�[%s]", m_szOprUser);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_cCmt108.sRecvbank);

	m_charge.m_amount = m_cCmt108.dAmount;	//ҵ����
	m_charge.m_iDCFlag = iCREDITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, MBVIRSUALNETID);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_cCmt108.sRecvbank);	//������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(RTN_SUCCESS != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FundSettle iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvCmt108::FundSettle..."); 
    
    return RTN_SUCCESS;
}

int CRecvCmt108::ChkMac()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvCmt108::ChkMac...");
	int iRet = -1;
	
	m_cCmt108.SetSeal();//��ȡ��Ѻ��

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt108.sRecvsapbk[%s]",m_cCmt108.sRecvsapbk);
	
    iRet = CheckMac(m_dbproc,m_cCmt108.GetMacStr(),m_cCmt108.m_Seal.c_str(),m_cCmt108.sRecvsapbk);
    if(0 != iRet)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ChkMac failed");

		m_cHvrcvexchglist.m_procstate	   = PR_HVBP_63;//����״̬		
    	//PMTS_ThrowException(OPT_CHECKSIGN_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]",m_cCmt108.m_szMacStr);
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvCmt108::ChkMac..."); 
    
    return RTN_SUCCESS;
}

int CRecvCmt108::UpdateOrgData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvCmt108::UpdateOrgData...");
    
    SETCTX(m_cHvsndexchglist);
    
    string strTable = "hv_sndexchglist";

    char oldtxssno[8+1]={0};
    sprintf(oldtxssno, "%08d",m_cCmt108.iOldtxssno);
    m_cHvsndexchglist.m_msgid  = m_cCmt108.sOldconsigndate;
    m_cHvsndexchglist.m_msgid += oldtxssno;
    m_cHvsndexchglist.m_instgindrctpty = m_cCmt108.sRecvbank;
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_msgid= %s", m_cHvsndexchglist.m_msgid.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_instgindrctpty= %s", m_cHvsndexchglist.m_instgindrctpty.c_str());
    
	int iRet = m_cHvsndexchglist.findByPK();
	if(RTN_SUCCESS != iRet)
	{
		if (iRet == SQLNOTFOUND){
			CHvsndexchglisthis his;
			SETCTX(his);
			his.m_msgid = m_cHvsndexchglist.m_msgid;
			his.m_instgindrctpty = m_cHvsndexchglist.m_instgindrctpty ;
			iRet = his.findByPK();
			strTable = "hv_sndexchglisthis";
			if (iRet != SQL_SUCCESS){
				if (iRet != SQLNOTFOUND){
					Trace(L_ERROR,  __FILE__,  __LINE__, NULL,
							"��ȡ����ʧ��, iRet = %d", iRet, his.GetSqlErr());
					PMTS_ThrowException(DB_FIND_FAIL);
				}
				else {
					Trace(L_INFO, __FILE__, __LINE__, NULL, "�Ҳ���ԭҵ��!");
					return 0;
				}
			}
			else{
				m_strMsgDirect = his.m_msgdirect.c_str();
			}
		}
		else{
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��, iRet = %d", iRet, m_cHvsndexchglist.GetSqlErr());
			PMTS_ThrowException(DB_NOT_FOUND);
		}
	}
	else{
		m_strMsgDirect = m_cHvsndexchglist.m_msgdirect.c_str();
	}
	
	string strSQL;
	strSQL += "UPDATE ";
	strSQL += strTable;
	strSQL += " t SET t.ISRBFLG = '1' ";
	strSQL += " WHERE t.MSGTP = '";
	strSQL += m_cHvsndexchglist.m_msgtp.c_str();
	strSQL += "' AND t.MSGID = '";
	strSQL += m_cHvsndexchglist.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_cHvsndexchglist.m_instgindrctpty.c_str(); 									
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());
	
	 iRet = m_cHvsndexchglist.execsql(strSQL.c_str());
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL, "Update failed,SQLNOTFOUND, sqlcode=[%d]", iRet);
	}
	else if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��iRet=%d, %s", iRet, m_cHvsndexchglist.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}  
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvCmt108::UpdateOrgData..."); 
    return RTN_SUCCESS;
    
}

