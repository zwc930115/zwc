/********************************************************************
文件名：recvfromfe.cpp
创建人：zny
日  期：2009.07.07
修改人：zj
日  期：
描  述：后台业务来账处理主控
版  本：
Copyright (c) 2009  YLINK
********************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "exception.h"
#include "configparser.h"
#include "logger.h"
#include "parser111.h"
#include "pmtspubfunc.h"
#include "connectpool.h"

CConnectPool *g_DBConnPool;

using namespace ZFPT;
#define MQ_ERR_MAX_TIMES 20

#define	TRANS_PARM		1
#define	STATUS_PARM		2


int getFileText(char *  sFileName,char * sMsg)
{
	
	char sBuff[1024] ;
	//循环读取数据并处理
	FILE *fp = NULL; 
	
	fp = fopen(sFileName, "r");
	
	if ( fp == NULL )
	{
		printf("打开文件出错\n");
		return -1;	
	}
	
	int rendlen = 0;
	int iTotalLen = 0;
	while ( 1 )
	{
		memset(sBuff, 0, sizeof(sBuff));
		fgets(sBuff, sizeof(sBuff), fp)	;
		
        rendlen = strlen(sBuff);
		if (rendlen == 0)
			break;
		strcpy(sMsg+iTotalLen ,sBuff);
		iTotalLen += rendlen;
		
	}
	return 0;
	
} 


int unPack(LPCSTR sMsg)
{
	ZFPTLOG << eSystem << __FILE__ << " " << __LINE__ << " entering unPack " << endl;	
	
	int iMsgVer = JudgeMsgVer(sMsg);
	int iBizCode = GetMsgCode(sMsg);
	printf("szBizCode = [%d]\n",iBizCode);
	PARSER111 oParser111(iMsgVer,iBizCode);
	//oParser111.Init(iMsgVer,iBizCode);
	
	int iRet = oParser111.ParseMsg(sMsg);
	if (iRet != 0)
	{
		ZFPTLOG << eSystem << __FILE__ << " " << __LINE__ << " 报文解析出错!iRet= " << iRet << endl;
        
        return iRet;
	}
	ZFPTLOG << eSystem << __FILE__ << " " << __LINE__ << " oParser111.DbtrNm = " << oParser111.DbtrNm.c_str() << endl;
	ZFPTLOG << eSystem << __FILE__ << " " << __LINE__ << " oParser111.MsgId = " << oParser111.MsgId.c_str() << endl;
	ZFPTLOG << eSystem << __FILE__ << " " << __LINE__ << " oParser111.CdtrNm = " << oParser111.CdtrNm.c_str() << endl;
	ZFPTLOG << eSystem << __FILE__ << " " << __LINE__ << " oParser111.m_PMTSHeader.getMesgID = " << oParser111.m_PMTSHeader.getMesgID() << endl;
	
	printf("digitsign = [%s]\n",oParser111.m_szDigitSign.c_str());
	
	string sUstrd = "";
	sUstrd = oParser111.GetUstrd(3);
	printf("sUstrd = [%s]\n",sUstrd.c_str());
	
	ZFPTLOG << eSystem << __FILE__ << " " << __LINE__ << " leaving unPack " << endl;
	
	return 0;
}


int pack()
{
	ZFPTLOG << eSystem << __FILE__ << " " << __LINE__ << " entering unPack " << endl;	
	
	PARSER111 oParser111(1,100);
	//oParser111.Init;
	oParser111.m_PMTSHeader.setOrigSender("888888888888");
	oParser111.MsgId = "a123456789a";
	oParser111.DbtrNm = "付款人";
	oParser111.CdtrNm = "收款人";
	oParser111.m_szDigitSign = "ASDERT#$%GTRTYTADSQWER^KYIPOIUYUNHGWESDCVVZXAWQ@!$%^HYGT&*U$";
	
	int iRet = oParser111.CreateMsg();
	if (0 != iRet)
	{
		ZFPTLOG << eSystem << __FILE__ << " " << __LINE__ << " 生成报文出错!iRet= " << iRet << endl;
        
        return iRet;
	}
	
	printf("m_MsgTxt = [%s]\n",oParser111.m_MsgTxt.c_str());
	
	ZFPTLOG << eSystem << __FILE__ << " " << __LINE__ << " leaving Pack " << endl;
	
	return 0;
}

int digitSignTest()
{
	printf("%s %d\n",__FILE__,__LINE__);
    DBProc      dbproc;                        //连接	
   	printf("%s %d\n",__FILE__,__LINE__);
	// 获取连接	
    if(0 != g_DBConnPool->GetConnect(dbproc))
    {				
   		printf("获取连接失败\n");	
        return -1;
    }
   	printf("%s %d\n",__FILE__,__LINE__);
   	char sOrigenStr[] = "helloworld";
    char sSignedStr[10240] = {0};
	int iRet = digitSign(dbproc, sOrigenStr,sSignedStr,0, 0);
   	printf("%s %d\n",__FILE__,__LINE__);
	if(0 != iRet)
    {				
   		printf("加签失败\n");	
        return -1;
    }
   	printf("%s %d\n",__FILE__,__LINE__);
    
   	//removeChar13_10(sSignedStr);
   	
   	printf("sSignedStr = [%s]\n",sSignedStr);
   	//iRet = checkSignDetached(dbproc,sOrigenStr,sSignedStr,"402602000018");
   	iRet = checkSign(dbproc,sOrigenStr,sSignedStr,"402602000018");
   	if(0 != iRet)
    {				
   		printf("核签失败\n");	
        return -1;
    }
   	return 0;
}

int main(int argc, char **argv)
{
	
    char 		sErrDesc[1024] 		= {0};
    int			iRet				=	0;
    char        sDbUser[32]           = {0};   //数据库用户
    char        sDbPass[32]           = {0};   //数据库密码
    char        sDbSid[128]           = {0};   //数据库服务名
    int         iConnPoolMinSize      = 0;     //连接池中最小连接数
    int         iConnPoolMaxSize      = 0;     //连接池中最大连接数
    int         iNoConnWaitTime       = 0;     //取不到连接时等待时间
    int         iConnPoolSize         = 0;     //连接池中初始连接数
    int         iThreadPoolSize       = 0;     //线程池中线程数
    int         iThreadPoolTaskSize   = 0;     //线程池任务数
     //加载配置文件 
    CConfigParser& cCfg = CConfigParser::getInstance();
	try
	{
				
		cCfg.loadConfig("../cfg/pmts.xml");
    	
    	//初始化日志 
		ZFPTLOG.setCfgInfo(cCfg.getOption("LOGPATH"), "parsertest", (LOG_LEVEL)atoi(cCfg.getOption("LOGLVL")));
		g_LogObj = new CCategory();
        iRet = g_LogObj->initialize("../log", 
                5, 
                "parsertest",		    // application name
                R_NOSOCKET,	            // Listen the control port
                0,				        // availabel only if R_SOCKET
                9999,			        // Control manager port
                M_SYNC		            // output mode 1-M_SYNC 2-M_ASYNC
                );
        g_LogObj->log(L_INFO,  __FILE__,  __LINE__, NULL, "初始化日志...");		
        
		iConnPoolMinSize = atoi(cCfg.getOption("CONNPOOLMINSIZE"));
        iConnPoolMaxSize = atoi(cCfg.getOption("CONNPOOLMAXSIZE"));
        iNoConnWaitTime	 = atoi(cCfg.getOption("NOCONNWAITTIME"));
        iConnPoolSize    = atoi(cCfg.getOption("CONNPOOLSIZE"));

        strncpy(sDbUser,cCfg.getOption("DBUSER"), sizeof(sDbUser)-1);
        strncpy(sDbPass,cCfg.getOption("DBKEY") , sizeof(sDbPass)-1);
        strncpy(sDbSid,cCfg.getOption("DBNAME") , sizeof(sDbSid) -1);
		
        //创建连接池 
        g_DBConnPool = new CConnectPool(iConnPoolMinSize,iConnPoolMaxSize,iNoConnWaitTime);
		
       
        iRet= g_DBConnPool->InitPool(iConnPoolSize,sDbUser,sDbPass,sDbSid);
		
        if(iRet == RTN_SUCCESS)
        {
            //ZFPT_LOG << eSystem << "连接池创建成功" << endl;	
            printf("连接池创建成功\n");
        }
        else
        {
            //ZFPT_LOG << eSystem << "连接池创建失败" << endl;	
            printf("连接池创建失败\n");
            return RTN_FAIL;
        }
        
	}catch(CException &e)
    {
    	sprintf(sErrDesc, "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());
    	
        
    }
	char sMsg[1024 * 10] = {0};
	char sCmt100[256] = {0};
	char sHvps111[256] = {0};
	char sHvps1112[256] = {0};
	
	strncpy(sCmt100,"/ncb/pmts/mqtest/file/hvps/cmt100.txt",sizeof(sCmt100)-1);
	strncpy(sHvps111,"/ncb/pmts/mqtest/file/hvps/hvps.111.001.01.xml",sizeof(sHvps111)-1);
	strncpy(sHvps1112,"/ncb/pmts/mqtest/file/hvps/hvps111",sizeof(sHvps1112)-1);
    iRet = getFileText(sHvps1112,sMsg);
    if(0 != iRet)
    {
   		printf("读取报文失败[%d]\n",iRet);
   		return -1;
    }
    
    unPack(sMsg);
    
	pack();
	
	digitSignTest();
	
	ZFPTLOG << eSystem << "exit" << endl;	
	
	setsid();  //退出前设置会话session组id,防止影响其子进程 
	
   	
	return RTN_SUCCESS;
}
	
