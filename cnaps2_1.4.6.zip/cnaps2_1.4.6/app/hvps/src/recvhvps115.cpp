/******************************************************************** 
�ļ����� recv115.cpp
�����ˣ� zwc
��  ��   �� 2017-11-07
�޸��ˣ� 
��  �ڣ� 
��  ���� ���ڻ���������ҵ�����˱��Ĵ���(hvps.115.001.01)
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvhvps115.h"

using namespace ZFPT;

CRecvHvps115::CRecvHvps115()
{
	m_iMsgVer	=	2;
	m_strMsgTp	=	"hvps.115.001.01";
	m_strMsgDirect = "";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps115::CRecvHvps115()");	
}


CRecvHvps115::~CRecvHvps115()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps115::~CRecvHvps115()");		
}

INT32 CRecvHvps115::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps115::Work()");	
	
	int iRet = RTN_FAIL;
	
	// 1.��������
	unPack(sMsg);
	
	// 2.��m_cHvrcvexchglist�ĳ�Ա��ֵ
	SetData(sMsg);
	
	// 3.����������ʻ����ϸ��hv_rcvexchglist
	InsertData();
	
	// 4.��ǩ
	CheckSign115();
	
	if( NULL != strstr(m_cParser115.Prtry.c_str(),"A105") )//������˻����ѯԭҵ��
	{
	    UpdateOrgData();
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps115::work()");
	
	return RTN_SUCCESS;
}



INT32 CRecvHvps115::unPack(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps115::unPack");	

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "receive msg len = [%d]", strlen(sMsg));
    
    int iRet = RTN_FAIL;

	//1�������Ƿ�Ϊ��
	if (NULL == sMsg || '\0' == sMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
	}

	//3����������
	iRet = m_cParser115.ParseXml(sMsg);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ParseXml[%d]", iRet);
	if (RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= %d", iRet);	
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
	}

    //ZFPTLOG.SetLogInfo("115", m_cParser115.MsgId.c_str());
    
	m_strWorkDate	=	m_sWorkDate;

	m_strMsgID	=	m_cParser115.MsgId;

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps115::unPack");	

	return RTN_SUCCESS;
}

void CRecvHvps115::CheckSign115()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps115::CheckSign115()");
	
	m_cParser115.getOriSignStr();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSignBuff = [%s]", m_cParser115.m_sSignBuff.c_str());	
	
	CheckSign(m_cParser115.m_sSignBuff.c_str(),
						m_cParser115.m_szDigitSign.c_str(),
						m_cParser115.DbtrMmbId.c_str());
		
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps115::CheckSign115()");
}

/******************************************************************************
*  Function:   SetData
*  Description:
*  Input:      ��
*  Output:     
*  Return:     0   : �����ɹ�,
               ����: ����ʧ��
*  Others:     ��
*  Author:     zwc
*  Date:       2017-11-13
*******************************************************************************/
INT32 CRecvHvps115::SetData(LPCSTR pchMsg)
{    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps115::SetData");
    
    string strTemp;

    //==============================m_cHvrcvexchglist�ֶ�==============================
	m_cHvrcvexchglist.m_workdate       = m_strWorkDate;				//��������

	m_cHvrcvexchglist.m_consigndate	= m_cParser115.MsgId.substr(0, 8);  //ί������:�������ĵ��ڹ�������
	m_cHvrcvexchglist.m_mesgid		= m_cParser115.m_PMTSHeader.getMesgID();		//ͨ�ż���ʶ��
	m_cHvrcvexchglist.m_mesgrefid	= m_cParser115.m_PMTSHeader.getMesgRefID();	//ͨ�ż��ο���	
	m_cHvrcvexchglist.m_msgtp          = m_strMsgTp;				//��������
	m_cHvrcvexchglist.m_msgid          = m_cParser115.MsgId;		//���ı�ʶ��
	m_cHvrcvexchglist.m_endtoendid     = m_cParser115.EndToEndId;	//�˵��˱�ʶ��
	//m_cHvrcvexchglist.m_credttm        = m_cParser115.CreDtTm;	//���ķ���ʱ��
	m_cHvrcvexchglist.m_instgdrctpty   = m_cParser115.DbtrMmbId;	//����ֱ�Ӳ������=����������
	m_cHvrcvexchglist.m_instgindrctpty = m_cParser115.DbtrId;	//����������=������
	m_cHvrcvexchglist.m_instddrctpty   = m_cParser115.CdtrMmbId;	//����ֱ�Ӳ������=�տ�������
	m_cHvrcvexchglist.m_instdindrctpty = m_cParser115.CdtrId;		//���ղ������=�տ���
	m_cHvrcvexchglist.m_sttlmprty      = m_cParser115.SttlmPrty;	//ҵ�����ȼ�
	m_cHvrcvexchglist.m_dbtrmmbid      = m_cParser115.DbtrMmbId;	//�����������к�
	m_cHvrcvexchglist.m_dbtnm          = m_cParser115.DbtrNm;		//����������
	m_cHvrcvexchglist.m_dbtracctid     = m_cParser115.DbtrAcctId;	//�������ʺ�
	m_cHvrcvexchglist.m_dbtid          = m_cParser115.DbtrId;		//�������к�
	m_cHvrcvexchglist.m_dbtrissr       = m_cParser115.DbtrAcctIssr;	//�����˿������к�
	m_cHvrcvexchglist.m_cdtrmmbid      = m_cParser115.CdtrMmbId;	//�տ��������к�
	m_cHvrcvexchglist.m_cdtrnm         = m_cParser115.CdtrNm;		//�տ��˻���
	m_cHvrcvexchglist.m_cdtracctid     = m_cParser115.CdtrAcctId;	//�տ����ʺ�
	m_cHvrcvexchglist.m_cdtid          = m_cParser115.CdtrId;		//�տ����к�
	m_cHvrcvexchglist.m_cdtrissr       = m_cParser115.CdtrAcctIssr;	//�տ��˿������к�
	m_cHvrcvexchglist.m_procstate      = PR_HVBP_06;				//����״̬:06����ִ
	m_cHvrcvexchglist.m_amount         = atof(m_cParser115.IntrBkSttlmAmt.c_str());	//���׽��
	m_cHvrcvexchglist.m_currency       = m_cParser115.Ccy;			//���ҷ���
	m_cHvrcvexchglist.m_ctgypurpprtry  = m_cParser115.Prtry;		//ҵ�����ͱ���	    	
	m_cHvrcvexchglist.m_busistate      = PROCESS_PR06;				//ҵ��״̬:������
	m_cHvrcvexchglist.m_processcode    = "";						//ҵ������
	m_cHvrcvexchglist.m_rjctinf        = "";						//ҵ��ܾ���Ϣ
	m_cHvrcvexchglist.m_acctstate      = "";						//����״̬
	m_cHvrcvexchglist.m_acctregnum     = "";						//������ˮ��
	m_cHvrcvexchglist.m_checkstate     = PR_HVBP_00;			    //��NPC����״̬
	m_cHvrcvexchglist.m_mbcheckstate   = PR_HVBP_00;				//�����ڶ���״̬
	m_cHvrcvexchglist.m_reserve        = "";						//������
	m_cHvrcvexchglist.m_npcmsg         = pchMsg;					//NPC����
	m_cHvrcvexchglist.m_mbmsg          = "";						//MB����
	m_cHvrcvexchglist.m_printno        = 0;							//��ӡ����
	m_cHvrcvexchglist.m_iststatetime   = "";
	m_cHvrcvexchglist.m_isrbflg        = "";
	m_cHvrcvexchglist.m_recvdest       = "";
    m_cHvrcvexchglist.m_dbtaddr        = m_cParser115.DbtrAdrLine;     // �����˵�ַ
    m_cHvrcvexchglist.m_cdtaddr        = m_cParser115.CdtrAdrLine;     // �տ��˵�ַ
    m_cHvrcvexchglist.m_clrmbid1       = m_cParser115.ClrMbId1;//�н����1
    m_cHvrcvexchglist.m_clrmbid1name   = m_cParser115.ClrMbId1Nm;// �н����1����
    m_cHvrcvexchglist.m_clrmbid2       = m_cParser115.ClrMbId2;//�н����2
    m_cHvrcvexchglist.m_clrmbid2name   = m_cParser115.ClrMbId2Nm;//�н����2����
    m_cHvrcvexchglist.m_dbtrlssrnm     = m_cParser115.DbtrAcctIssrNm;// �����˿���������
    m_cHvrcvexchglist.m_cdtrlssrnm     = m_cParser115.CbtrAcctIssrNm;//�տ��˿���������

    m_cHvrcvexchglist.m_srcflag        = "0";                          // ������־
	m_cHvrcvexchglist.m_iCount		   = 0;

    //add by zwc for v1.4.6 ������������
	m_cHvrcvexchglist.m_expectedstatedate     = m_cParser115.IntrBkSttlmDt;  
	//add end


    int iCount = m_cParser115.m_pXMLProc.m_PMTSUstrdDataMap.size();
    for(int i = 0;i < iCount ;i++)
    {
        strTemp = m_cParser115.GetUstrd(i);
        
        if(NULL != strstr(strTemp.c_str(),"/F25/"))
        {
            GetTagVal(m_cHvrcvexchglist.m_purpprtry, strTemp, "/F25/"); // ҵ���������
            m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr + strTemp +":";
            continue;

        }
        else if(NULL != strstr(strTemp.c_str(),"/H01/"))
        {
            GetTagVal(m_cHvrcvexchglist.m_addinfo , strTemp, "/H01/"); //����
            m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp + ":";
            continue;

        }
        else if(NULL != strstr(strTemp.c_str(),"/H02/"))
        {
            GetTagVal(m_cHvrcvexchglist.m_addinfo2, strTemp, "/H02/"); //����2
            m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp + ":";
            continue;

        }
        /*else if(NULL != strstr(strTemp.c_str(),"/C00/"))
        {
            GetTagVal(m_cHvrcvexchglist.m_finalstatedate, strTemp, "/C00/"); //��������
            m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            continue;

        }*/
        
        if(NULL != strstr(m_cParser115.Prtry.c_str(),"A200"))//�м��ʽ�㻮
        {
        
            if(NULL != strstr(strTemp.c_str(),"/D27/"))
            {
                // �������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            
            }
            else if(NULL != strstr(strTemp.c_str(),"/C18/"))
            {
                //  �������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            
            } 
            else
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "δ֪��ҵ������:strTemp = [%s]",strTemp.c_str());
            }
            
        }
        else if(NULL != strstr(m_cParser115.Prtry.c_str(),"A105"))//�˻�
        {
            if(NULL != strstr(strTemp.c_str(),"/E51/"))
            {
                // ԭ���ı�ʶ��
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
                m_cHvsndexchglist.m_msgid = strTemp.c_str()+strlen("/E51/");//Ϊ����ԭҵ��ֵ����
            }
            else if(NULL != strstr(strTemp.c_str(),"/A70/"))
            {
                // ԭ����������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
                m_cHvsndexchglist.m_instgindrctpty = strTemp.c_str()+strlen("/A70/");//Ϊ����ԭҵ��ֵ����
            }
            else if(NULL != strstr(strTemp.c_str(),"/F40/"))
            {
                // ԭ�������ʹ���
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";

            }
            else if(NULL != strstr(strTemp.c_str(),"/H20/"))
            {
                //   �˻�ԭ��
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";

            }      
            else
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "δ֪��ҵ������:strTemp = [%s]",strTemp.c_str());
            }
        }
        else if(NULL != strstr(m_cParser115.Prtry.c_str(),"A113"))//�羳֧��
        {
            
            if(NULL != strstr(strTemp.c_str(),"/C14/"))
            {
                //  ����ҵ��ί������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            
            }
            else if(NULL != strstr(strTemp.c_str(),"/A28/"))
            {
                //  ҵ����ת����BIC��
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            
            }
            else if(NULL != strstr(strTemp.c_str(),"/H17/"))
            {
                // ҵ����ת��������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            
            }
            else if(NULL != strstr(strTemp.c_str(),"/A29/"))
            {
                // ҵ�����ת����BIC��
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            
            }
            else if(NULL != strstr(strTemp.c_str(),"/H18/"))
            {
                // ҵ�����ת��������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            
            }
            else if(NULL != strstr(strTemp.c_str(),"/F56/"))
            {
                // ���ñ���
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            
            }
            else if(NULL != strstr(strTemp.c_str(),"/D63/"))
            {
                // �����е��շ�
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            
            }
            else if(NULL != strstr(strTemp.c_str(),"/D64/"))
            {
                // �ձ��е��շ�
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            
            }
            else if(NULL != strstr(strTemp.c_str(),"/H19/"))
            {
                // �羳ҵ����
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            
            }
            else if(NULL != strstr(strTemp.c_str(),"/H32/"))
            {
                // �տ�������2 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H33/"))
            {
                // �տ�������3 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H34/"))
            {
                // �տ��˵�ַ2 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H35/"))
            {
                // �տ��˵�ַ3 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H36/"))
            {
                // �տ��˵�ַ4 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H37/"))
            {
                // �տ��˵�ַ5 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/B29/"))
            {
                // �տ����˺�2 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            } 
            else if(NULL != strstr(strTemp.c_str(),"/H38/"))
            {
                // ����������2 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H39/"))
            {
                // ����������3 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H40/"))
            {
                // �����˵�ַ2 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H41/"))
            {
                // �����˵�ַ3 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H42/"))
            {
                // �����˵�ַ4 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            } 
            else if(NULL != strstr(strTemp.c_str(),"/H43/"))
            {
                // �����˵�ַ5 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/B30/"))
            {
                // �������˺�2 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }            
            else
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "δ֪��ҵ������:strTemp = [%s]",strTemp.c_str());
            }
        }
        else
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "δ֪��ҵ������:strTemp = [%s]",strTemp.c_str());
        }
    }        

    //==============================m_cHvrcvexchglist�ֶ�==============================

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps115::SetData");	

	return RTN_SUCCESS;
}


/******************************************************************************
*  Function:   InsertData
*  Description:������ʻ����ϸ��hv_rcvexchglist�����¼
*  Input:      ��
*  Output:     
*  Return:     0   : �����ɹ�,
               ����: ����ʧ��
*  Others:     ��
*  Author:     zwc
*  Date:       2017-11-13
*******************************************************************************/
INT32 CRecvHvps115::InsertData(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps115::InsertData");

    int iRet = RTN_FAIL;

	//1����������
    iRet = m_cHvrcvexchglist.setctx(m_dbproc);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_strMsgID.c_str(), "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }

	//2���������ݿ�
	iRet = m_cHvrcvexchglist.insert();
    if (RTN_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg, "������ʻ����ϸ��hv_rcvexchglist��������ʧ��[%s], [%d][%s]", 
            m_strMsgID.c_str(), iRet, m_cHvrcvexchglist.GetSqlErr());
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
    }
    
    //m_cHvrcvexchglist.commit();

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps115::InsertData");

	return RTN_SUCCESS;
}
	
	
int CRecvHvps115::ChargeMB()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvHvps115::ChargeMB...");

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvHvps115::ChargeMB..."); 
	
	return RTN_SUCCESS;
}

int CRecvHvps115::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvHvps115::FundSettle...");
	strcpy(m_szOprUserNetId, MBVIRSUALNETID);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_cHvrcvexchglist.m_instdindrctpty.c_str());

	m_charge.m_amount = m_cHvrcvexchglist.m_amount; //ҵ����
	m_charge.m_iDCFlag = iCREDITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, m_szOprUserNetId);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_cHvrcvexchglist.m_instdindrctpty.c_str());	//����������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(RTN_SUCCESS != iRet) 	   
	{
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "FundSettle iRet=%d", iRet);
		PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
	}
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvHvps115::FundSettle..."); 
	
	return RTN_SUCCESS;
}

int CRecvHvps115::UpdateOrgData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvHvps115::UpdateOrgData...");
    Trace(L_INFO,	__FILE__,  __LINE__, NULL, "m_cHvsndexchglist.m_msgid =[%s]", m_cHvsndexchglist.m_msgid.c_str());
    Trace(L_INFO,	__FILE__,  __LINE__, NULL, "m_cHvsndexchglist.m_instgindrctpty =[%s]", m_cHvsndexchglist.m_instgindrctpty.c_str());
    SETCTX(m_cHvsndexchglist);
	int iRet = m_cHvsndexchglist.findByPK();
	if(RTN_SUCCESS != iRet)
	{
		if (iRet == SQLNOTFOUND){
			SETCTX(m_cHvsndexchglisthis);
			m_cHvsndexchglisthis.m_msgid = m_cHvsndexchglist.m_msgid;
			m_cHvsndexchglisthis.m_instdindrctpty = m_cHvsndexchglist.m_instgindrctpty;
			iRet = m_cHvsndexchglisthis.findByPK();
			if (iRet != SQL_SUCCESS){
				if (iRet != SQLNOTFOUND){
					Trace(L_ERROR,  __FILE__,  __LINE__, NULL,
							"��ȡ����ʧ��, iRet = %d, [%s]", iRet, m_cHvsndexchglisthis.GetSqlErr());
					PMTS_ThrowException(DB_FIND_FAIL);
				}
				else{
					Trace(L_INFO, __FILE__, __LINE__, NULL, "�Ҳ���ԭҵ��!");
					return 0;
				}
			}
			else{
				m_strOrgnlTable = "hv_sndexchglisthis";
				m_strMsgDirect  = m_cHvsndexchglisthis.m_msgdirect.c_str();
			}
		}
		else{
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL,
					"��ȡ����ʧ��, iRet = %d, [%s]", iRet, m_cHvsndexchglist.GetSqlErr());
			PMTS_ThrowException(DB_FIND_FAIL);
		}
	}
	else{
		m_strOrgnlTable = "hv_sndexchglist";
		m_strMsgDirect  = m_cHvsndexchglist.m_msgdirect.c_str();
	}
	
	string strSQL;
	strSQL += "UPDATE ";
	strSQL += m_strOrgnlTable;
	strSQL += " t SET t.ISRBFLG = '1' ";
	strSQL += " WHERE t.MSGID = '";
	strSQL += m_cHvsndexchglist.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_cHvsndexchglist.m_instgindrctpty.c_str(); 									
	strSQL += "'";

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());
	
    iRet = m_cHvsndexchglist.execsql(strSQL.c_str());
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL, "Update failed,SQLNOTFOUND, sqlcode=[%d]", iRet);
	}
	else if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��iRet=%d, %s", iRet, m_cHvsndexchglist.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}  
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvHvps115::UpdateOrgData..."); 
    return RTN_SUCCESS;
}
