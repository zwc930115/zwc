/******************************************************************** 
�ļ����� sendcmt100.cpp
�����ˣ� aps-xcm
��  �ڣ� 2011-06-21
�޸��ˣ� 
��  �ڣ� 
��  ���� һ��������˻��֧������
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt100.h"

CSendCmt100::CSendCmt100(const stuMsgHead& Smsg):CSendHvpsBase(Smsg)
{
   
}

CSendCmt100::~CSendCmt100()
{
    
}

void CSendCmt100::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt100::SetDBKey...");

    m_Hvsndlist.m_msgtp = "CMT";
    m_Hvsndlist.m_msgtp = m_Hvsndlist.m_msgtp + m_szMsgType;
    
	m_Hvsndlist.m_msgid = m_szMsgFlagNO; 
	m_Hvsndlist.m_instgindrctpty = m_szSndNO; 

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_msgtp = %s", m_Hvsndlist.m_msgtp.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_msgid = %s", m_Hvsndlist.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_instgindrctpty = %s", m_Hvsndlist.m_instgindrctpty.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt100::SetDBKey...");
    
}

int CSendCmt100::GetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt100::GetData...");

    SETCTX(m_Hvsndlist);
    SetDBKey();
    int iRet = m_Hvsndlist.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ȡ����ʧ�ܣ� iRet = [%d]", iRet);
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    if(!m_Hvsndlist.m_endtoendid.empty())
    {
        m_sEndtoEnd = m_Hvsndlist.m_endtoendid;
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sEndtoEnd = %s", m_sEndtoEnd.c_str());
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt100::GetData...");
    return iRet;
}

void CSendCmt100::SetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt100::SetData...");

 
    
    strncpy(m_cCmt100.sConsigndate, m_Hvsndlist.m_consigndate.c_str(), sizeof(m_cCmt100.sConsigndate) - 1);
    m_cCmt100.iTxssno = atoi(m_szMsgSerial);
    
    strncpy(m_cCmt100.sCur, m_Hvsndlist.m_currency.c_str(), sizeof(m_cCmt100.sCur) - 1);
    m_cCmt100.dAmount = m_Hvsndlist.m_amount;
    strncpy(m_cCmt100.sSendsapbk, m_Hvsndlist.m_dbtmmbid.c_str(), sizeof(m_cCmt100.sSendsapbk) - 1);
    strncpy(m_cCmt100.sSendbank, m_Hvsndlist.m_dbtid.c_str(), sizeof(m_cCmt100.sSendbank) - 1);
    strncpy(m_cCmt100.sPayopenbk, m_Hvsndlist.m_dbtrissr.c_str(), sizeof(m_cCmt100.sPayopenbk) - 1);
    strncpy(m_cCmt100.sPayeracc, m_Hvsndlist.m_dbtracctid.c_str(), sizeof(m_cCmt100.sPayeracc) - 1);    
    strncpy(m_cCmt100.sRecvsapbk, m_Hvsndlist.m_cdtmmbid.c_str(), sizeof(m_cCmt100.sRecvsapbk) - 1);
    strncpy(m_cCmt100.sRecvbank, m_Hvsndlist.m_cdtid.c_str(), sizeof(m_cCmt100.sRecvbank) - 1);
    strncpy(m_cCmt100.sPayeeopenbk, m_Hvsndlist.m_cdtrissr.c_str(), sizeof(m_cCmt100.sPayeeopenbk) - 1);
    strncpy(m_cCmt100.sPayeeacc, m_Hvsndlist.m_cdtracctid.c_str(), sizeof(m_cCmt100.sPayeeacc) - 1);    
    strncpy(m_cCmt100.sTradetype, m_Hvsndlist.m_purpprtry.c_str(), sizeof(m_cCmt100.sTradetype) - 1);    
    
    /*
    strncpy(m_cCmt100.sRemark, m_Hvsndlist.m_addinfo.c_str(), sizeof(m_cCmt100.sRemark) - 1);
    strncpy(m_cCmt100.sPayername, m_Hvsndlist.m_dbtnm.c_str(), sizeof(m_cCmt100.sPayername) - 1);
    strncpy(m_cCmt100.sPayeraddr, m_Hvsndlist.m_dbtaddr.c_str(), sizeof(m_cCmt100.sPayeraddr) - 1);  
    strncpy(m_cCmt100.sPayeename, m_Hvsndlist.m_cdtrnm.c_str(), sizeof(m_cCmt100.sPayeename) - 1);
    strncpy(m_cCmt100.sPayeeaddr, m_Hvsndlist.m_cdtaddr.c_str(), sizeof(m_cCmt100.sPayeeaddr) - 1);
    */
    SetFieldAsGbk(m_Hvsndlist.m_addinfo,m_cCmt100.sRemark,sizeof(m_cCmt100.sRemark)-1);
    SetFieldAsGbk(m_Hvsndlist.m_dbtnm, m_cCmt100.sPayername, sizeof(m_cCmt100.sPayername) - 1);
    SetFieldAsGbk(m_Hvsndlist.m_dbtaddr, m_cCmt100.sPayeraddr, sizeof(m_cCmt100.sPayeraddr) - 1);  
    SetFieldAsGbk(m_Hvsndlist.m_cdtrnm, m_cCmt100.sPayeename, sizeof(m_cCmt100.sPayeename) - 1);
    SetFieldAsGbk(m_Hvsndlist.m_cdtaddr, m_cCmt100.sPayeeaddr, sizeof(m_cCmt100.sPayeeaddr) - 1);
    
    char SndCCPCNode[4 + 1] 	= {0};	
	char RcvCCPCNode[4 + 1] 	= {0};
   
    GetSapBkToCCPC(m_dbproc, m_Hvsndlist.m_instgdrctpty, SndCCPCNode);
	GetSapBkToCCPC(m_dbproc, m_Hvsndlist.m_instddrctpty, RcvCCPCNode);
	strncpy(m_cCmt100.sSendcenter, SndCCPCNode, sizeof(m_cCmt100.sSendcenter) - 1);
	strncpy(m_cCmt100.sRecvcenter, RcvCCPCNode, sizeof(m_cCmt100.sRecvcenter) - 1);
	
	
    strncpy(m_cCmt100.sTradetype, m_Hvsndlist.m_purpprtry.c_str(), sizeof(m_cCmt100.sTradetype) - 1);


    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt100::SetData...");
}

int CSendCmt100::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt100::buildCmtMsg...");

    int iRet = m_cCmt100.CreateCmt("100", m_Hvsndlist.m_instgdrctpty.c_str(), m_Hvsndlist.m_instddrctpty.c_str(), m_sMesgId.c_str(), m_sMesgId.c_str(), m_Hvsndlist.m_workdate.c_str(), m_Hvsndlist.m_sttlmprty.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt100::buildCmtMsg...");
    return iRet;
}
int CSendCmt100::UpdateState()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt100::UpdateState...");

    SETCTX(m_Hvsndlist);

    string strSQL;

    string strNpcMsg = "";
    if(!m_Hvsndlist.write_blob(m_cCmt100.m_strCmtmsg.c_str(), strNpcMsg, SYS_HVPS)){
    	Trace(L_ERROR, __FILE__, __LINE__, NULL,
    			"д���ֶα�����:[%s]", m_Hvsndlist.GetSqlErr());
    	PMTS_ThrowException(DB_INSERT_FAIL);
    }

    strSQL += "UPDATE hv_sndexchglist t SET t.STATETIME = sysdate, t.PROCSTATE = '";
	strSQL += m_szProState;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
	strSQL += "', t.endtoendid = '";
	strSQL += m_sEndtoEnd;
    strSQL += "', t.NPCMSG='";
    strSQL += strNpcMsg;
    
	strSQL += "' WHERE t.MSGTP = '";
	strSQL += m_Hvsndlist.m_msgtp.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_Hvsndlist.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Hvsndlist.m_instgindrctpty.c_str(); 									
	strSQL += "'";
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "strSQL=[%s]", strSQL.c_str());
    int iRet = m_Hvsndlist.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��iRet=[%d], [%s]", iRet, m_Hvsndlist.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
        
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt100::UpdateState...");
    return iRet;
}


int CSendCmt100::doWorkSelf()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt100::dowork...");
    //1)�������
    GetData();

    //2)��ֵ
    SetData();

    AddMac();
    
    buildCmtMsg();

	strcpy(m_szProState,PR_HVBP_08);//���ҵ��û���Ŷӣ�����״̬����08�ѷ���
	
    //ͷ�����
    FundSettle();

    UpdateState();

	if(strcmp(m_szProState,PR_HVBP_08) == 0)//�������״̬Ϊ�ѷ��ͣ�����Խ�����дMQ
	{
		AddQueue(m_cCmt100.m_strCmtmsg, m_cCmt100.m_strCmtmsg.length());
	}
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt100::dowork...");
    return RTN_SUCCESS;
}

int CSendCmt100::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt100::FundSettle...");

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt100::FundSettle..."); 
    
    return RTN_SUCCESS;
}

int CSendCmt100::AddMac()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt100::AddMac...");
	int iRet = -1;
	
	m_cCmt100.SetSeal();//��ȡ��Ѻ��

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt100.sSendsapbk[%s]",m_cCmt100.sSendsapbk);
	//m_cCmt100.m_Seal="123";
    iRet = CodeMac(m_dbproc,m_cCmt100.m_Seal.c_str(),m_cCmt100.sSendsapbk,m_cCmt100.m_szMacStr);
    if(0 != iRet)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "AddMac failed");
    	PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]",m_cCmt100.m_szMacStr);
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt100::AddMac..."); 
    
    return RTN_SUCCESS;
}
