/******************************************************************** 
�ļ����� send141.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
    
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendhvps141.h"

CSendHvps141::CSendHvps141(const stuMsgHead& Smsg):CSendHvpsBase(Smsg)
{

}

CSendHvps141::~CSendHvps141()
{
}

void CSendHvps141::AddSign141()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendHvps141::AddSign141");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_cParser141.getOriSignStr();
	
	AddSign(m_cParser141.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_Hvtrofacsndlist.m_instgdrctpty.c_str());
	
	m_cParser141.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendHvps141::AddSign141");
}

void CSendHvps141::GetTag2ND(const string& QryVal, const string& QryStr, int& iDepth)
{
    string strTemp;
    if(RTN_SUCCESS == GetTagVal(strTemp, QryStr, QryVal))
    {
        strTemp = QryVal + strTemp;
        m_cParser141.SetUstrd(iDepth, strTemp.c_str());
        iDepth++;    
    }
}

int CSendHvps141::doWorkSelf()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps141::doWork...");
	
	GetData();
	
	SetData();
	
	AddSign141();
	
	int iRet = m_cParser141.CreateXml();
	if(RTN_SUCCESS != iRet)        
	{            
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
		PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
	}
	
	//3)	ҵ���飨�ͻ������룩
	//.......
	//4)	���������ͻ������룩
	iRet = 0;
	iRet = FundSettle();
	if(RTN_SUCCESS != iRet)        
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FundSettle iRet=%d", iRet);
		PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
	}
	
	UpdateState();
	
	AddQueue(m_cParser141.m_sXMLBuff.c_str(), m_cParser141.m_sXMLBuff.length());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps141::doWork..."); 
	return RTN_SUCCESS;
}


void CSendHvps141::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps141::SetData...");
	
    char szBuff[128]                 = {0};
    int iRet = GetIsoDateTime(m_dbproc, SYS_HVPS, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }
	
	m_cParser141.m_szDigitSign     = "";
	m_cParser141.MsgId     = m_Hvtrofacsndlist.m_msgid;                   
	m_cParser141.Prtry     = m_Hvtrofacsndlist.m_ctgypurpprtry;
	m_cParser141.InstgAgtMmbId     = m_Hvtrofacsndlist.m_spjoinmmbid;
	m_cParser141.DbtrId     = m_Hvtrofacsndlist.m_dbtid;
	m_cParser141.DbtrMmbId     = m_Hvtrofacsndlist.m_dbtmmbid;
	m_cParser141.SttlmMtd     = "CLRG";
	m_cParser141.CdtrNm     = m_Hvtrofacsndlist.m_cdtrnm;
	m_cParser141.CdtrMmbId     = m_Hvtrofacsndlist.m_cdtmmbid;
	m_cParser141.Ccy     = m_Hvtrofacsndlist.m_currency;
	m_cParser141.TxId     = m_Hvtrofacsndlist.m_msgid;
	m_cParser141.DbtrNm     = m_Hvtrofacsndlist.m_dbtnm;
	m_cParser141.DbtrAcctId     = m_Hvtrofacsndlist.m_dbtracctid;
	m_cParser141.NbOfTxs     = "1";	//�̶���1
	m_cParser141.CdtrAcctIssr     = m_Hvtrofacsndlist.m_cdtrissr;
	m_cParser141.EndToEndId     = m_sEndtoEnd;   
	m_cParser141.CdtrId     = m_Hvtrofacsndlist.m_cdtid;
	m_cParser141.IntrBkSttlmAmt     = ftoa(szBuff, m_Hvtrofacsndlist.m_amount, 2);
	m_cParser141.DbtrAcctIssr	  = m_Hvtrofacsndlist.m_dbtrissr;
	m_cParser141.CdtrAdrLine	= m_Hvtrofacsndlist.m_cdtaddr;
	m_cParser141.DbtrAdrLine    = m_Hvtrofacsndlist.m_dbtaddr;
	m_cParser141.CreDtTm 	= m_ISODateTime;
	m_cParser141.CdtrAcctId	   = m_Hvtrofacsndlist.m_cdtracctid;
	m_cParser141.InstdAgtMmbId	  = "0000";//�̶���дΪCNAPS2����???
    
    //1�����ļ�ͷ
    m_cParser141.CreateXMlHeader("HVPS",                        \
                                m_Hvtrofacsndlist.m_workdate.c_str(), \
                                m_Hvtrofacsndlist.m_instgdrctpty.c_str(),\
                                m_Hvtrofacsndlist.m_instddrctpty.c_str(),\
                                "hvps.141.001.01",\
                                m_sMesgId.c_str()); 

	//2������������
	string strUsdTmp;

	strUsdTmp	=	"/F25/" + m_Hvtrofacsndlist.m_purpprtry;
	m_cParser141.SetUstrd(0, strUsdTmp.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_purpprtry:%s", strUsdTmp.c_str());
	
	strUsdTmp	=	"/E48/" + m_Hvtrofacsndlist.m_tranmunum;
	m_cParser141.SetUstrd(1, strUsdTmp.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_tranmunum:%s", strUsdTmp.c_str());

	//strUsdTmp	=	"/F31/" + m_Hvtrofacsndlist.m_rsflag;
	//m_cParser141.SetUstrd(3, strUsdTmp.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_rmk:%s", strUsdTmp.c_str());
	
	strUsdTmp	=	"/H01/" + m_Hvtrofacsndlist.m_rmk;
	m_cParser141.SetUstrd(4, strUsdTmp.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_rmk:%s", strUsdTmp.c_str());

    m_Sign.append("/F25/" + m_Hvtrofacsndlist.m_purpprtry + "|"
                    "/E48/" + m_Hvtrofacsndlist.m_tranmunum + "|");
                    //"/F31/" + m_Hvtrofacsndlist.m_rsflag + "|");
                    
	//3����ҵ���������ֵĸ�����
	int iDepth = 3;
    if("G103" == m_Hvtrofacsndlist.m_ctgypurpprtry)//ծȯ���С��Ҹ������滮��
    {
        GetTag2ND("/E40/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/D14/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/D32/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/D33/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/D11/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/D34/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/C19/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);
    }
    
    if("G106" == m_Hvtrofacsndlist.m_ctgypurpprtry)//��㽻���г�����
    {
        GetTag2ND("/F58/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);
    }

    if(("G109" == m_Hvtrofacsndlist.m_ctgypurpprtry) && ("03501" == m_Hvtrofacsndlist.m_purpprtry)) //��Ѻ����&&����֧��
    {
        GetTag2ND("/D35/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/A07/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/E50/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/A70/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/F60/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);            
    }
    
    if(("G109" == m_Hvtrofacsndlist.m_ctgypurpprtry) && ("03502" == m_Hvtrofacsndlist.m_purpprtry)) //��Ѻ����&&���ʿۿ�
    {
        GetTag2ND("/D36/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/D35/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/A07/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/D37/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/F59/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);            
    }
    
    if(("G107" == m_Hvtrofacsndlist.m_ctgypurpprtry) || ("G108" == m_Hvtrofacsndlist.m_ctgypurpprtry)) //�ʽ�ؽ���"��"�����Զ����
    {
        GetTag2ND("/E39/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/F50/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/F60/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/G00/", m_Hvtrofacsndlist.m_ustrdstr, iDepth);    
    }        
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps141::SetData...");
    return;
}

void CSendHvps141::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps141::SetDBKey...");

	m_Hvtrofacsndlist.m_msgid = m_szMsgFlagNO; 
	m_Hvtrofacsndlist.m_instgindrctpty = m_szSndNO; 
    //m_Hvtrofacsndlist.m_rsflag= "0";
	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvtrofacsndlist.m_msgid = %s", m_Hvtrofacsndlist.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvtrofacsndlist.m_instgindrctpty = %s", m_Hvtrofacsndlist.m_instgindrctpty.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps141::SetDBKey...");
    return;
}

int CSendHvps141::GetData()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps141::GetData...");

	SetDBKey();
	
    SETCTX(m_Hvtrofacsndlist);
	int iRet = m_Hvtrofacsndlist.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ�� iRet = %d, %s", iRet, m_Hvtrofacsndlist.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    if(!m_Hvtrofacsndlist.m_endtoendid.empty())
    {
        m_sEndtoEnd = m_Hvtrofacsndlist.m_endtoendid;
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sEndtoEnd = %s", m_sEndtoEnd.c_str());
    }
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps141::GetData...");
	return iRet;
}

int CSendHvps141::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps141::UpdateState...");
    
    SetDBKey();

    string strSQL;
	strSQL += "UPDATE hv_trofacsndlist t SET t.STATETIME = sysdate, t.PROCSTATE = '08'";
	strSQL += ", t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
	strSQL += "', t.EndToEndId = '";
	strSQL += m_sEndtoEnd;
    strSQL += "' ";
    
	strSQL += " WHERE t.MSGTP = '";
	strSQL += m_Hvtrofacsndlist.m_msgtp.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_Hvtrofacsndlist.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Hvtrofacsndlist.m_instgindrctpty.c_str(); 									
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());

	SETCTX(m_Hvtrofacsndlist);
    int iRet = m_Hvtrofacsndlist.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ�� iRet = %d, %s", iRet, m_Hvtrofacsndlist.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps141::UpdateState...");
    return iRet;
}

int CSendHvps141::ChargeMB()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps141::ChargeMB...");

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps141::ChargeMB..."); 
    
    return RTN_SUCCESS;
}

int CSendHvps141::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps141::FundSettle...");
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û�[%s]", m_szOprUser);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_szSndNO);

	m_charge.m_amount = m_Hvtrofacsndlist.m_amount;	//ҵ����
	m_charge.m_iDCFlag = iDEBITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, m_szOprUserNetId);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_szSndNO);	//������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(RTN_SUCCESS != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FundSettle iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps141::FundSettle..."); 
    
    return RTN_SUCCESS;
}


