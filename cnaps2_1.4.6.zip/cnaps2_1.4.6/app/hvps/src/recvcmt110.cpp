/******************************************************************** 
文件名： recvcmt110.cpp
创建人： aps-xcm
日  期： 2011-06-24
修改人：
日  期：
描  述： 大额来账处理银行汇票支付报文
版  本：
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvcmt110.h"

using namespace ZFPT;


CRecvCmt110::CRecvCmt110()
{
    m_strMsgTp = "CMT110";
}

CRecvCmt110::~CRecvCmt110()
{

}

INT32 CRecvCmt110::unPack(LPCSTR sMsg)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvCmt110::unPack...");
    Trace(L_INFO, __FILE__, __LINE__, NULL, "receive sMsg[%s]", sMsg);
    // 1、报文是否为空
    if(NULL == sMsg || '\0' == sMsg)
    {
        Trace(L_ERROR, __FILE__, __LINE__, m_strBizCode.c_str(), "报文为空");
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "报文为空");
    }

    int iRet = RTN_FAIL;

    //2.解析报文

    iRet = m_cCmt110.ParseCmt(sMsg);

    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "报文解析失败");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文解析失败");
    }

    char szTxssno[8 + 1] = {0};
    sprintf(szTxssno, "%08d", m_cCmt110.iTxssno);
    // 报文标识符,用于写错误文件名用
    m_strMsgID = m_cCmt110.sConsigndate;
    m_strMsgID += szTxssno;
    //ZFPTLOG.SetLogInfo("110", m_strMsgID.c_str());

    //获取工作日期
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS, m_cCmt110.sRecvsapbk);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "获取工作日期失败");
        PMTS_ThrowException(OPT_GET_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvCmt110::unPack...");

    return RTN_SUCCESS;
}

INT32 CRecvCmt110::SetData(LPCSTR pchMsg)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvCmt110::SetData...");

    m_cHvrcvexchglist.m_workdate        = m_strWorkDate;//工作日期
    m_cHvrcvexchglist.m_consigndate     = m_cCmt110.sConsigndate;//委托日期
    m_cHvrcvexchglist.m_msgtp           = m_strMsgTp;//报文类型
	m_cHvrcvexchglist.m_mesgid         = m_cCmt110.GetHeadMesgID();
	m_cHvrcvexchglist.m_mesgrefid      = m_cCmt110.GetHeadMesgReqNo();
    m_cHvrcvexchglist.m_msgid           = m_strMsgID;//报文标识号c
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgID= [%s]",m_strMsgID.c_str());
    //m_cHvrcvexchglist.m_endtoendid     = ;//端到端标识号
    m_cHvrcvexchglist.m_instgdrctpty     = m_cCmt110.sSendsapbk;//发起直接参与机构
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSendsapbk= [%s]",m_cCmt110.sSendsapbk);
    m_cHvrcvexchglist.m_instgindrctpty   = m_cCmt110.sSendbank;//发起参与机构
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSendbank= [%s]",m_cCmt110.sSendbank);
    m_cHvrcvexchglist.m_instddrctpty     = m_cCmt110.sRecvsapbk;//接收直接参与机构
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sRecvsapbk= [%s]",m_cCmt110.sRecvsapbk);
    m_cHvrcvexchglist.m_instdindrctpty   = m_cCmt110.sRecvbank;//接收参与机构
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sRecvbank= [%s]",m_cCmt110.sRecvbank);
    m_cHvrcvexchglist.m_sttlmprty        = m_cCmt110.GetPayPRI();//业务优先级
    m_cHvrcvexchglist.m_dbtrmmbid        = m_cCmt110.sSendsapbk;//付款清算行行号
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSendsapbk= [%s]",m_cCmt110.sSendsapbk);
    //m_cHvrcvexchglist.m_dbtnm            = m_cCmt110.sPayername;//付款人名称
    SetGbkToUtf8(m_cCmt110.sPayername,m_cHvrcvexchglist.m_dbtnm);
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayername= [%s]",m_cCmt110.sPayername);
    m_cHvrcvexchglist.m_dbtracctid       = m_cCmt110.sPayeracc;//付款人账号
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayeracc= [%s]",m_cCmt110.sPayeracc);
    m_cHvrcvexchglist.m_dbtid            = m_cCmt110.sPayopenbk;//付款行号 �= 付款人开户行号
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayopenbk= [%s]",m_cCmt110.sPayopenbk);
    m_cHvrcvexchglist.m_dbtrissr         = m_cCmt110.sPayopenbk;//付款人开户行号
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayopenbk= [%s]",m_cCmt110.sPayopenbk);
    m_cHvrcvexchglist.m_cdtrmmbid        = m_cCmt110.sRecvsapbk;//收款清算行号
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sRecvsapbk= [%s]",m_cCmt110.sRecvsapbk);
    //m_cHvrcvexchglist.m_cdtrnm           = m_cCmt110.sPayeename;//收款人名称
    SetGbkToUtf8(m_cCmt110.sPayeename,m_cHvrcvexchglist.m_cdtrnm);
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayeename= [%s]",m_cCmt110.sPayeename);
    //m_cHvrcvexchglist.m_cdtracctid       = m_cCmt110.sPayeeacc;//收款人账号
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayeeacc= [%s]",m_cCmt110.sPayeeacc);
    m_cHvrcvexchglist.m_cdtid            = m_cCmt110.sPayeeopenbk;//收款行行号
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayeeopenbk= [%s]",m_cCmt110.sPayeeopenbk);
    m_cHvrcvexchglist.m_cdtrissr         = m_cCmt110.sPayeeopenbk;//收款人开户行行号
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayeeopenbk= [%s]",m_cCmt110.sPayeeopenbk);
    m_cHvrcvexchglist.m_procstate        = PR_HVBP_19;//处理状态
    m_cHvrcvexchglist.m_amount           = m_cCmt110.dAmount;//交易金额
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "dAmount= [%f]",m_cCmt110.dAmount);
    m_cHvrcvexchglist.m_currency         = m_cCmt110.sCur;//货币符号
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sCur= [%s]",m_cCmt110.sCur);
    
    m_cHvrcvexchglist.m_ctgypurpprtry  = "11000";//业务类型编码
    //m_cHvrcvexchglist.m_finalstatedate = ;//清算日期
    m_cHvrcvexchglist.m_purpprtry        = "11000";//业务种类编码
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sTradetype= [%s]",m_cCmt110.sTradetype);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sRecvcenter= [%s]",m_cCmt110.sRecvcenter);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSendcenter= [%s]",m_cCmt110.sSendcenter);
    m_cHvrcvexchglist.m_busistate        = BZ_CLEARED_PR04;//业务状态
    //m_cHvrcvexchglist.m_processcode    = ;//业务处理码
    //m_cHvrcvexchglist.m_rjctinf        = ;//业务拒绝信息
    //m_cHvrcvexchglist.m_acctstate      = ;//记账状态
    //m_cHvrcvexchglist.m_statetime      = ;//处理状态变更时间
    //m_cHvrcvexchglist.m_acstatetime    = ;//记账状态变更时间
    //m_cHvrcvexchglist.m_acctregnum     = ;//记账流水号
    //m_cHvrcvexchglist.m_checkstate     = ;//与NPC对账状态
    //m_cHvrcvexchglist.m_mbcheckstate   = ;//与行内对账状态
    m_cHvrcvexchglist.m_ustrdstr         = "59E:";//附加域
    m_cHvrcvexchglist.m_ustrdstr        += m_cCmt110.sLastholdno;
    m_cHvrcvexchglist.m_ustrdstr        += ":59D:";
    m_cHvrcvexchglist.m_ustrdstr        += m_cCmt110.sLastholdname;
    m_cHvrcvexchglist.m_ustrdstr         = ":30B:";
    m_cHvrcvexchglist.m_ustrdstr        += m_cCmt110.sBilldate;
    m_cHvrcvexchglist.m_ustrdstr        += ":21A:";
    m_cHvrcvexchglist.m_ustrdstr        += m_cCmt110.sBillno;
    m_cHvrcvexchglist.m_ustrdstr        += ":33C:";
    char szTemp[15 + 1] = {0};
    sprintf(szTemp, "%f", m_cCmt110.dTicketamount);
    m_cHvrcvexchglist.m_ustrdstr        += szTemp;
    m_cHvrcvexchglist.m_ustrdstr        += ":33D:";
    memset(szTemp, 0, 16);
    sprintf(szTemp, "%f", m_cCmt110.dMoreamount);
    m_cHvrcvexchglist.m_ustrdstr        += szTemp;
    //m_cHvrcvexchglist.m_addinfo              = m_cCmt110.sRemark;//备注
    SetGbkToUtf8(m_cCmt110.sRemark,m_cHvrcvexchglist.m_addinfo);
    //m_cHvrcvexchglist.m_reserve        = ;//保留域
    //m_cHvrcvexchglist.m_npcmsg         = ;//NPC报文
    //m_cHvrcvexchglist.m_mbmsg          = ;//MB报文
    //int m_printno                      = ;//打印次数
    //m_cHvrcvexchglist.m_iststatetime   = ;//入库时间
    //m_cHvrcvexchglist.m_isrbflg        = ;//是否退汇标志
    //m_cHvrcvexchglist.m_recvdest       = ;//接收目标
    //m_cHvrcvexchglist.m_dbtaddr        = m_cCmt110.sPayeraddr;//付款人地址
    SetGbkToUtf8(m_cCmt110.sPayeraddr,m_cHvrcvexchglist.m_dbtaddr);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayeraddr= [%s]",m_cCmt110.sPayeraddr);
    //m_cHvrcvexchglist.m_cdtaddr          = m_cCmt110.sPayeeaddr;//收款人地址
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayeeaddr= [%s]",m_cCmt110.sPayeeaddr);
    m_cHvrcvexchglist.m_srcflag        = "0";//补发标志 0:正常 1:对账补发

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvCmt110::SetData...");

    return RTN_SUCCESS;
}

INT32 CRecvCmt110::InsertData(void)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvCmt110::InsertData...");

    int iRet = RTN_FAIL;
    
    //设置连接
    iRet = m_cHvrcvexchglist.setctx(m_dbproc);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, m_strMsgID.c_str(), "setctx error");
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }

    //新增数据库
    if(RTN_SUCCESS != m_cHvrcvexchglist.insert())
    {
        sprintf(m_szErrMsg, "大额来帐汇兑明细表hv_rcvexchglist插入数据失败[%s], [%d][%s]",
            m_strMsgID.c_str(), iRet, m_cHvrcvexchglist.GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
        
    }

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvCmt110::InsertData...");

    return RTN_SUCCESS;
    
}

INT32 CRecvCmt110::Work(LPCSTR sMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvCmt110::Work()");

    // 1.解析报文
    unPack(sMsg);
    
    // 2.给m_cHvrcvexchglist的成员赋值
    SetData(sMsg);

    // 3.操作大额来帐汇兑明细表hv_rcvexchglist，插入数据
    InsertData();
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvCmt110::Work()");

    return RTN_SUCCESS;
}

