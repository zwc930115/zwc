/******************************************************************** 
 文件名： recvhvps711.h
 创建人： hq
 日  期： 2011-05-10
 修改人： 
 日  期： 
 描  述： 大额业务汇总核对报文<hvps.711.001.01>
 版  本： 
 Copyright (c) 2011  YLINK 
 ********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#include <math.h>
#endif

#include "recvhvps711.h"
#include "sysmbchkst.h"
#include "hvbkchkst.h"
using namespace ZFPT;

extern char		g_SendQueue[128];

CRecvHvps711::CRecvHvps711()
{
    m_bCheckOk = true;
    m_strMsgTp = "hvps.711.001.01";
}

CRecvHvps711::~CRecvHvps711()
{
    
}


int CRecvHvps711::Work(LPCSTR szMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps711::Work()");

	int iRet = -1;
	
	// 设置连接
	SetAllCtx();

	
	// 解析711报文
	iRet = UnPack(szMsg);

	if(!ChickIfContuine())
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Do nothing return");
		return 0;
	}
	// 修改清算行信息表的对账日期
	updateSapBank();
	
	// 删除大额汇总核对表数据
	DeleteCheckCl();
	  
	// 如果汇总笔数大于0，将数据插入大额汇总核对表
	if ( RTN_SUCCESS ==  iRet )
	{   
		FillCheckCl();
	}
	
	// 数字签名核押
	CheckSign711();
	
	// 修改大额对帐状态为:收到汇总对账
	updateBkChkSt(PR_CNCH_20);
	
	// 提交事务
	m_hvcheckcl.commit();
	
        
	// 调汇总对账类
	
	m_hvchecksum.doCheckSumWork(m_dbproc, 
	                            0, 
	                            m_hvps711.ChckDt.c_str(),
	                            m_hvps711.InstdDrctPty.c_str(),
	                            m_cMQAgent,
	                            g_SendQueue);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps711::Work()");
	return 0;
}

bool CRecvHvps711::ChickIfContuine()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps711::ChickIfContuine()");

    char sSql[1024 + 1] = {0};
    int  iRet = -1;
    
    sprintf(sSql, "CHECKDATE = '%s' AND SAPBANK = '%s'",
                    m_hvps711.ChckDt.c_str(), m_hvps711.InstdDrctPty.c_str() );

	SETCTX(m_sapbankinfo);	
	iRet = m_sapbankinfo.find(sSql);
	if(0 != iRet)
	{	
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FIND HV_SAPBANKINFO FILED[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "FIND HV_SAPBANKINFO FILED!");
	}
	else
	{
		iRet = m_sapbankinfo.fetch();
		if( 1403 == iRet)
		{
			Trace(L_INFO,	__FILE__,  __LINE__, NULL, "Now FIRST CHECK");
			m_sapbankinfo.closeCursor();
			return true;
		}		
	}
	
	m_sapbankinfo.closeCursor();

	m_checkqry.m_msgid = m_hvps711.OrgnlMsgId;
	m_checkqry.m_msgtype = m_hvps711.OrgnlMT;
	m_checkqry.m_sapbank = m_hvps711.InstdDrctPty;
	SETCTX(m_checkqry);
	iRet = m_checkqry.findByPK();
	if(1403 != iRet && 0 != iRet)
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FIND CM_CHECKQRY FILED[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "FIND CM_CHECKQRY FILED!");
	}
	else if(1403 == iRet)
	{	
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "MSGID=[%s] MSGTP=[%s] SAPBANK=[%s] NOT PMTS QRY",
			                        m_checkqry.m_msgid.c_str(),m_checkqry.m_msgtype.c_str(),m_checkqry.m_sapbank.c_str());		
		return false;
	}
	else{
		string strSql = "SAPBANK = '"+ m_checkqry.m_sapbank + "' AND CHECKDATE = '" + m_hvps711.ChckDt +"' AND MSGTYPE = 'hvps.710.001.01'";
		
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=[%s]",strSql.c_str());
		
		iRet = m_checkqry.findcount(strSql);

		if(1403 != iRet && 0 != iRet)
		{
	        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FIND CM_CHECKQRY FILED[%d]", iRet);
	        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "FIND CM_CHECKQRY FILED!");
		}
		if(m_checkqry.m_iCount > 3)
		{
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql[%s] times[%d] > 3",strSql.c_str(),m_checkqry.m_iCount);
		
			return false;
		}
		else
		{
			return true;
		}		
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "CRecvHvps711::ChickIfContuine()");
	return true;
}


int CRecvHvps711::UnPack(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps711::UnPack()");

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "szMsg[%s]", szMsg);
    
    int  iRet = -1;
    int  iTtlCnt = 0;

	// 解析报文
    iRet = m_hvps711.ParseXml(szMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "解析报文失败[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "解析报文失败!");
    }
    
	// 判断总笔数
    iTtlCnt = atoi(m_hvps711.TtlPmt.c_str()) + atoi(m_hvps711.TtlMsg.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "总笔数[%d],业务报文[%d],信息报文[%d]", 
		iTtlCnt, atoi(m_hvps711.TtlPmt.c_str()), atoi(m_hvps711.TtlMsg.c_str()));
	
    // 获取工作日期
	iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS, m_hvps711.InstdDrctPty.c_str());
	if(iRet != 0){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"获取[%s]工作日期失败!", m_hvps711.InstdDrctPty.c_str());
		PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
	}
	m_strWorkDate = m_sWorkDate;
	m_strMsgID = m_hvps711.MsgId;

    if (iTtlCnt == 0)
    {
        sprintf(m_szErrMsg, "当前对账日期[%s]无汇总核对记录, 无需对账!", 
            m_hvps711.ChckDt.c_str());
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        //NotifyOprUser(m_dbproc, "2", "01", m_szErrMsg, m_hvps711.InstdDrctPty.c_str());
        return 1;
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps711::UnPack()");
    return RTN_SUCCESS;
}

void CRecvHvps711::updateSapBank()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvHvps711::updateSapBank()");

    char sUpSql[1024 + 1] = {0};
    int  iRet = -1;
    
    sprintf(sUpSql, "UPDATE HV_SAPBANKINFO SET CHECKDATE = '%s' WHERE SAPBANK = '%s'",
                    m_hvps711.ChckDt.c_str(), m_hvps711.InstdDrctPty.c_str() );

    SETCTX(m_hvcheckcl);
    iRet = m_hvcheckcl.execsql(sUpSql);
    if ( iRet != SQL_SUCCESS )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "更新HV_SAPBANKINFO表失败[%d][%s]", 
            iRet, m_hvcheckcl.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新HV_SAPBANKINFO表失败");
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps711::updateSapBank()");
}

void CRecvHvps711::updateBkChkSt(LPCSTR _sChkSt)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvHvps711::updateBkChkSt()");

    int iRet = -1;

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "_sChkSt[%s]", _sChkSt);
    
    iRet = m_checkaccount.upHvBkChkSt(m_hvps711.InstdDrctPty.c_str(), m_hvps711.ChckDt.c_str(), _sChkSt);
    if ( iRet != SQL_SUCCESS && 1403 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "更新HV_BKCHKST表失败[%d][%s]", 
            iRet, m_checkaccount.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新HV_BKCHKST表失败");
    }
    else if(1403 == iRet)//增加异常处理
    {
        CHvbkchkst m_Hvbkchkst;
        SETCTX(m_Hvbkchkst);
        m_Hvbkchkst.m_checkstate = _sChkSt;
        m_Hvbkchkst.m_sapbank = m_hvps711.InstdDrctPty;
        m_Hvbkchkst.m_checkdate = m_hvps711.ChckDt;
        
        iRet = m_Hvbkchkst.insert();
        if ( iRet != SQL_SUCCESS)
        {
            Trace(L_ERROR, __FILE__, __LINE__, NULL, "insert HV_BKCHKST表失败[%d][%s]", 
                iRet, m_checkaccount.GetSqlErr());
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "insert HV_BKCHKST表失败");
        }        
    }
    else{
        //do nothing    
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CRecvHvps711::updateBkChkSt()");
}

void CRecvHvps711::DeleteCheckCl()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvHvps711::DeleteCheckCl()");

    string szDelSql = "";
    int iRet = -1;
    
    szDelSql = "delete from HV_CHECKCL t where t.CHCKDT = '";
    szDelSql += m_hvps711.ChckDt;
    szDelSql += "' and INSTDDRCTPTY = '";
    szDelSql += m_hvps711.InstdDrctPty;
    szDelSql += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "szDelSql=[%s]",szDelSql.c_str());

    iRet = m_hvcheckcl.execsql(szDelSql);
    if ( iRet != SQL_SUCCESS && iRet != SQLNOTFOUND )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "删除HV_CHECKCL表失败[%d][%s]", 
            iRet, m_hvcheckcl.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "删除HV_CHECKCL表失败");
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CRecvHvps711::DeleteCheckCl()");
}

void CRecvHvps711::FillCheckCl()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps711::FillCheckCl()");

    int  iCount = 0;
    string szSndSum = "";
    string szRcvSum = "";
    
    //业务报文对账清单
    iCount = m_hvps711.GetPmtInfDetailCnt();
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ChckPmtInfDtls iCount[%d]", iCount);
    
   	for(int i=0; i<iCount; i++)
   	{
        m_hvps711.ParsePmtInfDetail(i);
	
    ClearCycleValue();

   	    m_szMT          = m_hvps711.GetValueFromCycle("ChckPmtInfDtls", "ChckPmtInfDtlsMT", i);
        m_szTxTpCd      = m_hvps711.GetValueFromCycle("ChckPmtInfDtls", "ChckPmtInfDtlsTxTpCd", i);
        m_szSndgNbOfTxs = m_hvps711.GetValueFromCycle("ChckPmtInfDtls", "ChckPmtInfDtlsSndgNbOfTxs", i);

        szSndSum        = m_hvps711.GetValueFromCycle("ChckPmtInfDtls", "SndgCtrlSum", i);
        m_szSndCcy      = szSndSum.substr(0,3);
        m_szSndgCtrlSum = szSndSum.substr(3);
        
        m_szRcvgNbOfTxs = m_hvps711.GetValueFromCycle("ChckPmtInfDtls", "ChckPmtInfDtlsRcvgNbOfTxs", i);

        szRcvSum        = m_hvps711.GetValueFromCycle("ChckPmtInfDtls", "RcvgCtrlSum", i);
        m_szRcvCcy      = szRcvSum.substr(0,3);
        m_szRcvgCtrlSum = szRcvSum.substr(3);

        m_szPrcSts      = m_hvps711.GetValueFromCycle("ChckPmtInfDtls", "ChckPmtInfDtlsPrcSts", i);     

        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMT[%s]",          m_szMT.c_str());
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szTxTpCd[%s]",      m_szTxTpCd.c_str());
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndgNbOfTxs[%s]", m_szSndgNbOfTxs.c_str());
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndgCtrlSum[%s]", m_szSndgCtrlSum.c_str());
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndCcy[%s]",      m_szSndCcy.c_str());
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szRcvgNbOfTxs[%s]", m_szRcvgNbOfTxs.c_str());
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szRcvgCtrlSum[%s]", m_szRcvgCtrlSum.c_str());
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szRcvCcy[%s]",      m_szRcvCcy.c_str());
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szPrcSts[%s]",      m_szPrcSts.c_str());       

        //写入对账汇总表
        InsertToCheckCl();
    }

    //信息报文对账清单
    iCount = m_hvps711.GetMsgInfDetailCnt();
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ChckMsg iCount[%d]",iCount);
    
   	for(int i=0; i<iCount; i++)
   	{
        m_hvps711.ParseMsgInfDetail(i);
        
   	    ClearCycleValue();

   	    m_szMT          = m_hvps711.GetValueFromCycle("ChckMsg", "ChckMsgMT", i);
        m_szTxTpCd      = m_hvps711.GetValueFromCycle("ChckMsg", "ChckMsgTxTpCd", i);
        m_szSndgNbOfTxs = m_hvps711.GetValueFromCycle("ChckMsg", "ChckMsgSndgNbOfTxs", i);
        m_szRcvgNbOfTxs = m_hvps711.GetValueFromCycle("ChckMsg", "ChckMsgRcvgNbOfTxs", i);
        m_szPrcSts      = m_hvps711.GetValueFromCycle("ChckMsg", "ChckMsgPrcSts", i);          

        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMT[%s]",          m_szMT.c_str());
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szTxTpCd[%s]",      m_szTxTpCd.c_str());
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndgNbOfTxs[%s]", m_szSndgNbOfTxs.c_str());
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szRcvgNbOfTxs[%s]", m_szRcvgNbOfTxs.c_str());
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szPrcSts[%s]",      m_szPrcSts.c_str());       

        //写入对账汇总表
        InsertToCheckCl();
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps711::FillCheckCl()");
}

void CRecvHvps711::ClearCycleValue()
{
    m_szMT          = "";     //报文编号
    m_szTxTpCd      = "";     //业务类型编码
    m_szSndgNbOfTxs = "";     //发起总笔数
    m_szSndgCtrlSum = "";     //发起总金额
    m_szSndCcy      = "";     //发起币种
    m_szRcvgNbOfTxs = "";     //接收总笔数
    m_szRcvgCtrlSum = "";     //接收总金额
    m_szRcvCcy      = "";     //接收币种
    m_szPrcSts      = "";     //处理状态
}

void CRecvHvps711::InsertToCheckCl()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps711::InsertToCheckCl()");

    char sCheckState[2 + 1] = {0};
    int  iRet = -1;
    int  iLSndCount = 0;
    int  iLRcvCount = 0;
    double dLSndSum = 0.00;
    double dLRcvSum = 0.00;
    string szSndTableNm = "";
    string szRcvTableNm = "";
    stCheckSum stTemp;
    
    // 1、说明
    // 需对账的状态:
    //支付类:PR04已清算/PR08已撤销/PR09已拒绝
    //信息类:PR00已转发/PR09已拒绝
    
    // 需对账报文:
    //二代:共7种报文
    //111,112对应表HV_RCVEXCHGLIST/HV_SNDEXCHGLIST
    //141对应表HV_TROFACSNDLIST
    //314,315对应表CM_TRANSINFOQRY
    //(631,633暂时不做,特许参与者用的)

    //一代:共14种报文
    //支付类:
    //100,101,102,108,121,122,123,124对应二代111报文
    //103,105对应二代112报文
    //109暂不做
    //232,407,408对应二代141报文
 
  Trace(L_INFO,  __FILE__,  __LINE__, NULL, "取本地汇总数据");
    //2、取本地汇总数据
    if ( "hvps.111.001.01" == m_szMT 
      || "hvps.112.001.01" == m_szMT
      //add by zwc 20171123 for cnaps_v1.4.6
      || "hvps.115.001.01" == m_szMT
      || "hvps.116.001.01" == m_szMT
      || "hvps.118.001.01" == m_szMT
      //add end
      || "CMT100" == m_szMT
      || "CMT101" == m_szMT
      || "CMT102" == m_szMT
      || "CMT103" == m_szMT
      || "CMT105" == m_szMT
      || "CMT108" == m_szMT
      || "CMT121" == m_szMT
      || "CMT122" == m_szMT
      || "CMT123" == m_szMT
      || "CMT124" == m_szMT)
    {
    		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_szMT=%s",m_szMT.c_str());
        //往账
        szSndTableNm = "SNDEXCHGLIST";
        getLocalData(szSndTableNm.c_str(), m_szSndCcy.c_str(), iLSndCount, dLSndSum);

        //来账
        szRcvTableNm = "RCVEXCHGLIST";
        getLocalData(szRcvTableNm.c_str(), m_szRcvCcy.c_str(), iLRcvCount, dLRcvSum);
    }
    else if ( "hvps.141.001.01" == m_szMT 
           || "hvps.141.002.01" == m_szMT
           || "CMT232" == m_szMT
           || "CMT407" == m_szMT
           || "CMT408" == m_szMT)
    {
    	  Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_szMT=%s",m_szMT.c_str());
        //往账
        szSndTableNm = "SNDTROFACSNDLIST";
        getLocalData(szSndTableNm.c_str(), m_szSndCcy.c_str(), iLSndCount, dLSndSum);

        //来账
        szRcvTableNm = "RCVTROFACSNDLIST";
        getLocalData(szRcvTableNm.c_str(), m_szRcvCcy.c_str(), iLRcvCount, dLRcvSum);
    }
    else if ( "hvps.633.001.01" == m_szMT )
    {
    	  Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_szMT=%s",m_szMT.c_str());
        //往账:无
        iLSndCount = 0;
        dLSndSum   = 0.00;
        
        //来账
        szRcvTableNm = "RCVMNETSTLNTC";
        getLocalData(szRcvTableNm.c_str(), m_szRcvCcy.c_str(), iLRcvCount, dLRcvSum);
    }
    else if ( "ccms.314.001.01" == m_szMT 
           || "ccms.315.001.01" == m_szMT
           || "CMT301" == m_szMT
           || "CMT302" == m_szMT)
    {
    	  Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_szMT=%s",m_szMT.c_str());
        //往账
        szSndTableNm = "SNDTRANSINFOQRY";
        getLocalData(szSndTableNm.c_str(), m_szSndCcy.c_str(), iLSndCount, dLSndSum);
        m_szSndgCtrlSum = "0.00";

        //来账
        szRcvTableNm = "RCVTRANSINFOQRY";
        getLocalData(szRcvTableNm.c_str(), m_szRcvCcy.c_str(), iLRcvCount, dLRcvSum);
        m_szRcvgCtrlSum = "0.00";
    }
    else
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "不支持的报文类型[%s]", m_szMT.c_str());
        PMTS_ThrowException(__FILE__, __LINE__, ERR_NOT_FOUND_NO, "不支持的报文类型");
    }
    
    //浮点型精度不准确 将本地的金额与来报金额相减 如果误差小于千分位则认为相等
    double sndsub = atof(m_szSndgCtrlSum.c_str()) - dLSndSum;
    double rcvsub = atof(m_szRcvgCtrlSum.c_str()) - dLRcvSum;
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "sndsub[%.5f],rcvsub[%.5f]", sndsub,rcvsub);
    //3、比较数据
    if (   atoi(m_szSndgNbOfTxs.c_str()) == iLSndCount
        //&& fabs(sndsub) < 0.001
        && atoi(m_szRcvgNbOfTxs.c_str()) == iLRcvCount )
    {
        strcpy(sCheckState, PR_CNCH_01); //对账相符  
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "报文类型[%s],业务类型[%s]", m_szMT.c_str(),m_szTxTpCd.c_str());
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "对帐相符,往报笔数[%s][本地%d],往报金额[%s][本地%f]", m_szSndgNbOfTxs.c_str(),iLSndCount,m_szSndgCtrlSum.c_str(),dLSndSum);
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "对帐相符,来报笔数[%s][本地%d],来报金额[%s][本地%f]", m_szRcvgNbOfTxs.c_str(),iLRcvCount,m_szRcvgCtrlSum.c_str(),dLRcvSum);
    }
    else
    {
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "报文类型[%s],业务类型[%s]", m_szMT.c_str(),m_szTxTpCd.c_str());
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "对帐不符,往报笔数[%s][本地%d],往报金额[%s][本地%f]", m_szSndgNbOfTxs.c_str(),iLSndCount,m_szSndgCtrlSum.c_str(),dLSndSum);
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "对帐不符,来报笔数[%s][本地%d],来报金额[%s][本地%f]", m_szRcvgNbOfTxs.c_str(),iLRcvCount,m_szRcvgCtrlSum.c_str(),dLRcvSum);
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndgNbOfTxs[%d],m_szRcvgNbOfTxs[%d]",atoi(m_szSndgNbOfTxs.c_str()), atoi(m_szRcvgNbOfTxs.c_str()));
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndgCtrlSum[%f],m_szRcvgCtrlSum[%f]",atof(m_szSndgCtrlSum.c_str()), atof(m_szRcvgCtrlSum.c_str()));
        
        m_bCheckOk = false;
        strcpy(sCheckState, PR_CNCH_02); //对账不符
        m_hvchecksum.m_szMT     = m_szMT;
        m_hvchecksum.m_szTxTpCd = m_szTxTpCd;
        m_hvchecksum.m_szPrcSts = m_szPrcSts;
            
        if ( atoi(m_szSndgNbOfTxs.c_str()) != iLSndCount
          )
        {
            Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "往报对帐不符");
            //往账不符,且人行笔数大于零时,下载明细
            if ( 0 < atoi(m_szSndgNbOfTxs.c_str()) )
            {
                m_hvchecksum.m_iTtlCnt++;
                m_hvchecksum.AddDetail("SR00"); 
            }
            /*
            //往账不符,且人行笔数为零时,直接更新本地状态为本地多
            else 
            {
                m_hvchecksum.m_iLocalMore++;
                memset(&stTemp, 0x00, sizeof(stTemp));
                strncpy(stTemp.sTableNm, szSndTableNm.c_str(),           sizeof(stTemp.sTableNm) - 1);
                strncpy(stTemp.sCheckSt, PR_CNCH_05,                     sizeof(stTemp.sTableNm) - 1);
                strncpy(stTemp.sMt,      m_szMT.c_str(),                 sizeof(stTemp.sMt)      - 1);
                strncpy(stTemp.sBkCode,  m_hvps711.InstdDrctPty.c_str(), sizeof(stTemp.sBkCode)  - 1);
                strncpy(stTemp.sPrcSts,  m_szPrcSts.c_str(),             sizeof(stTemp.sPrcSts)  - 1);
                strncpy(stTemp.sChkDt,   m_hvps711.ChckDt.c_str(),       sizeof(stTemp.sChkDt)   - 1);
                strncpy(stTemp.sTxTpCd,  m_szTxTpCd.c_str(),             sizeof(stTemp.sTxTpCd)  - 1);
                strncpy(stTemp.sCcy,     m_szSndCcy.c_str(),             sizeof(stTemp.sCcy)     - 1);
                
                m_hvchecksum.VCheckArray.push_back(stTemp);
            }*/
        }
        if ( atoi(m_szRcvgNbOfTxs.c_str()) != iLRcvCount
           )
        {
            Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "来报对帐不符");
            //来账不符,且人行笔数大于零时,下载明细
            if ( 0 < atoi(m_szRcvgNbOfTxs.c_str()) )
            {
                m_hvchecksum.m_iTtlCnt++;
                m_hvchecksum.AddDetail("SR01"); 
            }
            /*
            //来账不符,且人行笔数为零时,直接更新本地状态为本地多
            else 
            {
                m_hvchecksum.m_iLocalMore++;
                memset(&stTemp, 0x00, sizeof(stTemp));
                strncpy(stTemp.sTableNm, szRcvTableNm.c_str(),           sizeof(stTemp.sTableNm) - 1);
                strncpy(stTemp.sCheckSt, PR_CNCH_05,                     sizeof(stTemp.sTableNm) - 1);
                strncpy(stTemp.sMt,      m_szMT.c_str(),                 sizeof(stTemp.sMt)      - 1);
                strncpy(stTemp.sBkCode,  m_hvps711.InstdDrctPty.c_str(), sizeof(stTemp.sBkCode)  - 1);
                strncpy(stTemp.sPrcSts,  m_szPrcSts.c_str(),             sizeof(stTemp.sPrcSts)  - 1);
                strncpy(stTemp.sChkDt,   m_hvps711.ChckDt.c_str(),       sizeof(stTemp.sChkDt)   - 1);
                strncpy(stTemp.sTxTpCd,  m_szTxTpCd.c_str(),             sizeof(stTemp.sTxTpCd)  - 1);
                strncpy(stTemp.sCcy,     m_szRcvCcy.c_str(),             sizeof(stTemp.sCcy)     - 1);
                
                m_hvchecksum.VCheckArray.push_back(stTemp);
            }*/
        }
    }

    //4、入库
  m_hvcheckcl.m_chckdt            = m_hvps711.ChckDt;              //对账日期
	m_hvcheckcl.m_msgtp             = m_szMT;                        //报文类型
	m_hvcheckcl.m_msgid             = m_hvps711.MsgId;               //报文标识号
	m_hvcheckcl.m_txtpcd            = m_szTxTpCd;                    //业务类型编码
	m_hvcheckcl.m_prcsts            = m_szPrcSts;                    //报文处理状态
	m_hvcheckcl.m_instddrctpty      = m_hvps711.InstdDrctPty;        //接收直接参与机构
	m_hvcheckcl.m_workdate          = m_strWorkDate;                 //工作日期
	m_hvcheckcl.m_remark            = m_hvps711.Rmk;                 //备注
	m_hvcheckcl.m_orgnlmsgid        = m_hvps711.OrgnlMsgId;          //原报文标识号
	m_hvcheckcl.m_orgnlinstgdrctpty = m_hvps711.OrgnlInstgPty;       //原发起机构号
	m_hvcheckcl.m_orgnlmsgtp        = m_hvps711.OrgnlMT;             //原报文类型
	m_hvcheckcl.m_sndgnboftxs       = atoi(m_szSndgNbOfTxs.c_str()); //发起总笔数
	m_hvcheckcl.m_sndgctrlsum       = atof(m_szSndgCtrlSum.c_str()); //发起总金额
	m_hvcheckcl.m_sndgctrlsumccy    = m_szSndCcy;                    //发起币种
	m_hvcheckcl.m_rcvgnboftxs       = atoi(m_szRcvgNbOfTxs.c_str()); //接收总笔数
	m_hvcheckcl.m_rcvgctrlsum       = atof(m_szRcvgCtrlSum.c_str()); //接收总金额
	m_hvcheckcl.m_rcvgctrlsumccy    = m_szRcvCcy;                    //接收币种
	m_hvcheckcl.m_lsndgnboftxs      = iLSndCount;                    //本地发起总笔数
	m_hvcheckcl.m_lsndgctrlsum      = dLSndSum;                      //本地发起总金额
	m_hvcheckcl.m_lsndgctrlsumccy   = m_szSndCcy;                    //本地发起币种
	m_hvcheckcl.m_lrcvgnboftxs      = iLRcvCount;                    //本地接收总笔数
	m_hvcheckcl.m_lrcvgctrlsum      = dLRcvSum;                      //本地接收总金额
	m_hvcheckcl.m_lrcvgctrlsumccy   = m_szRcvCcy;                    //本地接收币种
	m_hvcheckcl.m_checkstate        = sCheckState;                   //与NPC汇总核对状态
	m_hvcheckcl.m_procstate         = "18";                          //处理状态:18已处理
	m_hvcheckcl.m_printno           = 0;                             //打印次数
    
	iRet = m_hvcheckcl.insert();
	if ( SQL_SUCCESS != iRet )
	{
		sprintf(m_szErrMsg, "新增HV_CHECKCL失败[%d][%s]", iRet, m_hvcheckcl.GetSqlErr());
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);      
	}

    //5、如果对账相符且笔数大于零:将需要更新的表存到容器，统一在hvchecksum里执行.
    if (   atoi(m_szSndgNbOfTxs.c_str()) == iLSndCount
 //       && fabs(sndsub) < 0.001 
        && 0 < iLSndCount )
    {   
        memset(&stTemp, 0x00, sizeof(stTemp));
        strncpy(stTemp.sTableNm, szSndTableNm.c_str(),           sizeof(stTemp.sTableNm) - 1);
        strncpy(stTemp.sCheckSt, PR_CNCH_01,                     sizeof(stTemp.sTableNm) - 1);
        strncpy(stTemp.sMt,      m_szMT.c_str(),                 sizeof(stTemp.sMt)      - 1);
        strncpy(stTemp.sBkCode,  m_hvps711.InstdDrctPty.c_str(), sizeof(stTemp.sBkCode)  - 1);
        strncpy(stTemp.sPrcSts,  m_szPrcSts.c_str(),             sizeof(stTemp.sPrcSts)  - 1);
        strncpy(stTemp.sChkDt,   m_hvps711.ChckDt.c_str(),       sizeof(stTemp.sChkDt)   - 1);
        strncpy(stTemp.sTxTpCd,  m_szTxTpCd.c_str(),             sizeof(stTemp.sTxTpCd)  - 1);
        strncpy(stTemp.sCcy,     m_szSndCcy.c_str(),             sizeof(stTemp.sCcy)     - 1);
        
        m_hvchecksum.VCheckArray.push_back(stTemp);
    }
    if ( atoi(m_szRcvgNbOfTxs.c_str()) == iLRcvCount
        //&& fabs(rcvsub) < 0.001  
      && 0 < iLRcvCount)
    {
        memset(&stTemp, 0x00, sizeof(stTemp));
        strncpy(stTemp.sTableNm, szRcvTableNm.c_str(),           sizeof(stTemp.sTableNm) - 1);
        strncpy(stTemp.sCheckSt, PR_CNCH_01,                     sizeof(stTemp.sTableNm) - 1);
        strncpy(stTemp.sMt,      m_szMT.c_str(),                 sizeof(stTemp.sMt)      - 1);
        strncpy(stTemp.sBkCode,  m_hvps711.InstdDrctPty.c_str(), sizeof(stTemp.sBkCode)  - 1);
        strncpy(stTemp.sPrcSts,  m_szPrcSts.c_str(),             sizeof(stTemp.sPrcSts)  - 1);
        strncpy(stTemp.sChkDt,   m_hvps711.ChckDt.c_str(),       sizeof(stTemp.sChkDt)   - 1);
        strncpy(stTemp.sTxTpCd,  m_szTxTpCd.c_str(),             sizeof(stTemp.sTxTpCd)  - 1);
        strncpy(stTemp.sCcy,     m_szRcvCcy.c_str(),             sizeof(stTemp.sCcy)     - 1);
        
        m_hvchecksum.VCheckArray.push_back(stTemp);
    }

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps711::InsertToCheckCl()");
}

void CRecvHvps711::getLocalData(LPCSTR sTableNm, LPCSTR sCcy, int &iLCount, double &dLAmount)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps711::getLocalData()");
    
    int iRet = -1;
    
    iRet = m_checkaccount.getHvLocalSumData(sTableNm, 
                                m_szMT.c_str(),
                                m_hvps711.InstdDrctPty.c_str(),
                                m_szPrcSts.c_str(),
                                m_hvps711.ChckDt.c_str(),
                                m_szTxTpCd.c_str(),
                                sCcy);
    if ( iRet != SQL_SUCCESS )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "汇总本地数据失败[%d][%s]", 
            iRet, m_checkaccount.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "汇总本地数据失败");
    }

    iLCount  = m_checkaccount.m_iCount;
    dLAmount = m_checkaccount.m_amount;
        
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps711::getLocalData()");
}

void CRecvHvps711::CheckSign711()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps711::CheckSign711()");
	
	m_hvps711.getOriSignStr();
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_hvps711.m_sSignBuff.c_str()  =[%s] ,\
																						 m_hvps711.m_szDigitSign.c_str()=[%s] ,\
	                                           m_hvps711.InstgDrctPty.c_str() =[%s]",\
	                                           m_hvps711.m_sSignBuff.c_str()      ,\
	                                           m_hvps711.m_szDigitSign.c_str()    ,\
	                                           m_hvps711.InstgDrctPty.c_str())    ;	
	CheckSign(
	          m_hvps711.m_sSignBuff.c_str()  ,
						m_hvps711.m_szDigitSign.c_str(),
          	m_hvps711.InstgDrctPty.c_str()
           );
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps711::CheckSign711()");
}

void CRecvHvps711::SetAllCtx()
{
    int iRet = -1;
    
    iRet = m_hvcheckcl.setctx(m_dbproc);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }
    
    iRet = m_checkaccount.setctx(m_dbproc);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }
}

void CRecvHvps711::InitMbCheck(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps711::InitMbCheck()");

	int iRet = -1;

	//日期需要转换成yyyymmdd格式
	char szChkDt[16] = {0};
	chgToDate(m_hvps711.ChckDt.c_str(), szChkDt);

	//新增行内对账记录
	CSysmbchkst mcs;
	SETCTX(mcs);
	mcs.m_checkdate = szChkDt; //对账日期
	mcs.m_sapbank   = m_hvps711.InstdDrctPty; //对账清算行
	mcs.m_sysflag   = "0"; //大额额标志
	mcs.m_checkstate= "00"; //对账状态, 初始态
	mcs.m_handflag  = "0"; //是否手工发起, 否
	const char* szSr[2] = {"0", "1"}; //往来标识
	for(int j = 0; j < 2; ++j){
		mcs.m_srflag = szSr[j];
		iRet = mcs.insert();
		if(iRet != SQL_SUCCESS && iRet != DUPLICATE_KEY){
			Trace(L_ERROR, __FILE__, __LINE__, NULL,
					"[sys_mbchkst]插入失败:%s", mcs.GetSqlErr());
			PMTS_ThrowException(DB_INSERT_FAIL);
		}
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps711::InitMbCheck()");
}



//huwei 2013-07-11 初始化需要参与行内对账记录行内对账状态
//strSqlBank: 对账清算行
//strChkDt: 对账日期 格式yyyy-mm-dd
int CRecvHvps711::InitBizMbCheckState(const string& strSapBank, const string& strChkDt)
{
    Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvHvps711::InitBizMbCheckState");
	
	int iRet = -1;
		
	char szSql[1024]  = {0};
	char szChkDt[32] = {0};
	chgToDate(strChkDt.c_str(), szChkDt);
	
	CEntityBase entity;
	SETCTX(entity);
		
		
	//贷记往报, 注： 疑似重账不参与对账
	const char* szSendTbl[] = {"hv_sndexchglist", "hv_sndexchglisthis"
		    };
	for(int si = 0; si < 2; ++si){
	    memset(szSql, 0x00, sizeof(szSql));
	    snprintf(szSql, sizeof(szSql), 
    	     " update %s set mbcheckstate='00', statetime=sysdate "
    	     " where instgdrctpty='%s' and (finalstatedate='%s' or   "
    	     " CONSIGNDATE='%s')  and MSGDIRECT = '0' and procstate<>'53' ",
    	     szSendTbl[si], strSapBank.c_str(), strChkDt.c_str(), szChkDt);
    	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__szSql=[%s]", szSql);
	    iRet = entity.execsql(szSql);
	    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__iRet=[%d]", iRet);
	    if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND){
	        Trace(L_ERROR, __FILE__, __LINE__, NULL, 
	            "[%s]更新失败:[%s]", szSendTbl[si], entity.GetSqlErr());
	        PMTS_ThrowException(DB_UPDATE_FAIL);
	    }
	}
	const char* szRecvTbl[] = {  "hv_rcvexchglist", "hv_rcvexchglisthis",
	    "hv_trofacrcvlist", "hv_trofacrcvlisthis"
	    };
	for(int si = 0; si < 4; ++si){
	    memset(szSql, 0x00, sizeof(szSql));
	    snprintf(szSql, sizeof(szSql), 
    	     " update %s set mbcheckstate='00', statetime=sysdate "
    	     " where instddrctpty='%s' and (finalstatedate='%s' or   "
    	     " CONSIGNDATE='%s')   ",
    	     szRecvTbl[si], strSapBank.c_str(), strChkDt.c_str(), szChkDt);
    	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__szSql=[%s]", szSql);
	    iRet = entity.execsql(szSql);
	    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__iRet=[%d]", iRet);
	    if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND){
	        Trace(L_ERROR, __FILE__, __LINE__, NULL, 
	            "[%s]更新失败:[%s]", szRecvTbl[si], entity.GetSqlErr());
	        PMTS_ThrowException(DB_UPDATE_FAIL);
	    }
	}
	
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvHvps711::InitBizMbCheckState");
	
	return RTN_SUCCESS;		
}
