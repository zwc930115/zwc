package com.ylink.cnaps2.hvps.service.impl;

import com.ylink.cnaps2.HvPopulateBeanUtils;
import com.ylink.cnaps2.common.Page;
import com.ylink.cnaps2.hvps.entity.HvRcvexchglist;
import com.ylink.cnaps2.hvps.entity.HvSndRcvexchg_TrofacPO;
import com.ylink.cnaps2.hvps.formbeans.HvSndExchglistForm;
import com.ylink.cnaps2.hvps.service.HvRcvexchglistService;
import com.ylink.cnaps2.hvps.service.HvTrofacrcvlistService;
import java.util.List;
import javax.annotation.Resource;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

public class HvRcvexchglistServiceImpl
  implements HvRcvexchglistService
{
  private Logger log = Logger.getLogger(HvSndexchglistServiceImpl.class);

  @Resource
  private SessionFactory sessionFactory;

  @Resource
  private HvTrofacrcvlistService hvTrofacrcvlistService;

  public Page getHvRcvexchglistInfoBy(HvSndExchglistForm form, int pageNo, int pageSize) { String strWhereSql = getWhereSql(form);
    String sbSelect = "Select MSGID, AMOUNT, cast(PROCSTATE as varchar2(2)) AS PROCSTATE, INSTGINDRCTPTY, INSTDINDRCTPTY,INSTGDRCTPTY, MSGTP, cast(workdate as varchar2(8)) AS workdate, cast(ctgypurpprtry as varchar2(5)) AS ctgypurpprtry, cast(purpprtry as varchar2(5)) AS purpprtry, cdtracctid, dbtracctid , '' as CDCODE ,cdtrnm, dbtnm ";
    String sbCount = "Select count(*) ";
    String sb_hvRcvexchglist = "from Hv_Rcvexchglist where 1 = 1";
    String sb_hvRcvexchglisthis = "from Hv_Rcvexchglisthis where 1 = 1 ";
    StringBuffer sb = new StringBuffer();

    String strSql = " ";
    if ("".equals(form.getMsgtp())) {
      String strSql1 = " union Select MSGID, AMOUNT, cast(PROCSTATE as varchar2(2)) AS PROCSTATE, INSTGINDRCTPTY, INSTDINDRCTPTY,INSTGDRCTPTY, MSGTP, cast(workdate as varchar2(8)) AS workdate, cast(ctgypurpprtry as varchar2(5)) AS ctgypurpprtry, cast(purpprtry as varchar2(5)) AS purpprtry, cdtracctid, dbtracctid , CDCODE ,cdtrnm, dbtnm  from hv_trofacrcvlist where 1 = 1  AND trim(lower(msgtp)) in ('hvps.141.001.01','hvps.141.002.01','cmt232') ";

      String strSql2 = " union Select MSGID, AMOUNT, cast(PROCSTATE as varchar2(2)) AS PROCSTATE, INSTGINDRCTPTY, INSTDINDRCTPTY,INSTGDRCTPTY, MSGTP, cast(workdate as varchar2(8)) AS workdate, cast(ctgypurpprtry as varchar2(5)) AS ctgypurpprtry, cast(purpprtry as varchar2(5)) AS purpprtry, cdtracctid, dbtracctid , CDCODE,cdtrnm, dbtnm   from hv_trofacrcvlisthis where 1 = 1  AND trim(lower(msgtp))='hvps.141.001.01' ";

      strSql = strSql1 + strWhereSql;
    }

    String sql = sbSelect + sb_hvRcvexchglist + strWhereSql + strSql + " order by AMOUNT desc";

    List listTemp = null;
    if (pageSize > 0)
      listTemp = this.sessionFactory.getCurrentSession().createSQLQuery(sql).setFirstResult((pageNo - 1) * pageSize)
        .setMaxResults(pageSize).list();
    else {
      listTemp = this.sessionFactory.getCurrentSession().createSQLQuery(sql).list();
    }

    List list = HvPopulateBeanUtils.getHvSndRcvexchg_TrofacPOList(listTemp);

    String sqlCount = "select count(*) from (" + sb.toString() + ")";
    int intTotalCounts = ((Number)this.sessionFactory.getCurrentSession().createSQLQuery(sqlCount).uniqueResult())
      .intValue();

    return new Page((pageNo - 1) * pageSize, intTotalCounts, pageSize, list); }

  public String getSumAmount(HvSndExchglistForm form) {
    StringBuffer sb = new StringBuffer();
    sb.append("select sum (amount) from (select sum(amount) as amount  from Hv_Rcvexchglist where 1 = 1 AND trim(lower(msgtp))<>'hvps.142.001.01' ")
      .append(getWhereSql(form)).append(" union select sum(amount) as amount from hv_trofacrcvlist where 1 = 1  AND trim(lower(msgtp)) in ('hvps.141.001.01','hvps.141.002.01','cmt232')  ").append(getWhereSql(form)).append(" )");

    return this.sessionFactory.getCurrentSession().createSQLQuery(sb.toString()).list().get(0).toString();
  }

  public String getWhereSql(HvSndExchglistForm form) {
    String msgid = form.getMsgid();
    String msgtp = form.getMsgtp();
    String workdate = form.getWorkdate();
    String workdate_start = form.getStartworkdate();
    String workdate_end = form.getEndworkdate();
    String instgindrctpty = form.getLzodficode();
    String instdindrctpty = form.getLzrdficode();
    String dbtracctid = form.getDbtracctid();
    String cdtracctid = form.getCdtracctid();
    String procstate = form.getProcstate();
    String amount_down = form.getAmount_down();
    String amount_up = form.getAmount_up();
    String sqlBanks = form.getSqlBanks();

    String ctgypurpprtry = form.getCtgypurpprtry();
    StringBuffer whereSql = new StringBuffer();

    if (!StringUtils.isBlank(msgid)) {
      whereSql.append(" AND msgid like '%" + msgid.trim() + "%'");
    }

    if (!StringUtils.isBlank(msgtp)) {
      whereSql.append(" AND trim(lower(msgtp))='" + msgtp.trim().toLowerCase() + "'");
    }
    else if ("".equals(msgtp)) {
      whereSql.append(" AND trim(lower(msgtp))<>'hvps.142.001.01' ");
    }

    if (!StringUtils.isBlank(workdate)) {
      whereSql.append(" AND trim(workdate) ='" + workdate.trim() + "'");
    }
    if (!StringUtils.isBlank(workdate_start)) {
      whereSql.append(" AND trim(workdate) >='" + workdate_start.trim() + "'");
    }
    if (!StringUtils.isBlank(workdate_end)) {
      whereSql.append(" AND trim(workdate) <='" + workdate_end.trim() + "'");
    }

    if (!StringUtils.isBlank(instgindrctpty)) {
      whereSql.append(" AND instgindrctpty like '%" + instgindrctpty.trim() + "%'");
    }

    if (!StringUtils.isBlank(instdindrctpty)) {
      whereSql.append(" AND instdindrctpty like '%" + instdindrctpty.trim() + "%'");
    }

    if (StringUtils.isNotBlank(amount_down)) {
      whereSql.append(" and amount  >= " + amount_down);
    }
    if (StringUtils.isNotBlank(amount_up)) {
      whereSql.append(" and amount <= " + amount_up);
    }

    if (!StringUtils.isBlank(dbtracctid)) {
      whereSql.append(" AND dbtracctid like '%" + dbtracctid.trim() + "%'");
    }

    if (!StringUtils.isBlank(cdtracctid)) {
      whereSql.append(" AND cdtracctid like '%" + cdtracctid.trim() + "%'");
    }

    if (!StringUtils.isBlank(procstate)) {
      whereSql.append(" AND trim(procstate)='" + procstate.trim() + "'");
    }

    if (StringUtils.isNotBlank(ctgypurpprtry)) {
      whereSql.append(" and ctgypurpprtry = '" + ctgypurpprtry + "'");
    }

    return whereSql.toString();
  }

  @Transactional(readOnly=true, propagation=Propagation.REQUIRED)
  public Page getHvRcvexchglistInfoBy(String strMsgId, String strMsgtp, String strWorkdate, String strInstgindrctpty, String strInstdindrctpty, String strDbtracctid, String strCdtracctid, String strProcstate, double douAmount_down, double douAmount_up, int pageNo, int pageSize, String sqlBanks)
  {
    String strlog = ".gethvRcvexchglistInfoBy-->";
    this.log.debug(strlog + "start:");

    String strUnionOrderSql = getUnionOrderSqlBy(strMsgId, strMsgtp, strWorkdate, strInstgindrctpty, 
      strInstdindrctpty, strDbtracctid, strCdtracctid, strProcstate, douAmount_down, douAmount_up, sqlBanks);
    this.log.debug(strlog + "1.strUnionOrderSql=" + strUnionOrderSql);

    List listTemp = null;
    if (pageSize > 0)
      listTemp = this.sessionFactory.getCurrentSession().createSQLQuery(strUnionOrderSql).setFirstResult(
        (pageNo - 1) * pageSize).setMaxResults(pageSize).list();
    else {
      listTemp = this.sessionFactory.getCurrentSession().createSQLQuery(strUnionOrderSql).list();
    }

    List list = HvPopulateBeanUtils.getHvSndRcvexchg_TrofacPOList(listTemp);

    String strSqlCount = getCountSqlBy(strMsgId, strMsgtp, strWorkdate, strInstgindrctpty, strInstdindrctpty, 
      strDbtracctid, strCdtracctid, strProcstate, douAmount_down, douAmount_up, sqlBanks);
    this.log.debug(strlog + "1.strSqlCount=" + strSqlCount);

    int intTotalCounts = ((Number)this.sessionFactory.getCurrentSession().createSQLQuery(strSqlCount).uniqueResult())
      .intValue();
    this.log.debug(strlog + "1.intTotalCounts=" + intTotalCounts);

    this.log.debug(strlog + "end:");
    return new Page((pageNo - 1) * pageSize, intTotalCounts, pageSize, list);
  }

  @Transactional(readOnly=true, propagation=Propagation.REQUIRED)
  public HvRcvexchglist getSingleHvRcvexchglistInfoByPK(String strMsgid, String strMsgtp, String strInstgindrctpty)
  {
    String strlog = ".getSingleHvRcvexchglistInfoByPK--<";
    this.log.debug(strlog + "start>");

    strMsgid = strMsgid == null ? "" : strMsgid.trim();
    strMsgtp = strMsgtp == null ? "" : strMsgtp.trim();
    strInstgindrctpty = strInstgindrctpty == null ? "" : strInstgindrctpty.trim();

    HvRcvexchglist hvRcvexchglist = getHvRcvexchglistCurrByPK(strMsgid, strMsgtp, strInstgindrctpty);

    if (hvRcvexchglist == null) {
      hvRcvexchglist = getHvRcvexchglistHisByPK(strMsgid, strMsgtp, strInstgindrctpty);
    }

    return hvRcvexchglist;
  }

  private HvRcvexchglist getHvRcvexchglistCurrByPK(String strMsgid, String strMsgtp, String strInstgindrctpty) {
    String strlog = ".getHvRcvexchglistCurrByPK-->";
    this.log.debug(strlog + "start:");

    String strSqlQueryClause = "FROM HvRcvexchglist A WHERE TRIM(A.id.msgid) =:msgid AND TRIM(LOWER(A.id.msgtp)) =:msgtp AND TRIM(A.id.instgindrctpty) =:instgindrctpty";

    HvRcvexchglist hvRcvexchglist = (HvRcvexchglist)this.sessionFactory.getCurrentSession().createQuery(
      strSqlQueryClause).setString("msgid", strMsgid).setString("msgtp", strMsgtp).setString(
      "instgindrctpty", strInstgindrctpty).uniqueResult();

    return hvRcvexchglist;
  }

  private HvRcvexchglist getHvRcvexchglistHisByPK(String strMsgid, String strMsgtp, String strInstgindrctpty)
  {
    String strlog = ".getHvRcvexchglistHisByPK-->";
    this.log.debug(strlog + "start:");

    String strSqlHis = "SELECT A.* FROM HV_RCVEXCHGLISTHIS A WHERE TRIM(A.msgid) =:msgid AND TRIM(LOWER(A.msgtp)) =:msgtp AND TRIM(A.instgindrctpty) =:instgindrctpty";

    HvRcvexchglist hvRcvexchglist = (HvRcvexchglist)this.sessionFactory.getCurrentSession().createSQLQuery(strSqlHis)
      .addEntity(HvRcvexchglist.class).setString("msgid", strMsgid).setString("msgtp", strMsgtp).setString(
      "instgindrctpty", strInstgindrctpty).uniqueResult();

    return hvRcvexchglist;
  }

  private String getUnionOrderSqlBy(String strMsgId, String strMsgtp, String strWorkdate, String strInstgindrctpty, String strInstdindrctpty, String strDbtracctid, String strCdtracctid, String strProcstate, double douAmount_down, double douAmount_up, String sqlBanks)
  {
    StringBuffer sb = new StringBuffer("SELECT * FROM ( ");
    String strUnionSqlBy = getUnionSqlBy(strMsgId, strMsgtp, strWorkdate, strInstgindrctpty, 
      strInstdindrctpty, strDbtracctid, strCdtracctid, strProcstate, douAmount_down, douAmount_up, sqlBanks);

    sb.append(strUnionSqlBy + " )");
    sb.append(" ORDER By msgid DESC");
    return sb.toString();
  }

  private String getCountSqlBy(String strMsgId, String strMsgtp, String strWorkdate, String strInstgindrctpty, String strInstdindrctpty, String strDbtracctid, String strCdtracctid, String strProcstate, double douAmount_down, double douAmount_up, String sqlBanks)
  {
    StringBuffer sb = new StringBuffer("SELECT COUNT(*) FROM ( ");
    String strCountSql = getUnionSqlBy(strMsgId, strMsgtp, strWorkdate, strInstgindrctpty, strInstdindrctpty, 
      strDbtracctid, strCdtracctid, strProcstate, douAmount_down, douAmount_up, sqlBanks);

    sb.append(strCountSql + " )");
    return sb.toString();
  }

  private String getUnionSqlBy(String strMsgId, String strMsgtp, String strWorkdate, String strInstgindrctpty, String strInstdindrctpty, String strDbtracctid, String strCdtracctid, String strProcstate, double douAmount_down, double douAmount_up, String sqlBanks)
  {
    String strFields1 = "MSGID, AMOUNT, cast(PROCSTATE as varchar2(2)) AS PROCSTATE, INSTGINDRCTPTY, INSTDINDRCTPTY,INSTGDRCTPTY, MSGTP, cast(workdate as varchar2(8)) AS workdate, cast(ctgypurpprtry as varchar2(5)) AS ctgypurpprtry, cast(purpprtry as varchar2(5)) AS purpprtry, cdtracctid, dbtracctid , '' as CDCODE";
    StringBuffer sb = new StringBuffer();

    sb = new StringBuffer("SELECT ");
    sb.append(strFields1);
    sb.append(" FROM HV_RCVEXCHGLIST A WHERE 1=1");
    String strAndSql = this.hvTrofacrcvlistService.getAndSqlBy(strMsgId, strMsgtp, strWorkdate, strInstgindrctpty, 
      strInstdindrctpty, strDbtracctid, strCdtracctid, strProcstate, douAmount_down, douAmount_up, "A", 
      sqlBanks);
    sb.append(strAndSql);

    sb.append(" UNION ");

    sb.append("SELECT ");
    sb.append(strFields1);
    sb.append(" FROM HV_RCVEXCHGLISTHIS B WHERE 1=1");
    strAndSql = this.hvTrofacrcvlistService.getAndSqlBy(strMsgId, strMsgtp, strWorkdate, strInstgindrctpty, 
      strInstdindrctpty, strDbtracctid, strCdtracctid, strProcstate, douAmount_down, douAmount_up, "B", 
      sqlBanks);
    sb.append(strAndSql);

    if ("".equals(strMsgtp)) {
      sb.append(" UNION ");

      String strSqlTemp = this.hvTrofacrcvlistService.getUnionSqlBy(strMsgId, strMsgtp, strWorkdate, 
        strInstgindrctpty, strInstdindrctpty, strDbtracctid, strCdtracctid, strProcstate, douAmount_down, 
        douAmount_up, sqlBanks);
      sb.append(strSqlTemp);
    }

    return sb.toString();
  }

  @Transactional(propagation=Propagation.REQUIRED, readOnly=true)
  public HvRcvexchglist getHvRcvexchglistByIM(String instgindrctpty, String msgid) {
    if (StringUtils.isBlank(msgid)) {
      return null;
    }

    StringBuffer sb = new StringBuffer();
    sb.append(" FROM HvRcvexchglist  WHERE 1=1");
    if (!StringUtils.isBlank(instgindrctpty)) {
      sb.append(" AND id.instgindrctpty like '%" + instgindrctpty.trim() + "%'");
    }

    sb.append(" AND id.msgid like '%" + msgid.trim() + "%'");

    return (HvRcvexchglist)this.sessionFactory.getCurrentSession().createQuery(sb.toString()).uniqueResult();
  }

  @Transactional(readOnly=true, propagation=Propagation.REQUIRED)
  public List<HvSndRcvexchg_TrofacPO> getOutputList(String strMsgId, String strMsgtp, String strWorkdate, String strInstgindrctpty, String strInstdindrctpty, String strDbtracctid, String strCdtracctid, String strProcstate, double douAmount_down, double douAmount_up, String sqlBanks)
  {
    String strUnionOrderSql = getUnionOrderSqlBy(strMsgId, strMsgtp, strWorkdate, strInstgindrctpty, 
      strInstdindrctpty, strDbtracctid, strCdtracctid, strProcstate, douAmount_down, douAmount_up, sqlBanks);

    List listTemp = this.sessionFactory.getCurrentSession().createSQLQuery(strUnionOrderSql).list();
    List list = HvPopulateBeanUtils.getHvSndRcvexchg_TrofacPOList(listTemp);
    return list;
  }

  @Transactional(readOnly=true, propagation=Propagation.REQUIRED)
  public void saveOrUpdate(HvRcvexchglist hvRcvexchglist) {
    this.sessionFactory.getCurrentSession().clear();
    this.sessionFactory.getCurrentSession().saveOrUpdate(hvRcvexchglist);
  }

  public Page getNotTransmitLvbPage(HvSndExchglistForm hvSndExchglistForm, int pageNo, int pageSize)
  {
    String strWhereSql = getWhereSql(hvSndExchglistForm);
    String sbSelect = "Select MSGID, AMOUNT, cast(PROCSTATE as varchar2(2)) AS PROCSTATE, INSTGINDRCTPTY, INSTDINDRCTPTY,INSTGDRCTPTY, MSGTP, cast(workdate as varchar2(8)) AS workdate, cast(ctgypurpprtry as varchar2(5)) AS ctgypurpprtry, cast(purpprtry as varchar2(5)) AS purpprtry, cdtracctid, dbtracctid , '' as CDCODE ";
    String sbCount = "Select count(*) ";
    String sb_hvRcvexchglist = "from Hv_Rcvexchglist where 1 = 1";
    String sb_hvRcvexchglisthis = "from Hv_Rcvexchglisthis where 1 = 1 ";
    StringBuffer sb = new StringBuffer();

    String sql = sbSelect + sb_hvRcvexchglist + strWhereSql + " and msgdirect = '0' " + " union " + 
      sbSelect + sb_hvRcvexchglisthis + strWhereSql + " and msgdirect = '0' " + " order by msgid desc";

    List listTemp = null;
    if (pageSize > 0)
      listTemp = this.sessionFactory.getCurrentSession().createSQLQuery(sql).setFirstResult((pageNo - 1) * pageSize)
        .setMaxResults(pageSize).list();
    else {
      listTemp = this.sessionFactory.getCurrentSession().createSQLQuery(sql).list();
    }

    List list = HvPopulateBeanUtils.getHvSndRcvexchg_TrofacPOList(listTemp);

    String sqlCount = "select count(*) from (" + sb.toString() + ")";
    int intTotalCounts = ((Number)this.sessionFactory.getCurrentSession().createSQLQuery(sqlCount).uniqueResult())
      .intValue();

    return new Page((pageNo - 1) * pageSize, intTotalCounts, pageSize, list);
  }
}
