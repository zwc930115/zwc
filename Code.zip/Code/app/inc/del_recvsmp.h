/********************************************************************
�ļ�����del_recvsmp.h
�����ˣ�xqg
��  �ڣ�2008-08-23
�޸��ˣ�
��  �ڣ�2007-08-23
��  �����Ϻ�ͬ��֧��ƽ̨���ʴ�����

��  ����
Copyright (c) 2008  YLINK
********************************************************************/
#ifndef _RECVSMP_HPP
#define _RECVSMP_HPP
#define       SQLCA_STORAGE_CLASS   extern
#include "smppub.h"
#include "SMP001.hpp"
#include  "dbutil.hpp"
#include  "crdrecvlist.hpp"
#include "pubfunc.h"
#include "SMP009.hpp"
#include "Exception.hpp"
#include "exception.hpp"
#include "SMP002.hpp"
#include "SMP012.hpp"
#include "SMP003.hpp"
#include "SMP007.hpp"
#include "SMP006.hpp"
#include "SMP999.hpp"
#include "SMP203.hpp"
#include "SMP204.hpp"
#include "SMP207.hpp"
#include "SMP201.hpp"
#include "SMP202.hpp"
#include "SMP203.hpp"
#include "SMP204.hpp"
#include "SMP101.hpp"
#include "SMP102.hpp"
#include "commexception.hpp"
#include "SMP752.hpp"
#include "SMP751.hpp"
#include "SMP613.hpp"
#include "SMP614.hpp"
#include "SMP503.hpp"
#include "SMP504.hpp"
#include "SMP501.hpp"
#include "SMP502.hpp"
#include "SMP301.hpp"
#include "SMP302.hpp"
#include "SMP209.hpp"
#include "SMP207.hpp"
#include "SMP208.hpp"
#include "SMP206.hpp"
#include "SMP205.hpp"
#include "SMP305.hpp"
#include "SMP418.hpp"
#include "SMP642.hpp"
#include "SMP713.hpp"
#include "SMP714.hpp"
#include "SMP702.hpp"
#include "SMP703.hpp"
#include "SMP704.hpp"
#include "SMP706.hpp"
#include "SMP011.hpp"
#include "SMP031.hpp"
#include "SMP099.hpp"
#include "SMP013.hpp"
#include "SMP017.hpp"
#include "SMP315.hpp"
#include "SMP543.hpp"
#include "SMP542.hpp"
// add by zhongwenchong
// 2015-12-14
// ��Ϣ���ı���ͷ
// begin
#include "SMP820.hpp"
#include "SMP821.hpp"
#include "SMP822.hpp"
#include "SMP824.hpp"
//end
// add by yuxiaobo 
// 2015-11-26
// ��ó���ʽ��ҵ����ͷ
// begin
#include "SMP011.hpp"
#include "SMP012.hpp"
#include "SMP013.hpp"
#include "SMP016.hpp"
#include "SMP017.hpp"
#include "SMP033.hpp"
#include "SMP037.hpp"
#include "SMP099.hpp"

#include "SMP215.hpp"
#include "SMP413.hpp"

#include "SMP513.hpp"
#include "SMP514.hpp"
#include "SMP542.hpp"

#include "SMP708.hpp"
#include "SMP899.hpp"
// end


#include "checkstate.hpp"
#include "userinfotel.hpp"
#include "comsend.hpp"
#include "crdrecvlist.hpp"
#include "crdsendlist.hpp"
#include "ftcrdrecvlist.hpp"
#include "ftcrdsendlist.hpp"
#include "ftcrosscrdrecvlist.hpp"
#include "ftcrosscrdsendlist.hpp"
#include "ftcrashoutrecvlist.hpp"
#include "ftcrashoutsendlist.hpp"
#include "ftcrashinrecvlist.hpp"
#include "ftcrashinsendlist.hpp"
#include "errcode.hpp"
#include "BaseSMP.hpp"
#include "sendtomb.hpp"
#include "dbrecvlist.hpp"
#include "dbsendlist.hpp"
#include "ftdbrecvlist.hpp"
#include "ftdbsendlist.hpp"
#include "ccandet.hpp"
#include "sysparm.hpp"
#include "querybook.hpp"
#include "SMP505.hpp"
#include "returnlist.hpp"
#include "freeinfo.hpp"
#include "transquery.hpp"
#include "spepaymentinfo.hpp"
#include "bkacctqry.hpp"
#include "comsend.hpp"
#include "billimageinfo.hpp"
#include "bankinfo.hpp"
#include "acctchange.hpp"
#include "ftacctchange.hpp"
#include "acctbalance.hpp"
#include "feelist.hpp"
#include "liquidation.hpp"
#include "msgheader.hpp"
#include "smp_systofmp.hpp"
#include "collect.hpp"
#include "smp3_queryreturn.hpp"
#include "smp3_liquidation.hpp"
#include "smp3_corpfeeitem.hpp" 
#include "smp3_protocol.hpp" 
#include "smp3_protocoltrans.hpp" 
#include "smp3_trademap.hpp"
#include "smp3_feeitem.hpp"
#include "moneyflowinfo.hpp"
#include "ftcheckstate.hpp"
#include "ftcollectchkinfo.hpp"
#include "ftlistchkinfo.hpp"
#include "collectservlist.hpp"
#include "ftzdbcanrecvlist.hpp"

#ifndef NEW_BANK_CODE_LENGTH 
#define NEW_BANK_CODE_LENGTH  14
#endif


/* ��־�ļ��� */
//extern char g_sTraceFileName[20];

/*******************************************************************************
*����:CDelRecvSmp                                                               *
*����:��                                                                       *
*˵��:֧��ƽ̨���ʻ���                                                         *
*����:xqg                                                                      *
*�޸�˵����                                                                    *
*                                                                              *
*******************************************************************************/
class CDelRecvSmp
{
public:
    void DoWork(const char *strMsg);
		
    CDelRecvSmp();       
    ~CDelRecvSmp(){}; 
    
protected:
  
    char      m_sMsgNo[4];
    char      m_sFmpFlag[2];
    char      m_sMon[17];
                  
    /* ��¼�쳣��Ϣ */
    char      m_sTemp[3000];

	/* ������ */
	char m_ErrCode[8 + 1];	

	//����
	CBaseSMP *pMsgIn;
	
	void SaveMsgID(const char *strMsg, const CString &strSndeq);
    CString GetMsgValue(const CString &strMsg, const CString &strName);
    void InsertToFmp(char *SMPTYPE,char *SETTLEBANKNO,char *SUBDATE,const char *MSGTEXT);
    virtual void  DoSelfWork(const char *strMsg) = 0; 

    /* д���ĵ�������ͨѶ�� */
	virtual int InsertMBCom(const char *strMsg){return 0;};
	virtual int TranToMBMsg(char *strMsg){return 0;};
	void GetToFmpFlag();
	char* GetsMon(const char *strMsg);
};

/*******************************************************************************
*����:CDelRecvSmp001                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�SMP001���Ĵ�����                                              *
*����:XQG                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp001:public CDelRecvSmp
{
public:
    CDelRecvSmp001();
    
protected:    
    virtual bool UnPackSmp001(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg);
    virtual int TranToMBMsg(char *strMsg);   
	void SendSmp009(char *strCode, char *strRemark);
    CrdRecvList oCrdRecvList;
    CSMP001 *pCSsmp001;
};

/*******************************************************************************
*����:CDelRecvSmp011                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�SMP011���Ĵ�����                                              *
*����:wangjing                                                                      *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp011:public CDelRecvSmp
{
public:
    CDelRecvSmp011();
    
protected:    
    virtual bool UnPackSmp011(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg);
    virtual int TranToMBMsg(char *strMsg);   
	void Sendsmp099(char *strCode, char *strRemark);//wangjing add
    FtCrdRecvList oCrdRecvList;
    CSMP011 *pCSsmp011;
};

/*******************************************************************************
*����:CDelRecvSmp031                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�SMP031���Ĵ�����                                              *
*����:wangjing                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp031:public CDelRecvSmp
{
public:
    CDelRecvSmp031();
    
protected:    
    virtual bool UnPackSmp031(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg);
    virtual int TranToMBMsg(char *strMsg);   
	void Sendsmp099(char *strCode, char *strRemark);
	
    FtCrossCrdRecvList oCrsCrdRecv;
    CSMP031 *pCSsmp031;
};

/*******************************************************************************
*����:CDelRecvSmp033                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�SMP033���Ĵ�����                                              *
*����:wangjing                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp033:public CDelRecvSmp{
public:
    CDelRecvSmp033();
    
protected:    
    virtual bool UnPackSmp033(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg, bool bSuccess);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
	void Sendsmp099(CString strRstCode, CString strRemark = "");
	void UpdateCrdListState(CString strRstCode, CString strRemark);
	
	bool FindInCrdSendList();
	
	FtCrossCrdRecvList oCrsCrdRecv;
	FtCrossCrdSendList oCrsCrdSend;
    CSMP033 *pCSMP033;
};


/*******************************************************************************
*����:CDelRecvSmp037                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�SMP037���Ĵ�����                                              *
*����:KangHongWen                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp037:public CDelRecvSmp{
public:
    CDelRecvSmp037();
protected:    
    virtual bool UnPackSmp037(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg);
    virtual int TranToMBMsg(char *strMsg);   
	void Sendsmp099(char *strCode, char *strRemark);
	
    FtCrossCrdRecvList oCrsCrdRecv;
    CSMP037 *pCSsmp037;
};

/*******************************************************************************
*����:CDelRecvSmp003                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�SMP003���Ĵ�����                                              *
*����:XQG                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp003:public CDelRecvSmp
{
public:
    CDelRecvSmp003();
    
protected:    
    virtual bool UnPackSmp003(const char *strMBMsg);
	  virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg, bool bSuccess);
	//modify by jienjun 2015-09-25 ���gps�޸Ķ���hub���ʵ��˻㷢������
    //virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);	
    virtual int TranToMBMsg(char *sMBmsg);	
	//modify by jienjun 2015-09-25 ���gps�޸Ķ���hub���ʵ��˻㷢������
	void Sendsmp009(CString strRstCode, CString strRemark = "");
	void UpdateCrdListState(CString strRstCode, CString strRemark);
	
	bool FindInCrdSendList();
    CSMP003 *pCSMP003;
    CrdRecvList oCrdRecvList;
	CrdSendList oCrdSendList;
};

/*******************************************************************************
*����:CDelRecvSmp013                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�SMP013���Ĵ�����                                              *
*����:wangjing                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp013:public CDelRecvSmp
{
public:
    CDelRecvSmp013();
    
protected:    
    virtual bool UnPackSmp013(const char *strMBMsg);
	  virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg, bool bSuccess);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
	void Sendsmp099(CString strRstCode, CString strRemark = "");
	void UpdateCrdListState(CString strRstCode, CString strRemark);
	
	bool FindInCrdSendList();
    CSMP013 *pCSMP013;
    FtCrdRecvList oCrdRecvList;
	FtCrdSendList oCrdSendList;
};


/*******************************************************************************
*����:CDelRecvSmp017                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�SMP017���Ĵ�����                                              *
*����:wangjing                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp017:public CDelRecvSmp
{
public:
    CDelRecvSmp017();
    
protected:    
    virtual bool UnPackSmp017(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg);
    virtual int TranToMBMsg(char *strMsg);   
	void Sendsmp099(char *strCode, char *strRemark);//wangjing add
    FtCrdRecvList oCrdRecvList;
    CSMP017 *pCSsmp017;
};


/*******************************************************************************
*����:CDelRecvSmp002                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp002���Ĵ�����                                              *
*����:XQG                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp002:public CDelRecvSmp
{
public:
    CDelRecvSmp002();
    
protected:    
    virtual bool UnPackSmp002(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg);
    virtual int TranToMBMsg(CString &sMBmsg);
	void SendSmp009(char *strCode, char *strRemark);
	int CheckPaymentCode();
    
    CSMP002 *pCSMP002;
    DbRecvList oDbRecvList;
};

/*******************************************************************************
*����:CDelRecvSmp012                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp012���Ĵ�����                                              *
*����:XQG                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp012:public CDelRecvSmp
{
public:
    CDelRecvSmp012();
    
protected:    
    virtual bool UnPackSmp012(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg);
    virtual int TranToMBMsg(CString &sMBmsg);
	void SendSmp099(char *strCode, char *strRemark); //wangjing add 12.02
	int CheckPaymentCode();
    
    CSMP012 *pCSMP012;
    FtDbRecvList oDbRecvList;
};

/*******************************************************************************
*����:CDelRecvSmp006                                                         *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp006���Ĵ�����                                              *
*����:                                                                     *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/

class CDelRecvSmp006:public CDelRecvSmp
{
public:
    CDelRecvSmp006();

protected:    
    virtual bool UnPackSmp006(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
    
    CSMP006 *pCSMP006;
    CCandet oCCandet;
};

/*******************************************************************************
*����:CDelRecvSmp001                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�SMP001���Ĵ�����                                              *
*����:XQG                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp007:public CDelRecvSmp
{
public:
    CDelRecvSmp007();
    
protected:    
    virtual bool UnPackSmp007(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg);
    virtual int TranToMBMsg(char *strMsg);   
	void SendSmp009(char *strCode, char *strRemark);
    CrdRecvList oCrdRecvList;
    CSMP007 *pCSsmp007;
};


/*******************************************************************************
*����:CDelRecvSmp502                                                         *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp502���Ĵ�����                                              *
*����:                                                                     *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp502:public CDelRecvSmp
{
public:
    CDelRecvSmp502();
    
protected:    
    virtual bool UnPackSmp502(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int UpdateLoginState(void);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
    
    CSMP502 *pCSMP502;
    SysParm oSysParm;
};

/*******************************************************************************
*����:CDelRecvSmp504                                                         *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp504���Ĵ�����                                              *
*����:                                                                     *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp504:public CDelRecvSmp
{
public:
    CDelRecvSmp504();
    
protected:    
    virtual bool UnPackSmp504(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int UpdateLoginState(void);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
    
    CSMP504 *pCSMP504;
    SysParm oSysParm;
};

/*******************************************************************************
*����:CDelRecvSmp505                                                        *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp505���Ĵ�����                                              *
*����:                                                                     *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp505:public CDelRecvSmp
{
public:
    CDelRecvSmp505();
    
protected:    
    virtual bool UnPackSmp505(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int UpdateLoginState(void);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
    
    CSMP505* pCSMP505;
    SysParm oSysParm;
};

/*******************************************************************************
*����:CDelRecvSmp201                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp201���Ĵ�����                                              *
*����:XQG                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp201:public CDelRecvSmp
{
public:
    CDelRecvSmp201();
    
protected:    
    virtual bool UnPackSmp201(const char *strMBMsg);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
    
    CSMP201 *pCSMP201;
    QueryBook oQueryBook;
};


/*******************************************************************************
*����:CDelRecvSmp209                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp209���Ĵ�����                                              *
*����:                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp209:public CDelRecvSmp
{
public:
    CDelRecvSmp209();
    
protected:    
    virtual bool UnPackSmp209(const char *strMBMsg);
	  virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
    
    CSMP209 *pCSMP209;
    FreeInfo oFreeInfo;
};

/*******************************************************************************
*����:CDelRecvSmp207                                                           *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp207���Ĵ�����                                              *
*����:                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp208:public CDelRecvSmp
{
public:
    CDelRecvSmp208();
    
protected:    
    virtual bool UnPackSmp208(const char *strMBMsg);
	  virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
	const char* GetProcState();
	int UpdateState();
	
    
    CSMP208 *pCSMP208;
    TransQuery oTransQuery;
};

/*******************************************************************************
*����:CDelRecvSmp203                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp203���Ĵ�����                                              *
*����:XQG                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp203:public CDelRecvSmp
{
public:
    CDelRecvSmp203();
    
protected:    
    virtual bool UnPackSmp203(const char *strMBMsg);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
    
    CSMP203 *pCSMP203;
    SpepaymentInfo oSpepaymentInfo;
};

/*******************************************************************************
*����:CDelRecvSmp102                                                          *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp102���Ĵ�����                                              *
*����:                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp102:public CDelRecvSmp
{
public:
    CDelRecvSmp102();
    
protected:    
    virtual bool UnPackSmp102(const char *strMBMsg);
	  virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
    
	void SendSmp001();
	
	bool IsCounter();
	void ModifyCrdSendList();
	int CompareAcocunt();
	
    CSMP102 *pCSMP102;
    BkAcctQry oBkAcctQry;
	
    CrdSendList oCrdSendList;
};

/*******************************************************************************
*����:CDelRecvSmp713                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�SMP713���Ĵ�����                                              *
*����:XQG                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp713:public CDelRecvSmp
{
public:
    CDelRecvSmp713();   
    
protected:    
    virtual bool UnPackSmp713(const char *strMBMsg);
	virtual bool checkValues();		
    virtual void DoSelfWork(const char *strMsg);
    
    int sendSmp613(int sum,  char * sSmp613DLC);
	int cmpDetail();
	int updateTable(char *sTableName, int iCmpState);
	int sendSmp714();
	
    //д����ͳ����Ϣ��
    int InsertCollectChkInfo(int iCheckResult);

    //д��ϸͳ����Ϣ��
    int InsertListChkInfo(int iCheckResult);	
	void SendSmp001Ack(const CrdSendList &oCrdSendList);
	
	//�������Ǵ��޸ġ������ˣ���ǵĴ����ˣ��˻�Ĵ�����
	//״̬����Ϊ��ɾ�����������Ļ�����Ҫ�����ڻػ�ִhwf	
	void Undeal();
	
	
	CSMP713 *pCSMP713;

	struct SDetail713Map //ʵʱ���շ�����ϸ�ṹ
	{
		char  szSerialNO[2 + 1];   //���
		char  szSMPCode[3 + 1]; //ָ�����
		char  szCurrencyType[3 + 1]; //����
		char  szLoanCount[8 + 1]; //���Ǳ���
		char  szLoanAmount[15 + 1];    //���ǽ��
		char  szBorrowCount[8 + 1]; //��Ǳ���
		char  szBorrowAmount[15 + 1];    //��ǽ��
	};

    enum
    {
        CHK_STATE_001_SEND         = 1,  //���˴���	
        CHK_STATE_001_RECV         = 2,  //���˻���
		CHK_STATE_002_SEND		   = 4,  //���˽��
		CHK_STATE_002_RECV		   = 8,  //���˽��
		CHK_STATE_003_SEND		   = 16, //�����˻�
		CHK_STATE_003_RECV		   = 32, //�����˻�
	    CHK_STATE_007_SEND		   = 64, //����ת��
		CHK_STATE_007_RECV		   = 128,  //����ת��
	    
    };	
	
};

/*******************************************************************************
*����:CDelRecvSmp751                                                         *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp751���Ĵ�����                                              *
*����:                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp751:public CDelRecvSmp
{
public:
    CDelRecvSmp751();
    
protected:    
    virtual bool UnPackSmp751(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
    
    int BuildReply752(void);
    
    CSMP751 *pCSMP751;
};

/*******************************************************************************
*����:CDelRecvSmp999                                                         *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp999���Ĵ�����                                              *
*����:                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp999:public CDelRecvSmp
{
public:
    CDelRecvSmp999();
    ~CDelRecvSmp999(){};
    
protected:    
    virtual bool UnPackSmp999(const char *strMBMsg);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
    virtual int UpdateOldTrade();
    virtual void GetProcstate(char * sProcstate);
    
    CSMP999 *pCSMP999;
};

/*******************************************************************************
*����:CDelRecvSmp642                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp642���Ĵ�����                                              *
*����:XQG                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/

class CDelRecvSmp642:public CDelRecvSmp
{
public:
    CDelRecvSmp642();
    
protected:    
    virtual bool UnPackSmp642(const char *strMBMsg);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(char *strMsg);
    virtual int UpdateDB();
    
    CSMP642 *pCSMP642;
};

/*******************************************************************************
*����:CDelRecvSmp305                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp305���Ĵ�����                                              *
*����:XQG                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/

class CDelRecvSmp305:public CDelRecvSmp
{
public:
    CDelRecvSmp305();
    ~CDelRecvSmp305(){};
protected:    
    virtual bool UnPackSmp305(const char *strMBMsg);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
    virtual void DealDetail(CString strDetail);
    virtual int UpdateOldTrade(char * sDetail);
	int UpdateAcctInfo(const AcctChange &oAcctChange);
	
    
    CSMP305 *pCSMP305;
};

/*******************************************************************************
*����:CDelRecvSmp315                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp315���Ĵ�����                                              *
*����:wangjing                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/

class CDelRecvSmp315:public CDelRecvSmp
{
public:
    CDelRecvSmp315();
    ~CDelRecvSmp315(){};
protected:    
    virtual bool UnPackSmp315(const char *strMBMsg);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
    virtual void DealDetail(CString strDetail);
    virtual int UpdateOldTrade(char * sDetail);
	int UpdateAcctInfo(const FtAcctChange &oAcctChange);//wangjing change 11.21
	
    
    CSMP315 *pCSMP315;
};


/*******************************************************************************
*����:CDelRecvSmp302                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp302���Ĵ�����                                              *
*����:XQG                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/

class CDelRecvSmp302:public CDelRecvSmp
{
public:
    CDelRecvSmp302();
    ~CDelRecvSmp302(){};
protected:    
    virtual bool UnPackSmp302(const char *strMBMsg);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
    virtual int UpdateOldTrade();
    
    CSMP302 *pCSMP302;
};

/*******************************************************************************
*����:CDelRecvSmp301                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp301���Ĵ�����                                              *
*����:XQG                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/

class CDelRecvSmp301:public CDelRecvSmp
{
public:
    CDelRecvSmp301();
    
protected:    
    virtual bool UnPackSmp301(const char *strMBMsg);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
    
    CSMP301 *pCSMP301;
    AcctBalance oAcctBalance;
};
/*******************************************************************************
*����:CDelRecvSmp206                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp206���Ĵ�����                                              *
*����:XQG                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/

class CDelRecvSmp206:public CDelRecvSmp
{
public:
    CDelRecvSmp206();
    
protected:    
    virtual bool UnPackSmp206(const char *strMBMsg);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
    
    CSMP206 *pCSMP206;
    //BillImageInfo oBillImageInfo;
};

/*******************************************************************************
*����:CDelRecvSmp204                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp204���Ĵ�����                                              *
*����:XQG                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/

class CDelRecvSmp204:public CDelRecvSmp
{
public:
    CDelRecvSmp204();
    ~CDelRecvSmp204(){};
protected:    
    virtual bool UnPackSmp204(const char *strMBMsg);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
    virtual int UpdateOldTrade();
    
    CSMP204 *pCSMP204;
};
/*******************************************************************************
*����:CDelRecvSmp202                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp202���Ĵ�����                                              *
*����:XQG                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/

class CDelRecvSmp202:public CDelRecvSmp
{
public:
    CDelRecvSmp202();
    ~CDelRecvSmp202(){};
protected:    
    virtual bool UnPackSmp202(const char *strMBMsg);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
    virtual int UpdateOldTrade();
    
    CSMP202 *pCSMP202;
};

/*******************************************************************************
*����:CDelRecvSmp009                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp009���Ĵ�����                                              *
*����:XQG                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/

class CDelRecvSmp009:public CDelRecvSmp
{
public:
    CDelRecvSmp009();
    ~CDelRecvSmp009(){};
protected:    
    virtual bool UnPackSmp009(const char *strMBMsg);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(CString &sMBmsg);
    virtual int UpdateOldTrade();
    virtual void GetProcstate(char * sProcstate);
	bool IsNeedToMb();
	
    
    CSMP009 *pCSMP009;
};

/*******************************************************************************
*����:CDelRecvSmp099                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp099���Ĵ�����                                              *
*����:wangjing                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/

class CDelRecvSmp099:public CDelRecvSmp
{
public:
    CDelRecvSmp099();
    ~CDelRecvSmp099(){};
protected:    
    virtual bool UnPackSmp099(const char *strMBMsg);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(CString &sMBmsg);
    virtual int UpdateOldTrade();
    virtual void GetProcstate(char * sProcstate);
	bool IsNeedToMb();
	
    
    CSMP099 *pCSMP099;
};

/*******************************************************************************
*����:CDelRecvSmp899                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp899���Ĵ�����                                              *
*����:wangjing                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/

class CDelRecvSmp899:public CDelRecvSmp
{
public:
    CDelRecvSmp899();
    ~CDelRecvSmp899(){};
protected:    
    virtual bool UnPackSmp899(const char *strMBMsg);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(CString &sMBmsg);
    virtual int UpdateOldTrade();
    virtual void GetProcstate(char * sProcstate);
	bool IsNeedToMb();
	
    CSMP899 *pCSMP899;
};
/*******************************************************************************
*����:CDelRecvSmp614                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�SMP614���Ĵ�����                                              *
*����:XQG                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp614:public CDelRecvSmp
{
public:
    CDelRecvSmp614();   
    
protected:    
    virtual bool UnPackSmp614(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
    void TrimRight(char *buf);
	int detailCmp();
	int updateTable();
	CSMP614 *pCSMP614;
	
	//��ϸ����
    struct SDetail614Map //ʵʱ���շ�����ϸ�ṹ
    {
        char szSerNo[8];       		//���
        char szSMPCode[3];     		//ָ�����
        char szSubDate[8];      	//ί������
        char szSendCode[NEW_BANK_CODE_LENGTH];     	//����������
        char szSendAgency[NEW_BANK_CODE_LENGTH];		//�������к�
        char szPayerAcc[32];		//�����ʺ�
        char szPayerName[60];
        char szSendSeqNo[32];       //������ˮ
        char szRecvCode[NEW_BANK_CODE_LENGTH];    	//����������
        char szRecvAgency[NEW_BANK_CODE_LENGTH];  	//�������к�
        char szOpenName[60];  	//�������к�
        char szRecvAcc[32];  		//�տ��ʺ�
        char szRecvName[60];
        char szRecvSeqNo[32];  		//���շ���ˮ
        char szAmount[15];    		//���
        char szOperType[2];			//ҵ������
        char szWarrantType[2];		//Ʊ������
        char szWarrantDate[8];		//Ʊ�����ڣ�ԭί�����ڣ�
        char szWarrantNo[32];		//Ʊ�ݺ��루ԭί����ˮ��
        char szContent[128];		//��ע
        char szPurpose[1];			//��;
    };
	SDetail614Map stDetail614;

	struct stDetail614Map //ʵʱ���շ�����ϸ�ṹ
    {
        char szSerNo[8 + 1];       		//���
        char szSMPCode[3 + 1];     		//ָ�����
        char szSubDate[8 + 1];      	//ί������
        char szSendCode[NEW_BANK_CODE_LENGTH + 1];     	//����������
        char szSendAgency[NEW_BANK_CODE_LENGTH + 1];		//�������к�
        char szPayerAcc[32 + 1];		//�����ʺ�
        char szPayerName[60 + 1];
        char szSendSeqNo[32 + 1];       //������ˮ
        char szRecvCode[NEW_BANK_CODE_LENGTH + 1];    	//����������
        char szRecvAgency[NEW_BANK_CODE_LENGTH + 1];  	//�������к�
        char szRecvAcc[32 + 1];  		//�տ��ʺ�
        char szRecvName[60 + 1];
        char szRecvSeqNo[32 + 1];  		//���շ���ˮ
        char szAmount[15 + 1];    		//���
        char szOperType[2 + 1];			//ҵ������
        char szWarrantType[2 + 1];		//Ʊ������
        char szWarrantDate[8 + 1];		//Ʊ�����ڣ�ԭί�����ڣ�
        char szWarrantNo[32 + 1];		//Ʊ�ݺ��루ԭί����ˮ��
        char szContent[128 + 1];		//��ע
        char szPurpose[1 + 1];		    //��;
    };
	
    enum
    {
        CHK_STATE_001_SEND         = 1,  //���˴���	
        CHK_STATE_001_RECV         = 2,  //���˻���
		CHK_STATE_002_SEND		   = 4,  //���˽��
		CHK_STATE_002_RECV		   = 8,  //���˽��
		CHK_STATE_003_SEND		   = 16, //�����˻�
		CHK_STATE_003_RECV		   = 32, //�����˻�
    };	

	int InsertCrdSendList(const stDetail614Map &stDetail614map);
	int InsertDbSendList(const stDetail614Map &stDetail614map);
	int InsertCrdRecvList(const stDetail614Map &stDetail614map);
	int InsertDbRecvList(const stDetail614Map &stDetail614map);
	int DealUnCheckState(int iSMPCode);
	
};

/*******************************************************************************
*����:CDelRecvSmp702                                                       *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp702���Ĵ�����                                              *
*����:                                                                     *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp702:public CDelRecvSmp
{
public:
    CDelRecvSmp702();
    
protected:    
    virtual bool UnPackSmp702(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(char *strMsg);   

	int updateTable();

	//add by zwc 20171207 for transfer account files
	// ���������ļ�
	void trafAcct();
	// �����˻��ļ�
	int createAcctF(CString &sDirPath, CString &sFileName);
	// �����˻���ɫ�ļ�
	int createAcctRoleF(CString &sDirPath, CString &sFileName);
	// ������ɫ�����ļ�
	int createRoleF(CString &sDirPath, CString &sFileName);
	// ���ݽ�ɫid��ȡ��ɫ��
	void GetRoleName(CString &strRoleID,CString &strRoleName);
	// ���ݹ���id��ȡ��ť
	void GetFuncButton(CString &strFuncID,CString &strButton);
	//add end
    
    CSMP702 *pCSMP702;
    SysParm oSysParm;
};
/*******************************************************************************
*����:CDelRecvSmp704                                                       *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp704���Ĵ�����                                              *
*����:                                                                     *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp704:public CDelRecvSmp
{
public:
    CDelRecvSmp704();
    
protected:    
    virtual bool UnPackSmp704(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
    
    CSMP704 *pCSMP704;
};

/*******************************************************************************
*����:CDelRecvSmp418                                                       *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp702���Ĵ�����                                              *
*����:                                                                     *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp418:public CDelRecvSmp
{
public:
    CDelRecvSmp418();
    
protected:    
    virtual bool UnPackSmp418(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);

	int updateTable();
    
    CSMP418 *pCSMP418;
    SysParm oSysParm;
};

/*******************************************************************************
*����:CDelRecvSmp703                                                       *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp703���Ĵ�����                                              *
*����:                                                                     *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp703:public CDelRecvSmp
{
public:
    CDelRecvSmp703();
    
protected:    
    virtual bool UnPackSmp703(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);

	int insertTable();
    
  CSMP703 *pCSMP703;
  
  struct S703DetailMap {
        char SeqNo[4+1];          // NOT NULL 4n  ���
        char AgencyNo[NEW_BANK_CODE_LENGTH+1];      // NOT NULL 12n �����
        char SendiNum[8+1];        // NOT NULL 8n  �����ܱ������ɹ���
        char SendiAmount[16+1];    // NOT NULL 16n �����ܽ��ɹ���
        char RecviNum[8+1];           // NOT NULL 8n �����ܱ���
        char RecviAmount[16+1];        //NOT NULL 16n �����ܽ��
        char CreditNum[8+1];      // NOT NULL 8n ����ҵ���ܱ���
        char CreditAmount[16+1];  // NOT NULL 16n ����ҵ���ܽ��
        char DebitNum[8+1];       // NOT NULL 8n ���ҵ���ܱ���
        char DebitAmount[16+1];   // NOT NULL 16n ���ҵ����
        char StandFee[12+1];       // NOT NULL 12n  ��׼Ӧ��������
        char ReturnFee[12+1];      // NOT NULL 12n ����������
        char FactFee[12+1];         // NOT NULL 12n ʵ��Ӧ��������
    };
};

class CDelRecvSmp706:public CDelRecvSmp
{
public:
    CDelRecvSmp706();
    
protected:    
    virtual bool UnPackSmp706(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);

	int insertTable();
    
  	CSMP706 *pCSMP706;

	struct SDetail706Map //ʵʱ���շ�����ϸ�ṹ
	{		
		char szBalDate[8+1];                     
		char szBalSeq[2+1];                      
		char szCreditCount[8+1];                 
		char szCreditAmount[16+1];               
		char szDebitCount[8+1];                  
		char szDebitAmount[16+1];
	}; 
  
};

class CDelRecvSmp543:public CDelRecvSmp
{
public:
    CDelRecvSmp543();
    
protected:    
    virtual bool UnPackSmp543(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);

	int insertTable();
    
  	CSMP543 *pCSMP543;

	struct SDetail543Map //���ռ�Ϣ��ϸ�ṹ
	{		
		char szSettlementDay[8+1];
		char szBalDate[8+1];                     
		char szBalSeq[2+1];   
		char szBusinessType[3+1];                   
		char szCreditCount[8+1];                 
		char szCreditAmount[16+1];               
		char szDebitCount[8+1];                  
		char szDebitAmount[16+1];
    char szInterestRate[8+1];         
    char szInterest[15+1];
	}; 
  
};

/*******************************************************************************
*����:CDelRecvSmp820                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�SMP820(��ҵ������֪ͨ����)���˱��Ĵ�����                    *
*����:hawrk                                                                     *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp820:public CDelRecvSmp
{
public:
	
    CDelRecvSmp820();
    ~CDelRecvSmp820();

    char sSeqno[32 + 1];     /*�����з�����ˮ*/

protected:
    virtual bool UnPackSmp820(const char *strMBMsg);
    virtual void DoSelfWork(int iFlowListID, const char *strMsg);

    void UpdateTransDB();
    int InsertintoDB();
    void DealDetail(CString strDetail);

    CSMP820 *pCSMP820;
    CorpFeeItem oCorpFeeItem;
};
/*******************************************************************************
*����:CDelRecvSmp821                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�SMP821(��ҵ������֪ͨ����)���˱��Ĵ�����                    *
*����:hawrk                                                                     *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp821:public CDelRecvSmp
{
public:
    CDelRecvSmp821();
    ~CDelRecvSmp821();

    char sSeqno[32 + 1];     /*�����з�����ˮ*/

protected:
    virtual bool UnPackSmp821(const char *strMBMsg);
    virtual void DoSelfWork(int iFlowListID, const char *strMsg);

    void UpdateTransDB();
    int InsertintoDB();
    void DealDetail(CString strDetail);

    CSMP821 *pCSMP821;
    CorpFeeItem oCorpFeeItem;
};

/*******************************************************************************
*����:CDelRecvSmp822                                                          *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�SMP822(�ͻ�Э�������뱨��)                                  *
*����:hawrk                                                                     *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp822:public CDelRecvSmp
{
public:
    CDelRecvSmp822();
    ~CDelRecvSmp822();

protected:
    virtual bool UnPackSmp822(const char *strMBMsg);
    virtual void DoSelfWork(int iFlowListID, const char *strMsg);

    void UpdateTransDB();
    int InsertintoDB();
    void InsertProtocol();
    void UpdateProtocol();

    CSMP822 *pCSMP822;
    ProtocolTrans oProtocolTrans;
    Protocol oProtocol;
};
/*******************************************************************************
*����:CDelRecvSmp824                                                           *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�SMP824(������Ϣ����)���˱��Ĵ�����                                              *
*����:zhangqinglin                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp824:public CDelRecvSmp
{
public:
    CDelRecvSmp824();
    ~CDelRecvSmp824();

    char sSeqno[32 + 1];     /*�����з�����ˮ*/

protected:
    virtual bool UnPackSmp824(const char *strMBMsg);
    virtual void DoSelfWork(int iFlowListID, const char *strMsg);

    void UpdateTransDB();
    int InsertintoDB();

    CSMP824  *pCSMP824;
    FeeItem  oFeeItem;
    TradeMap oTradeMap;
    //FlowList oFlowList;

};

//////////////////////////////////////////////////////////////////////////////////
//add by yuxiaobo
//2015-11-26
//end
/*******************************************************************************
*����:CDelRecvSmp542                                                       *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp542���Ĵ�����                                              *
*����:       wangjing add 12.18                                                              *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp542:public CDelRecvSmp
{
public:
    CDelRecvSmp542();
    
protected:    
    virtual bool UnPackSmp542(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);
	virtual	int InsertintoDB(const char *strMsg);
	virtual void DealDetail(CString strDetail);
	void Sendsmp099(char *strCode, char *strRemark);
    
    CSMP542 *pCSsmp542;
};

/*******************************************************************************
*����:CDelRecvSmp513                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�SMP513���Ĵ�����                                              *
*����:wangjing                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp513:public CDelRecvSmp
{
public:
    CDelRecvSmp513();   
    
protected:    
    virtual bool UnPackSmp513(const char *strMBMsg);
	virtual bool checkValues();		
    virtual void DoSelfWork(const char *strMsg);
    
    int sendSmp413(int sum,  char * sSmp413DLC);
	int cmpDetail();
	int updateTable(char *sTableName, int iCmpState);
	int sendSmp514();
	
    //д����ͳ����Ϣ��
    int InsertCollectChkInfo(int iCheckResult);

    //д��ϸͳ����Ϣ��
    int InsertListChkInfo(int iCheckResult);	
	void SendSmp011Ack(const FtCrdSendList &oCrdSendList);
	
	//�������Ǵ��޸ġ������ˣ���ǵĴ����ˣ��˻�Ĵ�����
	//״̬����Ϊ��ɾ�����������Ļ�����Ҫ�����ڻػ�ִhwf	
	void Undeal();
	
	
	CSMP513 *pCSMP513;

	struct SDetail513Map //ʵʱ���շ�����ϸ�ṹ
	{
		char  szSerialNO[2 + 1];   //���
		char  szSMPCode[3 + 1]; //ָ�����
		char  szCurrencyType[3 + 1]; //����
		char  szLoanCount[8 + 1]; //���Ǳ���
		char  szLoanAmount[15 + 1];    //���ǽ��
		char  szBorrowCount[8 + 1]; //��Ǳ���
		char  szBorrowAmount[15 + 1];    //��ǽ��
	};

    enum
    {
        CHK_STATE_011_SEND         = 1,  //��ó�����˴���	
        CHK_STATE_011_RECV         = 2,  //��ó�����˻���
		CHK_STATE_012_SEND		   = 4,  //��ó�����˽��
		CHK_STATE_012_RECV		   = 8,  //��ó�����˽��
		CHK_STATE_013_SEND		   = 16, //��ó�������˻�
		CHK_STATE_013_RECV		   = 32, //��ó�������˻�
		CHK_STATE_017_SEND         = 64,  	//��ó������ת��
        CHK_STATE_017_RECV         = 128,  	//��ó������ת��
    };	
	
};


/*******************************************************************************
*����:CDelRecvSmp514                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�SMP514���Ĵ�����                                              *
*����:wangjing                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp514:public CDelRecvSmp
{
public:
    CDelRecvSmp514();   
    
protected:    
    virtual bool UnPackSmp514(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    virtual int TranToMBMsg(const char *strMsg,CString &sMBmsg);

	int detailCmp();
	int updateTable();
	CSMP514 *pCSMP514;
	
	//��ϸ����
    struct SDetail514Map //ʵʱ���շ�����ϸ�ṹ
    {
        char szSerNo[8];       		//���
        char szSMPCode[3];     		//ָ�����
        char szSubDate[8];      	//ί������
        char szSendCode[14];     	//����������
        char szSendAgency[35];		//�������к�wangjing change 14->35
        char szPayerAcc[35];		//�����ʺ�wangjing change 32->35
        char szPayerName[140];      //�����˺Ż���wangjing change 60->140
        char szSendSeqNo[32];       //������ˮ
        char szRecvCode[14];    	//����������
        char szRecvAgency[35];  	//�������к�wangjing change 14->35
        char szRecvBnkName[140];  	//�տ��˿�������wangjing change 60->140
        char szRecvAcc[35];  		//�տ��ʺ�wangjing change 32->35
        char szRecvName[140];       //�տ��˺Ż���wangjing change 60->140
        char szRecvSeqNo[32];  		//���շ���ˮ
        char szAmount[15];    		//���
        char szOperType[2];			//ҵ������
        char szWarrantType[2];		//Ʊ������
        char szWarrantDate[8];		//Ʊ�����ڣ�ԭί�����ڣ�
        char szWarrantNo[32];		//Ʊ�ݺ��루ԭί����ˮ��
        char szClientRemark[135];	//�ͻ�����wangjing change
    	char szBankRemark[210];	    //���и���wangjing change
        char szPurpose[1];			//��;
    };
	SDetail514Map stDetail514;

	struct stDetail514Map //ʵʱ���շ�����ϸ�ṹ
    {
        char szSerNo[8 + 1];       		//���
        char szSMPCode[3 + 1];     		//ָ�����
        char szSubDate[8 + 1];      	//ί������
        char szSendCode[14 + 1];     	//����������
        char szSendAgency[35 + 1];		//�������к�wangjing change 14->35
        char szPayerAcc[35 + 1];		//�����ʺ�wangjing change 32->35
        char szPayerName[140 + 1];		//wangjing change 60->140
        char szSendSeqNo[32 + 1];       //������ˮ
        char szRecvCode[14 + 1];    	//����������
        char szRecvAgency[35 + 1];  	//�������к�wangjing change 14->35
        char szRecvAcc[35 + 1];  		//�տ��ʺ�wangjing change 32->35
        char szRecvName[140 + 1];		//wangjing change 60->140
        char szRecvSeqNo[32 + 1];  		//���շ���ˮ
        char szAmount[15 + 1];    		//���
        char szOperType[2 + 1];			//ҵ������
        char szWarrantType[2 + 1];		//Ʊ������
        char szWarrantDate[8 + 1];		//Ʊ�����ڣ�ԭί�����ڣ�
        char szWarrantNo[32 + 1];		//Ʊ�ݺ��루ԭί����ˮ��
        char szClientRemark[135 + 1];	//�ͻ�����wangjing change
    	char szBankRemark[210 + 1];	    //���и���wangjing change
        char szPurpose[1 + 1];		    //��;
    };
	
    enum
    {
		CHK_STATE_011_SEND         = 1,  //��ó�����˴���	
        CHK_STATE_011_RECV         = 2,  //��ó�����˻���
		CHK_STATE_012_SEND		   = 4,  //��ó�����˽��
		CHK_STATE_012_RECV		   = 8,  //��ó�����˽��
		CHK_STATE_013_SEND		   = 16, //��ó�������˻�
		CHK_STATE_013_RECV		   = 32, //��ó�������˻�
		CHK_STATE_017_SEND         = 64,  	//��ó������ת��
        CHK_STATE_017_RECV         = 128,  	//��ó������ת��
    };	

	int InsertCrdSendList(const stDetail514Map &stDetail514map);
	int InsertDbSendList(const stDetail514Map &stDetail514map);
	int InsertCrdRecvList(const stDetail514Map &stDetail514map);
	int InsertDbRecvList(const stDetail514Map &stDetail514map);

	//wangjing add 02.21
	int InsertCrsCrdSendList(const stDetail514Map &stDetail514map);
	int InsertCrsCrdRecvList(const stDetail514Map &stDetail514map);
	//wangjing add end
	int DealUnCheckState(int iSMPCode);
	
};
/*******************************************************************************
*����:CDelRecvSmp016                                                            *
*����:CDelRecvSmp                                                               *
*˵��:֧��ƽ̨�յ�Smp016���Ĵ�����                                              *
*����:XQG                                                                       *
*�޸�˵����                                                                     *
*                                                                               *
*******************************************************************************/
class CDelRecvSmp016:public CDelRecvSmp
{
public:
    CDelRecvSmp016();
    
protected:    
    virtual bool UnPackSmp016(const char *strMBMsg);
	virtual bool checkValues();		
    virtual bool isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq);
    virtual void DoSelfWork(const char *strMsg);
    virtual int InsertMBCom(const char *strMsg);
    int InsertintoDB(const char *strMsg);
    virtual int TranToMBMsg(CString &sMBmsg);
	void SendSmp009(char *strCode, char *strRemark);
	void SendSmp099(char *strCode, char *strRemark); //wangjing add 12.02
	int CheckPaymentCode();
    
    CSMP016 *pCSMP016;
    ftzdbCansendRecv odbCansendRecv;
};

#endif
