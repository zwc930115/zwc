#!/bin/sh
#IP="172.26.188.82"
#USER="abis"
RouteAddress="192.168.1.115"
LocalAddress="192.168.1.113"
USER="root"
PORT="22"
SRCFILE=$1
TGTFILE=/tmp

TMPFILE=tmpfile

#echo "sftp $USER@$IP" > $TMPFILE
#echo "cd /tmp" >>$TMPFILE
echo "put $SRCFILE $TGTFILE" >> $TMPFILE
echo "bye" >> $TMPFILE

sftp -b $TMPFILE -oBindAddress=$LocalAddress -oPort=$PORT $USER@$RouteAddress
if [ $? = 0 ]
then
	echo "sftp Ok"
	rm -f $TMPFILE
	exit 0 
else
	echo "sftp error"
	#rm -f $TMPFILE
	exit -1
fi

