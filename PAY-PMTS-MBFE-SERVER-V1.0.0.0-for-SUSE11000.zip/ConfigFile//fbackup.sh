#!/bin/sh
NUMBER=1024
while [[ ${NUMBER} -ne 0 ]]
do
var=`ps -ef | grep PAMTinstall.bin | awk -F" " '{print $6}'`
if [[ -n "$var" ]]
then
break
else 
NUMBER=`expr ${NUMBER} - 1`
fi
done
var1=/dev/$var
#echo "�˿ں�Ϊ$var1" > $var1
../ConfigFile/backup.sh <$var1 | tee -a ../InstallAnyWhere/install.log   >$var1 2>&1