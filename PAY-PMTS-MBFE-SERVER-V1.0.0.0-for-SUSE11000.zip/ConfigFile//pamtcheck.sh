#!/bin/sh
# create and modified by 高卓 
#定义系统检查时用到的变量
#查看系统名称
Node_Name=`hostname`
#查看安装时的平台
#iconv -f gb18030 -t utf-8 preinstall.sh -o preinstall.sh
#iconv -f gb18030 -t utf-8 PreconditionInfo.txt -o PreconditionInfo.txt
#iconv -f gb18030 -t utf-8 MediumInfo.txt -o PackageDescription.txt
cat PackageDescription.txt | tr -d '\015' > PackageDescription1.txt
cat ConfigInfo.txt | tr -d '\015' > ConfigInfo1.txt
cat PreconditionInfo.txt | tr -d '\015' > PreconditionInfo1.txt
OS_Version=`grep OS ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`

OS_FLAG=`echo $OS_Version |cut -c1`
#取得包的放置路径，存放路径改为由安装者设置
#PACKAGEPATH=`grep PackagePath ./PackageDescription1.txt|awk -F"=" '{print $2}'`
#安装的系统名称
PRODUCTNAME=`grep ProductName ./ConfigInfo1.txt|awk -F"=" '{print $2}'`
PRODUCTFULLNAME=`grep ProductName ./PackageDescription1.txt|awk -F"=" '{print $2}'`

#取得备份路径
#BACKUPPATH=`grep BackupPath ./PackageDescription1.txt|awk -F"=" '{print $2}'`
PPRODUCTPRENAME=`grep $PRODUCTNAME ${PAMTBACKUP}/LocalMediumInfo.txt|awk -F"=" '{print $2}' 2>/dev/null`

INSTALL_USR=`grep OS ./ConfigInfo1.txt|awk -F"=" '{print $2}'`



#取得数据库类型信息
DATABASE=`grep -w DataBase ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`


#取得FIX补丁串
FIXRECORDNAMESTR=`grep FixNo ./ConfigInfo1.txt|awk -F"=" '{print $2}'`

#取得FIX补丁个数
FIXFILENUMBER=`grep FixNum ./ConfigInfo1.txt|awk -F"=" '{print $2}'`

#取得FIX补丁说明串
FIXRECORDINSTRUCTIONSTR=`grep -w "Instruction" ./ConfigInfo1.txt|awk -F"=" '{print $2}'`

#取得文件个数
PACKAGENUMBER=`grep -w "FileNum" ./PackageDescription1.txt|awk -F"=" '{print $2}'`

#取得文件串
PACKAGEFILESTR=`grep FileName ./PackageDescription1.txt|awk -F"=" '{print $2}'`

#取得文件说明串

PACKAGEFILEINSTRUCTSTR=`grep FileInstrct ./PackageDescription1.txt|awk -F"=" '{print $2}'`

#取得数据库版本号
#DATABASEVERSION=`echo "$DATABASE"| awk -F"-" '{print $2}'`
TMIDDLEWARE=`grep -w TransactionMiddleware ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`


MMIDDLEWARE=`grep -w MessageMiddleware ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`


nexts()
{
    echo
    echo "--回车进行下一步操作--"
    read a
    echo
}
choice()
{
  echo
  echo "--输入'Y'或'y'进行确认，或同时按下CTRL+C键退出本次安装--"
  read ch
  if [[ ${ch} == "Y" ]] || [[ ${ch} == "y" ]]
  then
  echo "--继续执行下一步--"  
  echo
  else
  echo "输入字符错误，请重新输入！"
  choice
  fi
}
rm PackageDescription1.txt
rm ConfigInfo1.txt
rm PreconditionInfo1.txt
echo "==============================================================================="
echo "   PAMT安装程序开始运行检查脚本                                                "
echo "   以下内容是对磁盘空间、安装用户、常规检查等说明                              "
echo "==============================================================================="
echo

#获取消息中间件版本信息

#echo "----常规性检查："
		echo "--检查系统时间、磁盘空间，请确认是否满足安装需要"
		date
		df -k
    echo
		
choice

#echo "${INSTALL_USR}"
echo "--节点名称为：${Node_Name}，要求以‘root’用户进行安装，实际用户：`whoami`，安装包存放位置：${PAMTINSTALL}，请确认"
choice

#path=`pwd`
#echo "--安装文件的配置文件所在路径为:${path}"
#nexts




#echo "----下发的产品为：${PRODUCTNAME}"

echo "--正在安装的产品版本为：${PRODUCTFULLNAME}"


if [[ -n "$PPRODUCTPRENAME" ]]
then
    echo "--本产品历史版本为：${PPRODUCTPRENAME}"
else
    echo "--没有此产品的历史版本信息"
fi
echo "--下发产品/补丁文件正确性验证："
echo "请稍候..."

  if [[ ${OS_FLAG} == "a" ]] || [[ ${OS_FLAG} == "A" ]]
  then
#     echo "--环境为aix操作系统"
./PAMT0001 ${PAMTINSTALL}/${PRODUCTFULLNAME}
  else
#     echo "--环境为linux操作系统"
./LPAMT0001 ${PAMTINSTALL}/${PRODUCTFULLNAME}
  fi
choice


#cat ConfigInfo.txt | tr -d '\015' > ConfigInfo1.txt

#    ./PAMT0003 $PRODUCTNAME $PAMTINSTALL/ ConfigInfo1.txt 1

    
#echo "----本地操作系统："
#  if [[ ${OS_FLAG} == "a" ]] || [[ ${OS_FLAG} == "A" ]]
#  then
#     echo "--aix操作系统"
#echo "./PAMT0003 ${PRODUCTNAME} ${PAMTBACKUP}/ LocalMediumInfo.txt 0"
#PAMT0003 ${PRODUCTNAME} ${BACKUPPATH} LocalMediumInfo.txt 0
#  else
#     echo "--linux操作系统"
#LPAMT0003 ${PRODUCTNAME} ${BACKUPPATH} LocalMediumInfo.txt 0
# fi



#将字符串变为数字
if [[ -n "$FIXFILENUMBER" ]]
then
echo "--正在安装的版本的补丁（列表）："
#FIXFILENUMBER=`echo $FIXFILENUMBER|tr -cs "[0-9]" " "`
while [[ ${FIXFILENUMBER} -ne  0 ]]
do
		FIXRECORDNAME=`echo ${FIXRECORDNAMESTR}|awk -F";" '{print $(FIXFILENUMBER)}' FIXFILENUMBER="$FIXFILENUMBER" `
		FIXRECORDINSTRUCTION=`echo ${FIXRECORDINSTRUCTIONSTR}|awk -F" " '{print $(FIXFILENUMBER)}' FIXFILENUMBER="$FIXFILENUMBER" `
echo "补丁号为$FIXRECORDNAME"
echo "补丁说明为${FIXRECORDINSTRUCTION}"
echo "----"
FIXFILENUMBER=`expr ${FIXFILENUMBER} - 1`
done
choice
else
:;
fi


cat PreconditionInfo.txt | tr -d '\015' > PreconditionInfo1.txt
cat MediumInfo.txt | tr -d '\015' > MediumInfo1.txt
DATABASENUM=`grep DataBaseNum ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`
MESSAGEMIDDLEWARENUM=`grep MessageMiddlewareNum ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`
TRANSCATIONMIDDLEWARENUM=`grep TransactionMiddlewareNum ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`
PAMTFILEPROPERTYSTR=`grep Property ./MediumInfo1.txt|awk -F"=" '{print $2}'`
PAMTFILENAMESTR=`grep MaintanceFileName ./MediumInfo1.txt|awk -F"=" '{print $2}'`

PAMTFILEPATHSTR=`grep Path ./MediumInfo1.txt|awk -F"=" '{print $2}'`
PAMTFILENUMBER=`grep MaintanceFileNum ./MediumInfo1.txt|awk -F"=" '{print $2}'`

PAMTFILENUMBER=`echo $PAMTFILENUMBER|tr -cs "[0-9]" " "`
while [[ ${PAMTFILENUMBER} -ne  0 ]]
do
    PAMTFILEPATH=`echo ${PAMTFILEPATHSTR}|awk -F" " '{print $(PAMTFILENUMBER)}' PAMTFILENUMBER="$PAMTFILENUMBER" `
    PAMTPROPERTY=`echo ${PAMTPROPERTYSTR}|awk -F" " '{print $(PAMTFILENUMBER)}' PAMTFILENUMBER="$PAMTFILENUMBER" `
		PAMTFILENAME=`echo ${PAMTFILENAMESTR}|awk -F";" '{print $(PAMTFILENUMBER)}' PAMTFILENUMBER="$PAMTFILENUMBER" `
		PAMTFILEPROPERTY=`echo ${PAMTFILEPROPERTYSTR}|awk -F" " '{print $(PAMTFILENUMBER)}' PAMTFILENUMBER="$PAMTFILENUMBER" `
				
		echo "--需要进行安装的文件为：${PAMTFILENAME}，安装路径为${PAMTFILEPATH}"
		if [[ ${PAMTFILEPROPERTY} == "Replace" ]]
		then
		echo "--此文件将替换目录下同名文件"
		else 
		echo "--此文件为本次更新新增服务文件"
		fi	

    PAMTFILENUMBER=`expr ${PAMTFILENUMBER} - 1`	
    echo "----"
done

choice

PACKAGENUMBER=`echo $PACKAGENUMBER|tr -cs "[0-9]" " "`
echo "----此次更新包中一共有${PACKAGENUMBER}个相关文件:"

echo "--文件列表及文件具体说明如下："
while [[ ${PACKAGENUMBER} -ne  0 ]]
do
		PACKAGEFILE=`echo "${PACKAGEFILESTR}" |awk -F";" '{print $(PACKAGENUMBER)}' PACKAGENUMBER="$PACKAGENUMBER" `
	  PACKAGEFILEINSTRUCT=`echo ${PACKAGEFILEINSTRUCTSTR}|awk -F" " '{print $(PACKAGENUMBER)}' PACKAGENUMBER="$PACKAGENUMBER" `
		
   echo "文件：${PACKAGEFILE}"
   echo "作用：${PACKAGEFILEINSTRUCT}"
   echo "----"
	 PACKAGENUMBER=`expr $PACKAGENUMBER - 1`
done
choice

echo "==============================================================================="
echo "   PAMT安装程序开始进行系统常规检查                                            "
echo "   系统检查包括了操作系统、中间件等常规性的检查                                "
echo "==============================================================================="
echo

echo "--本次安装对操作系统的要求为：${OS_Version}--"
# echo "版本号为${OS_Version}"
  if [[ ${OS_FLAG} == "a" ]] || [[ ${OS_FLAG} == "A" ]]
  then
     echo "--正在运行的AIX操作系统版本信息\c"
     oslevel
  else
     echo "--正在运行的SUSE操作系统版本信息"
     lsb_release -a
  fi
 echo

choice

#echo "----本步骤是对消息中间件的要求检查"


if [ -n "$MESSAGEMIDDLEWARENUM" ]
then 
:;
else
echo "--此次安装没有对消息中间件的约束要求"
fi

while [[ ${MESSAGEMIDDLEWARENUM} -ne  0 ]]
do
MMIDDLEWARENAME=`echo ${MMIDDLEWARE}|awk -F";" '{print $(MESSAGEMIDDLEWARENUM)}' MESSAGEMIDDLEWARENUM="$MESSAGEMIDDLEWARENUM" `

MMIDDLEWARE_FLAG=`echo "$MMIDDLEWARENAME" |cut -c1`
#MMIDDLEWAREVERSION=`echo "$MMIDDLEWARE"| awk -F"-" '{print $2}'`

if [[ ${MMIDDLEWARE_FLAG} == "M" ]] || [[ ${MMIDDLEWARE_FLAG} == "m" ]]
  then
    echo
	  echo "本次安装对MQ版本号的要求为${MMIDDLEWARENAME}"
	  echo "以下是正在运行的版本信息，请比对"
	  dspmqver
	 else
	 :;
fi

if [[ ${MMIDDLEWARE_FLAG} == "T" ]] || [[ ${MMIDDLEWARE_FLAG} == "t" ]]
  then
    echo "请输入TLQ用户名："
    read tlqname
	  echo "本次安装对TLQ版本号的要求为${MMIDDLEWARENAME}"
	  echo "以下是正在运行的版本信息，请比对"
	  su - $tlqname -c "tlqstat -ver <<- EOF
      q
      EOF"
	 else
	 :;
echo
fi
MESSAGEMIDDLEWARENUM=`expr $MESSAGEMIDDLEWARENUM - 1`
done
choice


#echo "----本步骤是对交易中间件的要求检查"
if [ -n "$TRANSCATIONMIDDLEWARENUM" ]
then 
:;
else
echo "--此次安装没有对交易中间件的约束要求"
fi

while [[ ${TRANSCATIONMIDDLEWARENUM} -ne  0 ]]
do
TMIDDLEWARENAME=`echo ${TMIDDLEWARE}|awk -F";" '{print $(TRANSCATIONMIDDLEWARENUM)}' TRANSCATIONMIDDLEWARENUM="$TRANSCATIONMIDDLEWARENUM" `

TMIDDLEWARE_FLAG=`echo "$TMIDDLEWARENAME" |cut -c1`
#获取交易中间件版本
#TMIDDLEWAREVERSION=`echo "$TMIDDLEWARE"| awk -F"-" '{print $2}'`
  if [[ ${TMIDDLEWARE_FLAG} == "c" ]] || [[ ${TMIDDLEWARE_FLAG} == "C" ]]
  then
	   echo "本次安装对CICS版本号的要求为${TMIDDLEWARE}"
	   echo "以下是正在运行的版本信息，请比对"
	   cicscp version
	 else
	 :;
  fi
TRANSCATIONMIDDLEWARENUM=`expr $TRANSCATIONMIDDLEWARENUM - 1`
done

choice
#echo "----本步骤是对数据库的要求检查"
if [ -n "$DATABASENUM" ]
then
#echo "--要求的数据库为:${DATABASE}"
:;
else
 	 echo "--此次安装没有对数据库的约束要求"
fi
while [[ ${DATABASENUM} -ne  0 ]]
do
DATABASENUMNAME=`echo ${DATABASE}|awk -F";" '{print $(DATABASENUM)}' DATABASENUM="$DATABASENUM" `
DATABASE_FLAG=`echo $DATABASENUMNAME |cut -c1`
  if [[ ${DATABASE_FLAG} == "o" ]] || [[ ${DATABASE_FLAG} == "O" ]]
  then
     echo "--本次安装对ORACLE版本号的要求为:${DATABASENUMNAME}"
     echo "以下是正在运行的版本信息，请比对"
     		su - oracle -c "sqlplus /nolog <<- EOF
      exit
      EOF"
   else
   :;
  fi
    if [[ ${DATABASE_FLAG} == "d" ]] || [[ ${DATABASE_FLAG} == "D" ]]
  then
     echo "--本次安装对DB2版本号的要求为:${DATABASENUMNAME}"
     echo "以下是正在运行的版本信息，请比对"
     		db2level
     		quit
   else
   :;
  fi
DATABASENUM=`expr $DATABASENUM - 1`
done
echo
choice

#rm PreconditionInfo1.txt

echo "==============================================================================="
echo "   PAMT安装程序开始运行独特性检查脚本                                          "
echo "   如检查用户等，检查相关系统状态                                              "
echo "==============================================================================="
echo
#cat PreconditionInfo.txt | tr -d '\015' > PreconditionInfo1.txt
#SPECIALSHELLNUM=`grep -w SpecialShellNum ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`
#SPECIALSHELLSTR=`grep -w SpecialShell ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`
#INSTRUCTIONSTR=`grep -w Instruction ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`
#if [ -n "$SPECIALSHELLNUM" ]
#then
#SPECIALSHELLNUM=`echo $SPECIALSHELLNUM|tr -cs "[0-9]" " "`
#echo "此次安装一共有$SPECIALSHELLNUM个独特性检查脚本"
#while [[ ${SPECIALSHELLNUM} -ne  0 ]]
#do
#    SPECIALSHELL=`echo ${SPECIALSHELLSTR}|awk -F";" '{print $(SPECIALSHELLNUM)}' SPECIALSHELLNUM="$SPECIALSHELLNUM" `
#    INSTRUCTION=`echo ${INSTRUCTIONSTR}|awk -F" " '{print $(SPECIALSHELLNUM)}' SPECIALSHELLNUM="$SPECIALSHELLNUM" `
#    echo "独特性检查脚本的名称为"
#    echo $SPECIALSHELL
#    echo "脚本描述为"
#    echo $INSTRUCTION
#    echo "下面开始执行独特性脚本"
#    ./$SPECIALSHELL
#    SPECIALSHELLNUM=`expr ${SPECIALSHELLNUM} - 1`
#done
#else
#echo "**************本次安装没有独特性检查的要求"
#fi

SPECIALCHECKNAMESTR=`grep SpecialCheckName ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`
INSTRUCTIONSTR=`grep -w Instruction ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`
SPECIALCHECKNUMBER=`grep SpecialCheckNum ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`

if [ -n "$SPECIALCHECKNUMBER" ]
then
SPECIALCHECKNUM=`echo ${SPECIALCHECKNUMBER}|tr -cs "[0-9]" " "`
#echo "$SPECIALCHECKNUM"
VAR2=1
#echo "$VAR2"
while [[ ${VAR2} -le ${SPECIALCHECKNUM} ]]
do
  SPECIALCHECKNAME=`echo ${SPECIALCHECKNAMESTR}|awk -F";" '{print $(VAR2)}' VAR2="$VAR2"`
  echo "执行脚本${SPECIALCHECKNAME}"
#  echo "${SPECIALCHECKNAME}"
  ./${SPECIALCHECKNAME}
  VAR2=`expr ${VAR2} + 1`	
#  echo "$VAR2"
done
else
echo "--本次安装没有集成独特性检查脚本--"
echo
fi

echo "==============================================================================="
echo "   PAMT安装程序开始调用安装前运行脚本                                          "
echo "   安装前运行脚本可进行创建用户、创建逻辑卷等操作                              "
echo "==============================================================================="
echo
PREINSTALLNAMESTR=`grep PreInstallName ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`
INSTRUCTIONSTR=`grep -w Instruction ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`
PREINSTALLNUMBER=`grep PreInstallNum ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`

if [ -n "$PREINSTALLNUMBER" ]
then
PREINSTALLNUM=`echo ${PREINSTALLNUMBER}|tr -cs "[0-9]" " "`
#echo "$PREINSTALLNUM"
VAR1=1
#echo "$VAR1"
while [[ ${VAR1} -le ${PREINSTALLNUM} ]]
do
  PREINSTALLNAME=`echo ${PREINSTALLNAMESTR}|awk -F";" '{print $(VAR1)}' VAR1="$VAR1"`
  
  PREINSTALLNAME=`echo "${PREINSTALLNAME}"|tr -d " "`
  echo "执行脚本${PREINSTALLNAME}"
  ./${PREINSTALLNAME}
  VAR1=`expr ${VAR1} + 1`	
#  echo "$VAR1"
done
else
echo "--本次安装没有集成安装前运行脚本--"
echo
fi

rm MediumInfo1.txt
rm PreconditionInfo1.txt
#rm ConfigInfo1.txt