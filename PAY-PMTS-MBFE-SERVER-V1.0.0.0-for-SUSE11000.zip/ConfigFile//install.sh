#!/bin/sh
choice()
{
  echo
  echo "--输入'Y'或'y'进行确认，或同时按下CTRL+C键退出本次安装--"
  read ch
  if [[ ${ch} == "Y" ]] || [[ ${ch} == "y" ]]
  then
  echo "--继续执行下一步--"  
  echo
  else
  echo "输入字符错误，请重新输入！"
  choice
  fi
}

cat ConfigInfo.txt | tr -d '\015' > ConfigInfo1.txt
cat PreconditionInfo.txt | tr -d '\015' > PreconditionInfo1.txt
cat PackageDescription.txt | tr -d '\015' > PackageDescription1.txt
cat MediumInfo.txt | tr -d '\015' > MediumInfo1.txt
#去掉回车

OS_Version=`grep OS ./PreconditionInfo.txt|awk -F"=" '{print $2}'`
OS_FLAG=`echo $OS_Version |cut -c1`
#add on 20120104 for delete the previous full version
OS_FIXFLAG=`echo ${OS_Version}|awk -F"." '{print $4}'`
OS_FIXFLAG=`expr ${OS_FIXFLAG}`

PRODUCTNAME=`grep ProductName ./ConfigInfo1.txt|awk -F"=" '{print $2}'`
#echo ${PRODUCTNAME}.md5

#echo 
if [[ ${OS_FIXFLAG} -eq 0 ]]
then
rm -rf ${PAMTBACKUP}/bin/${PRODUCTNAME}.md5
fi

PRODUCTNAME=`grep ProductName ./PackageDescription1.txt|awk -F"=" '{print $2}'`
#PACKAGEPATH=`grep PackagePath ./PackageDescription1.txt|awk -F"=" '{print $2}'`

echo "==============================================================================="
echo "   PAMT安装程序开始进行系统安装                                                "
echo "   系统安装是对系统中已存在的文件进行权限、属主等赋值操作                      "
echo "==============================================================================="
OS_Version=`grep OS ./PreconditionInfo.txt|awk -F"=" '{print $2}'`
BACKPATH=`grep BackupPath ./PackageDescription1.txt|awk -F"=" '{print $2}'`
PAMTFILENAMESTR=`grep MaintanceFileName ./MediumInfo1.txt|awk -F"=" '{print $2}'`
PAMTAUTHORITYSTR=`grep Authority ./MediumInfo1.txt|awk -F"=" '{print $2}'`
PAMTFILEPATHSTR=`grep Path ./MediumInfo1.txt|awk -F"=" '{print $2}'`
PAMTFILENUMBER=`grep MaintanceFileNum ./MediumInfo1.txt|awk -F"=" '{print $2}'`
PAMTGROUPSTR=`grep Group ./MediumInfo1.txt|awk -F"=" '{print $2}'`
PAMTFILENUMBER=`echo $PAMTFILENUMBER|tr -cs "[0-9]" " "`
while [[ ${PAMTFILENUMBER} -ne  0 ]]
do
    PAMTFILEPATH=`eval echo ${PAMTFILEPATHSTR}|awk -F" " '{print $(PAMTFILENUMBER)}' PAMTFILENUMBER="$PAMTFILENUMBER" `
    PAMTPROPERTY=`echo ${PAMTPROPERTYSTR}|awk -F" " '{print $(PAMTFILENUMBER)}' PAMTFILENUMBER="$PAMTFILENUMBER" `
		PAMTFILENAME=`echo ${PAMTFILENAMESTR}|awk -F";" '{print $(PAMTFILENUMBER)}' PAMTFILENUMBER="$PAMTFILENUMBER" `
		PAMTAUTHORITY=`eval echo ${PAMTAUTHORITYSTR}|awk -F" " '{print $(PAMTFILENUMBER)}' PAMTFILENUMBER="$PAMTFILENUMBER" `
		PAMTGROUP=`echo ${PAMTGROUPSTR}|awk -F" " '{print $(PAMTFILENUMBER)}' PAMTFILENUMBER="$PAMTFILENUMBER" `
		PAMTFILEPROPERTY=`echo ${PAMTFILEPROPERTYSTR}|awk -F" " '{print $(PAMTFILENUMBER)}' PAMTFILENUMBER="$PAMTFILENUMBER" `
		echo "文件：${PAMTFILENAME}，安装路径：${PAMTFILEPATH}，权限：${PAMTAUTHORITY}，属主${PAMTGROUP}"
		echo "chmod $PAMTAUTHORITY $PAMTFILEPATH/$PAMTFILENAME"
		chmod $PAMTAUTHORITY $PAMTFILEPATH/$PAMTFILENAME
		echo "chown $PAMTGROUP $PAMTFILEPATH/$PAMTFILENAME"
		chown $PAMTGROUP $PAMTFILEPATH/$PAMTFILENAME
    PAMTFILENUMBER=`expr ${PAMTFILENUMBER} - 1`	
    echo "----"
done
choice

echo "--进行本地文件更新："
  if [[ ${OS_FLAG} == "a" ]] || [[ ${OS_FLAG} == "A" ]]
  then
     ./PAMT0004  $PAMTBACKUP/ LocalMediumInfo.txt ./ PackageDescription.txt
  else
      ./LPAMT0004  $PAMTBACKUP/ LocalMediumInfo.txt ./ PackageDescription.txt
  fi
echo "--本地文件更新完毕"

choice

echo "更新本地文件的MD5码"
echo "..."
#echo "${PACKAGEPATH}---"
#echo " ${PRODUCTNAME}"
  if [[ ${OS_FLAG} == "a" ]] || [[ ${OS_FLAG} == "A" ]]
  then
     ./PAMT0007  ${PAMTINSTALL}/${PRODUCTNAME}
  else
      ./LPAMT0007  ${PAMTINSTALL}/${PRODUCTNAME}
  fi
echo "更新完毕"
echo "==============================================================================="
echo "   PAMT安装程序开始调用安装后运行脚本                                          "
echo "   安装后运行脚本是对安装后的介质进行启动、比对等操作                          "
echo "==============================================================================="
POSTINSTALLNAMESTR=`grep PostInstallName ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`
INSTRUCTIONSTR=`grep -w Instruction ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`
POSTINSTALLNUMBER=`grep PostInstallNum ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`

if [ -n "$POSTINSTALLNUMBER" ]
then
POSTINSTALLNUM=`echo ${POSTINSTALLNUMBER}|tr -cs "[0-9]" " "`
#echo "$POSTINSTALLNUM"
VAR1=1
#echo "$VAR1"
while [[ ${VAR1} -le ${POSTINSTALLNUM} ]]
do
  POSTINSTALLNAME=`echo ${POSTINSTALLNAMESTR}|awk -F";" '{print $(VAR1)}' VAR1="$VAR1"`
  echo "执行脚本${POSTINSTALLNAME}"
  POSTINSTALLNAME=`echo "${POSTINSTALLNAME}"|tr -d " "`
  ./${POSTINSTALLNAME}
  VAR1=`expr ${VAR1} + 1`	
#  echo "$VAR1"
done
else
echo "--本次安装没有集成安装后运行脚本--"
fi
rm MediumInfo1.txt
rm PackageDescription1.txt

echo

echo "==============================================================================="
echo "   PAMT安装程序开始调用安装验证脚本                                            "
echo "   安装验证是查看安装正确与否的脚本                                            "
echo "==============================================================================="
echo
VERIFYNAMESTR=`grep VerifyName ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`
INSTRUCTIONSTR=`grep -w Instruction ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`
VERIFYNUMBER=`grep VerifyNum ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`

if [ -n "$VERIFYNUMBER" ]
then
VERIFYNUM=`echo ${VERIFYNUMBER}|tr -cs "[0-9]" " "`
#echo "$VERIFYNUM"
VAR1=1
#echo "$VAR1"
while [[ ${VAR1} -le ${VERIFYNUM} ]]
do
  VERIFYNAME=`echo ${VERIFYNAMESTR}|awk -F";" '{print $(VAR1)}' VAR1="$VAR1"`
  
  echo "执行脚本${VERIFYNAME}"
    VERIFYNAME=`echo "${VERIFYNAME}"|tr -d " "`
  ./${VERIFYNAME}
  VAR1=`expr ${VAR1} + 1`	
#  echo "$VAR1"
done
else
    echo "--本次安装没有集成验证脚本--"
fi

rm PreconditionInfo1.txt
echo
echo "--本次应用介质安装已经完成，请根据屏幕后续提示退出安装--"

if [ uid=0 ]
then
chmod -R 777 ${PAMTBACKUP}/bin
chmod 777 ${PAMTBACKUP}/LocalMediumInfo.txt
fi