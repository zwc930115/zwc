/********************************************************************
文件名：charge.cpp
创建人：hdf
日  期：2011-10-12
修改人：
日  期：
描  述：记帐类公共函数定义

版  本：
Copyright (c) 2011  YLINK
********************************************************************/
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "charge.h"


CCharge::CCharge(DBProc& dbproc)
{
	m_dbproc = dbproc;
}

CCharge::CCharge()
{
	m_iDCFlag = 0;
	m_iRetCode = 0;
	m_amount = 0.00;
	memset(m_szOprUserNetId, 0x00, sizeof(m_szOprUserNetId));
	memset(m_szSapNetId, 0x00, sizeof(m_szSapNetId));
	memset(m_szSendBank, 0x00, sizeof(m_szSendBank));
	memset(m_szSysFlag, 0x00, sizeof(m_szSysFlag));
	memset(m_szRetDesc, 0x00, sizeof(m_szRetDesc));
}

CCharge::~CCharge()
{
}

int CCharge::ChargeMB()
{
	return RTN_SUCCESS;
}

int CCharge::FundSettle()
{
	return 0;
	Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CCharge::FundSettle...");	
	Trace(L_INFO, __FILE__, __LINE__, NULL, "操作用户所属机构[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "发起行行号[%s]", m_szSendBank);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "借贷标识[%d]", m_iDCFlag);

	//1)获取发起用户所属银行的清算行
	char szSapBank[14+1];
	memset(szSapBank, 0x00, sizeof(szSapBank));
		
	GetSapBank(m_dbproc, m_szSendBank, szSapBank);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "所属清算行[%s]", szSapBank);	
	SETCTX(m_Syssapbankinfo);
	m_Syssapbankinfo.m_sapbank = szSapBank;
	m_Syssapbankinfo.findByPK();
	itoa(m_szSysFlag, (enum SYS_FLAG)1, 2);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "对应总行机构号[%s], 系统标识[%s]", m_Syssapbankinfo.m_mbbankid.c_str(), m_szSysFlag);
	
	m_Syssapbankinfo.SaFundSettlement(m_iDCFlag, m_szOprUserNetId, m_Syssapbankinfo.m_mbbankid.c_str(), m_amount, m_szSysFlag, m_iRetCode, m_szRetDesc);

	Trace(L_INFO, __FILE__, __LINE__, NULL, "返回值[%d], 返回描述[%s]",  m_iRetCode, m_szRetDesc);	

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CCharge::FundSettle..."); 
    
    return RTN_SUCCESS;
}
