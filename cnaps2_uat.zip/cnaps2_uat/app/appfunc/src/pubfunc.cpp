#include "pubfunc.h"
#include "entitybase.h" 
#include "syssysparm.h"
#include "exception.h" 
#include "logger.h"
#include "cmbankinfo.h"
#include "cmsapcertinfo.h"
#include "cmbankcertinfo.h" 
#include "hvsapbankinfo.h" 
#include "bpsapbankinfo.h" 
#include "cmtxamtlmt.h"
#include "des.h" 
//#include "cfca.h"
#include "cmrecverrmsg.h"
#include "sysrecvmsgtel.h"
#include "syssapbankinfo.h"
#include "cmmsgnocomp.h"
#include "cmbankcertinfo.h"
#include "tsocket.h"
#include <sys/ioctl.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>

extern char			g_SendCBSP[128];
extern int          g_IsConnCBSP;
extern char         g_IP[16];
extern char         g_MqTxtPath[256];
extern char         g_MQmgr[256];
extern int          g_iCfcaSign;        //是否验签名或核押
extern char         g_SignAddr[496];

const char* SP_MB_USERID          = "@*&#^$";//特殊字符串(收到发送往报消息时，用它来判断业务来源)
using namespace ZFPT;

int UpdateRecvErrmsg(DBProc &DBproc1, int iRowid)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering UpdateRecvErrmsg");	

    char szRowid[33] = {0};
    itoa(szRowid, iRowid);
    
    string strSQL;
	strSQL += "UPDATE cm_recverrmsg t SET t.PROCSTATE = '00'";
	strSQL += " WHERE t.ROW_ID = '";
	strSQL += szRowid;
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());

    CCmrecverrmsg cCmrecverrmsg(DBproc1);
    int iRet = cCmrecverrmsg.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新失败原因[%d] [%s]",iRet, cCmrecverrmsg.GetSqlErr());
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving UpdateRecvErrmsg");	
    return iRet;
}

int DelRecvErrmsg(DBProc &DBproc1, int iRowid)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering DelRecvErrmsg");	

    char szRowid[33] = {0};
    itoa(szRowid, iRowid);
    
    string strSQL;
	strSQL += "delete from cm_recverrmsg t ";
	strSQL += " WHERE t.ROW_ID = '";
	strSQL += szRowid;
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());

    CCmrecverrmsg cCmrecverrmsg(DBproc1);
    int iRet = cCmrecverrmsg.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "DelRecvErrmsg failed [%d] [%s]",iRet, cCmrecverrmsg.GetSqlErr());
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving DelRecvErrmsg");	
    return iRet;    

}

//add in 20171207
//DB password decode function
//add in 20171130
void DecodeDBPsw(CString &DBPsw)
{
	//printf("Before DBPsw = %s\n", DBPsw.GetBuffer(0));
	char sCMD[100];          //命令行
	char sResult[100];       //命令返回的结果
	CString strDepProc;      //解密进程
	char strBfDeyPd[100];    //解密前密码
	CString strAfDeyPd;      //解密后密码
	
	memset(sCMD,       NULL_CHAR, sizeof(sCMD)      );
	memset(sResult,    NULL_CHAR, sizeof(sResult)   );
	memset(strBfDeyPd, NULL_CHAR, sizeof(strBfDeyPd));
	
	strncpy(strBfDeyPd, DBPsw.GetBuffer(0),sizeof(strBfDeyPd)-1);
	//printf("strBfDeyPd = %s\n", strBfDeyPd);
	
	strDepProc = "./3des.bin 1";
	sprintf(sCMD, "echo %s | %s | tail -n 1 | cut -d '[' -f2 | cut -d ']' -f1", strBfDeyPd, strDepProc.GetBuffer(0));
	MyCMD(sCMD, sResult);
	//printf("sResult = %s\n", sResult);
	strAfDeyPd.Format("%s", sResult);
	strAfDeyPd.Replace("\n", "");
	//printf("strAfDeyPd = %s\n", strAfDeyPd.GetBuffer(0));
	
	DBPsw.Replace(strBfDeyPd, strAfDeyPd.GetBuffer(0));
	//printf("After DBPsw = %s\n", DBPsw.GetBuffer(0));
}

void MyCMD(const char *cmd, char *result)
{
	char sBuf[1024];
	char sCmd[1024]={0};
	FILE *pFile;
	
	memset(sBuf, 0x00, sizeof(sBuf));
	memset(sCmd, 0x00, sizeof(sCmd));
	
	strcpy(sCmd, cmd);
	if((pFile=popen(sCmd, "r"))!=NULL)
	{
		while(fgets(sBuf, 1024, pFile)!=NULL)
		{
			strcat(result, sBuf);
			if(strlen(result)>1024)
				break;
		}
		pclose(pFile);
		pFile = NULL;
	}
	else
	{
		printf("popen %s error\n", sCmd);
		pclose(pFile);
		pFile = NULL;
	}
}
//add end

//注意主控里使用
int WriteException(DBProc &DBproc1, string strSys, int iErrMsgFlag, LPCSTR pchMsg, int nErrCode, LPCSTR pchErrDesc, LPCSTR BizCode, LPCSTR Msgid)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering WriteException");	

    int iRet = 0;
    if(nErrCode == DB_CNNCT_FAIL)
    {
        //连接数据库失败，暂时不做任务操作
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "error:MB_PFR0020");
        return RTN_SUCCESS;
    }
    
    if(iErrMsgFlag != 0)
    {
        iRet = UpdateRecvErrmsg(DBproc1, iErrMsgFlag);
        if(iRet == RTN_SUCCESS)
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "更新异常表状态成功");
            return RTN_SUCCESS;
        }
        else
        {
            Trace(L_FATAL,  __FILE__,  __LINE__, NULL, "更改状态失败,写错误文件,客户端上看不到这条记录!!");
            WriteErrFile(pchMsg, BizCode, Msgid, strSys);
            return RTN_FAIL;
        }
    }

    // 错误码为空
    if (NULL == pchErrDesc  ||  "" == pchErrDesc)
    {
        nErrCode = OTH_ERR;
        pchErrDesc = "";
    }

    // 获取工作日期
    char sWorkDate[8 + 1];
    char sCode[10]= {0};
    memset(sWorkDate, 0x00, sizeof(sWorkDate));

    SYS_FLAG S_Flag;
    if(0 == STRCASECMP(strSys.c_str(), "HVPS"))
    {
        S_Flag = SYS_HVPS;
    }
    else if(0 == STRCASECMP(strSys.c_str(), "BEPS"))
    {
        S_Flag = SYS_BEPS;
    }
    else if(0 == STRCASECMP(strSys.c_str(), "CCMS"))
    {
        S_Flag = SYS_CCMS;
    }
    else if(0 == STRCASECMP(strSys.c_str(), "SAPS"))
    {
        S_Flag = SYS_SAPS;
    }
    else
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "未知的系统标志");
        return RTN_FAIL;
    }
    
    iRet = GetWorkDate(DBproc1, sWorkDate, S_Flag);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "获取工作日期失败,写错误文件");
        WriteErrFile(pchMsg, BizCode, Msgid, strSys);
        return RTN_FAIL;
    }
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "sWorkDate = %s", sWorkDate);

	// 设置连接
	CCmrecverrmsg cCmrecverrmsg(DBproc1);

	cCmrecverrmsg.m_syscode    = strSys;
    cCmrecverrmsg.m_msgtext    = pchMsg;
    cCmrecverrmsg.m_wrkdate    = sWorkDate;
    cCmrecverrmsg.m_msgtp      = BizCode; 
    cCmrecverrmsg.m_procstate  = "00"; 
    cCmrecverrmsg.m_proctimes  = 1; 
    cCmrecverrmsg.m_errcode    = itoa(sCode,nErrCode); 
    cCmrecverrmsg.m_errdesc    = pchErrDesc;
    	
	// 往来帐异常表插入记录
	iRet = cCmrecverrmsg.insert();
	if (0 == iRet)
	{
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Write Error Table Success");	
        cCmrecverrmsg.commit();
	}    
    else
    {
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
            "m_cCmrecverrmsg.insert error:error code =[%d],error info = [%s]", iRet,cCmrecverrmsg.GetSqlErr());
        cCmrecverrmsg.rollback();

        // 写文件
        iRet = WriteErrFile(pchMsg, BizCode, Msgid, strSys);  
        if(0 != iRet)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Write Error File Faile");
            return RTN_FAIL;
        }
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving WriteException");
    return RTN_SUCCESS;
}

//add by jienjun
INT32 WriteMsgFile(const char * MsgText, LPCSTR MsgID, LPCSTR msgPath)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering WriteMsgFile()");

    time_t timep;
    struct tm *p;
    time(&timep);
    p = gmtime(&timep);

	bool bRet = createDeepDir(msgPath);
    if(!bRet)
    {
        printf("异常文件目录创建失败!\n");
        return RTN_FAIL;
    }

    FILE* msgFile = NULL;
	
    char szFileName[gc_nMaxPathLen] = {0};

    sprintf(szFileName,"%s/%s",msgPath,MsgID);
 

    if (NULL != (msgFile = fopen(szFileName, "w+")))
    {
        fprintf(msgFile, "%s", MsgText);
        fclose(msgFile);
    }
    else
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "写异常文件失败");
        return RTN_FAIL;
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving WriteMsgFile()");

    return RTN_SUCCESS;
}

//add by jienjun
INT32 DelMsgFile(LPCSTR strMsgFile)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering DelMsgFile()");

    char cmd[256] = {0};
    sprintf(cmd,"rm -rf %s",strMsgFile);
    int iRet = system(cmd);
    if (0 != iRet)
    {
    
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "del file [%s] failed iRet=[%d]",strMsgFile,iRet);
        //return RTN_FAIL;
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving DelMsgFile()");

    return RTN_SUCCESS;
}

INT32 MvFile(LPCSTR strFileName,  LPCSTR tarPath ,LPCSTR srcPath)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering MvFile()");

    char cmd[256] = {0};
    sprintf(cmd,"mv %s %s/%s",tarPath, srcPath, strFileName);
    if (0 != system(cmd))
    {
    
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "mv file [%s] failed",strFileName);
        return RTN_FAIL;
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving MvFile()");

    return RTN_SUCCESS;
}

INT32 GetMsgFromFile(LPCSTR strFileName, string &strMsg)
{

    FILE *fp = NULL;

    if(NULL == (fp = fopen(strFileName, "rb+")))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "open:%s failed", strFileName);
    	return -1;
    }

    char szBuf[MQ_MAX_SEGMENT_SIZE + 1] = { 0 };
    int iReadCount;
    int iCount;

    if((iReadCount = fread(szBuf, sizeof(char), MQ_MAX_SEGMENT_SIZE, fp)) <= 0)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "read:%s failed", strFileName);
        fclose(fp);          
        return -1;
    }

	while (0 != iReadCount)
	{
        strMsg += szBuf;
		iReadCount = fread(szBuf, sizeof(char), MQ_MAX_SEGMENT_SIZE, fp);

	} 	

	fclose(fp);    
    return RTN_SUCCESS;

}

INT32 WriteErrFile(const char * pchErrText, LPCSTR BizCode, LPCSTR MsgID, string strSys)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering WriteErrFile()");

    time_t timep;
    struct tm *p;
    time(&timep);
    p = gmtime(&timep);

    char szchPathName[gc_nMaxPathLen] = {0};

    sprintf(szchPathName, "../errmsg/%d/%d/%d/", p->tm_year + 1900, p->tm_mon + 1, p->tm_mday);

	bool bRet = createDeepDir(szchPathName);
    if(!bRet)
    {
        printf("异常文件目录创建失败!\n");
        return RTN_FAIL;
    }

    FILE* msgFile = NULL;

    char szchTime[8 + 1] = {0};
    sprintf(szchTime, "%02d%02d%02d", p->tm_hour, p->tm_min, p->tm_sec);
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "szchTime:%s", szchTime);
	
    string strFileName = szchPathName;
    strFileName += strSys;
    strFileName += "-";
    strFileName += BizCode;
    strFileName += "-";
    strFileName += MsgID;
    strFileName += "-";
    strFileName += szchTime;
    strFileName += ".txt";

    if (NULL != (msgFile = fopen(strFileName.c_str(), "w+")))
    {
        fprintf(msgFile, "%s", pchErrText);
        fclose(msgFile);
    }
    else
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "写异常文件失败");
        return RTN_FAIL;
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving WriteErrFile()");

    return RTN_SUCCESS;
}

char* GetLocalIp()  
{        
    int MAXINTERFACES=16;  
    char *ip = NULL;  
    int fd, intrface, retn = 0;    
    struct ifreq buf[MAXINTERFACES];    
    struct ifconf ifc;    

    if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) >= 0)    
    {    
        ifc.ifc_len = sizeof(buf);    
        ifc.ifc_buf = (caddr_t)buf;    
        if (!ioctl(fd, SIOCGIFCONF, (char *)&ifc))    
        {    
            intrface = ifc.ifc_len / sizeof(struct ifreq);    

            while (intrface-- > 0)    
            {    
                if (!(ioctl (fd, SIOCGIFADDR, (char *) &buf[intrface])))    
                {    
                    ip=(inet_ntoa(((struct sockaddr_in*)(&buf[intrface].ifr_addr))->sin_addr));    
                    break;  
                }                        
            }  
        }    
        close (fd);            
    }  
    
    return ip;
} 


char* OffsetCpy(char* cSrc, const char* szOriMsgfrMb, int &offset, int iLen, bool bCur)
{
    char *address = cSrc;
    if(false == bCur)
    {
        address = (char*)memcpy(cSrc, szOriMsgfrMb + 8 + offset, iLen);
    }
    else
    {
        address = (char*)memcpy(cSrc, szOriMsgfrMb + offset, iLen);
    }

    offset+=iLen;
    return address;
}

int TransProcStates(const char * sInput, char * sOut)
{
    //以下为一代的
	if(0== strcmp(sInput ,"01"))
	{

		strcpy(sOut, PR_HVBP_24);

	}
	else if(0== strcmp(sInput ,"02"))
	{
		strcpy(sOut, PR_HVBP_02);
	}
	else if(0== strcmp(sInput ,"03"))
	{

		strcpy(sOut, PR_HVBP_15);

	}
	else if(0== strcmp(sInput ,"04"))
	{

		strcpy(sOut, PR_HVBP_16);

	}
	else if(0== strcmp(sInput ,"05"))
	{
		strcpy(sOut, PR_HVBP_11);
	}
	else if(0== strcmp(sInput ,"06"))
	{

		strcpy(sOut, PR_HVBP_19);

	}
	else if(0== strcmp(sInput ,"10"))
	{

		strcpy(sOut, PR_HVBP_07);

	}
	else if(0== strcmp(sInput ,"11"))
	{
		strcpy(sOut, PR_HVBP_23);
	}
 	else if(0== strcmp(sInput ,"12"))
	{
		strcpy(sOut, PR_HVBP_18);
	}
	else if(0== strcmp(sInput ,"13"))
	{

		strcpy(sOut, PR_HVBP_25);

	}
	else if(0== strcmp(sInput ,"14"))
	{

		strcpy(sOut, PR_HVBP_21);

	}
	else if(0== strcmp(sInput ,"15"))
	{

		strcpy(sOut, PR_HVBP_06);

	}	
	else if(0== strcmp(sInput ,"99"))
	{

		strcpy(sOut, PR_HVBP_99);

	}
	//以下为二代的
	else if(0== strcmp(sInput ,"PR00"))
	{
		strcpy(sOut,PR_HVBP_02 );         //已转发
	}
	else if(0== strcmp(sInput ,"PR01"))
	{
		strcpy(sOut, PR_HVBP_20 );        //待认证
	}
	else if(0== strcmp(sInput ,"PR02"))
	{
		strcpy(sOut, PR_HVBP_15 );       //已付款 已轧差
	}
	else if(0== strcmp(sInput ,"PR03"))
	{
		strcpy(sOut, PR_HVBP_15  );        //已轧差
	}
	else if(0== strcmp(sInput ,"PR04"))
	{
		strcpy(sOut, PR_HVBP_19  );        //已清算
	}
	else if(0== strcmp(sInput ,"PR05"))
	{
		strcpy(sOut, PR_HVBP_74 ) ;    //已成功
	}
	else if(0== strcmp(sInput ,"PR06"))
	{
		strcpy(sOut, PR_HVBP_71 ) ;      //待处理
	}
	else if(0== strcmp(sInput ,"PR07"))
	{
		strcpy(sOut, PR_HVBP_74 ) ;    //已处理
	}
	else if(0== strcmp(sInput ,"PR08"))
	{
		strcpy(sOut, PR_HVBP_18 ) ;       //已撤销
	}
	else if(0== strcmp(sInput ,"PR09"))
	{
		strcpy(sOut, PR_HVBP_24 ) ;    //已拒绝
	}
	else if(0== strcmp(sInput ,"PR10"))
	{
		strcpy(sOut, PR_HVBP_74 ) ;       //已确认
	}
	else if(0== strcmp(sInput ,"PR11"))
	{
		strcpy(sOut, PR_HVBP_16 ) ;      //轧差排队
	}
	else if(0== strcmp(sInput ,"PR12"))
	{
		strcpy(sOut, PR_HVBP_16 ) ;      //清算排队
	}
	else if(0== strcmp(sInput ,"PR13"))
	{
		strcpy(sOut, PR_HVBP_22  );       //清算异常，待重新清算
	}
	else if(0== strcmp(sInput ,"PR21"))
	{
		strcpy(sOut, PR_HVBP_25);        //已止付
	}
	else if(0== strcmp(sInput ,"PR22"))
	{
		strcpy(sOut, PR_HVBP_18 ) ;    //已冲正
	}
	else if(0== strcmp(sInput ,"PR23"))
	{
		strcpy(sOut, PR_HVBP_33 ) ;      //已退回
	}
	else if(0== strcmp(sInput ,"PR24"))
	{
		strcpy(sOut, PR_HVBP_06 );     //NPC未受理
	}
	else if(0== strcmp(sInput ,"PR32"))
	{
		strcpy(sOut, PR_HVBP_21  );       //已超期（逾期退回）
	}
	else if(0== strcmp(sInput ,"PR91"))
	{
		strcpy(sOut, PR_HVBP_23 ) ;      //部分止付
	}
	//add by zwc 20171116 for cnaps_v1.4.6
	else if(0== strcmp(sInput ,"PR16"))
	{
		strcpy(sOut, PR_HVBP_40 );       //已冻结待清算
	}
	else if(0== strcmp(sInput ,"PR17"))
	{
		strcpy(sOut, PR_HVBP_41  );      //已划回
	}
	else if(0== strcmp(sInput ,"PR18"))
	{
		strcpy(sOut, PR_HVBP_42 ) ;      //已退回
	}
	//add end
	else
	{
	    strcpy(sOut, PR_HVBP_00);
	}
    return 0;
}

int GetErrDsc(int iErrCode, char *p) 
{                               
    switch(iErrCode)    
    {        
        case 0:        
        {            
            strcpy(p, "处理成功");            
            break;        
        }
        case FAILED:        
        {            
            strcpy(p, "处理失败");            
            break;        
        }
        case PRM_FAIL:        
        {            
            strcpy(p, "参数错误");            
            break;        
        }
        case DATA_FAIL:        
        {            
            strcpy(p, "数据非法");            
            break;        
        }        
        case UNKNOWN_ERR:        
        {            
            strcpy(p, "未知错误");            
            break;        
        }
        case OTH_ERR:        
        {            
            strcpy(p, "其他错误");            
            break;        
        }
        case OPT_GET_DATE_FAIL:        
        {            
            strcpy(p, "取日期失败");            
            break;        
        }
        case OPT_GET_TIME_FAIL:        
        {            
            strcpy(p, "取时间失败");            
            break;        
        }
        case OPT_GET_SYS_DATETIME_FAIL:        
        {            
            strcpy(p, "获取系统日期时间失败");            
            break;        
        }
        case OPT_GET_SYS_PARA_FAIL:        
        {            
            strcpy(p, "获取系统参数失败");            
            break;        
        }
        case OPT_GET_WORK_DATE_FAIL:        
        {            
            strcpy(p, "获取工作日期失败");            
            break;        
        }
        case OPT_PRS_MSG_FAIL:        
        {            
            strcpy(p, "报文解析失败");            
            break;        
        }
        case OPT_SET_VLU_FAIL:        
        {            
            strcpy(p, "实体类成员赋值失败");            
            break;        
        }
        case OPT_GET_OBJ_FAIL:        
        {            
            strcpy(p, "获得解析类对象失败");            
            break;        
        }
        case OPT_DIGITSIGN_FAIL:
        {
            strcpy(p, "数字签名加签失败");
            break;
        }
        case OPT_CHECKSIGN_FAIL:        
        {            
            strcpy(p, "数字签名核签失败");            
            break;        
        }
        case OPT_TRADE_CHECK__FAIL:
        {
            strcpy(p, "业务检查未通过");
            break;
        }
        case ERR_NOT_FOUND_NO:       
        {            
            strcpy(p, "未知找到相应报文号");            
            break;        
        }
        case OPT_CREAT_MSG_FAIL:        
        {            
            strcpy(p, "创建消息失败");            
            break;        
        }
        case OPT_AMT_OUT_OF_LIMIT:        
        {            
            strcpy(p, "业务金额超过上限");            
            break;        
        }
        case OPT_GET_MSGID_FAIL:        
        {            
            strcpy(p, "获取报文标识号失败");            
            break;        
        }
        case OPT_RECVBANK_CHECK_FAIL:        
        {            
            strcpy(p, "接收行号检查失败");            
            break;        
        }
        case OPT_SENDBANK_CHECK_FAIL:        
        {            
            strcpy(p, "发起行号检查失败");            
            break;        
        }
        case OPT_GET_MESGREFID_FAIL:        
        {            
            strcpy(p, "取通信级参考号失败");            
            break;        
        }
        case OPT_MQ_ADD_FAIL:        
        {            
            strcpy(p, "往MQ队列添加数据失败");            
            break;        
        }
        case OPT_GET_MQ_CNNCT_FAIL:        
        {            
            strcpy(p, "获取MQ连接失败");            
            break;        
        }
        case OPT_DAYCUT_FAIL:
        {
            strcpy(p, "日切失败");
            break;
        }
        case DB_CNNCT_FAIL:        
        {            
            strcpy(p, "数据库连接失败");            
            break;        
        } 
        case DB_OPT_FAIL:        
        {            
            strcpy(p, "操作数据库错误");            
            break;        
        }
        case DB_NOT_FOUND:        
        {            
            strcpy(p, "数据库未找到记录");            
            break;        
        }
        case DB_KEY_FAIL:        
        {            
            strcpy(p, "违反唯一约束条件");            
            break;        
        }
        case DB_UPDATE_FAIL:
        { 
            strcpy(p, "更新数据库失败");            
            break;   
        }
        case DB_GET_DATA_FAIL:        
        {            
            strcpy(p, "获取数据失败");            
            break;        
        }
        case DB_DEL_FAIL:        
        {            
            strcpy(p, "删除数据库记录失败");            
            break;        
        }
        case DB_FIND_BY_PK_FAIL:        
        {            
            strcpy(p, "主键查找失败");            
            break;        
        }        
        case DB_INSERT_FAIL:        
        {            
            strcpy(p, "插入数据失败");            
            break;        
        }
        case DB_OTH_ERR:        
        {            
            strcpy(p, "数据库其他错误");            
            break;        
        }
         case OPT_LOGON:        
        {            
            strcpy(p, "系统已登录");            
            break;        
        }       
        case OPT_TRADE_NOTFOUND__FAIL:
        {
            strcpy(p, "没有找到相应报文业务类型");
            break;
        }
        case DB_FIND_FAIL:
        {
            strcpy(p, "查找数据库记录失败");
            break;
        }
        case OPT_HEAVY_ACCOUT_FAIL:
        {
            strcpy(p, "疑似重账业务");
            break;
        }
        default:        
        {            
            strcpy(p, "错误码未赋值.");            
            break;        
        }
    }             

    return SUCCESSED;
}


//----------------------------------------------------------------------
/*说明：获得系统参数
 *输入： sParamCode参数代码
 *输出： sParamValue 参数值
 *返回结果：0 调用成功 其他:失败
*/
//----------------------------------------------------------------------
int GetSysParam(DBProc &dbproc,const char  * sParamCode, char * sParamValue)
{
    char   sErrorDescTmp[1024+1] = {0};
    
    CSyssysparm p_CSysparm(dbproc);
    p_CSysparm.m_code= sParamCode;

    int iRetCode = p_CSysparm.findByPK();
    if (SQLNOTFOUND == iRetCode) 
    {
        sprintf(sErrorDescTmp,"系统参数控制表无记录,参数代码[%s], [%d][%s]", 
            p_CSysparm.m_code.c_str(), iRetCode, p_CSysparm.GetSqlErr());	

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDescTmp);		

        //PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, sErrorDescTmp);
    }
    else if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(sErrorDescTmp,"获取系统参数错误,参数代码[%s], [%d][%s]", 
            p_CSysparm.m_code.c_str(), iRetCode, p_CSysparm.GetSqlErr());	

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDescTmp);		

        //PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, sErrorDescTmp);
    }

    strcpy( sParamValue, p_CSysparm.m_parmvalue.c_str());

    return iRetCode;
}

/******************************************************************************
*  Function:    GetSapBankByCd
*  Description: 根据行号取清算行号
*  Input:		cpBankcode:参与者行号
*  Output:	    pSapBank:清算行号
*  Return:	    
*  Author:	    aps-lel
*  Date:	    2011-12-19
*******************************************************************************/
int GetSapBankByCd(DBProc &dbproc,const char * cpBankcode,char * pSapBank)
{
	int iRet = 0;
	CCmbankinfo oCmbankinfo(dbproc);

	oCmbankinfo.m_bankcode = cpBankcode;
	    
	iRet = oCmbankinfo.findByPK();
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取清算行失败,iRet=%d, %s", iRet, oCmbankinfo.GetSqlErr());
		return RTN_FAIL;
    }

	strcpy(pSapBank,oCmbankinfo.m_bankagent.c_str());

	return RTN_SUCCESS;
}

/******************************************************************************
*  Function:   GetWorkDate
*  Description:获取工作日期
*  Input:      sSapBank 直接参与机构，如为空时,则默认为当前清算行
*  Input:      iSysFlag 系统标识号, 默认取公共参数
*  Output:     sWorkDate 工作日期
*  Return:     0 调用成功 -1调用失败
*  Others:     无
*  Author:     
*  Date:       
*******************************************************************************/
int GetWorkDate(DBProc &dbproc, char *sWorkDate, int iSysFlag, const char *sSapBank)
{
    if (NULL == sWorkDate)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "sWorkDate = NULL!");
        return -1;
    }
    CSyssysparm cSapBankInfo(dbproc);
    
    int iRet = cSapBankInfo.GetWorkDate(sWorkDate, iSysFlag, sSapBank);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败,iRet=%d, %s iSysFlag=[%d] sSapBank=[%s]", iRet, cSapBankInfo.GetSqlErr(),iSysFlag, sSapBank);
    }
    
    return iRet;
}

int Zhenshu()
{
	/*
    unsigned char szTmp[1024 * 10] = {0};
    buffer_struct buffer;
    buffer.length = 0;
    buffer.szBuf = szTmp;
    printf("读文件开始\n");
    long i = ReadFile("cnapsqdo.pfx", &buffer);
    printf("读文件结束 i[%f]\n", i);

    printf("文件转64编码开始\n");
    char szEn64[1024 * 10] = {0};
    int ii = base64_encode(buffer.szBuf, buffer.length, szEn64);
    printf("文件转64编码结束 ii[%d]  szEn64[%s]\n", ii, szEn64);

    printf("密码des编码开始\n");
    char szDes[1024] = {0};
    desEncode("hdf", "BOCHKcnaps2", szDes);
    printf("密码des编码结束 szDes[%s]\n", szDes);
    */
    return 0;
}
/******************************************************************************
*  Function:    GetMsgIdValue
*  Description: 获取报文标识号、端到端标识号、交易标识号
*  Input:	    iCodeType：序号类型
*             01 = eMsgId	    报文标识号
*             02 = eInfoId	    信息业务类序号
*             03 = eRefId	    报文参考号 //注:文档里说明，是占20位
*             04 = eRecvId	    来帐业务序号
*             05 = eBigDataId	大文本标识号
*             15 = ebpListNo	小额明细序号
*             16 = ebpTmColNo	代收付签约协议号
*  Input:		sSendSapCode：  发起直接参与行行号
*  Output:	   sRtnValue：标识号  10:35位
*  Output:	   sErrorDesc：错误描述
*  Return:	   
*  Others:	   
*  Author:	   
*  Date:	   
*******************************************************************************/

bool GetMsgIdValue(DBProc &dbproc, char * sRtnValue, int iCodeType, int iSysFlag, const char * sSendSapCode, char * sErrorDesc, char * sWorkdate)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "entre GetMsgIdValue");
    if(NULL == sRtnValue)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "sRtnValue = NULL!");
        return false;
    }
	
    CSyssysparm cSysparm(dbproc);

    long lSn = cSysparm.get_serialno(iCodeType, iSysFlag, sSendSapCode);    

    if(-1 == lSn)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "get_serialno failed!,%s",  cSysparm.GetSqlErr());
        return false;
    }

    char sWrkDate[8 + 1] = {0};
    if (NULL == sWorkdate)
    {
        if (0 != GetWorkDate(dbproc, sWrkDate, iSysFlag, sSendSapCode))
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "GetWorkDate failed!");
            return false;
        }
    } 
    else
    {
        strcpy(sWrkDate, sWorkdate);
    }

    switch(iCodeType)
    {
        case 1:
        case 2:
        case 4:
        case 5:
        case 15:
        case 16:
            sprintf(sRtnValue, "%s%08d", sWrkDate,lSn);
            break;
        case 3:    
            sprintf(sRtnValue, "%s%012d", sWrkDate, lSn);
            break;
        default:
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "取序号类型未知[%d]!",iCodeType); 
            return false;
    }  
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "msgid=[%s]",sRtnValue ); 

    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "leave GetMsgIdValue");		
    return true;
} 


/******************************************************************************
*  Function:   JudgeMsgVer
*  Description:判断是第一代报文还是第二代报文
*  Input:      pchMsg 报文消息
*  Output:     无
*  Return:     1：   一代报文，
               2:    二代报文，
               其他：无法识别
*  Others:     无
*  Author:     yszhong
*  Date:       2011-01-27
*******************************************************************************/

int JudgeMsgVer(const char *pchMsg)
{
    int  iMsgVer       = MSG_VER_FAIL;    
    char szchMsgTag[MAX_BIZ_CODE_LEN + 1] = {0};

    memcpy(szchMsgTag, pchMsg, MAX_BIZ_CODE_LEN);

    if (0 == strncmp(szchMsgTag, MSG_TAG_2ND, MSG_TAG_LEN))
    {
        // 二代
        iMsgVer = MSG_VER_2ND;
    }
    else if (0 == strncmp(szchMsgTag, MSG_TAG_1ST, MSG_TAG_LEN))
    {
        // 一代
        iMsgVer = MSG_VER_1ST;
    }

    return iMsgVer;
}

/******************************************************************************
*  Function:   GetMsgCode
*  Description:获取报文码(一代返回一代报文码，二代返回二代报文码)
*  Input:      pchMsg 报文消息
*  Output:     无
*  Return:     报文码 -1：获取失败， 其他：成功
*  Others:     无
*  Author:     yszhong
*  Date:       2011-02-16
*******************************************************************************/

int GetMsgCode(const char *pchMsg)
{   
    if (NULL == pchMsg || strlen(pchMsg) < MAX_BIZ_CODE_LEN)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "pchMsg=%s", pchMsg);
        return -1;
    }

    char szchCode[MAX_BIZ_CODE_LEN + 1] = {0};
    char szchMsgTag[MSG_TAG_LEN + 1]    = {0};

    memcpy(szchMsgTag, pchMsg, MAX_BIZ_CODE_LEN);
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "szchMsgTag = %s", szchMsgTag);	

    int iBizCode = -1;
    
    int iVersion = JudgeMsgVer(pchMsg);    // 判断是一代报文还是二代报文

    if (iVersion == MSG_VER_2ND)
    {
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iVersion == MSG_VER_2ND...");
        // 二代报文
        if (strlen(pchMsg) < 63 + 3 + 1 )
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "pchMsg=%s", pchMsg);
            return -1;
        }

        memcpy(szchCode, pchMsg + 63, 3);
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "szchCode = %s", szchCode);	
    
        iBizCode = Get2NDBizCode(szchCode);
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iBizCode = %d", iBizCode);	
    }
    else if (iVersion == MSG_VER_1ST)
    {
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iVersion == MSG_VER_1ST...");

        // 一代报文
        if (strlen(pchMsg) < 11 + 3 + 1)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "pchMsg=%s", pchMsg);
            return -1;
        }
        memcpy(szchCode, pchMsg + 11, 3);

        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "szchCode = %s", szchCode);	

        iBizCode = Get1STBizCode(szchCode);
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iBizCode = %d", iBizCode);	
    }

    return iBizCode; 	
}



/******************************************************************************
*  Function:   GetBizCode
*  Description:获取业务码
*  Input:      pchMsg 报文消息
*                iVersion报文版本号
*  Output:     无
*  Return:     业务码 -1：获取失败， 其他：成功
*  Others:     无
*  Author:     yszhong
*  Date:       2011-01-27
*******************************************************************************/
int GetBizCode(const char *pchMsg, int &iVersion)
{   
    //Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "entering GetBizCode");	

    if (NULL == pchMsg || strlen(pchMsg) < 3)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "pchMsg=%s", pchMsg);
        return -1;
    }

    char szchCode[4]   = {0};
    char szchMsgTag[4] = {0};

    memcpy(szchMsgTag, pchMsg, 3);

    int iBizCode = -1;

    iVersion = JudgeMsgVer(pchMsg);
    if (iVersion == MSG_VER_2ND)
    {
        // 二代报文
        if (strlen(pchMsg) < 63 + 3 + 1)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "pchMsg=%s", pchMsg);
            return -1;
        }

        memcpy(szchCode, pchMsg + 63, 3);
        iBizCode = Get2NDBizCode(szchCode);
    }
    else if (iVersion == MSG_VER_1ST)
    {
        // 一代报文
        if (strlen(pchMsg) < 11 + 3 + 1)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "pchMsg=%s", pchMsg);
            return -1;
        }

        memcpy(szchCode, pchMsg + 11, 3);
        iBizCode = Get1STBizCode(szchCode);
    }
    else
  	{
  		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "GetBizCode failed!!!");
  	}

    //Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "leaving GetBizCode");	

    return iBizCode; 	
}


int GetBizCodeEx(const char *pchMsg, int& iMsgReserve, int& iMsgVersion, int &iVersion)
{
	iMsgReserve = iMsgVersion = -1;
	
	int iBizCode = GetBizCode(pchMsg, iVersion);
	if (iVersion == MSG_VER_2ND)
	{
		char szData[3+1] = {0};
		memset(szData, 0, sizeof(szData));
		memcpy(szData, pchMsg + 67, 3);
		iMsgReserve = atoi(szData);
		memset(szData, 0, sizeof(szData));
		memcpy(szData, pchMsg + 71, 3);
		iMsgVersion = atoi(szData);		
  }
  
  return iBizCode;
}


/******************************************************************************
*  Function:   Get1STBizCode
*  Description:获取一代对应二代的业务码
*  Input:      pchBizCode 业务码
*  Output:     无
*  Return:     业务码 -1：获取失败， 其他：成功
*  Others:     无
*  Author:     yszhong
*  Date:       2011-01-27
*******************************************************************************/

int Get1STBizCode(const char *pchBizCode)
{
    if (NULL == pchBizCode || '\0' == pchBizCode)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "pchBizCode=%s", pchBizCode);
        return -1;
    }
    
    int iBizCode = -1;

    switch (atoi(pchBizCode))
    {
        //==================== HV begin ====================   
        case HV_1ST_100:
            iBizCode = HV_1ST_100;
            break;
        case HV_1ST_101:
            iBizCode = HV_1ST_101;
            break;
        case HV_1ST_102:
            iBizCode = HV_1ST_102;
            break;
        case HV_1ST_103:
            iBizCode = HV_1ST_103;
            break;
        case HV_1ST_104:
            iBizCode = HV_1ST_104;
            break;
        case HV_1ST_105:
            iBizCode = HV_1ST_105;
            break;
        case HV_1ST_108:
            iBizCode = HV_1ST_108;
            break;
        case HV_1ST_121:
            iBizCode = HV_1ST_121;
            break;
        case HV_1ST_122:
            iBizCode = HV_1ST_122;
            break;
        case HV_1ST_123:
            iBizCode = HV_1ST_123;
            break;
        case HV_1ST_124:
            iBizCode = HV_1ST_124;
            break;
        case HV_1ST_231:
            iBizCode = HV_1ST_231;
            break;
        case HV_1ST_232:
            iBizCode = HV_1ST_232;
            break;
        case HV_1ST_233:
            iBizCode = HV_1ST_233;
            break;
        case HV_1ST_234:
            iBizCode = HV_1ST_234;
            break;
        case HV_1ST_402:
            iBizCode = HV_1ST_402;
            break;
        case HV_1ST_403:
            iBizCode = HV_1ST_403;
            break;
        case HV_1ST_407:
            iBizCode = HV_1ST_407;
            break;
        case HV_1ST_408:
            iBizCode = HV_1ST_408;
            break;
        case HV_1ST_841:
            iBizCode = HV_1ST_841;
            break;           
        //==================== HV end ====================

        //==================== BP begin ====================
        case BP_1ST_001:
            iBizCode = BP_1ST_001;
            break;
        case BP_1ST_002:
            iBizCode = BP_1ST_002;
            break;
        case BP_1ST_003:
            iBizCode = BP_1ST_003;
            break;
        case BP_1ST_004:
            iBizCode = BP_1ST_004;
            break;            
        case BP_1ST_005:
            iBizCode = BP_1ST_005;
            break;
        case BP_1ST_006:
            iBizCode = BP_1ST_006;
            break;
        case BP_1ST_007:
            iBizCode = BP_1ST_007;
            break;
        case BP_1ST_008:
            iBizCode = BP_1ST_008;
            break;
        case BP_1ST_009:
            iBizCode = BP_1ST_009;
            break;
        case BP_1ST_010:
            iBizCode = BP_1ST_010;
            break;            
        case BP_1ST_011:
            iBizCode = BP_1ST_011;
            break;
        case BP_1ST_012:
            iBizCode = BP_1ST_012;
            break;
        case BP_1ST_013:
            iBizCode = BP_1ST_013;
            break;
        case BP_1ST_324:
            iBizCode = BP_1ST_324;
            break;   
        case BP_1ST_325:
            iBizCode = BP_1ST_325;
            break;             
        case BP_2ND_130:
            iBizCode = BP_2ND_130;
            
            
        //==================== BP end ====================

        //==================== SP begin ====================
        case SP_1ST_253:
            iBizCode = SP_1ST_253;
            break;
		case SP_1ST_254:
			iBizCode = SP_1ST_254;
			break;

        //==================== SP end ====================


        //==================== CM begin ====================
        case 301:
            iBizCode = CM_1ST_301;
            break;
        case 302:
            iBizCode = CM_1ST_302;
            break;
        case 303:
            iBizCode = CM_1ST_303;
            break;
        case 310:
            iBizCode = CM_1ST_310;
            break;
        case 311:
            iBizCode = CM_1ST_311;
            break;
        case 312:
            iBizCode = CM_1ST_312;
            break;
        case 313:
            iBizCode = CM_1ST_313;
            break;
        case 314:
            iBizCode = CM_1ST_314;
            break;            
        case 319:
            iBizCode = CM_1ST_319;
            break;    
        case 320:
            iBizCode = CM_1ST_320;
            break;         
        case CM_1ST_321:
            iBizCode = CM_1ST_321;
            break;
        case CM_1ST_322:
            iBizCode = CM_1ST_322;
            break;
        case CM_1ST_327:
            iBizCode = CM_1ST_327;
            break;            
        case CM_1ST_328:
            iBizCode = CM_1ST_328;
            break;                        
        case CM_1ST_910:
            iBizCode = CM_1ST_910;
            break;
        case 911:
            iBizCode = CM_1ST_911;
            break;
        case CM_1ST_920:
            iBizCode = CM_1ST_920;
            break;
        //==================== CM end ====================
        default:
            break;
    }

    return iBizCode;
}


/******************************************************************************
*  Function:   GetMsgInfo
*  Description:根据二代报文信息获取对应的一代报文信息，或者由一代报文获取二代信息
*  Input:      
*  Output:     无
*  Return:     业务码 -1：获取失败， 其他：成功
*  Others:     无
*  Author:     Nine
*  Date:       2011-01-27
*******************************************************************************/
//int GetMsgInfo(DBProc &dbproc, int iVersion, stuMsgInfo *pstuMsgInfo)
//{
//	string strSql = "";
//	int iRet = 0;
//	CCmmsgnocomp oCmmsgnocomp(dbproc);
//	
//	if(iVersion == 1)
//	{
//		strSql =  "MSGID='";
//		strSql += pstuMsgInfo->szMsgid;
//		strSql += "' and PMTTPPRTRY='";
//		strSql += pstuMsgInfo->szPmtTpPrtry;
//		strSql += "' and PURPPRTRY='";
//		strSql += pstuMsgInfo->szPurpPrtry;
//		strSql += "'";
//	}
//	else if(iVersion == 2)
//	{
//		strSql =  "MSGNO='";
//		strSql += pstuMsgInfo->szMsgid;
//		strSql += "' and TRXSTYPE='";
//		strSql += pstuMsgInfo->szPmtTpPrtry;
//		strSql += "' and TRXKIND='";
//		strSql += pstuMsgInfo->szPurpPrtry;
//		strSql += "'";
//	}
//	
//	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[GetMsgInfo] sql=[%s]", strSql.c_str());
//	
//	iRet = oCmmsgnocomp.find(strSql);
//	
//	if(OPERACT_SUCCESS != iRet)
//	{
//		Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"一二代报文对照表[cm_msgnocomp]查询失败：[%d][%s]", iRet, oCmmsgnocomp.GetSqlErr());
//
//		return iRet;
//	}
//	
//	iRet = oCmmsgnocomp.fetch();
//	
//	if(iRet != 1403 && iRet != 0)
//	{
//		Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"一二代报文对照表[cm_msgnocomp]打开游标失败：[%d][%s]", iRet, oCmmsgnocomp.GetSqlErr());
//		
//		oCmmsgnocomp.closeCursor();
//
//		return iRet;
//	}
//	
//	if(iVersion == 1)
//	{
//		memset(pstuMsgInfo->szMsgNo, 0x00, sizeof(pstuMsgInfo->szMsgNo));
//		memset(pstuMsgInfo->szTrxstype, 0x00, sizeof(pstuMsgInfo->szTrxstype));
//		memset(pstuMsgInfo->szTrxkind, 0x00, sizeof(pstuMsgInfo->szTrxkind));
//		
//		strncpy(pstuMsgInfo->szMsgNo, oCmmsgnocomp.m_msgno.c_str(), 6);
//		strncpy(pstuMsgInfo->szTrxstype, oCmmsgnocomp.m_trxstype.c_str(), 5);
//		strncpy(pstuMsgInfo->szTrxkind, oCmmsgnocomp.m_trxkind.c_str(), 12);
//	}
//	else if(iVersion == 2)
//	{
//		memset(pstuMsgInfo->szMsgid, 0x00, sizeof(pstuMsgInfo->szMsgid));
//		memset(pstuMsgInfo->szPmtTpPrtry, 0x00, sizeof(pstuMsgInfo->szPmtTpPrtry));
//		memset(pstuMsgInfo->szPurpPrtry, 0x00, sizeof(pstuMsgInfo->szPurpPrtry));
//		
//		strncpy(pstuMsgInfo->szMsgid, oCmmsgnocomp.m_msgid.c_str(), 32);
//		strncpy(pstuMsgInfo->szPmtTpPrtry, oCmmsgnocomp.m_pmttpprtry.c_str(), 6);
//		strncpy(pstuMsgInfo->szPurpPrtry, oCmmsgnocomp.m_purpprtry.c_str(), 12);
//	}
//	
//	oCmmsgnocomp.closeCursor();
//	
//	return 0;
//}



/******************************************************************************
*  Function:   Get2NDBizCode
*  Description:获取二代业务码
*  Input:      pchBizCode 业务码
*  Output:     无
*  Return:     业务码 -1：获取失败， 其他：成功
*  Others:     无
*  Author:     yszhong
*  Date:       2011-01-27
*******************************************************************************/

int Get2NDBizCode(const char *pchBizCode)
{
    if (NULL == pchBizCode || '\0' == pchBizCode)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "pchBizCode=%s", pchBizCode);
        return -1;
    }   

		int iBizCode = atoi(pchBizCode);		

    return iBizCode;
}


/******************************************************************************
*  Function:   digitSign 
*  Description:数字签名加签函数
*  Input:      sOrigenStr 编签原始串
*  Input:      iSysFlag		私钥所属系统:0大额、1小额，默认为0
*  Input:      iSignType	签名类型：1裸签,2带签名者证书的签名
*  Input:      pPfxNm       pfx证书名称
*  Output:     sSignedStr  数字签名串
*  Return:     操作结果：0操作成功,其他操作失败
*  Others:     无
*  Author:     zwy
*  Date:       2010-04-10
*******************************************************************************/

int digitSign(DBProc &dbproc, 
			const char * sOrigenStr,
			char * sSignedStr,
			int iSysFlag, 
			int iSignType,
			const char * pPfxNm)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter digitSign...");

//	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "digitSign: OrigenStr=[%s]", sOrigenStr);

	int iRet = 0;
	char ipaddr[20] = {0};	
	char iport[20] = {0};
	char sPwdStr[256] = {0};
	int timeout=20;	
	char signDN[256] = {0};

	
	unsigned char retSignBuff[2048] = {0};
	
	unsigned char SignBuff[2048] = {0};
	int retLen = 0;
    int i=0;
	int socketfd;
	int indx=1;

	CCmbankcertinfo oCCmbankcertinfo(dbproc);
	
	oCCmbankcertinfo.m_bankcode = pPfxNm;
	iRet = oCCmbankcertinfo.findByPK();
	if(0 != iRet)
	{
		Trace(L_DEBUG,	__FILE__,  __LINE__, NULL,"oCCmbankcertinfo.findByPK Faild iRet=[%d][%s]",iRet,oCCmbankcertinfo.GetSqlErr());
		return iRet;
	}	
	else
	{
	    strcpy(signDN,oCCmbankcertinfo.m_certdn.c_str());
	}		

  Trace(L_DEBUG,	__FILE__,  __LINE__, NULL,"signDN=[%s]",signDN);

	//strcpy(signDN,"C=CN,O=CFCA TEST CA,OU=CNAPS,OU=Enterprises,CN=041@7501290000012@HSBC@00000010");
	//get sign ip
	/*iRet = GetSysParam(dbproc,"27",ipaddr);
	if(RTN_SUCCESS != iRet)
	{
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"获取系统参数失败");

		return iRet;
  }*/

  string sPaddr = g_SignAddr;
  string sTemp;
  
  string::size_type posBegin = 0;
  string::size_type posEnd = 0;
    
	char list[3][100] = {0};
	int istatus[3] = {0};
	int j = 0;
	    
  for ( j = 0; ;j ++ )
  {
      if (string::npos != (posEnd = sPaddr.find(";", posBegin) ))
      {
        sTemp = sPaddr.substr(posBegin,posEnd - posBegin );
       	strcpy(list[j],sTemp.c_str());    
       	posBegin =  posEnd + 1;

        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"list[%d][%s]",j,list[j]);       	
      }
      else
      {
        break;      
      }          
  } 
    
	//strcpy(list[0],"133.11.92.86:60001: ");
	//strcpy(list[1],"133.11.92.87:60001: ");
	
	//InitServerList( j, list, 2, istatus );
	InitServerList( 2, list, j, istatus );

	iRet = GetConncetion( &indx,  &socketfd );

	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"iRet=[%d] socketfd=[%d]",iRet,socketfd);

	//iRet = Connect( ipaddr ,atoi(iport) ,"" , &socketfd);
	if(0 != iRet ||  socketfd < 0)
	{
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"Get Connect Faild");
		return iRet;

	}
	
	int iLen = strlen(sOrigenStr);
	iRet = RawSign(socketfd,(unsigned char*)sOrigenStr,iLen, signDN,retSignBuff,&retLen);	
	
	
	if(0 != iRet)
	{
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"RawSign Faild");
		return iRet;
	}

	base64_encode(retSignBuff, retLen,sSignedStr);
	
	Disconnect( socketfd );

	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"digitSign: SignedStr=[%s]", sSignedStr);	

	return 0;
}


/******************************************************************************
*  Function:   getPfxBase64ByPfxName
*  Description:根据证书名字获取相应私钥证书信息(base64码)及密码
*  Input:      sPfxName 证书名称
*  Output:     sPfxBase64 私钥证书信息(base64码)max4000text
*  Output:     sPassWord 私钥证书密码
*  Return:     无
*  Others:     无
*  Author:     zwy
*  Date:       2010-05-20
*******************************************************************************/

int getPfxBase64ByPfxName(DBProc &dbproc, const char * sPfxName,char * sPfxBase64,char * sPassWord)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL,"enter getPfxBase64ByPfxName...");

	CCmsapcertinfo cCmsapcertinfo(dbproc);

	cCmsapcertinfo.m_certnm = sPfxName;

    int iRetCode = cCmsapcertinfo.findByPK();

    if (SQLNOTFOUND == iRetCode)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"本行证书信息表无名为[%s]的记录[%s]", 
		    sPfxName,cCmsapcertinfo.GetSqlErr());

		return iRetCode;
	}
	else if (SQL_SUCCESS != iRetCode) 
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"查询本行证书信息表中名为[%s]的记录失败[%s]", 
		    sPfxName,cCmsapcertinfo.GetSqlErr());

		return iRetCode;
	}

	strcpy(sPfxBase64, cCmsapcertinfo.m_certtxt.c_str());

	//desDecode(PMTS_EN_KEY, cCmsapcertinfo.m_passwd.c_str(), sPassWord);//暂时不用解密，数据存放的是明文
    strcpy(sPassWord ,cCmsapcertinfo.m_passwd.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL,"leave getPfxBase64ByPfxName...");

	return 0;
}

/******************************************************************************
*  Function:   getCerBase64ByBankCode
*  Description:根据行号获取该行公钥证书信息(base64码)
*  Input:      sBankCode 参与机构行号
*  Output:     sCerBase64 公钥证书信息(base64码)max4000text
*  Return:     操作结果：0操作成功,其他操作失败
*  Others:     无
*  Author:     zwy
*  Date:       2010-05-20
*******************************************************************************/

int getCerBase64ByBankCode(DBProc &dbproc, const char * sBankCode, char * sCerBase64)
{
    char   sErrorDescTmp[1024+1] = {0};
    
	CCmbankcertinfo cCmbankcertinfo(dbproc);

	cCmbankcertinfo.m_bankcode= sBankCode;

    int iRetCode = cCmbankcertinfo.findByPK();
    if (SQLNOTFOUND == iRetCode) 
	{
		sprintf(sErrorDescTmp,"参与者证书信息表无参与者行号为[%s]的记录[%s]", cCmbankcertinfo.m_bankcode.c_str(),cCmbankcertinfo.GetSqlErr());	

		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDescTmp);

		return 1;
	}
	else if (SQL_SUCCESS != iRetCode) 
	{
		sprintf(sErrorDescTmp,"参与者证书信息表无参与者行号为 bankcode [%s][%s]", cCmbankcertinfo.m_bankcode.c_str(),cCmbankcertinfo.GetSqlErr());	

		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDescTmp);

		return -1;
	}

	strcpy(sCerBase64, cCmbankcertinfo.m_certbody.c_str());

	return 0;
}


/******************************************************************************
*  Function:   setCerBase64ByBankCode
*  Description:根据行号更新该行公钥证书信息(base64码)
*  Input:      sBankCode 参与机构行号
*  Input:     sCerBase64 公钥证书信息(base64码)max4000text
*  Input:     sDN 公钥证书DN信息
*  Input:     sSN 公钥证书SN信息
*  Input:     sEffectDate 公钥证书颁发日期
*  Input:     sInvalidDate 公钥证书过期日期
*  Input:     iChangeType 变更类型：0：新增，1：撤销
*  Return:     无
*  Others:     无
*  Author:     zwy
*  Date:       2010-05-20
*******************************************************************************/
int setCerBase64ByBankCode(DBProc &dbproc,const char * sBankCode,const char * sCerBase64,char * sDN, char * sSN, char * sEffectDate, char * sInvalidDate,int iChangeType)
{
	#if 0
	char sErrorDescTmp[1024] = {0};
	int iRetCode = 0;

	CCmbankcertinfo cCmbankcertinfo(dbproc);

	cCmbankcertinfo.m_bankcode = sBankCode;

    iRetCode = cCmbankcertinfo.findByPK();

    if(SQLNOTFOUND == iRetCode) 
	{
		sprintf(sErrorDescTmp,"参与者证书信息表无参与者行号为[%s]的记录[%s]", 
		    cCmbankcertinfo.m_bankcode.c_str(),cCmbankcertinfo.GetSqlErr());	

		if(1 == iChangeType)/*如果是要撤销，却查询不到的话*/
		{
		    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDescTmp);
			return 1;
		}
	}
	else if (SQL_SUCCESS != iRetCode) 
	{
		sprintf(sErrorDescTmp,"参与者证书信息表无参与者行号为 bankcode [%s][%s]", 
		    cCmbankcertinfo.m_bankcode.c_str(),cCmbankcertinfo.GetSqlErr());	

		Trace(L_ERROR,  __FILE__,  __LINE__, NULL,sErrorDescTmp);

		return -1;
	}
	else
	{
		iRetCode = cCmbankcertinfo.remove();

	  	if (SQL_SUCCESS != iRetCode) 
		{
			sprintf(sErrorDescTmp,"删除参与机构[%s]证书信息失败[%d][%s]", 
			    sBankCode,iRetCode, cCmbankcertinfo.GetSqlErr());	

			if(1 == iChangeType)/*如果是要撤销，却删除出错的话*/
			{
			    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDescTmp);
				return 2;
			}
		}
	}

	printf("sEffectDate[%s]\n",sEffectDate);
	printf("sInvalidDate[%s]\n",sInvalidDate);
	
	//日期格式转换：由[2012-02-02 05:28:52]->20120202
	
	char szEffectDate[8+1]={0};
	char szInvalidDate[8+1]={0};
	chgToDate(sEffectDate,szEffectDate);
	chgToDate(sInvalidDate,szInvalidDate);
	printf("szEffectDate[%s]\n",szEffectDate);
	printf("szInvalidDate[%s]\n",szInvalidDate);
	
	cCmbankcertinfo.m_bankcode		= sBankCode;
	cCmbankcertinfo.m_certdn		= sDN;
	cCmbankcertinfo.m_certsn		= sSN;
	cCmbankcertinfo.m_certbody		= sCerBase64;	
	cCmbankcertinfo.m_certbinddate	= "";
	cCmbankcertinfo.m_certdatebegin	= szEffectDate;
	cCmbankcertinfo.m_certdateend	= szInvalidDate;
	cCmbankcertinfo.m_status		= "1";/*1为有效*/

	if(1 == iChangeType)/*如果是要撤销*/
	{
		cCmbankcertinfo.m_status	= "2";/*2为无效*/
	}

	iRetCode = cCmbankcertinfo.insert();

  	if (DUPLICATE_KEY == iRetCode) 
	{
		sprintf(sErrorDescTmp,"新增参与机构[%s]的公钥证书信息失败,证书已存在[%s]",
		    sBankCode,cCmbankcertinfo.GetSqlErr());	
		if(1 == iChangeType)
		{
			sprintf(sErrorDescTmp,"撤销参与机构[%s]的公钥证书信息失败,证书已存在[%s]",
			    sBankCode,cCmbankcertinfo.GetSqlErr());	
		}

		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDescTmp);
	}

	else if(SQL_SUCCESS != iRetCode)
	{
		sprintf(sErrorDescTmp,"新增参与机构[%s]的公钥证书信息发生错误[%s]",
		    sBankCode,cCmbankcertinfo.GetSqlErr());	
		if(1 == iChangeType)
		{
			sprintf(sErrorDescTmp,"撤销参与机构[%s]的公钥证书信息发生错误[%s]",
			    sBankCode,cCmbankcertinfo.GetSqlErr());	
		}

		Trace(L_ERROR,  __FILE__,  __LINE__, NULL,sErrorDescTmp);

		return -2;
	}
	#endif
	return 0;
}


/******************************************************************************
*  Function:   checkSign 
*  Description:数字签名核签函数
*  Input:      sOrigenStr 编签原始串
*  Input:      sSignedStr 数字签名串
*  Input:      sSendBankCode 报文发起参与机构行号
*  Input:      iSignType	签名类型：0裸签,1带签名者证书的签名
*  Return:     操作结果：0操作成功,其他操作失败
*  Others:     无
*  Author:     zwy
*  Date:       2010-04-10
*******************************************************************************/

int checkSign(DBProc &dbproc,const char * sOrigenStr,char* sSignedStr, const char * sSendBankCode ,int iSignType)
{
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"checkSign: OrigenStr = [%s]",sOrigenStr);
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"checkSign: SignedStr = [%s]",sSignedStr);
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"checkSign: SendBankCode = [%s]",sSendBankCode);

	int iRet = 0;
	char ipaddr[20] = {0};	
	char iport[20] = {0};
	char sPwdStr[256] = {0};
	int timeout=20;	
	char signDN[256] = {0};

	CERTINFO	rparam = {0};
	unsigned char retSignBuff[2048] = {0};
	int retLen = 0;
    int i=0;
	int socketfd;
	int indx;

  string sPaddr = g_SignAddr;
  string sTemp;
  
  string::size_type posBegin = 0;
  string::size_type posEnd = 0;
    
	char list[3][100] = {0};
	int istatus[3] = {0};
	int j = 0;
	    
  for ( j = 0; ;j ++ )
  {
      if (string::npos != (posEnd = sPaddr.find(";", posBegin) ))
      {
        sTemp = sPaddr.substr(posBegin,posEnd - posBegin );
       	strcpy(list[j],sTemp.c_str());    
       	posBegin =  posEnd + 1;

        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"list[%d][%s]",j,list[j]);       	
      }
      else
      {
        break;      
      }          
  } 
    
	//strcpy(list[0],"133.11.92.86:60001: ");
	//strcpy(list[1],"133.11.92.87:60001: ");
	
	//InitServerList( j, list, 2, istatus );
	InitServerList( 2, list, j, istatus );


	GetConncetion( &indx,  &socketfd );

	//iRet = Connect( ipaddr ,atoi(iport) ,"" , &socketfd);
	if(0 != iRet ||  socketfd < 0)
	{
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"Get Connect Faild");
		return iRet;

	}

	iRet = RawVerifySimple(socketfd ,
		                  (unsigned char*)sOrigenStr, 
		                  strlen(sOrigenStr),
		                  (char*)sSendBankCode,
		                  (unsigned char*)sSignedStr,
		                  strlen(sSignedStr),
		                  0,
		                  &rparam);	
	if(0 != iRet)
	{
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"RawVerifySimple Faild");
		return iRet;
	}
	
	Disconnect( socketfd );

	return 0;
}

/******************************************************************************
*  Function:   checkSignDetached
*  Description:带公钥信息数字签名核签函数
*  Input:      sOrigenStr 编签原始串
*  Input:      sSignedStr 数字签名串
*  Input:      sSendBankCode 报文发起参与机构行号
*  Input:      iChangeType 变更类型:默认0:新增，1:撤销
*  Return:     操作结果：0操作成功,其他操作失败
*  Others:     无
*  Author:     zwy
*  Date:       2010-04-10
*******************************************************************************/

int checkSignDetached(DBProc &dbproc,const char * sOrigenStr,char* sSignedStr, const char * sSendBankCode ,int iChangeType)
{
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"checkSign: OrigenStr = [%s]",sOrigenStr);
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"checkSign: SignedStr = [%s]",sSignedStr);
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"checkSign: SendBankCode = [%s]",sSendBankCode);
  return 0;
	int iRet = 0;
	char ipaddr[20] = {0};	
	char iport[20] = {0};
	char sPwdStr[256] = {0};
	int timeout=20;	
	char signDN[256] = {0};

	CERTINFO	rparam = {0};
	unsigned char retSignBuff[2048] = {0};
	int retLen = 0;
    int i=0;
	int socketfd;
	int indx;

	CERTINFO result = {0};

	//get sign ip
	iRet = GetSysParam(dbproc,"27",ipaddr);
	if(RTN_SUCCESS != iRet)
	{
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"获取系统参数失败");

		return iRet;
    }

	//get sign port
	iRet = GetSysParam(dbproc,"28",iport);
	if(RTN_SUCCESS != iRet)
	{
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"获取系统参数失败");

		return iRet;
    }

	iRet = GetSysParam(dbproc,"29",sPwdStr);
	if(RTN_SUCCESS != iRet)
	{
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"获取系统参数失败");

		return iRet;
    }


	char list[2][100] = {0};
	int istatus[2] = {0};
	strcpy(list[0],"133.11.92.86:60000:");
	strcpy(list[0],"133.11.92.87:60000:");
	
	InitServerList( 2, list, 2, istatus );

	GetConncetion( &indx,  &socketfd );

	//iRet = Connect( ipaddr ,atoi(iport) ,"" , &socketfd);
	if(0 != iRet ||  socketfd < 0)
	{
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"Get Connect Faild");
		return iRet;

	}

	CCmbankcertinfo oCCmbankcertinfo(dbproc);
	
	/*

	char buf[1024] = {0};
	char sign[2048] = {0};
	int isign = 0;
	strcpy(buf,"nihao");
	
	iRet =  DetachedSign(         socketfd, 
							  (unsigned char*)buf, 
							  strlen(buf), 
							  signDN, 
							  (unsigned char*)sign, 
							  &isign);

	if(0 != iRet)
	{
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"DetachedSign Faild");
		Disconnect( socketfd );		
		return iRet;
	}

	iRet = DetachedVerify(socketfd, 
							(unsigned char*)buf,
							strlen(buf),
							(unsigned char*)sign,
							isign,
							1, 
						  &result);
	*/

	unsigned long outlen = 0;
	char sDecodeStr[2048] = {0};
	base64_decode(sSignedStr,(unsigned char *)sDecodeStr,&outlen);

	Trace(L_DEBUG,	__FILE__,  __LINE__, NULL,"sDecodeStr=[%s] outlen=[%d]",sDecodeStr,outlen);
	
	iRet = DetachedVerifySimple(socketfd, 
							(unsigned char*)sOrigenStr,
							strlen(sOrigenStr),
							(unsigned char*)sDecodeStr,
							outlen,
							1, 
						  &result);
	
	if(0 != iRet)
	{
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"DetachedVerify Faild");
		Disconnect( socketfd );		
		return iRet;
	}

  Trace(L_DEBUG,	__FILE__,  __LINE__, NULL,"DN=[%s] SUBJECT=[%s]",result.issuer,result.subject);

	Disconnect( socketfd );
	
	oCCmbankcertinfo.m_bankcode = sSendBankCode;
	iRet = oCCmbankcertinfo.findByPK();
	if(0 != iRet && 1403 != iRet)
	{
		Trace(L_DEBUG,	__FILE__,  __LINE__, NULL,"oCCmbankcertinfo.findByPK Faild iRet=[%d][%s]",iRet,oCCmbankcertinfo.GetSqlErr());
		return iRet;
	}	
	else if(1403 == iRet)
	{
		Trace(L_DEBUG,	__FILE__,  __LINE__, NULL,"[%s]SAP BANK NOT FOUND---insert",sSendBankCode);
	    
    oCCmbankcertinfo.m_bankcode = sSendBankCode;
		oCCmbankcertinfo.m_certdn = result.issuer;

		iRet = oCCmbankcertinfo.insert();
		if(0 != iRet )
		{
			Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,"oCCmbankcertinfo.insert Faild iRet=[%d][%s]",iRet,oCCmbankcertinfo.GetSqlErr());
			return iRet;
		}			

	}
	else{

		Trace(L_DEBUG,	__FILE__,  __LINE__, NULL,"[%s]SAP BANK FOUND---UPDATE",sSendBankCode);

    oCCmbankcertinfo.m_bankcode = sSendBankCode;
		oCCmbankcertinfo.m_certdn = result.issuer;
		
		iRet = oCCmbankcertinfo.updatestate();
		if(0 != iRet )
		{
			Trace(L_DEBUG,	__FILE__,  __LINE__, NULL,"oCCmbankcertinfo.updatestate Faild iRet=[%d][%s]",iRet,oCCmbankcertinfo.GetSqlErr());
			return iRet;
		}	

	}		
	
	return 0;
}

/******************************************************************************
*  Function:   TranSapBkToCCPCCode
*  Description:根据清算行行号获取CCPC节点号
*  Input:      sSapBank 清算行行号
*  output:     sCCPCCode CCPC节点号
*  Return:     0:操作成功,其他:操作失败
*  Others:     无
*  Author:     lpye
*  Date:       2011-03-02
*******************************************************************************/

int TranSapBkToCCPCCode(DBProc &dbproc, const char * sSapBank, char* sCCPCCode)
{
    CCmbankinfo p_CCmbankinfo(dbproc);
    char   sErrorDescTmp[1024+1] = {0};
    
    p_CCmbankinfo.m_bankcode = sSapBank;

    int iRetCode=p_CCmbankinfo.findByPK();
    if (SQLNOTFOUND == iRetCode) 
    {
        sprintf(sErrorDescTmp,"行名行号表无记录,参数代码[%s], [%d][%s]", 
            p_CCmbankinfo.m_bankcode.c_str(), iRetCode, p_CCmbankinfo.GetSqlErr());	

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "%s", sErrorDescTmp);		

        //PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, sErrorDescTmp);
    }
    else if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(sErrorDescTmp, "行名行号表无记录,参数代码[%s], [%d][%s]", 
            p_CCmbankinfo.m_bankcode.c_str(), iRetCode, p_CCmbankinfo.GetSqlErr());	

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "%s", sErrorDescTmp);		

        //PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, sErrorDescTmp);
    }

    strcpy(sCCPCCode, p_CCmbankinfo.m_bankcenter.c_str());

    return iRetCode;
}

/******************************************************************************
*  Function:   GetTagVal
*  Description:从字符串strInputSrc中获取Tag对应的value
*  Input:      strInputTag  tag
               strInputSrc  源字符串
*  Output:     strValue     字符串值
*  Return:     无
*  Others:     无
*  Author:     yszhong
*  Date:       2011-03-08
*******************************************************************************/
/*void GetTagVal(string &strValue, const string &strInputSrc, const string &strInputTag)
{
    if ("" == strInputSrc)    
    {    
        return;    
    }
    
    string            strEndTag = ":";        
    string::size_type posBegin  = 0;    
    string::size_type posEnd    = 0;    
    
    if (string::npos != (posBegin = strInputSrc.find(strInputTag, posBegin) ) )     
    {
        posBegin = posBegin + strInputTag.length();
    
        if (string::npos != (posEnd = strInputSrc.find(strEndTag, posBegin) ) )        
        {        
            strValue = strInputSrc.substr(posBegin, posEnd - posBegin);        
        }        
        else        
        {        
            strValue = strInputSrc.substr(posBegin, strInputSrc.length() - posBegin);        
        }        
    }
}*/


/******************************************************************************
*  Function:   GetTagCount
*  Description:从字符串strInputSrc中获取Tag出现的次数
*  Input:      strInputTag  tag
               strInputSrc  源字符串
*  Output:     iCount       tag出现的次数
*  Return:     0:成功，其他:失败
*  Others:     无
*  Author:     yszhong
*  Date:       2011-03-17
*******************************************************************************/
int GetTagCount(const string &strInputSrc, const string &strInputTag, int &iCount)
{
    if (strInputSrc.empty() || strInputTag.empty())
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"strInputTag is empty");

        return PRM_FAIL;
    }
    
    string::size_type posBegin   = 0;
    int               iCountTmp  = 0;
    
    while(string::npos != (posBegin = strInputSrc.find(strInputTag, posBegin) ) )
    {
        posBegin = posBegin + strInputTag.length();
    
        iCountTmp++;
    }
    
    iCount = iCountTmp;

    return SUCCESSED;
}


/******************************************************************************
*  Function:   GetTagVal
*  Description:从字符串strInputSrc中获取Tag对应的value
*  Input:      strInputTag  tag
               strInputSrc  源字符串
               iTimes       第几个tag,不传默认为1
*  Output:     strValue     字符串值
*  Return:     0 成功,-1失败,-2找到TAG但值为空
*  Others:     无
*  Author:     yszhong
*  Date:       2011-03-17
*******************************************************************************/
int GetTagVal(string &strValue, const string &strInputSrc, const string &strInputTag, const int iTimes)
{
    strValue = "";
    
    if (strInputSrc.empty())    
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"strInputTag is empty");
        return PRM_FAIL;    
    }
    
    string            strEndTag = ":";     
    int               iTimesTmp = 0;   
    string::size_type posBegin  = 0;    
    string::size_type posEnd    = 0;
    int               iIsFind   = 0;
    
    while (string::npos != (posBegin = strInputSrc.find(strInputTag, posBegin) ) )     
    {    
        iTimesTmp++;
    
        posBegin = posBegin + strInputTag.length();

        if (iTimes == iTimesTmp)
        {    
            if (string::npos != (posEnd = strInputSrc.find(strEndTag, posBegin) ) )        
            {        
                strValue = strInputSrc.substr(posBegin, posEnd - posBegin);        
            }        
            else        
            {        
                strValue = strInputSrc.substr(posBegin, strInputSrc.length() - posBegin);        
            }   

            if (0 != strValue.length())
            {
                iIsFind = 1;
            }
            else
            {
                iIsFind = 2;
            }
            
            break;
        }     
    }

    if ( 0 == iIsFind )
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL," 0 == iIsFind ");
        return FAILED;
    }
    else if ( 2 == iIsFind )
    {
        return -2;
    }
    else
    {
        return SUCCESSED;
    }
}


/******************************************************************************
*  Function:   GetSubstrByDepth
*  Description:从字符串strInputSrc中获取子字符串
*  Input:      strInputTag  tag
               strInputSrc  源字符串
               iDepth       出现的深度,不传默认为1
*  Output:     strValue     字符串值
*  Return:     0 成功,-1失败,-2找到TAG但值为空
*  Others:     无
*  Author:     yszhong
*  Date:       2011-04-12
*******************************************************************************/
int GetSubstrByDepth(string &strSubstr, const string &strInputSrc, const string &strInputTag, const int iDepth)
{
    if (strInputSrc.empty() || strInputTag.empty())
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"strInputTag or strInputSrc is empty");
        return PRM_FAIL;
    }

    strSubstr = "";

    int               iDepthTmp = 0;   
    string::size_type posBegin  = 0;    
    string::size_type posEnd    = 0;

    while (string::npos != (posEnd = strInputSrc.find(strInputTag, posBegin) ) )
    {
        ++iDepthTmp;

        if (iDepth == iDepthTmp)
        {
            break;
        }

        posBegin = posEnd + strInputTag.length();
    }

    // 找不到tag，返回-1
    if (0 == iDepthTmp)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"0 == iDepthTmp");
        return FAILED;
    }

    // 截取字符串
    strSubstr = strInputSrc.substr(posBegin, posEnd - posBegin);

    if (0 != strSubstr.length())
    {
        // 成功取到值，返回0
        return SUCCESSED;
    }
    else
    {
        // 取到空值，返回-2
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"取到空值");
        return -2;
    }
}


/******************************************************************************
*  Function:   GetIsoDateTime
*  Description:获取系统工作ISO日期:YYYY-MM-DDTHH:mm:SS
*  Input:      iSysFlag 系统标识
*  Input:      sIsoDateTime 日期串指针
*  Output:     sIsoDateTime 系统工作ISO日期:YYYY-MM-DDTHH:mm:SS
*  Return:     无
*  Others:     无
*  Author:     zwy
*  Date:       2011-03-09
*******************************************************************************/

int GetIsoDateTime(DBProc &dbproc,int iSysFlag,char * sIsoDateTime)
{
	char sTmpDate[8 + 1]     = {0};
	char sIsoTmpDate[10 + 1] = {0};

    if (SUCCESSED != GetWorkDate(dbproc,sTmpDate, iSysFlag))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"获取工作日期出错");
        return FAILED;
    }
    
	chgToISODate(sTmpDate,sIsoTmpDate);

    struct tm *nowtime;
    time_t longtime;
    time(&longtime);

    nowtime=localtime(&longtime);

    sprintf(sIsoDateTime,"%sT%02d:%02d:%02d",sIsoTmpDate,nowtime->tm_hour,nowtime->tm_min,nowtime->tm_sec);

    return SUCCESSED;
}


/******************************************************************************
*  Function:   GetSapBank
*  Description:根据参与者行号取清算行号
*  Input:      sBankCode   参与者行号
*  Output:     sSapBank    清算行号
*  Return:     0 调用成功 其他 调用失败
*  Others:     无
*  Author:     
*  Date:       2011-03-30
*******************************************************************************/
int GetSapBank(DBProc &dbproc, const char* sBankCode, char* sSapBank)
{
    if (NULL == sBankCode || '\0' == sBankCode || NULL == sSapBank)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"sBankCode or sSapBank is empyt value");
        return PRM_FAIL;
    }
    
    CSyssysparm cBankInfo(dbproc);

    int iRet = cBankInfo.GetSapBank(sBankCode, sSapBank);
    
    return iRet;
}

/******************************************************************************
*  Function:    isOutOfLimit
*  Description: 检查是否超过业务金额上限
*  Input:       sMsgType:报文编号 sBizType:业务类型 sAmount:金额
*  Output:      
*  Return:      0:没超过上限,1:超过上限,-1:出错
*  Others:
*  Author:      hq
*  Date:        2011-04-12
*******************************************************************************/
int isOutOfLimit(DBProc &dbproc, const char* sMsgType, const char* sBizType, double sAmount, char* sErrorDesc)
{
    CCmtxamtlmt cCmtxamtlmt(dbproc);
    char sErrMsgTmp[1024+1] = {0};

    memset(sErrorDesc, 0x00, sizeof(sErrorDesc));
    
    cCmtxamtlmt.m_msgtype = sMsgType;
    cCmtxamtlmt.m_biztype = sBizType;
    
    int iRetCode = cCmtxamtlmt.findByPK();
    if (SQLNOTFOUND == iRetCode)
    {
        sprintf(sErrMsgTmp,"业务金额上限表无该记录[%s][%s]", 
            cCmtxamtlmt.m_msgtype.c_str(), cCmtxamtlmt.m_biztype.c_str());

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrMsgTmp);
        if(sErrorDesc)
        {
            sprintf(sErrorDesc, sErrMsgTmp);
        }

        return FAILED;
    }
    else if (SQL_SUCCESS != iRetCode)
    {
        sprintf(sErrMsgTmp, "查询业务金额上限表出错[%s]", cCmtxamtlmt.GetSqlErr());

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrMsgTmp);
        if(sErrorDesc)
        {
            sprintf(sErrorDesc, sErrMsgTmp);
        }
        return FAILED;
    }

    if( sAmount > cCmtxamtlmt.m_amtlmt)
    {
        sprintf(sErrMsgTmp, "金额[%.2f]超过业务金额上限[%.2f]", sAmount, cCmtxamtlmt.m_amtlmt);

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrMsgTmp);
        if(sErrorDesc)
        {
            sprintf(sErrorDesc, sErrMsgTmp);
        }
        return 1;
    }

    return SUCCESSED;
}

/******************************************************************************
*  Function:    isBankRight
*  Description: 检查参与者是否合法
*  Input:       sBankCode：参与者行号
*  Output:      sErrorDesc：错误描述
*  Return:      0:合法,1:不合法,-1:出错
*  Others:
*  Author:      hq
*  Date:        2011-04-12
*******************************************************************************/
int isBankRight(DBProc &dbproc, const char* sBankCode, char* sErrorDesc)
{
    CCmbankinfo oCmbankinfo(dbproc);
	char sErrMsgTmp[1024+1] = {0};
	
	memset(sErrorDesc, 0x00, sizeof(sErrorDesc));
	oCmbankinfo.m_bankcode = sBankCode;
	
    int iRetCode = oCmbankinfo.findByPK();
    if (SQLNOTFOUND == iRetCode) 
	{
		sprintf(sErrMsgTmp, "未找到行号为[%s]的记录", oCmbankinfo.m_bankcode.c_str());	
			
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrMsgTmp);
		if(sErrorDesc)
		{
			sprintf(sErrorDesc, sErrMsgTmp);
		}
		
		return FAILED;
	}
	else if (SQL_SUCCESS != iRetCode) 
	{
		sprintf(sErrMsgTmp, "查询行名行号信息表表发生错误[%d][%s]", 
		    iRetCode, oCmbankinfo.GetSqlErr());	

		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrMsgTmp);
		if(sErrorDesc)
		{
			sprintf(sErrorDesc, sErrMsgTmp);
		}
		
		return FAILED;
	}
	
	if(0 == strcmp(oCmbankinfo.m_procstate.c_str(), "34"))
    {
        sprintf(sErrMsgTmp, "参与者行号[%s]未生效!", oCmbankinfo.m_bankcode.c_str());
        
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrMsgTmp);
    	if(sErrorDesc)
		{
			sprintf(sErrorDesc, sErrMsgTmp);
		}
		
    	return 1;
    }
	else if(0 == strcmp(oCmbankinfo.m_procstate.c_str(), "36"))
    {
    	sprintf(sErrMsgTmp, "参与者行号[%s]已注销!", oCmbankinfo.m_bankcode.c_str());
        
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrMsgTmp);
    	if(sErrorDesc)
		{
			sprintf(sErrorDesc, sErrMsgTmp);
		}
		
    	return 1;
    }

	return SUCCESSED;
}

/******************************************************************************
*  Function:    ChkHvpsSysstat
*  Description: 大额系统状态检查
*  Input:       dbproc:数据库连接对象
*               sMsgTp:报文类型
*               sSapBankCode：参与清算行号
*  Output:      sErrorDesc：错误描述
*  Return:      0:合法,1:不合法,-1:出错
*  Author:      aps-lel
*  Date:        2011-07-12
*******************************************************************************/
int ChkHvpsSysstat(DBProc &dbproc, const char* sMsgTp,const char* sSapBankCode, char* sErrorDesc)
{
    if(NULL == sErrorDesc)
    {
        return FAILED;
    }

    char szMsgTP[20] = {0};
    strncpy(szMsgTP,sMsgTp,sizeof(szMsgTP)-1);
    StrLowerCase_ZFPT(szMsgTP);

    CHvsapbankinfo oHvsapbankinfo(dbproc);

    oHvsapbankinfo.m_sapbank = sSapBankCode;

    int iRetCode = oHvsapbankinfo.findByPK();
    if (SQLNOTFOUND == iRetCode) 
    {
        sprintf(sErrorDesc, "未找到行号为[%s]的记录", oHvsapbankinfo.m_sapbank.c_str());                
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);     
        return FAILED;
    }
    else if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(sErrorDesc, "查询行名行号信息表表发生错误[%d][%s]", 
         iRetCode, oHvsapbankinfo.GetSqlErr());  
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);     
        return FAILED;
    }

    if(0 != strcmp(oHvsapbankinfo.m_chgstate.c_str(), "02"))//检查系统登录状态:02已登录
    {
        sprintf(sErrorDesc, "参与者行号[%s]未生效!", oHvsapbankinfo.m_sapbank.c_str());

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);

        return 1;
    }
    if (0 == strcmp(oHvsapbankinfo.m_sysstate.c_str(),"40"))//系统状态:日终处理
    {
        if(NULL != strstr(szMsgTP,"hvps.710")||NULL != strstr(szMsgTP,"hvps.712")||
           NULL != strstr(szMsgTP,"saps.731")||NULL != strstr(szMsgTP,"hvps.714")||
           NULL != strstr(szMsgTP,"ccms.903")||NULL != strstr(szMsgTP,"ccms.990")||
           NULL != strstr(szMsgTP,"ccms.991")||NULL != strstr(szMsgTP,"ccms.303"))
        {
            return 0;
        }
        else
        {
            sprintf(sErrorDesc, "日终状态不能发送msgtp [%s]", sMsgTp);  
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);
            return 1;
        }
    }
    else if(0 == strcmp(oHvsapbankinfo.m_sysstate.c_str(),"00"))//系统状态: 营业准备       
    {
        if(NULL != strstr(szMsgTP,"hvps.710")||NULL != strstr(szMsgTP,"hvps.712")||
           NULL != strstr(szMsgTP,"hvps.714")||NULL != strstr(szMsgTP,"saps.357")||
           NULL != strstr(szMsgTP,"saps.358")||NULL != strstr(szMsgTP,"saps.361")||
           NULL != strstr(szMsgTP,"saps.366")||NULL != strstr(szMsgTP,"saps.368")||
           NULL != strstr(szMsgTP,"saps.369")||NULL != strstr(szMsgTP,"saps.370")||
           NULL != strstr(szMsgTP,"saps.371")||NULL != strstr(szMsgTP,"saps.373")||
           NULL != strstr(szMsgTP,"saps.374")||NULL != strstr(szMsgTP,"saps.375")||
           NULL != strstr(szMsgTP,"saps.614")||NULL != strstr(szMsgTP,"saps.615")||
           NULL != strstr(szMsgTP,"saps.731")||NULL != strstr(szMsgTP,"ccms.303")||
           NULL != strstr(szMsgTP,"ccms.903")||NULL != strstr(szMsgTP,"ccms.919")||
           NULL != strstr(szMsgTP,"ccms.990")||NULL != strstr(szMsgTP,"ccms.991"))
        {
            return 0;
        }
        else
        {
            sprintf(sErrorDesc, "营业准备期间不能发送msgtp [%s]", sMsgTp);  
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);
            return 1;
        }
    
    }
    else if(0 == strcmp(oHvsapbankinfo.m_sysstate.c_str(),"10"))//系统状态:日间
    {
        if(NULL != strstr(szMsgTP,"saps.737"))
         {
            sprintf(sErrorDesc, "日间系统状态不能发送msgtp [%s]", sMsgTp);  
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);
            return 1;
         }
         else
         {
             return 0;
         }
    
    }
    else if(0 == strcmp(oHvsapbankinfo.m_sysstate.c_str(),"20"))//系统状态:业务截止
    {
        if(NULL != strstr(szMsgTP,"ccms.990")||NULL != strstr(szMsgTP,"ccms.991"))
         {

            return 0;

         }
         else
         {
             sprintf(sErrorDesc, "日间系统状态不能发送msgtp [%s]", sMsgTp);  
             Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);
             return 1;
         }
    
    }
    else if(0 == strcmp(oHvsapbankinfo.m_sysstate.c_str(),"30"))//系统状态:清算窗口
    {
        if(NULL != strstr(szMsgTP,"hvps.111")||NULL != strstr(szMsgTP,"hvps.112")||
           NULL != strstr(szMsgTP,"hvps.141")||NULL != strstr(szMsgTP,"hvps.143")||
           NULL != strstr(szMsgTP,"hvps.144")||NULL != strstr(szMsgTP,"hvps.151")||
           NULL != strstr(szMsgTP,"hvps.152")||NULL != strstr(szMsgTP,"hvps.153")||
           NULL != strstr(szMsgTP,"hvps.154")||NULL != strstr(szMsgTP,"hvps.631")||
           NULL != strstr(szMsgTP,"hvps.634")||NULL != strstr(szMsgTP,"saps.357")||
           NULL != strstr(szMsgTP,"saps.358")||NULL != strstr(szMsgTP,"saps.363")||
           NULL != strstr(szMsgTP,"saps.365")||NULL != strstr(szMsgTP,"saps.366")||
           NULL != strstr(szMsgTP,"saps.368")||NULL != strstr(szMsgTP,"saps.369")||
           NULL != strstr(szMsgTP,"saps.609")||NULL != strstr(szMsgTP,"saps.611")||
           NULL != strstr(szMsgTP,"saps.612")||NULL != strstr(szMsgTP,"saps.613")||
           NULL != strstr(szMsgTP,"saps.614")||NULL != strstr(szMsgTP,"saps.615")||
           NULL != strstr(szMsgTP,"ccms.303")||NULL != strstr(szMsgTP,"ccms.307")||
           NULL != strstr(szMsgTP,"ccms.308")||NULL != strstr(szMsgTP,"ccms.990")||
           NULL != strstr(szMsgTP,"ccms.991"))
        {
            return 0;
        }
        else
        {
            sprintf(sErrorDesc, "营业准备期间不能发送msgtp [%s]", sMsgTp);  
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);
            return 1;
        }
    
    }
    else if(0 == strcmp(oHvsapbankinfo.m_sysstate.c_str(),"03"))//系统状态:停运
    {
    
        if(NULL != strstr(szMsgTP,"ccms.303")||NULL != strstr(szMsgTP,"ccms.990")||
           NULL != strstr(szMsgTP,"ccms.991"))
         {
        
            return 0;
        
         }
         else
         {
             sprintf(sErrorDesc, "日间系统状态不能发送msgtp [%s]", sMsgTp);  
             Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);
             return 1;
         }
    }
    else
    {
        sprintf(sErrorDesc, "系统状态未知[%s]", oHvsapbankinfo.m_sysstate.c_str());  
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);
        return FAILED;
    }
   
	return SUCCESSED;
}
/******************************************************************************
*  Function:    ChkBepsSysstat
*  Description: 小额系统状态检查
*  Input:       dbproc:数据库连接对象
*               sMsgTp:报文类型
*               sSapBankCode：参与清算行号
*  Output:      sErrorDesc：错误描述
*  Return:      0:合法,1:不合法,-1:出错
*  Author:      aps-lel
*  Date:        2011-07-12
*******************************************************************************/
int ChkBepsSysstat(DBProc &dbproc, const char* sMsgTp,const char* sSapBankCode, char* sErrorDesc)
{
    if(NULL == sErrorDesc)
    {
        return FAILED;
    }

    char szMsgTP[20] = {0};
    strncpy(szMsgTP,sMsgTp,sizeof(szMsgTP)-1);
    StrLowerCase_ZFPT(szMsgTP);

    CBpsapbankinfo oBpsapbankinfo(dbproc);
    
    oBpsapbankinfo.m_sapbank = sSapBankCode;
    
    int iRetCode = oBpsapbankinfo.findByPK();
    if (SQLNOTFOUND == iRetCode) 
    {
        sprintf(sErrorDesc, "未找到行号为[%s]的记录", oBpsapbankinfo.m_sapbank.c_str());                
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);     
        return FAILED;
    }
    else if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(sErrorDesc, "查询行名行号信息表表发生错误[%d][%s]", 
         iRetCode, oBpsapbankinfo.GetSqlErr());  
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);     
        return FAILED;
    }
    
    if(0 != strcmp(oBpsapbankinfo.m_chgstate.c_str(), "02"))//检查系统登录状态:02已登录
    {
        sprintf(sErrorDesc, "参与者行号[%s]未生效!", oBpsapbankinfo.m_sapbank.c_str());
    
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);
    
        return 1;
    }   
    if (0 == strcmp(oBpsapbankinfo.m_sysstate.c_str(),"40"))//系统状态:日终处理
     {
         if(NULL != strstr(szMsgTP,"saps.731")||NULL != strstr(szMsgTP,"ccms.903")||
            NULL != strstr(szMsgTP,"ccms.990")||NULL != strstr(szMsgTP,"ccms.991")||
            NULL != strstr(szMsgTP,"ccms.303"))
         {
             return 0;
         }
         else
         {
             sprintf(sErrorDesc, "日终状态不能发送msgtp [%s]", sMsgTp);  
             Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);
             return 1;
         }
     }
     else if(0 == strcmp(oBpsapbankinfo.m_sysstate.c_str(),"00"))//系统状态: 营业准备       
     {
         if(NULL != strstr(szMsgTP,"saps.357")||NULL != strstr(szMsgTP,"saps.358")||
            NULL != strstr(szMsgTP,"saps.361")||NULL != strstr(szMsgTP,"saps.366")||
            NULL != strstr(szMsgTP,"saps.368")||NULL != strstr(szMsgTP,"saps.369")||
            NULL != strstr(szMsgTP,"saps.370")||NULL != strstr(szMsgTP,"saps.371")||
            NULL != strstr(szMsgTP,"saps.373")||NULL != strstr(szMsgTP,"saps.374")||
            NULL != strstr(szMsgTP,"saps.375")||NULL != strstr(szMsgTP,"saps.614")||
            NULL != strstr(szMsgTP,"saps.615")||NULL != strstr(szMsgTP,"saps.731")||
            NULL != strstr(szMsgTP,"ccms.303")||NULL != strstr(szMsgTP,"ccms.903")||
            NULL != strstr(szMsgTP,"ccms.919")||NULL != strstr(szMsgTP,"ccms.990")||
            NULL != strstr(szMsgTP,"ccms.991"))
         {
             return 0;
         }
         else
         {
             sprintf(sErrorDesc, "营业准备期间不能发送msgtp [%s]", sMsgTp);  
             Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);
             return 1;
         }
     
     }
     else if(0 == strcmp(oBpsapbankinfo.m_sysstate.c_str(),"10"))//系统状态:日间
     {
         if(NULL != strstr(szMsgTP,"saps.737"))
          {
             sprintf(sErrorDesc, "日间系统状态不能发送msgtp [%s]", sMsgTp);  
             Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);
             return 1;
          }
          else
          {
              return 0;
          }
     
     }
     else if(0 == strcmp(oBpsapbankinfo.m_sysstate.c_str(),"20"))//系统状态:业务截止
     {
         if(NULL != strstr(szMsgTP,"ccms.990")||NULL != strstr(szMsgTP,"ccms.991"))
          {
    
             return 0;
    
          }
          else
          {
              sprintf(sErrorDesc, "日间系统状态不能发送msgtp [%s]", sMsgTp);  
              Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);
              return 1;
          }
     
     }
     else if(0 == strcmp(oBpsapbankinfo.m_sysstate.c_str(),"30"))//系统状态:清算窗口
     {
         if(NULL != strstr(szMsgTP,"saps.357")||NULL != strstr(szMsgTP,"saps.358")||
            NULL != strstr(szMsgTP,"saps.363")||NULL != strstr(szMsgTP,"saps.365")||
            NULL != strstr(szMsgTP,"saps.366")||NULL != strstr(szMsgTP,"saps.368")||
            NULL != strstr(szMsgTP,"saps.369")||NULL != strstr(szMsgTP,"saps.609")||
            NULL != strstr(szMsgTP,"saps.611")||NULL != strstr(szMsgTP,"saps.612")||
            NULL != strstr(szMsgTP,"saps.613")||NULL != strstr(szMsgTP,"saps.614")||
            NULL != strstr(szMsgTP,"saps.615")||NULL != strstr(szMsgTP,"ccms.303")||
            NULL != strstr(szMsgTP,"ccms.307")||NULL != strstr(szMsgTP,"ccms.308")||
            NULL != strstr(szMsgTP,"ccms.990")||NULL != strstr(szMsgTP,"ccms.991"))
         {
             return 0;
         }
         else
         {
             sprintf(sErrorDesc, "营业准备期间不能发送msgtp [%s]", sMsgTp);  
             Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);
             return 1;
         }
     
     }
     else if(0 == strcmp(oBpsapbankinfo.m_sysstate.c_str(),"03"))//系统状态:停运
     {
     
         if(NULL != strstr(szMsgTP,"ccms.303")||NULL != strstr(szMsgTP,"ccms.990")||
            NULL != strstr(szMsgTP,"ccms.991"))
          {
         
             return 0;
         
          }
          else
          {
              sprintf(sErrorDesc, "日间系统状态不能发送msgtp [%s]", sMsgTp);  
              Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);
              return 1;
          }
     }
     else
     {
         sprintf(sErrorDesc, "系统状态未知[%s]", oBpsapbankinfo.m_sysstate.c_str());  
         Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrorDesc);
         return FAILED;
     }

	return SUCCESSED;
}

/******************************************************************************
*  Function:    chgSysCd
*  Description: 转换系统编号(人行-->本地)
*  Input:       sNpcCd：  人行系统编号
*  Output:      sLocalCd：本地系统编号
*  Return:      
*  Others:
*  Author:      hq
*  Date:        2011-04-28
*******************************************************************************/
int chgSysCd(const char* sNpcCd, int &sLocalCd)
{
    string strSysCd;

    strSysCd = sNpcCd;
    Upper(strSysCd);
    
    if ( strSysCd == "HVPS" )
	{
		sLocalCd = SYS_HVPS;
	}
	else if ( strSysCd == "BEPS" )
	{
		sLocalCd = SYS_BEPS;
	}
	else if ( strSysCd == "IBPS" )
	{
		sLocalCd = SYS_IBPS;
	}
	else
	{
		sLocalCd = SYS_PUBS;
	}

    return SUCCESSED;
}

/******************************************************************************
*  Function:    NotifyOprUser
*  Description: 写客户信息通知表
*  Input:       sQueNm:MQ队列名称
				sLevel:通知级别(0: 系统异常、1: 应用异常、2: 重要信息、3: 普通信息)
				sMsgid:报文标识
				sSendBank:发起行行号
				sSysflg:系统编号(HVPS: 大额 BEPS:小额)
				sMsyTp:报文类型
                sRecvBank:接收行行号
                sRecvBank:接收清算行行号
                sSndSapBank:发起清算行行号
                sTellMsg:通知信息
*  Output:      
*  Return:      0:成功,其他:失败
*  Others:
*  Author:      hq
*  Date:        2011-05-09
*******************************************************************************/
int NotifyOprUser(DBProc &dbproc,
				  MQAgent &oMqAgent,
				  LPCSTR sQueNm,
			      LPCSTR sMsgid,
			      LPCSTR sSendBank,
			      LPCSTR sSndSapBank,
			      LPCSTR sRecvBank,
			      LPCSTR sRcvSapBank,
			      LPCSTR sSysflg,
			      LPCSTR sMsyTp,			      			     			      
				  LPCSTR sLevel,
				  LPCSTR sTellMsg)
{
	if(NULL == sQueNm || NULL == sMsgid || NULL == sSendBank || 
	   NULL == sSysflg || NULL == sMsyTp || NULL == sRecvBank || 
	   NULL == sRcvSapBank || NULL == sSndSapBank || 
	   NULL == sLevel || NULL == sTellMsg )
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "传入参错误！");
		return -1;
	}
	
    CSysrecvmsgtel oSysrecvmsgtel(dbproc);
    
	oSysrecvmsgtel.m_telmsg = sTellMsg;// 
	//oSysrecvmsgtel.m_readtime = ;//
	//oSysrecvmsgtel.m_readuser = ;//
	oSysrecvmsgtel.m_readflag = "0";//
	oSysrecvmsgtel.m_tellevel = sLevel;//
	oSysrecvmsgtel.m_recvsapbk = sRcvSapBank;
	oSysrecvmsgtel.m_recvbank = sRecvBank;//
	oSysrecvmsgtel.m_sendsapbk = sSndSapBank;
	oSysrecvmsgtel.m_msgtp = sMsyTp;//  
	oSysrecvmsgtel.m_sysflag = sSysflg;//
	oSysrecvmsgtel.m_sendbank = sSendBank;//
	oSysrecvmsgtel.m_msgid = sMsgid;//  
  
    int iRet = oSysrecvmsgtel.insert();
    if (SQL_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "写客户信息通知表失败[%d][%s]",
            iRet, oSysrecvmsgtel.GetSqlErr());
        return iRet; 
    }
    
    if(0 == strcmp(NT_MAJOR,sLevel))//重要级别消息写MQ
	{
		char szMsg[256] = {0};
		sprintf(szMsg,"%-35s%-14s%-4s%-20s",sMsgid,sSendBank,sSysflg,sMsyTp);
	    iRet = oMqAgent.PutMsg(sQueNm, szMsg, strlen(szMsg));
	    if(iRet != RTN_SUCCESS)
		{		
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "往MQ发送消息失败[%d][%s]！",iRet,sQueNm);
			return -1;
		}
		
	}
    return iRet;
}

/******************************************************************************
*  Function:   PriorityExchange
*  Description:转换一二代业务优先级
*  Input:      szPriority 原业务优先级
*  Input:      iVersion 一二代版本
*  			   
*  Output:	   szPriority 转换后业务优先级
*  Return:     操作结果：true操作成功,false操作失败
*  Others:     无
*  Author:     zwy
*  Date:       2010-04-10
*******************************************************************************/
int PriorityExchange(char *szPriority, int iVersion)
{
	//Priority
	enum EPriority
	{
	    E_PRIORITY_NORM = 0,
	    E_PRIORITY_HIGH = 1,
	    E_PRIORITY_URGT = 2
	};
	
	int iPriority = -1;
	int iRet = -1;
	char szPriorityType[4+1] = {0};
	
	strcpy(szPriorityType, szPriority);
	
	iPriority = atoi(szPriority);
	
	if(1 == iVersion)
	{
		if(0 == strcmp(szPriorityType, "NORM"))
		{
			strcpy(szPriority, "0");
			iRet = 0;
		}
		else if(0 == strcmp(szPriorityType, "HIGH"))
		{
			strcpy(szPriority, "1");
			iRet = 0;
		}
		else if(0 == strcmp(szPriorityType, "URGT"))
		{
			strcpy(szPriority, "2");
			iRet = 0;
		}
		else
		{
			Trace(L_INFO, __FILE__, __LINE__, NULL, "checkSignDetached exit.");
			iRet = -1;
		}
	}
	else if(2 == iVersion)
	{
		switch(iPriority)
		{
			case E_PRIORITY_NORM:
				strcpy(szPriority, "NORM");
				iRet = 0;
				break;
			case E_PRIORITY_HIGH:
				strcpy(szPriority, "HIGH");
				iRet = 0;
				break;
			case E_PRIORITY_URGT:
				strcpy(szPriority, "URGT");
				iRet = 0;
				break;
			default:
				iRet = -1;
				break;
		}
	}
	else
	{
		iRet = -1;
	}
	
	return iRet;
}

/******************************************************************************
*  Function:   textBase64Encode
*  Description:对输入串进行base64编码
*  Input:      sOrigenStr 输入串
*  Output:	   sBase64Str 编码后的串
*  Return:     无 
*  Others:     无
*  Author:     zwy
*  Date:       2010-07-20
*******************************************************************************/
void textBase64Encode(const char * sOrigenStr,char * sBase64Str)
{
    /*
    unsigned char szTmp[1024 * 10] = {0};
    buffer_struct buffer;
    buffer.length = 0;
    buffer.szBuf = szTmp;
    printf("ļʼ\n");
    long i = ReadFile("./cnaps2.pfx", &buffer);
    printf("ļ i[%f]\n", i);
    
    printf("ļת64뿪ʼ\n");
    char szEn64[1024 * 10] = {0};
    int ii = base64_encode(buffer.szBuf, buffer.length, szEn64);
    printf("ļת64 ii[%d]  szEn64[%s]\n", ii, szEn64);
    
    printf("des뿪ʼ\n");
    char szDes[1024] = {0};
    desEncode("hdf", "BOCHKcnaps2", szDes);
    printf("des szDes[%s]\n", szDes);     
    */

	//base64_encode((unsigned char *)sOrigenStr,strlen(sOrigenStr),sBase64Str);
}


/******************************************************************************
*  Function:   textBase64Decode
*  Description:对输入串进行base64解码
*  Input:      sBase64Str 输入串
*  Output:	   sDecodeStr 解码后的串
*  Return:     无 
*  Others:     无
*  Author:     zwy
*  Date:       2010-07-20
*******************************************************************************/
void textBase64Decode(const char * sBase64Str,char * sDecodeStr)
{
	unsigned long outlen = 0;
	
	base64_decode(sBase64Str,(unsigned char *)sDecodeStr,&outlen);
}

/******************************************************************************
*  Function:   textBase64Decode
*  Description:对输入串进行base64解码
*  Input:      sBase64Str 输入串
*  Output:	   szDecodeStr 解码后的串
*  Return:     无 
*  Others:     无
*  Author:     zwy
*  Date:       2010-07-20
*******************************************************************************/
string textBase64Decode(const char * sBase64Str,string & szDecodeStr)
{
	int iLen = strlen(sBase64Str);
	
	char * sDecodeStr = new char[iLen];
	
	memset(sDecodeStr,'\0',iLen);
	
	unsigned long outlen = 0;
	
	base64_decode(sBase64Str,(unsigned char *)sDecodeStr,&outlen);
	
	szDecodeStr = sDecodeStr;
	
	delete [] sDecodeStr;
	
	return szDecodeStr;
	
}

// 将一串char字符串转化成hex字符串
string MbBinToHex(unsigned char* sInpStr,int nSize)
{

    char chHi;
    char chLo;
    char * pStr = new char[nSize*2 + 1];   
    memset(pStr, 0,nSize *2 +1); 
    for(int nIndex =0;nIndex < nSize; nIndex ++)
    {
        chHi = (sInpStr[nIndex] >> 4) & 0x0F;
        chLo = (sInpStr[nIndex] & 0x0F);
        if(chHi>9) chHi = 'A' + chHi - 10; else chHi = '0' + chHi;
        if(chLo>9) chLo = 'A' + chLo - 10; else chLo = '0' + chLo;
        *(pStr + 2*nIndex)    = chHi;
        *(pStr + 2*nIndex +1) = chLo;
    }
    
    string strRet = pStr;
    if(pStr)
	{
		delete[] pStr;
	}
    return strRet;
}


// 恢复二进制串
void HexToBin(char* sInpStr,unsigned char * sOutStr,int * nSize)
{
    char chHi;
    char chLo;
    int nMaxSize = strlen(sInpStr)>>1;
    if(nSize!=NULL) (* nSize) = nMaxSize;
    memset(sOutStr,0,nMaxSize);
    for(int nIndex=0;nIndex < nMaxSize; nIndex ++)
    {
        chHi = sInpStr[nIndex *2];
        chLo = sInpStr[nIndex *2 +1];
        
        if      (chHi> 0x2F && chHi < 0x3A) chHi = chHi - '0';       // 0x30='0',0x39='9'
        else if (chHi> 0x40 && chHi < 0x5B) chHi = chHi - 'A' + 10;  // 0x41='A',0x5A='Z'
        else if (chHi> 0x60 && chHi < 0x7B) chHi = chHi - 'a' + 10;  // 0x61='a',0x7A='z'
        else     chHi = 0;

        if      (chLo> 0x2F && chLo < 0x3A) chLo = chLo - '0';       // 0x30='0',0x39='9'
        else if (chLo> 0x40 && chLo < 0x5B) chLo = chLo - 'A' + 10;  // 0x41='A',0x5A='Z'
        else if (chLo> 0x60 && chLo < 0x7B) chLo = chLo - 'a' + 10;  // 0x61='a',0x7A='z'
        else     chLo = 0;

        *(sOutStr + nIndex) = (chHi<<4) | chLo;
    }
}




/*base64编码函数*/
int base64_encode(unsigned char * bin_data, unsigned long bin_size,char * base64_data)
{

    unsigned long i,j,k,blk_size,remain_size;

    unsigned char *p, left[3];

	if (bin_data == NULL) {

		return -1;

	}

	

    blk_size = bin_size / 3;

    remain_size = bin_size % 3;

	

    p = bin_data;

    j = 0;

	

    for(i=0;i<blk_size;i++){

        k = (p[0] & 0xFC) >> 2;

        base64_data[j++] = base64_table[k];

        k = ((p[0] & 0x03) << 4) | (p[1] >> 4);

        base64_data[j++] = base64_table[k];

        k = ((p[1] & 0x0F) << 2) | (p[2] >> 6);

        base64_data[j++] = base64_table[k];

        k = p[2] & 0x3F;

        base64_data[j++] = base64_table[k];

        p += 3;

    }

	

    switch(remain_size){

	case 0:

		break;

		

	case 1:

		left[0] = p[0];

		left[1] = 0;

		p = left;

		

		k = (p[0] & 0xFC) >> 2;

		base64_data[j++] = base64_table[k];

		k = ((p[0] & 0x03) << 4) | (p[1] >> 4);

		base64_data[j++] = base64_table[k];

		

		base64_data[j++] = '=';

		base64_data[j++] = '=';

		break;

		

	case 2:

		left[0] = p[0];

		left[1] = p[1];

		left[2] = 0;

		p = left;

		

		k = (p[0] & 0xFC) >> 2;

		base64_data[j++] = base64_table[k];

		k = ((p[0] & 0x03) << 4) | (p[1] >> 4);

		base64_data[j++] = base64_table[k];

		k = ((p[1] & 0x0F) << 2) | (p[2] >> 6);

		base64_data[j++] = base64_table[k];

		base64_data[j++] = '=';

		break;

		

	default:

		break;

    }

	

    base64_data[j] = 0;

    return 0;

}



/*base64解码函数*/
int base64_decode(const char * base64_data,unsigned char * bin_data, unsigned long * bin_size)
{

    unsigned long i,j,k,m,n,l;

    unsigned char four_bin[4];

    char four_char[4],c;

	

	if (base64_data == NULL) {

		return -1;

	}

	

    j = strlen(base64_data);

    i = 0;

    l = 0;

    

    for(;;){

        if((i+4) > j){

            break;

        }

		

        for(k=0;k<4;k++){

            if(i == j){

                break;

            }

			

          c = base64_data[i++];

            if((c == '+') || (c == '/') || (c == '=') ||

				((c >= '0') && (c <= '9')) ||

				((c >= 'A') && (c <= 'Z')) ||

				((c >= 'a') && (c <= 'z'))){

				four_char[k] = c;

            }

        }

		

        if(k != 4){

			return -1;

        }

		

        n = 0;

        for(k=0;k<4;k++){

            if(four_char[k] != '='){

                for(m=0;m<64;m++){

                    if(base64_table[m] == four_char[k]){

                        four_bin[k] = (unsigned char)m;

                    }

                }

            }

            else{

                n++;

            }

        }

		

        switch(n){

		case 0:

			bin_data[l++] = (four_bin[0] << 2) | (four_bin[1] >> 4);

			bin_data[l++] = (four_bin[1] << 4) | (four_bin[2] >> 2);

			bin_data[l++] = (four_bin[2] << 6) | four_bin[3]; 

			break;

			

		case 1:

			bin_data[l++] = (four_bin[0] << 2) | (four_bin[1] >> 4);

			bin_data[l++] = (four_bin[1] << 4) | (four_bin[2] >> 2);

			break;

			

		case 2:

			bin_data[l++] = (four_bin[0] << 2) | (four_bin[1] >> 4);

			break;

			

		default:

			break;

        }

		

        if(n != 0){

            break;

        }

    }

	

    /*l++;*/

    *bin_size = l;

	

    return 0;

}
/******************************************************************************
*  Function:   CodeMac
*  Description:一代报文加押凼数(南洋专用)
*  Input:      pCodeStr 加押串
*              pSendSapBank  发起清算行
*  Output:     成功：pMacStr 经加押后的密押串；失败：pMacStr 为错误信息
*  Return:     0：   成功
*              其他：失败
*  Others:     无
*  Author:     aps-lel
*  Date:       2012-02-16
*******************************************************************************/

int CodeMac(DBProc &dbproc,const char *pAddStr ,const char *bank,char *pMacStr)
{
    char szReturn_Code  = 0x00  ;
    int iResult         = 0     ;
    char szAddStr[1024]= { 0 };
    char szOldMacIndex[8 + 1] = { 0 };
    char szNewMacIndex[8 + 1] = { 0 };
    char szMacALG[8 + 1]      = { 0 };
    //从数据库中获取索引参数
    int iRet = GetSysParam(dbproc,"24", szOldMacIndex);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"获取系统参数[23]失败");

        return iRet;
    }
    iRet = GetSysParam(dbproc,"25", szNewMacIndex);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"获取系统参数[24]失败");

        return iRet;
    }
    iRet = GetSysParam(dbproc,"26", szMacALG);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"获取系统参数[25]失败");

        return iRet;
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
        "szOldMacIndex = [%s], szNewMacIndex = [%s], szMacALG = [%s]", 
        szOldMacIndex, szNewMacIndex, szMacALG);
    
    strncpy(szAddStr, pAddStr, sizeof(szAddStr) - 1);
    //strncpy(szAddStr, "123", sizeof(szAddStr) - 1);
    
    CMac Mac(szAddStr);
    
    //索引号赋值
    Mac.SetMacInfo(atoi(szOldMacIndex), atoi(szNewMacIndex), szMacALG);
    
    iResult = Mac.AddMac(pMacStr, &szReturn_Code);
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "szAddStr     = [%s]", szAddStr );
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "pMacStr      = [%s]", pMacStr    );
    return iResult;
}

int CodeMac(DBProc &dbproc,const char *pAddStr ,char *pMacStr)
{
    char szReturn_Code  = 0x00  ;
    int iResult         = 0     ;
    char szAddStr[1024]= { 0 };
    char szOldMacIndex[8 + 1] = { 0 };
    char szNewMacIndex[8 + 1] = { 0 };
    char szMacALG[8 + 1]      = { 0 };
    //从数据库中获取索引参数
    int iRet = GetSysParam(dbproc,"24", szOldMacIndex);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"获取系统参数[23]失败");

        return iRet;
    }
    iRet = GetSysParam(dbproc,"25", szNewMacIndex);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"获取系统参数[24]失败");

        return iRet;
    }
    iRet = GetSysParam(dbproc,"26", szMacALG);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"获取系统参数[25]失败");

        return iRet;
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
        "szOldMacIndex = [%s], szNewMacIndex = [%s], szMacALG = [%s]", 
        szOldMacIndex, szNewMacIndex, szMacALG);
    
    strncpy(szAddStr, pAddStr, sizeof(szAddStr) - 1);
    //strncpy(szAddStr, "123", sizeof(szAddStr) - 1);
    
    CMac Mac(szAddStr);
    //CMac Mac("abcdefghijklmn1234567890");

    //索引号赋值
    Mac.SetMacInfo(atoi(szOldMacIndex), atoi(szNewMacIndex), szMacALG);
    
    iResult = Mac.AddMac(pMacStr, &szReturn_Code);
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "szAddStr     = [%s]", szAddStr );
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "pMacStr      = [%s]", pMacStr    );
    return iResult;
}

/******************************************************************************
*  Function:   ConnAppMac
*  Description:一代连接加押服务端凼数(南洋专用)
*  Input:      pInStr 加押串
*              pMacIp  mac服务端ip
               iPort mac服务端端口
*  Output:     pOutStr 经加押后的密押串
*  Return:     0：   成功
*              其他：失败
*  Others:     无
*  Author:     aps-lel
*  Date:       2012-02-16
*******************************************************************************/
int ConnAppMac(DBProc &dbproc,char *szInstr,const char* pMacIp,int iPort,char *pOutStr)
{
	if(NULL == szInstr || NULL == pMacIp)
	{
		return -1;
	}
	int iMsgLen = 0;
	
	TSocketClient tClnt;
	char szIp[32] = {0};
	strcpy(szIp,pMacIp);

	int iSocketid = tClnt.connectServer(szIp,iPort);
	
	if(iSocketid < 1)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "连接服务端socket失败ip[%s][%d]",szIp, iSocketid);	
		return -1;
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%d][%s]" ,strlen(szInstr), szInstr);
	if(!tClnt.sendMsg(szInstr))
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "发往macApp消息失败");

		return -1;
	}

	if(1 != tClnt.recvMsg(pOutStr))
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "接收macApp回应消息失败");
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "返回消息[%s]",pOutStr);
		return -1;
	}

	return 0;
}

/******************************************************************************
*  Function:   ChecKMac
*  Description:一代报文核押凼数(南洋专用)
*  Input:      pCheckStr 加押串
*              pRefStr   20位密押参考值
               pSendSapBank 发起清算行号
*  Return:     0：   成功
*              其他：失败
*  Others:     无
*  Author:     aps-lel
*  Date:       2012-02-16
*******************************************************************************/
int CheckMac(DBProc &dbproc,const char *pRefStr, const char *pCheckStr,const char *bank )
{
	
    char szReturn_Code      = 0x00  ;
    int iResult             = 0     ;
    char szCheckStr[1024]   = { 0 } ;
    char szPaySeal[60]      = { 0 } ;
    char szOldMacIndex[8 + 1] = { 0 };
    char szNewMacIndex[8 + 1] = { 0 };
    char szMacALG[8 + 1]      = { 0 };

    return 0;
    int iRet = GetSysParam(dbproc,"24", szOldMacIndex);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"获取系统参数[23]失败");

        return iRet;
    }
    iRet = GetSysParam(dbproc,"25", szNewMacIndex);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"获取系统参数[24]失败");

        return iRet;
    }
    iRet = GetSysParam(dbproc,"26", szMacALG);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"获取系统参数[25]失败");

        return iRet;
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
        "szOldMacIndex = [%s], szNewMacIndex = [%s], szMacALG = [%s]", 
        szOldMacIndex, szNewMacIndex, szMacALG);
    
    strncpy(szCheckStr  , pCheckStr, sizeof(szCheckStr ) - 1);
    strncpy(szPaySeal   , pRefStr  , sizeof(szPaySeal  ) - 1);
    
    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "szCheckStr   = [%s]", szCheckStr );
    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "szPaySeal    = [%s]", szPaySeal  );
    
    CMac Mac(szCheckStr,szPaySeal);
    
    //索引号赋值
    Mac.SetMacInfo(atoi(szOldMacIndex), atoi(szNewMacIndex), szMacALG);
    
    iResult = Mac.CheckMac(&szReturn_Code);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Return_Code    = [%s]", szReturn_Code  );

    return iResult;
}

int CheckMac(DBProc &dbproc,const char *pRefStr, const char *pCheckStr )
{
	
    char szReturn_Code      = 0x00  ;
    int iResult             = 0     ;
    char szCheckStr[1024]   = { 0 } ;
    char szPaySeal[60]      = { 0 } ;
    char szOldMacIndex[8 + 1] = { 0 };
    char szNewMacIndex[8 + 1] = { 0 };
    char szMacALG[8 + 1]      = { 0 };

    int iRet = GetSysParam(dbproc,"24", szOldMacIndex);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"获取系统参数[23]失败");

        return iRet;
    }
    iRet = GetSysParam(dbproc,"25", szNewMacIndex);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"获取系统参数[24]失败");

        return iRet;
    }
    iRet = GetSysParam(dbproc,"26", szMacALG);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,"获取系统参数[25]失败");

        return iRet;
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
        "szOldMacIndex = [%s], szNewMacIndex = [%s], szMacALG = [%s]", 
        szOldMacIndex, szNewMacIndex, szMacALG);
    
    strncpy(szCheckStr  , pCheckStr, sizeof(szCheckStr ) - 1);
    strncpy(szPaySeal   , pRefStr  , sizeof(szPaySeal  ) - 1);
    
    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "szCheckStr   = [%s]", szCheckStr );
    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "szPaySeal    = [%s]", szPaySeal  );
    
    CMac Mac(szCheckStr,szPaySeal);
    
    //索引号赋值
    Mac.SetMacInfo(atoi(szOldMacIndex), atoi(szNewMacIndex), szMacALG);
    
    iResult = Mac.CheckMac(&szReturn_Code);
    return iResult;
}
/******************************************************************************
*  Function:   changISODT
*  Description:转换ISO日期
*  Input:      sISODateTime 日期串指针
*  Output:     sDateTime 标准日期时间:YYYY-MM-DD HH:mm:SS
*  Return:     无
*  Others:     无
*  Author:     zj
*  Date:       2010-06-17
*******************************************************************************/
void changISODT(const char * sISODateTime, char * sDateTime)
{
	if(NULL == sISODateTime || 0 == strlen(sISODateTime) )
		return;
	
	char sCreDtTm[20] = { 0 };
	
	memcpy(sCreDtTm, sISODateTime, strlen(sISODateTime));
	
	char *pDT = strchr(sCreDtTm, 'T');	
	int iDateLen = strlen(sCreDtTm) - strlen(pDT);
	
	memcpy(sDateTime, sCreDtTm, iDateLen);	
	memcpy(sDateTime + iDateLen, " ", 1);
	memcpy(sDateTime + iDateLen + 1, pDT + 1, strlen(pDT) - 1);
}

void SetGbkToUtf8(char* _in, string& _out)
{
    if(_in == NULL){
        return;
    }
    
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "_in=[%s]", _in);
    int iLen = strlen(_in);
    //if( !IsUTF8(_in, iLen) ){
    if( 1 ){
    	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__not utf8[%d]!!!", iLen);
        char* pBuffer = new char[iLen*3+1];
        memset(pBuffer, 0x00, iLen*3+1);
        if(!changeEncode(_in, pBuffer, "GB18030", "UTF-8")){
        	Trace(L_ERROR, __FILE__, __LINE__,
        			NULL, "GB18030->UTF-8 Failed!");
        	if(!changeEncode(_in, pBuffer, "GBK", "UTF-8")){
				Trace(L_ERROR, __FILE__, __LINE__,
						NULL, "GBK->UTF-8 Failed!");
			}
        }
        _out = pBuffer;
        delete[] pBuffer;
        pBuffer = NULL;
    }
    else{
        _out = _in;
    }
} 


void GetSysparm(DBProc &dbproc,const char* sCode ,char* sValues)
{
	int iRet;
	char sTemp[300];
	memset(sTemp,0x00,sizeof(sTemp));
	
	CSyssysparm m_CSyssysparm(dbproc);
		
	m_CSyssysparm.m_code=sCode;
	iRet = m_CSyssysparm.findByPK();
	if(iRet < 0)
	{
		sprintf(sTemp,"m_CSyssysparȡϵͳ²ϊ�§°ڬiRet=[%d]",sCode,iRet);
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "%s",sTemp);
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "ȡϵͳ²ϊ�¡");
    }
    if(iRet == 1403)
    {
    	sprintf(sTemp,"m_CSyssysparȡϵͳ²ϊ�§°ڬiRet=[%d],sCode=[%s]²»´畚!",sCode,iRet,sCode);
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "%s",sTemp);
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "ȡϵͳ²ϊ�¡");
    }
    else
    {
    	strcpy(sValues,m_CSyssysparm.m_parmvalue.c_str());
    }
}

