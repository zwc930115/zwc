/******************************************************************** 
文件名： sendxmlpack.cpp
创建人： zhj
日  期   ： 2011-04-11
修改人： 
日  期： 
描  述：    XML打包处理类 
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendxmlpack.h"

#include "pubfunc.h"
#include "exception.h"
#include "logger.h"

#include "beps121.h"
#include "beps122.h"
#include "beps123.h"
#include "beps125.h"
#include "beps127.h"
#include "beps128.h"
#include "beps130.h"
#include "beps133.h"
#include "beps134.h"
#include "bppkgassist.h"
#include "bpbcoutsendlist.h"
#include "bpbdsendlist.h"


using namespace ZFPT;

extern CConnectPool			*g_DBConnPool;

extern char					g_MQmgr[256];
extern char					g_MqTxtPath[256];
extern char					g_SendQueue[128];


string XMLGetTag2ND(const string& QryVal, const string& QryStr, int& iDepth, PMTSMsgBase* Base)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendXmlPack::XMLGetTag2ND...");
    string strTemp = "";
    
    if(RTN_SUCCESS == GetTagVal(strTemp, QryStr, QryVal))
    { 
        strTemp = QryVal + strTemp;
        Base->SetUstrd(iDepth, strTemp.c_str());
    	printf("Ustrd[%d]=[%s]\n",iDepth,strTemp.c_str());
        iDepth++;
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendXmlPack::XMLGetTag2ND...");
    return strTemp;
}

string XMLGetTag2ND_plus(const string& QryVal, const string& QryStr, int& iDepth, PMTSMsgBase* Base)
{
	string strTemp;
	string strVal = "";
	if(RTN_SUCCESS == GetTagVal(strTemp, QryStr, QryVal))
	{
		strVal = strTemp;
		strTemp = QryVal + strTemp;
		Base->SetUstrd(iDepth, strTemp.c_str());
		iDepth++;
	}
	return strVal;
}

int CSendXmlPack::AddSign( PMTSMsgBase &oMsgBase, const char *pSapSendBank, int iFlag)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendXmlPack::AddSign...");
    
    oMsgBase.getOriSignStr();//获取加签串
    
    string strSign = oMsgBase.m_sSignBuff;
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "strOriSign = [%s]", strSign.c_str());
    
    char *pStr = new char[strlen(strSign.c_str()) + 1];
    strcpy(pStr, strSign.c_str());
    
    char szDstSign[4096 + 1]= {0};
    
    int iRet = digitSign(m_dbproc, signTrim(pStr), szDstSign, SYS_BEPS, iFlag, pSapSendBank);
    if(NULL != pStr)
    {
		delete []pStr;
		pStr = NULL;    
    }
	if( RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "数字签名加签失败");
		PMTS_ThrowException(OPT_DIGITSIGN_FAIL);
	}
	
	oMsgBase.m_szDigitSign = szDstSign; //
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendXmlPack::AddSign...");
    
    return RTN_SUCCESS;
}	

CSendXmlPack::CSendXmlPack()
{
	memset(m_szErrMsg, 0, sizeof(m_szErrMsg));
	memset(m_sWorkDate, 0, sizeof(m_sWorkDate));
	memset(m_sIsoWorkDate, 0, sizeof(m_sIsoWorkDate));
	memset(m_sMsgRefId, 0, sizeof(m_sMsgRefId));
	
	m_strWrkDate	= "";
	m_strSendBank	= "";
	m_strRecvBank	= "";
	m_strMsgType	= "";
	m_strMsgID		= "";
	m_strMsgTxt		= "";

	m_iMsgNo		= 0 ;
}

CSendXmlPack::~CSendXmlPack()
{
}

void CSendXmlPack::setData(stPkgTab &_PkgTab)
{
	char sMsgNo[3 + 1] = { 0 };

	memcpy(&m_stPkgTab, &_PkgTab, sizeof(m_stPkgTab));
	
    m_strWrkDate	= m_stPkgTab.szWrkDate;     //工作日期
	m_strSendBank	= m_stPkgTab.szSendBank;    //发起清算行
	m_strRecvBank	= m_stPkgTab.szRecvBank;    //接收清算行
	m_strMsgType	= m_stPkgTab.szMsgType;     //报文类型
	m_strMsgID		= m_stPkgTab.szMsgID;       //报文标识号
	
	memcpy(sMsgNo, m_stPkgTab.szMsgType + 5, sizeof(sMsgNo) - 1);
	m_iMsgNo = atoi(sMsgNo);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strWrkDate  =[%s]", m_strWrkDate .c_str()	);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strSendBank =[%s]", m_strSendBank.c_str()  );
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strRecvBank =[%s]", m_strRecvBank.c_str()  );
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgType  =[%s]", m_strMsgType .c_str()  );
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgID    =[%s]", m_strMsgID	  .c_str()  );
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_iMsgNo      =[%d]", m_iMsgNo               );
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iPKGRtrltd    =[%d]", m_stPkgTab.iPKGRtrltd  );
}

INT32 CSendXmlPack::Work()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendXmlPack::Work()");	

	int iRet = RTN_FAIL;
	
    try
    {	
    	//获取MQ连接
    	GetMqConn();
			
        //获取数据库连接
        GetDBConnect();

		//Init
		InitSysParam();
		
		//业务处理
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_iMsgNo = %d",m_iMsgNo);	
		switch(m_iMsgNo)
	    {
	        case 121:
	        {
				PackXml121();
	            break;
	        }
	        case 122:
	        {
				PackXml122();
	            break;
	        }
			case 125:
	        {
				PackXml125();
	            break;
	        }
	        case 127:
	        {
				PackXml127();
	            break;
	        }
	        case 128:
	        {
				PackXml128();
	            break;
	        }
			case 130:
	        {
				PackXml130();
	            break;
	        } 
			case 133:
	        {
				PackXml133();
	            break;
	        } 
			case 134:
	        {
				PackXml134();
	            break;
	        } 
	        default:
	            return RTN_FAIL;
	    }

		//put MQ
		SendMsgToMQ();

		//更新打包辅助表处理状态为"04: 已打包"
		UpdPkgAssistState(PR_PACK_04);

		m_cCCmcomsend.setctx(m_dbproc);
		m_cCCmcomsend.commit();
		
        //释放连接
        g_DBConnPool->PutConnect(m_dbproc);	
		
		m_cMQAgent.Commit();

    }
    catch(CException &e)
    {        
        Trace(L_ERROR, __FILE__, __LINE__, NULL, 
            "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());

		//数据库事物回滚
		m_cCCmcomsend.setctx(m_dbproc);
		m_cCCmcomsend.rollback();

		// 释放连接
        g_DBConnPool->PutConnect(m_dbproc);

		//MQ事物回滚
		m_cMQAgent.RollBack();
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendXmlPack::Work()");	

    return 0;
}


void CSendXmlPack::GetMqConn(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendXmlPack::GetMqConn()");	

	//初始化MQ
    if(0 != m_cMQAgent.Init(g_MQmgr, g_MqTxtPath))
    {
    	snprintf(m_szErrMsg, sizeof(m_szErrMsg), 
			"CSendXmlPack::GetMqConn(),Init Thread MQ manager failed.");
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		
        PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_MQ_CNNCT_FAIL, m_szErrMsg);
    }
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendXmlPack::GetMqConn()");		
}


/******************************************************************************
*  Function:   GetDBConnect
*  Description:获取数据库连接
*  Input:      无
*  Output:     无
*  Return:     无
*  Others:     无
*  Author:     zys
*  Date:       2011-03-01
*******************************************************************************/
void CSendXmlPack::GetDBConnect(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendXmlPack::GetDBConnect()");	

    if(0 != g_DBConnPool->GetConnect(m_dbproc))
    {
        snprintf(m_szErrMsg, sizeof(m_szErrMsg), 
			"CSendXmlPack::GetDBConnect():获取数据库连接失败");
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, m_szErrMsg);
    }
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendXmlPack::GetDBConnect()");		
}


void CSendXmlPack::InitSysParam()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendXmlPack::InitSysParam()");

	if ( 0 != GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS, m_strSendBank.c_str()) )
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "取工作日期失败");
        PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "取工作日期失败");
	}
	
	if ( 0 != GetIsoDateTime(m_dbproc, SYS_BEPS, m_sIsoWorkDate) )
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "取系统时间失败");
        PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "取系统时间失败");
	}
	
	if ( !GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS, m_strSendBank.c_str()) )
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "取报文参考号失败");
        PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "取报文参考号失败");
	}
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendXmlPack::InitSysParam()");
}

void CSendXmlPack::SendMsgToMQ()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendXmlPack::AddQueue()");

	int iRet = -1;

	if(m_strMsgTxt == "")
	{

		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_strMsgTxt is NULL");
		PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "m_strMsgTxt is NULL");
	}
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "xmlmsg = %s",m_strMsgTxt.c_str());
    iRet = m_cMQAgent.PutMsg(g_SendQueue, m_strMsgTxt.c_str(), m_strMsgTxt.length(), NULL, NULL);
	if(0 != iRet)
	{

		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "向远程队列[%s]发送往账报文[%s]失败", 
												g_SendQueue, m_strMsgID.c_str());
		
		//写往NPC通讯表
		m_cCCmcomsend.setctx(m_dbproc);

		m_cCCmcomsend.m_syscode	 	= "BEPS" ;
		m_cCCmcomsend.m_wrkdate		= m_sWorkDate ;
		m_cCCmcomsend.m_msgtp       = m_strMsgType  ;
		m_cCCmcomsend.m_sendbankcode= m_strSendBank ;
		m_cCCmcomsend.m_msgid		= m_strMsgID ;
		m_cCCmcomsend.m_recvbankcode= m_strRecvBank ;
		m_cCCmcomsend.m_msglevel	= "2" ;
		m_cCCmcomsend.m_msgtext		= m_strMsgTxt ; 
		m_cCCmcomsend.m_procstate	= "01" ;
		m_cCCmcomsend.m_sendtimes	= 0 ;

		iRet = m_cCCmcomsend.insert();
		if (SQL_SUCCESS != iRet) 
	    {
	        sprintf(m_szErrMsg, "m_cCCmcomsend.insert:插入往NPC通讯表错误, m_msgid[%s], [%d][%s]",
				m_cCCmcomsend.m_msgid.c_str(), iRet, m_cCCmcomsend.GetSqlErr()); 
			
	        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);

	        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
	    }
		
	}
	
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "成功向远程队列[%s]发送往账报文[%s]",
												g_SendQueue, m_strMsgID.c_str());
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendXmlPack::AddQueue()");
}


void CSendXmlPack::UpdPkgAssistState(LPCSTR pProstate)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendXmlPack::UpdPkgAssistState()");
	CBppkgassist oCBppkgassist		;
	string		 strProstate = ""	;
	
	oCBppkgassist.setctx(m_dbproc);
	
	oCBppkgassist.m_recvbank	= m_strRecvBank;
	oCBppkgassist.m_msgtype		= m_strMsgType;
	oCBppkgassist.m_msgid		= m_strMsgID;
	strProstate					= pProstate;
	
	int iUpdCode = oCBppkgassist.setstate(strProstate);
	if (SQL_SUCCESS != iUpdCode) 
    {
        sprintf(m_szErrMsg, "oCBppkgassist.find:更新打包辅助表记录错, setstate[%s], [%d][%s]",
			strProstate.c_str(), iUpdCode, oCBppkgassist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);

        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
    }
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendXmlPack::UpdPkgAssistState()");
}



void CSendXmlPack::PackXml121()
{   
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendXmlPack::PackXml121()");
    
	beps121				oBeps121;
	CBpbcoutsendlist	oCBpbcoutsendlist   ;

	char				sSqlStr[4000 + 1]  = {0};
	string				strWhereClause	= "";
	int					iRetCode		= RTN_FAIL;
	int					iUpdCode		= RTN_FAIL;
	char				sTemp[32]		= { 0 };
	string				strTemp				;
	int 				iCount				;
	int 				iNbOfTxs		= 0;
	double				dCtrlSum		= 0.00;
    int                 nLoop           = 0;
	
	//组报文头
	oBeps121.CreateXMlHeader("BEPS", 
								m_sWorkDate,
								m_strSendBank.c_str(),
								m_strRecvBank.c_str(),
				  				"beps.121.001.01",
				  				m_sMsgRefId);
				  				
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "____m_strTx1 = %s", oBeps121.m_strTx1.c_str());
	
	//取明细，组明细
	oCBpbcoutsendlist.setctx(m_dbproc);

	strWhereClause = "msgid = '" + m_strMsgID + "' " + "and procstate = " + PR_HVBP_95 + "  order by txid ";
	
	iRetCode = oCBpbcoutsendlist.find(strWhereClause);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(m_szErrMsg, "oCBpbcoutsendlist.find:查询小额往帐贷记明细表记录错, [%d][%s]",
			iRetCode, oCBpbcoutsendlist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);

        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
    }
	
	while(SQL_SUCCESS == iRetCode)
	{
	    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "____m_strTx1 = %s", oBeps121.m_strTx1.c_str());
	    nLoop++;
		iRetCode = oCBpbcoutsendlist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
			break;
		if (SQL_SUCCESS != iRetCode) 
		{
		    //关闭游标
		    oCBpbcoutsendlist.closeCursor();
			sprintf(m_szErrMsg, "oCBpbcoutsendlist.fetch:查询小额往帐贷记明细表记录错, [%d][%s]",
				iRetCode, oCBpbcoutsendlist.GetSqlErr()); 
			
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
	
			PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
		}

		/**************************************************************/
		
		oBeps121.TxId              = oCBpbcoutsendlist.m_txid			;//明细标识号	
		oBeps121.DbtrNm            = oCBpbcoutsendlist.m_dbtnm			;//付款人名称
		oBeps121.DbtrAdrLine       = oCBpbcoutsendlist.m_dbtaddr		;//付款人地址
		oBeps121.DbtrAcctId        = oCBpbcoutsendlist.m_dbtracctid		;//付款人账号
		oBeps121.DbtrAcctIssr      = oCBpbcoutsendlist.m_dbtrissr		;//付款人开户行行号
		oBeps121.DbtrAgtId         = oCBpbcoutsendlist.m_dbtrbrnchid	;//付款行行号
		oBeps121.CdtrAgtId         = oCBpbcoutsendlist.m_cdtrbrnchid	;//收款行行号
		oBeps121.CdtrNm            = oCBpbcoutsendlist.m_cdtrnm			;//收款人名称
		oBeps121.CdtrAdrLine       = oCBpbcoutsendlist.m_cdtaddr		;//收款人地址
		oBeps121.CdtrAcctId        = oCBpbcoutsendlist.m_cdtracctid		;//收款人账号
		oBeps121.CdtrAcctIssr      = oCBpbcoutsendlist.m_cdtrissr		;//收款人开户行行号

		memset(sTemp,'\0',sizeof(sTemp));
		sprintf(sTemp, "%.2f", oCBpbcoutsendlist.m_amount)				;
		oBeps121.CstmrCdtTrfInfAmt = 	sTemp		                    ;//金额
		
		oBeps121.CstmrCdtTrfInfCcy = 	oCBpbcoutsendlist.m_currency	;//货币符号
		oBeps121.CtgyPurpPrtry     = 	oCBpbcoutsendlist.m_pmttpprtry	;//业务类型编码
		oBeps121.PurpPrtry         = 	oCBpbcoutsendlist.m_purpprtry	;//业务种类编码
		oBeps121.AddtlInf          = 	oCBpbcoutsendlist.m_addtlinf	;//附言
		
		/*业务类型为汇兑业务、业务种类为委托收款划回*/
		if(oCBpbcoutsendlist.m_pmttpprtry == "A109" && oCBpbcoutsendlist.m_purpprtry == "02106")
		{
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/Tp/");
			oBeps121.ColltnInfTp            = strTemp;//票据种类
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/Dt/");
			oBeps121.ColltnInfDt            = strTemp;//票据日期
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/Nb/");
			oBeps121.ColltnInfNb            = strTemp;//票据号码
		}
		/*业务类型为汇兑业务、业务种类为托收承付划回*/
		else if(oCBpbcoutsendlist.m_pmttpprtry == "A110" && oCBpbcoutsendlist.m_purpprtry == "02107")
		{
		    GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/Dt/");
			oBeps121.ColltnWthAccptncInfDt  = strTemp;//票据日期
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/Nb/");
			oBeps121.ColltnWthAccptncInfNb  = strTemp;//票据号码

			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "0");
			
			if(0 == GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/AmdsAmt/"))
			{
    			oBeps121.AmdsAmt                = strTemp.substr(3);//赔偿金金额
    			oBeps121.AmdsAmtCcy             = strTemp.substr(0,3);
			}

			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "1");
			
			if(0 == GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/RctAmt/"))
			{
    			oBeps121.RctAmt                 = strTemp.substr(3);//拒付金额
    			oBeps121.RctAmtCcy              = strTemp.substr(0,3);
			}

            Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "2");
            
            if(0 == GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/OrgnlAmt/"))
            {
    			oBeps121.OrgnlAmt                 = strTemp.substr(3);//原托金额
    			oBeps121.OrgnlAmtCcy              = strTemp.substr(0,3);
			}

            Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "3");
            
            if(0 == GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/PmtAmt/"))
            {
    			oBeps121.PmtAmt                 = strTemp.substr(3);//支付金额
    			oBeps121.PmtAmtCcy              = strTemp.substr(0,3);
            }

            Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "4");
            
            if(0 == GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/OddAmt/"))
            {
    			oBeps121.OddAmt                 = strTemp.substr(3);//多付金额
    			oBeps121.OddAmtCcy              = strTemp.substr(0,3);
			}
		}
		
		/*业务类型为缴费业务*/
		else if(oCBpbcoutsendlist.m_pmttpprtry == "A301" )
		{   
		    GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/FlowNb/");
			oBeps121.PmtInfFlowNb           = strTemp;	//收费单位流水号
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/Term/");
			oBeps121.Term                   = strTemp;	//所属期间
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/Tp/");
			oBeps121.PmtInfTp               = strTemp;	//缴费类型
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/Rmk/");
			oBeps121.PmtInfRmk              = strTemp;	//收费附言
		}
		/*退汇业务附加数据*/
		else if(oCBpbcoutsendlist.m_pmttpprtry == "A105" )
		{
		    GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/OrgnlMsgId/");
			oBeps121.OrgnlMsgId             = strTemp;//原报文标识号
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/OrgnlInstgPty/");
			oBeps121.OrgnlInstgPty          = strTemp;//原发起参与机构
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/OrgnlMT/");
			oBeps121.OrgnlMT                = strTemp;//原报文类型
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/InstgIndrctPty/");
			oBeps121.InstgIndrctPty         = strTemp;//原发起间接参与机构
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/InstdIndrctPty/");
			oBeps121.InstdIndrctPty         = strTemp;//原接收间接参与机构
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/OrgnlTxId/");
			oBeps121.OrgnlTxId              = strTemp;//原明细标识号
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/OrgnlTxTpCd/");
			oBeps121.OrgnlTxTpCd            = strTemp;//原业务类型编码
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/Cntt/");
			oBeps121.Cntt                   = strTemp;//退汇原因
		}
		/*支票业务附加数据*/
		else if( oCBpbcoutsendlist.m_pmttpprtry == "A201" )
		{
		    GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/IsseDt/");
			oBeps121.IsseDt             = strTemp;

		    GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/DrwrNm/");
			oBeps121.DrwrNm             = strTemp;

		    GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/ChqAmt/");
			oBeps121.ChqAmt                 = strTemp.substr(3);//多付金额
			oBeps121.ChqAmtCcy              = strTemp.substr(0,3);

		    if(0 == GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/Amt/"))
		    {
    			oBeps121.ChqInfAmt                 = strTemp.substr(3);//多付金额
    			oBeps121.ChqInfCcy              = strTemp.substr(0,3);
			}

		    GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/Nb/");
			oBeps121.ChqInfNb             = strTemp;			
		}
		/*银行汇票业务附加数据*/
		else if(oCBpbcoutsendlist.m_pmttpprtry == "A203" )
		{
		    GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/IsseDt/");
			oBeps121.BkIsseDt             = strTemp;//出票日期
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/DrftAmt/");
			oBeps121.BkDrftAmt          = strTemp;//出票金额
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/ApplyAcct/");
			oBeps121.BkApplyAcct                = strTemp;//申请人账号
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/ApplyNm/");
			oBeps121.BkApplyNm         = strTemp;// 申请人名称
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/SttlmAmt/");
			oBeps121.BkSttlmAmt         = strTemp;//实际结算金额
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/OddAmt/");
			oBeps121.BkOddAmt              = strTemp;//多余金额
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/DrftTp/");
			oBeps121.BkDrftTp            = strTemp;//汇票种类			
		}
		/*商业汇票业务附加数据*/
		else if(oCBpbcoutsendlist.m_pmttpprtry == "A111" )
		{
		    GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/IsseDt/");
			oBeps121.ComIsseDt             = strTemp;//出票日期
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/DrftAmt/");
			oBeps121.ComDrftAmt          = strTemp;//出票金额
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/ApplyAcct/");
			oBeps121.ComApplyAcct                = strTemp;//申请人账号
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/ApplyNm/");
			oBeps121.ComApplyNm         = strTemp;// 申请人名称
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/SttlmAmt/");
			oBeps121.ComSttlmAmt         = strTemp;//实际结算金额
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/OddAmt/");
			oBeps121.ComOddAmt              = strTemp;//多余金额
						
		}
		/*银行本票业务附加数据*/
		else if(oCBpbcoutsendlist.m_pmttpprtry == "A204" )
		{
		    GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/IsseDt/");
			oBeps121.CshIsseDt             = strTemp;//出票日期
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/DrftAmt/");
			oBeps121.CshDrftAmt          = strTemp;//出票金额
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/ApplyAcct/");
			oBeps121.CshApplyAcct                = strTemp;//申请人账号
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/ApplyNm/");
			oBeps121.CshApplyNm         = strTemp;// 申请人名称
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/SttlmAmt/");
			oBeps121.CshSttlmAmt         = strTemp;//实际结算金额
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/OddAmt/");
			oBeps121.CshOddAmt              = strTemp;//多余金额
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/DrftTp/");
			oBeps121.CshDrftTp            = strTemp;//汇票种类			
		}
						
		Trace(L_DEBUG,	__FILE__,  __LINE__, NULL, "5");
		
		oBeps121.AddDetail();

        Trace(L_DEBUG,	__FILE__,  __LINE__, NULL, "6");
		//Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "TXID = [%s]", oCBpbcoutsendlist.m_txid.c_str());
		
		/**************************************************************/
		iNbOfTxs++;
		dCtrlSum += oCBpbcoutsendlist.m_amount;
	}
    
    //关闭游标
    oCBpbcoutsendlist.closeCursor();
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "____m_strTx1 = %s", oBeps121.m_strTx1.c_str());
	oBeps121.MsgId                  =	m_strMsgID;
	oBeps121.CreDtTm                =	m_sIsoWorkDate;
	oBeps121.InstgDrctPty           =	m_strSendBank;
	oBeps121.InstdDrctPty           =	m_strRecvBank;
	
	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp,"%d", iNbOfTxs);
	oBeps121.PKGGrpHdrNbOfTxs       =	sTemp;
	
	
	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp,"%.2f", dCtrlSum);
	oBeps121.CtrlSum                =	sTemp;
	
    
	oBeps121.CtrlSumCcy             =	oCBpbcoutsendlist.m_currency;
	oBeps121.SysCd                  =	"BEPS";
	oBeps121.PKGGrpHdrRmk           =	"";

    //在这赋值入汇总表    
    m_cBpbcoutsndcl.m_nboftxs       =   atoi(oBeps121.PKGGrpHdrNbOfTxs.c_str());//明细业务总笔数
    m_cBpbcoutsndcl.m_dgtsign       =   "dgtsign";//数值签名
    m_cBpbcoutsndcl.m_ctrlsum       =   atof(oBeps121.CtrlSum.c_str());//明细业务总金额
    m_cBpbcoutsndcl.m_ccy           =   oCBpbcoutsendlist.m_currency ;
    InsertBcoutsndcl();

    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "____m_strTx1 = %s", oBeps121.m_strTx1.c_str());
	//组签名串
	AddSign( oBeps121, m_strSendBank.c_str(),RAWSIGN);
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "____m_strTx1 = %s", oBeps121.m_strTx1.c_str());
	
	int iRet = oBeps121.CreateXml();
	if (0 != iRet)
	{
		
		sprintf(m_szErrMsg,"创建往账beps.121.001.01报文失败[%d]", iRet);
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, m_szErrMsg);
	}
	
    m_strMsgTxt = oBeps121.m_sXMLBuff;

	//Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgTxt = [%s]", m_strMsgTxt.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "len = [%d]", m_strMsgTxt.length());

	//并更新处理状态为"已发送"
	sprintf(sSqlStr,"update bp_bcoutsendlist set procstate = '%s' "
            			" where msgid = '%s' and procstate = '%s' ", PR_HVBP_08,m_strMsgID.c_str(),PR_HVBP_95);
	
	iUpdCode = oCBpbcoutsendlist.execsql(sSqlStr);
	if (SQL_SUCCESS != iUpdCode) 
	{
		sprintf(m_szErrMsg, "oCBppkgassist.setstate:更新小额往帐贷记明细表记录错, [%d][%s]",
			iUpdCode, oCBpbcoutsendlist.GetSqlErr()); 
		
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendXmlPack::PackXml121()");
}


void CSendXmlPack::PackXml122()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendXmlPack::PackXml122()");
	
	beps122				oBeps122;
	CBpbcoutsendlist	oCBpbcoutsendlist   ;

	char				sSqlStr[4000 + 1]  = {0};
	string				strWhereClause	= "";
	int					iRetCode		= RTN_FAIL;
	int					iUpdCode		= RTN_FAIL;
	char				sTemp[32]		= { 0 };
	string				strTemp				;
	int 				iCount				;
	int 				iNbOfTxs		= 0;
	double				dCtrlSum		= 0.00;
    int                 nLoop           = 0;

	//组报文头
	oBeps122.CreateXMlHeader("BEPS", 
								m_sWorkDate,
								m_strSendBank.c_str(),
								m_strRecvBank.c_str(),
				  				"beps.122.001.01",
				  				m_sMsgRefId);
	
	//取明细，组明细
	oCBpbcoutsendlist.setctx(m_dbproc);

	strWhereClause = "msgid = '" + m_strMsgID + "' ";
	
	iRetCode = oCBpbcoutsendlist.find(strWhereClause);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(m_szErrMsg, "oCBpbcoutsendlist.find:查询小额往帐贷记明细表记录错, [%d][%s]",
			iRetCode, oCBpbcoutsendlist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);

        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
    }
	
	while(SQL_SUCCESS == iRetCode)
	{
    	nLoop++;
		iRetCode = oCBpbcoutsendlist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
			break;
		if (SQL_SUCCESS != iRetCode) 
		{
		
            //关闭游标
            oCBpbcoutsendlist.closeCursor();
			sprintf(m_szErrMsg, "oCBpbcoutsendlist.fetch:查询小额往帐贷记明细表记录错, [%d][%s]",
				iRetCode, oCBpbcoutsendlist.GetSqlErr()); 
			
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
	
			PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
		}

		//----------------------------------------------------------------------------
		oBeps122.TxId						= oCBpbcoutsendlist.m_txid		;	
		oBeps122.DbtrNm						= oCBpbcoutsendlist.m_dbtnm		;
		oBeps122.DbtrAdrLine				= oCBpbcoutsendlist.m_dbtaddr	;
		oBeps122.DbtrAcctId					= oCBpbcoutsendlist.m_dbtracctid;
		oBeps122.DbtrAcctIssr				= oCBpbcoutsendlist.m_dbtrissr	;
		oBeps122.DbtrAgtId					= oCBpbcoutsendlist.m_dbtrbrnchid;
		oBeps122.CdtrAgtId					= oCBpbcoutsendlist.m_cdtrbrnchid;
		oBeps122.CdtrNm						= oCBpbcoutsendlist.m_cdtrnm	;
		oBeps122.CdtrAdrLine				= oCBpbcoutsendlist.m_cdtaddr	;
		oBeps122.CdtrAcctId					= oCBpbcoutsendlist.m_cdtracctid;
		oBeps122.CdtrAcctIssr				= oCBpbcoutsendlist.m_cdtrissr	;
		sprintf(sTemp, "%.2f", oCBpbcoutsendlist.m_amount);
		oBeps122.FinCdtTrfInfAmt			= sTemp							;
		oBeps122.FinCdtTrfInfCcy			= oCBpbcoutsendlist.m_currency	;
		oBeps122.CtgyPurpPrtry				= oCBpbcoutsendlist.m_pmttpprtry;
		oBeps122.PurpPrtry					= oCBpbcoutsendlist.m_purpprtry	;
		oBeps122.AddtlInf					= oCBpbcoutsendlist.m_addtlinf	;

		//业务类型为国库资金贷记划拨
		if("A104" == oBeps122.CtgyPurpPrtry)		
		{
		    GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/FlowNb/");
			oBeps122.NtlTrsrCdtInfFlowNb           = strTemp;//信息流水号
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/Amt/");
			oBeps122.NtlTrsrCdtInfAmt              = strTemp.substr(3);//明细汇总金额
			oBeps122.NtlTrsrCdtInfCcy              = strTemp.substr(0,3);
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/RptCd/");
			oBeps122.NtlTrsrCdtInfRptCd            = strTemp;//上报国库代码
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/RcvCd/");
			oBeps122.NtlTrsrCdtInfRcvCd            = strTemp;//接收国库代码
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/RptFrms/");
			oBeps122.NtlTrsrCdtInfRptFrms          = strTemp;//报表日期
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/RptNb/");
			oBeps122.NtlTrsrCdtInfRptNb            = strTemp;//报表序号

            GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/BugtLvl/");
			oBeps122.BugtLvl            = strTemp;//预算级次
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/Ind/");
			oBeps122.Ind            = strTemp;//调整期标志
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/BugtTp/");
			oBeps122.BugtTp            = strTemp;//预算种类
			
			//获取明细条数
			iCount = 0;
			GetTagVal(oBeps122.NtlTrsrCdtInfNbOfTxs,oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/NbOfTxs/");		
			iCount = atoi(oBeps122.NtlTrsrCdtInfNbOfTxs.c_str());//明细条数
			for(int i = 1; i <=iCount; i++)//循环从1开始
			{
				/*以下字段为循环中的循环*/
				GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/TpCd/", i);
				oBeps122.AddNodeToSubcycle("NtlTrsrCdtInfDtlsTpCd",strTemp.c_str());//征收机关大类代码
				oBeps122.m_strTx2 += Trim(strTemp.c_str()) + "|";
				
				GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/SbjtCd/", i);
				oBeps122.AddNodeToSubcycle("SbjtCd",strTemp.c_str());//征收机关大类代码
				oBeps122.m_strTx2 += Trim(strTemp.c_str()) + "|";
				
				GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/Amt/", i);
				oBeps122.NtlTrsrCdtInfDtlsAmt                = strTemp.substr(3);//发生额
				oBeps122.AddNodeToSubcycle("NtlTrsrCdtInfDtlsAmt",oBeps122.NtlTrsrCdtInfDtlsAmt.c_str());//发生额
				oBeps122.m_strTx2 += Trim(strTemp.c_str()) + "|";
				
				oBeps122.NtlTrsrCdtInfDtlsCcy             = strTemp.substr(0,3);
                oBeps122.AddNodeToSubcycle("NtlTrsrCdtInfDtlsCcy",oBeps122.NtlTrsrCdtInfDtlsCcy.c_str());
                oBeps122.AddSubcycleToNode("NtlTrsrCdtInfDtls");
                
				Trace(L_INFO,	__FILE__,  __LINE__, NULL, "m_strTx2 = [%s]", oBeps122.m_strTx2.c_str());
			}      
            memset(sTemp,0,sizeof(sTemp));
            sprintf(sTemp,"%d",nLoop);//这个仅作mat中关键字使用
            oBeps122.AddNodeToSubcycle("NtlTrsrCdtInfDtls",sTemp,1);//备注：将子循环节点添加的父节点
			
		}
		//业务类型为国库资金国债兑付贷记划拨
		else if("A307" == oBeps122.CtgyPurpPrtry)
		{
		    GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/FlowNb/");
			oBeps122.NtlTrsrInfFlowNb           = strTemp;//信息流水号
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/Amt/");
			oBeps122.NtlTrsrInfAmt              = strTemp.substr(3);//明细汇总金额
			oBeps122.NtlTrsrInfCcy              = strTemp.substr(0,3);
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/RptCd/");
			oBeps122.NtlTrsrInfRptCd            = strTemp;//上报国库代码
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/RcvCd/");
			oBeps122.NtlTrsrInfRcvCd            = strTemp;//接收国库代码
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/RptFrms/");
			oBeps122.NtlTrsrInfRptFrms          = strTemp;//报表日期
			
			GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/RptNb/");
			oBeps122.NtlTrsrInfRptNb            = strTemp;//报表序号
	
			//获取明细条数
			iCount = 0;
			GetTagVal(oBeps122.NtlTrsrInfNbOfTxs,oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/NbOfTxs/");		
			iCount = atoi(oBeps122.NtlTrsrInfNbOfTxs.c_str());//明细条数

			for(int i = 1; i <=iCount; i++)//循环从1开始
			{
				/*以下字段为循环中的循环*/
				GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/TpCd/", i);
				oBeps122.AddNodeToSubcycle("NtlTrsrInfDtlsTpCd",strTemp.c_str());//兑付国债银行大类
				oBeps122.m_strTx2 += Trim(strTemp.c_str()) + "|";
				
				GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/CptlCd/", i);
				oBeps122.AddNodeToSubcycle("CptlCd",strTemp.c_str());//本金代码
				oBeps122.m_strTx2 += Trim(strTemp.c_str()) + "|";
				
				GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/CptlAmt/", i);
				oBeps122.CptlAmt                = strTemp.substr(3);//本金金额
				oBeps122.AddNodeToSubcycle("CptlAmt",oBeps122.CptlAmt.c_str());//本金金额
				
				oBeps122.CptlAmtCcy             = strTemp.substr(0,3);
                oBeps122.AddNodeToSubcycle("CptlAmtCcy",oBeps122.CptlAmtCcy.c_str());
				oBeps122.m_strTx2 += Trim(strTemp.c_str()) + "|";
				
				GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/AcrlCd/", i);
				oBeps122.AcrlCd                 = strTemp;//利息代码
				oBeps122.AddNodeToSubcycle("AcrlCd",oBeps122.AcrlCd.c_str());
				oBeps122.m_strTx2 += Trim(strTemp.c_str()) + "|";
                
				GetTagVal(strTemp, oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, "/AcrlAmt/", i);
				oBeps122.AcrlAmt                = strTemp.substr(3);//利息金额
				oBeps122.AddNodeToSubcycle("AcrlAmt",oBeps122.AcrlAmt.c_str());
                
				oBeps122.AcrlAmtCcy             = strTemp.substr(0,3);
                oBeps122.AddNodeToSubcycle("AcrlAmtCcy",oBeps122.AcrlAmtCcy.c_str());
                oBeps122.AddSubcycleToNode("NtlTrsrInfDtls");
				oBeps122.m_strTx2 += Trim(strTemp.c_str()) + "|";
				
				Trace(L_DEBUG,	__FILE__,  __LINE__, NULL, "m_strTx2 = [%s]", oBeps122.m_strTx2.c_str());
			}      
            memset(sTemp,0,sizeof(sTemp));
            sprintf(sTemp,"%d",nLoop);//这个仅作mat中关键字使用
            oBeps122.AddNodeToSubcycle("NtlTrsrInfDtls",sTemp,1);//备注：将子循环节点添加的父节点

		}
		//业务类型为国库同城交换净额清算
		else if("A103" == oBeps122.CtgyPurpPrtry)	//国库同城交换净额清算 
		{
			oBeps122.AddtlInf				= "";	//交换场次
		}
		
		oBeps122.AddDetail();

		//----------------------------------------------------------------------------
		
		iNbOfTxs++;
		dCtrlSum += oCBpbcoutsendlist.m_amount;
		
	}
    //关闭游标
    oCBpbcoutsendlist.closeCursor();

	oBeps122.MsgId                  =	m_strMsgID;
	oBeps122.CreDtTm                =	m_sIsoWorkDate;
	oBeps122.InstgDrctPty           =	m_strSendBank;
	oBeps122.InstdDrctPty           =	m_strRecvBank;
	
	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp,"%d", iNbOfTxs);
	oBeps122.PKGGrpHdrNbOfTxs       =	sTemp;
	
	
	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp,"%.2f", dCtrlSum);
	oBeps122.CtrlSum                =	sTemp;
	
	oBeps122.CtrlSumCcy             =	oCBpbcoutsendlist.m_currency;
	oBeps122.SysCd                  =	"BEPS";
	oBeps122.Rmk			        =	"";

    //在这赋值入汇总表
    m_cBpbcoutsndcl.m_nboftxs       =   atoi(oBeps122.PKGGrpHdrNbOfTxs.c_str());//明细业务总笔数
    m_cBpbcoutsndcl.m_dgtsign       =   "dgtsign";//数值签名
    m_cBpbcoutsndcl.m_ctrlsum       =   atof(oBeps122.CtrlSum.c_str());//明细业务总金额
    m_cBpbcoutsndcl.m_ccy           =   oCBpbcoutsendlist.m_currency;
    InsertBcoutsndcl();
    
	//组签名串
	AddSign( oBeps122, m_strSendBank.c_str(),RAWSIGN);
	
	int iRet = oBeps122.CreateXml();
	if (0 != iRet)
	{
		
		sprintf(m_szErrMsg,"创建往账beps.122.001.01报文失败[%d]", iRet);
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, m_szErrMsg);
	}
	
    m_strMsgTxt = oBeps122.m_sXMLBuff;

	//Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgTxt = [%s]", m_strMsgTxt.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "len = [%d]", m_strMsgTxt.length());

	//并更新处理状态为"已发送"
	sprintf(sSqlStr,"update bp_bcoutsendlist set procstate = '%s' "
            			" where msgid = '%s' and procstate = '%s' ", PR_HVBP_08,m_strMsgID.c_str(),PR_HVBP_95);
	iUpdCode = oCBpbcoutsendlist.execsql(sSqlStr);
	if (SQL_SUCCESS != iUpdCode) 
	{
		sprintf(m_szErrMsg, "oCBppkgassist.setstate:更新小额往帐贷记明细表记录错, [%d][%s]",
			iUpdCode, oCBpbcoutsendlist.GetSqlErr()); 
		
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendXmlPack::PackXml122()");
}

void CSendXmlPack::PackXml125()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendXmlPack::PackXml125()");
	
	beps125				oBeps125;
	CBpbcoutsendlist	oCBpbcoutsendlist   ;

	char				sSqlStr[4000 + 1]  = {0};
	string				strWhereClause	= "";
	int					iRetCode		= RTN_FAIL;
	int					iUpdCode		= RTN_FAIL;
	char				sTemp[32]		= { 0 };
	string				strTemp				;
	int 				iCount				;
	int 				iNbOfTxs		= 0;
	double				dCtrlSum		= 0.00;
	int 				iDepth 			= 0;
	
	//组报文头
	oBeps125.CreateXMlHeader("BEPS", 
								m_sWorkDate,
								m_strSendBank.c_str(),
								m_strRecvBank.c_str(),
				  				"beps.125.001.01",
				  				m_sMsgRefId);
	
	//取明细，组明细
	oCBpbcoutsendlist.setctx(m_dbproc);

	strWhereClause = "msgid = '" + m_strMsgID + "' " + "and procstate = " + PR_HVBP_95 + "  order by txid ";
	
	iRetCode = oCBpbcoutsendlist.find(strWhereClause);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(m_szErrMsg, "oCBpbcoutsendlist.find:查询小额往帐贷记明细表记录错, [%d][%s]",
			iRetCode, oCBpbcoutsendlist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);

        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
    }
	
	while(SQL_SUCCESS == iRetCode)
	{
		iRetCode = oCBpbcoutsendlist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
			break;
		if (SQL_SUCCESS != iRetCode) 
		{
		
		    oCBpbcoutsendlist.closeCursor();
            
			sprintf(m_szErrMsg, "oCBpbcoutsendlist.fetch:查询小额往帐贷记明细表记录错, [%d][%s]",
				iRetCode, oCBpbcoutsendlist.GetSqlErr()); 
			
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
	
			PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
		}

		/**************************************************************/
		
		oBeps125.TxId              = oCBpbcoutsendlist.m_txid			;//明细标识号	
		oBeps125.EndToEndId        = oCBpbcoutsendlist.m_endtoendid     ;//端到端标识号
		oBeps125.ClrSysRef         = oCBpbcoutsendlist.m_clrsysref      ;//明细业务参考号
		oBeps125.ChrgBr            = "DEBT"                             ;//固定填写DEBT
		oBeps125.DbtrNm            = oCBpbcoutsendlist.m_dbtnm			;//付款人名称
		oBeps125.DbtrAdrLine       = oCBpbcoutsendlist.m_dbtaddr		;//付款人地址
		oBeps125.DbtrAcctId        = oCBpbcoutsendlist.m_dbtracctid		;//付款人账号
		oBeps125.DbtrAcctIssr      = oCBpbcoutsendlist.m_dbtrissr		;//付款人开户行行号
		oBeps125.DbtrAgtMmbId      = oCBpbcoutsendlist.m_instgdrctpty   ;//付款清算行
		oBeps125.DbtrAgtId         = oCBpbcoutsendlist.m_dbtrbrnchid	;//付款行行号
		oBeps125.CdtrAgtId         = oCBpbcoutsendlist.m_cdtrbrnchid	;//收款行行号
		oBeps125.CdtrNm            = oCBpbcoutsendlist.m_cdtrnm			;//收款人名称
		oBeps125.CdtrAdrLine       = oCBpbcoutsendlist.m_cdtaddr		;//收款人地址
		oBeps125.CdtrAcctId        = oCBpbcoutsendlist.m_cdtracctid		;//收款人账号
		oBeps125.CdtrAcctIssr      = oCBpbcoutsendlist.m_cdtrissr		;//收款人开户行行号
		oBeps125.CdtrAgtMmbId      = oCBpbcoutsendlist.m_instddrctpty   ;//收款清算行
        oBeps125.DbtrAcctIssrNm    = oCBpbcoutsendlist.m_dbtrissrnm     ;//付款人开户行名称
        oBeps125.CdtrAcctIssrNm    = oCBpbcoutsendlist.m_cdtrissrnm     ;//收款人开户行名称

        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "oBeps125.DbtrAcctIssr = [%s]",oBeps125.DbtrAcctIssr.c_str());
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "oBeps125.CdtrAcctIssr = [%s]",oBeps125.CdtrAcctIssr.c_str());

		memset(sTemp,'\0',sizeof(sTemp));
		sprintf(sTemp, "%.2f", oCBpbcoutsendlist.m_amount)				;
		oBeps125.IntrBkSttlmAmt    = 	sTemp		                    ;//金额
		
		oBeps125.Ccy               = 	oCBpbcoutsendlist.m_currency	;//货币符号
		oBeps125.PurpPrtry         = 	oCBpbcoutsendlist.m_purpprtry	;//业务种类编码
		
		//XMLGetTag2ND("/H01/", oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, iDepth, &oBeps125);// 附言
        //XMLGetTag2ND("/H02/", oCBpbcoutsendlist.m_cstmrcdttrfaddtlinf, iDepth, &oBeps125);//  附言2

	    string strTemp = "";
	    
        iDepth = 0;
        strTemp = "/H01/" + oCBpbcoutsendlist.m_addtlinf;
        oBeps125.SetUstrd(iDepth, strTemp.c_str());
        iDepth++;
        strTemp = "/H02/" + oCBpbcoutsendlist.m_addtlinf2;
        oBeps125.SetUstrd(iDepth, strTemp.c_str());
        
        memset(sTemp,'\0',sizeof(sTemp));
        sprintf(sTemp, "Ustrd%d", iNbOfTxs + 1);
		oBeps125.AddNodeToSubcycle("Ustrd", sTemp, 2);
		
		oBeps125.AddDetail();

		/**************************************************************/
		iNbOfTxs++;
		dCtrlSum += oCBpbcoutsendlist.m_amount;
	}
    
    //关闭游标
	oCBpbcoutsendlist.closeCursor();
    
	oBeps125.MsgId                  =	m_strMsgID;
	oBeps125.CreDtTm                =	m_sIsoWorkDate;
	
	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp,"%d", iNbOfTxs);
	oBeps125.NbOfTxs       			=	sTemp;
	
	
	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp,"%.2f", dCtrlSum);
	oBeps125.CtrlSum                =	sTemp;
	
	oBeps125.SttlmMtd				= 	"CLRG";
	
	oBeps125.CtgyPurpPrtry          =   oCBpbcoutsendlist.m_pmttpprtry	;//业务类型编码
	
	//在这赋值入汇总表
    m_cBpbcoutsndcl.m_nboftxs       =   atoi(oBeps125.NbOfTxs.c_str());//明细业务总笔数
    m_cBpbcoutsndcl.m_dgtsign       =   "dgtsign";//数值签名
    m_cBpbcoutsndcl.m_ctrlsum       =   atof(oBeps125.CtrlSum.c_str());//明细业务总金额
    m_cBpbcoutsndcl.m_ccy           =   oCBpbcoutsendlist.m_currency;
    
    InsertBcoutsndcl();
    
	//组签名串
	AddSign( oBeps125,m_strSendBank.c_str(), RAWSIGN);  
	 
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSignBuff = [%s]", oBeps125.m_sSignBuff.c_str());
    
 	int iRet = oBeps125.CreateXml();
	if (0 != iRet)
	{
		sprintf(m_szErrMsg,"创建往账beps.125.001.01报文失败[%d]", iRet);
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, m_szErrMsg);
	}
	
    m_strMsgTxt = oBeps125.m_sXMLBuff;

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgTxt = [%s]", m_strMsgTxt.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "len = [%d]", m_strMsgTxt.length());

	//并更新处理状态为"已发送"
	sprintf(sSqlStr,"update bp_bcoutsendlist set procstate = '%s' "
            			" where msgid = '%s' and procstate = '%s' ",PR_HVBP_08, m_strMsgID.c_str(),PR_HVBP_95);
	
	iUpdCode = oCBpbcoutsendlist.execsql(sSqlStr);
	if (SQL_SUCCESS != iUpdCode) 
	{
		sprintf(m_szErrMsg, "oCBppkgassist.setstate:更新小额往帐贷记明细表记录错, [%d][%s]",
			iUpdCode, oCBpbcoutsendlist.GetSqlErr()); 
		
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendXmlPack::PackXml125()");
}

void CSendXmlPack::PackXml127()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendXmlPack::PackXml127()");

	beps127				oBeps127;
	CBpbdsendlist	oBpbdsendlist   ;

	char				sSqlStr[4000 + 1]  = {0};
	string				strWhereClause	= "";
	int					iRetCode		= RTN_FAIL;
	int					iUpdCode		= RTN_FAIL;
	char				sTemp[32]		= { 0 };
	string				strTemp				;
	int 				iCount				;
	int 				iNbOfTxs		= 0;
	double				dCtrlSum		= 0.00;
	int 				iDepth 			= 0;
    int                 nLoop           = 0;
	
	//组报文头
	oBeps127.CreateXMlHeader("BEPS", 
								m_sWorkDate,
								m_strSendBank.c_str(),
								m_strRecvBank.c_str(),
				  				"beps.127.001.01",
				  				m_sMsgRefId);
	
	//取明细，组明细
	SETCTX(oBpbdsendlist);

	strWhereClause = "msgid = '" + m_strMsgID + "' " + "and procstate = " + PR_HVBP_95 + "  order by txid ";
	
	iRetCode = oBpbdsendlist.find(strWhereClause);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(m_szErrMsg, "oBpbdsendlist.find:查询表记录错, [%d][%s]",
			iRetCode, oBpbdsendlist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);

        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
    }
	
	while(SQL_SUCCESS == iRetCode)
	{
	    nLoop++;
		iRetCode = oBpbdsendlist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
			break;
		if (SQL_SUCCESS != iRetCode) 
		{
		    //关闭游标
            oBpbdsendlist.closeCursor();
                    
			sprintf(m_szErrMsg, "oBpbdsendlist.fetch:查询明细表记录错, [%d][%s]",
				iRetCode, oBpbdsendlist.GetSqlErr()); 
			
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
	
			PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
		}
		
		oBeps127.TxId						  = 	oBpbdsendlist.m_txid		;

		oBeps127.AgrmtNb                      = 	oBpbdsendlist.m_agrmtnb;
		oBeps127.DbtrNm                       = 	oBpbdsendlist.m_dbtnm		;
		oBeps127.DbtrAdrLine                  = 	oBpbdsendlist.m_dbtaddr		;
		oBeps127.DbtrAcctId                   = 	oBpbdsendlist.m_dbtracctid		;
		oBeps127.DbtrAcctIssr                 = 	oBpbdsendlist.m_dbtrissr		;
		oBeps127.DbtrAgtId                    = 	oBpbdsendlist.m_dbtrbrnchid		;
		oBeps127.CdtrAgtId                    = 	oBpbdsendlist.m_cdtrbrnchid		;
		oBeps127.CdtrNm                       = 	oBpbdsendlist.m_cdtrnm		;
		oBeps127.CdtrAdrLine                  = 	oBpbdsendlist.m_cdtaddr		;
		oBeps127.CdtrAcctId                   = 	oBpbdsendlist.m_cdtracctid		;
		oBeps127.CdtrAcctIssr                 = 	oBpbdsendlist.m_cdtrissr		;
		
		memset(sTemp,'\0',sizeof(sTemp));
		oBeps127.CstmrDrctDbtInfAmt       	=	ftoa(sTemp, oBpbdsendlist.m_amount, 2);    
		oBeps127.CstmrDrctDbtInfCcy       	=	oBpbdsendlist.m_currency;    
		oBeps127.CtgyPurpPrtry            	=	oBpbdsendlist.m_pmttpprtry;    
		oBeps127.CstmrDrctDbtInfPrtry     	=	oBpbdsendlist.m_purpprtry;    
		oBeps127.AddtlInf                 	=	oBpbdsendlist.m_addtlinf;
		
	    sprintf(sTemp,"%.2f",oBpbdsendlist.m_amount);
		
		oBeps127.CstmrDrctDbtInfAmt            = 	sTemp		;
		oBeps127.CstmrDrctDbtInfCcy            = 	oBpbdsendlist.m_currency		;
		oBeps127.CtgyPurpPrtry                = 	oBpbdsendlist.m_pmttpprtry		;
		oBeps127.CstmrDrctDbtInfPrtry         = 	oBpbdsendlist.m_purpprtry		;
		oBeps127.AddtlInf                     = 	oBpbdsendlist.m_addtlinf		;
		
		/*业务类型为国库资金借记划拨业务*/
		if(oBpbdsendlist.m_pmttpprtry == "B104")
		{
			GetTagVal(oBeps127.NtlTrsrCdtInfFlowNb   ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/FlowNb/"); 
			GetTagVal(strTemp, oBpbdsendlist.m_cstmrcdttrfaddtlinf, "/Amt/");
			oBeps127.NtlTrsrCdtInfAmt = strTemp.substr(3);
			oBeps127.NtlTrsrCdtInfCcy = strTemp.substr(0, 3);  
			//GetTagVal(oBeps127.NtlTrsrCdtInfAmt      ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/FslInfAmt/"); 
			//GetTagVal(oBeps127.NtlTrsrCdtInfCcy      ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/FslInfAmtCcy/"); 
			GetTagVal(oBeps127.NtlTrsrCdtInfRptCd    ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/RptCd/"); 
			GetTagVal(oBeps127.NtlTrsrCdtInfRcvCd    ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/RcvCd/"); 
			GetTagVal(oBeps127.NtlTrsrCdtInfRptFrms  ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/RptFrms/"); 
			GetTagVal(oBeps127.NtlTrsrCdtInfRptNb    ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/RptNb/"); 
			GetTagVal(oBeps127.BugtLvl               ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/BugtLvl/"); 
			GetTagVal(oBeps127.Ind                   ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Ind/"); 
			GetTagVal(oBeps127.BugtTp                ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/BugtTp/");
            
			//获取明细条数
			GetTagVal(oBeps127.NtlTrsrCdtInfNbOfTxs ,oBpbdsendlist.m_cstmrcdttrfaddtlinf, "/NbOfTxs/");
            //明细条数
            iCount = atoi(oBeps127.NtlTrsrCdtInfNbOfTxs.c_str());
			for(int i = 1; i <=iCount; i++)
			{
				/*以下字段为循环中的循环*/
                GetTagVal(strTemp      ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/TpCd/",i); 
				oBeps127.NtlTrsrCdtInfTpCd                   = strTemp;//兑付国债银行大类
				oBeps127.AddNodeToSubcycle("NtlTrsrCdtInfTpCd",oBeps127.NtlTrsrCdtInfTpCd.c_str());//兑付国债银行大类s
				
				GetTagVal(strTemp, oBpbdsendlist.m_cstmrcdttrfaddtlinf, "/SbjtCd/", i);
				oBeps127.SbjtCd                 = strTemp;//本金代码
				oBeps127.AddNodeToSubcycle("SbjtCd",oBeps127.SbjtCd.c_str());
                
				GetTagVal(strTemp, oBpbdsendlist.m_cstmrcdttrfaddtlinf, "/Amt/", i);
				oBeps127.Amt                = strTemp.substr(3);//本金金额
				oBeps127.AmtCcy             = strTemp.substr(0,3);
                oBeps127.AddNodeToSubcycle("Amt",oBeps127.Amt.c_str());
                oBeps127.AddNodeToSubcycle("AmtCcy",oBeps127.AmtCcy.c_str());
                
				oBeps127.AddSubcycleToNode("TxsDtls");
			}   
            memset(sTemp,0,sizeof(sTemp));
            sprintf(sTemp,"%d",nLoop);//这个仅作mat中关键字使用
            oBeps127.AddNodeToSubcycle("TxsDtls",sTemp,1);//备注：将子循环节点添加的父节点

		}
		/*业务类型为国库资金国债兑付借记划拨业务*/
		else if(oBpbdsendlist.m_pmttpprtry == "B307")
		{
			GetTagVal(oBeps127.NtlTrsrInfFlowNb	   ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/FlowNb/");  
			//GetTagVal(oBeps127.NtlTrsrInfAmt       ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Amt/");
			//Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
			//    "_____oBeps127.NtlTrsrInfAmt=%s", oBeps127.NtlTrsrInfAmt.c_str()); 
			//GetTagVal(oBeps127.NtlTrsrInfCcy       ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Ccy/");
			GetTagVal(strTemp, oBpbdsendlist.m_cstmrcdttrfaddtlinf, "/Amt/");
			oBeps127.NtlTrsrInfAmt = strTemp.substr(3);
			oBeps127.NtlTrsrInfCcy = strTemp.substr(0, 3); 
			GetTagVal(oBeps127.NtlTrsrInfRptCd     ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/RptCd/"); 
			GetTagVal(oBeps127.NtlTrsrInfRcvCd     ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/RcvCd/"); 
			GetTagVal(oBeps127.NtlTrsrInfRptFrms   ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/RptFrms/"); 
			GetTagVal(oBeps127.NtlTrsrInfRptNb     ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/RptNb/"); 
            
			//获取明细条数
			GetTagVal(oBeps127.NtlTrsrInfNbOfTxs ,oBpbdsendlist.m_cstmrcdttrfaddtlinf, "/NbOfTxs/");
            
            //明细条数
            iCount = atoi(oBeps127.NtlTrsrInfNbOfTxs.c_str());
			for(int i = 1; i <= iCount; i++)
			{
				/*以下字段为循环中的循环*/
                GetTagVal(strTemp      ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/TpCd/",i); 
				oBeps127.NtlTrsrInfTpCd                   = strTemp;//兑付国债银行大类
				oBeps127.AddNodeToSubcycle("NtlTrsrInfTpCd",oBeps127.NtlTrsrInfTpCd.c_str());
                
				GetTagVal(strTemp, oBpbdsendlist.m_cstmrcdttrfaddtlinf, "/CptlCd/", i);
				oBeps127.CptlCd                 = strTemp;//本金代码
				oBeps127.AddNodeToSubcycle("CptlCd",oBeps127.CptlCd.c_str());
                
				GetTagVal(strTemp, oBpbdsendlist.m_cstmrcdttrfaddtlinf, "/CptlAmt/", i);
				oBeps127.CptlAmt                = strTemp.substr(3);//本金金额
				oBeps127.CptlAmtCcy             = strTemp.substr(0,3);
				oBeps127.AddNodeToSubcycle("CptlAmt",oBeps127.CptlAmt.c_str());
                oBeps127.AddNodeToSubcycle("CptlAmtCcy",oBeps127.CptlAmtCcy.c_str());
                
				GetTagVal(strTemp, oBpbdsendlist.m_cstmrcdttrfaddtlinf, "/AcrlCd/", i);
				oBeps127.AcrlCd                 = strTemp;//利息代码
                oBeps127.AddNodeToSubcycle("AcrlCd",oBeps127.AcrlCd.c_str());             
                
				GetTagVal(strTemp, oBpbdsendlist.m_cstmrcdttrfaddtlinf, "/AcrlAmt/", i);
				oBeps127.AcrlAmt                = strTemp.substr(3);//利息金额
				oBeps127.AcrlAmtCcy             = strTemp.substr(0,3);
                oBeps127.AddNodeToSubcycle("AcrlAmt",oBeps127.AcrlAmt.c_str());
                oBeps127.AddNodeToSubcycle("AcrlAmtCcy",oBeps127.AcrlAmtCcy.c_str());
                
                oBeps127.AddSubcycleToNode("NtlTrsrInfTxsDtls");
			}    
            memset(sTemp,0,sizeof(sTemp));
            sprintf(sTemp,"%d",nLoop);//这个仅作mat中关键字使用
            oBeps127.AddNodeToSubcycle("NtlTrsrInfTxsDtls",sTemp,1);//备注：将子循环节点添加的父节点  
		}   
		/*业务类型为小额支付系统支票截留业务 注：这个业务类型是单笔发送，不会在这里做打包处理*/
		else if(oBpbdsendlist.m_pmttpprtry == "B308")
		{ 
			GetTagVal(oBeps127.ChqInfIsseDt        ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/IsseDt/");  
			GetTagVal(oBeps127.ChqInfPayDT         ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/PayDT/"); 
			GetTagVal(oBeps127.ChqInfNb            ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Nb/"); 
			GetTagVal(oBeps127.ChqInfPmtPswd       ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/PmtPswd/"); 
			GetTagVal(oBeps127.ChqInfPurp          ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Purp/"); 
			GetTagVal(oBeps127.ChqInfNbOfEndrsr    ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/NbOfEndrsr/"); 
			GetTagVal(oBeps127.ChqInfNm            ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Nm/"); 
			GetTagVal(oBeps127.ChqInfImgTp         ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ImgTp/"); 
			GetTagVal(oBeps127.ChqInfImgFrntLen    ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ImgFrntLen/"); 
			GetTagVal(oBeps127.ChqInfImgFrntData   ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ImgFrntData/"); 
			GetTagVal(oBeps127.ChqInfImgBckLen     ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ImgBckLen/"); 
			GetTagVal(oBeps127.ChqInfImgBckData    ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ImgBckData/");
		} 
		/*业务类型为小额支付系统通用票据截留业务 注：这个业务类型是单笔发送，不会在这里做打包处理*/
		else if(oBpbdsendlist.m_pmttpprtry == "B308")
		{ 
			GetTagVal(oBeps127.BllInfIsseDt        ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/IsseDt/");  
			GetTagVal(oBeps127.BllInfAmt           ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Amt/"); 
			GetTagVal(oBeps127.BllInfCcy           ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Ccy/"); 
			GetTagVal(oBeps127.BllInfPayDT         ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/PayDT/"); 
			GetTagVal(oBeps127.BllInfNb            ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Nb/"); 
			GetTagVal(oBeps127.BllInfPmtPswd       ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/PmtPswd/"); 
			GetTagVal(oBeps127.MtrtyDt             ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/MtrtyDt/"); 
			GetTagVal(oBeps127.Seal                ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Seal/"); 
			GetTagVal(oBeps127.AccptncAgrmtNb      ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/AccptncAgrmtNb/"); 
			GetTagVal(oBeps127.AccptncDt           ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/AccptncDt/"); 
			GetTagVal(oBeps127.AccptncNm           ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/AccptncNm/"); 
			GetTagVal(oBeps127.ApplyNm             ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ApplyNm/"); 
			GetTagVal(oBeps127.ApplyAcct           ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ApplyAcct/"); 
			GetTagVal(oBeps127.DrwrNm              ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/DrwrNm/"); 
			GetTagVal(oBeps127.DrwrAcct            ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/DrwrAcct/"); 
			GetTagVal(oBeps127.TxlCtrctNb          ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/TxlCtrctNb/");
			GetTagVal(oBeps127.BllInfPurp          ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Purp/"); 
			GetTagVal(oBeps127.BllInfNbOfEndrsr    ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/NbOfEndrsr/"); 
			GetTagVal(oBeps127.BllInfNm            ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/Nm/"); 
			GetTagVal(oBeps127.OrgnlCdtrNm         ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/OrgnlCdtrNm/"); 
			GetTagVal(oBeps127.BllInfImgTp         ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/mgTp/"); 
			GetTagVal(oBeps127.BllInfImgFrntLen    ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ImgFrntLen/"); 
			GetTagVal(oBeps127.BllInfImgFrntData   ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ImgFrntData/"); 
			GetTagVal(oBeps127.BllInfImgBckLen     ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ImgBckLen/"); 
			GetTagVal(oBeps127.BllInfImgBckData    ,oBpbdsendlist.m_cstmrcdttrfaddtlinf,"/ImgBckData/"); 
		}
	
		oBeps127.AddDetail();
		
		iNbOfTxs++;
		dCtrlSum += oBpbdsendlist.m_amount;		
	}
    
    //关闭游标
    oBpbdsendlist.closeCursor();

	oBeps127.MsgId                  =	m_strMsgID;
	oBeps127.CreDtTm                =	m_sIsoWorkDate;


	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp, "%d", m_stPkgTab.iPKGRtrltd);
	oBeps127.PKGRtrLtd              =   sTemp;
	
	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp,"%d", iNbOfTxs);
	oBeps127.PKGGrpHdrNbOfTxs =	sTemp;
	
	
	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp,"%.2f", dCtrlSum);
	oBeps127.CtrlSum                = sTemp;	
	oBeps127.CtgyPurpPrtry          = oBpbdsendlist.m_pmttpprtry	;//业务类型编码
	oBeps127.InstgDrctPty           = oBpbdsendlist.m_instgdrctpty;
	oBeps127.InstdDrctPty           = oBpbdsendlist.m_instddrctpty;
	oBeps127.CtrlSumCcy             = oBpbdsendlist.m_currency;
	oBeps127.SysCd                  = "BEPS";//注意，表里没有存入系统标识号的字段
	oBeps127.Rmk                    = oBpbdsendlist.m_rmk;

	
	//在这赋值入汇总表
    m_cBpbdsndcl.m_nboftxs       =   atoi(oBeps127.PKGGrpHdrNbOfTxs.c_str());//明细业务总笔数
    m_cBpbdsndcl.m_dgtsign       =   "dgtsign";//数值签名
    m_cBpbdsndcl.m_ctrlsum       =   atof(oBeps127.CtrlSum.c_str());//明细业务总金额
    m_cBpbdsndcl.m_ccy           =   oBpbdsendlist.m_currency;
    
    InsertBdsndcl();
    
  	//组签名串
	AddSign( oBeps127,m_strSendBank.c_str(), RAWSIGN);   
	 
	int iRet = oBeps127.CreateXml();
	if (0 != iRet)
	{
		
		sprintf(m_szErrMsg,"创建往账beps.127.001.01报文失败[%d]", iRet);
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, m_szErrMsg);
	}
	
    m_strMsgTxt = oBeps127.m_sXMLBuff;

	//Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgTxt = [%s]", m_strMsgTxt.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "len = [%d]", m_strMsgTxt.length());

	//并更新处理状态为"已发送"
	sprintf(sSqlStr,"update bp_bdsendlist set procstate = '%s' "
            			" where msgid = '%s' and procstate = '%s' ",PR_HVBP_08, m_strMsgID.c_str(),PR_HVBP_95);
	
	iUpdCode = oBpbdsendlist.execsql(sSqlStr);
	if (SQL_SUCCESS != iUpdCode) 
	{
		sprintf(m_szErrMsg, "oCBppkgassist.setstate:更新记明细表记录错, [%d][%s]",
			iUpdCode, oBpbdsendlist.GetSqlErr()); 
		
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendXmlPack::PackXml127()");
}

void CSendXmlPack::PackXml128()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendXmlPack::PackXml128()");

	beps128				oBeps128;
	CBpbcoutsendlist	bcoutsendlist   ;

	char				sSqlStr[4000 + 1]  = {0};
	string				strWhereClause	= "";
	int					iRetCode		= RTN_FAIL;
	int					iUpdCode		= RTN_FAIL;
	char				sTemp[32]		= { 0 };
	string				strTemp				;
	int 				iCount				;
	int 				iNbOfTxs		= 0;
	double				dCtrlSum		= 0.00;
	int 				iDepth 			= 0;
	
	//组报文头
	oBeps128.CreateXMlHeader("BEPS", 
								m_sWorkDate,
								m_strSendBank.c_str(),
								m_strRecvBank.c_str(),
				  				"beps.128.001.01",
				  				m_sMsgRefId);
	
	//取明细，组明细
	SETCTX(bcoutsendlist);

	strWhereClause = "msgid = '" + m_strMsgID + "' " + "and procstate = " + PR_HVBP_95 + "  order by txid ";
	
	iRetCode = bcoutsendlist.find(strWhereClause);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(m_szErrMsg, "oBpbdsndlist.find:查询表记录错, [%d][%s]",
			iRetCode, bcoutsendlist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);

        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
    }
	
	while(SQL_SUCCESS == iRetCode)
	{
		iRetCode = bcoutsendlist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
			break;
		if (SQL_SUCCESS != iRetCode) 
		{
		    //关闭游标
            bcoutsendlist.closeCursor();
            
			sprintf(m_szErrMsg, "oBpbdsndlist.fetch:查询明细表记录错, [%d][%s]",
				iRetCode, bcoutsendlist.GetSqlErr()); 
			
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
	
			PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
		}

        char sAmount[255] = {0};
        
        oBeps128.StsId                                  = bcoutsendlist.m_busistate;
        oBeps128.OrgnlTxId                              = bcoutsendlist.m_oritxid;
        oBeps128.RsnPrtry                               = bcoutsendlist.m_processcode ;
        oBeps128.TxInfAndStsAddtlInf                    = bcoutsendlist.m_rjctinf;
        oBeps128.IntrBkSttlmAmt                         = ftoa(sAmount, bcoutsendlist.m_amount, 2);
        oBeps128.Ccy                                    = bcoutsendlist.m_currency;
        oBeps128.CtgyPurpPrtry                          = bcoutsendlist.m_purpprtry;
        oBeps128.OrgnlCdtrAgtMmbId                      = bcoutsendlist.m_instgdrctpty ;
        oBeps128.OrgnlCdtrAgtId                         = bcoutsendlist.m_dbtracctid ;
        oBeps128.Ustrd                                  = bcoutsendlist.m_addtlinf ;
        oBeps128.DbtrAgtMmbId                           = bcoutsendlist.m_instgdrctpty ;
        oBeps128.DbtrAgtId                              = bcoutsendlist.m_dbtracctid ;
        oBeps128.CdtrAgtMmbId                           = bcoutsendlist.m_instddrctpty ;
        oBeps128.CdtrAgtId                              = bcoutsendlist.m_cdtracctid;

        XMLGetTag2ND("/F61/", bcoutsendlist.m_cstmrcdttrfaddtlinf, iDepth, &oBeps128);
        XMLGetTag2ND("/C01/", bcoutsendlist.m_cstmrcdttrfaddtlinf, iDepth, &oBeps128);
        XMLGetTag2ND("/E05/", bcoutsendlist.m_cstmrcdttrfaddtlinf, iDepth, &oBeps128);
        XMLGetTag2ND("/C00/", bcoutsendlist.m_cstmrcdttrfaddtlinf, iDepth, &oBeps128);
        
        oBeps128.AddDetail();
		
		iNbOfTxs++;
		dCtrlSum += bcoutsendlist.m_amount;		        
    }
    
    //关闭游标
    bcoutsendlist.closeCursor();

	oBeps128.MsgId                  =	m_strMsgID;
	oBeps128.CreDtTm                =	m_sIsoWorkDate;
	
	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp,"%d", iNbOfTxs);
	oBeps128.OrgnlNbOfTxs = sTemp;
	
	
	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp,"%.2f", dCtrlSum);
	oBeps128.IntrBkSttlmAmt         =	sTemp;
		
	oBeps128.CtgyPurpPrtry          = 	bcoutsendlist.m_pmttpprtry	;//业务类型编码
	
	//在这赋值入汇总表
    m_cBpbcoutsndcl.m_nboftxs       =   atoi(oBeps128.OrgnlNbOfTxs.c_str());//明细业务总笔数
    m_cBpbcoutsndcl.m_dgtsign       =   "dgtsign";//数值签名
    m_cBpbcoutsndcl.m_ctrlsum       =   atof(oBeps128.IntrBkSttlmAmt.c_str());//明细业务总金额
    m_cBpbcoutsndcl.m_ccy           =   bcoutsendlist.m_currency;
    InsertBcoutsndcl();
    
    //组签名串
	AddSign( oBeps128,m_strSendBank.c_str(), RAWSIGN); 
	
	int iRet = oBeps128.CreateXml();
	if (0 != iRet)
	{
		
		sprintf(m_szErrMsg,"创建往账beps.128.001.01报文失败[%d]", iRet);
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, m_szErrMsg);
	}
	
    m_strMsgTxt = oBeps128.m_sXMLBuff;

	//Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgTxt = [%s]", m_strMsgTxt.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "len = [%d]", m_strMsgTxt.length());

	//并更新处理状态为"已发送"
	sprintf(sSqlStr,"update bp_bcoutsendlist set procstate ='%s' "
            			" where msgid = '%s' and procstate = '%s' ", PR_HVBP_08,m_strMsgID.c_str(),PR_HVBP_95);
	
	iUpdCode = bcoutsendlist.execsql(sSqlStr);
	if (SQL_SUCCESS != iUpdCode) 
	{
		sprintf(m_szErrMsg, "oCBppkgassist.setstate:更新记明细表记录错, [%d][%s]",
			iUpdCode, bcoutsendlist.GetSqlErr()); 
		
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendXmlPack::PackXml128()");
}

void CSendXmlPack::PackXml130()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendXmlPack::PackXml130()");

	beps130				oBeps130;
	CBpbcoutsendlist	oBpbcsndlist   ;

	char				sSqlStr[4000 + 1]  = {0};
	string				strWhereClause	= "";
	int					iRetCode		= RTN_FAIL;
	int					iUpdCode		= RTN_FAIL;
	char				sTemp[32]		= { 0 };
	string				strTemp				;
	int 				iCount				;
	int 				iNbOfTxs		= 0;
	double				dCtrlSum		= 0.00;
	int 				iDepth 			= 0;
	
	//组报文头
	oBeps130.CreateXMlHeader("BEPS", 
								m_sWorkDate,
								m_strSendBank.c_str(),
								m_strRecvBank.c_str(),
				  				"beps.130.001.01",
				  				m_sMsgRefId);
	
	//取明细，组明细
	SETCTX(oBpbcsndlist);

	strWhereClause = "msgid = '" + m_strMsgID + "' " + "and procstate = " + PR_HVBP_95 + "  order by txid ";
	
	iRetCode = oBpbcsndlist.find(strWhereClause);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(m_szErrMsg, "oBpbcsndlist.find:查询表记录错, [%d][%s]",
			iRetCode, oBpbcsndlist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);

        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
    }
	
	while(SQL_SUCCESS == iRetCode)
	{
		iDepth = 0;
		iRetCode = oBpbcsndlist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
			break;
		if (SQL_SUCCESS != iRetCode) 
		{
		    //关闭游标
            oBpbcsndlist.closeCursor();
			sprintf(m_szErrMsg, "oBpbcsndlist.fetch:查询明细表记录错, [%d][%s]",
				iRetCode, oBpbcsndlist.GetSqlErr()); 
			
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
	
			PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
		}

        //oBeps130.EndToEndId                                 = oBpbcsndlist.m_endtoendid;//端到端标识号
        oBeps130.EndToEndId                                 = oBpbcsndlist.m_txid;
        oBeps130.TxId                                       = oBpbcsndlist.m_txid;//明细标识号
        oBeps130.CtgyPurpPrtry                              = oBpbcsndlist.m_pmttpprtry;//业务类型编码
        memset(sTemp, '\0', sizeof(sTemp));
        oBeps130.IntrBkSttlmAmt    = ftoa(sTemp, oBpbcsndlist.m_amount, 2); //金额
        
        oBeps130.Ccy                                        = oBpbcsndlist.m_currency;//
        //oBeps130.IntrBkSttlmDt                              = ;//没有了
        oBeps130.ChrgBr                                     = "DEBT";//没有了
        oBeps130.DbtrNm                                     = oBpbcsndlist.m_dbtnm;//付款人户名
        oBeps130.DbtrAcctId                                 = oBpbcsndlist.m_dbtracctid;//付款人账号
        oBeps130.DbtrAcctIssr                               = oBpbcsndlist.m_dbtrissr;//付款人开户行行号
        oBeps130.DbtrAgtMmbId                               = oBpbcsndlist.m_instgdrctpty;//付款清算行行号
        oBeps130.DbtrAgtId                                  = oBpbcsndlist.m_dbtrbrnchid;//付款行行号
        oBeps130.CdtrAgtMmbId                               = oBpbcsndlist.m_instddrctpty;//收款清算行行号
        oBeps130.CdtrAgtId                                  = oBpbcsndlist.m_cdtrbrnchid;//收款行行号
        oBeps130.CdtrNm                                     = oBpbcsndlist.m_cdtrnm;//收款人名称
        oBeps130.CdtrAcctId                                 = oBpbcsndlist.m_cdtracctid;//收款人账号
        oBeps130.CdtrAcctIssr                               = oBpbcsndlist.m_cdtrissr;//收款人开户行行号
        oBeps130.PurpPrtry                                  = oBpbcsndlist.m_purpprtry;//业务种类编码

        oBeps130.Dbtaddr                                    = oBpbcsndlist.m_dbtaddr;
        oBeps130.DbtrAcctIssrNm                             = oBpbcsndlist.m_dbtrissrnm;
        oBeps130.Cdtaddr                                    = oBpbcsndlist.m_cdtaddr;
        oBeps130.CdtrAcctIssrNm                             = oBpbcsndlist.m_cdtrissrnm;
        
        //oBeps130.Ustrd                                      = ;//附加域
        printf("oBpbcsndlist.m_cstmrcdttrfaddtlinf = [%s] \n", oBpbcsndlist.m_cstmrcdttrfaddtlinf.c_str());
        XMLGetTag2ND("/H01/", oBpbcsndlist.m_cstmrcdttrfaddtlinf, iDepth, &oBeps130);//附言
        XMLGetTag2ND("/H02/", oBpbcsndlist.m_cstmrcdttrfaddtlinf, iDepth, &oBeps130);//附言1
        XMLGetTag2ND("/HA1/", oBpbcsndlist.m_cstmrcdttrfaddtlinf, iDepth, &oBeps130);//备注
        XMLGetTag2ND("/HA2/", oBpbcsndlist.m_cstmrcdttrfaddtlinf, iDepth, &oBeps130);//备注2
        XMLGetTag2ND("/C14/", oBpbcsndlist.m_cstmrcdttrfaddtlinf, iDepth, &oBeps130);//原CIS委托日期
        XMLGetTag2ND("/EA2/", oBpbcsndlist.m_cstmrcdttrfaddtlinf, iDepth, &oBeps130);//原CIS交易序号
        XMLGetTag2ND("/E45/", oBpbcsndlist.m_cstmrcdttrfaddtlinf, iDepth, &oBeps130);//原CIS票据号码
        XMLGetTag2ND("/F60/", oBpbcsndlist.m_cstmrcdttrfaddtlinf, iDepth, &oBeps130);//回执状态
        XMLGetTag2ND("/G00/", oBpbcsndlist.m_cstmrcdttrfaddtlinf, iDepth, &oBeps130);//业务拒绝处理码
        XMLGetTag2ND("/H06/", oBpbcsndlist.m_cstmrcdttrfaddtlinf, iDepth, &oBeps130);//业务拒绝信息
        
        iNbOfTxs++;

        oBeps130.AddDetail(iNbOfTxs, iDepth);
        
		dCtrlSum += oBpbcsndlist.m_amount;
	}	
    
    //关闭游标
    oBpbcsndlist.closeCursor();

	oBeps130.MsgId                  =	m_strMsgID;//报文标识号
	oBeps130.CreDtTm                =	m_sIsoWorkDate;//报文发送时间
	
	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp,"%d", iNbOfTxs);
	oBeps130.NbOfTxs       			=	sTemp;//回执明细业务成功总笔数
	
	oBeps130.ClrSysPrtry          = 	sTemp; //oBpbcsndlist.m_pmttpprtry	;//回执明细总笔数
	
	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp,"%.2f", dCtrlSum);
	oBeps130.CtrlSum                =	sTemp;//回执明细业务成功总金额
	
	oBeps130.SttlmMtd				= 	"CLRG";//固定填写CLRG
	
	//oBeps130.CtgyPurpPrtry          = 	oBpbcsndlist.m_pmttpprtry	;//回执明细总笔数
	
	//在这赋值入汇总表
    m_cBpbcoutsndcl.m_nboftxs       =   atoi(oBeps130.NbOfTxs.c_str());//明细业务总笔数
    m_cBpbcoutsndcl.m_dgtsign       =   "dgtsign";//数值签名
    m_cBpbcoutsndcl.m_ctrlsum       =   atof(oBeps130.CtrlSum.c_str());//明细业务总金额
    m_cBpbcoutsndcl.m_ccy           =   oBpbcsndlist.m_currency;
    InsertBcoutsndcl();
    
    //组签名串
	AddSign( oBeps130,m_strSendBank.c_str(), RAWSIGN); 
	    
	int iRet = oBeps130.CreateXml();
	if (0 != iRet)
	{
		
		sprintf(m_szErrMsg,"创建往账beps.130.001.01报文失败[%d]", iRet);
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, m_szErrMsg);
	}
	
    m_strMsgTxt = oBeps130.m_sXMLBuff;

	//Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgTxt = [%s]", m_strMsgTxt.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "len = [%d]", m_strMsgTxt.length());

	//并更新处理状态为"已发送"
	sprintf(sSqlStr,"update bp_bcoutsendlist set procstate = '%s' "
            			" where msgid = '%s' and procstate = '%s' ",PR_HVBP_08,m_strMsgID.c_str(),PR_HVBP_95);
	
	iUpdCode = oBpbcsndlist.execsql(sSqlStr);
	if (SQL_SUCCESS != iUpdCode) 
	{
		sprintf(m_szErrMsg, "oCBppkgassist.setstate:更新记明细表记录错, [%d][%s]",
			iUpdCode, oBpbcsndlist.GetSqlErr()); 
		
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendXmlPack::PackXml130()");
}

void CSendXmlPack::PackXml133()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendXmlPack::PackXml133()");

	beps133				oBeps133;
	CBpbdsendlist	oBpbdsndlist   ;

	char				sSqlStr[4000 + 1]  = {0};
	string				strWhereClause	= "";
	int					iRetCode		= RTN_FAIL;
	int					iUpdCode		= RTN_FAIL;
	char				sTemp[32]		= { 0 };
	string				strTemp				;
	int 				iCount				;
	int 				iNbOfTxs		= 0;
	double				dCtrlSum		= 0.00;
	int 				iDepth 			= 0;
	
	//组报文头
	oBeps133.CreateXMlHeader("BEPS", 
								m_sWorkDate,
								m_strSendBank.c_str(),
								m_strRecvBank.c_str(),
				  				"beps.133.001.01",
				  				m_sMsgRefId);
	
	//取明细，组明细
	SETCTX(oBpbdsndlist);

	strWhereClause = "msgid = '" + m_strMsgID + "' " + "and procstate = " + PR_HVBP_95 + "  order by txid ";
	
	iRetCode = oBpbdsndlist.find(strWhereClause);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(m_szErrMsg, "oBpbdsndlist.find:查询表记录错, [%d][%s]",
			iRetCode, oBpbdsndlist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);

        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
    }
	
	while(SQL_SUCCESS == iRetCode)
	{
	    iDepth = 0;
		iRetCode = oBpbdsndlist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
			break;
		if (SQL_SUCCESS != iRetCode) 
		{
		    //关闭游标
            oBpbdsndlist.closeCursor();
            
			sprintf(m_szErrMsg, "oBpbdsndlist.fetch:查询明细表记录错, [%d][%s]",
				iRetCode, oBpbdsndlist.GetSqlErr()); 
			
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
	
			PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
		}
		char szBuffer[255] = {0};
		
        //oBeps133.EndToEndId                             = oBpbdsndlist.m_agrmtnb;
        oBeps133.EndToEndId                             = oBpbdsndlist.m_txid;
        oBeps133.TxId                                   = oBpbdsndlist.m_txid;
        oBeps133.ClrSysRef                              = oBpbdsndlist.m_clrsysref;
        oBeps133.IntrBkSttlmAmt                         = ftoa(szBuffer, oBpbdsndlist.m_amount, 2);
        oBeps133.Ccy                                    = oBpbdsndlist.m_currency;
        oBeps133.ChrgBr                                 = "CRED" ;
        oBeps133.CdtrNm                                 = oBpbdsndlist.m_cdtrnm;
        oBeps133.CdtrAdrLine                            = oBpbdsndlist.m_cdtaddr;
        oBeps133.CdtrAcctId                             = oBpbdsndlist.m_cdtracctid;
        oBeps133.CdtrAcctIssr                           = oBpbdsndlist.m_cdtrissr;
        oBeps133.CdtrAgtMmbId                           = oBpbdsndlist.m_instgdrctpty;
        oBeps133.CdtrAgtId                              = oBpbdsndlist.m_cdtrbrnchid ;
        oBeps133.DbtrNm                                 = oBpbdsndlist.m_dbtnm;
        oBeps133.DbtrAdrLine                            = oBpbdsndlist.m_dbtaddr;
        oBeps133.DbtrAcctId                             = oBpbdsndlist.m_dbtracctid;
        oBeps133.DbtrAcctIssr                           = oBpbdsndlist.m_dbtrissr;
        oBeps133.DbtrAgtMmbId                           = oBpbdsndlist.m_instddrctpty ;
        oBeps133.DbtrAgtId                              = oBpbdsndlist.m_dbtrbrnchid;
        oBeps133.PurpPrtry                              = oBpbdsndlist.m_purpprtry;
                
        XMLGetTag2ND("/H01/", oBpbdsndlist.m_cstmrcdttrfaddtlinf, iDepth, &oBeps133);   //附言
        XMLGetTag2ND("/E47/", oBpbdsndlist.m_cstmrcdttrfaddtlinf, iDepth, &oBeps133);   //附言
        
        //oBeps133.AddDetail(iNbOfTxs, iDepth);
        
        iNbOfTxs++;
		dCtrlSum += oBpbdsndlist.m_amount;
	}
    
    //关闭游标
    oBpbdsndlist.closeCursor();
    
	oBeps133.MsgId                  =	m_strMsgID;
	oBeps133.CreDtTm                =	m_sIsoWorkDate;
	
	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp,"%d", iNbOfTxs);
	oBeps133.NbOfTxs       			=	sTemp;
	
	
	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp,"%.2f", dCtrlSum);
	oBeps133.CtrlSum                =	sTemp;
	
	oBeps133.SttlmMtd				= 	"CLRG";
	
	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp, "%d", m_stPkgTab.iPKGRtrltd);
	oBeps133.CtgyPurpPrtry          =   sTemp;                   //回执期限
	oBeps133.LclInstrmPrtry         =   m_stPkgTab.szPmttpPrtry; //业务类型
	
	//在这赋值入汇总表
    m_cBpbdsndcl.m_nboftxs       =   atoi(oBeps133.NbOfTxs.c_str());//明细业务总笔数
    m_cBpbdsndcl.m_dgtsign       =   "dgtsign";//数值签名
    m_cBpbdsndcl.m_ctrlsum       =   atof(oBeps133.CtrlSum.c_str());//明细业务总金额
    m_cBpbdsndcl.m_ccy           =   oBpbdsndlist.m_currency;
    
    //入汇总表
    InsertBdsndcl();
    
     //组签名串
	AddSign( oBeps133, m_strSendBank.c_str(), RAWSIGN);  
	  
	int iRet = oBeps133.CreateXml();
	if (0 != iRet)
	{
		
		sprintf(m_szErrMsg,"创建往账beps.133.001.01报文失败[%d]", iRet);
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, m_szErrMsg);
	}
	
    m_strMsgTxt = oBeps133.m_sXMLBuff;

	//Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgTxt = [%s]", m_strMsgTxt.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "len = [%d]", m_strMsgTxt.length());

	//并更新处理状态为"已发送"
	sprintf(sSqlStr,"update BP_BDSENDLIST set procstate = '%s' "
            			" where msgid = '%s' and procstate = '%s' ", PR_HVBP_08,m_strMsgID.c_str(),PR_HVBP_95);
	
	iUpdCode = oBpbdsndlist.execsql(sSqlStr);
	if (SQL_SUCCESS != iUpdCode) 
	{
		sprintf(m_szErrMsg, "oCBppkgassist.setstate:更新记明细表记录错, [%d][%s]",
			iUpdCode, oBpbdsndlist.GetSqlErr()); 
		
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendXmlPack::PackXml133()");
}

void CSendXmlPack::PackXml134()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendXmlPack::PackXml134()");

	beps134				oBeps134;
	CBpbcoutsendlist	bcoutsendlist   ;

	char				sSqlStr[4000 + 1]  = {0};
	string				strWhereClause	= "";
	int					iRetCode		= RTN_FAIL;
	int					iUpdCode		= RTN_FAIL;
	char				sTemp[32]		= { 0 };
	string				strTemp				;
	int 				iCount				;
	int 				iNbOfTxs		= 0;
	double				dCtrlSum		= 0.00;
	int 				iDepth 			= 0;
	
	//组报文头
	oBeps134.CreateXMlHeader("BEPS", 
								m_sWorkDate,
								m_strSendBank.c_str(),
								m_strRecvBank.c_str(),
				  				"beps.134.001.01",
				  				m_sMsgRefId);
	
	//取明细，组明细
	SETCTX(bcoutsendlist);

	strWhereClause = "msgid = '" + m_strMsgID + "' " + "and procstate = " + PR_HVBP_95 + "  order by txid ";
	
	iRetCode = bcoutsendlist.find(strWhereClause);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(m_szErrMsg, "bcoutsendlist.find:查询表记录错, [%d][%s]",
			iRetCode, bcoutsendlist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);

        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
    }
	
	while(SQL_SUCCESS == iRetCode)
	{
		iRetCode = bcoutsendlist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
			break;
		if (SQL_SUCCESS != iRetCode) 
		{
			//关闭游标
            bcoutsendlist.closeCursor();
			sprintf(m_szErrMsg, "bcoutsendlist.fetch:查询明细表记录错, [%d][%s]",
				iRetCode, bcoutsendlist.GetSqlErr()); 
			
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
	
			PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
		}

		char sAmount[255] = {0};
        oBeps134.StsId                                  = bcoutsendlist.m_busistate;
        oBeps134.OrgnlTxId                              = bcoutsendlist.m_oritxid ;
        oBeps134.RsnPrtry                               = bcoutsendlist.m_processcode ;
        oBeps134.TxInfAndStsAddtlInf                    = bcoutsendlist.m_rjctinf;
        oBeps134.IntrBkSttlmAmt                         = ftoa(sAmount, bcoutsendlist.m_amount, 2); ;
        oBeps134.Ccy                                    = bcoutsendlist.m_currency ;
        oBeps134.CtgyPurpPrtry                          = bcoutsendlist.m_purpprtry ;
        oBeps134.OrgnlCdtrAgtMmbId                      = bcoutsendlist.m_instgdrctpty ;
        oBeps134.OrgnlCdtrAgtId                         = bcoutsendlist.m_dbtracctid ;
        oBeps134.DbtrAgtMmbId                           = bcoutsendlist.m_instgdrctpty ;
        oBeps134.DbtrAgtId                              = bcoutsendlist.m_dbtracctid ;
        oBeps134.CdtrAgtMmbId                           = bcoutsendlist.m_instddrctpty   ;
        oBeps134.CdtrAgtId                              = bcoutsendlist.m_cdtracctid ;

		oBeps134.AddDetail();
		
        iNbOfTxs++;
		dCtrlSum += bcoutsendlist.m_oriamount;//原金额
	}	
    
    //关闭游标
    bcoutsendlist.closeCursor();
    
	oBeps134.MsgId                  =	m_strMsgID;
	oBeps134.CreDtTm                =	m_sIsoWorkDate;
	
	memset(sTemp,'\0',sizeof(sTemp));
	sprintf(sTemp,"%d", iNbOfTxs);
	oBeps134.DtldNbOfTxs=	sTemp;//回执明细业务总笔数
	
	
	oBeps134.CtgyPurpPrtry          = 	bcoutsendlist.m_pmttpprtry	;//业务类型编码
	
	//在这赋值入汇总表
	//m_cBpbcoutsndcl.m_sapsnboftxs   =   at//备注
    m_cBpbcoutsndcl.m_nboftxs       =   atoi(oBeps134.DtldNbOfTxs.c_str());//回执明细业务总笔数
    m_cBpbcoutsndcl.m_dgtsign       =   "dgtsign";//数值签名
    m_cBpbcoutsndcl.m_ctrlsum       =   dCtrlSum;//明细业务总金额
    m_cBpbcoutsndcl.m_ccy           =   bcoutsendlist.m_currency;
    
    //入汇总
    InsertBcoutsndcl();
    
     //组签名串
	AddSign( oBeps134, m_strSendBank.c_str(), RAWSIGN); 
	   
	int iRet = oBeps134.CreateXml();
	if (0 != iRet)
	{
		
		sprintf(m_szErrMsg,"创建往账beps.134.001.01报文失败[%d]", iRet);
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, m_szErrMsg);
	}
	
    m_strMsgTxt = oBeps134.m_sXMLBuff;

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgTxt  = [%s]", m_strMsgTxt.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "len          = [%d]", m_strMsgTxt.length());

	//并更新处理状态为"已发送"
	sprintf(sSqlStr,"update bp_bcoutsendlist set procstate = '%s' "
            			" where msgid = '%s' and procstate = '%s' ", PR_HVBP_08,m_strMsgID.c_str(),PR_HVBP_95);
	
	iUpdCode = bcoutsendlist.execsql(sSqlStr);
	if (SQL_SUCCESS != iUpdCode) 
	{
		sprintf(m_szErrMsg, "oCBppkgassist.setstate:更新记明细表记录错, [%d][%s]",
			iUpdCode, bcoutsendlist.GetSqlErr()); 
		
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}
	
	//更新原借记汇总处理状态
	sprintf(sSqlStr,"update bp_bdsndcl set procstate = '%s' where msgid = '%s' ", 
	                PR_HVBP_07,m_strMsgID.c_str());
	
	iUpdCode = bcoutsendlist.execsql(sSqlStr);
	if (SQL_SUCCESS != iUpdCode) 
	{
		sprintf(m_szErrMsg, "oCBppkgassist.setstate:更新原借记汇总处理状态错, [%d][%s]",
			iUpdCode, bcoutsendlist.GetSqlErr()); 
		
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}
	
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendXmlPack::PackXml134()");
}

void CSendXmlPack::InsertBcoutsndcl()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendXmlPack::InsertBcoutsndcl()");
    
    SETCTX(m_cBpbcoutsndcl);

    m_cBpbcoutsndcl.m_workdate      = m_strWrkDate;//工作日期
    m_cBpbcoutsndcl.m_msgtp         = m_strMsgType;
    m_cBpbcoutsndcl.m_msgid         = m_strMsgID;//报文标识号/包序号
    m_cBpbcoutsndcl.m_mesgid        = m_sMsgRefId;//通信级标识号
    m_cBpbcoutsndcl.m_mesgrefid     = m_sMsgRefId;//通信级标识号参考号
    m_cBpbcoutsndcl.m_instgdrctpty  = m_strSendBank;//发起直接参与机构/付款清算行
    m_cBpbcoutsndcl.m_instddrctpty  = m_strRecvBank;//接收直接参与机构/收款清算行
    m_cBpbcoutsndcl.m_consigdate    = m_strMsgID.substr(0,8);//委托日期
    m_cBpbcoutsndcl.m_srcflag       = "0";//补发标志
    m_cBpbcoutsndcl.m_realtimeflag  = "0";//实时标志
    m_cBpbcoutsndcl.m_procstate     = PR_HVBP_08;//处理状态
    m_cBpbcoutsndcl.m_checkstate    = "1";//对账状态

    int iRet = m_cBpbcoutsndcl.insert();
    if(SUCCESSED!=iRet)
    {
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, 
            "m_cBpbcoutsndcl insert failed:[%d][%s]",iRet,m_cBpbcoutsndcl.GetSqlErr());
        PMTS_ThrowException(DB_INSERT_FAIL);
    }
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendXmlPack::InsertBcoutsndcl()");
}

void CSendXmlPack::InsertBdsndcl()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendXmlPack::InsertBdsndcl()");
    
    SETCTX(m_cBpbdsndcl);

    m_cBpbdsndcl.m_workdate      = m_strWrkDate;//工作日期
    m_cBpbdsndcl.m_msgtp         = m_strMsgType;
    m_cBpbdsndcl.m_msgid         = m_strMsgID; //报文标识号/包序号
    m_cBpbdsndcl.m_mesgid        = m_sMsgRefId;//通信级标识号
    m_cBpbdsndcl.m_mesgrefid     = m_sMsgRefId;//通信级标识号参考号
    m_cBpbdsndcl.m_instgdrctpty  = m_strSendBank;//发起直接参与机构/付款清算行
    m_cBpbdsndcl.m_instddrctpty  = m_strRecvBank;//接收直接参与机构/收款清算行
    m_cBpbdsndcl.m_consigdate    = m_strMsgID.substr(0,8);//委托日期
    m_cBpbdsndcl.m_srcflag       = "0";//补发标志
    m_cBpbdsndcl.m_realtimeflag  = "0";//实时标志
    m_cBpbdsndcl.m_procstate     = PR_HVBP_08;//处理状态
    m_cBpbdsndcl.m_checkstate    = "1";//对账状态

    int iRet = m_cBpbdsndcl.insert();
    if(SUCCESSED!=iRet)
    {
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, 
            "m_cBpbdsndcl insert failed: [%d][%s]",iRet,m_cBpbdsndcl.GetSqlErr());
        PMTS_ThrowException(DB_INSERT_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CSendXmlPack::InsertBdsndcl()");
}

