/******************************************************************** 
�ļ����� sendbeps720.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-03-07
�޸��ˣ� hq
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps720.h"


CSendBeps720::CSendBeps720(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
}

CSendBeps720::~CSendBeps720()
{
}

INT32 CSendBeps720::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "ENTER CSendBeps720::doWorkSelf");

    // �鱨��
    CreateXML720();

	CMcheckqry m_checkqry;
	m_checkqry.m_msgid = m_beps720.MsgId;
	m_checkqry.m_msgtype = "beps.720.001.01";
	m_checkqry.m_sapbank = m_beps720.InstgDrctPty;	
	m_checkqry.m_checkdate = m_beps720.ChckDt;

	SETCTX(m_checkqry);
	iRet = m_checkqry.insert();
	if( 0 != iRet)
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "INSERT CM_CHECKQRY FILED[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "INSERT CM_CHECKQRY FILED!");
	}

    // ���ͱ���
    AddQueue();
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "LEAVE CSendBeps720::doWorkSelf"); 
    return 0;
}

void CSendBeps720::AddSign720()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms720::AddSign720");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_beps720.getOriSignStr();
	
	AddSign(m_beps720.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_sSendOrg);
	
	m_beps720.m_szDigitSign = sSignedStr;

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms720::AddSign720");
}

void CSendBeps720::CreateXML720()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "ENTER CSendBeps720::CreateXML720");

    char MsgID[40] = {0};
    int iRet = 0;
    
    // ���ı�ʶ��
    if( !GetMsgIdValue(m_dbproc, MsgID, eMsgId,  SYS_BEPS, m_sSendOrg) )
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ȡ���ı�ʶ�Ŵ���");
        PMTS_ThrowException(PRM_FAIL);
    }

    // ���Ĳο���
    if( !GetMsgIdValue(m_dbproc, m_sMesgID, eRefId, SYS_BEPS, m_sSendOrg) )
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ȡ���Ĳο��Ŵ���");
        PMTS_ThrowException(PRM_FAIL);
    }

    // ��ֵ
    m_beps720.MsgId = MsgID;
    m_beps720.CreDtTm = m_sIsoWorkDate;
    m_beps720.InstgDrctPty = m_sSendOrg;
    m_beps720.GrpHdrInstgPty = m_sSendOrg;
    m_beps720.InstdDrctPty = "0000";
    m_beps720.GrpHdrInstdPty = "0000";
    m_beps720.SysCd = "BEPS";
    m_beps720.ChckDt = m_sMsgId;

    //��ǩ
    AddSign720();
    
    // �鱨��ͷ
    m_beps720.CreateXMlHeader("BEPS", \
                               m_sWorkDate, \
                               m_sSendOrg, \
                               "0000", \
                               "beps.720.001.01",  \
                               m_sMesgID);

    // �鱨��
    iRet = m_beps720.CreateXml();
    if( RTN_SUCCESS != iRet )        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }

    m_sMsgTxt = m_beps720.m_sXMLBuff;

    Trace(L_DEBUG,  __FILE__,  __LINE__, m_sMsgId, "m_sMsgTxt[%s]", m_sMsgTxt.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "LEAVE CSendBeps720::CreateXML720");
    return ;
}

