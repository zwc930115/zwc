
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "bpbcoutsndcl.h"
#include "bpbcoutrcvcl.h"
#include "bpbdsndcl.h"
#include "bpbdrcvcl.h"
#include "bpcolltnchrgscl.h"
#include "bpcolltnchrgslist.h"
#include "cmtransinfoqry.h"
#include "syscomsendmb.h"
#include "sysmbchkst.h"

#include "bpchkhelper.h"

CBpChkHelper::CBpChkHelper(void)
{
}

CBpChkHelper::~CBpChkHelper(void)
{
}

//__wsh 2012-11-02 ��������
int CBpChkHelper::ToBizTable(int iMode, LPCSTR szMT, LPCSTR szSR, LPCSTR szPT)
{
    Trace(L_INFO,  __FILE__, __LINE__,
				NULL, "Enter CBpChkHelper::ToBizTable");
#define EQUAL_MT(MT) strcmp(szMT, MT) == 0
#define LIKE_MT(MT)  strstr(szMT, MT) != NULL

	if(EQUAL_MT("PKG001") || EQUAL_MT("PKG003")  || EQUAL_MT("PKG005") ||
	   EQUAL_MT("PKG007") || EQUAL_MT("PKG008")  || EQUAL_MT("PKG010") ||
	   EQUAL_MT("PKG011") || LIKE_MT("beps.121") || LIKE_MT("beps.122") ||
	   LIKE_MT("beps.123")|| LIKE_MT("beps.125") || LIKE_MT("beps.128") ||
	   LIKE_MT("beps.130")|| LIKE_MT("beps.132") || LIKE_MT("beps.134")){
		//����
		m_iTblNo = TBL_CDTR;
		FillTable(iMode, szSR, "BP_BCOUTSNDCL", "BP_BCOUTSENDLIST",
				"BP_BCOUTRCVCL", "BP_BCOUTRECVLIST");				
	}
	else if(EQUAL_MT("PKG002") || EQUAL_MT("PKG004") || EQUAL_MT("PKG006") ||
			EQUAL_MT("PKG009") || LIKE_MT("beps.124") || LIKE_MT("beps.127") ||
			LIKE_MT("beps.131")|| LIKE_MT("beps.133")){
		//���
		m_iTblNo = TBL_DBTR;
		FillTable(iMode, szSR, "BP_BDSNDCL", "BP_BDSENDLIST",
				"BP_BDRCVCL", "BP_BDRECVLIST");
	}
	else if(EQUAL_MT("PKG012")  || LIKE_MT("beps.380") || LIKE_MT("beps.381") ||
			LIKE_MT("beps.382") || LIKE_MT("beps.383") || LIKE_MT("beps.384")||
			LIKE_MT("beps.385") || LIKE_MT("beps.386") || LIKE_MT("beps.387")){
		//���ո�
		m_iTblNo = TBL_COLL;
		FillTable(iMode, szSR, "BP_COLLTNCHRGSCL", "BP_COLLTNCHRGSLIST",
				"BP_COLLTNCHRGSCL", "BP_COLLTNCHRGSLIST");
	}
	else if(EQUAL_MT("CMT301")  || EQUAL_MT("CMT302") ||
			LIKE_MT("ccms.314") || LIKE_MT("ccms.315")){
		//��ѯ�鸴
		m_iTblNo = TBL_TXIQ;
		FillTable(iMode, szSR, "CM_TRANSINFOQRY", "CM_TRANSINFOQRY",
				"CM_TRANSINFOQRY", "CM_TRANSINFOQRY");
	}
	else{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "[%s]�Ҳ�����Ӧҵ���!", szMT);
		return RTN_FAIL;
	}
	
	if(iMode == MODE_CHECK_LIST){
    	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "��ϸ����[%s][%s]->(%s)(%s)",
    		        szMT, szSR, m_szTblNmCl, m_szTblNmList);
    }
    else{
        Trace(L_DEBUG, __FILE__, __LINE__, NULL, "���ܶ���[%s]->{(%s)(%s)}{%s)(%s)}",
		        szMT, m_szSTblNmCl, m_szSTblNmList, m_szRTblNmCl, m_szRTblNmList);
    }

    Trace(L_INFO,  __FILE__, __LINE__,
				NULL, "Leave CBpChkHelper::ToBizTable");
				
	return RTN_SUCCESS;
}

//__wsh 2012-11-02 ��������
void CBpChkHelper::FillTable(int iMode, LPCSTR szSR,
		LPCSTR STCL, LPCSTR STLIST, LPCSTR RTCL, LPCSTR RTLIST)
{

#define FILL_TABLE(BUFFER, SZTBL) snprintf(BUFFER, sizeof(BUFFER), SZTBL)

	if(iMode == MODE_CHECK_LIST){
		if(strcmp(szSR, TAG_SEND) == 0){
			FILL_TABLE(m_szTblNmCl,   STCL);
			FILL_TABLE(m_szTblNmList, STLIST);
		}
		else{
			FILL_TABLE(m_szTblNmCl,   RTCL);
			FILL_TABLE(m_szTblNmList, RTLIST);
		}
	}
	else if(iMode == MODE_CHECK_SUM){
		FILL_TABLE(m_szSTblNmCl,   STCL);
		FILL_TABLE(m_szSTblNmList, STLIST);
		FILL_TABLE(m_szRTblNmCl,   RTCL);
		FILL_TABLE(m_szRTblNmList, RTLIST);
	}
	else{

	}
}

//__wsh 2012-11-02 ��ѯ���ػ�����ϸҵ�� ״̬�� �� ��ϸ����
int CBpChkHelper::GetLocalBiz(string& strMsgTp, string& strMsgId, string& strInstgDrctPty, LPCSTR szSR, LPCSTR szPT)
{
	Trace(L_INFO,  __FILE__, __LINE__,
				NULL, "Enter CBpChkHelper::GetLocalBiz");
	int iRet = -1;
	
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "[%s][%s][%s]",
			strMsgTp.c_str(), strMsgId.c_str(), strInstgDrctPty.c_str());

	m_iLocalTtlCnt = 0;
	m_dLocalCtrlSum= 0.0;
	m_strLocalBizSt= "";

	iRet = ToBizTable(MODE_CHECK_LIST, strMsgTp.c_str(), szSR, szPT);

#define ISTABLE(TBL) strcmp(TBL, m_szTblNmCl) == 0

//__MACRO START__���Ǳ��ؼ�¼��ѯ��
#define FINDLOCALCBIZ(ENTITY) ENTITY o##ENTITY; SETCTX(o##ENTITY); \
	o##ENTITY.m_msgid        = strMsgId; \
	o##ENTITY.m_instgdrctpty = strInstgDrctPty; \
	iRet = o##ENTITY.findByPK(); \
	if(iRet == SQL_SUCCESS){ \
		m_dLocalCtrlSum = o##ENTITY.m_ctrlsuccsum; \
		m_strLocalBizSt = o##ENTITY.m_busistate; \
		m_iLocalTtlCnt  = o##ENTITY.m_nboftxs; \
		m_strLocalFinalStateDate = o##ENTITY.m_finalstatedate;\
	}
//__MACRO START__��Ǳ��ؼ�¼��ѯ��
#define FINDLOCALDBIZ(ENTITY) ENTITY o##ENTITY; SETCTX(o##ENTITY); \
	o##ENTITY.m_msgid        = strMsgId; \
	o##ENTITY.m_instgdrctpty = strInstgDrctPty; \
	iRet = o##ENTITY.findByPK(); \
	if(iRet == SQL_SUCCESS){ \
		m_dLocalCtrlSum = o##ENTITY.m_ctrlsum; \
		m_strLocalBizSt = o##ENTITY.m_busistate; \
		m_iLocalTtlCnt  = o##ENTITY.m_nboftxs; \
		m_strLocalFinalStateDate = o##ENTITY.m_finalstatedate;\
	}	
//__MACRO END__

	if( ISTABLE("BP_BCOUTSNDCL") ){//��������
		FINDLOCALCBIZ(CBpbcoutsndcl);
	}
	else if( ISTABLE("BP_BCOUTRCVCL") ){//��������
		FINDLOCALCBIZ(CBpbcoutrcvcl);
	}
	else if( ISTABLE("BP_BDSNDCL") ){//�������
		FINDLOCALDBIZ(CBpbdsndcl);
	}
	else if( ISTABLE("BP_BDRCVCL") ){//�������
		FINDLOCALDBIZ(CBpbdrcvcl);
	}
	else if( ISTABLE("BP_COLLTNCHRGSCL") ){//���ո�
		CBpcolltnchrgscl coll;
		SETCTX(coll);
		coll.m_msgid    = strMsgId;
		coll.m_instgpty = strInstgDrctPty;		

		if(strcmp(szSR, TAG_RECV) == 0
		   && strcmp(szPT, TAG_PT00) == 0)
		{	
			coll.m_srcflag	= "3";
		}
		else if(strcmp(szSR, TAG_RECV) == 0
		   && strcmp(strMsgTp.c_str(), "beps.381.001.01") == 0)
		{	
			coll.m_srcflag	= "3";
		}		
		else if(strcmp(szSR, TAG_RECV) == 0
		   && strcmp(strMsgTp.c_str(), "beps.385.001.01") == 0)
		{	
			coll.m_srcflag	= "3";
		}		
		else if(strcmp(szSR, TAG_RECV) == 0
		   && strcmp(strMsgTp.c_str(), "beps.383.001.01") == 0)
		{	
			coll.m_srcflag	= "2";
		}			
		else if(strcmp(szSR, TAG_RECV) == 0
		   && strcmp(strMsgTp.c_str(), "beps.387.001.01") == 0)
		{	
			coll.m_srcflag	= "2";
		}					
		else if(strcmp(szSR, TAG_RECV) == 0
		   && strcmp(szPT, TAG_PT01) == 0)
		{	
			coll.m_srcflag	= "2";
		}
		else
		{
			coll.m_srcflag	= "1";
		}

		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "msgid=[%s] instgpty=[%s] srcflag=[%s]", 
			            coll.m_msgid.c_str(),coll.m_instgpty.c_str(),coll.m_srcflag.c_str() );                

		iRet = coll.findByPK();
		if(iRet == SQL_SUCCESS){
			
			Trace(L_DEBUG, __FILE__, __LINE__, NULL, "have find"); 
				m_dLocalCtrlSum = coll.m_rcvsndgttlamt;
				m_strLocalBizSt = coll.m_busistate;
				m_strLocalFinalStateDate = coll.m_finalstatedate;

				CBpcolltnchrgslist collist;
				SETCTX(collist);
				string strsql = "MSGID = '" +coll.m_msgid+"' AND srcflag = '"+coll.m_srcflag+"' AND INSTGPTY='" +coll.m_instgpty +"'";
				iRet = collist.findcount(strsql);
				if(iRet == SQL_SUCCESS){
        	Trace(L_DEBUG, __FILE__, __LINE__, NULL,"collist.m_iCount[%d]", collist.m_iCount);				  
					m_iLocalTtlCnt = collist.m_iCount;
				}
				else{
        		Trace(L_ERROR, __FILE__, __LINE__, NULL,
        				"��ѯ����:%d",  iRet);
        		PMTS_ThrowException(DB_FIND_FAIL);				    
				}
		}
		else
		{
			Trace(L_DEBUG, __FILE__, __LINE__, NULL, "not find"); 

		}
		
	}
	else if(ISTABLE("CM_TRANSINFOQRY")){//��ѯ�鸴
		CCmtransinfoqry tiq;
		SETCTX(tiq);
		string strSql = "msgid='";
		strSql.append(strMsgId).append("' and instgindrctpty='");
		strSql.append(strInstgDrctPty).append("' and sysid='BEPS'");
		strSql += (strcmp(szSR, TAG_SEND) == 0 ? 
		            " and rsflag < '2'" : " and rsflag='2'");
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strSql=[%s]", strSql.c_str());                
		iRet = tiq.find(strSql);
		if(iRet == SQL_SUCCESS && (iRet = tiq.fetch()) == SQL_SUCCESS){
			m_strLocalBizSt = tiq.m_busistate;
			m_strLocalFinalStateDate = tiq.m_finalstatedate;
		}
		tiq.closeCursor();
	}

	if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[%s]��ѯ����:%d", m_szTblNmCl, iRet);
		PMTS_ThrowException(DB_FIND_FAIL);
	}

	Trace(L_INFO,  __FILE__, __LINE__,
				NULL, "Leave CBpChkHelper::GetLocalBiz");

	return iRet;
}

//__wsh 2012-11-02 ��ȡ���ػ�������
int CBpChkHelper::GetLocalSum(bool bIsPmt, string& strMsgTp, string& strSSql, string& strRSql)
{
	int iRet = -1;

	m_iLocalSTtlCnt = 0;
	m_iLocalRTtlCnt = 0;
	m_dLocalSTtlAmt = 0.0;
	m_dLocalRTtlAmt = 0.0;

	m_bIsPmt = bIsPmt;
	
	iRet = ToBizTable(MODE_CHECK_SUM, strMsgTp.c_str());
	
	if(strcmp(m_szSTblNmCl, "BP_BCOUTSNDCL") == 0 ||
	   strcmp(m_szSTblNmCl, "BP_BDSNDCL") == 0){
		iRet = GetDCSum(TAG_SEND, strSSql);
		iRet = GetDCSum(TAG_RECV, strRSql);
	}
	else if(strcmp(m_szSTblNmCl, "BP_COLLTNCHRGSCL") == 0){
		iRet = GetCollSum(TAG_SEND, strSSql);
		iRet = GetCollSum(TAG_RECV, strRSql);
	}
	else if(strcmp(m_szSTblNmCl, "CM_TRANSINFOQRY") == 0){
		iRet = GetTiqSum(TAG_SEND, strSSql);
		iRet = GetTiqSum(TAG_RECV, strRSql);
	}

	return iRet;
}

//__wsh 2012-11-02 ���ܱ���Ǽ�����ҵ��
int CBpChkHelper::GetDCSum(LPCSTR SR, string& strSql)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CBpChkHelper::DoSumCrdtDebt");

	int iRet = -1;

	//Ϊ�����޸Ĺ����ж���޸Ķ���ʵ����,�ݲ��û�����
//__MACRO START__ͳ�ƽ���ǻ��ܺ�
#define SUMCD721(ENTITY, SZTBL, SZSR) ENTITY o##ENTITY; SETCTX(o##ENTITY);\
	iRet = o##ENTITY.find(strSql); \
	if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND ){\
		Trace(L_ERROR, __FILE__, __LINE__, NULL, \
			"[%s]��ѯʧ��:%s", SZTBL, o##ENTITY.GetSqlErr());\
		PMTS_ThrowException(DB_FIND_FAIL);\
	}\
	while((iRet = o##ENTITY.fetch()) == SQL_SUCCESS){\
		if(strcmp(SZSR,TAG_SEND)==0){\
			++m_iLocalSTtlCnt; \
			if(m_bIsPmt){m_dLocalSTtlAmt += o##ENTITY.m_ctrlsum;}\
		}\
		else{\
			++m_iLocalRTtlCnt; \
			if(m_bIsPmt){m_dLocalRTtlAmt += o##ENTITY.m_ctrlsum;}\
		}\
	}\
	o##ENTITY.closeCursor();\
	if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND ){\
		Trace(L_ERROR, __FILE__, __LINE__, NULL, \
			"[%s]��ѯʧ��:%s", SZTBL, o##ENTITY.GetSqlErr());\
			PMTS_ThrowException(DB_FIND_FAIL);\
	}
//__MACRO END__

	if(strcmp(m_szSTblNmCl, "BP_BCOUTSNDCL") == 0){
		if(strcmp(SR, TAG_SEND) == 0){
			SUMCD721(CBpbcoutsndcl, m_szSTblNmCl, TAG_SEND);
		}
		else{
			SUMCD721(CBpbcoutrcvcl, m_szRTblNmCl, TAG_RECV);
		}
	}
	else if(strcmp(m_szSTblNmCl, "BP_BDSNDCL") == 0){
		if(strcmp(SR, TAG_SEND) == 0){
			SUMCD721(CBpbdsndcl, m_szSTblNmCl, TAG_SEND);
		}
		else{
			SUMCD721(CBpbdrcvcl, m_szRTblNmCl, TAG_RECV);
		}
	}

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CBpChkHelper::DoSumCrdtDebt");

	return iRet;
}

//__wsh 2012-11-02 ���ܴ��ո��౨��
int CBpChkHelper::GetCollSum(LPCSTR SR, string& strSql)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CBpChkHelper::GetCollSum");

	int iRet = -1;
	CBpcolltnchrgscl coll;
	SETCTX(coll);
	if(m_bIsPmt){//����������
		iRet = coll.find(strSql);
		if(iRet == SQL_SUCCESS){
			while((iRet = coll.fetch()) == SQL_SUCCESS){
				if(strcmp(SR, TAG_SEND) == 0){//����
					++m_iLocalSTtlCnt;
					m_dLocalSTtlAmt += coll.m_rcvsndgttlamt;
				}
				else{//����
					++m_iLocalRTtlCnt;
					m_dLocalRTtlAmt += coll.m_rcvsndgttlamt;
				}
			}
		}
	}
	else{//��Ϣ��
		iRet = coll.findcount(strSql);
		if(iRet == SQL_SUCCESS){
			strcmp(SR, TAG_SEND) == 0 ? m_iLocalSTtlCnt = coll.m_iCount :
					m_iLocalRTtlCnt = coll.m_iCount;

		}
	}

	if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND ){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
			"[%s]��ѯʧ��:%s", m_szSTblNmCl, coll.GetSqlErr());
		PMTS_ThrowException(DB_FIND_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CBpChkHelper::GetCollSum");

	return iRet;
}

//__wsh 2012-11-02 ���ܲ�ѯ�鸴ҵ��
int CBpChkHelper::GetTiqSum(LPCSTR SR, string& strSql)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CBpChkHelper::GetTiqSum");
	int iRet = -1;

	CCmtransinfoqry tiq;
	SETCTX(tiq);

	iRet = tiq.findcount(strSql);
	if(iRet == SQL_SUCCESS){
		if(strcmp(SR, TAG_SEND) == 0){//����
			m_iLocalSTtlCnt = tiq.m_iCount;
		}
		else{//����
			m_iLocalRTtlCnt = tiq.m_iCount;
		}
	}

	if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND ){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
			"[%s]��ѯʧ��:%s", m_szSTblNmCl, tiq.GetSqlErr());
		PMTS_ThrowException(DB_FIND_FAIL);
	}
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CBpChkHelper::GetTiqSum");

	return iRet;
}

//__wsh 2012-11-02 �жϱ����Ƿ�ҵ���౨��
bool CBpChkHelper::IsPmtMsg(const string& strMT)
{
    if(strMT == "beps.121.001.01" || strMT == "PKG001" || strMT == "PKG007" || 
       strMT == "beps.122.001.01" || strMT == "PKG008" || strMT == "PKG011" ||
       strMT == "beps.125.001.01" || strMT == "PKG007" || strMT == "PKG005" ||
       strMT == "beps.128.001.01" || strMT == "PKG009" || strMT == "PKG011" ||
       strMT == "beps.130.001.01" || strMT == "PKG010" || strMT == "PKG012" ||
       strMT == "beps.132.001.01" || strMT == "beps.134.001.01" ||
       strMT == "beps.381.001.01" || strMT == "beps.383.001.01" ||
       strMT == "beps.385.001.01" || strMT == "beps.387.001.01"){
        return true;
    }
    else{
        return false;
    }
}

//__wsh 2012-11-02 ��ʼ����Ҫ�������ڶ��˼�¼���ڶ���״̬
//strSqlBank: ����������
//strChkDt: �������� ��ʽyyyy-mm-dd
int CBpChkHelper::InitBizMbCheckState(const string& strSapBank, const string& strChkDt)
{
    Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CBpChkHelper::InitBizMbCheckState");
	
	int iRet = -1;
	
	char szSql[1024]  = {0};
	char szChkDt[32] = {0};
	chgToDate(strChkDt.c_str(), szChkDt);
	
	CEntityBase entity;
	SETCTX(entity);
	
	//��������, ע�� �������˲��������
	const char* szSendTbl[] = {"bp_bcoutsendlist", "bp_bcoutsendlisthis"};
	for(int si = 0; si < 2; ++si){
	    memset(szSql, 0x00, sizeof(szSql));
	    snprintf(szSql, sizeof(szSql), 
    	     " update %s set mbcheckstate='00', statetime=sysdate "
    	     " where instgdrctpty='%s' and (finalstatedate='%s' or   "
    	     " consigdate='%s') and srcflag='0' and procstate<>'53' ",
    	     szSendTbl[si], strSapBank.c_str(), strChkDt.c_str(), szChkDt);
    	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__szSql=[%s]", szSql);
	    iRet = entity.execsql(szSql);
	    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__iRet=[%d]", iRet);
	    if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND){
	        Trace(L_ERROR, __FILE__, __LINE__, NULL, 
	            "[%s]����ʧ��:[%s]", szSendTbl[si], entity.GetSqlErr());
	        PMTS_ThrowException(DB_UPDATE_FAIL);
	    }
	}
	
	//��������
	const char* szRecvTbl[] = {"bp_bcoutrecvlist", "bp_bcoutrecvlisthis"};
	for(int ri = 0; ri < 2; ++ri){
	    memset(szSql, 0x00, sizeof(szSql));
	    snprintf(szSql, sizeof(szSql), 
    	     " update %s set mbcheckstate='00', statetime=sysdate "
    	     " where instddrctpty='%s' and (finalstatedate='%s' or consigdate='%s') "
    	     " and msgtp in('PKG001', 'PKG005', 'PKG007', 'beps.121.001.01', "
    	     " 'beps.122.001.01', 'beps.125.001.01') ", 
    	     szRecvTbl[ri], strSapBank.c_str(), strChkDt.c_str(), szChkDt);
    	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__szSql=[%s]", szSql);     
	    iRet = entity.execsql(szSql);
	    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__iRet=[%d]", iRet);
	    if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND){
	        Trace(L_ERROR, __FILE__, __LINE__, NULL, 
	            "[%s]����ʧ��:[%s]", szRecvTbl[ri], entity.GetSqlErr());
	        PMTS_ThrowException(DB_UPDATE_FAIL);
	    }
	}
	
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CBpChkHelper::InitBizMbCheckState");
	
	return RTN_SUCCESS;		
}

//__wsh 2012-11-02 ����С�������״̬���Ķ���״̬
//strSqlBank: ����������
//strChkDt  : �������� ��ʽyyyy-mm-dd
//szSts     : ����״̬ 2n
int CBpChkHelper::UpdateBChkState(const string& strSapBank, const string& strChkDt, LPCSTR szSts,int iDetailNm, int iRcvNm)
{
    Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CBpChkHelper::UpdateBChkState");
			
    int iRet = -1;
    CEntityBase entity;
    SETCTX(entity);
    char szSql[256] = {0};
    snprintf(szSql, sizeof(szSql), 
            " update bp_bchkstate set checkstate='%s', statetime=sysdate, detailnm = %d, rcvnm = %d "
            " where chkdate='%s' and pkbknode='%s' ",
            szSts ,iDetailNm, iRcvNm ,strChkDt.c_str(), strSapBank.c_str());
            
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__szSql=[%s]", szSql);     
	iRet = entity.execsql(szSql);
    if(iRet != SQL_SUCCESS){
        Trace(L_ERROR, __FILE__, __LINE__, NULL, 
            "[bp_bchkstate]����ʧ��:[%s]", entity.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }
    
    Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CBpChkHelper::UpdateBChkState");	
				
    return iRet;
}



