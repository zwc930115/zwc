/******************************************************************** 
文件名： recvbepsbase.cpp
创建人： zhj
日  期： 2011-03-03
修改人： 
日  期： 
描  述： beps来帐处理基类 
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "ccms990.h"
#include "recvbepsbase.h"
#include "cmtfileoperator.hpp"
#include "sysmsgonlinectrl.h"
#include "bpcomsendmb.h"
#include "bpcstctrctmg.h"
#include "bpmbfecfg.h"
#include "bppkgassist.h" 
#include "bppkgassist1.h" 
#include "syssysparm.h"
#include "rout.h"
using namespace ZFPT;

extern char		g_MQmgr[256];
extern char		g_MqTxtPath[256];
extern char		g_SendQueue[128];
extern char		g_SendCCMSQueue[128];
extern int      g_iCfcaSign;
extern CMutex g_Mutex;
extern int          g_pkgpack;
extern char        g_SapBank[17];
extern Rout    *g_rout;
extern char        g_msgpath[128];

CRecvBepsBase::CRecvBepsBase()
{
    m_strBizCode	= "";
    m_strRcvMsgID	= "";
    m_strMsgID		= "";
    m_bIfOptBigData = true;
    memset(m_szErrMsg, 0, sizeof(m_szErrMsg));
	memset(m_szOprUser, 0x00, sizeof(m_szOprUser));
	memset(m_szOprUserNetId,0x00, sizeof(m_szOprUserNetId));
    memset(m_sWorkDate, 0x00, sizeof(m_sWorkDate));
    m_strWorkDate	= "";
    m_iMsgVer		= 0;
    m_strMsgTp		= "";
	m_szOriSign		= "";
	iRet            = -1;
	m_strSendMsg    = "";
	memset(m_sCommHead, 0x00, sizeof(m_sCommHead));
	
	memset(m_szIngoingDetailTable, 0x00, sizeof(m_szIngoingDetailTable));
	memset(m_szPmtTpPrtry, 0x00, sizeof(m_szPmtTpPrtry));
    m_agreeanduser = true;
    m_IsSendMB = true;
}

CRecvBepsBase::~CRecvBepsBase()
{

}

void CRecvBepsBase::SetFieldAsGbk(const string& strVal, char* szField, int iLen)
{
    if(szField == NULL || iLen < 1 || strVal.length() < 1){
        return;
    }

    int iBufLen = strVal.length()+1;
    char* pBuffer = new char[iBufLen];
    if(pBuffer == NULL){
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "__Alloc Memory Failed!");
        return;
    }

    memset(pBuffer, 0x00, iBufLen);
    if(IsUTF8((char*)strVal.c_str(), strVal.length())){
        if(!changeEncode((char*)strVal.c_str(), pBuffer, "UTF-8", "GB18030")){
            Trace(L_ERROR, __FILE__, __LINE__, NULL, "__Encode Failed!");
        }
    }
    else{
        strncpy(pBuffer, strVal.c_str(), iBufLen-1);
    }
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__pBuffer=[%s]", pBuffer);
    strncpy(szField, pBuffer, iLen);
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__szField=[%s]", szField);
    delete[] pBuffer;
    pBuffer = NULL;
}

void CRecvBepsBase::SetFieldAsUtf8(const char* szField, string& strDst)
{
    int iLen = strlen(szField);
    //if( !IsUTF8(szField, iLen) ){
    if( 1 ){
        char* pBuffer = new char[iLen*3+1];
        memset(pBuffer, 0x00, iLen*3+1);
        if(!changeEncode((char*)szField, pBuffer, "GB18030", "UTF-8")){
            Trace(L_DEBUG, __FILE__, __LINE__,
                NULL, "GB18030->UTF-8 Failed!");
            if(!changeEncode((char*)szField, pBuffer, "GBK", "UTF-8")){
                Trace(L_DEBUG, __FILE__, __LINE__,
                    NULL, "GBK->UTF-8 Failed!");
            }
        }
        strDst = pBuffer;
        delete[] pBuffer;
        pBuffer = NULL;
    }
    else{
        strDst = szField;
    }
}

/******************************************************************
当有不定长字段时,不要使用此函数,但可以使用表示长度的字段放在iArrary相应下标位置仍可使用.见recvpkg002,"30102"时的用法
strPmttpprtry 业务种类
iArray 业务附加字段中除循环以上的所有字段长度值,不要加循环长度
iArraySize 数组下标值
iNum   有循环的附加域时,填明细数目
iLen   有循环的附加域时,填单笔明细长度
hdf/20110711
******************************************************************/
void CRecvBepsBase::AddAppData(string& strPmttpprtry, int iArray[], const char* strAppData, string& szDstData, int iArraySize, int iNum, int iLen)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBepsBase::AddAppData...");
    
    int offset = 0;
    int j = 0;
    
    if ( "00102" == strPmttpprtry )
    {
	    for (int i=1; i<=iArraySize; i++)
	    {
	        char cDst[512] = {0};
	        memcpy(cDst, strAppData + offset, iArray[i-1]);
	        offset+=iArray[i-1];
	        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cDst[%s][%d]", cDst, iArray[i-1]);
	        if(0 != strcmp(cDst, ""))
	        {
	            szDstData+=":72C:";
	            if (15 == iArray[i-1])
	            {
	            	szDstData+="RMB";
	            }
	            szDstData.append(cDst);        
	        }
	    }
    }
    else if ( "00103" == strPmttpprtry || "00113" == strPmttpprtry )
    {
	    for (int i=1; i<=iArraySize; i++)
	    {
	        char cDst[512] = {0};
	        memcpy(cDst, strAppData + offset, iArray[i-1]);
	        offset+=iArray[i-1];
	        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cDst[%s][%d]", cDst, iArray[i-1]);
	        if(0 != strcmp(cDst, ""))
	        {
	            szDstData+=":72C:";
	            if (18 == iArray[i-1])
	            {
	            	szDstData+="RMB";
	            }
	            szDstData.append(cDst);        
	        }
	    }
	
	    if (iNum > 0)
	    {
	        for (int i = 1; i<=iNum; i++)
	        {
	            char cDst[512] = {0};
	            iLen = 10;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	            iLen = 20;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	            iLen = 18;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData+="RMB";
	            szDstData.append(cDst);
	        }
	    }
    }
    else if ( "20103" == strPmttpprtry || "20104" == strPmttpprtry || 
    		  "20003" == strPmttpprtry || "20004" == strPmttpprtry)
    {
	    for (int i=1; i<=iArraySize; i++)
	    {
	        char cDst[512] = {0};
	        memcpy(cDst, strAppData + offset, iArray[i-1]);
	        offset+=iArray[i-1];
	        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cDst[%s][%d]", cDst, iArray[i-1]);
	        if(0 != strcmp(cDst, ""))
	        {
	            szDstData+=":72C:";
	            if (18 == iArray[i-1])
	            {
	            	szDstData+="RMB";
	            }
	            szDstData.append(cDst);        
	        }
	    }
	
	    if (iNum > 0)
	    {
	        for (int i = 1; i<=iNum; i++)
	        {
	            char cDst[512] = {0};
	            iLen = 15;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	            iLen = 20;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	            iLen = 20;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	            iLen = 1;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	            iLen = 18;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData+="RMB";
	            szDstData.append(cDst);
	        }
	    }
    }
    else if ( "30102" == strPmttpprtry )
    {
	    for (int i=1; i<=iArraySize; i++)
	    {
	        char cDst[512] = {0};
	        memcpy(cDst, strAppData + offset, iArray[i-1]);
	        offset+=iArray[i-1];
	        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cDst[%s][%d]", cDst, iArray[i-1]);
	        if(0 != strcmp(cDst, ""))
	        {
	            szDstData+=":72C:";
	            if (15 == iArray[i-1])
	            {
	            	szDstData+="RMB";
	            }
	            szDstData.append(cDst);        
	        }
	    }
    }
    else if ( "30103" == strPmttpprtry )
    {
	    for (int i=1; i<=iArraySize; i++)
	    {
	        char cDst[512] = {0};
	        memcpy(cDst, strAppData + offset, iArray[i-1]);
	        offset+=iArray[i-1];
	        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cDst[%s][%d]", cDst, iArray[i-1]);
	        if(0 != strcmp(cDst, ""))
	        {
	            szDstData+=":72C:";
	            if (15 == iArray[i-1])
	            {
	            	szDstData+="RMB";
	            }
	            szDstData.append(cDst);        
	        }
	    }
    }
    else if ( "20005" == strPmttpprtry || "20105" == strPmttpprtry )
    {
	    for (int i=1; i<=iArraySize; i++)
	    {
	        char cDst[512] = {0};
	        memcpy(cDst, strAppData + offset, iArray[i-1]);
	        offset+=iArray[i-1];
	        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cDst[%s][%d]", cDst, iArray[i-1]);
	        if(0 != strcmp(cDst, ""))
	        {
	            szDstData+=":72C:";
	            if (18 == iArray[i-1])
	            {
	            	szDstData+="RMB";
	            }
	            szDstData.append(cDst);        
	        }
	    }
	
	    if (iNum > 0)
	    {
	        for (int i = 1; i<=iNum; i++)
	        {
	            char cDst[512] = {0};
	            iLen = 12;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	            iLen = 12;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	            iLen = 18;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData+="RMB";
	            szDstData.append(cDst);
	            iLen = 12;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	            iLen = 18;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData+="RMB";
	            szDstData.append(cDst);
	        }
	    }
    }
    else
    {
	    for (int i=1; i<=iArraySize; i++)
	    {
	        char cDst[512] = {0};
	        memcpy(cDst, strAppData + offset, iArray[i-1]);
	        offset+=iArray[i-1];
	        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cDst[%s][%d]", cDst, iArray[i-1]);
	        if(0 != strcmp(cDst, ""))
	        {
	            szDstData+=":72C:";
	            szDstData.append(cDst);        
	        }
	    }
	
	    if (iNum > 0)
	    {
	        for (int i = 1; i<=iNum; i++)
	        {
	            char cDst[512] = {0};
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	        }
	    }
	}

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBepsBase::AddAppData...");
}

int CRecvBepsBase::AddSign(const char *srcSign, char *dstSign, int iFlag, const char * pSendSapbank)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBepsBase::AddSign...");

    char *Str = new char[strlen(srcSign) + 1];
    ISNULL(Str);
    strcpy(Str, srcSign);
    int iRet = digitSign(m_dbproc, signTrim(Str), dstSign, SYS_BEPS, iFlag, pSendSapbank);
    DELPOINT(Str);
	if( RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "数字签名加签失败");
		PMTS_ThrowException(OPT_DIGITSIGN_FAIL);
	}
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBepsBase::AddSign...");
    return RTN_SUCCESS;
}
void CRecvBepsBase::AddSign(const char *srcSign, char *dstSign, int iFlag)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBepsBase::AddSign...");
    
    if (g_iCfcaSign != 0)
    {
        char *Str = new char[strlen(srcSign) + 1];
        ISNULL(Str);
        strcpy(Str, srcSign);
        int iRet = digitSign(m_dbproc, signTrim(Str), dstSign, SYS_BEPS, iFlag);
        DELPOINT(Str);
        if( RTN_SUCCESS != iRet)
        {
            Trace(L_ERROR, __FILE__, __LINE__, NULL, "数字签名加签失败!");
            PMTS_ThrowException(OPT_DIGITSIGN_FAIL);
        }
    }
    	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBepsBase::AddSign...");

}

void CRecvBepsBase::CheckSign(const char *srcSign, const char *dstSign, const char * sSendBankCode, int iFlag)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBepsBase::CheckSign...");
    
    if (g_iCfcaSign != 0)
    {
        string strSendBankCode = sSendBankCode;
    	
        char *Str = new char[strlen(srcSign) + 1];
        ISNULL(Str);
        strcpy(Str, srcSign);
        int iRet = checkSign(m_dbproc,signTrim(Str),
                                (char *)dstSign,
                                Trim(strSendBankCode).c_str(),
                                iFlag);
        DELPOINT(Str);
	    if( RTN_SUCCESS != iRet)
	    {
		    Trace(L_ERROR, __FILE__, __LINE__,NULL, "数字签名验证未通过!");
		    PMTS_ThrowException(__FILE__, __LINE__, OPT_CHECKSIGN_FAIL, "数字签名验证未通过");
	    }
    }

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBepsBase::CheckSign...");

}

int CRecvBepsBase::AddQueue(string msgtx, int length)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBepsBase::AddQueue...");
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "消息内容:msgtx = %s", msgtx.c_str());

    int iRet = m_cMQAgent.PutMsg(g_SendQueue, msgtx.c_str(), length);
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "往MQ发送消息失败！");
		PMTS_ThrowException(OPT_MQ_ADD_FAIL);
	}
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBepsBase::AddQueue...");
    return iRet;
}

void CRecvBepsBase::Init()
{
    int iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS, g_SapBank);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");	
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
}

void CRecvBepsBase::SetFieldAsUtf8(char* szField, string& strDst)
{
    int iLen = strlen(szField);
    //if( !IsUTF8(szField, iLen) ){    
    if( 1 ){
        char* pBuffer = new char[iLen*3+1];
        memset(pBuffer, 0x00, iLen*3+1);
        if(!changeEncode(szField, pBuffer, "GB18030", "UTF-8")){
        	Trace(L_DEBUG, __FILE__, __LINE__,
        			NULL, "GB18030->UTF-8 Failed!");
            if(!changeEncode(szField, pBuffer, "GBK", "UTF-8")){
            	Trace(L_DEBUG, __FILE__, __LINE__,
            	        	NULL, "GBK->UTF-8 Failed!");
            }
        }
        strDst = pBuffer;
        delete[] pBuffer;
        pBuffer = NULL;
    }
    else{
        strDst = szField;
    }
}
INT32 CRecvBepsBase::doChildWork(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBepsBase::doChildWork()");	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "i get a msg[%s]", pchMsg);		

    int iRet = 0;
    char sRet[15 + 1] = { 0 };
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS, g_SapBank);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");	
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }

	
    //4、子业务入口
    iRet = Work(pchMsg);
    if (SUCCESSED != iRet) /*成功:*/
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "子业务处理失败!iRet = [%d]",iRet);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBepsBase::doChildWork()");	

    return iRet;
}


INT32 CRecvBepsBase::doWork(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBepsBase::doWork()");	

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "i get a msg[%s]", pchMsg);		

    int iRet = 0;
    char sRet[15 + 1] = { 0 };
    try
    {	
    	//1、获取连接
    	//GetMqConn();
		
        //2、获取连接
        //GetDBConnect();

        Init();

		//3、回应990
    	Send990(pchMsg);

		//delete begin by jienjun 20161111	question  332  the msg 721,723,725 send to TOPS from progress routrecv
		#if 0
		//ɧ¹�֋`Ј½«±¨τЈ·¢¸�£¬ҵϱ´¦mº󲼔ٷ¢̍
	    if( "720" == m_strBizCode ||
			"723" == m_strBizCode ||
			"725" == m_strBizCode)
	    {
			if (SUCCESSED != g_rout->PutMsg(pchMsg))
			{
				   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "往MQ发送消息失败！");
				   PMTS_ThrowException(OPT_MQ_ADD_FAIL);			
			}
		}
		#endif
		//delete end by jienjun 20161111	question  332  the msg 721,723,725 send to TOPS from progress routrecv

		
        //4、子业务入口
        iRet = Work(pchMsg);
        if (SUCCESSED != iRet) /*成功:*/
        {
            Trace(L_ERROR, __FILE__, __LINE__, NULL, "子业务处理失败!iRet = [%d]",iRet);
        }

		//modify begin by jienjun 20161111	question  332  the msg 721,723,725 send to TOPS from progress routrecv
	    //if( "720" != m_strBizCode &&
		if( "721" != m_strBizCode &&	    
			"723" != m_strBizCode &&
			"725" != m_strBizCode)
	    {
			if (true == m_IsSendMB)
			{
				 if (SUCCESSED != g_rout->PutMsg(pchMsg))
				 {
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "往MQ发送消息失败！");
					PMTS_ThrowException(OPT_MQ_ADD_FAIL);			 
				 }
			}
		}
		//modify end by jienjun 20161111	question 332   the msg 721,723,725 send to TOPS from progress routrecv
		 
        SETCTX(m_cBprecvmsg);
        m_bIfOptBigData = true;    // 操作大文本表

        //暂时注释,后期解开.
        DelBpRecvMsg();            // 删除小额来帐通讯表数据:这里失败，暂不处理
        m_cBprecvmsg.commit(); 
		m_cMQAgent.Commit();
    }
    catch(CException &e)
    {        
        sprintf(m_szErrMsg, "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);

		m_cMQAgent.Commit();
        //异常处理
       iRet = DoException(pchMsg, e.code(), e.what());

    }
    catch(CT_CommException &e)
    {
        sprintf(m_szErrMsg, "parser msg error,error info:[%s] file:[%s] line:[%d]" ,e.GetErrInfo(),e.GetFileNameEx(),e.GetLine());
    
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_szErrMsg);
        m_cMQAgent.Commit();

        iRet = DoException(pchMsg, OPT_PRS_MSG_FAIL, e.GetErrInfo());
    }
    catch(...)
    {
         Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "未知异常截获！ " );
         m_cMQAgent.Commit();
         iRet = DoException(pchMsg, OTH_ERR, "未知异常！");
    }

	//5、释放连接
	//g_DBConnPool->PutConnect(m_dbproc); 

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBepsBase::doWork()");	

    return iRet;
}


/******************************************************************************
*  Function:   GetDBConnect
*  Description:获取数据库连接
*  Input:      无
*  Output:     无
*  Return:     无
*  Others:     无
*  Author:     zys
*  Date:       2011-03-01
*******************************************************************************/
void CRecvBepsBase::GetDBConnect(void)
{
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBepsBase::GetDBConnect()");	
	    char	sSapBank[14 + 1]	= { 0 };
	    int bRet = 0;
    if(0 == g_DBConnPool->GetConnect(m_dbproc))
    {

	    bRet = GetSysParam(m_dbproc,"01", sSapBank);
	    if(bRet !=0)
	    {
				if(0 == g_DBConnPool->DBReconnect(m_dbproc))
				{
					bRet = GetSysParam(m_dbproc,"01", sSapBank);
					if(!bRet)
					{
						snprintf(m_szErrMsg, sizeof(m_szErrMsg), "CRecvBepsBase::GetDBConnect():获取数据库连接失败");
						Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
						PMTS_ThrowException(DB_CNNCT_FAIL);
					}
				}
				else
				{
						snprintf(m_szErrMsg, sizeof(m_szErrMsg), "CRecvBepsBase::GetDBConnect():获取数据库连接失败");
						Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
						PMTS_ThrowException(DB_CNNCT_FAIL);
				}		
	    }
		}
		else
		{
				if(0 == g_DBConnPool->DBReconnect(m_dbproc))
				{
					bRet = GetSysParam(m_dbproc,"01", sSapBank);
					if(bRet !=0)
					{
						snprintf(m_szErrMsg, sizeof(m_szErrMsg), "CRecvBepsBase::GetDBConnect():获取数据库连接失败");
						Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
						PMTS_ThrowException(DB_CNNCT_FAIL);
					}
				}
				else
				{
						snprintf(m_szErrMsg, sizeof(m_szErrMsg), "CRecvBepsBase::GetDBConnect():获取数据库连接失败");
						Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
						PMTS_ThrowException(DB_CNNCT_FAIL);
				}		
		}

	m_charge.m_dbproc = m_dbproc;	//初始化记账类
	
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBepsBase::GetDBConnect()");
}

/******************************************************************************
*  Function:   GetMqConn
*  Description:获取MQ连接
*  Input:      无
*  Output:     无
*  Return:     无
*  Others:     无
*  Author:     zys
*  Date:       2011-03-01
*******************************************************************************/
void CRecvBepsBase::GetMqConn(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBepsBase::GetMqConn()");	
	
	 //初始化MQ
    if(0 != m_cMQAgent.Init(g_MQmgr, g_MqTxtPath))
    {
    	snprintf(m_szErrMsg, sizeof(m_szErrMsg), 
			"CRecvBepsBase::GetMqConn(),Init Thread MQ manager failed.");
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		
        PMTS_ThrowException(OPT_GET_MQ_CNNCT_FAIL);
    }
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBepsBase::GetMqConn()");		
}


/******************************************************************************
*  Function:   DelBpRecvMsg
*  Description:从大额来帐通讯表hv_recvmsg里删除对应m_sMsgID的信息
*  Input:      无
*  Output:     无
*  Return:     0   : 操作成功,
               其他: 操作失败
*  Others:     无
*  Author:     zys
*  Date:       2011-02-17
*******************************************************************************/
INT32 CRecvBepsBase::DelBpRecvMsg(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBepsBase::DelBpRecvMsg");	

    // 若m_strRcvMsgID为空，则无法对应到bp_recvmsg中的记录
    if ("" == m_strRcvMsgID)
    {
        return RTN_FAIL;
    }

    if(m_iErrMsgFlag)
    {
        if( 0 != DelMsgFile(m_strRcvMsgID.c_str()))
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "del file [%s] failed",m_strRcvMsgID.c_str());
            PMTS_ThrowException(DB_DEL_FAIL);
        } 
        
        if(RTN_SUCCESS != DelRecvErrmsg(m_dbproc, m_iErrMsgFlag))
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "del row [%d] failed",m_iErrMsgFlag);
            PMTS_ThrowException(DB_DEL_FAIL);
        }

    }
    else
    {
        string strMsgFile = g_msgpath;
        strMsgFile += "/";
        strMsgFile += m_strRcvMsgID;
        
        if( 0 != DelMsgFile(strMsgFile.c_str()))
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "del file [%s] failed",strMsgFile.c_str());
            PMTS_ThrowException(DB_DEL_FAIL);
        } 

    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBepsBase::DelBpRecvMsg");	

    return RTN_SUCCESS;
}

INT32 CRecvBepsBase::DoException(LPCSTR pchMsg, int nErrCode, LPCSTR pchErrDesc)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBepsBase::DoException");	

    if(nErrCode == DB_CNNCT_FAIL)
    {
        //连接数据库失败，暂时不做任务操作
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "error:MB_PFR0020:[%s]", m_strRcvMsgID.c_str());
        return RTN_SUCCESS;
    }

    // 回滚数据库
    int iRet = m_cBprecvmsg.setctx(m_dbproc);	
    if (0 != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error:%d", iRet);	
        return iRet;
    }
    m_cBprecvmsg.rollback();

    if(m_iErrMsgFlag != 0)
    {
        iRet = UpdateRecvErrmsg(m_dbproc, m_iErrMsgFlag);
        if(RTN_SUCCESS != iRet)
        {
            Trace(L_FATAL,  __FILE__,  __LINE__, NULL, "更改状态失败,写错误文件,客户端上看不到这条记录!!");
            WriteErrFile(pchMsg);
            return iRet;
        }
        
        m_cBprecvmsg.commit();
        return RTN_SUCCESS;
    }
    
    // 写小额来帐异常表
    if (0 == WriteErrTable(pchMsg, nErrCode, pchErrDesc))
    {
        m_bIfOptBigData = false;  // 不操作大文本表
        m_cBprecvmsg.commit();
    }
    // 写小额来帐异常表失败，写入文件
    else
    {
        m_cBprecvmsg.rollback();
        WriteErrFile(pchMsg);  // 写文件
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBepsBase::DoException");
    return RTN_SUCCESS;
}

/******************************************************************************
*  Function:   WriteErrTable
*  Description:小额异常来帐表hv_recverrmsg插入记录
*  Input:      iInputErrCode 错误码
*  Output:	   
*  Return:	   0   : 操作成功,
			   其他: 操作失败
*  Others:	   无
*  Author:	   zys
*  Date:	   2011-02-21
*******************************************************************************/
INT32 CRecvBepsBase::WriteErrTable(LPCSTR pchMsg, int nErrCode, LPCSTR pchErrDesc)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBepsBase::WriteErrTable");

	int iRet = -1;

    // 错误码为空
    if (NULL == pchErrDesc || "" == m_strRcvMsgID)
    {
        return RTN_FAIL;
    }
    
	// 设置连接
	iRet = m_cCmrecverrmsg.setctx(m_dbproc);	
	if (0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error:%d", iRet);	
		return iRet;
	}

    // 获取工作日期
    char sWorkDate[8 + 1];
    char sCode[10]= {0};
    memset(sWorkDate, 0x00, sizeof(sWorkDate));
    GetWorkDate(m_dbproc, sWorkDate, SYS_BEPS);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "sWorkDate = %s", sWorkDate);

    // 给小额来帐异常表字段赋值
    m_cCmrecverrmsg.m_syscode    = "BEPS";
    //m_cCmrecverrmsg.m_msgtext    = pchMsg;

    m_cCmrecverrmsg.m_msgtext    = g_msgpath;
    m_cCmrecverrmsg.m_msgtext    += "/";
    m_cCmrecverrmsg.m_msgtext    += m_strRcvMsgID;
    
    m_cCmrecverrmsg.m_wrkdate    = sWorkDate;
    m_cCmrecverrmsg.m_msgtp      = m_ErrMsgTp; 
    m_cCmrecverrmsg.m_procstate  = "00"; 
    m_cCmrecverrmsg.m_proctimes  = 1; 
    m_cCmrecverrmsg.m_errcode    = itoa(sCode,nErrCode); 
    m_cCmrecverrmsg.m_errdesc    = pchErrDesc;

	// 往小额来帐异常表插入记录
	iRet = m_cCmrecverrmsg.insert();
	if (0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
            "m_cCmrecverrmsg.insert error:error code =[%d],error info = [%s]", iRet,m_cCmrecverrmsg.GetSqlErr());
		return iRet;
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBepsBase::WriteErrTable");

	return RTN_SUCCESS;
}

INT32 CRecvBepsBase::WriteErrFile(const char * pchErrText)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBepsBase::WriteErrFile()");

    time_t timep;
    struct tm *p;
    time(&timep);
    p = gmtime(&timep);

    char szchPathName[gc_nMaxPathLen] = {0};

    sprintf(szchPathName, "../errmsg/%d/%d/%d/beps/", p->tm_year + 1900, p->tm_mon + 1, p->tm_mday);

	bool bRet = createDeepDir(szchPathName);
    if(!bRet)
    {
        printf("异常文件目录创建失败!\n");
        return RTN_FAIL;
    }

    FILE* msgFile = NULL;

    char szchTime[8 + 1] = {0};
    sprintf(szchTime, "%02d%02d%02d", p->tm_hour, p->tm_min, p->tm_sec);
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "szchTime:%s", szchTime);
	
    string strFileName = szchPathName;
    strFileName += "beps";
    strFileName += "-";
    strFileName += m_strBizCode;
    strFileName += "-";
    strFileName += m_strMsgID;
    strFileName += "-";
    strFileName += szchTime;
    strFileName += ".txt";

    if (NULL != (msgFile = fopen(strFileName.c_str(), "w+")))
    {
        fprintf(msgFile, "%s", pchErrText);
        fclose(msgFile);
    }
    else
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "写异常文件失败");
        return RTN_FAIL;
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBepsBase::WriteErrFile()");

    return RTN_SUCCESS;
}


void CRecvBepsBase::Send990(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBepsBase::Send990()");

	ccms990	oCcms990;
	
	char	sMsgRefId[20 + 1]	= { 0 };

	char	sOrignSender[14 + 1]= { 0 };
	char	sOrignReceiver[14 + 1]= { 0 };
	char	sOrignSendDate[8 + 1]={ 0 };
	char	sOrignMsgType[20 + 1]={ 0 };
	char	sOrignMesgID[35 + 1]= { 0 };
	char	sOrignRefId[35 + 1] = { 0 };
    
	GetMsgIdValue(m_dbproc, sMsgRefId, eRefId, SYS_BEPS, g_SapBank, NULL, m_sWorkDate);

    //判断报文是一代还是二代
	//m_iMsgVer =  JudgeMsgVer(pchMsg);   work类里已经判断过
    
	//组报头
	if(MSG_VER_2ND == m_iMsgVer)
	{

		oCcms990.m_PMTSHeader.ParsePMTSMsgHeader(pchMsg);

		strncpy(sOrignSender, oCcms990.m_PMTSHeader.getOrigSender(), sizeof(sOrignSender)-1);
		strcpy(sOrignSendDate, oCcms990.m_PMTSHeader.getOrigSendDate());
		strcpy(sOrignMsgType, oCcms990.m_PMTSHeader.getMesgType());
		strcpy(sOrignMesgID, oCcms990.m_PMTSHeader.getMesgID());
		strcpy(sOrignRefId, oCcms990.m_PMTSHeader.getMesgRefID());

		m_ErrMsgTp = sOrignMsgType;
		
		// 当收到的是<ccms.990.001.02>报文，不需要回复
		if (strncmp(sOrignMsgType, "ccms.990.001.02", 15) == 0)
		{
			return;
		}
		//alter in 20180130
		oCcms990.m_PMTSHeader.SetPMTSXMlHeader(oCcms990.m_PMTSHeader.getOrigReceiverSID(),
                                  oCcms990.m_PMTSHeader.getOrigSenderSID(), 
                                  m_sWorkDate,
                                  oCcms990.m_PMTSHeader.getOrigReceiver(),
                                  "0000",
                                  "ccms.990.001.02",
                                  sMsgRefId
                                  );
		//alter end
	}
	else if(MSG_VER_1ST == m_iMsgVer)
	{
	    char szCmtno[3+1]={0};
		strncpy(szCmtno, pchMsg+11, 3);
		strncpy(sOrignSender, pchMsg+18, 12);
		strncpy(sOrignReceiver, pchMsg+30, 12);
		strncpy(sOrignSendDate, pchMsg+84, 8);
		strncpy(sOrignMesgID, pchMsg+44, 20);
		strncpy(sOrignRefId, pchMsg+64, 20);
		
		// 当收到的是910报文，不需要回复
		if (strncmp(sOrignMsgType, "910", 3) == 0)
		{
			return;
		}
		//alter in 20180130
		oCcms990.m_PMTSHeader.SetPMTSXMlHeader(oCcms990.m_PMTSHeader.getOrigReceiverSID(),
                                  oCcms990.m_PMTSHeader.getOrigSenderSID(), 
                                  m_sWorkDate,
                                  sOrignReceiver,
                                  "0000",
                                  "ccms.990.001.02",
                                  sMsgRefId
                                  );
                //alter end
        atoi(szCmtno) > 13?\
        sprintf(sOrignMsgType,"BCMT%s",szCmtno):\
        sprintf(sOrignMsgType,"BPKG%s",szCmtno);

        m_ErrMsgTp = sOrignMsgType + 1;
	}
		
	oCcms990.OrigSndr					= sOrignSender;
	oCcms990.OrigSndDt					= sOrignSendDate;
	oCcms990.MT							= sOrignMsgType;
	oCcms990.MsgId 						= sOrignMesgID;
	oCcms990.MsgRefId					= sOrignRefId;
	oCcms990.MsgPrcCd					= "CU0I0000";
	
	oCcms990.CreateXml();

	int iRet = AddQueue(oCcms990.m_sXMLBuff.c_str(),  oCcms990.m_sXMLBuff.length());
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "往MQ队列发送通讯级确认报文失败！");
		PMTS_ThrowException(OPT_MQ_ADD_FAIL);
	}
	m_cMQAgent.Commit();
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBepsBase::Send990()");
}

int CRecvBepsBase::UpPKGAssist1(LPTSTR pMsgId)
{
    //g_Mutex.lock();

    CBppkgassist1 m_pkgassist1;

    char db_MsgId[35 + 1]   = {0};
    char szWrkDate[8 + 1]   = {0};
    char szSqlStr[4096 + 1] = {0};
    int  db_nCount          = 0;
    int  iRet               = 0;
    int  iChgTp             = -1;  //0查询无记录,1笔数小于,2笔数等于,3笔数大于,4更新未找到记录
    string whereClause      = "";
    char sMsgNo[3 + 1]      = {0};
    int  iMsgNo             = 0;
    char sIsRspn[1 + 1]     = {0};

    strcpy(sIsRspn, "0");

    memcpy(sMsgNo,    m_strAssist.sMsgType + 3, sizeof(sMsgNo) - 1);
    iMsgNo = atoi(sMsgNo);

    if ( 1 == iMsgNo || 7 == iMsgNo ) /*普通贷记/贷记退汇*/
    {
        sprintf(szSqlStr, " SENDBANK = '%s' AND RECVBANK = '%s' "
            " AND MSGTYPE = '%s' AND PROCSTATE = '00' ", 
            m_strAssist.sSendBank, 
            m_strAssist.sRecvBank, 
            m_strAssist.sMsgType);
    }
    else if ( 2 == iMsgNo ) /*普通借记*/
    {
        sprintf(szSqlStr, " SENDBANK = '%s' AND RECVBANK = '%s' AND MSGTYPE = '%s' "
            " AND PKGRTRLTD = '%d' AND PROCSTATE = '00' ", 
            m_strAssist.sSendBank, 
            m_strAssist.sRecvBank, 
            m_strAssist.sMsgType,
            m_strAssist.iPkgRtrltd);
    }
    else if ( 5 == iMsgNo ) /*定期贷记*/
    {
        sprintf(szSqlStr, " SENDBANK = '%s' AND RECVBANK = '%s' AND MSGTYPE = '%s' "
            " AND PMTTPPRTRY = '%s' AND  ISSR = '%s'  "
            " AND ACCTID = '%s' AND PROCSTATE = '00' ", 
            m_strAssist.sSendBank, 
            m_strAssist.sRecvBank, 
            m_strAssist.sMsgType,
            m_strAssist.sPmttpPrtry,
            m_strAssist.sIssr,
            m_strAssist.sAcctId);
    }
    else if ( 6 == iMsgNo ) /*定期借记*/
    {
        sprintf(szSqlStr, " SENDBANK = '%s' AND RECVBANK = '%s' AND MSGTYPE = '%s' "
            " AND PMTTPPRTRY = '%s' AND  ISSR = '%s'  "
            " AND ACCTID = '%s' AND PKGRTRLTD = '%d' AND PROCSTATE = '00' ", 
            m_strAssist.sSendBank, 
            m_strAssist.sRecvBank, 
            m_strAssist.sMsgType,
            m_strAssist.sPmttpPrtry,
            m_strAssist.sIssr,
            m_strAssist.sAcctId,
            m_strAssist.iPkgRtrltd);
    }
    else if ( 8 == iMsgNo || 11 == iMsgNo ) /*定期/普通借记回执*/
    {
        sprintf(szSqlStr, " SENDBANK = '%s' AND RECVBANK = '%s' AND MSGTYPE = '%s' "
            " AND ORIMSGTP = '%s' AND  ORIMSGID = '%s' AND PROCSTATE = '00' ", 
            m_strAssist.sSendBank, 
            m_strAssist.sRecvBank, 
            m_strAssist.sMsgType,
            m_strAssist.sOriMsgTp,
            m_strAssist.sOriMsgId);
        strcpy(sIsRspn, "1");
    }
    else
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "不支持的报文类型[%d]", iMsgNo);	
        g_Mutex.unLock();
        return -1;
    }

    if (0 != m_pkgassist1.setctx(m_dbproc))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
        g_Mutex.unLock();
        return -1;
    }

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "szSqlStr = [%s]",szSqlStr); 

    whereClause = szSqlStr;
    iRet = m_pkgassist1.find(whereClause);
    if ( 0 != iRet )
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_pkgassist.find error [%d][%s]",iRet,m_pkgassist1.GetSqlErr());	
        g_Mutex.unLock();
        return iRet;
    }

    iRet = m_pkgassist1.fetch();
    if ( SQLNOTFOUND == iRet )
    {
        iChgTp = 0; //没有记录,需要新增
    }
    else if (SQL_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Select Bp_Pkgassist1 Is ERROR[%d][%s]", iRet, m_pkgassist1.GetSqlErr()); 

        m_pkgassist1.closeCursor();
        g_Mutex.unLock();
        return iRet;
    }
    else
    {
        db_nCount = m_pkgassist1.m_listcount;
        strcpy(pMsgId, m_pkgassist1.m_msgid.c_str());
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "pMsgId[%s]", pMsgId);
    }

    m_pkgassist1.closeCursor();

    if ( 0 != iChgTp)
    {
        //笔数小于打包笔数,只更新笔数,不新增
        if (db_nCount + 1 < g_pkgpack)
        {
            iChgTp = 1;
            sprintf(szSqlStr, "UPDATE bp_pkgassist1 SET LISTCOUNT = %d "
                "WHERE RECVBANK = '%s' AND MSGTYPE = '%s' "
                "AND MSGID = '%s' AND LISTCOUNT = %d "
                "AND PROCSTATE = '00' ", 
                db_nCount + 1, 
                m_strAssist.sRecvBank, m_strAssist.sMsgType, pMsgId, db_nCount);
        }
        //笔数等于打包笔数,更新笔数和状态(预打包),不新增
        else if (db_nCount + 1 == g_pkgpack)
        {
            iChgTp = 2;
            sprintf(szSqlStr, "UPDATE bp_pkgassist1 SET LISTCOUNT = %d, PROCSTATE = '01' "
                "WHERE RECVBANK = '%s' AND MSGTYPE = '%s' "
                "AND MSGID = '%s' AND LISTCOUNT = %d "
                "AND PROCSTATE = '00' ", 
                db_nCount + 1, 
                m_strAssist.sRecvBank, m_strAssist.sMsgType, pMsgId, db_nCount);            
        }
        //笔数大于打包笔数,更新状态(预打包),同时新增,这种情况一般不会出现,特殊情况用
        else if (db_nCount + 1 > g_pkgpack)
        {   
            iChgTp = 3; 
            sprintf(szSqlStr, "UPDATE bp_pkgassist1 SET PROCSTATE = '01' "
                "WHERE RECVBANK = '%s' AND MSGTYPE = '%s' "
                "AND MSGID = '%s' AND LISTCOUNT = %d "
                "AND PROCSTATE = '00' ", 
                m_strAssist.sRecvBank, m_strAssist.sMsgType, pMsgId, db_nCount);            
        }
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
            "iChgTp=[%d],szSqlStr=[%s]", iChgTp, szSqlStr);

        iRet = m_pkgassist1.execsql(szSqlStr);
        if (SQLNOTFOUND == iRet )
        {
            iChgTp = 4; //如果查询有记录,更新没找到记录,需新增
        }
        else if (SQL_SUCCESS != iRet)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "UpDate Bp_Pkgassist1 Is ERROR, ErrorCode[%s], ErrorDesc[%s]", iRet, m_pkgassist1.GetSqlErr());
            g_Mutex.unLock();
            return iRet;
        }

        if ( 1 == iChgTp || 2 == iChgTp )
        {
            g_Mutex.unLock();
            return 0;//笔数小于或等于打包笔数,且更新成功,返回成功
        }
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iChgTp=[%d]", iChgTp);

    //新增一条记录
    //a.生成包序号/报文标识号
    memset(db_MsgId, 0, sizeof(db_MsgId));
    if ( !GetMsgIdValue(m_dbproc, db_MsgId, eMsgId, SYS_BEPS, m_strAssist.sSendBank) )
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "GetMsgIdValue error"); 
        g_Mutex.unLock();
        return -2;
    }
    memcpy(szWrkDate, db_MsgId, sizeof(szWrkDate) - 1);

    //b.赋值
    m_pkgassist1.m_wrkdate      = szWrkDate;
    m_pkgassist1.m_sendbank     = m_strAssist.sSendBank;
    m_pkgassist1.m_recvbank     = m_strAssist.sRecvBank;
    m_pkgassist1.m_msgtype      = m_strAssist.sMsgType;

    m_pkgassist1.m_pkgrtrltd    = m_strAssist.iPkgRtrltd;
    m_pkgassist1.m_pmttpprtry   = m_strAssist.sPmttpPrtry;
    m_pkgassist1.m_issr         = m_strAssist.sIssr;
    m_pkgassist1.m_acctid       = m_strAssist.sAcctId;
    m_pkgassist1.m_orimsgtp     = m_strAssist.sOriMsgTp;
    m_pkgassist1.m_orimsgid     = m_strAssist.sOriMsgId;

    m_pkgassist1.m_msgid        = db_MsgId;
    m_pkgassist1.m_listcount    = 1;
    m_pkgassist1.m_handpackflag = "0";
    m_pkgassist1.m_isrspn       = sIsRspn;
    m_pkgassist1.m_isallrspn    = "0"; //这个如何填，在哪用到,需确认?

    if ( 0 == iChgTp && 1 == g_pkgpack)
        m_pkgassist1.m_procstate = "01";
    else
        m_pkgassist1.m_procstate = "00";

    //c.写入打包辅助表
    iRet = m_pkgassist1.insert();
    if (DUPLICATE_KEY != iRet && SQL_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Insert Into Bp_Pkgassist1 Is ERROR[%d][%s]", iRet, m_pkgassist1.GetSqlErr());  
        g_Mutex.unLock();
        return   iRet;     
    }

    memset(pMsgId, 0x00, sizeof(pMsgId));
    strcpy(pMsgId, db_MsgId);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "db_MsgId[%s]", db_MsgId);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "pMsgId[%s]", pMsgId);
    g_Mutex.unLock();
    return 0;
}

void CRecvBepsBase::DirectInter(LPCSTR cpSendBank,
								LPCSTR cpRecvBank, 
								LPCSTR cpRecvSapBank,  
								LPCSTR cpTxid, 
								LPCSTR cpNpcMsg,
								LPCSTR cpIngoingDetailTable,
								LPCSTR cpPmtTpPrtry)
{
    /*Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBepsBase::DirectInter()");
    
    int iRet = RTN_FAIL;
    
    CSysmsgonlinectrl oSysmsgonlinectrl;
    
    oSysmsgonlinectrl.m_cmtno = m_strMsgTp.c_str();
    oSysmsgonlinectrl.m_sysid = "BEPS";
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "oSysmsgonlinectrl.m_cmtno[%s]",oSysmsgonlinectrl.m_cmtno.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "oSysmsgonlinectrl.m_sysid[%s]",oSysmsgonlinectrl.m_sysid.c_str());
    
    SETCTX(oSysmsgonlinectrl);
	
    iRet = oSysmsgonlinectrl.findByPK();
    if(OPERACT_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg, "oSysmsgonlinectrl findByPK fail:	[%d][%s]", 
        iRet, oSysmsgonlinectrl.GetSqlErr());
        Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(DB_GET_DATA_FAIL);
    }
    
    
    if("1" != oSysmsgonlinectrl.m_recvscflag)//不是直连的，直接返回
    {
    	
        return;
    }
    
    
    CBpcomsendmb oBpcomsendmb;
    
    
    oBpcomsendmb.m_workdate = m_strWorkDate;// 委托日期
    
    oBpcomsendmb.m_msgid = cpTxid;// 明细标志号
    
    oBpcomsendmb.m_sendbank = cpSendBank;// 发起行行号
    
    oBpcomsendmb.m_recvbank = cpRecvBank;// 接收行行号
    
    oBpcomsendmb.m_recvsapbank = cpRecvSapBank;// 接收清算行行号
    
    oBpcomsendmb.m_msgtype = m_strMsgTp;// 报文类型
    
    oBpcomsendmb.m_sysflag = "BEPS";// 系统标识
    
    oBpcomsendmb.m_procstate = "01";// 处理状态 01:待处理 02：正在处理03：处理失败 04：待手工派发
    
    oBpcomsendmb.m_proctimes = 0;// 处理次数
    
    oBpcomsendmb.m_recvtarget = "0";// 业务来源标志 0：正常 1：手工派发
    Trace(L_INFO,	__FILE__,  __LINE__, NULL, "cpIngoingDetailTable=[%s]",cpIngoingDetailTable);
    if(NULL != cpIngoingDetailTable)
    {
		oBpcomsendmb.m_ingoingdetailtable = cpIngoingDetailTable;	// 来账明细表名
	}
	
	if(cpPmtTpPrtry != NULL)
	{
		oBpcomsendmb.m_pmttpprtry = cpPmtTpPrtry;				// 业务类型编码
	}
    
    
    SETCTX(oBpcomsendmb);
    
    
    iRet = oBpcomsendmb.insert();
    
    
    if (OPERACT_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg, "oBpcomsendmb insert fail [%d][%s]", 
            iRet, oBpcomsendmb.GetSqlErr());
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
    }
    
    Trace(L_INFO,	__FILE__,  __LINE__, NULL, "LEAVE CRecvBepsBase::DirectInter()");*/

}

/******************************************************************************
*  Function:   CheckPkgMac
*  Description:一代报文核押凼数(南洋专用)
*  Input:      oPkgBase 
*              pRefStr   20位密押参考值
               pSendSapBank 发起清算行号
*  Return:     0：   成功
*              其他：失败
*  Others:     无
*  Author:     aps-lel
*  Date:       2012-02-16
*******************************************************************************/
int CRecvBepsBase::CheckPkgMac(pkgbase& oPkgBase,const char *pRefStr,const char* pSendSapBank)
{
	Trace(L_INFO,	__FILE__,  __LINE__, NULL, "LEAVE CRecvBepsBase::CheckPkgMac()");
	
    if (g_iCfcaSign != 0)
    {	
        string strCodeMac;//取核押串
        oPkgBase.GetMacStr(oPkgBase,strCodeMac);
        
	    iRet = CheckMac(m_dbproc,pRefStr,strCodeMac.c_str(),pSendSapBank);
	    if(0 != iRet)
        {
    	    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CheckPkgMac failed[%d]" ,iRet);
    	    PMTS_ThrowException(__FILE__, __LINE__, OPT_CHECKMAC_FAIL, "核押失败");
        }
    }

	Trace(L_INFO,	__FILE__,  __LINE__, NULL, "LEAVE CRecvBepsBase::CheckPkgMac()");
	
	return 0;
}

/******************************************************************************
*  Function:   CheckAgreemet
*  Description:check agreement
*  Input:     
        agrmetnb 协议号
        agrmet      协议
        acct           账户
        acctsts       账户状态
*  Return:     0：   成功
*              其他：失败
*  Others:     无
*******************************************************************************/

bool CRecvBepsBase::CheckAgreemet(string agrmetnb,string agrmet,string acct,string acctsts)
{
	Trace(L_INFO,	__FILE__,  __LINE__, NULL, "ENTER CRecvBepsBase::CheckAgreemet()");
	
	int iRet = -1;

    CBpcstctrctmg bpcstctrctmg;
    SETCTX(bpcstctrctmg);
    std::string strQry;
    char strSql[10240] = {0};
    sprintf(strSql, "AGRMTNB = '%s' and CTRCTAGRMTTP = '%s' and DBTRID = '%s' and ACCTSTS = '%s' and PROCSTATE = '35'"
            ,agrmetnb.c_str(),agrmet.c_str(),acct.c_str(),acctsts.c_str());

    strQry = strSql;
    Trace(L_INFO,	__FILE__,  __LINE__, NULL, "Qry SQL:%s",strQry.c_str());
    
    iRet = bpcstctrctmg.find(strQry);   
    if(0 != iRet)
    {   
        Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "CheckAgreemet failed:open flag failed!  iRet[%d]", iRet);
        m_strErrDesc = "CheckAgreemet failed:open flag failed!";
        return false;
    }

    if (0 != bpcstctrctmg.fetch())
    {
        Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "未找到配匹协议 iRet[%d]", iRet);
        bpcstctrctmg.closeCursor();
        Trace(L_INFO,	__FILE__,  __LINE__, NULL, "LEAVE CRecvBepsBase::CheckAgreemet()");
        return false;
    }

    bpcstctrctmg.closeCursor();
	Trace(L_INFO,	__FILE__,  __LINE__, NULL, "LEAVE CRecvBepsBase::CheckAgreemet()");
	return true;
}

/******************************************************************************
*  Function:   CheckUserState
*  Description:check acct state
*  Input:     
        mt      报文号
        acct     账户
*  Return:     0：   成功
*              其他：失败
*  Others:     无
*******************************************************************************/

bool CRecvBepsBase::CheckUserState(string mt,string acct)
{
	Trace(L_INFO,	__FILE__,  __LINE__, NULL, "LEAVE CRecvBepsBase::CheckUserState()");
	
	int iRet = -1;

    CBpmbfecfg bpmbfecfg;
    SETCTX(bpmbfecfg);
    bpmbfecfg.m_msgtype = mt;
    bpmbfecfg.m_account = acct;
    
    iRet = bpmbfecfg.findByPK();   
    if(0 != iRet)
    {   
        Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "CheckUserState failed     iRet[%d]", iRet);
        Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "bpmbfecfg.m_msgtype[%s]",mt.c_str());
        Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "bpmbfecfg.m_account[%s]",acct.c_str());

        m_strErrDesc = "其他";
        return false;
    }

    if ("0" != bpmbfecfg.m_retstate)
    {
        if ("1" == bpmbfecfg.m_retstate)
        {
            m_strErrCode = bpmbfecfg.m_errcode1;
            m_strErrDesc = bpmbfecfg.m_errdesc1;
        }
        else if ("2" == bpmbfecfg.m_retstate)
        {
            m_strErrCode = bpmbfecfg.m_errcode2;
            m_strErrDesc = bpmbfecfg.m_errdesc2;
        }

        return false;
    }
    
	Trace(L_INFO,	__FILE__,  __LINE__, NULL, "LEAVE CRecvBepsBase::CheckUserState()");
	
	return true;
}

void CRecvBepsBase::doMd5(string& strSrc, string& strDst)
{
    MD5 md5;
    md5.Hash_Start();
    md5.Hash_PatchBuffer((unsigned char*)strSrc.c_str(), strSrc.length());
    strDst =  md5.Hash_End().GetBuffer(0);
}



