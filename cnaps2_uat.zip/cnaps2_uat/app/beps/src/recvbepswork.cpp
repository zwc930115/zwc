/********************************************************************
文件名：recvbework.cpp
创建人：zhj
日  期：2011-03-03
修改人：
日  期：
描  述：beps来帐线程工作类
版  本：
Copyright (c) 2011  YLINK
********************************************************************/
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "pubfunc.h"
#include "logger.h"
#include "recvbepswork.h"
#include "bprecvmsg.h"
#include "recvbepsbase.h"
#include "recvbeps121.h"
#include "recvbeps122.h"
#include "recvbeps123.h"
#include "recvbeps124.h"
#include "recvbeps125.h"
#include "recvbeps127.h"
#include "recvbeps128.h"
#include "recvbeps130.h"
#include "recvbeps131.h"
#include "recvbeps132.h"
#include "recvbeps133.h"
#include "recvbeps134.h"
#include "recvbeps380.h"
#include "recvbeps381.h"
#include "recvbeps382.h"
#include "recvbeps383.h"
#include "recvbeps384.h"
#include "recvbeps385.h"
#include "recvbeps386.h"
#include "recvbeps387.h"
#include "recvbeps388.h"
#include "recvbeps389.h"
#include "recvbeps392.h"
#include "recvbeps393.h"
#include "recvbeps394.h"
#include "recvbeps395.h"
#include "recvbeps396.h"
#include "recvbeps397.h"
#include "recvbeps398.h"
#include "recvbeps399.h"
#include "recvbeps401.h"
#include "recvbeps402.h"
#include "recvbeps403.h"
#include "recvbeps404.h"
#include "recvbeps411.h"
#include "recvbeps412.h"
#include "recvbeps414.h"
#include "recvbeps415.h"
#include "recvbeps418.h"
#include "recvbeps419.h"
#include "recvpkg003.h"
#include "recvpkg004.h"
#include "recvpkg005.h"
#include "recvpkg006.h"
#include "recvpkg007.h"
#include "recvpkg008.h"
#include "recvpkg001.h"
#include "recvpkg002.h"
#include "recvpkg009.h"
#include "recvpkg012.h"
#include "recvpkg013.h"
#include "recvbeps721.h"
#include "recvbeps723.h"
#include "recvbeps725.h"
#include "recvbeps726.h"
#include "recvcmt324.h"
#include "recvcmt325.h"


using namespace ZFPT;

extern CConnectPool *g_DBConnPool;
extern int		g_IsConnPlatm;

CRecvBepsWork::CRecvBepsWork()
{
	m_sTrsCode = "";
    m_sMsgFile = "";
    m_strMsgID = "";		
}

CRecvBepsWork::~CRecvBepsWork()
{	
}

void CRecvBepsWork::setData(LPTSTR lpMsgID, int iErrMsgFlag, UINT32 len, LPCSTR data, LPCSTR lpTrsCode, LPCSTR lpMsgFile)
{
    
    if(NULL != data && 0 != len)
    {
        m_vData.resize(len + 1, 0);
    
        memset(&m_vData[0], 0, len * sizeof(char));
        memcpy(&m_vData[0], data, len);
    }
    
    if(lpTrsCode != NULL)
    {
        m_sTrsCode = lpTrsCode;
    }
    
    if(lpMsgFile != NULL)
    {
        m_sMsgFile = lpMsgFile;
    }
    
    if (NULL != lpMsgID)
    {
        m_strMsgID = lpMsgID;
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgID = %s", m_strMsgID.c_str());	
    }

    m_iErrMsgFlag = iErrMsgFlag;
}

void CRecvBepsWork::clear()
{
	
}

INT32 CRecvBepsWork::doWork()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBepsWork::doWork()");	

    // 大报文消息没传过来，需要从来帐通讯表取消息
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_vData.size() = %d", m_vData.size());	

	int iRet		= -1;
	int iBizCode	= -1; 
	int iVersion	= -1;
	
	/*if (0 == m_vData.size()) //当报文长度大于2000时,work从表里取;小于2000时,通过setdata设置
    {
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "0 == m_vData.size()");	

		iRet = GetMsg();
        if (0 != iRet)
        {
            return RTN_FAIL;
        }

        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "GetMsg() success");	
    }    */

	//取业务码   
    iBizCode = GetBizCode(&m_vData[0], iVersion);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iBizCode = %d", iBizCode);
	
    if (-1 == iBizCode)
    {
        return RTN_FAIL;
    }
    
    char szchBizCode[MAX_BIZ_CODE_LEN + 1] = {0};  // 业务码
    sprintf(szchBizCode, "%d", iBizCode);

    char sBizCode[MAX_BIZ_CODE_LEN + 1] = {0};  // 日志用
    sprintf(sBizCode, "%03d", iBizCode);
    
	CRecvBepsBase *PRecv = NULL;
		
    switch( iBizCode )
    {
        case 121:
        {
            PRecv = new CRecvbeps121;
            break;
        }
        case 1:
        {
            PRecv = new CRecvPkg001;
            break;
        }
        case 2:
        {
            PRecv = new CRecvPkg002;
            break;
        }
        case 3:
        {
            PRecv = new CRecvPkg003;
            break;
        }          
        case 4:
        {
            PRecv = new CRecvPkg004;
            break;
        }        
        case 122:
        {
            PRecv = new CRecvbeps122;
            break;
        }
        case 123:
        {
            PRecv = new CRecvBeps123;
            break;
        }
        case 124:
        {
            PRecv = new CRecvBeps124;
            break;
        }
		case 125:
        {
            PRecv = new CRecvBeps125;
            break;
        }
        case 127:
        {
            PRecv = new CRecvbeps127;
            break;
        }
        case 128:
        {
            PRecv = new CRecvBeps128;
            break;
        } 
        case 130:
        {
            PRecv = new CRecvBeps130;
            break;
        }   
        case 131:
        {
            PRecv = new CRecvBeps131;
            break;
        }   
        case 132:
        {
            PRecv = new CRecvBeps132;
            break;
        } 
        case 133:
        {
            PRecv = new CRecvBeps133;
            break;
        }   
        case 134:
        {
            PRecv = new CRecvBeps134;
            break;
        }
        case 324:
        {
            PRecv = new CRecvCmt324;
            break;
        }
        case 325:
        {
            PRecv = new CRecvCmt325;
            break;
        }
        case 380:
        {
            PRecv = new CRecvbeps380;
            break;
        }     
        case 381:
        {
            PRecv = new CRecvbeps381;
            break;
        }                      
        case 382:
        {
            PRecv = new CRecvbeps382;
            break;
        }
        case 383:
        {
            PRecv = new CRecvbeps383;
            break;
        }          
		case 384:
        {
            PRecv = new CRecvbeps384;
            break;
        } 
        case 385:
        {
            PRecv = new CRecvbeps385;
            break;
        }         
		case 386:
        {
            PRecv = new CRecvbeps386;
            break;
        }
		case 387:
       {
           PRecv = new CRecvbeps387;
           break;
       }
		case 388:
        {
            PRecv = new CRecvbeps388;
            break;
        }
		case 389:
        {
            PRecv = new CRecvbeps389;
            break;
        }   
        case 392:
        {
            PRecv = new CRecvBeps392;
            break;
        }                             
        case 393:
        {
            PRecv = new CRecvBeps393;
            break;
        }
        case 394:
        {
            PRecv = new CRecvbeps394;
            break;
        }
        case 395:
        {
            PRecv = new CRecvbeps395;
            break;
        }   
        case 396:
        {
            PRecv = new CRecvbeps396;
            break;
        }               
        case 397:
        {
            PRecv = new CRecvbeps397;
            break;
        }
       case 398:
       {
           PRecv = new CRecvbeps398;
           break;
       }          
        case 399:
        {
            PRecv = new CRecvbeps399;
            break;
        }    
		case 401:
        {
            PRecv = new CRecvbeps401;
            break;
        }
		case 402:
        {
            PRecv = new CRecvbeps402;
            break;
        }
		case 403:
        {
            PRecv = new CRecvbeps403;
            break;
        }
		case 404:
        {
            PRecv = new CRecvbeps404;
            break;
        }
        case 411:
        {
            PRecv = new CRecvBeps411;
            break;
        }
        case 412:
        {
            PRecv = new CRecvBeps412;
            break;
        }
        case 414:
        {
            PRecv = new CRecvBeps414;
            break;
        }        
        case 415:
        {
            PRecv = new CRecvBeps415;
            break;
        }    		
		case 418:
        {
            PRecv = new CRecvbeps418;
            break;
        }
		case 419:
        {
            PRecv = new CRecvbeps419;
            break;
        }
        case 721:
        {
            PRecv = new CRecvBeps721;
            break;
        }
        case 723:
        {
            PRecv = new CRecvBeps723;
            break;
        }
        case 725:
        {
            PRecv = new CRecvBeps725;
            break;
        }			
        case 726:
        {
            PRecv = new CRecvBeps726;
            break;
        }	        	
        case 5:
        {
            PRecv = new CRecvPkg005;
            break;
        }
        case 6:
        {
            PRecv = new CRecvPkg006;
            break;
        }
        case 7:
        {
            PRecv = new CRecvPkg007;
            break;
        }
        case 8:
        case 10:
        case 11:
        {
            PRecv = new CRecvPkg008;
            break;
        }        
        case 9:
        {
            PRecv = new CRecvPkg009;
            break;
        }     
        case 12:
        {
            PRecv = new CRecvPkg012;
            break;
        }
        case 13:
        {
            PRecv = new CRecvPkg013;
            break;
        }
        default:
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ERROR iBizCode[%d]",iBizCode);
            return RTN_FAIL;
        }
    }
	
	PRecv->m_strBizCode  = szchBizCode;
	PRecv->m_iMsgVer	 = iVersion;
	PRecv->m_strRcvMsgID = m_strMsgID;
	PRecv->m_iErrMsgFlag = m_iErrMsgFlag;
	
	//ZFPTLOG.SetLogInfo(sBizCode, NULL);
	ZFPTLOG.SetLogInfo(sBizCode, m_strMsgID.c_str());
	
	PRecv->doWork(&m_vData[0]);
	if (NULL != PRecv)
	{
		delete PRecv;
		PRecv = NULL;
	}
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBepsWork::doWork()");

    return RTN_SUCCESS;
}

/******************************************************************************
*  Function:   GetMsg
*  Description:从来帐通讯表取消息
*  Input:	   无
*  Output:	   
*  Return:	   0   : 操作成功,
			   其他: 操作失败
*  Others:	   无
*  Author:	   zys
*  Date:	   2011-02-21
*******************************************************************************/
INT32 CRecvBepsWork::GetMsg(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBepsWork::GetMsg");	

	int    iRet = RTN_FAIL;
	DBProc cDBProc;

	// 获取数据库连接
	iRet = g_DBConnPool->GetConnect(cDBProc);
	if(0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "GetConnect failed");
		return iRet;	
	}

	CBprecvmsg CBprecvmsg;
	iRet= CBprecvmsg.setctx(cDBProc);
	if (0 != iRet)
	{
		g_DBConnPool->PutConnect(cDBProc);//释放连接
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CBprecvmsg.setctx error[%d]", iRet);	
		return iRet;
	}

	CBprecvmsg.m_msgid  = m_strMsgID;
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_strMsgID = %s", m_strMsgID.c_str());	
	
	// 从来帐通讯表取消息
	iRet = CBprecvmsg.findByPK();
	if (RTN_SUCCESS == iRet)
	{
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "CBprecvmsg.findByPK success");	
		m_vData.resize(CBprecvmsg.m_msgtext.length() + 1, 0);	
		memset(&m_vData[0], 0, CBprecvmsg.m_msgtext.length() * sizeof(char));
		memcpy(&m_vData[0], CBprecvmsg.m_msgtext.c_str(), CBprecvmsg.m_msgtext.length());
	}
	else
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CBprecvmsg.findByPKfailed[%d]", iRet);
	}

	//释放连接
	g_DBConnPool->PutConnect(cDBProc);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBepsWork::GetMsg");

	return iRet;
}


