#include "ibpspubfunc.h"
#include "tsocket.h"

char g_sLogFileName[20];

int Snd2Host(LPTSTR sHostRqt)
{
	printf("99999999999999999999999999\n");

	char sMbRsp[4096 + 1];
	char sTimeOut[120 + 1];

	int iRet;
	int m_nHostPort;
	string m_strHostIp;
	string m_strHostRsp;
	memset(sMbRsp, 0, sizeof(sMbRsp));
	memset(sTimeOut, 0, sizeof(sTimeOut));

	char sTmpBuf[20 + 1];

	memset(sTmpBuf, 0, sizeof(sTmpBuf));

	m_nHostPort = 18601;
	m_strHostIp = "132.147.253.248";

	iRet = 0;

	TSocketClient SocketClient((char *)m_strHostIp.c_str(), m_nHostPort);

	SocketClient.setServerType(SEVER_TYPE_BANK);

	SocketClient.setSelectInterval(20);
	
	printf("888888888888888888888888888888888888888\n");
	if (SocketClient.connectServer() <= 0)
	{
		printf("777777777777777777777777777777777\n");
		return -1;
	}

	printf("666666666666666666666666666666666666666\n");

	if(true != SocketClient.sendMsg(sHostRqt))
	{
		printf("55555555555555555555555555555555555555555\n");
		return -2;
	}

	iRet = SocketClient.recvMsg(sMbRsp);
	if (iRet > 0)
	{
		m_strHostRsp = sMbRsp;
		printf("44444444444444444444444444444444444444444444444444444\n");
	}
	else
	{
		printf("33333333333333333333333333333333333333333333\n");
		return -3;
	}

	SocketClient.disConnet();
	
	printf("2222222222222222222222222222222222222222222\n");

	return 0;
}

int main()
{
	char *sHostRqt =NULL;
	pid_t pid;

	sHostRqt = "M00001201012231753100000000000000000000000047285000101010001Qibps.101.001.01|0100027012190012|大力神公司|6224271110277070|白雪|313345001665|1111.00|10.000000|0|货款|2010-12-23T17:53:10|C200|CNY|2010-12-23T17:53:10|AT00|313345001665|02001||0.000000|10.000000|IBPSHD|||";

	memset(g_sLogFileName,NULL_CHAR,sizeof(g_sLogFileName));
	strcpy(g_sLogFileName,"socketest");
	
	for(int k = 0; k < 100; k++)
	{
		Snd2Host(sHostRqt);
	}
}
