/********************************************************************
文件名：recvfrombp.cpp
创建人：zhj
日  期   ：2011-03-02
修改人：
日  期：
描  述：beps后台业务来账处理主控
版  本：
Copyright (c) 2011  YLINK
********************************************************************/

//#ifdef _LINUX_
//#define SQLCA_STORAGE_CLASS extern
//#include "sqlca.h"
//#endif
#include <sqlca.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include "exception.h"
#include "connectpool.h"
#include "mqagent.h"
#include "configparser.h"
#include "thread.h"
#include "logger.h"
#include "pubfunc.h"
#include "recvbepswork.h"
#include "bprecvmsg.h"
#include "cfg_obj.h"
#include "rout.h"


#define MQ_ERR_MAX_TIMES 20

using namespace ZFPT;

CConnectPool *g_DBConnPool;		
CCfgObj		pCfgFile;			//解析类读xml.cfg文件专用

char		g_MQmgr[256];
char		g_MqTxtPath[256];
char		g_SendQueue[128];
char		g_SendCCMSQueue[128];
char        g_SendCBSP[128];
int         g_IsConnCBSP;
char        g_IP[16];
int         g_IsConnPlatm;
int         g_iCfcaSign;//是否验签名或核押
char        g_msgpath[128] = {0};
char        g_SapBank[17] = {0};
char            g_SignAddr[496];

CMutex			g_Mutex;
extern Rout    *g_rout =  NULL;
int g_pkgpack;
MQAgent 	m_cMQAgent;
DBProc		m_dbproc; 					   //l½щ

int InsertRecvMsg(DBProc &dbProc, const char *pchMsg, const char *pchMsgID);
int LoadConfigFile(stuCfgInfo &CfgInfo);

int main(int argc, char **argv)
{
	
    char        szRecvMq[60]          = { 0 };
    char        sErrDesc[1024]        = {0};
    bool        IsHasMsg              = false; //是否读到了消息
    int         iRet                  = 0;
    int         iErrTimes             = 0;
    STRING      sMsg                  = "";    //MQ报文
    STRING      sFile                 = "";    //MQ收到的文件名称
    char        szMsgID[35]           = {0};   //MsgID
    string      sBizCode              = "";    //交易码
    
    stuCfgInfo  CfgInfo ;
	
    signal(SIGINT , SIG_IGN);					//屏蔽中断信号
    signal(SIGQUIT, SIG_IGN);					//屏蔽终端退出信号
    signal(SIGALRM, SIG_IGN);					//屏蔽超时信号
    signal(SIGHUP , SIG_IGN);					//屏蔽连接断开信号
    signal(SIGSTOP, SIG_IGN);					//这些信号被忽略
    //signal(SIGCHLD, SIG_IGN);


	sprintf(szMsgID, "%s", "12345");

    try
    {	
    	//加载配置文件
        LoadConfigFile(CfgInfo);


		//初始化日志
        ZFPTLOG.setCfgInfo(CfgInfo.szLogPath, "recvfrombeps", CfgInfo.iLogLeave, CfgInfo.dLogMaxSize);

        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化MQ...");
        //初始化MQ 
        if(m_cMQAgent.Init(CfgInfo.szMQmgr, CfgInfo.szMqTxtPath) != RTN_SUCCESS)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Init MQ manager failed.");
            exit(0);
        }
        strncpy(szRecvMq, CfgInfo.RecvQueue, sizeof(szRecvMq)-1);
        
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "读XML配置文件...");
		
        //读XML配置文件
        iRet = pCfgFile.Init(CfgInfo.szXmlCtgPath);  //配置文件路径
        if(iRet != 0)
        {
            sprintf(sErrDesc, "Failed to Init the node Config Object: ErrCode = %d, ErrInfo = %s", pCfgFile.GetLastErrCode(),pCfgFile.GetLastErrInfo());
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);          
            exit(0);
        }

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "创建并初始化数据库连接池..."); 
		
        //创建连接池 
        g_DBConnPool = new CConnectPool(CfgInfo.iConPoolMinNum,CfgInfo.iConPoolMaxNum,CfgInfo.iNoConWaitTime);
		
        iRet= g_DBConnPool->InitPool(CfgInfo.iConPoolSize,CfgInfo.DBUser,CfgInfo.DBKey,CfgInfo.DBName);	
        if(iRet == RTN_SUCCESS)
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "连接池创建成功");
        }
        else
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "连接池创建失败");
          
            exit(0);
        }

        g_rout = new Rout();

        if(-1 == g_rout->Init())
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "init rout failed");
            exit(0);
        }

    }catch(CException &e)
    {
        sprintf(sErrDesc,"Catch a exception from [%s]",  e.what());
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,sErrDesc );       
        exit(0);
    }

    //初始化线程池
    CThreadPool<CRecvBepsWork> cPool;
	
    cPool.start(CfgInfo.iThreadPoolSize, CfgInfo.iThreadPoolTaskSize);

    string strMsgId = "beps";
    string tmpMsg;
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "开始从MQ取消息");
    while(true)
    {
        try
        {
            IsHasMsg  = false;
            sMsg      = "";
            sFile     = "";
            sBizCode  = "";
            memset(szMsgID, 0, sizeof(szMsgID));	
            
		        ZFPTLOG.setCfgInfo(CfgInfo.szLogPath, "recvfrombeps", CfgInfo.iLogLeave, CfgInfo.dLogMaxSize);
	
            //从实时队列中读取消息
            int iErrMsgFlag = 0;
            iRet = m_cMQAgent.GetMsg(szRecvMq, sMsg, sFile, iErrMsgFlag,GET_MQMSG_MAXTIME);
						
            if(0 == iRet)
            {		
                //读到消息
                iErrTimes=0;
                IsHasMsg = true;

                // 获取数据库连接(主控取连接，配置文件中需要将连接数比线程数多1)	
    			if(0 != g_DBConnPool->GetMainConnect(m_dbproc))
    			{					
    				break;
    			}

    	        GetSysParam(m_dbproc,"01", g_SapBank);
                if(iErrMsgFlag)
                {
                    tmpMsg = "";
                    if(GetMsgFromFile(sMsg.c_str(),tmpMsg))
                    {
                        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Get Msg[%s] Faile",sMsg.c_str());
                        WriteException(m_dbproc, "BEPS", iErrMsgFlag, sMsg.c_str(), OPT_GET_WORK_DATE_FAIL, "GetMsgFromFile failed");
                        continue;
                    }
                    
                    memset(szMsgID, 0, 256);
                    sprintf(szMsgID, "%s", sMsg.c_str());     
                    sMsg = tmpMsg;
                }
                else
                {
                    // 获取MSGID
                    strMsgId = "beps";
                    bool bRet = GetMsgIdValue(m_dbproc, szMsgID, eRecvId, SYS_BEPS);		
                    if(true != bRet)
                    {
                        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Get Msgid Faile");
                        WriteException(m_dbproc, "BEPS", iErrMsgFlag, sMsg.c_str(), OTH_ERR, "获取工作日期失败");
                        continue;
                    }
                    strMsgId += szMsgID;
                    memset(szMsgID, 0, sizeof(szMsgID));
                    sprintf(szMsgID, "%s", strMsgId.c_str());      
                    //strncpy(szMsgID, "12345", 5);      
                    if( 0 != WriteMsgFile(sMsg.c_str(),szMsgID,g_msgpath))  
                    {
                        continue;    
                    }
                    else
                    {
                        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "write %s/%s OK",g_msgpath,szMsgID);
                    }
                                        
                }                
                m_cMQAgent.Commit();                
                CRecvBepsWork *pWorker = new CRecvBepsWork;

    			if(pWorker != NULL)
    			{
            
					pWorker->setData(szMsgID, iErrMsgFlag, sMsg.length(),sMsg.c_str());
                    pWorker->doWork();
                    
                    delete pWorker;
                    pWorker = NULL;
					
                }
                else
                {
                    Trace(L_ERROR, __FILE__, __LINE__, NULL, "__Alloc Memory Failed!");
					g_DBConnPool->PutMainConnect(m_dbproc);
    			    exit(-1);
                }				
				
				
				g_DBConnPool->PutMainConnect(m_dbproc);
            }
            else if (1 == iRet)
            {            
                IsHasMsg =false;

            }
            else if(-1 == iRet)
            {   
            	//读取消息失败
                iErrTimes++;
				
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Get MQ message failed:[%s]", szRecvMq);
    			
                if(iErrTimes >= MQ_ERR_MAX_TIMES) 
                {
                    break;
                }
            }
			
            if(!IsHasMsg)
            {
                usleep(1000);
                continue;		
            }
			
			
        }
        catch(CException &e)
        {
            sprintf(sErrDesc, "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);
            sleep(3);
	
        }

    }

    setsid();  //退出前设置会话session组id,防止影响其子进程 


    return RTN_SUCCESS;
}


int InsertRecvMsg(DBProc &dbProc, const char *pchMsg, const char *pchMsgID)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER InsertRecvMsg");
    
    if (NULL == pchMsg || '\0' == pchMsg)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE InsertRecvMsg");
        return RTN_FAIL;
    }

    char sWorkDate[8 + 1] = { 0 };
    CBprecvmsg cBprecvmsg;

    cBprecvmsg.setctx(dbProc);

    GetWorkDate(dbProc, sWorkDate, SYS_BEPS);

    cBprecvmsg.m_wrkdate	= sWorkDate;
    cBprecvmsg.m_msgid		= pchMsgID;
    cBprecvmsg.m_msgtext	= pchMsg;

    cBprecvmsg.m_procstate	= PR_HVBP_03; //待处理

    int iRet = cBprecvmsg.insert();
    if (0 == iRet)
    {
        cBprecvmsg.commit();
    }
    else
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "pRecvmsg insert failed[%d][%s]",
            iRet, cBprecvmsg.GetSqlErr());
        cBprecvmsg.rollback();
    }	

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE InsertRecvMsg");
    return iRet;
}

int LoadConfigFile(stuCfgInfo &CfgInfo)
{
    //先读配置，再加载日志程序，所以此函数是不能打印日志的
    
    CConfigParser& cCfg = CConfigParser::getInstance();

    strcpy(CfgInfo.path, ZFPT_CFG_PATH);
    cCfg.loadConfig(CfgInfo.path);

	strncpy(CfgInfo.szXmlCtgPath, cCfg.getOption("XMLCTGPATH"), sizeof(CfgInfo.szXmlCtgPath)-1);
    strncpy(CfgInfo.szLogPath   , cCfg.getOption("LOGPATH")   , sizeof(CfgInfo.szLogPath)-1   );
    CfgInfo.iPort               = atoi(cCfg.getOption("BEPSPORT")  );
    CfgInfo.iLogLeave           = atoi(cCfg.getOption("LOGLVL")    );
	CfgInfo.dLogMaxSize         = atof(cCfg.getOption("LOGMAXSIZE"));

	strncpy(CfgInfo.szMQmgr    , cCfg.getOption("MQMGR")     , sizeof(CfgInfo.szMQmgr)-1    );
    strncpy(CfgInfo.RecvQueue  , cCfg.getOption("BEPSRECVMQ"), sizeof(CfgInfo.RecvQueue)-1  );
	strncpy(CfgInfo.szMqTxtPath, cCfg.getOption("MQTEXTPATH"), sizeof(CfgInfo.szMqTxtPath)-1);
	
	memset(g_MQmgr         , 0x00, sizeof(g_MQmgr)        );
	memset(g_SendQueue     , 0x00, sizeof(g_SendQueue)    );
	memset(g_MqTxtPath     , 0x00, sizeof(g_MqTxtPath)    );
	memset(g_SendCCMSQueue , 0x00, sizeof(g_SendCCMSQueue));
  memset(g_SignAddr , 0x00, sizeof(g_SignAddr));
  strncpy(g_SignAddr, cCfg.getOption("SIGNADDR"), sizeof(g_SignAddr)-1);	 
   	
	strncpy(g_MQmgr        , cCfg.getOption("MQMGR")     , sizeof(g_MQmgr)-1        );
    strncpy(g_SendQueue    , cCfg.getOption("BEPSSENDMQ"), sizeof(g_SendQueue)-1    );
	strncpy(g_SendCCMSQueue, cCfg.getOption("CCMSSENDMQ"), sizeof(g_SendCCMSQueue)-1);
    strncpy(g_MqTxtPath    , cCfg.getOption("MQTEXTPATH"), sizeof(g_MqTxtPath)-1    );
    strncpy(g_msgpath, cCfg.getOption("MSGPATH"), sizeof(g_msgpath)-1);

    CfgInfo.iConPoolMinNum          = atoi(cCfg.getOption("BPCONNPOOLMINSIZE")   );
    CfgInfo.iConPoolMaxNum          = atoi(cCfg.getOption("BPCONNPOOLMAXSIZE")   );
    CfgInfo.iNoConWaitTime	        = atoi(cCfg.getOption("BPNOCONNWAITTIME")    );
    CfgInfo.iConPoolSize            = atoi(cCfg.getOption("BPCONNPOOLSIZE")      );
    CfgInfo.iThreadPoolSize         = atoi(cCfg.getOption("BPTHREADPOOLSIZE")    );
    CfgInfo.iThreadPoolTaskSize     = atoi(cCfg.getOption("BPTHREADPOOLTASKSIZE"));
    
    strncpy(CfgInfo.DBUser, cCfg.getOption("DBUSER"), sizeof(CfgInfo.DBUser)-1);
    strncpy(CfgInfo.DBKey , cCfg.getOption("DBKEY") , sizeof(CfgInfo.DBKey)-1);
    strncpy(CfgInfo.DBName, cCfg.getOption("DBNAME"), sizeof(CfgInfo.DBName)-1);

    strncpy(CfgInfo.szMqServConn  , cCfg.getOption("MQSERVCONN")  , sizeof(CfgInfo.szMqServConn) - 1  );
    strncpy(CfgInfo.szPmInfoHdFlg1, cCfg.getOption("PMINFOHDFLG1"), sizeof(CfgInfo.szPmInfoHdFlg1) - 1);
    strncpy(CfgInfo.szPmInfoHdFlg2, cCfg.getOption("PMINFOHDFLG2"), sizeof(CfgInfo.szPmInfoHdFlg2) - 1);
    strncpy(CfgInfo.szCbspRecvMQ  , cCfg.getOption("CBSPRECVMQ")  , sizeof(CfgInfo.szCbspRecvMQ) - 1  );    
    CfgInfo.iMqListener         = atoi(cCfg.getOption("MQLISTENER"));
    CfgInfo.iConnPlatm          = atoi(cCfg.getOption("ISCONNPLATM"));   
    
    g_IsConnPlatm               = atoi(cCfg.getOption("ISCONNPLATM"));  
    g_iCfcaSign                 = atoi(cCfg.getOption("CFCASIGN")); 
    g_pkgpack = atoi(cCfg.getOption("PKGPACK"));
	return OPERACT_SUCCESS;
}

