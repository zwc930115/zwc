/********************************************************************
文件名：sendbpwork.cpp
创建人：zhj
日	期    ：2011-03-02
修改人：
日	期    ：
描	述	：beps往帐线程工作类
版	本	：
Copyright (c) 2011	YLINK
********************************************************************/
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbepswork.h"
#include "sendbeps121.h"
#include "sendbeps122.h"
#include "sendbeps123.h"
#include "sendbeps125.h"
#include "sendbeps127.h"
#include "sendbeps128.h"
#include "sendbeps130.h"
#include "sendbeps131.h"
#include "sendbeps133.h"
#include "sendbeps134.h"
#include "sendbeps381.h"
#include "sendbeps383.h"
#include "sendbeps388.h"
#include "sendbeps389.h"
#include "sendbeps392.h"
#include "sendbeps395.h"
#include "sendbeps396.h"
#include "sendbeps396.h"
#include "sendbeps398.h"
#include "sendbeps411.h"
#include "sendbeps412.h"
#include "sendbeps401.h"
#include "sendbeps403.h"
#include "sendbeps404.h"
#include "sendbeps418.h"
#include "sendbeps419.h"
#include "sendbeps720.h"
#include "sendpkg001.h"
#include "sendpkg002.h"
#include "sendpkg003.h"
#include "sendpkg004.h"
#include "sendpkg005.h"
#include "sendpkg006.h"
#include "sendpkg007.h"
#include "sendpkg008.h"
#include "sendpkg011.h"
#include "sendpkg012.h"
#include "sendpkg013.h"
#include "sendcmt323.h"


using namespace ZFPT;



CSendBepsWork::CSendBepsWork()
{
 memset(&m_MsgHead, 0x00, sizeof(m_MsgHead));
}

CSendBepsWork::CSendBepsWork(const CSendBepsWork &e)
{
    if(this != &e)
    {
        m_sTrsCode = e.m_sTrsCode;
        memcpy(m_MQMsgId , e.m_MQMsgId, sizeof(e.m_MQMsgId));        
        memcpy(&m_MsgHead, &e.m_MsgHead, sizeof(e.m_MsgHead));
    }
}

CSendBepsWork::~CSendBepsWork()
{
}

void CSendBepsWork::UnpackMsgHead(const char* strMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Enter CSendBepsWork::UnpackMsgHead...");
    memset(m_MsgHead.szMsgFlagNO, ' ', 28);
    memset(m_MsgHead.szSndNO, ' ', 14);
	int offset = 0;
	OffsetCpy(m_MsgHead.szSysType, strMsg, offset, 4);
	OffsetCpy(m_MsgHead.szMsgUse, strMsg, offset, 1);
	OffsetCpy(m_MsgHead.szMsgTypeFlag, strMsg, offset, 3);
	OffsetCpy(m_MsgHead.szMsgType, strMsg, offset, 3);
	OffsetCpy(m_MsgHead.szMsgFlagNO, strMsg, offset, 28);
	OffsetCpy(m_MsgHead.szSndNO, strMsg, offset, 14);
	OffsetCpy(m_MsgHead.szOprUser,strMsg, offset, 20);
	OffsetCpy(m_MsgHead.szOprUserNetId,strMsg, offset, 20);	
	OffsetCpy(m_MsgHead.szMsgKind,strMsg, offset, 5);
	OffsetCpy(m_MsgHead.szReserve,strMsg, offset, 43);
	
	Trim(m_MsgHead.szMsgFlagNO);
	Trim(m_MsgHead.szSndNO);
	Trim(m_MsgHead.szOprUser);
	Trim(m_MsgHead.szOprUserNetId);
	Trim(m_MsgHead.szMsgKind);
	
	m_sTrsCode = m_MsgHead.szMsgFlagNO;
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_sTrsCode= [%s]",     m_sTrsCode.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_MsgHead.szSysType= [%s]",     m_MsgHead.szSysType);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_MsgHead.szMsgUse= [%s]",     m_MsgHead.szMsgUse); 
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_MsgHead.szMsgType= [%s]",     m_MsgHead.szMsgType);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_MsgHead.szMsgTypeFlag =[%s]",  m_MsgHead.szMsgTypeFlag);  
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_MsgHead.szMsgFlagNO= [%s]",   m_MsgHead.szMsgFlagNO);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_MsgHead.szSndNO =[%s]",  m_MsgHead.szSndNO);  
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leave CSendBepsWork::UnpackMsgHead...");
	return;
}

INT32 CSendBepsWork::doWork()
{
    ZFPTLOG.SetLogInfo(m_MsgHead.szMsgType, m_MsgHead.szMsgFlagNO);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvpsWork::doWork..."); 
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "收到交易:[%s]", m_sTrsCode.c_str());

    int iMsgNO = atoi(m_MsgHead.szMsgType);
    if(0 == iMsgNO)
    {
        Trace(L_INFO, __FILE__,  __LINE__, NULL, "转换报文号失败,m_MsgHead.szMsgType = %s", m_MsgHead.szMsgType);
    }
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "收到报文类型:iMsgNO[%d]", iMsgNO);

    int iRet = 0;
	CSendBepsBase * psendbepsbase = NULL;

	stuSndMsg SndMsg;
    memset(&SndMsg, 0x00, sizeof(SndMsg));
    
    switch(iMsgNO)
    {
        case 121:
        {
			psendbepsbase = new CSendBeps121(m_MsgHead);
            break;
        }    
        case 123:
        {
			psendbepsbase = new CSendBeps123(m_MsgHead);
            break;
        }
        case 125:
        {
			psendbepsbase = new CSendBeps125(m_MsgHead);
            break;
        }
        case 128:
        {
			psendbepsbase = new CSendBeps128(m_MsgHead);
            break;
        }        
        case 130:
        {
			psendbepsbase = new CSendBeps130(m_MsgHead);
            break;
        }
        case 131:
        {
			psendbepsbase = new CSendBeps131(m_MsgHead);
            break;
        }
        case 133:
        {
			psendbepsbase = new CSendBeps133(m_MsgHead);
            break;
        }
        case 134:
        {
			psendbepsbase = new CSendBeps134(m_MsgHead);
            break;
        }
        case 323:
        {
            psendbepsbase = new CSendCmt323(m_MsgHead);
            break;
        }
        case 411:
        {
            psendbepsbase = new CSendBeps411(m_MsgHead);
            break;
        }
		case 412:
        {
            psendbepsbase = new CSendBeps412(m_MsgHead);
            break;
        }
        case 392:
        {
            psendbepsbase = new CSendBeps392(m_MsgHead);
            break;
        }
        case 396:
        {
            psendbepsbase = new CSendBeps396(m_MsgHead);
            break;
        }
        case 398:
        {
            psendbepsbase = new CSendBeps398(m_MsgHead);
            break;
        }        
        case 401:
        {
            psendbepsbase = new CSendBeps401(m_MsgHead);
            break;
        }
		case 403:
        {
            psendbepsbase = new CSendBeps403(m_MsgHead);
            break;
        }
		case 404:
        {
            psendbepsbase = new CSendBeps404(m_MsgHead);
            break;
        }
		case 419:
        {
            psendbepsbase = new CSendBeps419(m_MsgHead);
            break;
        }
		case 720:
        {
            psendbepsbase = new CSendBeps720(m_MsgHead);
            break;
        } 
        case 1:
        {
			psendbepsbase = new CSendPkg001(m_MsgHead);
            break;
        } 			
        case 12:
        {
			psendbepsbase = new CSendPkg012(m_MsgHead);
            break;
        } 		
        case 13:
        {
			psendbepsbase = new CSendPkg013(m_MsgHead);
            break;
        }  
        default:
        {
            Trace(L_INFO, __FILE__,  __LINE__, NULL, "没有找到相应的报文号!");

            return RTN_FAIL;
        }
    }
    
    //将MQM消息ID赋值给pSendBase成员，便于SendBase基类中统一给客户端同步回应    
    memcpy(psendbepsbase->m_MQMsgId , m_MQMsgId, sizeof(m_MQMsgId));
    
    iRet = psendbepsbase->doWork();
    DELPOINT_VOID(psendbepsbase);  
    
    Trace(L_INFO, __FILE__,  __LINE__, NULL, "报文处理结束,iMsgNO = %d!", iMsgNO);
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Leave CSendBepsWork::doWork..."); 
    
    return RTN_SUCCESS;
}


void CSendBepsWork::clear()
{
	
}






