/******************************************************************** 
�ļ����� sendbeps418.cpp
�����ˣ� aps-lel	
��  �ڣ� 2011-04-07
�޸��ˣ� 
��  �ڣ� 
��  ���� С������beps.418���Ĵ�����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps418.h"


CSendBeps418::CSendBeps418(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{

}

CSendBeps418::~CSendBeps418()
{

}


int CSendBeps418::updateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps418::updateState...");

	SETCTX(m_cBpchckcdtforld);
	
    string strSQL;
	
	strSQL += "UPDATE BP_CHCKCDTFORLD  t SET t.PROCTIME = sysdate,t.PROCSTATE = '08' "; 
	strSQL += ", MESGID = '";
	strSQL += m_sMsgRefId;
	strSQL += "', MESGREFID = '";
	strSQL += m_sMsgRefId;
	strSQL += "' WHERE t.SRCFLAG = '1' AND t.MSGID = '";
	strSQL += m_cBpchckcdtforld.m_msgid.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_cBpchckcdtforld.m_instgpty.c_str(); 
	strSQL += "' ";	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	
	iRet = m_cBpchckcdtforld.execsql(strSQL.c_str());
	
    if(RTN_SUCCESS != iRet)
    {
		sprintf(m_sErrMsg,"execsql() error,error code =[%d],error cause = [%s]",iRet,m_cBpchckcdtforld.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_sErrMsg);

    }
   
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "leave CSendBeps418::updateState...");
    return 0;
}

INT32 CSendBeps418::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps418::doWorkSelf");
    
    /*��ҵ����л�ȡ����*/    
    GetData();
         
    /*��pmts����*/
    CreatePmtsMsg();
        
    /*����Զ�̶���*/
    AddQueue();

    /*�޸�״̬*/
    updateState();
        
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leave CSendBeps418::doWorkSelf..."); 
	
    return 0;
}


int CSendBeps418::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CSendBeps418::GetData...");
	
	SETCTX(m_cBpchckcdtforld);
	
  	m_cBpchckcdtforld.m_instgpty = m_sSendOrg;//���������
  	m_cBpchckcdtforld.m_msgid    = m_sMsgId;    
    m_cBpchckcdtforld.m_srcflag  = SRC_FRCLIENT;
    
  	Trace(L_DEBUG,  __FILE__,  __LINE__,NULL, "m_instgpty = [%s]",m_cBpchckcdtforld.m_instgpty.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__,NULL, "m_msgid = [%s]",m_cBpchckcdtforld.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__,NULL, "m_srcflag = [%s]",m_cBpchckcdtforld.m_srcflag.c_str());
  	iRet = m_cBpchckcdtforld.findByPK();
  	
	if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg,"findByPK() error,error code = [%d],error cause = [%s]",iRet,m_cBpchckcdtforld.GetSqlErr());
		
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}
			
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "leave CSendBeps418::GetData..."); 
    
	return iRet;
}

void CSendBeps418::AddSign418()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms418::AddSign418");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_cBeps418.getOriSignStr();
	
	AddSign(m_cBeps418.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_cBpchckcdtforld.m_instgdrctpty.c_str());
	
	m_cBeps418.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms418::AddSign418");
}


int CSendBeps418::CreatePmtsMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps418::CreatePmtsMsg...");
	char szTemp[25] = {0};
	
	bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);
    
    Trace(L_DEBUG,  __FILE__,  __LINE__,m_sMsgId, "bRet = %d",bRet);
    Trace(L_DEBUG,  __FILE__,  __LINE__,m_sMsgId, "m_sMsgRefId = %s",m_sMsgRefId);
    if(false == bRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get MsgRefId fail");
	    PMTS_ThrowException(PRM_FAIL);
    }	

	m_cBeps418.CreateXMlHeader("BEPS", 
								m_sWorkDate,
								m_sSendOrg,
								m_cBpchckcdtforld.m_instddrctpty.c_str(),
				  				"beps.418.001.01",
				  				m_sMsgRefId);
				  				

	m_cBeps418.MsgId             = m_cBpchckcdtforld.m_msgid ;                //���ı�ʶ��	                                              
	m_cBeps418.CreDtTm           = m_sIsoWorkDate ;                           //���ķ���ʱ��                                                
	m_cBeps418.InstgDrctPty      = m_cBpchckcdtforld.m_instgdrctpty ;         //����ֱ�Ӳ������                                            
	m_cBeps418.GrpHdrInstgPty    = m_cBpchckcdtforld.m_instgpty ;             //����������                                                
	m_cBeps418.InstdDrctPty      = m_cBpchckcdtforld.m_instddrctpty ;         //����ֱ�Ӳ������                                            
	m_cBeps418.GrpHdrInstdPty    = m_cBpchckcdtforld.m_instdpty ;             //���ղ������                                                
	m_cBeps418.SysCd             = m_cBpchckcdtforld.m_syscd ;                //ϵͳ���                                                    
	m_cBeps418.Rmk               = m_cBpchckcdtforld.m_rmk ;                  //��ע                                                        
	m_cBeps418.OrgnlMsgId        = m_cBpchckcdtforld.m_orgnlmsgid;            //ԭ���ı�ʶ��                                                
	m_cBeps418.OrgnlInstgPty     = m_cBpchckcdtforld.m_orgnlinstgpty;         //ԭ����������                                              
	m_cBeps418.OrgnlMT           = m_cBpchckcdtforld.m_orgnlmt;          //ԭ��������                                                  
	m_cBeps418.ApplyOrCclTp      = m_cBpchckcdtforld.m_applyorccltp;               //֧ƱȦ����������ʶ	AC00:֧ƱȦ������	AC01:֧ƱȦ���� 
	m_cBeps418.IsseDt            = m_cBpchckcdtforld.m_issedt;              //��Ʊ����                                                    
	m_cBeps418.Nb                = m_cBpchckcdtforld.m_orcclnb;       //֧Ʊ����                                                    
	m_cBeps418.Id                = m_cBpchckcdtforld.m_orcclid;            //��Ʊ���к�                                                  
	m_cBeps418.AcctNb            = m_cBpchckcdtforld.m_acctnb;              //��Ʊ���˺� 
	ftoa(szTemp, m_cBpchckcdtforld.m_amt, 2);
	m_cBeps418.Amt               = szTemp;           //���                                                        
	m_cBeps418.Ccy               = m_cBpchckcdtforld.m_currency;               //����                                                        
	m_cBeps418.ChckMd            = m_cBpchckcdtforld.m_chckmd;               //У��ģʽ                                                    
	m_cBeps418.ChckCd            = m_cBpchckcdtforld.m_chckcd;          //У������
	memset(szTemp,0,sizeof(szTemp));
	//__wsh 2012-05-23 ͼ��ǿ�ʱ�����ó��ȼ�ͼ���ֵҪ��
	if(m_cBpchckcdtforld.m_imgfrntlen > 0){
    	itoa(szTemp, m_cBpchckcdtforld.m_imgfrntlen, 8);
    	m_cBeps418.ImgFrntLen        = szTemp;          //֧Ʊ����ͼ�񳤶�                                            		
    	m_cBeps418.Cntt              = m_cBpchckcdtforld.m_cntt;               //֧Ʊ����ͼ������
    	//__wsh 2012-05-21 ����ͼ���MD5ֵ��Ϊ��ǩ��
        doMd5(m_cBeps418.Cntt, m_cBeps418.strImgMd5); 
    }                                              

    
    
	// ��ǩ
	AddSign418();
	
	int iRet = m_cBeps418.CreateXml();
	
	if (0 != iRet)
	{
		
		sprintf(m_sErrMsg,"�������˱���ʧ��iRet = [%d]! ",iRet);
		
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, m_sErrMsg);
	}
	
	
	m_sMsgTxt = m_cBeps418.m_sXMLBuff;
	
	
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "leave CSendBeps418::CreatePmtsMsg..."); 
    
	return iRet;
}

