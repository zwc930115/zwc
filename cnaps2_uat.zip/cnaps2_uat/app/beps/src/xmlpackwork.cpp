/********************************************************************
文件名：Xmlpackwork.cpp
创建人：zhj
日  期   ：2011-04-11
修改人：
日  期：
描  述：   XML打包线程工作类
版  本：
Copyright (c) 2011  YLINK
********************************************************************/
#include "logger.h"
#include "pubfunc.h"

#include "xmlpackwork.h"
#include "sendxmlpack.h"

using namespace ZFPT;

extern CConnectPool *g_DBConnPool;

CXmlPackWork::CXmlPackWork()
{
	memset(&m_stPkgTab, 0x00, sizeof(m_stPkgTab));
}

CXmlPackWork::~CXmlPackWork()
{	
}

void CXmlPackWork::setData(stPkgTab &_PkgTab)
{   
   memcpy(&m_stPkgTab, &_PkgTab, sizeof(m_stPkgTab));
}

void CXmlPackWork::clear()
{
}

INT32 CXmlPackWork::doWork()
{	
	ZFPTLOG.SetLogInfo(m_stPkgTab.szMsgType, m_stPkgTab.szMsgID);
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CXmlPackWork::doWork()");	
	
	CSendXmlPack *pCSend = NULL;

	
	pCSend	= new CSendXmlPack;

	pCSend->setData(m_stPkgTab);
	
	pCSend->Work();
				
	if (NULL != pCSend)
	{
		delete pCSend;
		pCSend = NULL;
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CXmlPackWork::doWork()");

    return RTN_SUCCESS;
}


