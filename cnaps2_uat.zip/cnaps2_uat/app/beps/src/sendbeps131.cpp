/******************************************************************** 
�ļ����� sendbeps131.cpp
�����ˣ� zys
��  ��   �� 2011-04-25
�޸��ˣ� 
��  �ڣ� 
��  ���� С������beps.131���Ĵ�����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps131.h"


CSendBeps131::CSendBeps131(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
}

CSendBeps131::~CSendBeps131()
{
}



INT32 CSendBeps131::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps131::doWorkSelf");
    
    //��ҵ����л�ȡ����    
    getData();
    
    //��pmts����
    buildPmtsMsg();
    
    //����һ������
    insertSum();

    //����Զ�̶���
    AddQueue();
    
    //�޸���ϸҵ��İ����
    UpdateSndList(PR_HVBP_08);
      
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps131::doWorkSelf"); 
    return 0;
}


int CSendBeps131::getData()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps131::getData");
    
	SETCTX(m_cbpbdsendlist);
	
  	m_cbpbdsendlist.m_cdtrbrnchid = m_sSendOrg;
  	m_cbpbdsendlist.m_txid         = m_sMsgId;
  	
  	iRet = m_cbpbdsendlist.findByPK();
  	
  	if (SQLNOTFOUND == iRet)
	{
		sprintf(m_sErrMsg,"С�����ʽ����ϸ�����Ҳ���ָ��ҵ��[%s],[%s],[%d][%s]", m_sSendOrg, m_sMsgId, iRet, m_cbpbdsendlist.GetSqlErr());
		
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	} 	
	else if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg,"��ѯС�����ʽ����ϸ����������[%d][%s]",iRet, m_cbpbdsendlist.GetSqlErr());
		
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "m_dbtnm = [%s]",m_cbpbdsendlist.m_dbtnm.c_str());
		
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps131::getData"); 
    
	return iRet;
}

int CSendBeps131::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps131::CheckValues");

    int iRet = -1;

    //������޼��
    /*iRet = isOutOfLimit(m_dbproc, 
                        m_cbpbdsendlist.m_msgtp.c_str(), 
                        m_cbpbdsendlist.m_purpprtry.c_str(),
                        m_cbpbdsendlist.m_amount, 
                        m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OTHER_ERR, m_sErrMsg);
    }
    
    //�����кż��
    iRet = isBankRight(m_dbproc, m_cbpbdsendlist.m_instddrctpty.c_str(), m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OTHER_ERR, m_sErrMsg);
    }*/
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps131::CheckValues"); 
    return 0;
}

int CSendBeps131::insertSum()
{
	Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps131::insertSum");

	SETCTX(m_cbpbdsndcl);
	
	m_cbpbdsndcl.m_workdate = m_sWorkDate;//��������
	m_cbpbdsndcl.m_consigdate = m_sWorkDate;//ί������
  	m_cbpbdsndcl.m_msgtp = m_cbpbdsendlist.m_msgtp;//��������
  	m_cbpbdsndcl.m_msgid = m_sPkgDtNSn;//���ı�ʶ��
  	m_cbpbdsndcl.m_mesgid = m_sMsgRefId;
  	m_cbpbdsndcl.m_mesgrefid = m_sMsgRefId;
  	m_cbpbdsndcl.m_instgdrctpty = m_cbpbdsendlist.m_instgdrctpty;
  	m_cbpbdsndcl.m_instddrctpty = m_cbpbdsendlist.m_instddrctpty;
  	m_cbpbdsndcl.m_srcflag = "0";
  	m_cbpbdsndcl.m_checkstate = PR_HVBP_00;
  	m_cbpbdsndcl.m_procstate = PR_HVBP_08;//����״̬(04:�ѷ���)
  	m_cbpbdsndcl.m_nboftxs = 1;//��ϸҵ���ܱ���
  	m_cbpbdsndcl.m_ccy = m_cbpbdsendlist.m_currency; //���ҷ���
  	m_cbpbdsndcl.m_ctrlsum = m_cbpbdsendlist.m_amount;//��ϸҵ���ܽ��
  	m_cbpbdsndcl.m_sapsnboftxs = 1;//��ϸҵ�������ܱ���
  	m_cbpbdsndcl.m_ctrlsapssum = m_cbpbdsendlist.m_amount;//��ϸҵ�������ܽ��
  	m_cbpbdsndcl.m_realtimeflag = "1";//ʵʱ��־
  	m_cbpbdsndcl.m_dgtsign = "DIGITSIGN";//����ǩ��
  	m_cbpbdsndcl.m_npcmsg = m_sMsgTxt;

  	
  	iRet = m_cbpbdsndcl.insert();
  	
  	if (DUPLICATE_KEY == iRet) 
	{
		sprintf(m_sErrMsg,"���������Ѵ���[%d][%s]", iRet, m_cbpbdsndcl.GetSqlErr());
        
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);
        
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_sErrMsg);
		
	}
	else if(SQL_SUCCESS != iRet)
	{
		sprintf(m_sErrMsg,"�������˻��ܱ���������ʧ��[%d][%s]", iRet, m_cbpbdsndcl.GetSqlErr());
		
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_sErrMsg);
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps131::insertSum"); 
    
	return iRet;
}

void CSendBeps131::AddSign131()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBeps131::DigitSign131...");

	char   sSignedStr[4096 + 1] = {0};
	
	m_xml131.getOriSignStr();
	
	AddSign(m_xml131.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_cbpbdsendlist.m_instgdrctpty.c_str());
	
	m_xml131.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBeps131::DigitSign131...");
}

 int CSendBeps131::buildPmtsMsg()
 {

	int     iDepth = 0;
    int     iRet = -1;

    //ͨ�ż��ο���
	bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);
	if(false == bRet)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get MsgRefId fail");
		PMTS_ThrowException(PRM_FAIL);
	}

	//pkg�����
	bRet = GetMsgIdValue(m_dbproc, m_sPkgDtNSn, eMsgId, SYS_BEPS);
	if(false == bRet)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get PkgDtNSn fail");
		PMTS_ThrowException(PRM_FAIL);
	}

    //���ñ���ͷҪ��
	m_xml131.m_PMTSHeader.SetPMTSXMlHeader("BEPS", 
							m_sWorkDate,
							m_cbpbdsendlist.m_instgdrctpty.c_str(),
							m_cbpbdsendlist.m_instddrctpty.c_str(),
			  				"beps.131.001.01",
			  				m_sMsgRefId);

    //�ֶθ�ֵ
	char szchTemp[32] = {0};
	
    m_xml131.MsgId                       = m_sPkgDtNSn;
    m_xml131.CreDtTm                     = m_sIsoWorkDate;
    m_xml131.InstgDrctPty                = m_cbpbdsendlist.m_instgdrctpty;
    m_xml131.InstdDrctPty                = m_cbpbdsendlist.m_instddrctpty;
    m_xml131.NbOfTxs                     = "1";
    m_xml131.CtrlSum                     = ftoa(szchTemp,m_cbpbdsendlist.m_amount);
    m_xml131.CtrlSumCcy                  = m_cbpbdsendlist.m_currency;
    m_xml131.SysCd                       = "BEPS";
    m_xml131.Rmk                         = m_cbpbdsendlist.m_rmk;    
    m_xml131.EndToEndId                  = m_cbpbdsendlist.m_txid;
    m_xml131.TxId                        = m_cbpbdsendlist.m_txid;    
    m_xml131.DbtrNm                      = m_cbpbdsendlist.m_dbtnm;
    m_xml131.DbtrAdrLine                 = m_cbpbdsendlist.m_dbtaddr;
    m_xml131.DbtrAcctId                  = m_cbpbdsendlist.m_dbtracctid;
    m_xml131.DbtrAcctIssr                = m_cbpbdsendlist.m_dbtrissr;
    m_xml131.DbtrAgtId                   = m_cbpbdsendlist.m_dbtrbrnchid;
    m_xml131.CdtrAgtId                   = m_cbpbdsendlist.m_cdtrbrnchid;
    m_xml131.CdtrNm                      = m_cbpbdsendlist.m_cdtrnm;
    m_xml131.CdtrAdrLine                 = m_cbpbdsendlist.m_cdtaddr;
    m_xml131.CdtrAcctId                  = m_cbpbdsendlist.m_cdtracctid;
    m_xml131.CdtrAcctIssr                = m_cbpbdsendlist.m_cdtrissr;
	memset(szchTemp,0,sizeof(szchTemp));
    sprintf(szchTemp, "%.2f", m_cbpbdsendlist.m_amount);
    m_xml131.RealTmCstmrDrctDbtInfAmt    = szchTemp;
    m_xml131.RealTmCstmrDrctDbtInfCcy    = m_cbpbdsendlist.m_currency;
    m_xml131.CtgyPurpPrtry               = m_cbpbdsendlist.m_pmttpprtry; //ҵ�����ͱ���
    m_xml131.RealTmCstmrDrctDbtInfPrtry  = m_cbpbdsendlist.m_purpprtry;  //ҵ���������
    m_xml131.CtrctNb                     = m_cbpbdsendlist.m_agrmtnb;//��ͬ��Э�飩��
    
    if ("D203" == m_xml131.CtgyPurpPrtry ||
        "D204" == m_xml131.CtgyPurpPrtry ||
        "D205" == m_xml131.CtgyPurpPrtry ||
        "D206" == m_xml131.CtgyPurpPrtry)
    {
        string strTmp = "";
        memset(szchTemp, 0, sizeof(szchTemp));
        GetTagVal(m_xml131.IsseDt,     m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/IsseDt/");
        //GetTagVal(m_xml131.RealTmBllInfAmt,     m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/RealTmBllInfAmt/");	
        GetTagVal(m_xml131.RealTmBllInfAmt,     m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/Amt/");	
        //_wsh 2012-05-04 �ͻ�����ѡ��,��ʱд��ΪCNY
        m_xml131.RealTmBllInfCcy = "CNY";
        //GetTagVal(m_xml131.RealTmBllInfCcy,     m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/RealTmBllInfCcy/");	
        GetTagVal(m_xml131.PayDT,               m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/PayDT/");	
        GetTagVal(m_xml131.Nb,                  m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/Nb/");	
        GetTagVal(m_xml131.PmtPswd,             m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/PmtPswd/");	
        GetTagVal(m_xml131.MtrtyDt,             m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/MtrtyDt/");	
        GetTagVal(m_xml131.Seal,                m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/Seal/");	
        GetTagVal(m_xml131.AccptncAgrmtNb,      m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/AccptncAgrmtNb/");	
        GetTagVal(m_xml131.AccptncDt,           m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/AccptncDt/");	
        GetTagVal(m_xml131.AccptncNm,           m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/AccptncNm/");	
        GetTagVal(m_xml131.ApplyNm,             m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/ApplyNm/");	
        GetTagVal(m_xml131.ApplyAcct,           m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/ApplyAcct/");	
        GetTagVal(m_xml131.DrwrNm,              m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/DrwrNm/");
        GetTagVal(m_xml131.DrwrAcct,            m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/DrwrAcct/");	
        GetTagVal(m_xml131.TxlCtrctNb,          m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/TxlCtrctNb/");	
        GetTagVal(m_xml131.RealTmBllInfPurp,    m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/Purp/");	
        GetTagVal(m_xml131.NbOfEndrsr,          m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/NbOfEndrsr/");	
        //GetTagVal(m_xml131.EndrsrDtlsNm,        m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/EndrsrDtlsNm/");	
        //__wsh 2012-05-17 �����˿����ж��
        //��ȡ��ϸ����
        int iCount = 0;
		GetTagCount(m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/Nm/",iCount);
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "icount = [%d]",iCount);
        string strTemp = "";
		for(int i = 1; i <=iCount; i++)
		{
			/*�����ֶ�Ϊѭ���е�ѭ��*/
            GetTagVal(strTemp      ,m_cbpbdsendlist.m_cstmrcdttrfaddtlinf,"/Nm/",i); 
			m_xml131.EndrsrDtlsNm  = strTemp;//������������
			m_xml131.m_strTx1 += m_xml131.CHECKVALUE(strTemp);
			m_xml131.AddNodeToSubcycle("EndrsrDtlsNm",m_xml131.EndrsrDtlsNm.c_str());//������������			
			m_xml131.AddSubcycleToNode("EndrsrDtls");
		}   
        //m_xml131.AddNodeToSubcycle("EndrsrDtls","EndrsrDtls",1);//��ע������ѭ���ڵ����ӵĸ��ڵ�
        GetTagVal(m_xml131.OrgnlCdtrNm,         m_cbpbdsendlist.m_cstmrcdttrfaddtlinf, "/OrgnlCdtrNm/");	
    }
    
    //��ǩ
    AddSign131();
    
    //�鱨��
	iRet = m_xml131.CreateXml();
	if (0 != iRet)
	{
        sprintf(m_sErrMsg,"�������˱���ʧ��[%d]",iRet);
        
        Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);        
        PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, m_sErrMsg);
	}

    m_sMsgTxt = m_xml131.m_sXMLBuff;
    
    Trace(L_ERROR, __FILE__, __LINE__, NULL, "[%s]", m_sMsgTxt.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps131::Createxml"); 

    return iRet;
 }
 
 int CSendBeps131::UpdateSndList(LPCSTR sProcstate)
 {
     Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps131::updatePkgId");

 	sprintf(m_sSqlStr, "UPDATE BP_BDSENDLIST t SET t.STATETIME = sysdate,"
 						"t.MSGID = '%s',"  \
 						" t.PROCSTATE = '%s'"  \
 						" WHERE t.txid = '%s'",
 						m_sPkgDtNSn,
 						sProcstate,
 						m_sMsgId);
 		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sSqlStr = [%s]",m_sSqlStr);
 		iRet = m_cbpbdsendlist.execsql(m_sSqlStr);
 		if (iRet == SQLNOTFOUND)
 		{
 			sprintf(m_sErrMsg,  "��m_cbpbdsendlist����û���ҵ�����[%d][%s]", iRet, m_cbpbdsendlist.GetSqlErr());
 			Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
 			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_sErrMsg);
 		}
 		else if (iRet != SQL_SUCCESS)
 		{
 			sprintf(m_sErrMsg,  "update m_cbpbdsendlist  is error![%d][%s]", iRet, m_cbpbdsendlist.GetSqlErr());
 			Trace(L_ERROR, __FILE__, __LINE__, NULL,m_sErrMsg);
 			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_sErrMsg);
 		}

     Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendBeps131::updatePkgId");
     return 0;
 }

 
