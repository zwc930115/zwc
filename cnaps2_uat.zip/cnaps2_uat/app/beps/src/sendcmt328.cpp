/******************************************************************** 
�ļ����� sendcmt328.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ���� С����ֹ������328���Ĵ�����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt328.h"

using namespace ZFPT;

CSendCmt328::CSendCmt328(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
}

CSendCmt328::~CSendCmt328()
{
}

INT32 CSendCmt328::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt328::doWorkSelf");

    /*��ҵ����л�ȡ����*/
    GetData();

    buildPmtsMsg();
    
    UpdateDb();

    if(RTN_SUCCESS == strcmp("1", m_cmt328.sFlag))
    {
        //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "״̬Ϊ��ֹ��,����ԭҵ��Ļ��ܱ�");	
       // UpdateState();   
    }
    
	AddQueue();

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt328::doWorkSelf"); 
    return 0;
}

int CSendCmt328::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt328::getData");

	SETCTX(m_cBpcstbdpcxlcl);
    
  	m_cBpcstbdpcxlcl.m_instgpty = m_sSendOrg;
  	m_cBpcstbdpcxlcl.m_msgid        = m_sMsgId;
  	m_cBpcstbdpcxlcl.m_rsflag       = "1";

  	int iRet = m_cBpcstbdpcxlcl.findByPK();
  	if (SQLNOTFOUND == iRet)
	{
		sprintf(m_sErrMsg, "�Ҳ���ָ��ҵ��[%s], [%s], [%d][%s]", 
		    m_sSendOrg, m_sMsgId, iRet, m_cBpcstbdpcxlcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	} 	
	else if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg, "��ѯ���ܱ���������[%s], [%s], [%d][%s]",
		    m_sSendOrg, m_sMsgId, iRet, m_cBpcstbdpcxlcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}

    SETCTX(m_OrgncBpcstbdpcxlcl);
  	m_OrgncBpcstbdpcxlcl.m_instgpty = m_cBpcstbdpcxlcl.m_osqinstgpty;
  	m_OrgncBpcstbdpcxlcl.m_msgid        = m_cBpcstbdpcxlcl.m_osqlmsgid;
  	m_OrgncBpcstbdpcxlcl.m_rsflag       = "2";
  	
  	iRet = m_OrgncBpcstbdpcxlcl.findByPK();

  	if (SQLNOTFOUND == iRet)
	{
		sprintf(m_sErrMsg, "�Ҳ���ָ��ҵ��[%s], [%s], [%d][%s]", 
		    m_sSendOrg, m_sMsgId, iRet, m_OrgncBpcstbdpcxlcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	} 	
	else if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg, "��ѯ���ܱ���������[%s], [%s], [%d][%s]",
		    m_sSendOrg, m_sMsgId, iRet, m_OrgncBpcstbdpcxlcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}

  	if("0" == m_OrgncBpcstbdpcxlcl.m_grpcxlid)
    {
        SETCTX(m_cOrgnBpcstbdpcxllist);
        m_cOrgnBpcstbdpcxllist.m_msgid = m_OrgncBpcstbdpcxlcl.m_msgid;
        m_cOrgnBpcstbdpcxllist.m_instgpty = m_OrgncBpcstbdpcxlcl.m_instgdrctpty ;

        string strSQL = "MSGID = '" + m_cOrgnBpcstbdpcxllist.m_msgid + "' and orgcdtrbrnchid = '" + m_cOrgnBpcstbdpcxllist.m_instgpty + "' and rsflag = '2'";
        iRet = m_cOrgnBpcstbdpcxllist.find(strSQL);
        if (SQL_SUCCESS != iRet) 
    	{
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ѯ���ҵ��ֹ����ϸ����������[%s], [%s], [%d][%s]", 
    		        m_cOrgnBpcstbdpcxllist.m_msgid.c_str(), m_cOrgnBpcstbdpcxllist.m_instgpty.c_str(), iRet, m_cOrgnBpcstbdpcxllist.GetSqlErr());
    		PMTS_ThrowException(DB_NOT_FOUND);
    	}

    	int iRetCode = m_cOrgnBpcstbdpcxllist.fetch();	
    	if (SQLNOTFOUND == iRetCode) 
    	{
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL,  "�Ҳ���ָ��ҵ��[%s], [%s], [%d][%s]", 
    		                                            m_cOrgnBpcstbdpcxllist.m_msgid.c_str(), 
    		                                            m_cOrgnBpcstbdpcxllist.m_instgpty.c_str(), 
    		                                            iRet, 
    		                                            m_cOrgnBpcstbdpcxllist.GetSqlErr());
    		
    		PMTS_ThrowException(DB_NOT_FOUND);		
    	}	    
    }
    
    SETCTX(m_cBpbdrcvcl);
    m_cBpbdrcvcl.m_msgid = m_OrgncBpcstbdpcxlcl.m_orgnlmsgid;
    m_cBpbdrcvcl.m_instgdrctpty = m_OrgncBpcstbdpcxlcl.m_orgnlinstgpty;
    
    iRet = m_cBpbdrcvcl.findByPK();
    if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg, "��ѯ���ҵ����ܱ���������[%s], [%s], [%d][%s]",
		    m_cBpbdrcvcl.m_msgid.c_str(), m_cBpbdrcvcl.m_instgdrctpty.c_str(), iRet, m_cBpbdrcvcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}
        
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt328::getData"); 
    
	return iRet;
}

int CSendCmt328::buildPmtsMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt328::buildPmtsMsg");

    char sTemp[128]  = {0};
    string strTemp;

	SETCTX(m_cBpcstbdpcxlcl);	
    char szOrgDate[8+1]={0};
    char szOrgTxss[8+1]={0};
    if(m_cBpcstbdpcxlcl.m_osqlmsgid.length() > 8){
        strncpy(szOrgDate, m_cBpcstbdpcxlcl.m_osqlmsgid.c_str(), sizeof(szOrgDate)-1);
        strncpy(szOrgTxss, m_cBpcstbdpcxlcl.m_osqlmsgid.c_str() + 8, sizeof(szOrgTxss)-1);
    }

    //char SndCCPCNode[30] 	= {0};	
	//TranSapBkToCCPCCode(m_dbproc, m_cBpcstbdpcxlcl.m_instgdrctpty.c_str(), SndCCPCNode);

    strcpy(m_cmt328.sConsigndate, m_cBpcstbdpcxlcl.m_consigdate.c_str());       //ί������   8n         M
    strcpy(m_cmt328.sOldrecvsapbk, m_cBpcstbdpcxlcl.m_instgdrctpty.c_str());        //ֹ��Ӧ�������� = ԭ������������     12n        M
    strcpy(m_cmt328.sOldrecvbank, m_cBpcstbdpcxlcl.m_instgpty.c_str());         //ֹ��Ӧ���� = ԭҵ�������     12n        O
    strcpy(m_cmt328.sRecvmssno, m_szMsgSerial);          //ֹ��Ӧ�����             8n         M
    strcpy(m_cmt328.sOldconsigndate, m_OrgncBpcstbdpcxlcl.m_consigdate.c_str());     //ԭֹ������ί������       8n         O	
    strcpy(m_cmt328.sOldsendsapbk, m_cBpcstbdpcxlcl.m_instddrctpty.c_str());      //ԭֹ������������ = ԭ������������     12n        M
    strcpy(m_cmt328.sOldsendbank,  m_cBpcstbdpcxlcl.m_instdpty.c_str());       //ԭֹ�������� = ԭҵ������     12n       O
    strcpy(m_cmt328.sOldsendmssno, szOrgTxss) ;       //ԭֹ���������       8n         M
    strcpy(m_cmt328.sOldpacktype, m_OrgncBpcstbdpcxlcl.m_grpcxlid.c_str());
    //m_cmt328.sTextkey= m_cBpcstbdpcxlcl. ;           //��Ѻ               40x        O                              

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstbdpcxlcl.m_stoppmtsts=%s", m_cBpcstbdpcxlcl.m_stoppmtsts.c_str());
    strcpy(m_cmt328.sFlag , m_cBpcstbdpcxlcl.m_stoppmtsts.c_str());
    //m_cmt328.sRemark= m_cBpcstbdpcxlcl. ;            //ֹ�����븽��           60g        O   
    
	bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ȡ���Ĳο���ʧ��!");
	    PMTS_ThrowException(PRM_FAIL);
    }

    int iRet = m_cmt328.CreateCmt("328",
                           	  m_cBpcstbdpcxlcl.m_instgdrctpty.c_str(),
                           	  m_cBpcstbdpcxlcl.m_instddrctpty.c_str(),
                           	  m_sMsgRefId,
                           	  m_sMsgRefId, 
                           	  m_cBpcstbdpcxlcl.m_workdate.c_str(),
                           	  "0");
    if (0 != iRet)
    {
		sprintf(m_sErrMsg, "Create msg Error!iRet[%d]", iRet);

		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, m_sErrMsg); 
    }

	 m_sMsgTxt = m_cmt328.m_strCmtmsg ;

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt328::buildPmtsMsg");
    return 0;   
}

int CSendCmt328::UpdateState(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendCmt328::UpdateState");

    int iRet = 0;
    string strSQL;
    if("1" == m_OrgncBpcstbdpcxlcl.m_grpcxlid)
    {
        SETCTX(m_cBpbdrcvcl);
    	strSQL += "UPDATE bp_BDRCVCL t SET t.Procstate = '";
        strSQL += PR_HVBP_23;
        strSQL += "', t.BusiState = '";
        strSQL += PROCESS_PR21;
    	strSQL += "', t.STATETIME = sysdate WHERE t.msgid = '";
    	strSQL += m_cBpbdrcvcl.m_msgid;
    	strSQL += "' AND t.INSTGDRCTPTY = '";
    	strSQL += m_cBpbdrcvcl.m_instgdrctpty;
    	strSQL += "'";
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    	
        iRet = m_cBpbdrcvcl.execsql(strSQL);
        if (iRet != SQL_SUCCESS)
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]", iRet, m_cBpbdrcvcl.GetSqlErr());
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
		}
		
        SETCTX(m_cBpbdrecvlist);
        strSQL = "";
    	strSQL += "UPDATE bp_bdrecvlist t SET t.Procstate = '23', t.BusiState = 'PR21'";
    	strSQL += " WHERE t.msgid = '";
    	strSQL += m_cBpbdrcvcl.m_msgid;
    	strSQL += "' AND t.INSTGDRCTPTY = '";
    	strSQL += m_cBpbdrcvcl.m_instgdrctpty;    	
    	strSQL += "'";
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    	
    	iRet = m_cBpbdrecvlist.execsql(strSQL);
        if (iRet != SQL_SUCCESS)
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]", iRet, m_cBpbdrecvlist.GetSqlErr());
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
		}
		    	
	}
    else
    {
        SETCTX(m_cBpbdrecvlist);
        strSQL = "";
    	strSQL += "UPDATE bp_bdrecvlist t SET t.Procstate = '23', t.BusiState = 'PR21'";
    	strSQL += " WHERE t.TxId = '";
    	strSQL += m_cOrgnBpcstbdpcxllist.m_orgnlpmtinfid;
    	strSQL += "' AND t.INSTGDRCTPTY = '";
    	strSQL += m_cBpbdrcvcl.m_instgdrctpty;
    	strSQL += "' AND t.msgid = '";
    	strSQL += m_cBpbdrcvcl.m_msgid;    	
    	strSQL += "'";
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    	
    	iRet = m_cBpbdrecvlist.execsql(strSQL);
        if (iRet != SQL_SUCCESS)
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]", iRet, m_cBpbdrecvlist.GetSqlErr());
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
		}
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendCmt328::UpdateState");
    return RTN_SUCCESS;
}

void CSendCmt328::UpdateDb(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendCmt328::UpdateDb");

	string strSQL;
	int iRet = -1;
	
	strSQL += "UPDATE bp_CstBdPCxlCl t SET t.Procstate = '";
    strSQL += PR_HVBP_08;
    strSQL += "', t.mesgid='";
    strSQL += m_sMsgRefId;
    strSQL += "', t.mesgrefid='";
    strSQL += m_sMsgRefId;
	strSQL += "', t.STATETIME = sysdate WHERE t.msgid = '";
	strSQL += m_cBpcstbdpcxlcl.m_msgid;
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_cBpcstbdpcxlcl.m_instgdrctpty; 
	strSQL += "' and rsflag = '1' ";

    SETCTX(m_cBpcstbdpcxlcl);
	iRet = m_cBpcstbdpcxlcl.execsql(strSQL.c_str());
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL, "Update failed, sqlcode=[%d]", iRet);
	}
	else if (iRet != SQL_SUCCESS)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]",
		    iRet, m_cBpcstbdpcxlcl.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
	}



	return ;
}

