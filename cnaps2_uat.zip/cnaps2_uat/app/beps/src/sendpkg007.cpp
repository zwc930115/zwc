/******************************************************************** 
�ļ����� sendpkg007.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendpkg007.h"

using namespace ZFPT;

CSendPkg007::CSendPkg007(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
	m_bInHis = false;
}

CSendPkg007::~CSendPkg007()
{

}

INT32 CSendPkg007::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg007::doWorkSelf");

    // ��ҵ����л�ȡ����
    GetData();
    
    // �鱨�ı�����*/
    CreateNpcMsg();

    //����������
    UpdatePkg();
    
    //�޸�״̬/NPCMSG
    UpdateSndList(PR_HVBP_03);

    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CSendPkg007::doWorkSelf"); 
    return 0;
}

INT32 CSendPkg007::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg007::GetData");

    SETCTX(m_cBpbcsndlist);

    m_cBpbcsndlist.m_dbtrbrnchid = m_sSendOrg;
    m_cBpbcsndlist.m_txid        = m_sMsgId;

    int iRet = m_cBpbcsndlist.findByPK();
    if (SQLNOTFOUND == iRet)
    {
        sprintf(m_sErrMsg, "С�����ʴ�����ϸ�����Ҳ���ָ��ҵ��[%s][%s]", 
            m_sSendOrg, m_sMsgId);

        Trace(L_INFO,  __FILE__,  __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    } 	
    else if (SQL_SUCCESS != iRet) 
    {
        sprintf(m_sErrMsg,"��ѯС�����ʴ�����ϸ����������[%d][%s]",
            iRet, m_cBpbcsndlist.GetSqlErr());

        Trace(L_INFO,  __FILE__,  __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    }

    SETCTX(m_Bpbcoutrecvlist);
    SETCTX(m_Bpbcoutrecvlisthis);
    
    m_Bpbcoutrecvlist.m_dbtrbrnchid = m_cBpbcsndlist.m_oriinstgpty;
    m_Bpbcoutrecvlist.m_txid        = m_cBpbcsndlist.m_oritxid;
    
    m_bInHis = false;

    iRet = m_Bpbcoutrecvlist.findByPK();
    if (SQLNOTFOUND == iRet){
    	Trace(L_INFO, __FILE__, __LINE__, NULL, "ҵ�����ѯ����ԭҵ�񣬳��Դ���ʷ���в�ѯ!!!");
    	m_Bpbcoutrecvlisthis.m_dbtrbrnchid = m_cBpbcsndlist.m_oriinstgpty;
    	m_Bpbcoutrecvlisthis.m_txid        = m_cBpbcsndlist.m_oritxid;
        iRet = m_Bpbcoutrecvlisthis.findByPK();
        if(iRet != SQL_SUCCESS){
        	Trace(L_ERROR, __FILE__, __LINE__, NULL,
        			"����ԭҵ�����[%s]", m_Bpbcoutrecvlisthis.GetSqlErr());
        	PMTS_ThrowException(DB_FIND_FAIL);
        }

        m_bInHis = true;
    } 	
    else if (SQL_SUCCESS != iRet) {
        sprintf(m_sErrMsg,"��ѯ����������[%d][%s]",
            iRet, m_Bpbcoutrecvlist.GetSqlErr());

        Trace(L_INFO,  __FILE__,  __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    }
    

    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CSendPkg007::GetData"); 

    return iRet;
}

INT32 CSendPkg007::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CSendPkg007::CheckValues");

    int iRet = -1;

    //������޼��
    iRet = isOutOfLimit(m_dbproc, 
                        m_cBpbcsndlist.m_msgtp.c_str(), 
                        m_cBpbcsndlist.m_purpprtry.c_str(),
                        m_cBpbcsndlist.m_amount, 
                        m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_AMT_OUT_OF_LIMIT, m_sErrMsg);
    }
    
    //�����кż��
    iRet = isBankRight(m_dbproc, m_cBpbcsndlist.m_instddrctpty.c_str(), m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_RECVBANK_CHECK_FAIL, m_sErrMsg);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "exit CSendPkg007::CheckValues"); 
    return 0;
}

INT32 CSendPkg007::ChargeMb()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg007::ChargeMb");
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg007::ChargeMb"); 
    return 0;
}

INT32 CSendPkg007::UpdatePkg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg007::UpdatePkg");

    strncpy(m_strAssist.sSendBank, 
            m_cBpbcsndlist.m_instgdrctpty.c_str(), 
            sizeof(m_strAssist.sSendBank) - 1);
            
    strncpy(m_strAssist.sRecvBank, 
            m_cBpbcsndlist.m_instddrctpty.c_str(), 
            sizeof(m_strAssist.sRecvBank) - 1);
            
    strncpy(m_strAssist.sMsgType,  
            m_cBpbcsndlist.m_msgtp.c_str(),        
            sizeof(m_strAssist.sMsgType)  - 1);
    
    m_strAssist.iPkgRtrltd = 0;
    strncpy(m_strAssist.sPmttpPrtry, "0", sizeof(m_strAssist.sPmttpPrtry) - 1);
    strncpy(m_strAssist.sIssr,       "0", sizeof(m_strAssist.sIssr)       - 1);
    strncpy(m_strAssist.sAcctId,     "0", sizeof(m_strAssist.sAcctId)     - 1);
    strncpy(m_strAssist.sOriMsgTp,   "0", sizeof(m_strAssist.sOriMsgTp)   - 1);
    strncpy(m_strAssist.sOriMsgId,   "0", sizeof(m_strAssist.sOriMsgId)   - 1);
    
    iRet = UpPKGAssist1(m_sPkgNo);
    if (iRet != SQL_SUCCESS)
    {
        memcpy(m_sPkgNo, m_cBpbcsndlist.m_msgid.c_str(), sizeof(m_sPkgNo) - 1);
        sprintf(m_sErrMsg,  "UpPKGAssist1 is error,iRet=[%d][%s]", iRet, m_sPkgNo);
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg007::UpdatePkg");
    return 0;
}

INT32 CSendPkg007::CreateNpcMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Enter CSendPkg007::CreateNpcMsg");

    char sTemp[32 + 1] = {0};
    char sMsgText[512 + 1] ={0};
    m_pkg007.m_szCurElementNo              = "002";
    strncpy(m_pkg007.stBody002.szTrxsType, 
            m_cBpbcsndlist.m_pmttpprtry.c_str(), 
            sizeof(m_pkg007.stBody002.szTrxsType)-1);	//ҵ�����ͺ�
            
    strncpy(m_pkg007.stBody002.szOdfiCode, 
            m_cBpbcsndlist.m_instgdrctpty.c_str(),
            sizeof(m_pkg007.stBody002.szOdfiCode)-1);   //�������к�
            
    strncpy(m_pkg007.stBody002.szRdfiCode, 
            m_cBpbcsndlist.m_instddrctpty.c_str(),
            sizeof(m_pkg007.stBody002.szRdfiCode)-1);	//�������к�
            
    strncpy(m_pkg007.stBody002.szConsignDate, 
            m_cBpbcsndlist.m_consigdate.c_str(),
            sizeof(m_pkg007.stBody002.szConsignDate)-1);//ί������
            
    strncpy(m_pkg007.stBody002.szTxssNo, 
            m_szMsgSerial,
            sizeof(m_pkg007.stBody002.szTxssNo)-1);		//֧���������

    
    if(!m_bInHis){
		strncpy(m_pkg007.stBody002.szOriTrxsType,
				m_Bpbcoutrecvlist.m_pmttpprtry.c_str(),
				sizeof(m_pkg007.stBody002.szOriTrxsType)-1);

		strncpy(m_pkg007.stBody002.szOriOdfiCode,
				m_Bpbcoutrecvlist.m_dbtrbrnchid.c_str(),
				sizeof(m_pkg007.stBody002.szOriOdfiCode)-1);

		strncpy(m_pkg007.stBody002.szOriRdfiCode,
				m_Bpbcoutrecvlist.m_cdtrbrnchid.c_str(),
				sizeof(m_pkg007.stBody002.szOriRdfiCode)-1);

		strncpy(m_pkg007.stBody002.szOriConsignDate,
				m_Bpbcoutrecvlist.m_consigdate.c_str(),
				sizeof(m_pkg007.stBody002.szOriConsignDate)-1);

		strncpy(m_pkg007.stBody002.szOriTxssNo,
				m_Bpbcoutrecvlist.m_txid.c_str()+8,
				sizeof(m_pkg007.stBody002.szOriTxssNo)-1);

		char szBuffer[128] = {0};
		sprintf(szBuffer, "%.0f", m_Bpbcoutrecvlist.m_amount * 100);
		strncpy(m_pkg007.stBody002.szOriAmount,
				szBuffer,
				sizeof(m_pkg007.stBody002.szOriAmount)-1);

		strncpy(m_pkg007.stBody002.szOriRecOpenAccBkCode,
				m_Bpbcoutrecvlist.m_cdtrissr.c_str(),
				sizeof(m_pkg007.stBody002.szOriRecOpenAccBkCode)-1);

		strncpy(m_pkg007.stBody002.szOriRecipientAcc,
					m_Bpbcoutrecvlist.m_cdtracctid.c_str(),
					sizeof(m_pkg007.stBody002.szOriRecipientAcc)-1);

		SetFieldAsGbk(m_Bpbcoutrecvlist.m_cdtrnm,
				m_pkg007.stBody002.szOriRecipientName,
				sizeof(m_pkg007.stBody002.szOriRecipientName)-1);

		SetFieldAsGbk(m_Bpbcoutrecvlist.m_cdtaddr,
				m_pkg007.stBody002.szOriRecipientAddr,
				sizeof(m_pkg007.stBody002.szOriRecipientAddr)-1);

		strncpy(m_pkg007.stBody002.szOriPayOpenAccBkCode,
				m_Bpbcoutrecvlist.m_dbtrissr.c_str(),
				sizeof(m_pkg007.stBody002.szOriPayOpenAccBkCode)-1);

		strncpy(m_pkg007.stBody002.szOriPayerAcc,
				m_Bpbcoutrecvlist.m_dbtracctid.c_str(),
				sizeof(m_pkg007.stBody002.szOriPayerAcc)-1);

		SetFieldAsGbk(m_Bpbcoutrecvlist.m_dbtnm,
				m_pkg007.stBody002.szOriPayerName,
				sizeof(m_pkg007.stBody002.szOriPayerName)-1);

		SetFieldAsGbk(m_Bpbcoutrecvlist.m_dbtaddr,
				m_pkg007.stBody002.szOriPayerAddr,
				sizeof(m_pkg007.stBody002.szOriPayerAddr)-1);
    }
    else{
    	strncpy(m_pkg007.stBody002.szOriTrxsType,
				m_Bpbcoutrecvlisthis.m_pmttpprtry.c_str(),
				sizeof(m_pkg007.stBody002.szOriTrxsType)-1);

		strncpy(m_pkg007.stBody002.szOriOdfiCode,
				m_Bpbcoutrecvlisthis.m_dbtrbrnchid.c_str(),
				sizeof(m_pkg007.stBody002.szOriOdfiCode)-1);

		strncpy(m_pkg007.stBody002.szOriRdfiCode,
				m_Bpbcoutrecvlisthis.m_cdtrbrnchid.c_str(),
				sizeof(m_pkg007.stBody002.szOriRdfiCode)-1);

		strncpy(m_pkg007.stBody002.szOriConsignDate,
				m_Bpbcoutrecvlisthis.m_consigdate.c_str(),
				sizeof(m_pkg007.stBody002.szOriConsignDate)-1);

		strncpy(m_pkg007.stBody002.szOriTxssNo,
				m_Bpbcoutrecvlisthis.m_txid.c_str()+8,
				sizeof(m_pkg007.stBody002.szOriTxssNo)-1);

		char szBuffer[128] = {0};
		sprintf(szBuffer, "%.0f", m_Bpbcoutrecvlisthis.m_amount * 100);
		strncpy(m_pkg007.stBody002.szOriAmount,
				szBuffer,
				sizeof(m_pkg007.stBody002.szOriAmount)-1);

		strncpy(m_pkg007.stBody002.szOriRecOpenAccBkCode,
				m_Bpbcoutrecvlisthis.m_cdtrissr.c_str(),
				sizeof(m_pkg007.stBody002.szOriRecOpenAccBkCode)-1);

		strncpy(m_pkg007.stBody002.szOriRecipientAcc,
				m_Bpbcoutrecvlisthis.m_cdtracctid.c_str(),
					sizeof(m_pkg007.stBody002.szOriRecipientAcc)-1);

		SetFieldAsGbk(m_Bpbcoutrecvlisthis.m_cdtrnm,
				m_pkg007.stBody002.szOriRecipientName,
				sizeof(m_pkg007.stBody002.szOriRecipientName)-1);

		SetFieldAsGbk(m_Bpbcoutrecvlisthis.m_cdtaddr,
				m_pkg007.stBody002.szOriRecipientAddr,
				sizeof(m_pkg007.stBody002.szOriRecipientAddr)-1);

		strncpy(m_pkg007.stBody002.szOriPayOpenAccBkCode,
				m_Bpbcoutrecvlisthis.m_dbtrissr.c_str(),
				sizeof(m_pkg007.stBody002.szOriPayOpenAccBkCode)-1);

		strncpy(m_pkg007.stBody002.szOriPayerAcc,
				m_Bpbcoutrecvlisthis.m_dbtracctid.c_str(),
				sizeof(m_pkg007.stBody002.szOriPayerAcc)-1);

		SetFieldAsGbk(m_Bpbcoutrecvlisthis.m_dbtnm,
				m_pkg007.stBody002.szOriPayerName,
				sizeof(m_pkg007.stBody002.szOriPayerName)-1);

		SetFieldAsGbk(m_Bpbcoutrecvlisthis.m_dbtaddr,
				m_pkg007.stBody002.szOriPayerAddr,
				sizeof(m_pkg007.stBody002.szOriPayerAddr)-1);
    }
            
    string strTagVal = "";
    GetTagVal(strTagVal, m_cBpbcsndlist.m_cstmrcdttrfaddtlinf, "72A:"); 
    Trace(L_DEBUG, __FILE__, __LINE__, 
            NULL, "__strTagVal=[%s]", strTagVal.c_str());
    char szPost[256] = {0};
    snprintf(szPost, sizeof(szPost), strTagVal.c_str());
    Utf8ToGbk(szPost, sizeof(szPost)-1, "%s");        
    strncpy(m_pkg007.stBody002.szPost,   
            szPost, 
            sizeof(m_pkg007.stBody002.szPost)-1);
    
    sprintf(m_pkg007.stBody002.szAppLen, "%d", 0);
    
    m_pkg007.AddBussiness();
    m_sMsgTxt = m_pkg007.m_szPkgBody;

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, " m_sMsgTxt = [%s]", m_sMsgTxt.c_str());
    Trace(L_INFO,   __FILE__,  __LINE__, NULL, "Leave CSendPkg007::CreateNpcMsg");

    return 0;
}

INT32 CSendPkg007::UpdateSndList(LPCSTR sProcstate)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg007::UpdateSndList");

    string strSql = "update bp_bcoutsendlist set statetime=sysdate, msgid='";
	strSql += m_sPkgNo;
	strSql += "', procstate='";
	strSql += sProcstate;
	strSql += "', npcmsg='";
	strSql += m_sMsgTxt;
	strSql += "' where txid='";
	strSql += m_sMsgId;
	strSql += "' and dbtrbrnchid='";
	strSql += m_sSendOrg;
	strSql += "' ";

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "__strSql=[%s]", strSql.c_str());

    iRet = m_cBpbcsndlist.execsql(strSql);
    if (iRet != SQL_SUCCESS)
    {
        sprintf(m_sErrMsg,  "update bp_bcoutsendlist  is error!iRet=[%d]", iRet);
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        if ( 0 == strcmp(sProcstate, PR_HVBP_95))
        {
            //��������ʱ�����쳣,������쳣������״̬,���ﲻ���쳣
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
        }
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg007::UpdateSndList");
    return 0;
}

INT32 CSendPkg007::SetErrACK(int iErrCode, LPCSTR pErrDesc)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg007::SetErrACK");

	//�޸�״̬Ϊ"���޸�"
    UpdateSndList(PR_HVBP_93);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg007::SetErrACK");
	return 0;
}

int CSendPkg007::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendPkg007::FundSettle...");
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û�[%s]", m_szOprUser);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_sSendOrg);

	m_charge.m_amount = m_cBpbcsndlist.m_amount*100;	//ҵ����
	m_charge.m_iDCFlag = iDEBITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, MBVIRSUALNETID);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_sSendOrg);	//������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(RTN_SUCCESS != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FundSettle iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendPkg007::FundSettle..."); 
    
    return RTN_SUCCESS;
}
