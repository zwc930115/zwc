/******************************************************************** 
�ļ����� sendpkg006.cpp
�����ˣ� hq
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ���� PKG006���ڽ��ҵ������˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendpkg006.h"

using namespace ZFPT;

CSendPkg006::CSendPkg006(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
    memset(m_sPkgNo, 0x00, sizeof(m_sPkgNo));
}

CSendPkg006::~CSendPkg006()
{

}

INT32 CSendPkg006::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg006::doWorkSelf");

    //��ҵ����л�ȡ����
    GetData();

    //��һ�����ı�����*/
    CreateNpcMsg();

    //����������
    UpdatePkg();
    
    //�޸�״̬/NPCMSG
    UpdateSndList(PR_HVBP_03);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg006::doWorkSelf"); 
    return 0;
}

INT32 CSendPkg006::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg006::GetData");

    SETCTX(m_cBpbdsndlist);
    
    m_cBpbdsndlist.m_cdtrbrnchid = m_sSendOrg;
    m_cBpbdsndlist.m_txid        = m_sMsgId;

    iRet = m_cBpbdsndlist.findByPK();
    if (SQLNOTFOUND == iRet)
    {
        sprintf(m_sErrMsg, "С�����ʽ����ϸ�����Ҳ���ָ��ҵ��[%s][%s]", 
            m_sSendOrg, m_sMsgId);

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    } 	
    else if (SQL_SUCCESS != iRet) 
    {
        sprintf(m_sErrMsg,"��ѯС�����ʴ�����ϸ����������[%d][%s]",
            iRet, m_cBpbdsndlist.GetSqlErr());

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg006::GetData"); 

    return iRet;
}

INT32 CSendPkg006::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg006::CheckValues");

    int iRet = -1;
    
    //������޼��
    iRet = isOutOfLimit(m_dbproc, 
                        m_cBpbdsndlist.m_msgtp.c_str(), 
                        m_cBpbdsndlist.m_purpprtry.c_str(),
                        m_cBpbdsndlist.m_amount, 
                        m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_AMT_OUT_OF_LIMIT, m_sErrMsg);
    }
    
    //�����кż��
    iRet = isBankRight(m_dbproc, m_cBpbdsndlist.m_instddrctpty.c_str(), m_sErrMsg);
    if ( 0 != iRet )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_RECVBANK_CHECK_FAIL, m_sErrMsg);
    }
    
    //�˺ż��
    CheckAcct();
    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CSendPkg006::CheckValues"); 
    return 0;
}

INT32 CSendPkg006::CheckAcct()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CSendPkg006::CheckAcct");
    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CSendPkg006::CheckAcct"); 
    return 0;
}

INT32 CSendPkg006::CreateNpcMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg006::CreateNpcMsg");

    //char sMsgText[512 + 1];
    char sTxssno[8 + 1];
    char sAmount[15 + 1];

    //�鸶�����嵥
    memset(sTxssno, 0x00, sizeof(sTxssno));
    strncpy(sTxssno, m_cBpbdsndlist.m_txid.c_str() + 8, sizeof(sTxssno) - 1);
    memset(sAmount, '\0', sizeof(sAmount));
    sprintf(sAmount,"%012.f", m_cBpbdsndlist.m_amount*100);
    
    /*sprintf(sMsgText, "%8s%8s%12s%12s%32s%60s%60s%15s%60s%60s", 
            sTxssno,
            sTxssno,
            m_cBpbdsndlist.m_dbtrbrnchid.c_str(),
            m_cBpbdsndlist.m_dbtrissr.c_str(),
            m_cBpbdsndlist.m_dbtracctid.c_str(),
            m_cBpbdsndlist.m_dbtnm.c_str(),
            m_cBpbdsndlist.m_dbtaddr.c_str(),
            sAmount,
            m_cBpbdsndlist.m_agrmtnb.c_str(),
            m_cBpbdsndlist.m_addtlinf.c_str()
            );
      */      
    //modified by _wsh 2012/04/28
    string strDbtInfo = "";
    char szBuffer[1024] = {0};
    
    char szDbtNm[64] = {0};
    //sprintf(szDbtNm, "%s", m_cBpbdsndlist.m_dbtnm.c_str());
    //Utf8ToGbk(szDbtNm, sizeof(szDbtNm), "%-60s");
    SetFieldAsGbk(m_cBpbdsndlist.m_dbtnm, szDbtNm, 60);
    
    char szDbtAddr[64] = {0};
    //sprintf(szDbtAddr, "%s", m_cBpbdsndlist.m_dbtaddr.c_str());
    //Utf8ToGbk(szDbtAddr, sizeof(szDbtAddr), "%-60s");
    SetFieldAsGbk(m_cBpbdsndlist.m_dbtaddr, szDbtAddr, 60);
    
    char szAgrmtNb[64] = {0};
    //sprintf(szAgrmtNb, "%s", m_cBpbdsndlist.m_agrmtnb.c_str());
    //Utf8ToGbk(szAgrmtNb, sizeof(szAgrmtNb), "%-60s");
    SetFieldAsGbk(m_cBpbdsndlist.m_agrmtnb, szAgrmtNb, 60);
    
    char szAddInf[64] = {0};
    //sprintf(szAddInf, "%s", m_cBpbdsndlist.m_addtlinf.c_str());
    //Utf8ToGbk(szAddInf, sizeof(szAddInf), "%-60s");
    SetFieldAsGbk(m_cBpbdsndlist.m_addtlinf, szAddInf, 60);
    
    sprintf(szBuffer, "%08s%08s%12s%12s%-32s%-60s%-60s%015s%-60s%-60s",
            sTxssno,
            sTxssno,
            m_cBpbdsndlist.m_dbtrbrnchid.c_str(),
            m_cBpbdsndlist.m_dbtrissr.c_str(),
            m_cBpbdsndlist.m_dbtracctid.c_str(),
            szDbtNm,
            szDbtAddr,
            sAmount,
            szAgrmtNb,
            szAddInf);
    
    strDbtInfo.append(szBuffer);      
            
            
    string strAppData;
    int iCount = 0;
    int iRet = GetTagCount(m_cBpbdsndlist.m_cstmrcdttrfaddtlinf, "72C:", iCount);
    if( (RTN_SUCCESS == iRet) && (iCount > 0) )
    {
        if("20102" == m_cBpbdsndlist.m_pmttpprtry)//������˰ҵ�� 
        {
            //char *szTypeTag[8] = {"%011s", "%08s", "%08s", "%08s", "%018s", "%060s", "%060s", "%060s"};
            //AddAppendData(m_cBpbdsndlist.m_cstmrcdttrfaddtlinf, szTypeTag, strAppData, iCount, 8);
            
            //_wsh 2012-4-27
            char* szBizFmts[8] = {"%011s", "%-8s", "%-8s", "%-8s", "%018s", "%-60s", "%-60s", "%-60s"};
            FormatAppendData(strAppData, m_cBpbdsndlist.m_cstmrcdttrfaddtlinf, iCount,
                    szBizFmts, 8, NULL, 0);
        }
        else if("00114" == m_cBpbdsndlist.m_pmttpprtry)//���ڽ��ҵ��
        {
            m_cBpbdsndlist.m_cstmrcdttrfaddtlinf = "";
        }        
        else
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "û���ҵ���Ӧ����ҵ������");
            PMTS_ThrowException(OPT_TRADE_NOTFOUND__FAIL);
        }
    }

    char szAppLen[8 + 1] = {0};
    sprintf(szAppLen, "%08d", strAppData.length());
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strAppData[%d][%s]", strAppData.length(), strAppData.c_str());
    strDbtInfo.append(szAppLen);
    strDbtInfo.append(strAppData);
    
    m_sMsgTxt = strDbtInfo;
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, " m_sMsgTxt = [%s]", m_sMsgTxt.c_str());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg006::CreateNpcMsg"); 

    return iRet;
}

INT32 CSendPkg006::UpdatePkg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg006::UpdatePkg");
    /*
    strncpy(m_strAssist.sSendBank,   m_cBpbdsndlist.m_instgdrctpty.c_str(), sizeof(m_strAssist.sSendBank)   - 1);
    strncpy(m_strAssist.sRecvBank,   m_cBpbdsndlist.m_instddrctpty.c_str(), sizeof(m_strAssist.sRecvBank)   - 1);
    strncpy(m_strAssist.sMsgType,    m_cBpbdsndlist.m_msgtp.c_str(),        sizeof(m_strAssist.sMsgType)    - 1);
    strncpy(m_strAssist.sPmttpPrtry, m_cBpbdsndlist.m_pmttpprtry.c_str(),   sizeof(m_strAssist.sPmttpPrtry) - 1);
    strncpy(m_strAssist.sIssr,       m_cBpbdsndlist.m_cdtrissr.c_str(),     sizeof(m_strAssist.sIssr)       - 1);
    strncpy(m_strAssist.sAcctId,     m_cBpbdsndlist.m_cdtracctid.c_str(),   sizeof(m_strAssist.sAcctId)     - 1);
    */
    m_strAssist.iPkgRtrltd = m_cBpbdsndlist.m_pkgrtrltd;
    snprintf(m_strAssist.sSendBank,   sizeof(m_strAssist.sSendBank), m_cBpbdsndlist.m_instgdrctpty.c_str());
    snprintf(m_strAssist.sRecvBank,   sizeof(m_strAssist.sRecvBank), m_cBpbdsndlist.m_instddrctpty.c_str());
    snprintf(m_strAssist.sMsgType,    sizeof(m_strAssist.sMsgType),  m_cBpbdsndlist.m_msgtp.c_str());
    snprintf(m_strAssist.sPmttpPrtry, sizeof(m_strAssist.sPmttpPrtry), m_cBpbdsndlist.m_pmttpprtry.c_str());
    snprintf(m_strAssist.sIssr,       sizeof(m_strAssist.sIssr),     m_cBpbdsndlist.m_cdtrissr.c_str());
    snprintf(m_strAssist.sAcctId,     sizeof(m_strAssist.sAcctId),   m_cBpbdsndlist.m_cdtracctid.c_str());
    snprintf(m_strAssist.sOriMsgTp,   sizeof(m_strAssist.sOriMsgTp), "0");
    snprintf(m_strAssist.sOriMsgId,   sizeof(m_strAssist.sOriMsgId), "0");

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "PmttpPrtry=%d,[%s]", strlen(m_strAssist.sPmttpPrtry),
        m_strAssist.sPmttpPrtry);

    

    iRet = UpPKGAssist1(m_sPkgNo);
    if (iRet != SQL_SUCCESS)
    {
        memcpy(m_sPkgNo, m_cBpbdsndlist.m_msgid.c_str(), sizeof(m_sPkgNo) - 1);
        sprintf(m_sErrMsg,  "UpPKGAssist1 is error,iRet=[%d][%s]", iRet, m_sPkgNo);
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg006::UpdatePkg");
    return 0;
}

INT32 CSendPkg006::UpdateSndList(LPCSTR sProcstate)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg006::UpdateSndList");

    string strSql = "update bp_bdsendlist set statetime=sysdate, msgid='";
	strSql += m_sPkgNo;
	strSql += "', procstate='";
	strSql += sProcstate;
	strSql += "', npcmsg='";
	strSql += m_sMsgTxt;
	strSql += "' where txid='";
	strSql += m_sMsgId;
	strSql += "' and cdtrbrnchid='";
	strSql += m_sSendOrg;
	strSql += "' ";

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "__strSql=[%s]", strSql.c_str());

    iRet = m_cBpbdsndlist.execsql(strSql);
    if (iRet != SQL_SUCCESS)
    {
        sprintf(m_sErrMsg,  "update bp_bdsendlist  is error!iRet=[%d][%s]", 
                iRet, m_cBpbdsndlist.GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        if ( 0 == strcmp(sProcstate, PR_HVBP_95))
        {
            //��������ʱ�����쳣,������쳣������״̬,���ﲻ���쳣
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
        }
    }


    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg006::UpdateSndList");
    return 0;
}

INT32 CSendPkg006::SetErrACK(int iErrCode, LPCSTR pErrDesc)
{
	Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CSendPkg006::SetErrACK");

	//�޸�״̬Ϊ"���޸�"
    UpdateSndList(PR_HVBP_93);

	Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CSendPkg006::SetErrACK");
	return 0;
}
