/******************************************************************** 
�ļ����� sendbeps133.cpp
�����ˣ� hq
��  �ڣ� 2011-04-11
�޸��ˣ� 
��  �ڣ� 
��  ���� ���ڽ��ҵ����< beps.133.001.01>���˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps133.h"

using namespace ZFPT;

CSendBeps133::CSendBeps133(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
    memset(m_sPkgNo, 0x00, sizeof(m_sPkgNo));
}

CSendBeps133::~CSendBeps133()
{

}

INT32 CSendBeps133::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps133::doWorkSelf");

    //��ҵ����л�ȡ����
    GetData();

    //����������
    UpdatePkg();
    
    //�޸�״̬/NPCMSG
    UpdateSndList(PR_HVBP_03);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps133::doWorkSelf"); 
    return 0;
}

INT32 CSendBeps133::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps133::GetData");

    SETCTX(m_cBpbdsndlist);

    m_cBpbdsndlist.m_cdtrbrnchid = m_sSendOrg;
    m_cBpbdsndlist.m_txid = m_sMsgId;

    iRet = m_cBpbdsndlist.findByPK();
    if (SQLNOTFOUND == iRet)
    {
        sprintf(m_sErrMsg, "С�����ʽ����ϸ�����Ҳ���ָ��ҵ��[%s],[%s], [%d][%s]", 
            m_sSendOrg, m_sMsgId, iRet, m_cBpbdsndlist.GetSqlErr());

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    } 	
    else if (SQL_SUCCESS != iRet) 
    {
        sprintf(m_sErrMsg,"��ѯС�����ʴ�����ϸ����������[%d][%s]",
            iRet, m_cBpbdsndlist.GetSqlErr());

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps133::GetData"); 

    return iRet;
}

INT32 CSendBeps133::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps133::CheckValues");

    int iRet = -1;
    
    //������޼��
    iRet = isOutOfLimit(m_dbproc, 
                        m_cBpbdsndlist.m_msgtp.c_str(), 
                        m_cBpbdsndlist.m_purpprtry.c_str(),
                        m_cBpbdsndlist.m_amount, 
                        m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_AMT_OUT_OF_LIMIT, m_sErrMsg);
    }
    
    //�����кż��
    iRet = isBankRight(m_dbproc, m_cBpbdsndlist.m_instddrctpty.c_str(), m_sErrMsg);
    if ( 0 != iRet )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_RECVBANK_CHECK_FAIL, m_sErrMsg);
    }
    
    //�˺ż��
    CheckAcct();
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps133::CheckValues"); 
    return 0;
}

INT32 CSendBeps133::CheckAcct()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps133::CheckAcct");
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps133::CheckAcct"); 
    return 0;
}

INT32 CSendBeps133::UpdatePkg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps133::UpdatePkg");

    strncpy(m_strAssist.sSendBank,   m_cBpbdsndlist.m_instgdrctpty.c_str(), sizeof(m_strAssist.sSendBank)   - 1);
    strncpy(m_strAssist.sRecvBank,   m_cBpbdsndlist.m_instddrctpty.c_str(), sizeof(m_strAssist.sRecvBank)   - 1);
    strncpy(m_strAssist.sMsgType,    m_cBpbdsndlist.m_msgtp.c_str(),        sizeof(m_strAssist.sMsgType)    - 1);
    strncpy(m_strAssist.sPmttpPrtry, m_cBpbdsndlist.m_pmttpprtry.c_str(),   sizeof(m_strAssist.sPmttpPrtry) - 1);
    strncpy(m_strAssist.sIssr,       m_cBpbdsndlist.m_cdtrissr.c_str(),     sizeof(m_strAssist.sIssr)       - 1);
    strncpy(m_strAssist.sAcctId,     m_cBpbdsndlist.m_cdtracctid.c_str(),   sizeof(m_strAssist.sAcctId)     - 1);
    
    m_strAssist.iPkgRtrltd = m_cBpbdsndlist.m_pkgrtrltd;
    strncpy(m_strAssist.sOriMsgTp,   "0", sizeof(m_strAssist.sOriMsgTp)   - 1);
    strncpy(m_strAssist.sOriMsgId,   "0", sizeof(m_strAssist.sOriMsgId)   - 1);
    
    iRet = UpPKGAssist(m_sPkgNo);
    if (iRet != SQL_SUCCESS)
    {
        memcpy(m_sPkgNo, m_cBpbdsndlist.m_msgid.c_str(), sizeof(m_sPkgNo) - 1);
        sprintf(m_sErrMsg,  "UpPKGAssist is error,m_sPkgNo=[%s][%s][%s]", m_sPkgNo, iRet, m_cBpbdsndlist.GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps133::UpdatePkg");
    return 0;
}


INT32 CSendBeps133::UpdateSndList(LPCSTR sProcstate)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps133::UpdateSndList");

    memset(m_sSqlStr, 0x00, sizeof(m_sSqlStr));
    sprintf(m_sSqlStr, "UPDATE bp_bdsendlist t SET t.STATETIME = sysdate,"
                			"t.MSGID = '%s', "
                			"t.PROCSTATE = '%s'"
                			" WHERE t.txid = '%s'",
                			m_sPkgNo,
                			sProcstate,
                			m_sMsgId);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sSqlStr=[%s]",m_sSqlStr);

    iRet = m_cBpbdsndlist.execsql(m_sSqlStr);
    if (iRet != SQL_SUCCESS)
    {
        sprintf(m_sErrMsg,  "update bp_bdsendlist  is error![%d][%s]", iRet, m_cBpbdsndlist.GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        if ( 0 == strcmp(sProcstate, PR_HVBP_95))
        {
            //��������ʱ�����쳣,������쳣������״̬,���ﲻ���쳣
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
        }
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps133::UpdateSndList");
    return 0;
}

INT32 CSendBeps133::SetErrACK(int iErrCode, LPCSTR pErrDesc)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps133::SetErrACK");

	//�޸�״̬Ϊ"���޸�"
    UpdateSndList(PR_HVBP_93);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps133::SetErrACK");
	return 0;
}
