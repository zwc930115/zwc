/*
 *  recvbeps725.cpp
 *  Description: С��ҵ������ر���(beps.725.001.01)����������
 *  Created on: 2012-10-18
 *  Author: __wsh
 */
 
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbeps725.h"
#include "bpsapbankinfo.h"

using namespace ZFPT;

extern char g_szRouteRecvQ[128];

CRecvBeps725::CRecvBeps725()
{
}

CRecvBeps725::~CRecvBeps725()
{
}

//__wsh 2012-10-18 ���Ĵ������
int CRecvBeps725::Work(LPCSTR szMsg)
{
	int iRet = -1; 
	
	//��ѹ����
	UnPack(szMsg);

	if(!ChickIfContuine())
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL, "Do nothing");
		return 0;
	}

	//���ĺ�ǩ
	ChkSign725();

	//��������
	iRet = Deal();

	if(CheckIfSend720())
	{
		Send720();
	}

	return iRet;
}


bool CRecvBeps725::ChickIfContuine()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBeps723::ChickIfContuine()");

    int  iRet = -1;

	m_checkqry.m_msgid = m_cBeps725.OrgnlMsgId;
	m_checkqry.m_msgtype = m_cBeps725.OrgnlMT;
	m_checkqry.m_sapbank = m_cBeps725.OrgnlInstgPty;
	SETCTX(m_checkqry);
	iRet = m_checkqry.findByPK();
	if(1403 != iRet && 0 != iRet)
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FIND CM_CHECKQRY FILED[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "FIND CM_CHECKQRY FILED!");
	}
	else if(1403 == iRet)
	{	
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "MSGID=[%s] MSGTP=[%s] SAPBANK=[%s] NOT PMTS QRY",
			                        m_checkqry.m_msgid.c_str(),m_checkqry.m_msgtype.c_str(),m_checkqry.m_sapbank.c_str());		
		return false;
	}
	else{
		return true;
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "CRecvBeps723::ChickIfContuine()");
	return true;
}


bool CRecvBeps725::CheckIfSend720()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CRecvBeps725::CheckIfSend720");
	int iRet = -1;
	

    char szSql[256] = {0};
    snprintf(szSql, sizeof(szSql), 
            " chkdate='%s' and pkbknode='%s' ",m_checkqry.m_checkdate.c_str(),m_cBeps725.InstdDrctPty.c_str());            

	
	CBpbchkstate oCBpbchkstate;
	oCBpbchkstate.m_chkdate = m_checkqry.m_checkdate;
	oCBpbchkstate.m_pkbknode = m_cBeps725.InstdDrctPty;

	SETCTX(oCBpbchkstate);

	iRet = oCBpbchkstate.findByPK();
	if(0 != iRet)
	{
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "oCBpbchkstate.find() error[%d]",iRet);
		PMTS_ThrowException(DB_OPT_FAIL);		
	}
	
	++oCBpbchkstate.m_rcvnm;

    Trace(L_INFO, __FILE__, __LINE__, NULL, "DETAIL NUM=[%d] RCVNUM=[%d]",oCBpbchkstate.m_detailnm,oCBpbchkstate.m_rcvnm);
	
	if(oCBpbchkstate.m_rcvnm == oCBpbchkstate.m_detailnm)
	{
		return true;
	}
	else
	{
		iRet = oCBpbchkstate.updatestate();
		if(0 != iRet)
		{
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "oCBpbchkstate.findByPK() error[%d]",iRet);
			PMTS_ThrowException(DB_OPT_FAIL);		
		}

	}
    	                    
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CRecvBeps725::CheckIfSend720");
	return false;
	                    
}

int CRecvBeps725::Send720(void)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CRecvBeps725::Send720");

    char MsgID[40] = {0};
    int iRet = 0;
    char   sSignedStr[4096 + 1] = {0};
    char   m_sMesgID[20+1] = {0};
    beps720 m_beps720;
    
    if( !GetMsgIdValue(m_dbproc, MsgID, eMsgId,  SYS_BEPS, m_cBeps725.InstdDrctPty.c_str()) )
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "error");
        PMTS_ThrowException(PRM_FAIL);
    }
    
    if( !GetMsgIdValue(m_dbproc, m_sMesgID, eRefId, SYS_BEPS, m_cBeps725.InstdDrctPty.c_str()) )
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "error");
        PMTS_ThrowException(PRM_FAIL);
    }

    iRet = GetIsoDateTime(m_dbproc,SYS_BEPS,m_sIsoWorkDate);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败");
        PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }
	
    m_beps720.MsgId = MsgID;
    m_beps720.CreDtTm = m_sIsoWorkDate;
    m_beps720.InstgDrctPty = m_cBeps725.InstdDrctPty;
    m_beps720.GrpHdrInstgPty = m_cBeps725.InstdDrctPty;
    m_beps720.InstdDrctPty = "0000";
    m_beps720.GrpHdrInstdPty = "0000";
    m_beps720.SysCd = "BEPS";
    m_beps720.ChckDt = m_checkqry.m_checkdate;
    
	m_beps720.getOriSignStr();
	AddSign(m_beps720.m_sSignBuff.c_str(), 
	sSignedStr, 
	RAWSIGN, 
	m_cBeps725.InstdDrctPty.c_str());
	m_beps720.m_szDigitSign = sSignedStr;
    
    m_beps720.CreateXMlHeader("BEPS", \
                               m_sWorkDate, \
                               m_cBeps725.InstdDrctPty.c_str(), \
                               "0000", \
                               "beps.720.001.01",  \
                               m_sMesgID);

    iRet = m_beps720.CreateXml();
    if( RTN_SUCCESS != iRet )        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }


	m_checkqry.m_msgid = m_beps720.MsgId;
	m_checkqry.m_msgtype = "beps.720.001.01";
	m_checkqry.m_sapbank = m_beps720.InstgDrctPty;
	m_checkqry.m_checkdate = m_beps720.ChckDt;
	
	SETCTX(m_checkqry);
	iRet = m_checkqry.insert();
	if( 0 != iRet)
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "INSERT CM_CHECKQRY FILED[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "INSERT CM_CHECKQRY FILED!");
	}


	iRet = AddQueue(m_beps720.m_sXMLBuff, strlen(m_beps720.m_sXMLBuff.c_str()));

	//iRet = m_cMQAgent.PutMsg(g_szCLISENDBEPS, buffer, strlen(buffer));
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "往MQ发送消息失败！");
		PMTS_ThrowException(OPT_MQ_ADD_FAIL);
	}

                    
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CRecvBeps725::Send720");
	return iRet;
	                    
}

//__wsh 2012-10-18 ��ѹ����
int CRecvBeps725::UnPack(LPCSTR szMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
						NULL, "Enter CRecvBeps725::UnPack");
	int iRet = -1;

	if(NULL == szMsg || '\0' == szMsg[0]){
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "���ĳ���Ϊ��");
		PMTS_ThrowException(PRM_FAIL);
	}

	//��������
	if (OPERACT_SUCCESS != m_cBeps725.ParseXml(szMsg)){
		Trace(L_ERROR,  __FILE__,  __LINE__,
				NULL, "���Ľ�������! iRet= %d", iRet);

		PMTS_ThrowException(__FILE__, __LINE__,
				OPT_PRS_MSG_FAIL, "���Ľ�������");
	}

	m_strWorkDate = m_sWorkDate;

	//ZFPTLOG.SetLogInfo("725", m_cBeps725.MsgId.c_str());

	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvBeps725::UnPack");
	return iRet;
}

//__wsh 2012-10-18 ��������
int CRecvBeps725::Deal(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CRecvBeps725::Deal");
	int iRet = -1;

	//���оܾ�����
	if(m_cBeps725.TxDwnldRspnInfPrcSts == PROCESS_PR09){
		//����"С����ϸ�˶Ա�"��"��ϸ���ر�־"Ϊ�ܾ�����
		UpdateChkList("2");
		return RTN_SUCCESS;
	}

	//�������ص�ԭ��������(BASE64����)
	ParseCntt();

	iRet = DetailProc(m_strCntt.c_str());

	if(iRet == RTN_SUCCESS){
		//����С����ϸ�˶Ա���Ӧ��¼���ر�־Ϊ������
		//iRet = UpdateChkList("1");
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvBeps725::Deal");

	return iRet;
}

int CRecvBeps725::DetailProc(const char *szMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBeps725::DetailProc()");	


	int iRet		= -1;
	int iBizCode	= -1; 
	int iVersion	= -1;
	

	//取业务码	 
	iBizCode = GetBizCode(szMsg, iVersion);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iBizCode = %d", iBizCode);
	
	if (-1 == iBizCode)
	{
		return RTN_FAIL;
	}
	
	char szchBizCode[MAX_BIZ_CODE_LEN + 1] = {0};  // 业务码
	sprintf(szchBizCode, "%d", iBizCode);

	char sBizCode[MAX_BIZ_CODE_LEN + 1] = {0};	// 日志用
	sprintf(sBizCode, "%03d", iBizCode);
	
	CRecvBepsBase *PRecv = NULL;
		
	switch( iBizCode )
	{
		case 121:
		{
			PRecv = new CRecvbeps121;
			break;
		}
		case 1:
		{
			PRecv = new CRecvPkg001;
			break;
		}
		case 2:
		{
			PRecv = new CRecvPkg002;
			break;
		}
		case 3:
		{
			PRecv = new CRecvPkg003;
			break;
		}		   
		case 4:
		{
			PRecv = new CRecvPkg004;
			break;
		}		 
		case 122:
		{
			PRecv = new CRecvbeps122;
			break;
		}
		case 123:
		{
			PRecv = new CRecvBeps123;
			break;
		}
		case 124:
		{
			PRecv = new CRecvBeps124;
			break;
		}
		case 125:
		{
			PRecv = new CRecvBeps125;
			break;
		}
		case 127:
		{
			PRecv = new CRecvbeps127;
			break;
		}
		case 128:
		{
			PRecv = new CRecvBeps128;
			break;
		} 
		case 130:
		{
			PRecv = new CRecvBeps130;
			break;
		}	
		case 131:
		{
			PRecv = new CRecvBeps131;
			break;
		}	
		case 132:
		{
			PRecv = new CRecvBeps132;
			break;
		} 
		case 133:
		{
			PRecv = new CRecvBeps133;
			break;
		}	
		case 134:
		{
			PRecv = new CRecvBeps134;
			break;
		}
		case 324:
		{
			PRecv = new CRecvCmt324;
			break;
		}
		case 325:
		{
			PRecv = new CRecvCmt325;
			break;
		}
		case 380:
		{
			PRecv = new CRecvbeps380;
			break;
		}	  
		case 381:
		{
			PRecv = new CRecvbeps381;
			break;
		}					   
		case 382:
		{
			PRecv = new CRecvbeps382;
			break;
		}
		case 383:
		{
			PRecv = new CRecvbeps383;
			break;
		}		   
		case 384:
		{
			PRecv = new CRecvbeps384;
			break;
		} 
		case 385:
		{
			PRecv = new CRecvbeps385;
			break;
		}		  
		case 386:
		{
			PRecv = new CRecvbeps386;
			break;
		}
		case 387:
	   {
		   PRecv = new CRecvbeps387;
		   break;
	   }
		case 388:
		{
			PRecv = new CRecvbeps388;
			break;
		}
		case 389:
		{
			PRecv = new CRecvbeps389;
			break;
		}	
		case 392:
		{
			PRecv = new CRecvBeps392;
			break;
		}							  
		case 393:
		{
			PRecv = new CRecvBeps393;
			break;
		}
		case 394:
		{
			PRecv = new CRecvbeps394;
			break;
		}
		case 395:
		{
			PRecv = new CRecvbeps395;
			break;
		}				  
		case 397:
		{
			PRecv = new CRecvbeps397;
			break;
		}		
		case 399:
		{
			PRecv = new CRecvbeps399;
			break;
		}	 
		case 401:
		{
			PRecv = new CRecvbeps401;
			break;
		}
		case 402:
		{
			PRecv = new CRecvbeps402;
			break;
		}
		case 403:
		{
			PRecv = new CRecvbeps403;
			break;
		}
		case 404:
		{
			PRecv = new CRecvbeps404;
			break;
		}
		case 411:
		{
			PRecv = new CRecvBeps411;
			break;
		}
		case 412:
		{
			PRecv = new CRecvBeps412;
			break;
		}
		case 414:
		{
			PRecv = new CRecvBeps414;
			break;
		}		 
		case 415:
		{
			PRecv = new CRecvBeps415;
			break;
		}			
		case 418:
		{
			PRecv = new CRecvbeps418;
			break;
		}
		case 419:
		{
			PRecv = new CRecvbeps419;
			break;
		}
		case 721:
		{
			PRecv = new CRecvBeps721;
			break;
		}
		case 723:
		{
			PRecv = new CRecvBeps723;
			break;
		}
		case 5:
		{
			PRecv = new CRecvPkg005;
			break;
		}
		case 6:
		{
			PRecv = new CRecvPkg006;
			break;
		}
		case 7:
		{
			PRecv = new CRecvPkg007;
			break;
		}
		case 8:
		case 10:
		case 11:
		{
			PRecv = new CRecvPkg008;
			break;
		}		 
		case 9:
		{
			PRecv = new CRecvPkg009;
			break;
		}	  
		case 12:
		{
			PRecv = new CRecvPkg012;
			break;
		}
		case 13:
		{
			PRecv = new CRecvPkg013;
			break;
		}
		default:
		{
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ERROR iBizCode[%d]",iBizCode);
			return RTN_FAIL;
		}
	}
	
	PRecv->m_strBizCode  = szchBizCode;
	PRecv->m_iMsgVer	 = iVersion;
	PRecv->m_strRcvMsgID = m_strMsgID;
	PRecv->m_iErrMsgFlag = m_iErrMsgFlag;
	
	//ZFPTLOG.SetLogInfo(sBizCode, NULL);
	
	PRecv->doChildWork(szMsg);
	if (NULL != PRecv)
	{
		delete PRecv;
		PRecv = NULL;
	}
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBeps725::DetailProc()");

	return RTN_SUCCESS;
}


//__wsh 2012-10-18 �������صı�������
int CRecvBeps725::ParseCntt(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CRecvBeps725::ParseCntt");

	int iRet = RTN_SUCCESS;

	Trace(L_DEBUG, __FILE__, __LINE__, NULL,
		        "m_beps725.Cntt=[%s]", m_cBeps725.Cntt.c_str());

	char *pBuffer = new char[m_cBeps725.Cntt.length() + 1];
	if(pBuffer == NULL){
		Trace(L_ERROR, __FILE__, __LINE__,
				NULL, "__Alloc Memory Failed!!!");
		PMTS_ThrowException(FAILED);
	}

	memset(pBuffer, 0x00, m_cBeps725.Cntt.length() + 1);

	strcpy(pBuffer, m_cBeps725.Cntt.c_str()); //��������ԭ��

	//ȥ�ո�
	removeChar13_10(pBuffer);

	//BASE64ת��
	textBase64Decode(pBuffer, m_strCntt);

	Trace(L_DEBUG, __FILE__, __LINE__, NULL,
				"__�������:[%s]", m_strCntt.c_str());

	delete[] pBuffer;
	pBuffer = NULL;

	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvBeps725::ParseCntt");
	return iRet;
}

//__wsh 2012-10-18 ת����CMI ROUTERECV����
int CRecvBeps725::DumpToRouteRecv(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CRecvBeps725::DumpToRouteRecv");
	#if 0
	int iRet = -1;

	iRet = m_cMQAgent.PutMsg(g_SendQueue,
			m_strCntt.c_str(), m_strCntt.length());
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���͵�ROUTERECVʧ��!!!");
		PMTS_ThrowException(OPT_MQ_ADD_FAIL);
	}

	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���͵�ROUTERECV�ɹ�!!!");

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CRecvBeps725::DumpToRouteRecv");
	#endif
	return 0;
}

//__wsh 2012-10-18 ���¶�����ϸ
int CRecvBeps725::UpdateChkList(LPCSTR pState)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
    		NULL, "Enter CRecvBeps725::UpdateChkList");

    char szSql[1024 + 1]  = {0};
    int iRet= -1;
    string strSql = "";
    // �ܾ�ʱ���޸ĵ�ǰ�������������ر�־Ϊ��ʼ�ļ�¼
    if( 0 == strcmp("2", pState)){
        return 0;
        #if 0
        strSql.append("update bp_chklstlist set isdownload='");
        strSql.append(pState);
        strSql.append("' where chckdt='").append(m_strChckDt);
        strSql.append("' and isdownload='0' ");
        #endif
    }
    // ����ʱ���޸ĵ��ʼ�¼�����ر�־
    else{
        strSql.append("update bp_chklstlist set isdownload='");
        strSql.append(pState);
        strSql.append("' where orgnlinstgdrpty='");
        strSql.append(m_bpchklstlist.m_orgnlinstgdrpty);
        strSql.append("' and orgnlmsgid='");
        strSql.append(m_bpchklstlist.m_orgnlmsgid).append("' ");
    }

    Trace(L_INFO, __FILE__, __LINE__, NULL,
    				"___strSql=[%s]", strSql.c_str());
    SETCTX(m_bpchklstlist);
    iRet = m_bpchklstlist.execsql(strSql);
    if (iRet != SQL_SUCCESS ){
        Trace(L_ERROR, __FILE__, __LINE__, NULL,
        		"[bp_chklstlist]����ʧ��:[%d][%s]", iRet,
        		m_bpchklstlist.GetSqlErr());
        PMTS_ThrowException(DB_OPT_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__,
    			NULL, "Leave CRecvBeps725::UpdateChkList");

    return iRet;
}

//__wsh 2012-10-18 ��ǩ
void CRecvBeps725::ChkSign725(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CheckSign725");

	m_cBeps725.getOriSignStr();

	CheckSign(
		m_cBeps725.m_sSignBuff.c_str(),
		m_cBeps725.m_szDigitSign.c_str(),
		m_cBeps725.InstgDrctPty.c_str());

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CheckSign725");
}

