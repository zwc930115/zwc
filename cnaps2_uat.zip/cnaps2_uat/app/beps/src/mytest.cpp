/********************************************************************
文件名：recvfromfe.cpp
创建人：zny
日  期：2009.07.07
修改人：zj
日  期：
描  述：后台业务来账处理主控
版  本：
Copyright (c) 2009  YLINK
********************************************************************/
#include <stdlib.h>
#include <sstream>
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>

using namespace std;

int getFileText(char *  sFileName,char * sMsg)
{
	
	char sBuff[1024] ;
	//循环读取数据并处理
	FILE *fp = NULL; 
	
	fp = fopen(sFileName, "r");
	
	if ( fp == NULL )
	{
		printf("打开文件出错\n");
		return -1;	
	}
	
	int rendlen = 0;
	int iTotalLen = 0;
	while ( 1 )
	{
		memset(sBuff, 0, sizeof(sBuff));
		fgets(sBuff, sizeof(sBuff), fp)	;
		
        rendlen = strlen(sBuff);
		if (rendlen == 0)
			break;
		strcpy(sMsg+iTotalLen ,sBuff);
		iTotalLen += rendlen;
		
	}
	return 0;
	
} 




int main(int argc, char **argv)
{	
	string szTest = "0123456789abcdefg";
	printf("szTest=[%s]\n",szTest.substr(0,3).c_str());
   	
	return 0;
}
	
