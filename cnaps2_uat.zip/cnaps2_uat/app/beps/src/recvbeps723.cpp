
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbeps723.h"

#include "bpbcoutsndcl.h"
#include "bpbcoutrcvcl.h"
#include "bpbdsndcl.h"
#include "bpbdrcvcl.h"
#include "bpcolltnchrgscl.h"
#include "cmtransinfoqry.h"

using namespace ZFPT;

//extern char g_szCLISENDBEPS[128];

CRecvBeps723::CRecvBeps723()
{
	m_iLocalLess = 0;
	m_iSndCnt724 = 0;
}

CRecvBeps723::~CRecvBeps723()
{
}

//__wsh 2012-10-30 报文处理入口
int CRecvBeps723::Work(LPCSTR szMsg)
{
	Trace(L_DEBUG, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps723::Work");

	int iRet = -1;

	
	//解析报文
	iRet = UnPack(szMsg);
	if(!ChickIfContuine())
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL, "Do nothing");
		return 0;
	}

	//入明细对账辅助汇总表
	iRet = InsertData_cl();

	//入明细对账对账表
	iRet = InsertData_list();

	//核签
	ChkSign723();

	//对账
	iRet = DoCheck();

	Trace(L_DEBUG, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps723::Work");

	return RTN_SUCCESS;
}

bool CRecvBeps723::ChickIfContuine()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBeps723::ChickIfContuine()");

    int  iRet = -1;

	m_checkqry.m_msgid = m_cBeps723.DtlChckRspnOrgnlMsgId;
	m_checkqry.m_msgtype = m_cBeps723.DtlChckRspnOrgnlMT;
	m_checkqry.m_sapbank = m_cBeps723.DtlChckRspnOrgnlInstgPty;
	SETCTX(m_checkqry);
	iRet = m_checkqry.findByPK();
	if(1403 != iRet && 0 != iRet)
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FIND CM_CHECKQRY FILED[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "FIND CM_CHECKQRY FILED!");
	}
	else if(1403 == iRet)
	{	
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "MSGID=[%s] MSGTP=[%s] SAPBANK=[%s] NOT PMTS QRY",
			                        m_checkqry.m_msgid.c_str(),m_checkqry.m_msgtype.c_str(),m_checkqry.m_sapbank.c_str());		
		return false;
	}
	else{
		return true;
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "CRecvBeps723::ChickIfContuine()");
	return true;
}


//__wsh 2012-10-30 解析报文
int CRecvBeps723::UnPack(LPCSTR szMsg)
{
	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Enter CRecvBeps723::UnPack");
	int iRet = -1;

	if(NULL == szMsg || '\0' == szMsg[0]){
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "报文长度为空");
		PMTS_ThrowException(PRM_FAIL);
	}

	//解析报文
	if (OPERACT_SUCCESS != m_cBeps723.ParseXml(szMsg)){
		Trace(L_ERROR,  __FILE__,  __LINE__,
				NULL, "报文解析出错! iRet= %d", iRet);

		PMTS_ThrowException(__FILE__, __LINE__,
				OPT_PRS_MSG_FAIL, "报文解析出错");
	}

	m_strWorkDate = m_sWorkDate;

	//ZFPTLOG.SetLogInfo("723", m_cBeps723.MsgId.c_str());


	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps723::UnPack");

	return iRet;
}

//__wsh 2012-10-30 723报文核签
void CRecvBeps723::ChkSign723(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter ChkSign723");

	m_cBeps723.getOriSignStr();

	CheckSign(
		m_cBeps723.m_sSignBuff.c_str(),
		m_cBeps723.m_szDigitSign.c_str(),
		m_cBeps723.InstgDrctPty.c_str());

	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave ChkSign723");
}

//__wsh 2012-10-30 入明细对账辅助表
int CRecvBeps723::InsertData_cl(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps723::InsertData_cl");

	int iRet = -1;
	//辅助表这样的表结构如何能用于确定723是否收完?
	m_lstcl.m_instgdrctpty = m_cBeps723.InstgDrctPty; //发起直接参与者
	m_lstcl.m_instddrctpty = m_cBeps723.InstdDrctPty; //接收直接参与者


	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps723::InsertData_cl");

	return iRet;
}

//__wsh 2012-10-30 入明细对账表
int CRecvBeps723::InsertData_list(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps723::InsertData_list");

	int iRet = -1;

	int i = 0;
	SETCTX(m_lstlist);
	//解析并入库业务类报文
	int iPmtDtlsCnt = atoi(m_cBeps723.DtlChckPmtRspnInfNbOfTxs.c_str());
	m_bIsPmt = true;
	for(i = 0; i < iPmtDtlsCnt; ++i){
		GetDtlChckRspnDtls(i);
	}

	//解析并入库信息类报文
	int iMsgDtlsCnt = atoi(m_cBeps723.DtlChckMsgRspnNbOfTxs.c_str());
	m_bIsPmt = false;
	for(i = 0; i < iMsgDtlsCnt; ++i){
		GetDtlChckMsgRspnDtls(i);
	}

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps723::InsertData_list");

	return iRet;
}

//__wsh 2012-10-30 设置实体类并入库
int CRecvBeps723::SetAndAddData(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps723::SetAndAddData");
	int iRet = -1;
#define _DEBUG_DB(FIELD) //Trace(L_DEBUG, __FILE__, __LINE__, NULL, ">>>"#FIELD"=[%s]", FIELD.c_str())

	m_lstlist.m_workdate     = m_strWorkDate;    //工作日期
	m_lstlist.m_msgid        = m_cBeps723.MsgId; //723报文标识
	m_lstlist.m_instgdrctpty = m_cBeps723.InstgDrctPty; //发起直接参与机构
	m_lstlist.m_instddrctpty = m_cBeps723.InstdDrctPty; //接收直接参与机构
	m_lstlist.m_chckdt       = m_cBeps723.ChckDt;//对账日期
	
	_DEBUG_DB(m_lstlist.m_workdate);
	_DEBUG_DB(m_lstlist.m_msgid);
	_DEBUG_DB(m_lstlist.m_instgdrctpty);
	_DEBUG_DB(m_lstlist.m_instddrctpty);
	_DEBUG_DB(m_lstlist.m_chckdt);

	if(m_bIsPmt){
		m_lstlist.m_msgetype = m_cBeps723.DtlChckRspnDtlsMT;//报文类型
		m_lstlist.m_txnetgdt = m_cBeps723.TxNetgDt; //轧差日期
		m_lstlist.m_txnetgrnd= m_cBeps723.TxNetgRnd;//轧差场次
		m_lstlist.m_sndrcvtp = m_cBeps723.DtlChckRspnDtlsSndRcvTp; //往来标识
		m_lstlist.m_prcsts   = m_cBeps723.DtlChckRspnDtlsPrcSts; //报文处理状态
		m_lstlist.m_orgnlmsgid = m_cBeps723.OrgnlPmtDtlsOrgnlMsgId; //原包报文标识
		m_lstlist.m_orgnlinstgdrpty = m_cBeps723.OrgnlPmtDtlsOrgnlInstgPty; //原包发起机构
		m_lstlist.m_orgnlmsgtp = m_cBeps723.OrgnlPmtDtlsOrgnlMT; //原包报文类型
		m_lstlist.m_ttlcnt   = atoi(m_cBeps723.TtlCnt.c_str()); //包明细笔数
		m_lstlist.m_ctrlsum  = atof(m_cBeps723.CtrlSum.c_str()); //包成功金额
	}
	else{ 
		m_lstlist.m_msgetype = m_cBeps723.DtlChckMsgRspnDtlsMT;//报文类型
		m_lstlist.m_txnetgdt = m_cBeps723.DtlChckMsgRspnDtlsRcvDt; //受理日期
		m_lstlist.m_txnetgrnd= "0";//轧差场次, 固定写一个0
		m_lstlist.m_sndrcvtp = m_cBeps723.DtlChckMsgRspnDtlsSndRcvTp; //往来标识
		m_lstlist.m_prcsts   = m_cBeps723.OrgnlMsgDtlsPrcSts; //报文处理状态,不用于对账
		m_lstlist.m_orgnlmsgid = m_cBeps723.OrgnlMsgDtlsOrgnlMsgId; //原包报文标识
		m_lstlist.m_orgnlinstgdrpty = m_cBeps723.OrgnlMsgDtlsOrgnlInstgPty; //原包发起机构
		m_lstlist.m_orgnlmsgtp = m_cBeps723.OrgnlMsgDtlsOrgnlMT; //原包报文类型
		m_lstlist.m_ttlcnt   = 0; //包明细笔数
		m_lstlist.m_ctrlsum  = 0.0; //包成功金额
	}

	#if 0
	if((m_lstlist.m_msgetype == "beps.382.001.01"||m_lstlist.m_msgetype == "beps.386.001.01")
	  &&m_lstlist.m_sndrcvtp == "SR01")
	{
		if(m_cBeps723.OrgnlMsgDtlsPmtId == "PT00")
		{
			m_lstlist.m_sndrcvtp == "SR02"
		}
	}
	#endif
	_DEBUG_DB(m_lstlist.m_msgetype);
	_DEBUG_DB(m_lstlist.m_txnetgdt);
	_DEBUG_DB(m_lstlist.m_txnetgrnd);
	_DEBUG_DB(m_lstlist.m_sndrcvtp);
	_DEBUG_DB(m_lstlist.m_prcsts);
	_DEBUG_DB(m_lstlist.m_orgnlinstgdrpty);
	_DEBUG_DB(m_lstlist.m_orgnlmsgtp);

	//比较本地与NPC报文状态， 得出对账状态
	DoCompare();
	m_lstlist.m_checkstate = m_strChkSt; //对账状态
	m_lstlist.m_isdownload = "0"; //下载标志

	iRet = m_lstlist.insert();
	if(iRet != SQL_SUCCESS && iRet != DUPLICATE_KEY){
		Trace(L_DEBUG, __FILE__, __LINE__, NULL,
				"[bp_chklstlist]插入失败:%s", m_lstlist.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps723::SetAndAddData");

	return RTN_SUCCESS;
}

//__wsh 2012-10-30 业务比较
void CRecvBeps723::DoCompare(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps723::DoCompare");

	//查询本地业务
	int iRet = m_cChkHelper.GetLocalBiz(m_lstlist.m_msgetype,
	    m_lstlist.m_orgnlmsgid, m_lstlist.m_orgnlinstgdrpty, 
	    m_lstlist.m_sndrcvtp.c_str(), m_cBeps723.OrgnlMsgDtlsPmtId.c_str());
	
	//非支付类业务金额，明细笔数清0
	if(!m_bIsPmt){
		m_cChkHelper.m_dLocalCtrlSum = 0.0;
		m_cChkHelper.m_iLocalTtlCnt  = 0;
	}

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "人行{金额:[%f]，状态:[%s], 明细笔数:[%d]}",
	      m_lstlist.m_ctrlsum, m_lstlist.m_prcsts.c_str(), m_lstlist.m_ttlcnt); 

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "本地{金额:[%f]，状态:[%s], 明细笔数:[%d]}",
	      m_cChkHelper.m_dLocalCtrlSum, m_cChkHelper.m_strLocalBizSt.c_str(), m_cChkHelper.m_iLocalTtlCnt);
	    
	if(iRet == SQL_SUCCESS){
		//找到本地业务进行比较
		if(m_cChkHelper.m_strLocalBizSt == m_lstlist.m_prcsts &&
				AmtEqual(m_cChkHelper.m_dLocalCtrlSum, m_lstlist.m_ctrlsum)){
			//比较终态日期，相符则对账相符，否则状态不符
			m_strChkSt = (m_cChkHelper.m_strLocalFinalStateDate == m_lstlist.m_txnetgdt)
				? PR_CNCH_01 : PR_CNCH_03;
		}
		else if(m_cChkHelper.m_strLocalBizSt == m_lstlist.m_prcsts &&
				!AmtEqual(m_cChkHelper.m_dLocalCtrlSum, m_lstlist.m_ctrlsum)){
			m_strChkSt = PR_CNCH_06; //金额不符
		}
		else if(m_cChkHelper.m_strLocalBizSt != m_lstlist.m_prcsts &&
				AmtEqual(m_cChkHelper.m_dLocalCtrlSum, m_lstlist.m_ctrlsum)){
			m_strChkSt = PR_CNCH_03; //状态不符
		}
		else{
			m_strChkSt = PR_CNCH_07; //金额状态不符
		}

		//如果原业务只是状态不平， 调平状态
		if(m_strChkSt == PR_CNCH_03){
			AdjustOrgnlBizSt();
		}

	}
	else if(iRet == SQLNOTFOUND){
		m_strChkSt = PR_CNCH_04; //本地少
		++m_iLocalLess;
		//本地少且为来报时需下载明细
		if(m_lstlist.m_sndrcvtp == "SR01"){
			AddDtls724();
		}
	}
	else{
        m_strChkSt = PR_CNCH_02;
	}
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__对账结果:[%s]", m_strChkSt.c_str());
	


	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps723::DoCompare");
}

//__wsh 2012-10-31 获取业务类报文节点值
//i: 节点索引
void CRecvBeps723::GetDtlChckRspnDtls(int i)
{
    Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps723::GetDtlChckRspnDtls");
			
#define GETCHKRSPDTL(NAME) m_cBeps723.NAME = \
	m_cBeps723.GetValueFromCycle("DtlChckRspnDtls", #NAME, i);\
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, \
			"###m_cBeps723."#NAME"=[%s]", m_cBeps723.NAME.c_str())
			
	GETCHKRSPDTL(DtlChckRspnDtlsSndRcvTp);
	GETCHKRSPDTL(TxNetgDt);
	GETCHKRSPDTL(TxNetgRnd);
	GETCHKRSPDTL(DtlChckRspnDtlsMT);
	GETCHKRSPDTL(DtlChckRspnDtlsPrcSts);
	GETCHKRSPDTL(DtlChckRspnDtlsNbOfDtls);
	//解析子节点明细存库
	int iNbOfDtls = atoi(m_cBeps723.DtlChckRspnDtlsNbOfDtls.c_str());
	for(int j = 1; j <= iNbOfDtls; ++j){
		GetOrgnlPmtDtls(i, j);
		SetAndAddData();
	}
	//循环加签
	m_cBeps723.getDtlChckRspnDtls();
	
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps723::GetDtlChckRspnDtls");
}

//__wsh 2012-10-31 获取业务类报文明细节点值
//i: 父节点索引
//j: 子节点索引
void CRecvBeps723::GetOrgnlPmtDtls(int i, int j)
{
    Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps723::GetOrgnlPmtDtls");
			
#define GETORGNLPMTDTL(NAME) m_cBeps723.NAME = \
	m_cBeps723.GetValueFromLiLCycle("DtlChckRspnDtls", i, \
			"OrgnlPmtDtls", j, #NAME);\
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, \
			"###m_cBeps723."#NAME"=[%s]", m_cBeps723.NAME.c_str())
    
	GETORGNLPMTDTL(OrgnlPmtDtlsOrgnlMsgId);
	GETORGNLPMTDTL(OrgnlPmtDtlsOrgnlInstgPty);
	GETORGNLPMTDTL(OrgnlPmtDtlsOrgnlMT);
	GETORGNLPMTDTL(TtlCnt);
	GETORGNLPMTDTL(CtrlSum);
	GETORGNLPMTDTL(Ccy);
	//循环加签
	m_cBeps723.getOrgnlPmtDtls();
	
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps723::GetOrgnlPmtDtls");
}

//__wsh 2012-10-31 获取信息类报文节点值
//i: 节点索引
void CRecvBeps723::GetDtlChckMsgRspnDtls(int i)
{
    Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps723::GetDtlChckMsgRspnDtls");
			
#define GETMSGRSPDTL(NAME) m_cBeps723.NAME = \
	m_cBeps723.GetValueFromCycle("DtlChckMsgRspnDtls", #NAME, i);\
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, \
			"###"#NAME"=[%s]", m_cBeps723.NAME.c_str())    
	GETMSGRSPDTL(DtlChckMsgRspnDtlsSndRcvTp);
	GETMSGRSPDTL(DtlChckMsgRspnDtlsMT);
	GETMSGRSPDTL(DtlChckMsgRspnDtlsRcvDt);
	GETMSGRSPDTL(DtlChckMsgRspnDtlsNbOfDtls);
	//解析子节点明细存库
	int iNbOfDtls = atoi(m_cBeps723.DtlChckMsgRspnDtlsNbOfDtls.c_str());
	for(int j = 1; j <= iNbOfDtls; ++j){
		GetOrgnlMsgDtls(i, j);
		SetAndAddData();
	}
	//循环加签
	m_cBeps723.getDtlChckMsgRspnDtls();
	
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps723::GetDtlChckMsgRspnDtls");
}

//__wsh 2012-10-31 获取信息类报文明细节点值
//i: 父节点索引
//j: 子节点索引
void CRecvBeps723::GetOrgnlMsgDtls(int i, int j)
{
    Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps723::GetOrgnlMsgDtls");
			
#define GETORGNLMSGDTL(NAME) m_cBeps723.NAME = \
	m_cBeps723.GetValueFromLiLCycle("DtlChckMsgRspnDtls", i, \
			"OrgnlMsgDtls", j, #NAME);\
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, \
			"###"#NAME"=[%s]", m_cBeps723.NAME.c_str())
	GETORGNLMSGDTL(OrgnlMsgDtlsOrgnlMsgId);
	GETORGNLMSGDTL(OrgnlMsgDtlsOrgnlInstgPty);
	GETORGNLMSGDTL(OrgnlMsgDtlsOrgnlMT);
	GETORGNLMSGDTL(OrgnlMsgDtlsPrcSts);
	GETORGNLMSGDTL(OrgnlMsgDtlsPmtId);
	//循环加签
	m_cBeps723.getOrgnlMsgDtls();
	
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps723::GetOrgnlMsgDtls");
}

//__wsh 2012-10-31 调平原业务
int CRecvBeps723::AdjustOrgnlBizSt(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps723::AdjustOrgnlBizSt");
	int iRet = -1;

	string strSql = "";
	string strSqlList = "";
	if(m_bIsPmt){
		//清算轧差类， 更新轧差日期， 轧差场次， 业务状态， 清算/终态日期
		strSql.append(" update ").append(m_cChkHelper.m_szTblNmCl);
		strSql.append(" set statetime=sysdate, netgdt='").append(m_cBeps723.TxNetgDt);
		strSql.append("', netgrnd='").append(m_cBeps723.TxNetgRnd);
		strSql.append("', busistate='").append(m_cBeps723.DtlChckRspnDtlsPrcSts);
		strSql.append("', finalstatedate='").append(m_cBeps723.ChckDt);
		strSql.append("' where msgid='").append(m_cBeps723.OrgnlPmtDtlsOrgnlMsgId);
		strSql.append("' and instgdrctpty='").append(m_cBeps723.OrgnlPmtDtlsOrgnlInstgPty).append("' ");
		if(m_cChkHelper.m_iTblNo == TBL_COLL){//代收付需要加上业务来源标譊			
			if(m_lstlist.m_sndrcvtp == TAG_RECV
			   && m_cBeps723.OrgnlMsgDtlsPmtId == TAG_PT00)
			{	
				strSql.append("and srcflag=").append(m_strCollSrcFlag).append("'3' ");
			}
			else if(m_lstlist.m_sndrcvtp == TAG_RECV
			   && m_cBeps723.OrgnlMsgDtlsPmtId == TAG_PT01)
			{	
				strSql.append("and srcflag=").append(m_strCollSrcFlag).append("'2' ");
			}
			else
			{
				strSql.append("and srcflag=").append(m_strCollSrcFlag).append("'1' ");
			}		
			//strSql.append("and srcflag=").append(m_strCollSrcFlag).append("' ");
		}

		if(m_cChkHelper.m_iTblNo == TBL_CDTR || m_cChkHelper.m_iTblNo == TBL_DBTR){
		    //借贷记表，需要更新明细
		    //清算轧差类， 更新轧差日期， 轧差场次， 业务状态， 清算/终态日期
    		strSqlList.append(" update ").append(m_cChkHelper.m_szTblNmList);
    		strSqlList.append(" set statetime=sysdate, netgdt='").append(m_cBeps723.TxNetgDt);
    		strSqlList.append("', netgrnd='").append(m_cBeps723.TxNetgRnd);
    		strSqlList.append("', busistate='").append(m_cBeps723.DtlChckRspnDtlsPrcSts);
    		strSqlList.append("', finalstatedate='").append(m_cBeps723.ChckDt);
    		strSqlList.append("' where msgid='").append(m_cBeps723.OrgnlPmtDtlsOrgnlMsgId);
    		strSqlList.append("' and instgdrctpty='").append(m_cBeps723.OrgnlPmtDtlsOrgnlInstgPty).append("' ");
		}
	}
	else{
		//信息类，更新业务状态， 终态日期
		strSql.append("update ").append(m_cChkHelper.m_szTblNmCl);
		strSql.append(" set statetime=sysdate, busistate='").append(m_cBeps723.OrgnlMsgDtlsPrcSts);
		strSql.append("', finalstatedate='").append(m_lstlist.m_txnetgdt);
		strSql.append("' where msgid='").append(m_cBeps723.OrgnlMsgDtlsOrgnlMsgId);
		if(m_cChkHelper.m_iTblNo == TBL_TXIQ){//查询查复, 明细对账原业务为间接参与机构
			strSql.append("' and instgindrctpty='").append(m_cBeps723.OrgnlMsgDtlsOrgnlInstgPty).append("' ");
			strSql += (m_lstlist.m_sndrcvtp == "SR00") ?
							" and rsflag<'2' " : " and rsflag='2' ";
		}
		else
		{
			strSql.append("' and instgdrctpty='").append(m_cBeps723.OrgnlMsgDtlsOrgnlInstgPty).append("' ");
			if(m_cChkHelper.m_iTblNo == TBL_COLL){//代收付需要加上业务来源标识
				if(m_lstlist.m_sndrcvtp == TAG_RECV
				   && m_cBeps723.OrgnlMsgDtlsPmtId == TAG_PT00)
				{	
					strSql.append("and srcflag=").append(m_strCollSrcFlag).append("'3' ");
				}
				else if(m_lstlist.m_sndrcvtp == TAG_RECV
				   && 0 == strcmp(m_cBeps723.OrgnlPmtDtlsOrgnlMT.c_str(),"beps.381.001.01"))
				{	
					strSql.append("and srcflag=").append(m_strCollSrcFlag).append("'3' ");
				}			
				else if(m_lstlist.m_sndrcvtp == TAG_RECV
				   && 0 == strcmp(m_cBeps723.OrgnlPmtDtlsOrgnlMT.c_str(),"beps.381.001.01"))
				{	
					strSql.append("and srcflag=").append(m_strCollSrcFlag).append("'3' ");
				}	
				else if(m_lstlist.m_sndrcvtp == TAG_RECV
				   && 0 == strcmp(m_cBeps723.OrgnlPmtDtlsOrgnlMT.c_str(),"beps.385.001.01"))
				{	
					strSql.append("and srcflag=").append(m_strCollSrcFlag).append("'3' ");
				}		
				else if(m_lstlist.m_sndrcvtp == TAG_RECV
				   && 0 == strcmp(m_cBeps723.OrgnlPmtDtlsOrgnlMT.c_str(),"beps.383.001.01"))
				{	
					strSql.append("and srcflag=").append(m_strCollSrcFlag).append("'2' ");
				}		
				else if(m_lstlist.m_sndrcvtp == TAG_RECV
				   && 0 == strcmp(m_cBeps723.OrgnlPmtDtlsOrgnlMT.c_str(),"beps.387.001.01"))
				{	
					strSql.append("and srcflag=").append(m_strCollSrcFlag).append("'2' ");
				}																
				else if(m_lstlist.m_sndrcvtp == TAG_RECV
				   && m_cBeps723.OrgnlMsgDtlsPmtId == TAG_PT01)
				{	
					strSql.append("and srcflag=").append(m_strCollSrcFlag).append("'2' ");
				}
				else
				{
					strSql.append("and srcflag=").append(m_strCollSrcFlag).append("'1' ");
				}	
			}
		}
		if(m_cChkHelper.m_iTblNo == TBL_CDTR || m_cChkHelper.m_iTblNo == TBL_DBTR){
		    //借贷记表，需要更新明细
		    //清算轧差类， 更新轧差日期， 轧差场次， 业务状态， 清算/终态日期
			strSqlList.append("update ").append(m_cChkHelper.m_szTblNmList);
			strSqlList.append(" set statetime=sysdate, busistate='").append(m_cBeps723.OrgnlMsgDtlsPrcSts);
			strSqlList.append("', finalstatedate='").append(m_lstlist.m_txnetgdt);
			strSqlList.append("' where msgid='").append(m_cBeps723.OrgnlMsgDtlsOrgnlMsgId);
			strSqlList.append("' and instgdrctpty='").append(m_cBeps723.OrgnlMsgDtlsOrgnlInstgPty).append("' ");
			
		}		
	}

	Trace(L_INFO, __FILE__, __LINE__, NULL, "__strSql=[%s]", strSql.c_str());

	iRet = m_lstlist.execsql(strSql);
	if(iRet == SQL_SUCCESS){

		//更新成功，对账状态为相符
		m_strChkSt = PR_CNCH_01;

	    //借贷记，需要更新明细
	    Trace(L_INFO, __FILE__, __LINE__, 
	        NULL, "__strSqlList=[%s]", strSqlList.c_str());
	    if(m_cChkHelper.m_iTblNo == TBL_CDTR || m_cChkHelper.m_iTblNo == TBL_DBTR){
	        iRet = m_lstlist.execsql(strSqlList);
	        if(iRet != SQL_SUCCESS){
	            Trace(L_ERROR, __FILE__, __LINE__, NULL,
				    "[%s]更新失败:[%s]", m_cChkHelper.m_szTblNmList, m_lstlist.GetSqlErr());
	            //更新找不到原业务不抛异常
	            if(iRet != SQLNOTFOUND){
	            	PMTS_ThrowException(DB_UPDATE_FAIL);
	            }
	        }
	    }
	}
	else{
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[%s]更新失败:[%s]", m_cChkHelper.m_szTblNmCl, m_lstlist.GetSqlErr());
		//更新找不到原业务不抛异常
		if(iRet != SQLNOTFOUND){
			PMTS_ThrowException(DB_UPDATE_FAIL);
		}
	}

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps723::AdjustOrgnlBizSt");

	return iRet;
}

//__wsh 2012-11-01 添加节点到724， 目前只下载来报少的业务报文
//szSR: 往来标识 SR00往报， SR01来报
void CRecvBeps723::AddDtls724(LPCSTR szSR)
{
	m_cBeps724.AddNodeToSubcycle("SndRcvIp",      szSR);
	m_cBeps724.AddNodeToSubcycle("OrgnlMsgId",    m_lstlist.m_orgnlmsgid.c_str());
	m_cBeps724.AddNodeToSubcycle("OrgnlInstgPty", m_lstlist.m_orgnlinstgdrpty.c_str());
	m_cBeps724.AddNodeToSubcycle("OrgnlMT",       m_lstlist.m_orgnlmsgtp.c_str());
	m_cBeps724.AddNodeToSubcycle("PmtId",         m_cBeps724.PmtId.c_str());
	m_cBeps724.AddSubcycleToNode("DwnldReqTxsDtls");
	//循环加签
	m_cBeps724.SndRcvIp     = szSR;
	m_cBeps724.OrgnlMsgId   = m_lstlist.m_orgnlmsgid.c_str();
	m_cBeps724.OrgnlInstgPty= m_lstlist.m_orgnlinstgdrpty.c_str();
	m_cBeps724.OrgnlMT      = m_lstlist.m_orgnlmsgtp.c_str();

	m_cBeps724.getDwnldReqTxsDtls();
	++m_iSndCnt724;
}

//__wsh 2012-11-01 724往报加签
void CRecvBeps723::AddSign724(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CRecvBeps723::AddSign724");

	char   sSignedStr[4096 + 1] = {0};

	m_cBeps724.getOriSignStr();
	
	AddSign(m_cBeps724.m_sSignBuff.c_str(), 
	sSignedStr, 
	RAWSIGN, 
	m_cBeps723.InstdDrctPty.c_str());

	m_cBeps724.m_szDigitSign = sSignedStr;

	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Leave CRecvBeps723::AddSign724");
}

//__wsh 2012-11-01 组724报文， 向NPC申请下载本地少的业务包
int CRecvBeps723::RequestBizDtls724(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CSendBeps388::RequestBizDtls724");
	int iRet = -1;

	//获取报文创建日期时间
	char szISoDt[64] = {0};
	iRet = GetIsoDateTime(m_dbproc, SYS_BEPS, szISoDt);
	if(iRet != RTN_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__,
					NULL, "获取报文创建日期时间失败！");
		PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
	}

	//获取报文标识
	char szMsgId[32] = {0};
	if(!GetMsgIdValue(m_dbproc, szMsgId,
			eMsgId, SYS_BEPS, m_cBeps723.InstdDrctPty.c_str())){
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "获取报文标识失败!");
		PMTS_ThrowException(OPT_GET_MESGREFID_FAIL);
	}

	//业务头
	m_cBeps724.MsgId            = szMsgId;
	m_cBeps724.CreDtTm          = szISoDt;
	m_cBeps724.InstgDrctPty     = m_cBeps723.InstdDrctPty;
	m_cBeps724.GrpHdrInstgPty   = m_cBeps723.InstdDrctPty;
	m_cBeps724.InstdDrctPty     = m_cBeps723.InstgDrctPty;
	m_cBeps724.GrpHdrInstdPty   = m_cBeps723.InstgDrctPty;
	m_cBeps724.SysCd            = "BEPS";
	m_cBeps724.Rmk              = "";
	char szCnt[16] = {0};
	snprintf(szCnt, sizeof(szCnt), "%d", m_iSndCnt724);
	m_cBeps724.NbOfTxs = szCnt;

	//获取通信参与号
	char szRefId[64] = {0};
	if( !GetMsgIdValue(m_dbproc, szRefId, eRefId, SYS_BEPS) ){
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "获取通信参与号出错!");
		PMTS_ThrowException(PRM_FAIL);
	}

	//加签
	AddSign724();

	//创建消息头
	m_cBeps724.CreateXMlHeader(
				"BEPS",
				m_sWorkDate,
				m_cBeps723.InstdDrctPty.c_str(),
				m_cBeps723.InstgDrctPty.c_str(),
				"beps.724.001.01",
				szRefId);

	//创建XML报文
	iRet = m_cBeps724.CreateXml();
	if(RTN_SUCCESS != iRet){
		Trace(L_ERROR,  __FILE__,  __LINE__,
				NULL, "创建报文失败,iRet=%d", iRet);
		PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
	}

	m_checkqry.m_msgid = m_cBeps724.MsgId;
	m_checkqry.m_msgtype = "beps.724.001.01";
	m_checkqry.m_sapbank = m_cBeps724.InstgDrctPty;
	m_checkqry.m_checkdate = m_cBeps723.ChckDt;
	
	SETCTX(m_checkqry);
	iRet = m_checkqry.insert();
	if( 0 != iRet)
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "INSERT CM_CHECKQRY FILED[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "INSERT CM_CHECKQRY FILED!");
	}

	iRet = AddQueue(m_cBeps724.m_sXMLBuff, m_cBeps724.m_sXMLBuff.length());

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendBeps388::RequestBizDtls724");

	return iRet;
}

//__wsh 2012-11-01 明细总对账入口
int CRecvBeps723::DoCheck(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CSendBeps388::DoCheck");
	int iRet = -1;

	if(m_iSndCnt724 > 0){
		RequestBizDtls724();
	}

	m_lstlist.commit();

	//判断是否已经收完723报文
	if( IsRecvAll() ){
		if( GetChklstCntByCondition(1)
				== atoi(m_cBeps723.TtlNb.c_str()) ){
			//对账相符,且没有达到最大发送次数
			if( !IsCriticalTimes() ){
				m_cChkHelper.UpdateBChkState(m_cBeps723.InstdDrctPty,
							m_cBeps723.ChckDt, PR_CNCH_23);
				//发送720申请汇总对账721
				Send720();
			}
		}
		else if( GetChklstCntByCondition(2) > 0 ){
			//来报少
			m_cChkHelper.UpdateBChkState(m_cBeps723.InstdDrctPty,
					m_cBeps723.ChckDt, PR_CNCH_25,m_iSndCnt724,0 );
		}
		else{
			//金额不符或往报少
			m_cChkHelper.UpdateBChkState(m_cBeps723.InstdDrctPty,
					m_cBeps723.ChckDt, PR_CNCH_10);
		}
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendBeps388::DoCheck");

	return RTN_SUCCESS;
}

//__wsh 2012-11-01 判断是否已经收完723
bool CRecvBeps723::IsRecvAll(void)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, 
	                    "Enter CRecvBeps723::IsRecvAll");
	bool bRet = false;
    char szSql[128] = {0};
    snprintf(szSql, sizeof(szSql), " chckdt='%s' and instddrctpty='%s' ",
        m_cBeps723.ChckDt.c_str(), m_cBeps723.InstdDrctPty.c_str());
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__szSql=[%s]", szSql);
    if(m_lstlist.findcount(szSql) == SQL_SUCCESS){
        int iTtlNb = atoi(m_cBeps723.TtlNb.c_str());
        Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
            "下载明细总数目:%d, 已下载明细数目:%d", iTtlNb, m_lstlist.m_iCount);
        bRet =  (iTtlNb == m_lstlist.m_iCount);
    }
    else{
        Trace(L_ERROR, __FILE__, __LINE__, NULL,
            "[bp_chklstlist]查询失败:%s", m_lstlist.GetSqlErr());
        PMTS_ThrowException(DB_FIND_FAIL);
    }
    
     Trace(L_INFO, __FILE__, __LINE__, NULL, 
	                    "Leave CRecvBeps723::IsRecvAll");
	return bRet;
}

//__wsh 2012-11-01 发送720申请721重新进行汇总对账
int CRecvBeps723::Send720(void)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, 
	                    "Enter CRecvBeps723::Send720");

    char MsgID[40] = {0};
    int iRet = 0;
    char   sSignedStr[4096 + 1] = {0};
    char   m_sMesgID[20+1] = {0};
    beps720 m_beps720;
    
    if( !GetMsgIdValue(m_dbproc, MsgID, eMsgId,  SYS_BEPS, m_cBeps723.InstdDrctPty.c_str()) )
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "error");
        PMTS_ThrowException(PRM_FAIL);
    }
    
    if( !GetMsgIdValue(m_dbproc, m_sMesgID, eRefId, SYS_BEPS, m_cBeps723.InstdDrctPty.c_str()) )
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "error");
        PMTS_ThrowException(PRM_FAIL);
    }

	memset(m_sIsoWorkDate, '\0', sizeof(m_sIsoWorkDate));
	
    iRet = GetIsoDateTime(m_dbproc,SYS_BEPS,m_sIsoWorkDate);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败");
        PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }
	
    m_beps720.MsgId = MsgID;
    m_beps720.CreDtTm = m_sIsoWorkDate;
    m_beps720.InstgDrctPty = m_cBeps723.InstdDrctPty;
    m_beps720.GrpHdrInstgPty = m_cBeps723.InstdDrctPty;
    m_beps720.InstdDrctPty = "0000";
    m_beps720.GrpHdrInstdPty = "0000";
    m_beps720.SysCd = "BEPS";
    m_beps720.ChckDt = m_cBeps723.ChckDt;
    
	m_beps720.getOriSignStr();
	AddSign(m_beps720.m_sSignBuff.c_str(), 
	sSignedStr, 
	RAWSIGN, 
	m_cBeps723.InstdDrctPty.c_str());
	m_beps720.m_szDigitSign = sSignedStr;
    
    m_beps720.CreateXMlHeader("BEPS", \
                               m_sWorkDate, \
                               m_cBeps723.InstdDrctPty.c_str(), \
                               "0000", \
                               "beps.720.001.01",  \
                               m_sMesgID);

    iRet = m_beps720.CreateXml();
    if( RTN_SUCCESS != iRet )        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }

	m_checkqry.m_msgid = m_beps720.MsgId;
	m_checkqry.m_msgtype = "beps.720.001.01";
	m_checkqry.m_sapbank = m_beps720.InstgDrctPty;
	m_checkqry.m_checkdate = m_beps720.ChckDt;
	
	SETCTX(m_checkqry);
	iRet = m_checkqry.insert();
	if( 0 != iRet)
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "INSERT CM_CHECKQRY FILED[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "INSERT CM_CHECKQRY FILED!");
	}


	iRet = AddQueue(m_beps720.m_sXMLBuff, strlen(m_beps720.m_sXMLBuff.c_str()));

	//iRet = m_cMQAgent.PutMsg(g_szCLISENDBEPS, buffer, strlen(buffer));
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "往MQ发送消息失败！");
		PMTS_ThrowException(OPT_MQ_ADD_FAIL);
	}

                    
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CRecvBeps723::Send720");
	return iRet;
	                    
}

//__wsh 2012-11-01 比较金额
bool CRecvBeps723::AmtEqual(double dAmt1, double dAmt2)
{
	char szAmt1[32] = {0};
	char szAmt2[32] = {0};
	snprintf(szAmt1, sizeof(szAmt1), "%.02f", dAmt1);
	snprintf(szAmt2, sizeof(szAmt2), "%.02f", dAmt2);
	return strcmp(szAmt1, szAmt2) == 0 ? true : false;
}

//__wsh 2013-04-10
//iCondition: 1 查询对账相符数目 2 查询往报往报少
int CRecvBeps723::GetChklstCntByCondition(int iCondition)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL,
		      "Enter CRecvBeps723::GetChklstCntByCondition");

	char szSql[256] = {0};
	if(iCondition == 1){
		//查询对账相符数目
		snprintf(szSql, sizeof(szSql),
				" chckdt='%s' and instddrctpty='%s' and checkstate='01' ",
				m_cBeps723.ChckDt.c_str(), m_cBeps723.InstdDrctPty.c_str());
	}
	else if(iCondition == 2){
		//查询往报往报少
		snprintf(szSql, sizeof(szSql),
				" chckdt='%s' and instddrctpty='%s' "
				"and sndrcvtp='SR01' and checkstate='04' ",
				m_cBeps723.ChckDt.c_str(), m_cBeps723.InstdDrctPty.c_str());
	}
	else{

	}

	iRet = m_lstlist.findcount(szSql);
	if(iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[bp_chklstlist]查询失败:[%s]", m_lstlist.GetSqlErr());
		PMTS_ThrowException(DB_FIND_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__, NULL,
			"Condition[%d] Count[%d]", iCondition, m_lstlist.m_iCount);

	Trace(L_INFO, __FILE__, __LINE__, NULL,
			  "Leave CRecvBeps723::GetChklstCntByCondition");

	return m_lstlist.m_iCount;
}

/**
 * 判断当前对账日期是否已达到最大自动发起710报文次数， 防止数据异常
 * 导致无限次自动发送710, 默认最大发3次
 */
bool CRecvBeps723::IsCriticalTimes(int max_times)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CRecvBeps723::IsCriticalTimes");

	bool bRet = false;

	/*
	 * 保存已发送次数及当前对账日期
	 */
	static int  _times = 0;      /*已发送710次数*/
	static char _chkdt[12] = {0};/*当前对账日期*/

	if(m_cBeps723.ChckDt != _chkdt){
		/*如果对账日期已经变更或初次执行，  次数清0并给*/
		_times = 0;
		snprintf(_chkdt, sizeof(_chkdt), m_cBeps723.ChckDt.c_str());
	}

	Trace(L_INFO, __FILE__, __LINE__, NULL,
			"对账日期:[%s]已发送720次数:[%d]", _chkdt, _times);

	++_times;

	Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CRecvBeps723::IsCriticalTimes");

	return (_times > max_times);
}
