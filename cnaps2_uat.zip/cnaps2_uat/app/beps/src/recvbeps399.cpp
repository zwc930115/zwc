/******************************************************************** 
文件名： recvbeps399.cpp
创建人： handongfeng
日  期： 2011-02-23
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif
#include "recvbeps399.h"

CRecvbeps399::CRecvbeps399()
{
}

CRecvbeps399::~CRecvbeps399()
{

}

int CRecvbeps399::Work(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps399::CRecvbeps399()");
    
    // 解析报文
    unPack(szMsg);

    SetData(szMsg);
    
    InsertData();
    //核签
    
    CheckSign399();
    
    // 更新数据
    UpdataData();
	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps399::CRecvbeps399()");
    return OPERACT_SUCCESS;
}


void CRecvbeps399::CheckSign399()
{
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps399::CheckSign399()");
	
	m_beps399.getOriSignStr();
	
	CheckSign(m_beps399.m_sSignBuff.c_str(),
						m_beps399.m_szDigitSign.c_str(),
						m_beps399.Nm.c_str());
	
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps399::CheckSign399()");
}

INT32 CRecvbeps399::unPack(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps399::unPack()");
    int iRet = -1;
    
    // 报文是否为空
    if (NULL == szMsg || '\0' == szMsg)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");	
    	PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "报文为空");
    }
    
    //获取工作日期
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(iRet != RTN_SUCCESS)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");	
    	PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;
    
    iRet = m_beps399.ParseXml(szMsg);    

    // 解析报文
    if (OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错! iRet= [%d]", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文解析出错!");
    }
	
	m_strMsgID = m_beps399.MsgId;
	
	//ZFPTLOG.SetLogInfo("399", m_strMsgID.c_str());

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps399::unPack()");
    return OPERACT_SUCCESS;;
}

INT32 CRecvbeps399::UpdataData()
{
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps399::UpdataData()");
	
	SETCTX(m_Bpbktocstdcntfctn);
	string strSQL;
	strSQL += "UPDATE bp_BkToCstDCNtfctn t SET  t.PROCSTATE = '07'";
	strSQL += ", t.ProcessCode = '";
	strSQL += m_beps399.StsId;
	strSQL += "', t.RjcPrtry = '";
	strSQL += m_beps399.Prtry;
	strSQL += "', t.RjclInf = '";
	strSQL += m_beps399.TxInfAndStsAddtlInf;
	strSQL += "' ";
	
	strSQL += " WHERE t.MSGID = '";
	strSQL += m_beps399.OrgnlMsgId.c_str();
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_beps399.MmbId.c_str(); 									
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	
	int iRet = m_Bpbktocstdcntfctn.execsql(strSQL.c_str());
	if(OPERACT_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
				" m_Bpbktocstdcntfctn execsql fail:error code=[%d], error cause =[%s]", iRet, m_Bpbktocstdcntfctn.GetSqlErr());
				PMTS_ThrowException(DB_INSERT_FAIL);
	}
	
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps399::UpdataData()");
	return iRet;
}

INT32 CRecvbeps399::InsertData()
{
	/*Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps399::InsertData()");
	
	SETCTX(m_Bpbktocstdcntfctn);
	
	int iRet = m_Bpbktocstdcntfctn.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__,  __LINE__, NULL, 
            "m_colltnchrgscl.insert() failed:error code =[%d],error cause =[%s]", iRet,m_Bpbktocstdcntfctn.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "新增表失败");
    }

	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps399::InsertData()");*/
	return OPERACT_SUCCESS;
}

INT32 CRecvbeps399::SetData(LPCSTR pchMsg)
{
	/*Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps399::SetData()");
	
	m_Bpbktocstdcntfctn.m_workdate                 = m_beps399.MsgId.substr(0,8);
	m_Bpbktocstdcntfctn.m_msgtp                    = "beps.399.001.01";
	m_Bpbktocstdcntfctn.m_msgid                    = m_beps399.MsgId;
	m_Bpbktocstdcntfctn.m_mesgid                   = m_beps399.m_PMTSHeader.getMesgID(); 
	m_Bpbktocstdcntfctn.m_mesgrefid                = m_beps399.m_PMTSHeader.getMesgRefID();
	m_Bpbktocstdcntfctn.m_instgdrctpty             = m_beps399.Nm;
	m_Bpbktocstdcntfctn.m_instddrctpty             = m_beps399.MmbId;
	m_Bpbktocstdcntfctn.m_addtlinf                 = m_beps399.AddtlInf;
	m_Bpbktocstdcntfctn.m_processcode              = m_beps399.StsId;
	m_Bpbktocstdcntfctn.m_rjcprtry                 = m_beps399.Prtry;
	m_Bpbktocstdcntfctn.m_rjclinf                  = m_beps399.TxInfAndStsAddtlInf;
	m_Bpbktocstdcntfctn.m_procstate                = "01";	

	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps399::SetData()");*/
	return OPERACT_SUCCESS;
}
