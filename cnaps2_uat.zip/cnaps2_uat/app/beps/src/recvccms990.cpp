/******************************************************************** 
文件名： recvccms990.cpp
创建人： xlz
日  期： 2011-03-08
修改人： hq
日  期： 
描  述： 通信级确认报文<ccms.990.001.02>来账处理
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvccms990.h"

using namespace ZFPT;

CRecvCcms990::CRecvCcms990()
{
    memset(m_sMsgTp,      0x00, sizeof(m_sMsgTp));
    memset(m_sSqlStr,     0x00, sizeof(m_sSqlStr));
    memset(m_sListSql,    0x00, sizeof(m_sListSql));
    memset(m_sOriSql,     0x00, sizeof(m_sOriSql));
    memset(m_sOriListSql, 0x00, sizeof(m_sOriListSql));
    memset(m_strSQL40507, 0x00, sizeof(m_strSQL40507));
	m_strProcSts = "";
	m_strMsgTp = "ccms.990.001.02";
}


CRecvCcms990::~CRecvCcms990()
{
		
}

INT32 CRecvCcms990::Work(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms990::doWork()");
    
    // 解析报文
    unPack(pchMsg);

    // 状态转换
	TransProcSts();
	
    // 更新业务表状态
    UpdateData();
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms990::doWork()");
    return RTN_SUCCESS;
}

INT32 CRecvCcms990::unPack(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms990::unPack()");

    int iRet = -1;
    
	// 报文是否为空
	if (NULL == pchMsg || '\0' == pchMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "报文为空");
	}
    
    // 解析报文
    iRet = m_ccms990.ParseXml(pchMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文解析出错");
    }

	ZFPTLOG.SetLogInfo("990", m_ccms990.MsgId.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_ccms990.MsgId = [%s]", m_ccms990.MsgId .c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_ccms990.MT    = [%s]", m_ccms990.MT .c_str());
	
	if ( 7 == m_ccms990.MT.length() )
	{
	    memcpy(m_sMsgTp, m_ccms990.MT.c_str()+1, 6);
	}
	else
	{
        memcpy(m_sMsgTp, m_ccms990.MT.c_str() + 5, 3);
	}

	// 测试信息
	//Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_ccms990.OrigSndr = [%s]", m_ccms990.OrigSndr .c_str());
	//Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_ccms990.OrigSndDt= [%s]", m_ccms990.OrigSndDt.c_str());
	//Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_ccms990.MT       = [%s]", m_ccms990.MT       .c_str());
	//Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_ccms990.MsgId    = [%s]", m_ccms990.MsgId    .c_str());
	//Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_ccms990.MsgRefId = [%s]", m_ccms990.MsgRefId .c_str());
	//Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_ccms990.MsgPrcCd = [%s]", m_ccms990.MsgPrcCd .c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sMsgTp           = [%s]", m_sMsgTp);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms990::unPack()");	
    return RTN_SUCCESS;
}

void CRecvCcms990::TransProcSts()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms990::TransProcSts()");

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strProcSts = [%s]", m_ccms990.MsgPrcCd.c_str());	
    
    if ( 0 == strncmp(m_ccms990.MsgPrcCd.c_str()+4,"0000",4))
    {       
        m_strProcSts = PR_HVBP_13;
    }
    else if ( 0 == strncmp(m_ccms990.MsgPrcCd.c_str()+4,"0001" ,4))
    {
        m_strProcSts  = PR_HVBP_09;
    }
    else if ( 0 == strncmp(m_ccms990.MsgPrcCd.c_str()+4,"0002" ,4))
    {
        m_strProcSts  = PR_HVBP_10;
    }
    else if ( 0 == strncmp(m_ccms990.MsgPrcCd.c_str()+4,"0003",4 ))
    {
        m_strProcSts  = PR_HVBP_11;
    }
    else if ( 0 == strncmp(m_ccms990.MsgPrcCd.c_str()+4,"0004",4 ))
    {
        m_strProcSts  = PR_HVBP_12;
    }
    else
    {
    	m_strProcSts  = PR_HVBP_12;
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms990::TransProcSts()");
}	

INT32 CRecvCcms990::UpdateData(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms990::UpdateData()");
	
	int iRet      = 0;
    
    // 设置连接
	SETCTX(m_centitybase);

	// ****************** 大额报文 ******************
	//客户发起汇兑业务报文/金融机构发起汇兑业务报文
	if( 0 == strcmp("111"   , m_sMsgTp) || 0 == strcmp("112"   , m_sMsgTp)
     || 0 == strcmp("CMT100", m_sMsgTp) || 0 == strcmp("CMT101", m_sMsgTp)
     || 0 == strcmp("CMT102", m_sMsgTp) || 0 == strcmp("CMT103", m_sMsgTp)
     || 0 == strcmp("CMT105", m_sMsgTp) || 0 == strcmp("CMT108", m_sMsgTp)
     || 0 == strcmp("CMT121", m_sMsgTp) || 0 == strcmp("CMT122", m_sMsgTp)
     || 0 == strcmp("CMT123", m_sMsgTp) || 0 == strcmp("CMT124", m_sMsgTp) )
	{
	    PubUpSql("HV_SNDEXCHGLIST", "STATETIME");
	}
	//即时转账报文
    else if( 0 == strcmp("141"   , m_sMsgTp) 
    	  || 0 == strcmp("CMT231", m_sMsgTp) || 0 == strcmp("CMT232", m_sMsgTp) 
          || 0 == strcmp("CMT407", m_sMsgTp) || 0 == strcmp("CMT408", m_sMsgTp) )
	{
	    PubUpSql("HV_TROFACSNDLIST", "STATETIME");
	}
	//PVP结算申请信息报文
	else if( 0 == strcmp("143" ,m_sMsgTp) )
	{
	    PubUpSql("HV_PVPSETOFAC", "STATETIME");
	}
	//申请清算银行汇票资金报文/银行汇票申请退回业务报文
	else if( 0 == strcmp("151" ,m_sMsgTp) || 0 == strcmp("153" ,m_sMsgTp) )
	{
	    PubUpSql("HV_DRAFT", "STATETIME");
	}
	//多边轧差净额结算报文
	else if( 0 == strcmp("631", m_sMsgTp) )
	{
	    PubUpSql_("HV_MNETSTLCL", "STATETIME");
	}
	//多边净额业务撤销申请报文
	else if( 0 == strcmp("634", m_sMsgTp) )
	{
	    PubUpSql_("HV_MNETSTLMCXL", "STATETIME");
	}
	// ****************** 小额报文 ******************
	//客户发起普通贷记业务报文/金融机构发起普通贷记业务报文
	//实时贷记业务报文/定期贷记业务报文
	//普通借记业务回执报文/CIS通用回执业务报文
	//实时借记业务回执报文/定期借记业务回执报文
	else if( 0 == strcmp("121",    m_sMsgTp) || 0 == strcmp("122",    m_sMsgTp)
 	      || 0 == strcmp("123",    m_sMsgTp) || 0 == strcmp("125",    m_sMsgTp)
 	      || 0 == strcmp("128",    m_sMsgTp) || 0 == strcmp("130",    m_sMsgTp)
	      || 0 == strcmp("132",    m_sMsgTp) || 0 == strcmp("134",    m_sMsgTp)
	      || 0 == strcmp("PKG001", m_sMsgTp) || 0 == strcmp("PKG003", m_sMsgTp) 
	      || 0 == strcmp("PKG005", m_sMsgTp) || 0 == strcmp("PKG007", m_sMsgTp) 
	      || 0 == strcmp("PKG008", m_sMsgTp) || 0 == strcmp("PKG010", m_sMsgTp) 
	      || 0 == strcmp("PKG011", m_sMsgTp) )
	{
	    PubUpSql("BP_BCOUTSNDCL", "STATETIME"); //汇总
	    m_bpbcsndcl.setctx(m_dbproc);
    	    
        if( (0 == strcmp("128",    m_sMsgTp) || 0 == strcmp("130",    m_sMsgTp)
	      || 0 == strcmp("132",    m_sMsgTp) || 0 == strcmp("134",    m_sMsgTp)
	      || 0 == strcmp("PKG008", m_sMsgTp) || 0 == strcmp("PKG009", m_sMsgTp)
	      || 0 == strcmp("PKG010", m_sMsgTp) || 0 == strcmp("PKG011", m_sMsgTp)) 
	      && m_ccms990.MsgPrcCd != "0000" )
    	{
    	    PubListSql(&m_bpbcsndcl, "BP_BCOUTSENDLIST", 1); //明细+原业务
    	}
    	else
    	{
            PubListSql(&m_bpbcsndcl, "BP_BCOUTSENDLIST", 0); //明细
    	}
	}
	//实时贷记回执业务报文/普通借记业务报文
	//实时借记业务报文/定期借记业务报文
	else if( 0 == strcmp("124" ,m_sMsgTp) || 0 == strcmp("127" ,m_sMsgTp) 
	      || 0 == strcmp("131" ,m_sMsgTp) || 0 == strcmp("133" ,m_sMsgTp)
	      || 0 == strcmp("PKG002" ,m_sMsgTp) || 0 == strcmp("PKG006" ,m_sMsgTp)
	      || 0 == strcmp("PKG004" ,m_sMsgTp) || 0 == strcmp("PKG009" ,m_sMsgTp) )
	{
	    PubUpSql("BP_BDSNDCL", "STATETIME");
        m_bpbdsndcl.setctx(m_dbproc);
            
        if( (0 == strcmp("124" ,m_sMsgTp) || 0 == strcmp("PKG009" ,m_sMsgTp))
          && m_ccms990.MsgPrcCd != "0000" )
        {
            PubListSql(&m_bpbdsndcl, "BP_BDSENDLIST", 1); //明细+原业务
        }
        else
        {
            PubListSql(&m_bpbdsndcl, "BP_BDSENDLIST", 0); //明细
        }
	}
	//批量代收业务报文/批量代收业务回执报文
	//批量代付业务报文/批量代付业务回执报文
	//实时代收业务报文/实时代收业务回执报文
	//实时代付业务报文/实时代付业务回执报文
	//388/390/391/392/393/394/395暂未加
	else if( 0 == strcmp("380" ,m_sMsgTp) || 0 == strcmp("381" ,m_sMsgTp) 
	      || 0 == strcmp("382" ,m_sMsgTp) || 0 == strcmp("383" ,m_sMsgTp)
	      || 0 == strcmp("384" ,m_sMsgTp) || 0 == strcmp("385" ,m_sMsgTp)
	      || 0 == strcmp("386" ,m_sMsgTp) || 0 == strcmp("387" ,m_sMsgTp) )
	{
	    PubUpSql("BP_COLLTNCHRGSCL", "STATETIME");
        m_bpcoll.setctx(m_dbproc);
        
	    if( ( 0 == strcmp("381" ,m_sMsgTp) || 0 == strcmp("383" ,m_sMsgTp) )
	      && m_ccms990.MsgPrcCd != "0000" )
    	{
    	    PubListSql(&m_bpcoll, "BP_COLLTNCHRGSLIST", 1);
    	}
    	else
    	{
            PubListSql(&m_bpcoll, "BP_COLLTNCHRGSLIST", 0);
    	}
	}
    else if(0 == strcmp("389" ,m_sMsgTp) || 0 == strcmp("388" ,m_sMsgTp))     //增加小额389
    {
        PubUpSql_("BP_BIZPUBNTCE", "PROCTIME");
    }
	//主动缴款查询报文/主动缴款通知报文
	//397,399没有发起权限,不需要处理
	else if( 0 == strcmp("396" ,m_sMsgTp) || 0 == strcmp("398" ,m_sMsgTp) )
	{
	    PubUpSql_("BP_GETTX", "PROCTIME");
	}
	//客户账户实时查询报文/客户账户实时查询应答报文
	else if( 0 == strcmp("401" ,m_sMsgTp) || 0 == strcmp("402" ,m_sMsgTp) )
	{
	    PubUpSql_("BP_REALTMCSTACCTMG", "PROCTIME");
	}
	//发票打印申请报文
	else if( 0 == strcmp("403" ,m_sMsgTp) )
	{
	    PubUpSql_("BP_INVCPRTAPPLY", "PROCTIME");
	}
	//发票打印回应报文:更新原申请报文
	else if( 0 == strcmp("404" ,m_sMsgTp))
	{
	    m_bpinvc.setctx(m_dbproc);
	    PubListSql(&m_bpinvc, "BP_INVCPRTRSPN");
	}
	//借记业务止付申请报文/借记业务止付应答报文
	else if( 0 == strcmp("411" ,m_sMsgTp) || 0 == strcmp("412" ,m_sMsgTp) )
	{
	    PubUpSql_("BP_CSTBDPCXLCL", "STATETIME");

	    if ( 0 == strcmp("412" ,m_sMsgTp) && m_ccms990.MsgPrcCd != "0000" ) //更新申请报文
	    {
	        m_bpcstb.setctx(m_dbproc);
            PubListSql(&m_bpcstb, "BP_CSTBDPCXLCL");
	    }
	}
	//实时业务冲正申请报文
	//实时业务冲正应答报文(没发起权限,不处理)
	else if( 0 == strcmp("413" ,m_sMsgTp) )
	{
	    PubUpSql_("BP_CSTPMTCXL", "PROCTIME");
	}
	//支票圈存管理报文/支票圈存管理应答报文
	else if( 0 == strcmp("418" ,m_sMsgTp) || 0 == strcmp("419" ,m_sMsgTp) )
	{
	    PubUpSql_("BP_CHCKCDTFORLD", "PROCTIME");

	    if ( 0 == strcmp("419" ,m_sMsgTp) && m_ccms990.MsgPrcCd != "0000" ) //更新申请报文
	    {
	        m_bpchck.setctx(m_dbproc);
            PubListSql(&m_bpchck, "BP_CHCKCDTFORLD");
	    }
	}
	// ****************** 公共报文 ******************
	//自由格式报文
	else if( 0 == strcmp("303" ,m_sMsgTp) || 0 == strcmp("CMT303" ,m_sMsgTp) )
	{
	    PubUpSql("CM_FREEINFO", "STATETIME");
	}
	//业务撤销申请报文
	else if( 0 == strcmp("307" ,m_sMsgTp) || 0 == strcmp("CMT311" ,m_sMsgTp) )
	{
	    PubUpSql("CM_TRANSREPEAL", "STATETIME");
	}
    //通用非签名信息业务报文
	else if( 0 == strcmp("310" ,m_sMsgTp) || 0 == strcmp("311" ,m_sMsgTp)
	      || 0 == strcmp("312" ,m_sMsgTp) || 0 == strcmp("313" ,m_sMsgTp)
	      || 0 == strcmp("PKG012" ,m_sMsgTp) )
	{
	    PubUpSql_("CM_CNOTSGNINFBIZ", "PROCTIME");
                
	    if ( (0 == strcmp("311" ,m_sMsgTp) || 0 == strcmp("313" ,m_sMsgTp))
	       && m_ccms990.MsgPrcCd != "0000" ) //更新申请报文
	    {
	        m_cmcnot.setctx(m_dbproc);
            PubListSql(&m_cmcnot, "CM_CNOTSGNINFBIZ");
	    }
	}
	//业务查询报文/业务查复报文
	else if( 0 == strcmp("314" ,   m_sMsgTp) || 0 == strcmp("315"   , m_sMsgTp) 
	      || 0 == strcmp("CMT301", m_sMsgTp) || 0 == strcmp("CMT302", m_sMsgTp) )
	{
	    PubUpSql("CM_TRANSINFOQRY", "STATETIME");

	    if ( (0 == strcmp("315", m_sMsgTp) || 0 == strcmp("CMT302", m_sMsgTp))
	       && m_ccms990.MsgPrcCd != "0000" ) //更新查询报文
	    {
	        m_cmtrinq.setctx(m_dbproc);
            PubListSql(&m_cmcnot, "CM_TRANSINFOQRY");
	    }
	}
	//业务状态查询申请报文
	else if( 0 == strcmp("316" ,m_sMsgTp) || 0 == strcmp("CMT651" ,m_sMsgTp) )
	{
	    PubUpSql("CM_TRANSSTQRY", "STATETIME");
	}
	//业务退回申请报文/业务退回应答报文
	else if( 0 == strcmp("318" ,m_sMsgTp) || 0 == strcmp("319" ,m_sMsgTp) || 
			 0 == strcmp("CMT313" ,m_sMsgTp)  || 0 == strcmp("CMT314" ,m_sMsgTp) || 
			 0 == strcmp("CMT319" ,m_sMsgTp)  || 0 == strcmp("CMT320" ,m_sMsgTp) )
	{
	    PubUpSql("CM_PMTRTRCL", "STATETIME");

	    if ( (0 == strcmp("CMT314" ,m_sMsgTp) || 
	    	  0 == strcmp("CMT320" ,m_sMsgTp) || 
	    	  0 == strcmp("319" ,m_sMsgTp)) && m_ccms990.MsgPrcCd != "0000" ) //更新申请报文
	    {
	        m_cmpmtr.setctx(m_dbproc);
            PubListSql(&m_cmpmtr, "CM_PMTRTRCL");
	    }
	}
	//借记业务止付申请报文
	else if( 0 == strcmp("CMT327" ,m_sMsgTp) )
	{
	    PubUpSql_("BP_CSTBDPCXLCL", "STATETIME");
	}
	//数字证书绑定管理通知报文/数字证书下载申请报文
	else if( 0 == strcmp("903" ,m_sMsgTp) ||0 == strcmp("919" ,m_sMsgTp) )
	{
	    PubUpSql_("CM_BNDDIGCERT", "STATETIME");
	}
	//清算帐户信息查询
	else if( 0 == strcmp("366" ,m_sMsgTp))
	{
	    PubUpSql_("SA_QAINFOQRY", "PROCTIME");
	}
	//登录退出申请报文
	else if( 0 == strcmp("805" ,m_sMsgTp))
	{//不用做更新，表里没有存原报文通信级标识号
	}	
	else if( 0 == strcmp("350" ,m_sMsgTp))
	{
		PubUpSql("SA_NTRYLIMTQRY", "PROCTIME");
	}
	else if( 0 == strcmp("353" ,m_sMsgTp))
	{
		PubUpSql_("SA_DBTLMTDSBTMG", "PROCTIME");
	}
	else if( 0 == strcmp("354" ,m_sMsgTp))
	{
		PubUpSql_("SA_DBTWRNAPP", "PROCTIME");
	}
    else if( 0 == strcmp("361" ,m_sMsgTp))
    {
        PubUpSql_("SA_BALWRNGMG", "PROCTIME");
    }
    else if( 0 == strcmp("365" ,m_sMsgTp) || 0 == strcmp("363" ,m_sMsgTp))
    {
        PubUpSql_("SA_QAINFOQRY", "PROCTIME");
    }
    else if( 0 == strcmp("368" ,m_sMsgTp))
    {
        PubUpSql_("SA_LQDTYQRYAPPL", "PROCTIME");
    }
    else if( 0 == strcmp("373" ,m_sMsgTp))
    {
        PubUpSql_("SA_FNDSOFPOOLMGMT", "PROCTIME");
    }
    else if( 0 == strcmp("374" ,m_sMsgTp) || 0 == strcmp("375" ,m_sMsgTp))
    {
        PubUpSql_("SA_INTRBKLNMGMT", "PROCTIME");
    }
    else if( 0 == strcmp("376" ,m_sMsgTp) || 0 == strcmp("377" ,m_sMsgTp))
    {
        PubUpSql_("SA_LQDTYTFR", "PROCTIME");
    }
    //轧差排队查询申请报文
	else if( 0 == strcmp("405" ,m_sMsgTp))
	{
	    PubUpSql_("SA_NETGQMGMT", "PROCTIME");
	}
	else if( 0 == strcmp("407" ,m_sMsgTp))
	{
	    PubUpSql_("SA_NETGQMGMT", "PROCTIME");
	}
    else if( 0 == strcmp("614" ,m_sMsgTp))
    {
        PubUpSql_("SA_PIBKLNQRYAPPL", "PROCTIME");
    }
	else
	{
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "不支持的报文类型[%s]", m_sMsgTp);
        PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "不支持的报文类型");
	}
	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sSqlStr     = [%s]", m_sSqlStr);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sListSql    = [%s]", m_sListSql);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sOriSql     = [%s]", m_sOriSql);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sOriListSql = [%s]", m_sOriListSql);

    // 执行SQL，修改业务处理状态
	iRet = m_centitybase.execsql(m_sSqlStr);
    if (iRet == SQLNOTFOUND)
    {
        //回为往帐PKG012不同的业务类型是从不同的表里取数据的,990报文里又没有原往帐的业务类型,所以就无法判断该更新哪个表的状态
        //这里处理为如果更新某一个业务类型的表失败那么再更新其它类型的所在表,如果全都失败,再抛出异常.
        if (0 == strcmp("PKG012" ,m_sMsgTp))
        {
            sprintf(m_strSQL40507, "UPDATE BP_CSTCTRCTMGCL t SET "
                                    "t.PROCTIME = sysdate,"
                                    "t.PROCSTATE = '%s' "
                                    " WHERE t.MESGID = '%s' "
                                    " and t.MESGREFID = '%s'"
                                    " and t.PROCSTATE <= '%s'",
                                    m_strProcSts.c_str(),                              
                                    m_ccms990.MsgId.c_str(),
                                    m_ccms990.MsgRefId.c_str(),
                                    m_strProcSts.c_str());
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "不是上面的业务类型,去更新业务为012_40507的原签约关系业务.m_strSQL40507=[%s]", m_strSQL40507);
            iRet = m_centitybase.execsql(m_strSQL40507);
            if (iRet == SQL_SUCCESS)//如果汇总更新成功了再去更新明细
            {
                sprintf(m_strSQL40507, "UPDATE bp_cstctrctmglist t SET "
                                        "t.PROCTIME = sysdate,"
                                        "t.PROCSTATE = '%s' "
                                        " WHERE t.MESGID = '%s' "
                                        " and t.MESGREFID = '%s'"
                                        " and t.PROCSTATE <= '%s'",
                                        m_strProcSts.c_str(),                              
                                        m_ccms990.MsgId.c_str(),
                                        m_ccms990.MsgRefId.c_str(),
                                        m_strProcSts.c_str());
                Trace(L_INFO, __FILE__, __LINE__, NULL,"更新原签约关系明细表[%s]", m_strSQL40507);
                iRet = m_centitybase.execsql(m_strSQL40507);
                if(iRet != SQL_SUCCESS)
                {
                    Trace(L_ERROR, __FILE__, __LINE__, NULL, "更新原业务状态失败[%d][%s]", iRet, m_centitybase.GetSqlErr());
                }
            }
            else
            {
                Trace(L_ERROR, __FILE__, __LINE__, NULL,"no data found[%s][%s]", m_sMsgTp, m_ccms990.MsgId.c_str());
            }
        }
        else
        {
            Trace(L_ERROR, __FILE__, __LINE__, NULL,"no data found[%s][%s]", m_sMsgTp, m_ccms990.MsgId.c_str());
        }
    }
    else if (iRet != SQL_SUCCESS)
    {
        sprintf(m_szErrMsg,  "更新原业务状态失败[%d][%s]", iRet, m_centitybase.GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
    }

    // 执行SQL，修改明细业务处理状态
	if ( NULL != m_sListSql && '\0' != m_sListSql && 0 < strlen(m_sListSql) )
    {
        iRet = m_centitybase.execsql(m_sListSql);
        if (iRet == SQLNOTFOUND)
        {
        	Trace(L_INFO, __FILE__, __LINE__, NULL,"更新时未找到数据[%s][%s]", m_sMsgTp, m_ccms990.MsgId.c_str());
        }
        else if (iRet != SQL_SUCCESS)
        {
            sprintf(m_szErrMsg,  "更新原业务状态失败[%d][%s]", iRet, m_centitybase.GetSqlErr());
            Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
            PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
        }
    }

    // 执行SQL，修改原业务处理状态
	if ( NULL != m_sOriSql && '\0' != m_sOriSql && 0 < strlen(m_sOriSql) )
    {
        iRet = m_centitybase.execsql(m_sOriSql);
        if (iRet == SQLNOTFOUND)
        {
        	Trace(L_INFO, __FILE__, __LINE__, NULL,"更新时未找到数据[%s][%s]", m_sMsgTp, m_ccms990.MsgId.c_str());
        }
        else if (iRet != SQL_SUCCESS)
        {
            sprintf(m_szErrMsg,  "更新原业务状态失败[%d][%s]", iRet, m_centitybase.GetSqlErr());
            Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
            PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
        }
    }

    // 执行SQL，修改原明细业务处理状态
	if ( NULL != m_sOriListSql && '\0' != m_sOriListSql && 0 < strlen(m_sOriListSql) )
    {
        iRet = m_centitybase.execsql(m_sOriListSql);
        if (iRet == SQLNOTFOUND)
        {
        	Trace(L_INFO, __FILE__, __LINE__, NULL,"更新时未找到数据[%s][%s]", m_sMsgTp, m_ccms990.MsgId.c_str());
        }
        else if (iRet != SQL_SUCCESS)
        {
            sprintf(m_szErrMsg,  "更新原业务状态失败[%d][%s]", iRet, m_centitybase.GetSqlErr());
            Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
            PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
        }
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms990::UpdateData()");
    return RTN_SUCCESS;
}

void CRecvCcms990::PubUpSql(LPCSTR sTableNm, LPCSTR sTimeNm)
{
    //人行990报文,没有系统号,不能按系统号去更新
	sprintf(m_sSqlStr, "UPDATE %s t SET "
	                 "t.%s = sysdate,"
                     "t.PROCESSCODE = '%s',"
	                 "t.PROCSTATE = '%s' "
	                 " WHERE t.MESGID = '%s' "
	                 " and t.MESGREFID = '%s'"
	                 " and t.PROCSTATE <= '%s'",
	                 sTableNm,
	                 sTimeNm,                           
	                 m_ccms990.MsgPrcCd.c_str(),
	                 m_strProcSts.c_str(),                              
	                 m_ccms990.MsgId.c_str(),
	                 m_ccms990.MsgRefId.c_str(),
	                 m_strProcSts.c_str());
		                 
    Trace(L_INFO, __FILE__, __LINE__, NULL, "m_sSqlStr = [%s]", m_sSqlStr);
}

void CRecvCcms990::PubUpSql_(LPCSTR sTableNm, LPCSTR sTimeNm)
{
    //人行990报文,没有系统号,不能按系统号去更新
	sprintf(m_sSqlStr, "UPDATE %s t SET "
	                 "t.%s = sysdate,"
	                 "t.PROCSTATE = '%s' "
	                 " WHERE t.MESGID = '%s' "
	                 " and t.MESGREFID = '%s'"
	                 " and t.PROCSTATE <= '%s'",
	                 sTableNm,
	                 sTimeNm,
	                 m_strProcSts.c_str(),                              
	                 m_ccms990.MsgId.c_str(),
	                 m_ccms990.MsgRefId.c_str(),
	                 m_strProcSts.c_str());
		                 
    Trace(L_INFO, __FILE__, __LINE__, NULL, "m_sSqlStr = [%s]", m_sSqlStr);
}

void CRecvCcms990::PubListSql(CEntityBase* oDbDetail, LPCSTR sTableNm, int sType)
{
    int iRet;
    char sSqlStr[1024 + 1] = {0};
    
    snprintf(sSqlStr, sizeof(sSqlStr) - 1, " mesgid = '%s' and mesgrefid = '%s' ", 
        m_ccms990.MsgId.c_str(), m_ccms990.MsgRefId.c_str());
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "sSqlStr = [%s]", sSqlStr);

    iRet = oDbDetail->find(sSqlStr);
    if (iRet != SQL_SUCCESS)
    {
        sprintf(m_szErrMsg,  "查找原业务信息失败[%d][%s]", iRet, oDbDetail->GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_FIND_BY_PK_FAIL, m_szErrMsg);
    }

    while (SQL_SUCCESS == iRet)
    {
        iRet = oDbDetail->fetch();
        if (iRet == SQLNOTFOUND)
        {
            Trace(L_DEBUG, __FILE__, __LINE__, NULL, "没有待可取的数据");
            oDbDetail->closeCursor();
            return;
        }
        else if (iRet != SQL_SUCCESS)
        {
            sprintf(m_szErrMsg,  "获取原业务信息失败[%d][%s]", iRet, oDbDetail->GetSqlErr());
            Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
            oDbDetail->closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);                
        }
    
        if ( 0 == strcmp(sTableNm, "BP_BCOUTSENDLIST") )        /*贷记往账*/
        {
            BpBcSndSql(sType);
        }
        else if ( 0 == strcmp(sTableNm, "BP_BDSENDLIST") )      /*借记往账*/
        {
            BpBdSndSql(sType);
        }
        else if ( 0 == strcmp(sTableNm, "BP_COLLTNCHRGSLIST") ) /*代收付往账*/
        {
            BpColltSql(sType);
        }
        else if ( 0 == strcmp(sTableNm, "BP_INVCPRTRSPN") )     /*发票打印应答*/
        {
            BpIncvpSql();
        }
        else if ( 0 == strcmp(sTableNm, "BP_CSTBDPCXLCL") )     /*借记业务止付应答*/
        {
            BpcstbdSql();
        }
        else if ( 0 == strcmp(sTableNm, "BP_CHCKCDTFORLD") )    /*支票圈存管理*/
        {
            BpchckcSql();
        }
        else if ( 0 == strcmp(sTableNm, "CM_CNOTSGNINFBIZ") )   /*通用非签名/签名信息*/
        {
            CmCnotsSql();
        }
        else if ( 0 == strcmp(sTableNm, "CM_TRANSINFOQRY") )    /*查询查复*/
        {
            CmTrInQsSql();
        }
        else if ( 0 == strcmp(sTableNm, "CM_PMTRTRCL") )        /*业务退回*/
        {
            CmPmtrtSql();
        }
    }
    oDbDetail->closeCursor();
}

void CRecvCcms990::BpBcSndSql(int sType)
{
    // 明细
    snprintf(m_sListSql, sizeof(m_sListSql) - 1, "UPDATE BP_BCOUTSENDLIST t SET "
    					"t.STATETIME = sysdate,"
                        "t.PROCSTATE = '%s' "
                        " WHERE t.msgid = '%s' "
                        " and t.InstgDrctPty = '%s'", 
                        m_strProcSts.c_str(),                              
    					m_bpbcsndcl.m_msgid.c_str(),
                        m_bpbcsndcl.m_instgdrctpty.c_str());

    // 原业务的汇总和明细
    if ( 1 == sType )
    {
        snprintf(m_sOriSql, sizeof(m_sOriSql) - 1, "UPDATE BP_BCOUTSNDCL t SET "
        					"t.STATETIME = sysdate,"
                            "t.PROCSTATE = '%s' "
                            " WHERE t.MSGID||t.INSTGDRCTPTY = "
                            " (SELECT k.ORGNLMSGID||k.ORIINSTGDRCTPTY "
                            " FROM BP_BCOUTSENDLIST k"
                            " WHERE k.MSGID = '%s' "
                            " AND k.INSTGDRCTPTY = '%s')", 
                            m_strProcSts.c_str(),                              
        					m_bpbcsndcl.m_msgid.c_str(),
                            m_bpbcsndcl.m_instgdrctpty.c_str());
                            
        snprintf(m_sOriListSql, sizeof(m_sOriListSql) - 1, "UPDATE BP_BCOUTSENDLIST t SET "
        					"t.STATETIME = sysdate,"
                            "t.PROCSTATE = '%s' "
                            " WHERE t.MSGID||t.INSTGDRCTPTY = "
                            " (SELECT k.ORGNLMSGID||k.ORIINSTGDRCTPTY "
                            " FROM BP_BCOUTSENDLIST k"
                            " WHERE k.MSGID = '%s' "
                            " AND k.INSTGDRCTPTY = '%s')", 
                            m_strProcSts.c_str(),                              
        					m_bpbcsndcl.m_msgid.c_str(),
                            m_bpbcsndcl.m_instgdrctpty.c_str());
    }
}

void CRecvCcms990::BpBdSndSql(int sType)
{
    //明细
    snprintf(m_sListSql, sizeof(m_sListSql) - 1, "UPDATE BP_BDSENDLIST t SET "
    					"t.STATETIME = sysdate,"
                        "t.PROCSTATE = '%s' "
                        " WHERE t.msgid = '%s' "
                        " and t.InstgDrctPty = '%s'", 
                        m_strProcSts.c_str(),                              
    					m_bpbdsndcl.m_msgid.c_str(),
                        m_bpbdsndcl.m_instgdrctpty.c_str());

    // 原业务的汇总和明细
    if ( 1 == sType )
    {
        snprintf(m_sOriSql, sizeof(m_sOriSql) - 1, "UPDATE BP_BDSNDCL t SET "
        					"t.STATETIME = sysdate,"
                            "t.PROCSTATE = '%s' "
                            " WHERE t.MSGID||t.INSTGDRCTPTY = "
                            " (SELECT k.ORGNLMSGID||k.ORIINSTGDRCTPTY "
                            " FROM BP_BDSENDLIST k"
                            " WHERE k.MSGID = '%s' "
                            " AND k.INSTGDRCTPTY = '%s')", 
                            m_strProcSts.c_str(),                              
        					m_bpbdsndcl.m_msgid.c_str(),
                            m_bpbdsndcl.m_instgdrctpty.c_str());
                            
        snprintf(m_sOriListSql, sizeof(m_sOriListSql) - 1, "UPDATE BP_BDSENDLIST t SET "
        					"t.STATETIME = sysdate,"
                            "t.PROCSTATE = '%s' "
                            " WHERE t.MSGID||t.INSTGDRCTPTY = "
                            " (SELECT k.ORGNLMSGID||k.ORIINSTGDRCTPTY "
                            " FROM BP_BDSENDLIST k"
                            " WHERE k.MSGID = '%s' "
                            " AND k.INSTGDRCTPTY = '%s')", 
                            m_strProcSts.c_str(),                              
        					m_bpbdsndcl.m_msgid.c_str(),
                            m_bpbdsndcl.m_instgdrctpty.c_str());
    }
}

void CRecvCcms990::BpColltSql(int sType)
{
    //明细
    snprintf(m_sListSql, sizeof(m_sListSql) - 1, "UPDATE BP_COLLTNCHRGSLIST t SET "
    					"t.STATETIME = sysdate,"
                        "t.PROCSTATE = '%s' "
                        " WHERE t.msgid = '%s' "
                        " and t.InstgDrctPty = '%s'", 
                        m_strProcSts.c_str(),                              
    					m_bpcoll.m_msgid.c_str(),
                        m_bpcoll.m_instgdrctpty.c_str());

    // 原业务的汇总和明细
    if ( 1 == sType )
    {
        snprintf(m_sOriSql, sizeof(m_sOriSql) - 1, "UPDATE BP_COLLTNCHRGSCL t SET "
        					"t.STATETIME = sysdate,"
                            "t.PROCSTATE = '%s' "
                            " WHERE t.MSGID||t.INSTGDRCTPTY = "
                            " (SELECT k.ORGNLMSGID||k.ORGNLINSTGPTY "
                            " FROM BP_COLLTNCHRGSLIST k"
                            " WHERE k.MSGID = '%s' "
                            " AND k.INSTGDRCTPTY = '%s')", 
                            m_strProcSts.c_str(),                              
        					m_bpbdsndcl.m_msgid.c_str(),
                            m_bpbdsndcl.m_instgdrctpty.c_str());
                            
        snprintf(m_sOriListSql, sizeof(m_sOriListSql) - 1, "UPDATE BP_COLLTNCHRGSLIST t SET "
        					"t.STATETIME = sysdate,"
                            "t.PROCSTATE = '%s' "
                            " WHERE t.MSGID||t.INSTGDRCTPTY = "
                            " (SELECT k.ORGNLMSGID||k.ORGNLINSTGPTY "
                            " FROM BP_COLLTNCHRGSLIST k"
                            " WHERE k.MSGID = '%s' "
                            " AND k.INSTGDRCTPTY = '%s')", 
                            m_strProcSts.c_str(),                              
        					m_bpbdsndcl.m_msgid.c_str(),
                            m_bpbdsndcl.m_instgdrctpty.c_str());
    }
}

void CRecvCcms990::BpIncvpSql()
{
    snprintf(m_sOriSql, sizeof(m_sOriSql) - 1, "UPDATE BP_INVCPRTAPPLY t SET "
    					"t.PROCTIME = sysdate,"
                        "t.PROCSTATE = '%s' "
                        " WHERE t.msgid = '%s' "
                        " and t.InstgDrctPty = '%s'", 
                        m_strProcSts.c_str(),                              
    					m_bpinvc.m_orgnlmsgid.c_str(),
                        m_bpinvc.m_orgnlinstgpty.c_str());
}

void CRecvCcms990::BpcstbdSql()
{
    snprintf(m_sOriSql, sizeof(m_sOriSql) - 1, "UPDATE BP_CSTBDPCXLCL t SET "
    					"t.STATETIME = sysdate,"
                        "t.PROCSTATE = '%s' "
                        " WHERE t.msgid = '%s' "
                        " and t.InstgDrctPty = '%s'", 
                        m_strProcSts.c_str(),                              
    					m_bpcstb.m_orgnlmsgid.c_str(),
                        m_bpcstb.m_orgnlinstgpty.c_str());
}

void CRecvCcms990::BpchckcSql()
{
    snprintf(m_sOriSql, sizeof(m_sOriSql) - 1, "UPDATE BP_CHCKCDTFORLD t SET "
    					"t.PROCTIME = sysdate,"
                        "t.PROCSTATE = '%s' "
                        " WHERE t.MSGID = '%s' "
                        " and t.INSTGDRCTPTY = '%s' and t.SRCFLAG = '1'",
                        m_strProcSts.c_str(),                              
    					m_bpchck.m_orgnlmsgid.c_str(),
                        m_bpchck.m_orgnlinstgpty.c_str());
}

void CRecvCcms990::CmCnotsSql()
{
    snprintf(m_sOriSql, sizeof(m_sOriSql) - 1, "UPDATE CM_CNOTSGNINFBIZ t SET "
    					"t.PROCTIME = sysdate,"
                        "t.PROCSTATE = '%s' "
                        " WHERE t.MSGID = '%s' "
                        " and t.INSTGDRCTPTY = '%s'",
                        m_strProcSts.c_str(),                              
    					m_cmcnot.m_orgnlmsgid.c_str(),
                        m_cmcnot.m_orgnlinstgpty.c_str());
}

void CRecvCcms990::CmTrInQsSql()
{
    //人行990报文,没有系统号,不能按系统号去更新
    snprintf(m_sOriSql, sizeof(m_sOriSql) - 1, "UPDATE CM_TRANSINFOQRY t SET "
    					"t.STATETIME = sysdate,"
                        "t.PROCSTATE = '%s' "
                        " WHERE t.MSGID = '%s' "
                        " and t.INSTGDRCTPTY = '%s' and t.RSFLAG = '1'",
                        m_strProcSts.c_str(), 
    					m_cmtrinq.m_qorgnlmsgid.c_str(),
                        m_cmtrinq.m_qorgnlinstgdrctpty.c_str());
}

void CRecvCcms990::CmPmtrtSql()
{
    //人行990报文,没有系统号,不能按系统号去更新
    snprintf(m_sOriSql, sizeof(m_sOriSql) - 1, "UPDATE CM_PMTRTRCL t SET "
    					"t.STATETIME = sysdate,"
                        "t.PROCSTATE = '%s' "
                        " WHERE t.MSGID = '%s' "
                        " and t.INSTGDRCTPTY = '%s'",
                        m_strProcSts.c_str(), 
    					m_cmpmtr.m_orgnlmsgid.c_str(),
                        m_cmpmtr.m_orgninstgdrctpty.c_str());
}

int CRecvCcms990::InsertComsendmb(LPCSTR pchMsg)
{
	string strSql = "";
	int iRet = -1;
	
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter [CRecvCcms990::InsertComsendmb]");
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "原报文编号 [%s]", m_sMsgTp);
	
	//行内可能发起的大额往账
	if( 0 == strcmp("111" ,m_sMsgTp) || 0 == strcmp("112" ,m_sMsgTp) 
	 || 0 == strcmp("CMT100" ,m_sMsgTp) || 0 == strcmp("CMT108" ,m_sMsgTp))
	{
		CHvsndexchglist cHvsndexchglist;
		
		strSql = " MESGID = '";
		strSql += m_ccms990.MsgId;
		strSql += "' and MESGREFID = '";
		strSql += m_ccms990.MsgRefId;
		strSql += "' and INSTGDRCTPTY = '";
		strSql += m_ccms990.OrigSndr + "'";
		
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[hv_sndexchglist] strSql=[%s]", strSql.c_str());
		
		//设置连接
		SETCTX(cHvsndexchglist);
		
		iRet = cHvsndexchglist.find(strSql);
		
		if(SQL_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "hv_sndexchglist find fail:  [%d][%s]", 
				iRet, cHvsndexchglist.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			cHvsndexchglist.closeCursor();
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
		
		iRet = cHvsndexchglist.fetch();
		if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
		{
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "循环hv_sndexchglist游标出错 --[%d] --[%s]", iRet, cHvsndexchglist.GetSqlErr());
			cHvsndexchglist.closeCursor();
			PMTS_ThrowException(DB_FIND_FAIL);
		}
		
		if(0 == iRet)
		{
			//原业务由行内发起
			if(strncmp(cHvsndexchglist.m_msgdirect.c_str(), "0", 1) == 0)
			{
				m_strMsgID = cHvsndexchglist.m_msgid;
				
				//入行内通信表
				//DirectInter("0000", cHvsndexchglist.m_instgindrctpty.c_str(), 
				//			cHvsndexchglist.m_instgdrctpty.c_str(),
				//			pchMsg, "HVPS", "hv_sndexchglist");
			}
			else
			{
				Trace(L_INFO,  __FILE__,	__LINE__, NULL, "原业务[%s][%s]由客户端发起，不用转至行内。", m_sMsgTp, cHvsndexchglist.m_msgid.c_str());
			}
		}
		cHvsndexchglist.closeCursor();
	}
	//行内发起小额贷记往账
	else if( 0 == strcmp("121",    m_sMsgTp) || 0 == strcmp("122",    m_sMsgTp)  
		  || 0 == strcmp("125",    m_sMsgTp) || 0 == strcmp("134", m_sMsgTp)
		  || 0 == strcmp("PKG001", m_sMsgTp) || 0 == strcmp("PKG005", m_sMsgTp)
	      || 0 == strcmp("PKG007", m_sMsgTp) || 0 == strcmp("PKG011", m_sMsgTp) )
	{
		//从贷记往账汇总中取原数据
		CBpbcoutsndcl cBpbcoutsndcl;
		
		strSql = "";
		strSql = " MESGID = '";
		strSql += m_ccms990.MsgId;
		strSql += "' and MESGREFID = '";
		strSql += m_ccms990.MsgRefId;
		strSql += "' and INSTGDRCTPTY = '";
		strSql += m_ccms990.OrigSndr + "'";

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[bp_bcoutsndcl] strSql=[%s]", strSql.c_str());
		
		SETCTX(cBpbcoutsndcl);
			
		iRet = cBpbcoutsndcl.find(strSql);
		if(SQL_SUCCESS != iRet)
		{
			 sprintf(m_szErrMsg, "bp_bcoutsndcl find fail:  [%d][%s]", 
				 iRet, cBpbcoutsndcl.GetSqlErr());
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			 cBpbcoutsndcl.closeCursor();
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		iRet = cBpbcoutsndcl.fetch();
		
		if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
		{
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "bp_bcoutsndcl游标出错 --[%d] --[%s]", iRet, cBpbcoutsndcl.GetSqlErr());
			cBpbcoutsndcl.closeCursor();
			PMTS_ThrowException(DB_FIND_FAIL);
		}
		
		if(SQL_SUCCESS == iRet)
		{
			//分明细拆分
			CBpbcoutsendlist cBpbcoutsendlist;
			strSql = "";
			strSql = " MSGID = '";
			strSql += cBpbcoutsndcl.m_msgid;
			strSql += "' and INSTGDRCTPTY = '";
			strSql += m_ccms990.OrigSndr + "'";
			
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[bp_bcoutsendlist] --sql[%s]", strSql.c_str());
			
			//设置连接
			SETCTX(cBpbcoutsendlist);
			
			iRet = cBpbcoutsendlist.find(strSql);
			
			if(SQL_SUCCESS != iRet)
			{
				 sprintf(m_szErrMsg, "bp_bcoutsendlist find fail:  [%d][%s]", 
					 iRet, cBpbcoutsendlist.GetSqlErr());
				 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
				 cBpbcoutsendlist.closeCursor();
				 cBpbcoutsndcl.closeCursor();
				 PMTS_ThrowException(DB_GET_DATA_FAIL);
			}
			
			iRet = cBpbcoutsendlist.fetch();
			
			if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
			{
				Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "循环bp_bcoutsendlist游标出错 --[%d] --[%s]", iRet, cBpbcoutsendlist.GetSqlErr());
				cBpbcoutsendlist.closeCursor();
				cBpbcoutsndcl.closeCursor();
				PMTS_ThrowException(DB_FIND_FAIL);
			}
			
			while(iRet == 0)
			{
				if(strncmp(cBpbcoutsendlist.m_srcflag.c_str(), "0", 1) == 0)
				{
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "txid[%s]", cBpbcoutsendlist.m_txid.c_str());
					
					m_strMsgID = cBpbcoutsendlist.m_txid;
					
					//判断间直连，如果是直连就入行内通讯表
					DirectInterBEPS(cBpbcoutsendlist.m_cdtrbrnchid.c_str(),
									cBpbcoutsendlist.m_dbtrbrnchid.c_str(),
									cBpbcoutsendlist.m_instddrctpty.c_str(),
									pchMsg,
									"BEPS",
									"bp_bcoutsendlist");
				}
				else
				{
					Trace(L_INFO,  __FILE__,	__LINE__, NULL, "原业务[%s]由客户端发起，不用转至行内。", m_sMsgTp);
				}
				
				iRet = cBpbcoutsendlist.fetch();
				
				if(iRet == SQLNOTFOUND)
					break;
				else if(iRet != SQL_SUCCESS)
				{
					Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "循环bp_bcoutsendlist游标出错 --[%d] --[%s]", iRet, cBpbcoutsendlist.GetSqlErr());
					cBpbcoutsendlist.closeCursor();
					cBpbcoutsndcl.closeCursor();
					PMTS_ThrowException(DB_FIND_FAIL);
				}
			}
			cBpbcoutsendlist.closeCursor();
		}
		cBpbcoutsndcl.closeCursor();
	}
	//行内可能发起小额借记往账
	else if(0 == strcmp("133", m_sMsgTp) || 0 == strcmp("PKG006", m_sMsgTp))
	{
		//从借记往账汇总表中取原数据
		CBpbdsndcl oBpbdsndcl;
		
		strSql = "";
		strSql = " MESGID = '";
		strSql += m_ccms990.MsgId;
		strSql += "' and MESGREFID = '";
		strSql += m_ccms990.MsgRefId;
		strSql += "' and INSTGDRCTPTY = '";
		strSql += m_ccms990.OrigSndr + "'";
		
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[bp_bdsndcl] strSql=[%s]", strSql.c_str());
		
		SETCTX(oBpbdsndcl);
			
		iRet = oBpbdsndcl.find(strSql);
		if(SQL_SUCCESS != iRet)
		{
			 sprintf(m_szErrMsg, "bp_bdsndcl find fail:  [%d][%s]", 
				 iRet, oBpbdsndcl.GetSqlErr());
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			 oBpbdsndcl.closeCursor();
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		iRet = oBpbdsndcl.fetch();
		
		if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
		{
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "bp_bdsndcl游标出错 --[%d] --[%s]", iRet, oBpbdsndcl.GetSqlErr());
			oBpbdsndcl.closeCursor();
			PMTS_ThrowException(DB_FIND_FAIL);
		}
		
		if(iRet == SQL_SUCCESS)
		{
			//分明细拆分
			CBpbdsendlist oBpbdsendlist;
			
			strSql = "";
			strSql = " MSGID = '";
			strSql += oBpbdsndcl.m_msgid;
			strSql += "' and INSTGDRCTPTY = '";
			strSql += m_ccms990.OrigSndr + "'";
			
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[bp_bdsendlist] --sql[%s]", strSql.c_str());
			
			//设置连接
			SETCTX(oBpbdsendlist);
			
			iRet = oBpbdsendlist.find(strSql);
			
			if(SQL_SUCCESS != iRet)
			{
				sprintf(m_szErrMsg, "CBpbdsendlist find fail:  [%d][%s]", 
					iRet, oBpbdsendlist.GetSqlErr());
				Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
				oBpbdsendlist.closeCursor();
				oBpbdsndcl.closeCursor();
				PMTS_ThrowException(DB_GET_DATA_FAIL);
			}
			
			iRet = oBpbdsendlist.fetch();
			
			if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
			{
				Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "bp_bdsendlist游标出错 --[%d] --[%s]", iRet, oBpbdsendlist.GetSqlErr());
				oBpbdsendlist.closeCursor();
				oBpbdsndcl.closeCursor();
				PMTS_ThrowException(DB_FIND_FAIL);
			}
			
			while(iRet == 0)
			{
				if(strncmp(oBpbdsendlist.m_bizsource.c_str(), "0", 1) == 0)
				{
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "txid[%s]", oBpbdsendlist.m_txid.c_str());
					
					m_strMsgID = oBpbdsendlist.m_txid;
					
					//判断间直连，如果是直连就入行内通讯表
					DirectInterBEPS(oBpbdsendlist.m_instgdrctpty.c_str(),
									oBpbdsendlist.m_dbtrbrnchid.c_str(),
									oBpbdsendlist.m_instddrctpty.c_str(),
									pchMsg,
									"BEPS",
									"bp_bdsendlist");
				}
				else
				{
					Trace(L_INFO,  __FILE__,	__LINE__, NULL, "原业务[%s]由客户端发起，不用转至行内。", m_sMsgTp);
				}
				
				iRet = oBpbdsendlist.fetch();
				
				if(iRet == SQLNOTFOUND)
					break;
				else if(iRet != SQL_SUCCESS)
				{
					Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "循环bp_bdsendlist游标出错 --[%d] --[%s]", iRet, oBpbdsendlist.GetSqlErr());
					oBpbdsendlist.closeCursor();
					oBpbdsndcl.closeCursor();
					PMTS_ThrowException(DB_FIND_FAIL);
				}
			}
			oBpbdsendlist.closeCursor();
		}
		oBpbdsndcl.closeCursor();
	}
	else
	{
        Trace(L_INFO, __FILE__, __LINE__, NULL, "报文类型[%s], 不用入行内通讯表", m_sMsgTp);
	}
	
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Exit [CRecvCcms990::InsertComsendmb]");
	
	return 0;
}

