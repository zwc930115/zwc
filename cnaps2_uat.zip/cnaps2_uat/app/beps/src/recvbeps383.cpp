/******************************************************************** 
文件名： recvbeps383.cpp
创建人： handongfeng
日  期： 2011-02-23
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif
#include "recvbeps383.h"

CRecvbeps383::CRecvbeps383()
{
    m_colltnchrgscl.m_msgtp = "beps.383.001.01";
    m_colltnchrgslist.m_msgtp = "beps.383.001.01";

}

CRecvbeps383::~CRecvbeps383()
{

}

int CRecvbeps383::Work(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps383::Work()");
 
     m_IsSendMB = false;
    // 解析报文
    unPack(szMsg);
    CheckSign383();

    SetData(szMsg);

    // 插入数据
    InsertData();

    //UpdataOriState();
    
/*
    // 设置返回消息
    SetRtuMsg();
    
    // 添加队列
    AddQueue(,)
*/
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps383::Work()");
    return OPERACT_SUCCESS;
}

int CRecvbeps383::UpdataOriState()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "ENTER CRecvbeps383::UpdateState");
    //获取通信id
   
    char m_MesgId[20+1] = {0};
    
    GetMsgIdValue(m_dbproc, m_MesgId, eRefId,  SYS_BEPS);

    std::string strSQL;

	strSQL = "UPDATE bp_colltnchrgslist t SET t.STATETIME = sysdate, t.PROCSTATE = '07'";
	strSQL += ", t.MESGID = '";
    strSQL += m_MesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_MesgId;
    strSQL += "' ,BUSISTATE = '";
    strSQL += m_beps383.Sts;
    strSQL += "' ,PROCESSCODE = '";
    strSQL += m_beps383.PrcSts;
    strSQL += "' ,RJCTINF = '";
    strSQL += m_beps383.RspsnInfRjctInf;
    strSQL += "'";
    
    strSQL = "WHERE  Msgid = '";
    strSQL += m_beps383.OrgnlMsgId;
    strSQL += "' AND INSTGPTY = '";
    strSQL += m_beps383.OrgnlInstgPty;
    strSQL += "' AND TXID = '";
    strSQL += m_beps383.TxId;
    strSQL += "' AND DBTRID = '";
    strSQL += m_beps383.DbtrAcctId;
    strSQL += "'";
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    SETCTX(m_colltnchrgslist);
    int iRet = m_colltnchrgslist.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "UpdateDetailState失败,  iRet=%d, %s", iRet, m_colltnchrgslist.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    strSQL = "UPDATE bp_colltnchrgscl t SET t.STATETIME = sysdate, t.PROCSTATE = '07'";
	strSQL += ", t.MESGID = '";
    strSQL += m_MesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_MesgId;
    strSQL += "' ,BUSISTATE = '";
    strSQL += m_beps383.Sts;
    
    strSQL += "' WHERE t.MSGID = '";
	strSQL += m_beps383.OrgnlMsgId.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_beps383.OrgnlInstgPty.c_str();
	strSQL += "' AND CDBTRID = '";
    strSQL += m_beps383.CdtrAcctId;
    strSQL += "'";
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    SETCTX(m_colltnchrgscl);
    iRet = m_colltnchrgscl.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "UpdateState失败,  iRet=%d, %s", iRet, m_colltnchrgscl.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "LEAVE CRecvbeps383::UpdateState");
    return iRet;
}

INT32 CRecvbeps383::unPack(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps383::unPack()");
    
    int iRet = -1;
    
    // 报文是否为空
    if (NULL == szMsg || '\0' == szMsg)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");	
    	PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文为空");
    }
    
    //获取工作日期
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(iRet != RTN_SUCCESS)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");	
    	PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;    

    // 解析报文
    if (OPERACT_SUCCESS != m_beps383.ParseXml(szMsg))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错! iRet= %d", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "获取解析对象失败");
    }
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps383::unPack()");
    return OPERACT_SUCCESS;
}

INT32 CRecvbeps383::InsertData()
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps383::InsertData()");

	m_colltnchrgscl.m_busistate = m_beps383.PrcSts;	
	m_colltnchrgscl.m_processcode = m_beps383.PrcCd;
	m_colltnchrgscl.m_rjctinf     = m_beps383.RspsnInfRjctInf;
	m_colltnchrgscl.m_netgdt      = m_beps383.NetgDt;
	m_colltnchrgscl.m_netgrnd     = m_beps383.NetgRnd;
	m_colltnchrgscl.m_finalstatedate = m_beps383.NetgDt;

    m_colltnchrgscl.m_procstate = "15" ; 
    m_colltnchrgscl.m_workdate = m_strWorkDate ;   
    m_colltnchrgscl.m_consigdate = m_strWorkDate ; 
    m_colltnchrgscl.m_msgtp = "beps.383.001.01";
    m_colltnchrgscl.m_srcflag = '2' ; 
    m_colltnchrgscl.m_dbtrmmbid = m_colltnchrgslist.m_instgdrctpty;
    m_colltnchrgscl.m_cdtrmmbid = m_colltnchrgslist.m_instddrctpty;
    m_colltnchrgscl.m_checkstate = "01";

	m_colltnchrgscl.m_orgnlttlnb = atoi(m_beps383.OrgnlTtlNb.c_str());
	m_colltnchrgscl.m_orgnlttlam = atof(m_beps383.OrgnlTtlAmt.c_str());
    m_colltnchrgscl.m_ttlamt = atof(m_beps383.SndgTtlAmt.c_str()); 
    m_colltnchrgscl.m_cdbtrnb = atoi(m_beps383.SndgTtlNb.c_str()) ; 
	m_colltnchrgscl.m_rcvsndgttlamt = atof(m_beps383.SndgTtlAmt.c_str()); 
	m_colltnchrgscl.m_rcvsndgttlnb = atoi(m_beps383.SndgTtlNb.c_str()) ; 

    m_colltnchrgscl.m_mesgid = m_beps383.m_PMTSHeader.getMesgID(); 
    m_colltnchrgscl.m_mesgrefid = m_beps383.m_PMTSHeader.getMesgRefID();
    m_colltnchrgscl.m_msgid = m_beps383.MsgId; 
    m_colltnchrgscl.m_instgdrctpty = m_beps383.InstgDrctPty; 
    m_colltnchrgscl.m_instgpty = m_beps383.GrpHdrInstgPty; 
    m_colltnchrgscl.m_instddrctpty = m_beps383.InstdDrctPty; 
    m_colltnchrgscl.m_instdpty = m_beps383.GrpHdrInstdPty; 
    m_colltnchrgscl.m_rmk = m_beps383.Rmk; 
    m_colltnchrgscl.m_syscd = m_beps383.SysCd;  

    m_colltnchrgscl.m_orgnlmsgid = m_beps383.OrgnlMsgId;// 原报文标识号
    m_colltnchrgscl.m_orgnlinstgpty = m_beps383.OrgnlInstgPty;//原发起参与机构
    m_colltnchrgscl.m_orgnlbtchnb = m_beps383.OrgnlBtchNb;//原批次序号

    m_colltnchrgscl.m_npcprcsts = m_beps383.PrcSts;//NPC处理状态
    m_colltnchrgscl.m_npcprccd = m_beps383.PrcCd;//NPC处理码
    m_colltnchrgscl.m_npcrjctinf = m_beps383.NPCPrcInfRjctInf;//NPC拒绝信息
    m_colltnchrgscl.m_netgdt = m_beps383.NetgDt;//NPC轧差日期
    m_colltnchrgscl.m_netgrnd = m_beps383.NetgRnd;//NPC轧差场次
    m_colltnchrgscl.m_finalstatedate = m_beps383.SttlmDt;//NPC清算日期/终态日期

    m_colltnchrgscl.m_currency = m_beps383.SndgTtlAmtCcy;//成功收款总金额货币符号
    m_colltnchrgscl.m_cdbtrid = m_beps383.DbtrAcctId;//付款人账号
    m_colltnchrgscl.m_cdbtrnm = m_beps383.DbtrNm;//付款人名称
    m_colltnchrgscl.m_cdbtrbrnchid = m_beps383.DbtrAgtId;// 付款行行号
    
    SETCTX(m_colltnchrgscl);
    int iRet = m_colltnchrgscl.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__,  __LINE__, NULL, 
            "m_colltnchrgscl.insert() failed:error code =[%d],error cause =[%s]", iRet,m_colltnchrgscl.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "新增表失败");
    }

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps383::InsertData()");
    return iRet;
}

INT32 CRecvbeps383::SetData(LPCSTR pchMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps383::SetData()");    
    int iRet = -1;
    int iNum = m_beps383.GetNodeCountByName("SndgDtls");

    char sMesgId[20 + 1] = {0};
    
    GetMsgIdValue(m_dbproc, sMesgId, eRefId,  SYS_BEPS);
    
    m_colltnchrgslist.m_instgdrctpty = m_beps383.InstgDrctPty;//发起直接参与机构
    m_colltnchrgslist.m_instgpty = m_beps383.GrpHdrInstgPty;//间接发起参与机构
    m_colltnchrgslist.m_instddrctpty = m_beps383.InstdDrctPty;//接收直接参与机构
    m_colltnchrgslist.m_instdpty = m_beps383.GrpHdrInstdPty;//间接发起参与机构
    m_colltnchrgslist.m_syscd = "BEPS"           ;//系统编号
    
    m_colltnchrgslist.m_workdate = m_strWorkDate;
    m_colltnchrgslist.m_consigdate = m_strWorkDate ; 
    m_colltnchrgslist.m_msgtp = "beps.383.001.01";    
    m_colltnchrgslist.m_dbtrmmbid = m_colltnchrgslist.m_instgdrctpty;
    m_colltnchrgslist.m_cdtrmmbid = m_colltnchrgslist.m_instddrctpty;
    m_colltnchrgslist.m_procstate = "15";
    	
    SETCTX(m_colltnchrgslist);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iNum[%d]",iNum);
    for(int i = 0; i < iNum; i++)
    {
        m_beps383.ParseDetail(i);

        m_colltnchrgslist.m_busistate = m_beps383.Sts;//业务状态
        //m_colltnchrgslist.m_rjctcd = m_beps383.RjctCd;//业务拒绝处理码
        m_colltnchrgslist.m_rjctinf = m_beps383.RspsnInfRjctInf;//业务拒绝信息
        m_colltnchrgslist.m_rjctprcpty = m_beps383.PrcPty;//业务处理参与机构
        m_colltnchrgslist.m_msgid = m_beps383.MsgId;//报文标识号        	
        m_colltnchrgslist.m_instgpty = m_beps383.GrpHdrInstgPty; 
        m_colltnchrgslist.m_txid = m_beps383.TxId;//明细标识号        
        m_colltnchrgslist.m_dbtrnm = m_beps383.DbtrNm           ;//付款人户名
        m_colltnchrgslist.m_dbtrid = m_beps383.DbtrAcctId           ;//付款人账号
        m_colltnchrgslist.m_dbtrbrnchid = m_beps383.DbtrAgtId           ;//付款行行号
        m_colltnchrgslist.m_cdtrbrnchid = m_beps383.SndgDtlsBrnchId           ;//收款行行号
        m_colltnchrgslist.m_cdtrnm = m_beps383.CdtrNm;//收款人名称
        m_colltnchrgslist.m_cdtrid = m_beps383.CdtrAcctId;//收款人账号
        m_colltnchrgslist.m_currency = m_beps383.AmtCcy;//货币符号
        m_colltnchrgslist.m_amout = atof(m_beps383.Amt.c_str());//金额  
        m_colltnchrgslist.m_addtlinf = m_beps383.AddtlInf;//附言
        m_colltnchrgslist.m_srcflag = "2";
        
        // 循环加签要素
        m_beps383.AddTxStr();  
        
        //明细表插入数据
        iRet = m_colltnchrgslist.insert();
        if(OPERACT_SUCCESS != iRet)
        {
            Trace(L_ERROR, __FILE__,  __LINE__, NULL, 
                "m_colltnchrgslist.insert() failed:error code =[%d],error cause =[%s]", iRet,m_colltnchrgscl.GetSqlErr());
            PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "新增表失败");
        }
    }


    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps383::SetData()");
    return OPERACT_SUCCESS;
}

void CRecvbeps383::SendRtuMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "ENTER CRecvbeps381::SetRtuMsg");

   char m_sMsgRefId[20+1] = {0};
   
    m_beps389.MsgId           = m_colltnchrgscl.m_msgid;//报文标识号	
    m_beps389.CreDtTm         = m_strWorkDate;//报文发送时间
    m_beps389.InstgDrctPty    = m_colltnchrgscl.m_instgdrctpty;//发起直接参与机构
    m_beps389.GrpHdrInstgPty  = m_colltnchrgscl.m_instgpty;//间接发起参与机构
    m_beps389.InstdDrctPty    = m_colltnchrgscl.m_instddrctpty;//接收直接参与机构
    m_beps389.GrpHdrInstdPty  = m_colltnchrgscl.m_instdpty;//间接接收参与机构
    m_beps389.SysCd           = m_colltnchrgscl.m_syscd;//系统编号
    m_beps389.Rmk             = m_colltnchrgscl.m_rmk;//备注
    m_beps389.OrgnlMsgId      = m_colltnchrgscl.m_msgid;//原报文标识号
    m_beps389.OrgnlInstgPty   = m_colltnchrgscl.m_instgpty;//原发起参与机构
    m_beps389.OrgnlMT     = m_colltnchrgscl.m_msgtp;//原报文类型
    m_beps389.Sts             = m_colltnchrgscl.m_busistate;//业务状态
    m_beps389.RjctCd          = m_colltnchrgscl.m_processcode;//业务拒绝处理码
    m_beps389.RjctInf = m_colltnchrgscl.m_rjctinf;//业务拒绝信息
    m_beps389.PrcPty          = m_colltnchrgscl.m_rjctprcpty;//业务处理参与机构

    bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "参数错误");
	    PMTS_ThrowException(PRM_FAIL);
    }

    // 组文件头
    m_beps389.CreateXMlHeader("beps",                        \
                                m_colltnchrgscl.m_workdate.c_str(), \
                                m_colltnchrgscl.m_instgdrctpty.c_str(),\
                                m_colltnchrgscl.m_instddrctpty.c_str(),\
                                "beps.389.001.01",              \
                                m_sMsgRefId);

    AddQueue(m_beps389.m_sXMLBuff, m_beps389.m_sXMLBuff.size());
    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "LEAVE CRecvbeps381::SetRtuMsg");
    return ;
}

void CRecvbeps383::CheckSign383()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbeps383::CheckSign383()");
	
	m_beps383.getOriSignStr();
	
	CheckSign(m_beps383.m_sSignBuff.c_str(),
			m_beps383.m_szDigitSign.c_str(),
			m_beps383.InstgDrctPty.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbeps383::CheckSign383()");
}


