#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif


#include "pubfunc.h"
#include "logger.h"
#include "tsocket.h"
#include "basic.h"
#include "exception.h"
#include "bpbcoutsendlist.h"
#include "connectpool.h"
#include "cfg_obj.h"
#include "configparser.h"
#include "mqagent.h"

CConnectPool *g_DBConnPool;
using namespace ZFPT;
CCfgObj pCfgFile;

int LoadConfigFile(stuCfgInfo &CfgInfo, int &iLoopNum, string &sTxId);


int Snd2Host(LPTSTR sHostRqt)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "进入Snd2Host");
	char sMbRsp[4096 + 1];
	char sTimeOut[120 + 1];

    int iSocket;
	int iRet = 0;
	int m_nHostPort;
	int iLenth = 0;
	string m_strHostIp;
	string m_strHostRsp;
	memset(sMbRsp, 0, sizeof(sMbRsp));
	memset(sTimeOut, 0, sizeof(sTimeOut));

	char sTmpBuf[20 + 1];

	memset(sTmpBuf, 0, sizeof(sTmpBuf));

	m_nHostPort = 50003;
	m_strHostIp = "172.168.8.197";

	TSocketClient SocketClient;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "开始连接SocketClient");
	
	if ( (iSocket = SocketClient.connectServer((char *)m_strHostIp.c_str(), m_nHostPort))<= 0)
	{
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "连接SocketClient失败");
		return -1;
	}

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "进入SocketClient.sendMsg");
	if(true != SocketClient.sendMsg(iSocket, sHostRqt, strlen(sHostRqt)))
	{
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "发送数据失败");
        SocketClient.disConnet();
		return -2;
	}
	
	iRet = SocketClient.recvMsg(sMbRsp, iLenth);
	if (iRet > 0)
	{
		m_strHostRsp = sMbRsp;
		printf("[%s]", sMbRsp);
		printf("44444444444444444444444444444444444444444444444444444\n");
	}
	else
	{
		printf("33333333333333333333333333333333333333333333\n");
		return -3;
	}

	SocketClient.disConnet();
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "退出Snd2Host");
	return 0;
}

int main()
{
	int iRet = 0;
	int iLoopNum = 0;
	char sMsgID[28 + 1] = {0};   //MsgID
	char szErrMsg[1024];	     //错误描述
	char sSqlStr[2048];		     //SQL语句
	DBProc dbproc;               //连接
	stuCfgInfo  CfgInfo ;
	CBpbcoutsendlist cBpbcoutsendlistTmp;
	string szTxId = "";

	//加载配置文件
	LoadConfigFile(CfgInfo, iLoopNum, szTxId);
	
	//初始化日志
	ZFPTLOG.setCfgInfo(CfgInfo.szLogPath, "sockettest", CfgInfo.iLogLeave, CfgInfo.dLogMaxSize);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化日志..."); 
 
	//创建连接池 
    g_DBConnPool = new CConnectPool(CfgInfo.iConPoolMinNum,CfgInfo.iConPoolMaxNum,CfgInfo.iNoConWaitTime);	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化连接池...");    
	    
    iRet= g_DBConnPool->InitPool(CfgInfo.iConPoolSize,CfgInfo.DBUser,CfgInfo.DBKey,CfgInfo.DBName);
		
    if(iRet == RTN_SUCCESS)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "连接池创建成功");
    }
    else
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "连接池创建失败");
        exit(0);
     }

	//连接
	if(0 != g_DBConnPool->GetConnect(dbproc))
    {
        snprintf(szErrMsg, sizeof(szErrMsg), 
            "CRecvCcmsBase::GetDBConnect():获取数据库连接失败");
        
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, szErrMsg);
        
        exit(0);
    }

	if (0 != cBpbcoutsendlistTmp.setctx(dbproc))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
        exit(0);
    }
	
	for(int k = 0; k < iLoopNum; k++)
	{
		memset(sMsgID, NULL_CHAR, sizeof(sMsgID));
		STRING sHostRqt = "00000095beps3XML125";
		// 获取MSGID
        if (!GetMsgIdValue(dbproc, sMsgID, eMsgId, SYS_BEPS))
            break;	
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sMsgID = [%s]", sMsgID);
		
		sprintf(sSqlStr, "INSERT INTO BP_BCOUTSENDLIST(INSTGDRCTPTY,WORKDATE, CONSIGDATE, MSGTP, MSGID, INSTDDRCTPTY, DBTNM, DBTRACCTID, DBTRISSR, DBTRBRNCHID, CDTRNM, CDTRACCTID, CDTRISSR, CDTRBRNCHID,"
						 "CURRENCY, AMOUNT, PMTTPPRTRY, PURPPRTRY, ADDTLINF, CSTMRCDTTRFADDTLINF, ORGNLMSGID, ORGNLMSGTP, ORIINSTGDRCTPTY, ORITXID, ORIPKGNUM,  ORIAMOUNT, NPCMSGLEN, NPCMSG, MBMSG, SRCFLAG, CHECKSTATE,"
						 "BUSISTATE, PROCESSCODE, RJCTINF, PROCSTATE, STATETIME, FINALSTATEDATE, ACCTSTATE, ACSTATETIME, ACCTREGNUM, REACREGNUM, NETGDT, NETGRND, ISTSTATETIME, INPUTTIME, CHECKTIME, GRANTTIME, INPUTOPER,"
						 "CHECKOPER, GRANTOPER, PRINTNO, ISRBFLG, DBTADDR, CDTADDR, MBMSGID, MBINSTPTY, REMARK, TXID) SELECT INSTGDRCTPTY,WORKDATE, CONSIGDATE, MSGTP, '0', INSTDDRCTPTY, DBTNM, DBTRACCTID, DBTRISSR,"
						 "DBTRBRNCHID, CDTRNM, CDTRACCTID, CDTRISSR, CDTRBRNCHID, CURRENCY, AMOUNT, PMTTPPRTRY, PURPPRTRY, ADDTLINF, CSTMRCDTTRFADDTLINF, ORGNLMSGID, ORGNLMSGTP, ORIINSTGDRCTPTY, ORITXID, ORIPKGNUM,"
						 "ORIAMOUNT, NPCMSGLEN, NPCMSG, MBMSG, SRCFLAG, CHECKSTATE, BUSISTATE, PROCESSCODE, RJCTINF, PROCSTATE, STATETIME, FINALSTATEDATE, ACCTSTATE, ACSTATETIME, ACCTREGNUM, REACREGNUM, NETGDT, NETGRND,"
						 "ISTSTATETIME, INPUTTIME, CHECKTIME, GRANTTIME, INPUTOPER, CHECKOPER, GRANTOPER, PRINTNO, ISRBFLG, DBTADDR, CDTADDR, MBMSGID, MBINSTPTY, REMARK, '%s' FROM BP_BCOUTSENDLIST WHERE TXID = '%s'",
						 sMsgID, szTxId.c_str());

        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr[%s]", sSqlStr);
		iRet = cBpbcoutsendlistTmp.execsql(sSqlStr);
        if(0 != iRet)
        {
            cBpbcoutsendlistTmp.rollback();
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "insert error[%d][%s]", 
                 iRet, cBpbcoutsendlistTmp.GetSqlErr());
        }
        cBpbcoutsendlistTmp.commit();
		sHostRqt += Trim(sMsgID);
		sHostRqt += "            785584000009   A1000000000000000000000000000000000000000";

        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "发送消息打印[%s]", sHostRqt.c_str());
		
		if(0 !=Snd2Host((char*)sHostRqt.c_str()))
		    break;
	}

	//释放连接
	g_DBConnPool->PutConnect(dbproc);

	if(NULL != g_DBConnPool)
	{
	    delete g_DBConnPool;
	    g_DBConnPool = NULL;
	}
}

int LoadConfigFile(stuCfgInfo &CfgInfo, int &iLoopNum, string &sTxId)
{
    CConfigParser& cCfg = CConfigParser::getInstance();

    strcpy(CfgInfo.path, ZFPT_CFG_PATH);
    cCfg.loadConfig(CfgInfo.path);
    
    strncpy(CfgInfo.szLogPath, cCfg.getOption("LOGPATH"), sizeof(CfgInfo.szLogPath)-1);
    CfgInfo.iPort = atoi(cCfg.getOption("BEPSPORT"));
    CfgInfo.iLogLeave = atoi(cCfg.getOption("LOGLVL"));
    strncpy(CfgInfo.RecvQueue, cCfg.getOption("BEPSRECVMQ"), sizeof(CfgInfo.RecvQueue)-1);
    strncpy(CfgInfo.SendQueue, cCfg.getOption("BEPSSENDMQ"), sizeof(CfgInfo.SendQueue)-1);

    CfgInfo.iConPoolMinNum = atoi(cCfg.getOption("BPCONNPOOLMINSIZE"));
    CfgInfo.iConPoolMaxNum = atoi(cCfg.getOption("BPCONNPOOLMAXSIZE"));
    CfgInfo.iNoConWaitTime	 = atoi(cCfg.getOption("BPNOCONNWAITTIME"));
    CfgInfo.iConPoolSize = atoi(cCfg.getOption("BPCONNPOOLSIZE"));
    CfgInfo.iThreadPoolSize = atoi(cCfg.getOption("BPTHREADPOOLSIZE"));
    CfgInfo.iThreadPoolTaskSize = atoi(cCfg.getOption("BPTHREADPOOLTASKSIZE"));
    CfgInfo.dLogMaxSize = atof(cCfg.getOption("LOGMAXSIZE"));

    strncpy(CfgInfo.szMQmgr , cCfg.getOption("MQMGR"), sizeof(CfgInfo.szMQmgr)-1);

    strncpy(CfgInfo.DBUser,cCfg.getOption("DBUSER"),sizeof(CfgInfo.DBUser)-1);
    strncpy(CfgInfo.DBKey,cCfg.getOption("DBKEY"),sizeof(CfgInfo.DBKey)-1);
    strncpy(CfgInfo.DBName,cCfg.getOption("DBNAME"),sizeof(CfgInfo.DBName)-1);

    strncpy(CfgInfo.szXmlCtgPath,cCfg.getOption("XMLCTGPATH"),sizeof(CfgInfo.szXmlCtgPath)-1);
    strncpy(CfgInfo.szMqTxtPath,cCfg.getOption("MQTEXTPATH"),sizeof(CfgInfo.szMqTxtPath)-1);

    iLoopNum = atoi(cCfg.getOption("LOOPNUM"));
    sTxId    = cCfg.getOption("LOOPMSGID");
    
    return OPERACT_SUCCESS;
}

