
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "bpbcoutsndcl.h"
#include "bpbcoutrcvcl.h"
#include "bpbdsndcl.h"
#include "bpbdrcvcl.h"
#include "bpcolltnchrgscl.h"
#include "cmtransinfoqry.h"
#include "syscomsendmb.h"
#include "sysmbchkst.h"

#include "recvbeps721.h"

using namespace ZFPT;

#define SR_SND "SR00"
#define SR_RCV "SR01"



CRecvBeps721::CRecvBeps721()
{
	m_iTtlCnt = 0;
	m_iLocalMore = 0;

	m_iSTtlCnt = 0;
	m_dSTtlAmt = 0.0;
	m_iRTtlCnt = 0;
	m_dRTtlAmt = 0.0;

	m_iLocalSTtlCnt = 0;
	m_dLocalSTtlAmt = 0.0;
	m_iLocalRTtlCnt = 0;
	m_dLocalRTtlAmt = 0.0;

	memset(m_szSTblNm, 0x00, sizeof(m_szSTblNm));
	memset(m_szRTblNm, 0x00, sizeof(m_szRTblNm));
	memset(m_szSLsTblNm, 0x00, sizeof(m_szSLsTblNm));
	memset(m_szRLsTblNm, 0x00, sizeof(m_szRLsTblNm));
	m_bIsPmt = false;

	m_iPmtCnt722 = 0;
	m_iMsgCnt722 = 0;
}

CRecvBeps721::~CRecvBeps721()
{
}

//__wsh 2012-10-23 报文处理入口
int CRecvBeps721::Work(LPCSTR szMsg)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps721::Work");

	int iRet = 0;

	//解析报文
	iRet = UnPack(szMsg);

	if(!ChickIfContuine())
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL, "Do nothing");
		return 0;
	}
	//检查小额对账状态表是否存在当前对账日期对账状态记录
	iRet = CheckBChkState();

	//更新清算行小额对账日期
	iRet = UpdateSapBkChkDt();

	//根据对账清算行及对账日期删除对账汇总数据
	iRet = ClearCheckCl();

	//对账汇总数据入库
	iRet = InsertData();

	//核签
	ChkSign721();

	//执行汇总对账
	iRet = DoCheck();	

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps721::Work");

	return RTN_SUCCESS;
}

bool CRecvBeps721::ChickIfContuine()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBeps721::ChickIfContuine()");

    char sSql[1024 + 1] = {0};
    int  iRet = -1;
    
    sprintf(sSql, "CHECKDATE = '%s' AND SAPBANK = '%s'",
                    m_cBeps721.ChckDt.c_str(), m_cBeps721.InstdDrctPty.c_str() );

	SETCTX(m_sapbankinfo);	
	iRet = m_sapbankinfo.find(sSql);
	if(0 != iRet)
	{	
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FIND HV_SAPBANKINFO FILED[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "FIND HV_SAPBANKINFO FILED!");
	}
	else
	{
		iRet = m_sapbankinfo.fetch();
		if( 1403 == iRet)
		{
			Trace(L_INFO,	__FILE__,  __LINE__, NULL, "Now FIRST CHECK");
			m_sapbankinfo.closeCursor();
			return true;
		}		
	}
	
	m_sapbankinfo.closeCursor();

	m_checkqry.m_msgid = m_cBeps721.OrgnlMsgId;
	m_checkqry.m_msgtype = m_cBeps721.OrgnlMT;
	m_checkqry.m_sapbank = m_cBeps721.InstdDrctPty;
	SETCTX(m_checkqry);
	iRet = m_checkqry.findByPK();
	if(1403 != iRet && 0 != iRet)
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FIND CM_CHECKQRY FILED[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "FIND CM_CHECKQRY FILED!");
	}
	else if(1403 == iRet)
	{	
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "MSGID=[%s] MSGTP=[%s] SAPBANK=[%s] NOT PMTS QRY",
			                        m_checkqry.m_msgid.c_str(),m_checkqry.m_msgtype.c_str(),m_checkqry.m_sapbank.c_str());		
		return false;
	}
	else{
		return true;
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "CRecvBeps721::ChickIfContuine()");
	return true;
}


//__wsh 2012-10-23 解析报文
int CRecvBeps721::UnPack(LPCSTR szMsg)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps721::UnPack");
	int iRet = -1;

	if(NULL == szMsg || '\0' == szMsg[0]){
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "报文长度为空");
		PMTS_ThrowException(PRM_FAIL);
	}

	//解析报文
	if (OPERACT_SUCCESS != m_cBeps721.ParseXml(szMsg)){
		Trace(L_ERROR,  __FILE__,  __LINE__,
				NULL, "报文解析出错! iRet= %d", iRet);

		PMTS_ThrowException(__FILE__, __LINE__,
				OPT_PRS_MSG_FAIL, "报文解析出错");
	}

	m_strWorkDate = m_sWorkDate;

	//ZFPTLOG.SetLogInfo("721", m_cBeps721.MsgId.c_str());

	//设置实体类数库连接
	SetConnCtx();

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps721::UnPack");

	return iRet;
}

//__wsh 2012-10-23 设置实体类数据库连接
void CRecvBeps721::SetConnCtx(void)
{
	SETCTX(m_chkcl);
	SETCTX(m_chkacct);
	SETCTX(m_bchkst);
}

//__wsh 2012-10-23 检查小额对账状态表是否存在当前对账日期对账状态记录， 如果不存在，则不对账
int CRecvBeps721::CheckBChkState(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps721::CheckBChkState");
	int iRet = -1;

	string strSql = "";
	strSql.append(" chkdate='").append(m_cBeps721.ChckDt);
	strSql.append("' and pkbknode='");
	strSql.append(m_cBeps721.InstdDrctPty).append("' ");

	Trace(L_DEBUG, __FILE__, __LINE__,
			NULL, "__strSql=[%s]", strSql.c_str());
	iRet = m_bchkst.findcount(strSql);
	if(iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[bp_bchkstate]查找失败,不执行对账:(%d)%s", iRet, m_bchkst.GetSqlErr());
		PMTS_ThrowException(DB_FIND_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps721::CheckBChkState");

	return iRet;
}

//__wsh 2012-10-23 更新清算行对账日期
int CRecvBeps721::UpdateSapBkChkDt(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps721::UpdateSapBkChkDt");

	int iRet = -1;

	char szSql[512] = {0};
	snprintf(szSql, sizeof(szSql),
			"update bp_sapbankinfo set checkdate='%s' "
			"where sapbank='%s'",
			m_cBeps721.ChckDt.c_str(), m_cBeps721.InstdDrctPty.c_str());

	Trace (L_DEBUG, __FILE__, __LINE__, NULL, "__szSql=[%s]", szSql);

	iRet = m_chkcl.execsql(szSql);
	if(iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[bp_sapbankinfo]更新失败:[%s]", m_chkcl.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	memset(szSql, 0x00, sizeof(szSql));
	snprintf(szSql, sizeof(szSql),
	            " update bp_bchkstate set checkstate='%s', statetime=sysdate "
	            " where chkdate='%s' and pkbknode='%s' ",
	            PR_CNCH_20, m_cBeps721.ChckDt.c_str(), m_cBeps721.InstdDrctPty.c_str());

	Trace (L_DEBUG, __FILE__, __LINE__, NULL, "__szSql=[%s]", szSql);

	iRet = m_chkcl.execsql(szSql);
	if(iRet != SQL_SUCCESS
	   && iRet != 1403)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[bp_bchkstate]更新失败:[%s]", m_chkcl.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}
	else if(iRet == 1403)
	{
    	snprintf(szSql, sizeof(szSql),
    	            " insert into bp_bchkstate (checkstate,statetime,chkdate,pkbknode,workdate,FEASTFLAG) values "
    	            " ('%s',sysdate,'%s','%s','%s','0')",
    	            PR_CNCH_20, m_cBeps721.ChckDt.c_str(), m_cBeps721.InstdDrctPty.c_str(),m_strWorkDate.c_str());	        
    	            
    	Trace (L_DEBUG, __FILE__, __LINE__, NULL, "__szSql=[%s]", szSql);
    	            
    	iRet = m_chkcl.execsql(szSql);
    	if(iRet != SQL_SUCCESS)
    	{
    		Trace(L_ERROR, __FILE__, __LINE__, NULL,
    				"[bp_bchkstate]插入失败:[%s]", m_chkcl.GetSqlErr());
    		PMTS_ThrowException(DB_UPDATE_FAIL);
    	}    	            
	}
	else
	{}


	//提交事务
	m_chkcl.commit();

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps721::UpdateSapBkChkDt");

	return iRet;
}

//__wsh 2012-10-23 根据对账清算行及对账日期删除对账汇总数据
int CRecvBeps721::ClearCheckCl(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps721::ClearCheckCl");

	int iRet = -1;

	//清除汇总对账明细
	string strSql = "delete from bp_checkcl where chckdt='";
	strSql += m_cBeps721.ChckDt;
	strSql += "' and instddrctpty='";
	strSql += m_cBeps721.InstdDrctPty + "' ";

	Trace (L_DEBUG, __FILE__, __LINE__,
				NULL, "__strSql=[%s]", strSql.c_str());

	iRet = m_chkcl.execsql(strSql);
	if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[bp_checkcl]删除失败:[%s]", m_chkcl.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	//__wsh 2013-01-15 清除明细对账表, 避免手工人行对账再次申请明细对账致处理723失败情况
	strSql.clear();
	strSql.append(" delete from bp_chklstlist where instddrctpty='");
	strSql.append(m_cBeps721.InstdDrctPty);
	strSql.append("' and chckdt='").append(m_cBeps721.ChckDt).append("' ");

	Trace (L_DEBUG, __FILE__, __LINE__,
				NULL, "__strSql=[%s]", strSql.c_str());

	iRet = m_chkcl.execsql(strSql);
	if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[bp_chklstlist]删除失败:[%s]", m_chkcl.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	//提交事务
	m_chkcl.commit();

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps721::ClearCheckCl");
	return iRet;
}

//__wsh 2012-10-23 对账汇总数据入库
int CRecvBeps721::InsertData(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps721::InsertData");

	int iRet = -1;

	//业务类对账汇总解析入库
	int iNbOfChckPmtInf = atoi(m_cBeps721.ChckPmtInfNbOfChckInf.c_str());
	for(int i = 0; i < iNbOfChckPmtInf; ++i){
		GetChckPmtInfDtls(i);
		AddCheckCl();
	}

	//信息类对账汇总解析入库
	int iNbOfChckMsgInf = atoi(m_cBeps721.ChckMsgNbOfChckInf.c_str());
	for(int j = 0; j < iNbOfChckMsgInf; ++j){
		GetChckMsg(j);
		AddCheckCl();
	}

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps721::InsertData");

	return iRet;
}

//__wsh 2012-10-24 解析业务类对账明细
//i: 节点索引
void CRecvBeps721::GetChckPmtInfDtls(int i)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps721::GetChckPmtInfDtls");
#define GETPMTDTL721(BEPS721MEMBER, TAG721) m_cBeps721.BEPS721MEMBER = \
	m_cBeps721.GetValueFromCycle("ChckPmtInfDtls", TAG721, i);\
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, \
		"### m_cBeps721."#BEPS721MEMBER"=[%s]", m_cBeps721.BEPS721MEMBER.c_str())

	GETPMTDTL721(TxNetgDt,  "TxNetgDt"); //轧差日期
	GETPMTDTL721(TxNetgRnd, "TxNetgRnd");//轧差场次
	GETPMTDTL721(ChckPmtInfDtlsMT, "ChckPmtInfDtlsMT"); //报文类型
	GETPMTDTL721(ChckPmtInfDtlsSndTtlCnt, "ChckPmtInfDtlsSndTtlCnt");//往报总笔数
	GETPMTDTL721(SndTtlAmt, "SndTtlAmt");//往报总金额
	GETPMTDTL721(ChckPmtInfDtlsRcvTtlCnt, "ChckPmtInfDtlsRcvTtlCnt");//来报总笔数
	GETPMTDTL721(RcvTtlAmt, "RcvTtlAmt");//来报总金额
	GETPMTDTL721(ChckPmtInfDtlsPrcSts, "ChckPmtInfDtlsPrcSts"); //报文处理状态

	m_iSTtlCnt = atoi(m_cBeps721.ChckPmtInfDtlsSndTtlCnt.c_str());
	m_dSTtlAmt = atof(m_cBeps721.SndTtlAmt.c_str()+3);
	m_iRTtlCnt = atoi(m_cBeps721.ChckPmtInfDtlsRcvTtlCnt.c_str());
	m_dRTtlAmt = atof(m_cBeps721.RcvTtlAmt.c_str()+3);

	m_bIsPmt = true;

	//循环加签
	m_cBeps721.getChckPmtInfDtls();

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps721::GetChckPmtInfDtls");
}

//__wsh 2012-10-24 解析信息类对账明细
//i: 节点索引
void CRecvBeps721::GetChckMsg(int i)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps721::GetChckMsg");
#define GETMSGDTL721(BEPS721MEMBER, TAG721) m_cBeps721.BEPS721MEMBER = \
	m_cBeps721.GetValueFromCycle("ChckMsgDtls", TAG721, i);\
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, \
		"### m_cBeps721."#BEPS721MEMBER"=[%s]", m_cBeps721.BEPS721MEMBER.c_str())

	GETMSGDTL721(ChckMsgDtlsMT, "ChckMsgDtlsMT"); //报文类型
	GETMSGDTL721(ChckMsgDtlsSndTtlCnt, "ChckMsgDtlsSndTtlCnt");//往报总笔数
	GETMSGDTL721(ChckMsgDtlsRcvTtlCnt, "ChckMsgDtlsRcvTtlCnt");//来报总笔数
	GETMSGDTL721(ChckMsgDtlsRcvDt, "ChckMsgDtlsRcvDt"); //受理日期

	//循环加签
	m_cBeps721.getChckMsgDtls();

	m_iSTtlCnt = atoi(m_cBeps721.ChckMsgDtlsSndTtlCnt.c_str());
	m_dSTtlAmt = 0.0;
	m_iRTtlCnt = atoi(m_cBeps721.ChckMsgDtlsRcvTtlCnt.c_str());
	m_dRTtlAmt = 0.0;

	m_bIsPmt = false;

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps721::GetChckMsg");
}

//__wsh 2012-10-24 对账汇总明细入库
int CRecvBeps721::AddCheckCl(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps721::AddCheckCl");
	int iRet = -1;

	//查询本地汇总数据
	QueryLocalSum();

	m_chkcl.m_chckdt            = m_cBeps721.ChckDt; //对账日期
	m_chkcl.m_msgid             = m_cBeps721.MsgId; //报文标识号
	if(m_bIsPmt){
    	m_chkcl.m_txnetgdt      = m_cBeps721.TxNetgDt; //轧差日期
    	m_chkcl.m_txnetgrnd     = m_cBeps721.TxNetgRnd; //轧差场次
    	m_chkcl.m_packprcsts    = m_cBeps721.ChckPmtInfDtlsPrcSts; //业务处理状态
    }
    else{
        m_chkcl.m_txnetgdt      = m_cBeps721.ChckMsgDtlsRcvDt; //轧差日期
    	m_chkcl.m_txnetgrnd     = "0"; //轧差场次
    	m_chkcl.m_packprcsts    = "PR00"; //业务处理状态 721信息类没有处理状态，这里给个默认值
    }
	m_chkcl.m_msgtype           = m_strMT; //报文类型
	m_chkcl.m_instddrctpty      = m_cBeps721.InstdDrctPty; //接收直接参与机构
	m_chkcl.m_workdate          = m_strWorkDate; //工作日期
	m_chkcl.m_remark            = m_cBeps721.Rmk; //备注

	m_chkcl.m_orgnlmsgid        = m_cBeps721.OrgnlMsgId; //原对账申请报文标识号
	m_chkcl.m_orgnlinstgdrctpty = m_cBeps721.OrgnlInstgPty; //原对账申请报文发起参与机构号
	m_chkcl.m_orgnlmsgtp        = m_cBeps721.OrgnlMT; //原对账申请报文报文类型

	m_chkcl.m_sndttlcnt         = m_iSTtlCnt; //发起总笔数
	m_chkcl.m_sndttlamt         = m_dSTtlAmt; //发起总金额
	m_chkcl.m_sndttlamtccy      = ""; //发起币种

	m_chkcl.m_rcvttlcnt         = m_iRTtlCnt; //接收总笔数
	m_chkcl.m_rcvttlamt         = m_dRTtlAmt; //接收总金额
	m_chkcl.m_rcvttlamtccy      = ""; //接收币种

	m_chkcl.m_lsndttlcnt        = m_iLocalSTtlCnt; //本地发起总笔数
	m_chkcl.m_lsndttlamt        = m_dLocalSTtlAmt; //本地发起总金额
	m_chkcl.m_lsndttlamtccy     = ""; //本地发起币种

	m_chkcl.m_lrcvttlcnt        = m_iLocalRTtlCnt; //本地接收总笔数
	m_chkcl.m_lrcvttlamt        = m_dLocalRTtlAmt; //本地接收总金额
	m_chkcl.m_lrcvttlamtccy     = ""; //本地接收币种

	m_chkcl.m_checkstate        = m_strChkSt; //与NPC汇总核对状态
	m_chkcl.m_procstate         = "18"; //处理状态:18已处理
	m_chkcl.m_printno           = 0; //打印次数

	iRet = m_chkcl.insert();
	if(iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[bp_checkcl]插入出错：%s", m_chkcl.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}
	m_chkcl.commit();

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps721::AddCheckCl");

	return iRet;
}

//__wsh 2012-10-24 查询本地汇总数据
int CRecvBeps721::QueryLocalSum(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps721::QueryLocalSum");

	int iRet = -1;
	m_iLocalSTtlCnt = 0;
	m_iLocalRTtlCnt = 0;
	m_dLocalSTtlAmt = 0.0;
	m_dLocalRTtlAmt = 0.0;
	m_strChkSt = "";
	m_strBizChkSt = "";

    //根据报文类型转换成对应的业务表
	ToBizTable();

	if(strcmp(m_szSTblNm, "BP_BCOUTSNDCL") == 0 ||
	   strcmp(m_szSTblNm, "BP_BDSNDCL") == 0){
		iRet = DoSumCrdtDebt();
	}
	else if(strcmp(m_szSTblNm, "BP_COLLTNCHRGSCL") == 0){
		iRet = DoSumColl(SR_SND);
		iRet = DoSumColl(SR_RCV);
	}
	else if(strcmp(m_szSTblNm, "CM_TRANSINFOQRY") == 0){
		iRet = DoSumTiq(SR_SND);
		iRet = DoSumTiq(SR_RCV);
	}
	
	//信息类报文不用比较金额，需要把往来金额清零
	if(!m_bIsPmt){
	    m_dLocalSTtlAmt = 0.0;
	    m_dLocalRTtlAmt = 0.0;
	}
    
    //比较本地业务与人行业务得出对账状态
	DoCompare();

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps721::QueryLocalSum");

	return iRet;
}

//__wsh 2012-10-24 获取汇总数据sql
void CRecvBeps721::GetSql(string& strSql, LPCSTR SR)
{
	strSql.clear();
	char szSql[2000] = {0};
	int inetgrnd = 0;
	
	inetgrnd = atoi(m_cBeps721.TxNetgRnd.c_str());
	//if(strcmp(m_cBeps721.TxNetgRnd.c_str(), "0") == 0)
	//{
	//      m_cBeps721.TxNetgRnd = "00";
	//}
	
	if(m_bIsPmt)
	{//清算轧差类
	    if(strcmp(SR, SR_SND) == 0)
	    {
			sprintf(szSql,"msgtp='%s' and instgdrctpty='%s' and finalstatedate in ('%s','%s') "
				          "and netgdt='%s' and to_number(netgrnd) = %d and busistate='%s'",
				          m_strMT.c_str(),
				          m_cBeps721.InstdDrctPty.c_str(),
				          m_cBeps721.ChckDt.c_str(),
				          m_cBeps721.TxNetgDt.c_str(),
				          m_cBeps721.TxNetgDt.c_str(),
				          //m_cBeps721.TxNetgRnd.c_str(),
				          inetgrnd,
				          m_cBeps721.ChckPmtInfDtlsPrcSts.c_str());
		}
		else
		{
			sprintf(szSql,"msgtp='%s' and instddrctpty='%s' and finalstatedate in ('%s','%s') "
				          "and netgdt='%s' and to_number(netgrnd) = %d and busistate='%s'",
				          m_strMT.c_str(),
				          m_cBeps721.InstdDrctPty.c_str(),
				          m_cBeps721.ChckDt.c_str(),
				          m_cBeps721.TxNetgDt.c_str(),
				          m_cBeps721.TxNetgDt.c_str(),
				          //m_cBeps721.TxNetgRnd.c_str(),
				          inetgrnd,
				          m_cBeps721.ChckPmtInfDtlsPrcSts.c_str());
		}

	}
	else
	{//信息类, 报文中没有业务状态， 只匹配终态日期是否为受理日期
		strSql.append(" msgtp='").append(m_strMT);
		strcmp(SR, SR_SND) == 0 ? strSql.append("' and instgdrctpty='")
				: strSql.append("' and instddrctpty='");
		strSql.append(m_cBeps721.InstdDrctPty);
		if(strcmp(m_szSTblNm, "CM_TRANSINFOQRY") == 0)
		{
		    //查询查复先匹配终态日期, 参与对账状态PR00, PR09  匹配PR09时处理状态不为14 911丢弃不参与对账 __wsh 2013-01-17
		    //PR05为收到来报入库时的业务状态，因此条件中带有PR05
		    if(strcmp(SR, SR_SND) == 0)
		    {
				sprintf(szSql,"msgtp='%s' and instgdrctpty='%s' and finalstatedate ='%s' "
					          "and sysid='BEPS' and procstate<>'14' and busistate in('PR00', 'PR05', 'PR09')"
					          " and rsflag < '2'",
					          m_strMT.c_str(),
					          m_cBeps721.InstdDrctPty.c_str(),
					          m_cBeps721.ChckMsgDtlsRcvDt.c_str());
			}
			else
			{
				sprintf(szSql,"msgtp='%s' and instddrctpty='%s' and finalstatedate ='%s' "
					          "and sysid='BEPS' and procstate<>'14' and busistate in('PR00', 'PR05', 'PR09')"
					          " and rsflag='2' ",
					          m_strMT.c_str(),
					          m_cBeps721.InstdDrctPty.c_str(),
					          m_cBeps721.ChckMsgDtlsRcvDt.c_str());
			}

			
		}
		else
		{
			
		    if(strcmp(SR, SR_SND) == 0)
		    {
				sprintf(szSql,"msgtp='%s' and instgdrctpty='%s' and finalstatedate ='%s' "
					          "and busistate in('PR00', 'PR05', 'PR08', 'PR09', 'PR21', 'PR22', 'PR32')",
					          m_strMT.c_str(),
					          m_cBeps721.InstdDrctPty.c_str(),
					          m_cBeps721.ChckMsgDtlsRcvDt.c_str());
			}
			else
			{
				sprintf(szSql,"msgtp='%s' and instddrctpty='%s' and finalstatedate ='%s' "
					          "and busistate in('PR00', 'PR05', 'PR08', 'PR09', 'PR21', 'PR22', 'PR32')",
					          m_strMT.c_str(),
					          m_cBeps721.InstdDrctPty.c_str(),
					          m_cBeps721.ChckMsgDtlsRcvDt.c_str());
			}			
    	}	
	}

	strSql = szSql;

	if(strcmp(m_szSTblNm, "BP_COLLTNCHRGSCL") == 0)
	{//代收付
		strSql += strcmp(SR, SR_SND) == 0 ?
				" and srcflag='1'" : " and srcflag > '1' ";
	}

	strcmp(SR, SR_SND) == 0 ? m_strSSql = strSql.c_str() :
			m_strRSql = strSql.c_str();

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strSql=[%s]",strSql.c_str());
}

//__wsh 2012-10-24 汇总本借记及贷记业务

int CRecvBeps721::DoSumCrdtDebt(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps721::DoSumCrdtDebt");

	int iRet = -1;
	string strSql = "";

	if(strcmp(m_szSTblNm, "BP_BCOUTSNDCL") == 0)
	{
		GetSql(strSql, SR_SND);		

		CBpbcoutsndcl oCBpbcoutsndcl;
		SETCTX(oCBpbcoutsndcl);
		iRet = oCBpbcoutsndcl.find(strSql); 
		if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND )
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL, 
				"[%s]查询失败:%s", m_szSTblNm, oCBpbcoutsndcl.GetSqlErr());
		}
		while((iRet = oCBpbcoutsndcl.fetch()) == SQL_SUCCESS)
		{
			++m_iLocalSTtlCnt; 
			//m_dLocalSTtlAmt += oCBpbcoutsndcl.m_ctrlsum;
			m_dLocalSTtlAmt += oCBpbcoutsndcl.m_ctrlsuccsum;
		}
		oCBpbcoutsndcl.closeCursor();
		if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND )
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL, 
				"[%s]查询失败:%s", m_szSTblNm, oCBpbcoutsndcl.GetSqlErr());
				PMTS_ThrowException(DB_FIND_FAIL);
		}	
		
		GetSql(strSql, SR_RCV);
		
		CBpbcoutrcvcl oCBpbcoutrcvcl;
		SETCTX(oCBpbcoutrcvcl);
		iRet = oCBpbcoutrcvcl.find(strSql); 
		if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND )
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL, 
				"[%s]查询失败:%s", m_szRTblNm, oCBpbcoutrcvcl.GetSqlErr());
		}
		while((iRet = oCBpbcoutrcvcl.fetch()) == SQL_SUCCESS)
		{
			++m_iLocalRTtlCnt; 
			//m_dLocalRTtlAmt += oCBpbcoutrcvcl.m_ctrlsum;
			m_dLocalRTtlAmt += oCBpbcoutrcvcl.m_ctrlsuccsum;
			
		}
		
		oCBpbcoutrcvcl.closeCursor();
		
		if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND )
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL, 
				"[%s]查询失败:%s", m_szRTblNm, oCBpbcoutrcvcl.GetSqlErr());
				PMTS_ThrowException(DB_FIND_FAIL);
		}			
	}
	else if(strcmp(m_szSTblNm, "BP_BDSNDCL") == 0)
	{
		GetSql(strSql, SR_SND);
		
		CBpbdsndcl oCBpbdsndcl;
		SETCTX(oCBpbdsndcl);
		iRet = oCBpbdsndcl.find(strSql); 
		if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND )
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL, 
				"[%s]查询失败:%s", m_szSTblNm, oCBpbdsndcl.GetSqlErr());
		}
		while((iRet = oCBpbdsndcl.fetch()) == SQL_SUCCESS)
		{
			++m_iLocalSTtlCnt; 
			m_dLocalSTtlAmt += oCBpbdsndcl.m_ctrlsum;
		}
		oCBpbdsndcl.closeCursor();	
		if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND )
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL, 
				"[%s]查询失败:%s", m_szSTblNm, oCBpbdsndcl.GetSqlErr());
				PMTS_ThrowException(DB_FIND_FAIL);
		}	
		
		GetSql(strSql, SR_RCV);
		
		CBpbdrcvcl oCBpbdrcvcl;
		SETCTX(oCBpbdrcvcl);
		iRet = oCBpbdrcvcl.find(strSql); 
		if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND )
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL, 
				"[%s]查询失败:%s", m_szRTblNm, oCBpbdrcvcl.GetSqlErr());
		}
		while((iRet = oCBpbdrcvcl.fetch()) == SQL_SUCCESS)
		{

				++m_iLocalRTtlCnt; 
				m_dLocalRTtlAmt += oCBpbdrcvcl.m_ctrlsum;
		}
		
		oCBpbdrcvcl.closeCursor();	
		if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND )
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL, 
				"[%s]查询失败:%s", m_szRTblNm, oCBpbdrcvcl.GetSqlErr());
				PMTS_ThrowException(DB_FIND_FAIL);
		}			
	}

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps721::DoSumCrdtDebt");

	return iRet;
}

//__wsh 2012-10-24 汇总代收付类报文
int CRecvBeps721::DoSumColl(LPCSTR SR)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps721::DoSumColl");

	int iRet = -1;


	CBpcolltnchrgscl coll;
	SETCTX(coll);
	string strSql = "";
	GetSql(strSql, SR);
	if(m_bIsPmt){//清算轧差类
		iRet = coll.find(strSql);
		if(iRet == SQL_SUCCESS){
			while((iRet = coll.fetch()) == SQL_SUCCESS){
				if(strcmp(SR, SR_SND) == 0){//往报
					++m_iLocalSTtlCnt;
					m_dLocalSTtlAmt += coll.m_rcvsndgttlamt;
				}
				else{//来报
					++m_iLocalRTtlCnt;
					m_dLocalRTtlAmt += coll.m_rcvsndgttlamt;
				}
			}
		}
	}
	else{//信息类
		iRet = coll.findcount(strSql);
		if(iRet == SQL_SUCCESS){
			strcmp(SR, SR_SND) == 0 ? m_iLocalSTtlCnt = coll.m_iCount :
					m_iLocalRTtlCnt = coll.m_iCount;

		}
	}

	if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND ){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
			"[%s]查询失败:%s", m_szSTblNm, coll.GetSqlErr());
		PMTS_ThrowException(DB_FIND_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps721::DoSumColl");

	return iRet;
}

//__wsh 2012-10-24 汇总查询查复业务
int CRecvBeps721::DoSumTiq(LPCSTR SR)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps721::DoSumTiq");
	int iRet = -1;

	CCmtransinfoqry tiq;
	SETCTX(tiq);
	string strSql = "";
	GetSql(strSql, SR);
	iRet = tiq.findcount(strSql);
	if(iRet == SQL_SUCCESS){
		if(strcmp(SR, SR_SND) == 0){//往报
			m_iLocalSTtlCnt = tiq.m_iCount;
		}
		else{//来报
			m_iLocalRTtlCnt = tiq.m_iCount;
		}
	}

	if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND ){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
			"[%s]查询失败:%s", m_szSTblNm, tiq.GetSqlErr());
		PMTS_ThrowException(DB_FIND_FAIL);
	}
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps721::DoSumTiq");

	return iRet;
}

//__wsh 2012-10-24 根据报文类型查询往来报存储表
int CRecvBeps721::ToBizTable(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps721::ToBizTable");

	memset(m_szSTblNm, 0x00, sizeof(m_szSTblNm));
	memset(m_szRTblNm, 0x00, sizeof(m_szRTblNm));
	m_strMT = m_bIsPmt ? m_cBeps721.ChckPmtInfDtlsMT.c_str()
			: m_cBeps721.ChckMsgDtlsMT.c_str();

#define EQUALMT721(MT) strcmp(m_strMT.c_str(), MT) == 0
#define LIKEMT721(MT)  strstr(m_strMT.c_str(), MT) != NULL
#define SET_STBL721(STBL) snprintf(m_szSTblNm, sizeof(m_szSTblNm), STBL)
#define SET_RTBL721(STBL) snprintf(m_szRTblNm, sizeof(m_szRTblNm), STBL)

	if(EQUALMT721("PKG001") || EQUALMT721("PKG003")  || EQUALMT721("PKG005") ||
	   EQUALMT721("PKG007") || EQUALMT721("PKG008")  || EQUALMT721("PKG010") ||
	   EQUALMT721("PKG011") || LIKEMT721("beps.121") || LIKEMT721("beps.122") ||
	   LIKEMT721("beps.123")|| LIKEMT721("beps.125") || LIKEMT721("beps.128") ||
	   LIKEMT721("beps.130")|| LIKEMT721("beps.132") || LIKEMT721("beps.134")){
		//贷记
		SET_STBL721("BP_BCOUTSNDCL");
		SET_RTBL721("BP_BCOUTRCVCL");
		snprintf(m_szSLsTblNm, sizeof(m_szSLsTblNm), "BP_BCOUTSENDLIST");
		snprintf(m_szRLsTblNm, sizeof(m_szRLsTblNm), "BP_BCOUTRECVLIST");
	}
	else if(EQUALMT721("PKG002") || EQUALMT721("PKG004") || EQUALMT721("PKG006") ||
			EQUALMT721("PKG009") || LIKEMT721("beps.124") || LIKEMT721("beps.127") ||
			LIKEMT721("beps.131")|| LIKEMT721("beps.133")){
		//借记
		SET_STBL721("BP_BDSNDCL");
		SET_RTBL721("BP_BDRCVCL");
		snprintf(m_szSLsTblNm, sizeof(m_szSLsTblNm), "BP_BDSENDLIST");
		snprintf(m_szRLsTblNm, sizeof(m_szRLsTblNm), "BP_BDRECVLIST");
	}
	else if(EQUALMT721("PKG012")  || LIKEMT721("beps.380") || LIKEMT721("beps.381") ||
			LIKEMT721("beps.382") || LIKEMT721("beps.383") || LIKEMT721("beps.384")||
			LIKEMT721("beps.385") || LIKEMT721("beps.386") || LIKEMT721("beps.387")){
		//代收付
		SET_STBL721("BP_COLLTNCHRGSCL");
		SET_RTBL721("BP_COLLTNCHRGSCL");
	}
	else if(EQUALMT721("CMT301")  || EQUALMT721("CMT302") ||
			LIKEMT721("ccms.314") || LIKEMT721("ccms.315")){
		//查询查复
		SET_STBL721("CM_TRANSINFOQRY");
		SET_RTBL721("CM_TRANSINFOQRY");
	}
	else{
		return RTN_FAIL;
	}

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps721::ToBizTable");

	return RTN_SUCCESS;
}

//__wsh 2012-10-24 比较本地业务与人行业务
void CRecvBeps721::DoCompare(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			    NULL, "Enter CRecvBeps721::DoCompare");

	Trace(L_DEBUG, __FILE__, __LINE__, NULL,
	    "人行往报笔数:[%d] 金额:[%.2f], 本地往报笔数:[%d] 金额:[%.2f]"
			, m_iSTtlCnt, m_dSTtlAmt, m_iLocalSTtlCnt,  m_dLocalSTtlAmt);
	       
	Trace(L_DEBUG, __FILE__, __LINE__, NULL,
	    "人行来报笔数:[%d] 金额:[%.2f], 本地来报笔数:[%d] 金额:[%.2f]"
			, m_iRTtlCnt, m_dRTtlAmt, m_iLocalRTtlCnt, m_dLocalRTtlAmt);

	if( (m_iSTtlCnt == m_iLocalSTtlCnt) && AmtEqual(m_dSTtlAmt, m_dLocalSTtlAmt) &&
	    (m_iRTtlCnt == m_iLocalRTtlCnt) && AmtEqual(m_dRTtlAmt, m_dLocalRTtlAmt) ){//对账相符

	    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "对账相符");

		m_strChkSt = PR_CNCH_01;

		if(m_iLocalSTtlCnt > 0){/*更新往报*/
			UpdateBizChkState(SR_SND, PR_CNCH_01);
		}

		if(m_iLocalRTtlCnt > 0){/*更新来报*/
			UpdateBizChkState(SR_RCV, PR_CNCH_01);
		}
	}
	else{//对账不符
		m_strChkSt = PR_CNCH_02;
		//往报不符
		if(m_iSTtlCnt != m_iLocalSTtlCnt || !AmtEqual(m_dSTtlAmt, m_dLocalSTtlAmt) ){
		    Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
		        "往报不相符[NPC(%d, %f) Local(%d, %f)]",
		        m_iSTtlCnt, m_dSTtlAmt, m_iLocalSTtlCnt, m_dLocalSTtlAmt);
			//人行笔数大于0申请明细对账
			if(m_iSTtlCnt > 0){
			    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "需申请明细");
				m_bIsPmt ? AddDtlChckPmt722(SR_SND) : AddDtlChckMsg722(SR_SND);
				UpdateBizChkState(SR_SND, PR_CNCH_05);
			}
			else{
			    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "本地多");
				//人行笔数等于0更明细为本地多
				if(m_iLocalSTtlCnt > 0){
    				UpdateBizChkState(SR_SND, PR_CNCH_05);
    				//++m_iLocalMore;
    				//往报没有，以人行为准
    				m_strChkSt = PR_CNCH_01;
    			}
			}
		}
		//来报不符
		if( (m_iRTtlCnt != m_iLocalRTtlCnt) || (m_dRTtlAmt != m_dLocalRTtlAmt) ){
		    if(m_iRTtlCnt != m_iLocalRTtlCnt || !AmtEqual(m_dRTtlAmt, m_dLocalRTtlAmt)){
		        Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
    		        "来报不相符[NPC(%d, %.2f) Local(%d, %.2f)]",
    		        m_iRTtlCnt, m_dRTtlAmt, m_iLocalRTtlCnt, m_dLocalRTtlAmt);
		    }
		    
			if(m_iRTtlCnt > 0){
			    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "需申请明细");
				//人行笔数大于0， 申请对账明细
				m_bIsPmt ? AddDtlChckPmt722(SR_RCV) : AddDtlChckMsg722(SR_RCV);
				UpdateBizChkState(SR_RCV, PR_CNCH_05);
			}
			else{
				//人行笔数等于0更明细为本地多
				if(m_iLocalRTtlCnt > 0){
				    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "本地多");
    				UpdateBizChkState(SR_RCV, PR_CNCH_05);
    				++m_iLocalMore;
    			}
			}
		}
	}

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps721::DoCompare");
}

//__wsh 2012-10-24 更新业务对账状态
int CRecvBeps721::UpdateBizChkState(LPCSTR szSR, LPCSTR szChkSt)
{
	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Enter CRecvBeps721::UpdateBizChkState");
	int iRet = -1;

	char szSql[512] = {0};
	char szSqlLs[512] = {0};
	bool bUpdateList  = false;

	if( strcmp(szSR, SR_SND) == 0){/*更新往报对账状态*/
		/*一代报文收人行920拒纳时有的为丢弃不参与对账,此处清空终态日期, 以使723明细对账判断该笔报文是否参与对账,是则重填*/
		const char* tmp = (strstr(szChkSt, PR_CNCH_05) != NULL) ? ", finalstatedate='' " : "";
		snprintf(szSql, sizeof(szSql),
			"update %s set checkstate='%s'  %s where %s",
			m_szSTblNm, szChkSt, tmp, m_strSSql.c_str());
		/*借贷记更新明细表*/
		if (strstr(m_szSTblNm, "BP_BCOUTSNDCL") != NULL
				|| strstr(m_szSTblNm, "BP_BDSNDCL") != NULL){
			bUpdateList = true;
			snprintf(szSqlLs, sizeof(szSqlLs),
				"update %s set checkstate='%s'  %s where %s",
				m_szSLsTblNm, szChkSt, tmp, m_strSSql.c_str());
		}
	}
	else{/*更新来报对账状态*/
		snprintf(szSql, sizeof(szSql),
			"update %s set checkstate='%s'  where %s",
			m_szRTblNm, szChkSt, m_strRSql.c_str());
		/*借贷记更新明细表*/
		if (strstr(m_szSTblNm, "BP_BCOUTSNDCL") != NULL
				|| strstr(m_szSTblNm, "BP_BDSNDCL") != NULL){
			bUpdateList = true;
			snprintf(szSqlLs, sizeof(szSqlLs),
				"update %s set checkstate='%s'  where %s",
				m_szRLsTblNm, szChkSt, m_strRSql.c_str());
		}
	}

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__szSql=[%s]", szSql);

	iRet = m_chkcl.execsql(szSql);
	if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND){
		Trace(L_ERROR, __FILE__, __LINE__,
				NULL, "更新出错:%s", m_chkcl.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__SQL RET:[%d]", iRet);

	if (bUpdateList){/*借贷记更新明细表*/
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__szSqlLs=[%s]", szSqlLs);
		iRet = m_chkcl.execsql(szSqlLs);
		if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND){
			Trace(L_ERROR, __FILE__, __LINE__,
					NULL, "更新出错:%s", m_chkcl.GetSqlErr());
			PMTS_ThrowException(DB_UPDATE_FAIL);
		}
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__SQL RET:[%d]", iRet);
	}
	m_chkcl.commit();

	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Leave CRecvBeps721::UpdateBizChkState");
	return iRet;
}

//__wsh 2012-10-24 更新对账状表对状态
int CRecvBeps721::UpdateBChkState(LPCSTR szChkSt)
{
	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Enter CRecvBeps721::UpdateBChkState");
	int iRet = -1;

	char szSql[512] = {0};
	snprintf(szSql, sizeof(szSql), "update bp_bchkstate "
			"set checkstate='%s', statetime=sysdate "
			"where chkdate='%s' and pkbknode='%s' ", szChkSt,
			m_cBeps721.ChckDt.c_str(), m_cBeps721.InstdDrctPty.c_str());

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__szSql=[%s]", szSql);

	iRet = m_bchkst.execsql(szSql);
	if(iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__,
				NULL, "[bp_bchkstate]更新出错:%s", m_bchkst.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Leave CRecvBeps721::UpdateBChkState");

	return iRet;
}

//__wsh 2012-10-24 添加722业务报文申请节点
void CRecvBeps721::AddDtlChckPmt722(LPCSTR szSR)
{
	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Enter CRecvBeps721::AddDtlChckPmt722");

	m_cBeps722.AddNodeToSubcycle("DtlChckPmtDtlsSndRcvTp", szSR);

	m_cBeps722.AddNodeToSubcycle("TxNetgDt",
					m_cBeps721.TxNetgDt.c_str());

	m_cBeps722.AddNodeToSubcycle("TxNetgRnd",
					m_cBeps721.TxNetgRnd.c_str());

	m_cBeps722.AddNodeToSubcycle("DtlChckPmtDtlsMT",
					m_cBeps721.ChckPmtInfDtlsMT.c_str());

	m_cBeps722.AddNodeToSubcycle("DtlChckPmtDtlsPrcSts",
					m_cBeps721.ChckPmtInfDtlsPrcSts.c_str());

	m_cBeps722.AddSubcycleToNode("DtlChckPmtDtls");

	++m_iPmtCnt722;

	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Leave CRecvBeps721::AddDtlChckPmt722");
}

//__wsh 2012-10-24 添加722信息报文申请节点
void CRecvBeps721::AddDtlChckMsg722(LPCSTR szSR)
{
	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Enter CRecvBeps721::AddDtlChckMsg722");

	m_cBeps722.AddNodeToSubcycle("DtlChckMsgDtlsSndRcvTp", szSR);

	m_cBeps722.AddNodeToSubcycle("DtlChckMsgDtlsMT",
					m_cBeps721.ChckMsgDtlsMT.c_str());

	m_cBeps722.AddNodeToSubcycle("DtlChckMsgDtlsRcvDt",
					m_cBeps721.ChckMsgDtlsRcvDt.c_str());

	m_cBeps722.AddSubcycleToNode("DtlChckMsgDtls");

	++m_iMsgCnt722;

	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Leave CRecvBeps721::AddDtlChckMsg722");
}

//__wsh 2012-10-24 向人行发送722申请明细对账
int CRecvBeps721::RequestCheckList722(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Leave CRecvBeps721::RequestCheckList722");
	int iRet = -1;

	//获取报文创建日期时间
	char szISoDt[64] = {0};
	iRet = GetIsoDateTime(m_dbproc, SYS_BEPS, szISoDt);
	if(iRet != RTN_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__,
					NULL, "获取报文创建日期时间失败！");
		PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
	}

	//获取报文标识
	char szMsgId[32] = {0};
	if(!GetMsgIdValue(m_dbproc, szMsgId,
			eMsgId, SYS_BEPS, m_cBeps721.InstdDrctPty.c_str())){
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "获取报文标识失败!");
		PMTS_ThrowException(OPT_GET_MESGREFID_FAIL);
	}

	//业务头
	m_cBeps722.MsgId            = szMsgId;
	m_cBeps722.CreDtTm          = szISoDt;
	m_cBeps722.InstgDrctPty     = m_cBeps721.InstdDrctPty;
	m_cBeps722.GrpHdrInstgPty   = m_cBeps721.InstdDrctPty;
	m_cBeps722.InstdDrctPty     = m_cBeps721.InstgDrctPty;
	m_cBeps722.GrpHdrInstdPty   = m_cBeps721.InstgDrctPty;
	m_cBeps722.SysCd            = "BEPS";
	m_cBeps722.Rmk              = "";
	m_cBeps722.ChckDt           = m_cBeps721.ChckDt;

	char szCnt[16] = {0};
	snprintf(szCnt, sizeof(szCnt), "%d", m_iPmtCnt722);
	m_cBeps722.DtlChckPmtInfNbOfTxs = szCnt;
	snprintf(szCnt, sizeof(szCnt), "%d", m_iMsgCnt722);
	m_cBeps722.DtlChckMsgNbOfTxs = szCnt;
	//获取通信参与号
	char szRefId[64] = {0};
	if( !GetMsgIdValue(m_dbproc, szRefId, eRefId, SYS_BEPS) ){
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "获取通信参与号出错!");
		PMTS_ThrowException(PRM_FAIL);
	}

	//创建消息头
	m_cBeps722.CreateXMlHeader(
				"BEPS",
				m_sWorkDate,
				m_cBeps721.InstdDrctPty.c_str(),
				m_cBeps721.InstgDrctPty.c_str(),
				"beps.722.001.01",
				szRefId);

	//创建XML报文
	iRet = m_cBeps722.CreateXml();
	if(RTN_SUCCESS != iRet){
		Trace(L_ERROR,  __FILE__,  __LINE__,
				NULL, "创建报文失败,iRet=%d", iRet);
		PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
	}

	m_checkqry.m_msgid = m_cBeps722.MsgId;
	m_checkqry.m_msgtype = "beps.722.001.01";
	m_checkqry.m_sapbank = m_cBeps722.InstgDrctPty;
	m_checkqry.m_checkdate = m_cBeps722.ChckDt;
	
	SETCTX(m_checkqry);
	iRet = m_checkqry.insert();
	if( 0 != iRet)
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "INSERT CM_CHECKQRY FILED[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "INSERT CM_CHECKQRY FILED!");
	}


	iRet = AddQueue(m_cBeps722.m_sXMLBuff, m_cBeps722.m_sXMLBuff.length());

	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Leave CRecvBeps721::RequestCheckList722");

	return iRet;
}

//__wsh 2012-10-24 对账
int CRecvBeps721::DoCheck(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Enter CRecvBeps721::DoCheck");
	int iRet = -1;

	if(m_iLocalMore > 0 || m_iPmtCnt722 > 0 || m_iMsgCnt722 > 0){
		//对账不符
		iRet = UpdateBChkState(PR_CNCH_22);
		//向人行申请对账明细
		if(m_iPmtCnt722 > 0 || m_iMsgCnt722 > 0){
			iRet = RequestCheckList722();
		}
	}
	else{
		//对账相符
		iRet = UpdateBChkState(PR_CNCH_21);
		
		//触发行内对账
		//iRet = CallMbCheck();
	}

	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Leave CRecvBeps721::DoCheck");
	return iRet;
}

//__wsh 2012-10-24 触发行内对账
int CRecvBeps721::CallMbCheck(void)
{
    Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Enter CRecvBeps721::CallMbCheck");
    int iRet = -1;
    
    //日期需要转换成yyyymmdd格式
	char szChkDt[16] = {0};
	chgToDate(m_cBeps721.ChckDt.c_str(), szChkDt);

	//新增行内对账记录, 已经改到日切程序里执行
	CSysmbchkst mcs;
	SETCTX(mcs);
	mcs.m_checkdate = szChkDt; //对账日期
	mcs.m_sapbank   = m_cBeps721.InstdDrctPty; //对账清算行
	mcs.m_sysflag   = "1"; //小额标志
	mcs.m_checkstate= "00"; //对账状态, 初始态
	mcs.m_handflag  = "0"; //是否手工发起, 否
	const char* szSr[2] = {"0", "1"}; //往来标识
	for(int j = 0; j < 2; ++j){
		mcs.m_srflag = szSr[j];
		iRet = mcs.insert();
		if(iRet != SQL_SUCCESS && iRet != DUPLICATE_KEY){
			Trace(L_ERROR, __FILE__, __LINE__, NULL,
					"[sys_mbchkst]插入失败:%s", mcs.GetSqlErr());
			PMTS_ThrowException(DB_INSERT_FAIL);
		}
	}
	mcs.commit();

    CSyscomsendmb csm;
	SETCTX(csm);
	csm.m_workdate    = m_strWorkDate;    //工作日期
	csm.m_msgid       = m_cBeps721.MsgId; //报文标识
	csm.m_refnumber   = ""; //行内22位参考号
	csm.m_sendbank    = m_cBeps721.InstdDrctPty; //发送行
	csm.m_recvbank    = m_cBeps721.InstdDrctPty; //接收行
	csm.m_recvsapbank = m_cBeps721.InstdDrctPty; //接收清算行
	csm.m_msgtype     = "beps.995.001.01"; //报文类型
	csm.m_sysflag     = "BEPS"; //系统标识
	csm.m_procstate   = "01"; //处理状态
	csm.m_proctimes   = 0; //处理次数
	csm.m_recvtarget  = "0";

	char szSql[128] = {0};
	snprintf(szSql, sizeof(szSql),
			"sapbank='%s' and checkstate='00' and sysflag='1' "
			" and handflag='0' and srflag='0' order by checkstate asc",
			m_cBeps721.InstdDrctPty.c_str());
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__szSql[%s]", szSql);

	CSysmbchkst mcsts;
	SETCTX(mcsts);
	iRet = mcsts.find(szSql);
	if (iRet == SQL_SUCCESS){
		while (true){
			iRet = mcsts.fetch();
			if (iRet != SQL_SUCCESS){
				if (iRet == SQLNOTFOUND){
					Trace(L_DEBUG, __FILE__, __LINE__,
							NULL, "__No MOre Data!!!");
					break;
				}
				else{
					Trace(L_ERROR, __FILE__, __LINE__, NULL,
							"[sys_mbchkst] fetch error[%s]", mcsts.GetSqlErr());
					mcsts.closeCursor();
					PMTS_ThrowException(DB_FIND_FAIL);
				}
			}
			Trim(mcsts.m_checkdate);

			char szReq[128] = {0};
			snprintf(szReq, sizeof(szReq), "%-14s%8s0%42s00",
					m_cBeps721.InstdDrctPty.c_str(), mcsts.m_checkdate.c_str(), " ");
			csm.m_npcmsg = szReq; //请求消息

			const char* szSys[4] = {"IBC", "REM", "TSS", "BEM"};
			for (int i = 0; i < 4; ++i){
				csm.m_targetsys = szSys[i]; //目标系统
				iRet = csm.insert();
				if(iRet != SQL_SUCCESS){
					Trace(L_ERROR, __FILE__, __LINE__, NULL,
							"[sys_comsendmb]插入失败:%s", csm.GetSqlErr());
					PMTS_ThrowException(DB_INSERT_FAIL);
				}

				Trace(L_DEBUG, __FILE__, __LINE__, NULL, "新增行内对账请求[%s][%s][%s]",
						m_cBeps721.InstdDrctPty.c_str(), szSys[i], mcsts.m_checkdate.c_str());
			}

			char szChkISODt[32] = {0};
			chgToISODate(mcsts.m_checkdate.c_str(), szChkISODt);
			//初始化业务表对账状态
			m_chkhelper.InitBizMbCheckState(
					m_cBeps721.InstdDrctPty, szChkISODt);
		}// end while
		mcsts.closeCursor();
	}
	else{
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[sys_mbchkst] fetch error[%s]", mcsts.GetSqlErr());
		PMTS_ThrowException(DB_FIND_FAIL);
	}

    Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Leave CRecvBeps721::CallMbCheck");
    return iRet;
}

//__wsh 2012-10-24 核签
void CRecvBeps721::ChkSign721(void)
{
    Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Enter CRecvBeps721::ChkSign721");

	m_cBeps721.getOriSignStr();

	CheckSign(
		m_cBeps721.m_sSignBuff.c_str(),
		m_cBeps721.m_szDigitSign.c_str(),
		m_cBeps721.InstgDrctPty.c_str());

					
	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Leave CRecvBeps721::ChkSign721");				
}

//__wsh 2012-10-24 比较金额
bool CRecvBeps721::AmtEqual(double dAmt1, double dAmt2)
{
    char szAmt1[32] = {0};
    char szAmt2[32] = {0};
    
    snprintf(szAmt1, sizeof(szAmt1), "%0.2f", dAmt1);
    snprintf(szAmt2, sizeof(szAmt2), "%0.2f", dAmt2);
    
    return strcmp(szAmt1, szAmt2) == 0 ? true : false;
}






















