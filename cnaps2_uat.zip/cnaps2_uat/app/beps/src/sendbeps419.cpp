/******************************************************************** 
�ļ����� sendbeps419.cpp
�����ˣ� aps-lel	
��  �ڣ� 2011-04-07
�޸��ˣ� 
��  �ڣ� 
��  ���� С������beps.419���Ĵ�����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps419.h"


CSendBeps419::CSendBeps419(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{

}

CSendBeps419::~CSendBeps419()
{

}

INT32 CSendBeps419::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CSendBeps419::doWorkSelf");
    
    /*��ҵ����л�ȡ����*/
    GetData();   
    
    /*��pmts����*/
    CreatePmtsMsg();
    
    /*�޸�״̬*/
    updateState();
    
    /*����Զ�̶���*/
    AddQueue();
    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "leave CSendBeps419::doWorkSelf..."); 
    return 0;
}


int CSendBeps419::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CSendBeps419::GetData...");
	
	SETCTX(m_cBpchckcdtforld);
	
  	m_cBpchckcdtforld.m_instgpty = m_sSendOrg;//���������
  	
  	m_cBpchckcdtforld.m_msgid = m_sMsgId;
  	
    m_cBpchckcdtforld.m_srcflag = "1";      
  	
  	iRet = m_cBpchckcdtforld.findByPK();
  	
 	
    if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg,"findByPK() error, error code = [%d],error cause = [%s]",iRet,m_cBpchckcdtforld.GetSqlErr());
		
		Trace(L_INFO,  __FILE__,  __LINE__,NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}
	
		
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "leave CSendBeps419::GetData..."); 
    
	return iRet;
}

int CSendBeps419::updateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps419::updateState...");

	SETCTX(m_cBpchckcdtforld);
    string strSQL;
	strSQL += "UPDATE BP_CHCKCDTFORLD  t SET t.PROCTIME = sysdate,t.PROCSTATE = '08', t.mesgid='";
	strSQL += m_sMsgRefId; 
	strSQL += "', t.mesgrefid = '";
	strSQL += m_sMsgRefId;
	strSQL += "' WHERE t.SRCFLAG = '1' and t.MSGID = '";
	strSQL += m_cBpchckcdtforld.m_msgid.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_cBpchckcdtforld.m_instgpty.c_str(); 
	strSQL += "'";	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	
	iRet = m_cBpchckcdtforld.execsql(strSQL.c_str());
		
    if(RTN_SUCCESS != iRet)
    {
		sprintf(m_sErrMsg,"execsql() error,error code = [%d],error cause = [%s] ",iRet,m_cBpchckcdtforld.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_sErrMsg);

    }

    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "leave CSendBeps419::updateState...");
    return 0;
}

void CSendBeps419::AddSign419()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms419::AddSign419");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_cBeps419.getOriSignStr();
	
	AddSign(m_cBeps419.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_cBpchckcdtforld.m_instgdrctpty.c_str());
	
	m_cBeps419.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms419::AddSign419");
}


int CSendBeps419::CreatePmtsMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CSendBeps419::CreatePmtsMsg...");
	char szTemp[25] = {0};

	bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(PRM_FAIL);
    }	


	m_cBeps419.CreateXMlHeader("BEPS", 
			m_sWorkDate,
			m_sSendOrg,
			m_cBpchckcdtforld.m_instddrctpty.c_str(),
			"beps.419.001.01",
			m_sMsgRefId);
			  				

	m_cBeps419.MsgId             = m_cBpchckcdtforld.m_msgid ;                //���ı�ʶ��	                                              
	m_cBeps419.CreDtTm           = m_sIsoWorkDate ;                           //���ķ���ʱ��                                                
	m_cBeps419.InstgDrctPty      = m_cBpchckcdtforld.m_instgdrctpty ;         //����ֱ�Ӳ������                                            
	m_cBeps419.GrpHdrInstgPty    = m_cBpchckcdtforld.m_instgpty ;             //����������                                                
	m_cBeps419.InstdDrctPty      = m_cBpchckcdtforld.m_instddrctpty ;         //����ֱ�Ӳ������                                            
	m_cBeps419.GrpHdrInstdPty    = m_cBpchckcdtforld.m_instdpty ;             //���ղ������                                                
	m_cBeps419.SysCd             = m_cBpchckcdtforld.m_syscd ;                //ϵͳ���                                                    
	m_cBeps419.Rmk               = m_cBpchckcdtforld.m_rmk ;                  //��ע                                                        
	m_cBeps419.OrgnlMsgId        = m_cBpchckcdtforld.m_orgnlmsgid;            //ԭ���ı�ʶ��                                                
	m_cBeps419.OrgnlInstgPty     = m_cBpchckcdtforld.m_orgnlinstgpty;         //ԭ����������                                              
	m_cBeps419.OrgnlMT           = m_cBpchckcdtforld.m_orgnlmt;               //ԭ��������                                                  
	m_cBeps419.Sts               = m_cBpchckcdtforld.m_status;                //ҵ��״̬
	m_cBeps419.RjctCd            = m_cBpchckcdtforld.m_rjctcd;                //ҵ��ܾ�������                                                  
	m_cBeps419.RjctInf           = m_cBpchckcdtforld.m_rjctinf;               //ҵ��ܾ���Ϣ                                                   
	m_cBeps419.PrcPty            = m_cBpchckcdtforld.m_rjcprcpty;             //ҵ�����������                                                 
                                         

	// ��ǩ
	AddSign419();
	
	int iRet = m_cBeps419.CreateXml();
	
	if (0 != iRet)
	{
		
		sprintf(m_sErrMsg,"�������˱���ʧ��iRet = [%d]! ",iRet);
		
		Trace(L_INFO,  __FILE__,  __LINE__,NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, m_sErrMsg);
	}
	
	
	m_sMsgTxt = m_cBeps419.m_sXMLBuff;
	
	
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "leave CSendBeps419::CreatePmtsMsg..."); 
    
	return iRet;
}

