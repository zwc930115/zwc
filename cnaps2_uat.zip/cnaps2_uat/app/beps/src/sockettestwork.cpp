/********************************************************************
文件名：sockettestwork.cpp
创建人：hq
日  期：2011-05-17
修改人：
日  期：
描  述：SOCKET测试WORK
版  本：
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sockettestwork.h"
#include "tsocket.h"
#include "bpbcoutsendlist.h"

using namespace ZFPT;

extern CConnectPool	*g_DBConnPool;

CSocketTestWork::CSocketTestWork()
{
    memset(m_sMsg, 0x00, sizeof(m_sMsg));
    
	m_nHostPort = 0;;
    m_szHostIp  = "";
    m_szTxId    = "";
    m_szMsgTp   = "";
}

CSocketTestWork::~CSocketTestWork()
{

}

void CSocketTestWork::clear()
{
	
}

int CSocketTestWork::doWork()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSocketTestWork::doWork..."); 

    // 获取数据库连接
	if(0 != g_DBConnPool->GetConnect(m_dbproc))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "GetConnect error");
        return -1;
    }
    
    // 插入数据库
    InsertDb();

    // 发送SOCKET
    SendtoHost();

    // 释放连接
    g_DBConnPool->PutConnect(m_dbproc);	
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Leave CSocketTestWork::doWork..."); 
    
    return RTN_SUCCESS;
}

void CSocketTestWork::setData(string sHostIp, string sTxId, string sMsgTp, int nHostPort)
{
    m_szHostIp  = sHostIp;
    
    m_szTxId    = sTxId;
    
    m_szMsgTp   = sMsgTp;	

    m_nHostPort = nHostPort;
}

int CSocketTestWork::InsertDb()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSocketTestWork::InsertDb..."); 
    
    
    CBpbcoutsendlist cBpBcSndList;

    char sMsgID[28 + 1] = {0};   //MsgID
	char sSqlStr[2048];		     //SQL语句
	STRING sHostRqt = "";
	int  iRet = -1;

    // 设置连接
	if (0 != cBpBcSndList.setctx(m_dbproc))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
        return -2;
    }

    // 获取MSGID
    memset(sMsgID, NULL_CHAR, sizeof(sMsgID));
	sHostRqt = "00000095beps3XML";
	sHostRqt += m_szMsgTp;
	
	// 获取MSGID
    if (!GetMsgIdValue(m_dbproc, sMsgID, eMsgId, SYS_BEPS))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "GetMsgIdValue failed");
        return -3;
    }
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sMsgID = [%s]", sMsgID);

	// 插入数据
	sprintf(sSqlStr, "INSERT INTO BP_BCOUTSENDLIST(INSTGDRCTPTY,WORKDATE, CONSIGDATE, "
	                 "MSGTP, MSGID, INSTDDRCTPTY, DBTNM, DBTRACCTID, DBTRISSR, "
	                 "DBTRBRNCHID, CDTRNM, CDTRACCTID, CDTRISSR, CDTRBRNCHID,"
					 "CURRENCY, AMOUNT, PMTTPPRTRY, PURPPRTRY, ADDTLINF, "
					 "CSTMRCDTTRFADDTLINF, ORGNLMSGID, ORGNLMSGTP, ORIINSTGDRCTPTY, "
					 "ORITXID, ORIPKGNUM,  ORIAMOUNT, NPCMSGLEN, NPCMSG, MBMSG, SRCFLAG,"
					 "CHECKSTATE,BUSISTATE, PROCESSCODE, RJCTINF, PROCSTATE, STATETIME,"
					 "FINALSTATEDATE, ACCTSTATE, ACSTATETIME, ACCTREGNUM, REACREGNUM, "
					 "NETGDT, NETGRND, ISTSTATETIME, INPUTTIME, CHECKTIME, GRANTTIME, "
					 "INPUTOPER,CHECKOPER, GRANTOPER, PRINTNO, ISRBFLG, DBTADDR, CDTADDR,"
					 "MBMSGID, MBINSTPTY, REMARK, TXID) SELECT INSTGDRCTPTY,WORKDATE, "
					 "CONSIGDATE, MSGTP, '0', INSTDDRCTPTY, DBTNM, DBTRACCTID, DBTRISSR,"
					 "DBTRBRNCHID, CDTRNM, CDTRACCTID, CDTRISSR, CDTRBRNCHID, CURRENCY, "
					 "AMOUNT, PMTTPPRTRY, PURPPRTRY, ADDTLINF, CSTMRCDTTRFADDTLINF, "
					 "ORGNLMSGID, ORGNLMSGTP, ORIINSTGDRCTPTY, ORITXID, ORIPKGNUM,"
					 "ORIAMOUNT, NPCMSGLEN, NPCMSG, MBMSG, SRCFLAG, CHECKSTATE, BUSISTATE,"
					 "PROCESSCODE, RJCTINF, '03', STATETIME, FINALSTATEDATE, ACCTSTATE, "
					 "ACSTATETIME, ACCTREGNUM, REACREGNUM, NETGDT, NETGRND,"
					 "ISTSTATETIME, INPUTTIME, CHECKTIME, GRANTTIME, INPUTOPER, CHECKOPER,"
					 "GRANTOPER, PRINTNO, ISRBFLG, DBTADDR, CDTADDR, MBMSGID, MBINSTPTY, "
					 "REMARK, '%s' FROM BP_BCOUTSENDLIST WHERE TXID = '%s'",
					 sMsgID, m_szTxId.c_str());

	iRet = cBpBcSndList.execsql(sSqlStr);
    if(0 != iRet)
    {
        cBpBcSndList.rollback();
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "sSqlStr[%s]", sSqlStr);
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "insert error[%d][%s]", 
             iRet, cBpBcSndList.GetSqlErr());
    }
    cBpBcSndList.commit();
    
	sHostRqt += Trim(sMsgID);
	sHostRqt += "            785584000009   A1000000000000000000000000000000000000000";

    strcpy(m_sMsg, sHostRqt.c_str());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Leave CSocketTestWork::InsertDb...");
    return 0;
}

int CSocketTestWork::SendtoHost()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSocketTestWork::SendtoHost..."); 
    
	char sMbRsp[4096 + 1];
    int iSocket;
	int iRet = 0;
	int iLenth = 0;
    TSocketClient SocketClient;
    
	memset(sMbRsp, 0, sizeof(sMbRsp));

	iSocket = SocketClient.connectServer((char *)m_szHostIp.c_str(), m_nHostPort);
	if ( iSocket <= 0)
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "连接SocketClient失败[%d][%d][%s]", 
            iSocket, m_nHostPort, m_szHostIp.c_str());
		return -1;
	}

	if( true != SocketClient.sendMsg(iSocket, m_sMsg, strlen(m_sMsg)) )
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "发送数据失败");
        SocketClient.disConnet();
		return -2;
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "发送数据成功[%s]", m_sMsg);
	
	iRet = SocketClient.recvMsg(sMbRsp, iLenth);
	if (iRet > 0)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sMbRsp[%s]", sMbRsp);
	}
	else
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "recvMsg error[%d]", iRet);
		SocketClient.disConnet();
		return -3;
	}

	SocketClient.disConnet();
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Leave CSocketTestWork::SendtoHost...");
    return 0;
}


