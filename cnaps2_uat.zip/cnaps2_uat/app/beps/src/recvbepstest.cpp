/********************************************************************
文件名：recvbepsptest.cpp
创建人：zny
日  期：2009.07.07
修改人：handongfeng
日  期：
描  述：后台业务来账处理主控
版  本：
Copyright (c) 2009  YLINK
********************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "exception.h"
#include "configparser.h"
#include "logger.h"
#include "parser111.h"
#include "pmtspubfunc.h"
#include "category.h"
#include "connectpool.h"
#include "mqagent.h"

CCategory *g_LogObj;
CConnectPool *g_DBConnPool;
MQAgent				cAgent;

#define SendQueue "MBRCV_BEPS";
#define FILENAME  "121.xml";

using namespace ZFPT;

int getFileText(const char *  sFileName,char * sMsg)
{
	char sBuff[1024] ;
	//循环读取数据并处理
	FILE *fp = NULL; 
	
	fp = fopen(sFileName, "r");
	
	if ( fp == NULL )
	{
		printf("打开文件出错\n");
		return -1;	
	}
	
	int rendlen = 0;
	int iTotalLen = 0;
	while ( 1 )
	{
		memset(sBuff, 0, sizeof(sBuff));
		fgets(sBuff, sizeof(sBuff), fp)	;
		
        rendlen = strlen(sBuff);
		if (rendlen == 0)
			break;
		strcpy(sMsg+iTotalLen ,sBuff);
		iTotalLen += rendlen;
		
	}
	return 0;
	
}

int main(int argc, char **argv)
{
    char 		sErrDesc[1024] 		= {0};
    int			iRet				=	0;
    char        sDbUser[32]           = {0};   //数据库用户
    char        sDbPass[32]           = {0};   //数据库密码
    char        sDbSid[128]           = {0};   //数据库服务名
    int         iConnPoolMinSize      = 0;     //连接池中最小连接数
    int         iConnPoolMaxSize      = 0;     //连接池中最大连接数
    int         iNoConnWaitTime       = 0;     //取不到连接时等待时间
    int         iConnPoolSize         = 0;     //连接池中初始连接数
    int         iThreadPoolSize       = 0;     //线程池中线程数
    int         iThreadPoolTaskSize   = 0;     //线程池任务数
     //加载配置文件 
    CConfigParser& cCfg = CConfigParser::getInstance();
	try
	{
		cCfg.loadConfig("../cfg/pmts.xml");
    	g_LogObj = new CCategory();
        iRet = g_LogObj->initialize("../log", 
                5, 
                "recvbptest",		    // application name
                R_NOSOCKET,	            // Listen the control port
                0,				        // availabel only if R_SOCKET
                9999,			        // Control manager port
                M_SYNC		            // output mode 1-M_SYNC 2-M_ASYNC
                );
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化日志...");		
        
		iConnPoolMinSize = atoi(cCfg.getOption("CONNPOOLMINSIZE"));
        iConnPoolMaxSize = atoi(cCfg.getOption("CONNPOOLMAXSIZE"));
        iNoConnWaitTime	 = atoi(cCfg.getOption("NOCONNWAITTIME"));
        iConnPoolSize    = atoi(cCfg.getOption("CONNPOOLSIZE"));

        strncpy(sDbUser,cCfg.getOption("DBUSER"), sizeof(sDbUser)-1);
        strncpy(sDbPass,cCfg.getOption("DBKEY") , sizeof(sDbPass)-1);
        strncpy(sDbSid,cCfg.getOption("DBNAME") , sizeof(sDbSid) -1);

		if(cAgent.Init(cCfg.getOption("MQMGR"), "./") != RTN_SUCCESS)
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Init MQ manager failed.");
            return -1;
        }
        
        //创建连接池 
        g_DBConnPool = new CConnectPool(iConnPoolMinSize,iConnPoolMaxSize,iNoConnWaitTime);

        iRet= g_DBConnPool->InitPool(iConnPoolSize,sDbUser,sDbPass,sDbSid);
		
        if(iRet == RTN_SUCCESS)
        {
            printf("连接池创建成功\n");
        }
        else
        {
            printf("连接池创建失败\n");
            return RTN_FAIL;
        }

        char msgtx[1024*5] = {0};
        int iRet = getFileText(FILENAME, msgtx);
        if(0 != iRet)
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "读取文件失败");	
        }    
        else
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "读取文件成功");	
        }
        
        iRet =  cAgent.PutMsg(SendQueue, msgtx.c_str(), length, NULL, NULL);
        if(0 != iRet)
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "往MQ添加数据失败");	
        }    
        else
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "往MQ添加数据成功");	
        }
        
	}catch(CException &e)
    {
    	sprintf(sErrDesc, "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());
    	
        
    }
   	
	return RTN_SUCCESS;
}
	
