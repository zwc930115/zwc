/******************************************************************** 
�ļ����� sendbeps121.cpp
�����ˣ� zwy
��  ��   �� 2011-03-07
�޸��ˣ� 
��  �ڣ� 
��  ���� С������beps.121���Ĵ�����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps121.h"

using namespace ZFPT;

CSendBeps121::CSendBeps121(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
}

CSendBeps121::~CSendBeps121()
{
}

INT32 CSendBeps121::UpdatePkg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps121::UpdatePkg");

    strncpy(m_strAssist.sSendBank, m_cBpbcoutsendlist.m_instgdrctpty.c_str(), 
            sizeof(m_strAssist.sSendBank) - 1);
            
    strncpy(m_strAssist.sRecvBank, m_cBpbcoutsendlist.m_instddrctpty.c_str(), 
            sizeof(m_strAssist.sRecvBank) - 1);
            
    strncpy(m_strAssist.sMsgType,  m_cBpbcoutsendlist.m_msgtp.c_str(),        
            sizeof(m_strAssist.sMsgType)  - 1);
            
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
        "m_cBpbcoutsendlist.m_msgtp[%s]", m_cBpbcoutsendlist.m_msgtp.c_str());
    
    m_strAssist.iPkgRtrltd = 0;
    strncpy(m_strAssist.sPmttpPrtry, "0", sizeof(m_strAssist.sPmttpPrtry) - 1);
    strncpy(m_strAssist.sIssr,       "0", sizeof(m_strAssist.sIssr)       - 1);
    strncpy(m_strAssist.sAcctId,     "0", sizeof(m_strAssist.sAcctId)     - 1);
    strncpy(m_strAssist.sOriMsgTp,   "0", sizeof(m_strAssist.sOriMsgTp)   - 1);
    strncpy(m_strAssist.sOriMsgId,   "0", sizeof(m_strAssist.sOriMsgId)   - 1);
    
    iRet = UpPKGAssist(m_sPkgNo);
    if (iRet != SQL_SUCCESS)
    {
        memcpy(m_sPkgNo, m_cBpbcoutsendlist.m_msgid.c_str(), sizeof(m_sPkgNo) - 1);
        sprintf(m_sErrMsg,  "UpPKGAssist is error,iRet=[%d][%s]", iRet, m_sPkgNo);
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps121::UpdatePkg");
    return 0;
}

INT32 CSendBeps121::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps121::doWorkSelf");
    
    /*��ҵ����л�ȡ����*/
    getData();

    //����������
    UpdatePkg();
    
    /*�޸���ϸ��:��ʾ���������޸İ����;������һ������ʱ,�޸�NPC����*/
    UpdateSendList("95");
    
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps121::doWorkSelf"); 
    return 0;
}

int CSendBeps121::getData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps121::getData");
    
	SETCTX(m_cBpbcoutsendlist);
    
  	m_cBpbcoutsendlist.m_dbtrbrnchid = m_sSendOrg;
  	m_cBpbcoutsendlist.m_txid = m_sMsgId;
  	
  	iRet = m_cBpbcoutsendlist.findByPK();
  	
  	if (SQLNOTFOUND == iRet)
	{
		sprintf(m_sErrMsg,"С�����ʴ�����ϸ�����Ҳ���ָ��ҵ��[%s],[%s],[%s]", 
		    m_sSendOrg, m_sMsgId, m_cBpbcoutsendlist.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	} 	
	else if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg,"��ѯС�����ʴ�����ϸ����������[%s]",
		    m_cBpbcoutsendlist.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps121::getData"); 
    
	return iRet;
}

int CSendBeps121::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps121::CheckValues");

    int iRet = -1;

    //������޼��
    iRet = isOutOfLimit(m_dbproc, 
                        m_cBpbcoutsendlist.m_msgtp.c_str(), 
                        m_cBpbcoutsendlist.m_purpprtry.c_str(),
                        m_cBpbcoutsendlist.m_amount, 
                        m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_AMT_OUT_OF_LIMIT, m_sErrMsg);
    }
    
    //�����кż��
    iRet = isBankRight(m_dbproc, m_cBpbcoutsendlist.m_instddrctpty.c_str(), m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_RECVBANK_CHECK_FAIL, m_sErrMsg);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps121::CheckValues");
    return 0;
}

int CSendBeps121::UpdateSendList(LPCSTR sProcstate)
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps121::UpdateSendList");

    //�������°����
    sprintf(m_sSqlStr, "UPDATE bp_bcoutsendlist t SET t.STATETIME = sysdate,"
            			"t.MSGID = '%s', t.PROCSTATE = '%s'"   /*�����*/
            			" WHERE t.txid = '%s'",
            			m_sPkgNo,
            			sProcstate,
            			m_sMsgId);

    iRet = m_cBpbcoutsendlist.execsql(m_sSqlStr);
    if (iRet != SQL_SUCCESS)
    {
        sprintf(m_sErrMsg,  "update bp_bcoutsendlist  is error!iRet=[%d]", iRet);
        Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps121::UpdateSendList");
    return 0;
}

INT32 CSendBeps121::SetErrACK(int iErrCode, LPCSTR pErrDesc)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps121::SetErrACK");

	//�޸�״̬Ϊ"���޸�"
    UpdateSendList(PR_HVBP_93);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps121::SetErrACK");
	return 0;
}

int CSendBeps121::ChargeMB()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBeps121::ChargeMB...");

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBeps121::ChargeMB..."); 
    
    return RTN_SUCCESS;
}

int CSendBeps121::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBeps121::FundSettle...");
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û�[%s]", m_szOprUser);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_sSendOrg);

	m_charge.m_amount = m_cBpbcoutsendlist.m_amount;	//ҵ����
	m_charge.m_iDCFlag = iDEBITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, m_szOprUserNetId);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_sSendOrg);	//������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(RTN_SUCCESS != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FundSettle iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBeps121::FundSettle..."); 
    
    return RTN_SUCCESS;
}


