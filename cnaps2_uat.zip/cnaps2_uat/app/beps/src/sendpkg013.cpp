/*
 *  sendpkg013.cpp
 *  Description: һ��PKG013����������
 *  Created on: 2012-06-07
 *  Author: __wsh
 */

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendpkg013.h"

static const char* _ccfl_req = "30501";
static const char* _ccfl_ans = "30504";

static const char*  _caq_req = "30502";
static const char*  _caq_ans = "30503";

static const char* _cfca_req = "30505";
static const char* _pkg_type = "013";

CSendPkg013::CSendPkg013(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
	memset(&(m_cPkg012.stBizBody005),
	        0x00, sizeof(m_cPkg012.stBizBody005));

	memset(&(m_cPkg012.stPkgHead012),
	        0x00, sizeof(m_cPkg012.stPkgHead012));

	m_pEntity = NULL;

	memset(m_szTblNm, 0x00, sizeof(m_szTblNm));

	m_strAppendData.clear();
}

CSendPkg013::~CSendPkg013()
{

}

//__wsh 2012-06-07 ���Ĵ������
INT32 CSendPkg013::doWorkSelf()
{
	int iRet = -1;

	//��ȡҵ������
	GetData();

	//�鱨��
	CreateNpcMsg();

    //����ҵ��״̬
	iRet = UpdateState();
	
	//���ͱ���
	iRet = AddQueue();
	
	//������Ϣ
	return iRet;
}

//__wsh 2012-06-06 ��ȡ֧ƱȦ��ҵ������
INT32 CSendPkg013::GetData_ccfl(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CSendPkg013::GetData_ccfl");

	int iRet = -1;

	SETCTX(m_ccfl);

	//������Ϣ
	m_ccfl.m_msgid    = m_sMsgId;
	m_ccfl.m_instgpty = m_sSendOrg;
	m_ccfl.m_srcflag  = "1";

	iRet = m_ccfl.findByPK();

	m_strWorkDate     = m_ccfl.m_workdate;
	m_strInstgdrctpty = m_ccfl.m_instgdrctpty;
	m_strInstgpty     = m_ccfl.m_instgpty;
	m_strInstddrctpty = m_ccfl.m_instddrctpty;
	m_strInstdpty     = m_ccfl.m_instdpty;
	m_strRmk          = m_ccfl.m_rmk;



	strcpy(m_szTblNm, "bp_chckcdtforld");
	m_pEntity = &m_ccfl;

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendPkg013::GetData_ccfl");

	return iRet;
}

//__wsh 2012-06-06 ��ȡ�ͻ�����Ϣ��ѯҵ������
INT32 CSendPkg013::GetData_caq(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CSendPkg013::GetData_caq");

	int iRet = -1;

	SETCTX(m_cam);

	//������Ϣ
	m_cam.m_msgid    = m_sMsgId;
	m_cam.m_instgpty = m_sSendOrg;
	m_cam.m_srcflag  = "1";

	iRet = m_cam.findByPK();

	m_strWorkDate     = m_cam.m_workdate;
	m_strInstgdrctpty = m_cam.m_instgdrctpty;
	m_strInstgpty     = m_cam.m_instgpty;
	m_strInstddrctpty = m_cam.m_instddrctpty;
	m_strInstdpty     = m_cam.m_instdpty;
	m_strRmk          = m_cam.m_rmk;

	strcpy(m_szTblNm, "bp_realtmcstacctmg");
	m_pEntity = &m_cam;

	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CSendPkg013::GetData_caq");

	return iRet;
}

//__wsh 2012-06-06 ��ȡCFCA��ѯҵ������
INT32 CSendPkg013::GetData_cfca(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CSendPkg013::GetData_cfca");

	int iRet = -1;

	SETCTX(m_cfca);

	//������Ϣ
	m_cfca.m_txid     = m_sMsgId;
	m_cfca.m_instgpty = m_sSendOrg;
	m_cfca.m_srcflag  = "1";

	iRet = m_cfca.findByPK();

	m_strWorkDate     = m_cfca.m_workdate;
	m_strInstgdrctpty = m_cfca.m_instgdrctpty;
	m_strInstgpty     = m_cfca.m_instgpty;
	m_strInstddrctpty = m_cfca.m_instddrctpty;
	m_strInstdpty     = m_cfca.m_instdpty;
	m_strRmk          = m_cfca.m_remark;

	strcpy(m_szTblNm, "bp_cfcaqry");
	m_pEntity = &m_cfca;

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendPkg013::GetData_cfca");

	return iRet;
}

//__wsh 2012-06-06 ��ȡҵ������
INT32 CSendPkg013::GetData(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CSendPkg013::GetData");

	int iRet = -1;

	if( NULL != strstr(m_BusinessType, _ccfl_req) ||
		NULL != strstr(m_BusinessType, _ccfl_ans)){
		//֧ƱȦ��ҵ��Ӧ��
		iRet = GetData_ccfl();
	}
	else if( NULL != strstr(m_BusinessType, _caq_req) ||
			 NULL != strstr(m_BusinessType, _caq_ans)){
		//�ͻ��˻���Ϣ��ѯҵ��Ӧ��
		iRet = GetData_caq();
	}
	else if( NULL != strstr(m_BusinessType, _cfca_req) ){
		//CFCA��ѯҵ��
		iRet = GetData_cfca();
	}
	else{
		//δ֪ҵ������
		sprintf(m_sErrMsg, "PKG013δ֪ҵ������[%s]", m_BusinessType);

		Trace(L_ERROR, __FILE__, __LINE__, NULL, "%s", m_sErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, m_sErrMsg);
	}

	//������ȡԭҵ��ʧ�� ���
	if(SQL_SUCCESS != iRet){
		if(SQLNOTFOUND == iRet){
			sprintf(m_sErrMsg, "[%s]�Ҳ���ָ��ҵ��[%s][%s]",
					m_szTblNm, m_sSendOrg, m_sMsgId);
		}
		else{
			sprintf(m_sErrMsg, "[%s]����ָ��ҵ�����[%s][%s]:%s",
					m_szTblNm, m_sSendOrg, m_sMsgId,
					m_pEntity->GetSqlErr());
		}

		Trace(L_ERROR, __FILE__, __LINE__, NULL, "%s", m_sErrMsg);

		PMTS_ThrowException(DB_FIND_BY_PK_FAIL);
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendPkg013::GetData");

	return iRet;
}


//__wsh 2012-06-07 ��ʽ�������֧ƱȦ��ҵ�񸽼�������
void CSendPkg013::FillAppendData_ccfl_req(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CSendPkg013::FillAppendData_ccfl_req");

	char szTmp[1024] = {0};

	//��Ʊ����8n
	chgToDate(m_ccfl.m_issedt.c_str(), szTmp);
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//֧Ʊ����20x ? 12n
	//sprintf(szTmp, "%-20s", m_ccfl.m_orcclnb.c_str());
	sprintf(szTmp, "%012s", m_ccfl.m_orcclnb.c_str());
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//�������к�12n
	sprintf(szTmp, "%12s", m_ccfl.m_orcclid.c_str());
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//��Ʊ���˺�
	sprintf(szTmp, "%-32s", m_ccfl.m_acctnb.c_str());
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//�տ����˺�  ����û�ֶδ�?
	sprintf(szTmp, "%-32s", " ");
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//���
	sprintf( szTmp, "%015d", (long)(m_ccfl.m_amt*100.0) );
	Trace(L_DEBUG, __FILE__, __LINE__,
	        NULL, "__@@__amt=[%.2f][%s]", m_ccfl.m_amt, szTmp);
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//��;,���Ժ�������Ҫ����GBKת��
	sprintf(szTmp, "%s", m_ccfl.m_usage.c_str());
	Utf8ToGbk(szTmp, sizeof(szTmp), "%-60s");
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//�����������������嵥
	string strTagVal = "";
	int iRet = -1;
	//��1��ֵΪ��������
	iRet = GetTagVal(strTagVal, m_ccfl.m_addtlinf, "72C:", 1);
	int nCnt = 0;
	if( 0 == iRet && strTagVal.length() <= 2 ){
		nCnt = atoi(strTagVal.c_str());

		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__��������_%d", nCnt);

		//��������
		sprintf(szTmp, "%02d", nCnt);
		m_strAppendData += szTmp;
		memset(szTmp, 0x00, sizeof(szTmp));

		char szNm[61] = {0};
		//�������嵥
		int i = 0;
		for(i = 2; i <= nCnt+1; ++i){
			strTagVal.clear();
			iRet = GetTagVal(strTagVal,
					m_ccfl.m_addtlinf, "72C:", i);
			if(-1 == iRet){
			    Trace(L_ERROR, __FILE__, __LINE__, NULL, 
			                "��ȡ��ǩֵʧ��!");
				break;
			}
			snprintf(szTmp, sizeof(szTmp)-1, "%s", strTagVal.c_str());
			Trace(L_DEBUG, __FILE__, __LINE__, NULL, "_szTmp=%s", szTmp);
			Utf8ToGbk(szTmp, sizeof(szTmp), "%-60s");
			Trace(L_DEBUG, __FILE__, __LINE__, NULL, "_szTmp=%s", szTmp);
			memcpy(szNm, szTmp, 60);
			m_strAppendData += szNm;
			memset(szTmp, 0x00, sizeof(szTmp));
		}
		Trace(L_DEBUG, __FILE__, __LINE__, NULL,
				"__nCnt=%d_i=%d", nCnt, i);
	}
	else{
	    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "_^^_��������_%d", nCnt);
		//��������, ������
		sprintf(szTmp, "%02d", nCnt);
		m_strAppendData += szTmp;
		memset(szTmp, 0x00, sizeof(szTmp));
	}

	//������֤ģʽ
	sprintf(szTmp, "%02s", m_ccfl.m_chckmd.c_str());
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//У������
	sprintf(szTmp, "%-512s", m_ccfl.m_chckcd.c_str());
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//ͼ�񳤶�
	sprintf(szTmp, "%08d", m_ccfl.m_imgfrntlen);
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//ͼ��
	m_strAppendData += m_ccfl.m_cntt;

	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Leave CSendPkg013::FillAppendData_ccfl_req");
}

//__wsh 2012-06-07 ��ʽ�������֧ƱȦ��ҵ��Ӧ�𸽼�������
void CSendPkg013::FillAppendData_ccfl_ans(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CSendPkg013::FillAppendData_ccfl_ans");

	char szTmp[256] = {0};

	//��Ӧ��ʶ
	sprintf(szTmp, "%02s", m_ccfl.m_status.c_str());
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//��Ʊ����8n
	chgToDate(m_ccfl.m_issedt.c_str(), szTmp);
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//֧Ʊ����12n
	sprintf(szTmp, "%012s", m_ccfl.m_orcclnb.c_str());
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//�������к�12n
	sprintf(szTmp, "%12s", m_ccfl.m_orcclid.c_str());
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//��Ʊ���˺�
	sprintf(szTmp, "%-32s", m_ccfl.m_acctnb.c_str());
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//���
	sprintf( szTmp, "%015d", (long)(m_ccfl.m_amt*100.0) );
	Trace(L_DEBUG, __FILE__, __LINE__,
			NULL, "__##__amt=[%.2f][%s]", m_ccfl.m_amt, szTmp);
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendPkg013::FillAppendData_ccfl_ans");
}

//__wsh 2012-06-07 ��ʽ�������ͻ��˻���ѯҵ�񸽼�������
void CSendPkg013::FillAppendData_caq_req(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CSendPkg013::FillAppendData_caq_req");

	char szTmp[256] = {0};
	//�˺�����
	m_strAppendData += m_cam.m_acctpmttp;

	//�˺�
	snprintf(szTmp, 32+1, "%-32s", m_cam.m_acctid.c_str());
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//������֤�㷨
	snprintf(szTmp, 2+1, "%02s", m_cam.m_chckmd.c_str());
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//����ֵ����
	snprintf(szTmp, 8+1, "%08d", m_cam.m_chckcdlen);
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//����ֵ
	m_strAppendData += m_cam.m_chckcdcntt;

	//��ѯ����
	m_strAppendData += m_cam.m_qrybalorststp;

	//��ѯ����,�ɺ�������Ҫתgbk
	snprintf(szTmp, sizeof(szTmp)-1, m_cam.m_rmk.c_str());
	Utf8ToGbk(szTmp, sizeof(szTmp)-1, "%-60s");
	m_strAppendData += szTmp;

	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Leave CSendPkg013::FillAppendData_caq_req");
}

//__wsh 2012-06-07 ��ʽ�������ͻ��˻���ѯҵ��Ӧ�𸽼�������
void CSendPkg013::FillAppendData_caq_ans(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CSendPkg013::FillAppendData_caq_ans");

	char szTmp[256] = {0};
    
    //ԭ������
	snprintf(szTmp, 8+1, "%8s", m_cam.m_orgnpkgdt.c_str());
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));
	//ԭ�����
	snprintf(szTmp, 8+1, "%8s", m_cam.m_orgnpkgno.c_str());
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));
	//ԭί������
	snprintf(szTmp, 8+1, "%8s", m_cam.m_orgnconsdt.c_str());
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));
	//ԭ��Ϣ���
	snprintf(szTmp, 8+1, "%8s", m_cam.m_orgntxno.c_str());
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));
	//�˺�
	snprintf(szTmp, 32+1, "%-32s", m_cam.m_acctid.c_str());
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));
	//ԭ��ѯ����
	m_strAppendData += m_cam.m_qrybalorststp;
	//Ӧ���ʶ
	m_strAppendData += m_cam.m_status;
	//��ǰ���
	snprintf(szTmp, 18+1, "RMB%015d", (long)(m_cam.m_currbal*100.0) );
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));
	//��ǰ�˻�״̬
	snprintf(szTmp, 2+1, "%02s", m_cam.m_acctsts.c_str());
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));
	//�鸴����,�ɺ�������Ҫתgbk
	snprintf(szTmp, sizeof(szTmp)-1, m_cam.m_rmk.c_str());
	Utf8ToGbk(szTmp, sizeof(szTmp)-1, "%-60s");
	m_strAppendData += szTmp;

	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Leave CSendPkg013::FillAppendData_caq_ans");
}

//__wsh 2012-06-07 ��ʽ�������CFCA֤���ҵ�񸽼�������
void CSendPkg013::FillAppendData_cfca(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CSendPkg013::FillAppendData_cfca");

	char szTmp[256] = {0};

	//���ԣ���Ϊ��
	strncpy(szTmp, m_cfca.m_remark.c_str(), 60);
	Utf8ToGbk(szTmp, sizeof(szTmp)-1, "%-60s");
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//֤�鳤��
	int nCfcaLen = m_cfca.m_cfcafile.length();
	sprintf(szTmp, "%08d", nCfcaLen);
	m_strAppendData += szTmp;
	memset(szTmp, 0x00, sizeof(szTmp));

	//֤��
	m_strAppendData += m_cfca.m_cfcafile;

	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Leave CSendPkg013::FillAppendData_cfca");
}

//__wsh 2012-06-07 ��ʽ������丽��������
void CSendPkg013::FillAppendData(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CSendPkg013::FillAppendData");

	if( NULL != strstr(m_BusinessType, _ccfl_req) ){
		//֧ƱȦ��ҵ��
		FillAppendData_ccfl_req();
	}
	else if( NULL != strstr(m_BusinessType, _ccfl_ans) ){
		//֧ƱȦ��ҵ��Ӧ��
		FillAppendData_ccfl_ans();
	}
	else if( NULL != strstr(m_BusinessType, _caq_req) ){
		//�ͻ��˻���Ϣ��ѯҵ��
		FillAppendData_caq_req();
	}
	else if( NULL != strstr(m_BusinessType, _caq_ans) ){
		//�ͻ��˻���Ϣ��ѯҵ��Ӧ��
		FillAppendData_caq_req();
	}
	else if( NULL != strstr(m_BusinessType, _cfca_req) ){
		//CFCA��ѯҵ��
		FillAppendData_cfca();
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendPkg013::FillAppendData");
}

//__wsh 2012-06-07 ���ҵ��ҵ��ͷ����
void CSendPkg013::FillBizHead(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CSendPkg013::FillBizHead");

	//������ 013
	sprintf(m_cPkg012.stPkgHead012.szPkgType,
			"%s", _pkg_type);

	//ֱ�ӷ�����
	strncpy(m_cPkg012.stPkgHead012.szOdfiCode,
			m_strInstgdrctpty.c_str(),
			sizeof(m_cPkg012.stPkgHead012.szOdfiCode)-1);

	//ֱ�ӽ�����
	strncpy(m_cPkg012.stPkgHead012.szRdfiCode,
			m_strInstddrctpty.c_str(),
			sizeof(m_cPkg012.stPkgHead012.szRdfiCode)-1);

	//��ί������
	strncpy(m_cPkg012.stPkgHead012.szPkgCDate,
			m_strWorkDate.c_str(),
			sizeof(m_cPkg012.stPkgHead012.szPkgCDate) - 1);

	//�������
	strncpy(m_cPkg012.stPkgHead012.szPkgserNo,
			m_szMsgSerial,
			sizeof(m_cPkg012.stPkgHead012.szPkgserNo)-1);
			
	//Ͻ�ڷַ���־
	sprintf(m_cPkg012.stPkgHead012.szSoFlag,
			"%d", 0);

	//ҵ������
	strncpy(m_cPkg012.stPkgHead012.szTradetype,
			m_BusinessType,
			sizeof(m_cPkg012.stPkgHead012.szTradetype)-1);

	//��ϸ��Ŀ �̶�1
	sprintf(m_cPkg012.stPkgHead012.szDetailCnt,
			"%d", 1);

	//��ע�����Ժ����ģ�Ҫ��GBKת��
	strncpy(m_cPkg012.stPkgHead012.szAppData,
			m_strRmk.c_str(),
			sizeof(m_cPkg012.stPkgHead012.szAppData)-1);

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendPkg013::FillBizHead");
}

//__wsh 2012-06-07 ���ҵ��Ҫ��������
void CSendPkg013::FillBizBody(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CSendPkg013::FillBizBody");

	//Ҫ�ؼ�5
	m_cPkg012.m_szCurElementNo = "005";

	//ҵ������
	strncpy(m_cPkg012.stBizBody005.szTrxsType,
			m_BusinessType,
			sizeof(m_cPkg012.stBizBody005.szTrxsType)-1);

	//�����к�
	strncpy(m_cPkg012.stBizBody005.szOdfiCode,
			m_strInstgpty.c_str(),
			sizeof(m_cPkg012.stBizBody005.szOdfiCode)-1);

	//�����к�
	strncpy(m_cPkg012.stBizBody005.szRdfiCode,
			m_strInstdpty.c_str(),
			sizeof(m_cPkg012.stBizBody005.szRdfiCode)-1);

	//ί������
	strncpy(m_cPkg012.stBizBody005.szConsignDate,
			m_strWorkDate.c_str(),
			sizeof(m_cPkg012.stBizBody005.szConsignDate)-1);

	//�������
	strncpy(m_cPkg012.stBizBody005.szTxssNo,
			m_szMsgSerial,
			sizeof(m_cPkg012.stBizBody005.szTxssNo)-1);

	//��ʽ������丽��������
	FillAppendData();
	//�����򳤶�
	int nAppLen = m_strAppendData.length();
	sprintf(m_cPkg012.stBizBody005.szAppLen, "%d", nAppLen);
	//��������򳤶ȹ����� ��ʱִ�нض�
	if(nAppLen > sizeof(m_cPkg012.stBizBody005.szAppData)-1){
		Trace(L_INFO, __FILE__, __LINE__,
				NULL, "__������[%d]������ �ض�!!!", nAppLen);

		nAppLen = sizeof(m_cPkg012.stBizBody005.szAppData)-1;
	}
	//������
	memcpy(m_cPkg012.stBizBody005.szAppData,
				m_strAppendData.c_str(), nAppLen);

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendPkg013::FillBizBody");
}

//__wsh 2012-06-07 ��ȡͨ�ż��ο���Ϣ��
INT32 CSendPkg013::GetMsgId(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CSendPkg013::GetMsgId");

	memset(m_sMsgRefId, 0x00, sizeof(m_sMsgRefId));
	memset(m_sMesgID, 0x00, sizeof(m_sMesgID));

	if(!GetMsgIdValue(m_dbproc, m_sMsgRefId,
				eRefId, SYS_BEPS, m_strInstgdrctpty.c_str())){
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ȡͨ�ű�ʶʧ��!");
		PMTS_ThrowException(OPT_GET_MESGREFID_FAIL);
	}

	Trace(L_DEBUG, __FILE__, __LINE__, NULL,
	        "m_sMesgID:[%s]m_sMsgRefId[%s]", m_sMesgID, m_sMsgRefId);

	//֧ƱȦ��ҵ����Ҫ�����кŽ��У����ı�ʶ��ͨ�ű�ʶ�����⴦��
	//����ο�һ��<<2.7.֧ƱȦ��ҵ��˵��_�ո�>>
	if( NULL != strstr(m_BusinessType, _ccfl_req) ||
		NULL != strstr(m_BusinessType, _ccfl_ans)){
		//���ı�ʶ��Q+7λ˳����
		memset(m_sMesgID, ' ', sizeof(m_sMesgID)-1);
		m_sMesgID[0] = 'Q';
		memcpy(m_sMesgID+1, m_sMsgRefId + 13, 7);

		//ͨ�ż���ʶ CFSCNAPS+12λ˳����
		memcpy(m_sMsgRefId, "CFSCNAPS", 8);

		//�±��ı�ʶ
		m_szMsgSerial[0] = '9';
		m_strNewMsgId = m_sMsgId;
		m_strNewMsgId[8] = '9';
	}
	else{
		memcpy(m_sMesgID, m_sMsgRefId, 20);
	}

	Trace(L_DEBUG, __FILE__, __LINE__, NULL,
	        "m_sMesgID:[%s]m_sMsgRefId[%s]", m_sMesgID, m_sMsgRefId);

    Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendPkg013::GetMsgId");

	return 0;
}

//__wsh 2012-06-07 ����PKG����
INT32 CSendPkg013::CreateNpcMsg(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CSendPkg013::CreateNpcMsg");

	int iRet = -1;

	//��ȡͨ�ż���ʶ
	GetMsgId(); 

	//�鱨ͷ
	iRet = m_cPkg012.CreateMsgHeader(
				"013",
				 m_strInstgdrctpty.c_str(),
				 m_strInstddrctpty.c_str(),
				 m_sMesgID,
				 m_sMsgRefId,
				 m_strWorkDate.c_str(),
				 "1");

	Trace(L_DEBUG, __FILE__, __LINE__, NULL,
	                "__%s", m_cPkg012.m_szMsgHead.c_str());

	//���ҵ��ͷ
	FillBizHead();

	//���ҵ����Ҫ��
	FillBizBody();

	//��ҵ����
	m_cPkg012.AddBussiness();

	Trace(L_DEBUG, __FILE__, __LINE__, NULL,
	                "__%s", m_cPkg012.m_szPkgBody.c_str());

    char szMac[40 + 1] = {0};                
    string strCodeMac;//ȡ��Ѻ��
    m_cPkg012.GetMacStr(m_cPkg012, strCodeMac);
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
                "__strCodeMac = [%s]", strCodeMac.c_str());
    
    int iRetCode = CodeMac(m_dbproc, strCodeMac.c_str(), 
                                m_strInstgdrctpty.c_str(), szMac);
    if (RTN_SUCCESS != iRetCode) {	
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "��Ѻʧ��");
		PMTS_ThrowException(__FILE__, __LINE__, OPT_CODEMAC_FAIL, "��Ѻʧ��");
	}
	
	memcpy(m_cPkg012.stPkgHead012.szPkgDest, szMac, sizeof(szMac)-1);
	
	//�鱨��β
	m_cPkg012.CreateMsgTail();

	//�鱨��
	iRet = m_cPkg012.CreateMsg();

	m_sMsgTxt = m_cPkg012.m_szMsgText;

    Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendPkg013::CreateNpcMsg");

	return iRet;
}

//__wsh 2012-06-08 ����״̬
INT32 CSendPkg013::UpdateState(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CSendPkg013::UpdateState");

	int iRet = -1;

    Trim(m_sMesgID);
	string strSql = " update ";
	strSql.append(m_szTblNm);
	strSql.append(" set mesgid='");
	strSql.append(m_sMesgID);
	strSql.append("', mesgrefid='");
	strSql.append(m_sMsgRefId);
	strSql.append("', procstate='08' ");

	if( NULL != strstr(m_BusinessType, _ccfl_req) ||
		NULL != strstr(m_BusinessType, _ccfl_ans)){
		//֧ƱȦ��ҵ��Ӧ��
		strSql.append(", msgid='");
		strSql.append(m_strNewMsgId);
		strSql.append("' where msgid='");
	}
	else if( NULL != strstr(m_BusinessType, _caq_req) ||
			 NULL != strstr(m_BusinessType, _caq_ans)){
		//�ͻ��˻���Ϣ��ѯҵ��Ӧ��
		strSql.append(" where msgid='");
	}
	else if( NULL != strstr(m_BusinessType, _cfca_req) ){
		//CFCA��ѯҵ��
		strSql.append(", msgid='");
		strSql.append(m_sMsgId);
		strSql.append("' where txid='");
	}

	strSql.append(m_sMsgId);
	strSql.append("' and instgpty='");
	strSql.append(m_strInstgpty);
	strSql.append("' and srcflag=1 ");

	Trace(L_DEBUG, __FILE__, __LINE__,
			NULL, "__strSql=%s", strSql.c_str());

	iRet = m_pEntity->execsql(strSql.c_str());
	if(SQL_SUCCESS != iRet){
		sprintf(m_sErrMsg, "[%s]����ָ��ҵ�����[%s][%s]:%s",
				m_szTblNm, m_sSendOrg, m_sMsgId,
				m_pEntity->GetSqlErr());
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "%s", m_sErrMsg);

		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendPkg013::UpdateState");

	return iRet;
}


