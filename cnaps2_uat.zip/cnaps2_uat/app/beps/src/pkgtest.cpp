/********************************************************************
文件名：recvfromfe.cpp
创建人：zny
日  期：2009.07.07
修改人：zj
日  期：
描  述：后台业务来账处理主控
版  本：
Copyright (c) 2009  YLINK
********************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "exception.h"
#include "configparser.h"
#include "cmtmsg.hpp"
#include "cmtpkgmsg.hpp"
#include "cmtfileoperator.hpp"
#include "pubfunc.h"
#include "category.h"
#include "connectpool.h"
#include "pkg001.h"
#include "parser121.h"
#include "basicapi.h"

CCategory g_LogObj;
CConnectPool *g_DBConnPool;

using namespace ZFPT;
#define MQ_ERR_MAX_TIMES 20

#define	TRANS_PARM		1
#define	STATUS_PARM		2


int getFileText(char *  sFileName,char * sMsg)
{
	
	char sBuff[1024] ;
	//循环读取数据并处理
	FILE *fp = NULL; 
	
	fp = fopen(sFileName, "r");
	
	if ( fp == NULL )
	{
		printf("打开文件出错\n");
		return -1;	
	}
	
	int rendlen = 0;
	int iTotalLen = 0;
	while ( 1 )
	{
		memset(sBuff, 0, sizeof(sBuff));
		fgets(sBuff, sizeof(sBuff), fp)	;
		
        rendlen = strlen(sBuff);
		if (rendlen == 0)
			break;
		strcpy(sMsg+iTotalLen ,sBuff);
		iTotalLen += rendlen;
		
	}
	return 0;
	
} 


int parsePkg001(const char * sMsg)
{
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter parsePkg001");
   	
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sMsg = [%s]",sMsg);
   	
	pkg001 cPkg001;
	cPkg001.ParseMsg(sMsg);
	
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cPkg001.m_stMsgHead.sDestAddr = [%s]",cPkg001.m_stMsgHead.sDestAddr);
	
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cPkg001.stPkgHead.sPkgType = [%s]",cPkg001.stPkgHead.sPkgType);
   	
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cPkg001.stBizBody.sRecipientName = [%s]",cPkg001.stBizBody.sRecipientName);
   	
   	
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cPkg001.m_iDetailCnt = [%d]",cPkg001.m_iDetailCnt);
   	
   	for(int i=0;i<10;i++)
   	{
   		cPkg001.ParseBusinessData(i);
   		
   		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cPkg001.m_szCurElementNo = [%s]",cPkg001.m_szCurElementNo.c_str());
   	
   		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cPkg001.stBizBody.sRecipientName = [%s]",cPkg001.stBizBody.sRecipientName);
   	}
   	
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit parsePkg001");
	return 0;
}


int createPkg001()
{
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter packPkg001");
   	
	pkg001 cPkg001;
	
	strncpy(cPkg001.stPkgHead.sPkgType		,"001"					,sizeof(cPkg001.stPkgHead.sPkgType		)-1		);  
	strncpy(cPkg001.stPkgHead.sOdfiCode		,"888888888888"			,sizeof(cPkg001.stPkgHead.sOdfiCode		)-1		); 
	strncpy(cPkg001.stPkgHead.sRdfiCode		,"999999999999"			,sizeof(cPkg001.stPkgHead.sRdfiCode		)-1		); 
	strncpy(cPkg001.stPkgHead.sPkgCDate		,"20110305"				,sizeof(cPkg001.stPkgHead.sPkgCDate		)-1		); 
	strncpy(cPkg001.stPkgHead.sPkgserNo		,"00000001"				,sizeof(cPkg001.stPkgHead.sPkgserNo		)-1		); 
	strncpy(cPkg001.stPkgHead.sPkgDest		,"ASDWWR3JUHYASDWWR3JUH",sizeof(cPkg001.stPkgHead.sPkgDest		)-1		);  
	strncpy(cPkg001.stPkgHead.sDetailCnt	,"1"					,sizeof(cPkg001.stPkgHead.sDetailCnt	)-1			);
	strncpy(cPkg001.stPkgHead.sDetailAmt	,"RMB300"				,sizeof(cPkg001.stPkgHead.sDetailAmt	)-1			);
	strncpy(cPkg001.stPkgHead.sNtNodeType   ,"1"					,sizeof(cPkg001.stPkgHead.sNtNodeType   )-1		);
	strncpy(cPkg001.stPkgHead.sNtDate		,"20110305"				,sizeof(cPkg001.stPkgHead.sNtDate		)-1		);   
	strncpy(cPkg001.stPkgHead.sNtNo			,"3"					,sizeof(cPkg001.stPkgHead.sNtNo			)-1	);     
	strncpy(cPkg001.stPkgHead.sSrcFlag		,"1"					,sizeof(cPkg001.stPkgHead.sSrcFlag		)-1		);  
	strncpy(cPkg001.stPkgHead.sSapsDate		,"20110305"				,sizeof(cPkg001.stPkgHead.sSapsDate		)-1		); 
	strncpy(cPkg001.stPkgHead.sProcState	,"1"					,sizeof(cPkg001.stPkgHead.sProcState	)-1			);
	strncpy(cPkg001.stPkgHead.sAppData		,"REMARK"				,sizeof(cPkg001.stPkgHead.sAppData		)-1		);  
	
	
   	for(int i=0;i<100;i++)
   	{
	
   		cPkg001.m_szCurElementNo = "001";
	
   		strncpy(cPkg001.stBizBody.sTrxsType        	,"001"					,sizeof(cPkg001.stBizBody.sTrxsType        )-1		);  
		strncpy(cPkg001.stBizBody.sOdfiCode        	,"888888888888"			,sizeof(cPkg001.stBizBody.sOdfiCode        )-1		); 
		strncpy(cPkg001.stBizBody.sRdfiCode        	,"999999999999"			,sizeof(cPkg001.stBizBody.sRdfiCode        )-1		); 
		strncpy(cPkg001.stBizBody.sConsignDate     	,"20110305"				,sizeof(cPkg001.stBizBody.sConsignDate     )-1		); 
		strncpy(cPkg001.stBizBody.sTxssNo          	,"00000001"				,sizeof(cPkg001.stBizBody.sTxssNo          )-1		); 
		strncpy(cPkg001.stBizBody.sAmount          	,"ASDWWR3JUHYASDWWR3JUH",sizeof(cPkg001.stBizBody.sAmount          )-1		);  
		strncpy(cPkg001.stBizBody.sPayOpenAccBkCode	,"1"					,sizeof(cPkg001.stBizBody.sPayOpenAccBkCode)-1			);
		strncpy(cPkg001.stBizBody.sPayerAcc        	,"RMB300"				,sizeof(cPkg001.stBizBody.sPayerAcc        )-1			);
		strncpy(cPkg001.stBizBody.sPayerName        ,"1"					,sizeof(cPkg001.stBizBody.sPayerName       )-1		);
		strncpy(cPkg001.stBizBody.sPayerAddr       	,"20110305"				,sizeof(cPkg001.stBizBody.sPayerAddr       )-1		);   
		strncpy(cPkg001.stBizBody.sRecOpenAccBkCode	,"3"					,sizeof(cPkg001.stBizBody.sRecOpenAccBkCode)-1	);     
		strncpy(cPkg001.stBizBody.sRecipientAcc    	,"1"					,sizeof(cPkg001.stBizBody.sRecipientAcc    )-1		);  
		strncpy(cPkg001.stBizBody.sRecipientName   	,"20110305"				,sizeof(cPkg001.stBizBody.sRecipientName   )-1		); 
		strncpy(cPkg001.stBizBody.sRecipientAddr   	,"1"					,sizeof(cPkg001.stBizBody.sRecipientAddr   )-1			);
		strncpy(cPkg001.stBizBody.sTrxKind         	,"REMARK"				,sizeof(cPkg001.stBizBody.sTrxKind         )-1		);  
		strncpy(cPkg001.stBizBody.sPost            	,"1"					,sizeof(cPkg001.stBizBody.sPost            )-1		); 
		strncpy(cPkg001.stBizBody.sAppLen          	,"234"					,sizeof(cPkg001.stBizBody.sAppLen          )-1			);
		strncpy(cPkg001.stBizBody.sAppData         	,"APPDATA"				,sizeof(cPkg001.stBizBody.sAppData         )-1		);  
		
	
		cPkg001.AddBussiness();
	
   	}
   	cPkg001.CreateMsg();
   	
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cPkg001.szMsgText = [%s]",cPkg001.m_szMsgText.c_str());
   	
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit packPkg001");
	return 0;
}

int unPackPkg001(const char * sMsg)
{
	//ZFPTLOG << eSystem << __FILE__ << " " << __LINE__ << " entering unpack " << endl;	
	
	CT_CMTPkgMsg m_CMTPkgMsg(sMsg);
	
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CMTPkgMsg = [%s]",m_CMTPkgMsg.ToString().GetBuffer(0));
   	
   	
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "IsBodyInFile = [%d]",m_CMTPkgMsg.IsBodyInFile());
   	
   	
   	char sPkgType[32] = {0};
   	m_CMTPkgMsg.GetPkgHeader()->GetTag("02C",sPkgType);
   	
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPkgType = [%s]",sPkgType);
   	
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "BusinessHeader = [%s]",m_CMTPkgMsg.GetBusinessHeader(0)->m_strSetCode.GetBuffer(0));
   	
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "BusinessData = [%s]",m_CMTPkgMsg.GetBusinessData(1)->ToString().GetBuffer(0));
   	
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "GetBody = [%s]",m_CMTPkgMsg.GetBody().GetBuffer(0));
   	
   	if(m_CMTPkgMsg.IsBodyInFile())
   	{
		CT_CMTFileOperator clsCmtFileOp;
		
		clsCmtFileOp.OpenBodyFile( m_CMTPkgMsg.GetBodyFileName().GetBuffer(0) );
		
		m_CMTPkgMsg.Clean(1);											
		clsCmtFileOp.ParseMessage( m_CMTPkgMsg);
	}
	
	int iCount = m_CMTPkgMsg.GetBusinessDataCnt();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "取的条数[%d]", iCount);

	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "BusinessData = [%s]",m_CMTPkgMsg.GetBusinessData(0)->ToString().GetBuffer(0));
	
		
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "BusinessData = [%s]",m_CMTPkgMsg.GetBusinessData(988)->ToString().GetBuffer(0));
	
	//ZFPTLOG << eSystem << __FILE__ << " " << __LINE__ << " leaving unpack " << endl;
	return 0;
}

int packPkg001()
{
		
	CT_CMTPkgBusinessHeader m_CMTPkgBusinessHeader;
    CT_CMTBusinessData m_MsgBusiData;
    CT_CMTMsg          m_cmtMsg;
    CMTHeaderMap       MsgHeader;
    CT_CMTPkgMsg	   m_CMTPkgMsg;
    
    m_CMTPkgBusinessHeader.m_strSetCode = "001";
    
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CMTPkgBusinessHeader = [%s]",m_CMTPkgBusinessHeader.ToString().GetBuffer(0));
   	
   	char sBodyFileName[256] = {0};
   	strcpy(sBodyFileName,"/ncb/pmts/bin/beps001.txt");
   	CT_CMTFileOperator clsCmtFileOp;
   	
    
    clsCmtFileOp.CreateBodyFile(sBodyFileName);
    
	clsCmtFileOp.AddBuffer(m_CMTPkgBusinessHeader.ToString().GetBuffer(0));
	
    m_MsgBusiData.AddTag("B40","hello");
    m_MsgBusiData.AddTag("A30","world");
    m_MsgBusiData.AddTag("B20","dodolo");
    m_MsgBusiData.AddTag("B30","kilene");
    
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_MsgBusiData = [%s]",m_MsgBusiData.ToString().GetBuffer(0));
   	
	char sBizText[1024 * 28] = {0};
	memset(sBizText,'\0',sizeof(sBizText));
	memset(sBizText,'a',sizeof(sBizText)-1);
	
    m_MsgBusiData.AddTag("LON",sBizText);
	
    
	clsCmtFileOp.AddBuffer(m_MsgBusiData.ToString().GetBuffer(0));
	
	clsCmtFileOp.AddBuffer(m_CMTPkgBusinessHeader.ToString().GetBuffer(0));
	
	m_MsgBusiData.SetTag("B40","hello");
	clsCmtFileOp.AddBuffer(m_MsgBusiData.ToString().GetBuffer(0));
	
    
   	m_CMTPkgMsg.SetBodyFileName(sBodyFileName);
   	
   	m_CMTPkgMsg.GetMsgHeader()->m_chSubSystemId = '1';
   	m_CMTPkgMsg.GetMsgHeader()->m_strCMTCode = "001";
   	m_CMTPkgMsg.GetMsgHeader()->m_strSender = "aaaaaaaaaaaa";
   	m_CMTPkgMsg.GetMsgHeader()->m_strReceiver = "bbbbbbbbbbbb";
   	m_CMTPkgMsg.GetMsgHeader()->m_strMsgId = "1234567890123456";
   	m_CMTPkgMsg.GetMsgHeader()->m_strRequestId = "001";
   	m_CMTPkgMsg.GetMsgHeader()->m_strValidDate = "20100303";
   	
   	m_CMTPkgMsg.GetPkgHeader()->AddTag("02C","包类型号");
   	m_CMTPkgMsg.GetPkgHeader()->AddTag("011","包发起清算行行号");
   	m_CMTPkgMsg.GetPkgHeader()->AddTag("012","包接收清算行行号");
   	m_CMTPkgMsg.GetPkgHeader()->AddTag("30E","包委托日期");
   	m_CMTPkgMsg.GetPkgHeader()->AddTag("0BD","包序号");
   	
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CMTPkgMsg = [%s]",m_CMTPkgMsg.ToString().GetBuffer(0));
   	
	//ZFPTLOG << eSystem << __FILE__ << " " << __LINE__ << " leaving Pack " << endl;
	
	return 0;
}

int digitSignTest()
{
	printf("%s %d\n",__FILE__,__LINE__);
    DBProc      dbproc;                        //连接	
   	printf("%s %d\n",__FILE__,__LINE__);
	// 获取连接	
    if(0 != g_DBConnPool->GetConnect(dbproc))
    {				
   		printf("获取连接失败\n");	
        return -1;
    }
   	printf("%s %d\n",__FILE__,__LINE__);
   	char sOrigenStr[] = "helloworld";
    char sSignedStr[10240] = {0};
	int iRet = digitSign(dbproc, sOrigenStr,sSignedStr,0, 0);
   	printf("%s %d\n",__FILE__,__LINE__);
	if(0 != iRet)
    {				
   		printf("加签失败\n");	
        return -1;
    }
   	printf("%s %d\n",__FILE__,__LINE__);
    
   	//removeChar13_10(sSignedStr);
   	
   	printf("sSignedStr = [%s]\n",sSignedStr);
   	//iRet = checkSignDetached(dbproc,sOrigenStr,sSignedStr,"402602000018");
   	iRet = checkSign(dbproc,sOrigenStr,sSignedStr,"402602000018");
   	if(0 != iRet)
    {				
   		printf("核签失败\n");	
        return -1;
    }
   	return 0;
}


int unPack(LPCSTR sMsg)
{
	int iMsgVer = JudgeMsgVer(sMsg);
	int iBizCode = GetMsgCode(sMsg);
	printf("szBizCode = [%d]\n",iBizCode);
	PARSER121 oParser121;
	
	oParser121.Init(VERSION_XML,1);
	
	int iRet = oParser121.ParseMsg(sMsg);
	if (iRet != 0)
	{
        return iRet;
	}
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, " oParser121.MsgId = [%s]",oParser121.MsgId.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, " oParser121.InstdDrctPty = [%s]",oParser121.InstdDrctPty.c_str());
	
	int iDetailCnt = oParser121.GetDetailCnt();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, " oParser121.iDetailCnt = [%d]",iDetailCnt);
	
	for(int i=0;i<iDetailCnt;i++)
	{
		oParser121.ParseDetail(i);
		
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, " oParser121.CdtrNm = [%s]",oParser121.CdtrNm.c_str());
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, " oParser121.AddtlInf = [%s]",oParser121.AddtlInf.c_str());
	}
	
	return 0;
}

int pack()
{
	int iMsgType = VERSION_CMT;
	PARSER121 oParser121;
	
	
	oParser121.Init(iMsgType,1);
	
	if(VERSION_CMT == iMsgType)
	{
		strncpy(oParser121.m_stMsgHead.sCmtNo,"001",sizeof(oParser121.m_stMsgHead.sCmtNo)-1);
		strncpy(oParser121.m_stMsgHead.sSrcAddr,"yyyyyyyyyyyy",sizeof(oParser121.m_stMsgHead.sSrcAddr)-1);
		strncpy(oParser121.m_stMsgHead.sDestAddr,"bbbbbbbbbbbb",sizeof(oParser121.m_stMsgHead.sDestAddr)-1);
		strncpy(oParser121.m_stMsgHead.sMesgId,"20000000000000000002",sizeof(oParser121.m_stMsgHead.sMesgId)-1);
		strncpy(oParser121.m_stMsgHead.sMesgReqNo,"30000000000000000003",sizeof(oParser121.m_stMsgHead.sMesgReqNo)-1);
		strncpy(oParser121.m_stMsgHead.sWorkDate,"20110309",sizeof(oParser121.m_stMsgHead.sWorkDate)-1);
	}
		
	oParser121.MsgId = "1234567";
	
	for(int i=0;i<3;i++)
	{
		oParser121.TxId = "1234567800000001";
		oParser121.CtgyPurpPrtry = "00001";
		oParser121.CdtrNm = "收款人A";
		oParser121.DbtrNm = "fu款人A";
		oParser121.AddDetail();
	}
	oParser121.InstgDrctPty = "sendbank";
	oParser121.InstdDrctPty = "recvbank";
	int iRet = oParser121.CreateMsg();
	if (iRet != 0)
	{
        return iRet;
	}
	printf("m_MsgTxt = [%s]\n",oParser121.m_MsgTxt.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, " oParser121.m_MsgTxt = [%s]",oParser121.m_MsgTxt.c_str());
	
	return 0;
}


int packRoopInRoop()
{
	int iMsgType = VERSION_XML;
	PARSER121 oParser121;
	
	
	oParser121.Init(iMsgType,1);
	
	if(VERSION_XML == iMsgType)
	{
		oParser121.m_PMTSHeader.setOrigSendDate("20110310");
		oParser121.m_PMTSHeader.setOrigSender("666666666666");
		oParser121.m_PMTSHeader.setOrigReceiver("888888888888");
		oParser121.m_PMTSHeader.setMesgType("beps.121.001.01");
		oParser121.m_PMTSHeader.setMesgID("66666666666600000001");
		oParser121.m_PMTSHeader.setMesgRefID("66666666666600000001");
	}
	else
	{
		strncpy(oParser121.m_stMsgHead.sCmtNo,"001",sizeof(oParser121.m_stMsgHead.sCmtNo)-1);
		strncpy(oParser121.m_stMsgHead.sSrcAddr,"yyyyyyyyyyyy",sizeof(oParser121.m_stMsgHead.sSrcAddr)-1);
		strncpy(oParser121.m_stMsgHead.sDestAddr,"bbbbbbbbbbbb",sizeof(oParser121.m_stMsgHead.sDestAddr)-1);
		strncpy(oParser121.m_stMsgHead.sMesgId,"20000000000000000002",sizeof(oParser121.m_stMsgHead.sMesgId)-1);
		strncpy(oParser121.m_stMsgHead.sMesgReqNo,"30000000000000000003",sizeof(oParser121.m_stMsgHead.sMesgReqNo)-1);
		strncpy(oParser121.m_stMsgHead.sWorkDate,"20110309",sizeof(oParser121.m_stMsgHead.sWorkDate)-1);
	}
	
	
	oParser121.MsgId                  =	"66666666666600000001";
	oParser121.CreDtTm                =	"2011-03-10T06:06:06";
	oParser121.InstgDrctPty           =	"666666666666";
	oParser121.InstdDrctPty           =	"888888888888";
	
	for(int i=0;i<3;i++)
	{
		oParser121.TxId = "66666666666600000001";
		oParser121.CtgyPurpPrtry = "00001";
		oParser121.CdtrNm = "收款人A";
		oParser121.DbtrNm = "fu款人A";
		
		
		oParser121.FslInf                       = 	"兑付信息"		;
		oParser121.NtlTrsrInfNbOfTxs            = 	"6"		;
		NtlTrsrInfDtls
		for(int j=0;j<6;j++)
		{
			AddNodeToSubcycle("TpCd","兑付国债银行大类");
			AddNodeToSubcycle("CptlCd","本金代码");
			AddNodeToSubcycle("CptlAmt","666.00");
			AddNodeToSubcycle("CptlAmtCcy","CNY");
			AddNodeToSubcycle("AcrlCd","利息代码");
			AddNodeToSubcycle("AcrlAmt","888.00");
			AddNodeToSubcycle("AcrlAmtCcy","CNY");
			AddSubcycleToNode("NtlTrsrInfDtls");
		}
		
		oParser121.AddDetail();
	}
	int iRet = oParser121.CreateMsg();
	if (iRet != 0)
	{
        return iRet;
	}
	printf("m_MsgTxt = [%s]\n",oParser121.m_MsgTxt.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, " oParser121.m_MsgTxt = [%s]",oParser121.m_MsgTxt.c_str());
	
	return 0;
}


int main(int argc, char **argv)
{
	
    char 		sErrDesc[1024] 		= {0};
    int			iRet				=	0;
    char        sDbUser[32]           = {0};   //数据库用户
    char        sDbPass[32]           = {0};   //数据库密码
    char        sDbSid[128]           = {0};   //数据库服务名
    int         iConnPoolMinSize      = 0;     //连接池中最小连接数
    int         iConnPoolMaxSize      = 0;     //连接池中最大连接数
    int         iNoConnWaitTime       = 0;     //取不到连接时等待时间
    int         iConnPoolSize         = 0;     //连接池中初始连接数
    int         iThreadPoolSize       = 0;     //线程池中线程数
    int         iThreadPoolTaskSize   = 0;     //线程池任务数
     //加载配置文件 
    CConfigParser& cCfg = CConfigParser::getInstance();
	try
	{
				
		cCfg.loadConfig("../cfg/pmts.xml");
    	
    	//初始化日志 
		//ZFPTLOG.setCfgInfo(cCfg.getOption("LOGPATH"), "parsertest", (LOG_LEVEL)atoi(cCfg.getOption("LOGLVL")));
        iRet = g_LogObj.initialize("../log", 
                5, 
                "parsertest",		    // application name
                R_NOSOCKET,	            // Listen the control port
                0,				        // availabel only if R_SOCKET
                9999,			        // Control manager port
                M_SYNC		            // output mode 1-M_SYNC 2-M_ASYNC
                );
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化日志...");		
        
		iConnPoolMinSize = atoi(cCfg.getOption("CONNPOOLMINSIZE"));
        iConnPoolMaxSize = atoi(cCfg.getOption("CONNPOOLMAXSIZE"));
        iNoConnWaitTime	 = atoi(cCfg.getOption("NOCONNWAITTIME"));
        iConnPoolSize    = atoi(cCfg.getOption("CONNPOOLSIZE"));

        strncpy(sDbUser,cCfg.getOption("DBUSER"), sizeof(sDbUser)-1);
        strncpy(sDbPass,cCfg.getOption("DBKEY") , sizeof(sDbPass)-1);
        strncpy(sDbSid,cCfg.getOption("DBNAME") , sizeof(sDbSid) -1);
		
        //创建连接池 
        g_DBConnPool = new CConnectPool(iConnPoolMinSize,iConnPoolMaxSize,iNoConnWaitTime);
		
       
        iRet= g_DBConnPool->InitPool(iConnPoolSize,sDbUser,sDbPass,sDbSid);
		
        if(iRet == RTN_SUCCESS)
        {
            //ZFPT_LOG << eSystem << "连接池创建成功" << endl;	
            printf("连接池创建成功\n");
        }
        else
        {
            //ZFPT_LOG << eSystem << "连接池创建失败" << endl;	
            printf("连接池创建失败\n");
            return RTN_FAIL;
        }
        
	}catch(CException &e)
    {
    	sprintf(sErrDesc, "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());
    	
        
    }
	char sMsg[1024 * 10] = {0};
	char sCmt100[256] = {0};
	char sHvps111[256] = {0};
	char sHvps1112[256] = {0};
	char sPkg001[256] = {0};
	char sBeps121[256] = {0};
	
	strncpy(sCmt100,"/ncb/pmts/mqtest/file/hvps/cmt100.txt",sizeof(sCmt100)-1);
	strncpy(sHvps111,"/ncb/pmts/mqtest/file/hvps/hvps.111.001.01.xml",sizeof(sHvps111)-1);
	strncpy(sHvps1112,"/ncb/pmts/mqtest/file/hvps/hvps111",sizeof(sHvps1112)-1);
	strncpy(sPkg001,"/ncb/pmts/mqtest/file/beps/pkg001",sizeof(sPkg001)-1);
	strncpy(sBeps121,"/ncb/pmts/mqtest/file/beps/beps.121.001.01.xml",sizeof(sBeps121)-1);
    iRet = getFileText(sBeps121,sMsg);
    if(0 != iRet)
    {
   		printf("读取报文失败[%d]\n",iRet);
   		return -1;
    }
    
    
	pack();
	
    //unPack(sMsg);
    
	//digitSignTest();
	
	//parsePkg001(sMsg);
	
	//packPkg001();
	
	setsid();  //退出前设置会话session组id,防止影响其子进程 
	
   	
	return RTN_SUCCESS;
}
	
