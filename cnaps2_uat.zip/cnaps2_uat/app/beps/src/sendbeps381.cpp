/******************************************************************** 
�ļ����� sendbeps381.cpp
�����ˣ� handongfeng
��  ��   �� 2011-03-07
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps381.h"


CSendBeps381::CSendBeps381(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
}

CSendBeps381::~CSendBeps381()
{
}

void CSendBeps381::AddSign381()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms381::AddSign381");

	char   sSignedStr[4096 + 1] = {0};
	
	m_beps381.getOriSignStr();
	
	AddSign(m_beps381.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_colltnchrgscl.m_instgdrctpty.c_str());
	
	m_beps381.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, 
	            NULL, "leaving CRecvCcms381::AddSign381");
}

void CSendBeps381::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBeps381::SetDBKey...");

	m_colltnchrgscl.m_msgid = m_sMsgId; 
	m_colltnchrgscl.m_instgpty = m_sSendOrg; 
	m_colltnchrgscl.m_srcflag = "1"; 
	m_colltnchrgslist.m_msgid = m_sMsgId; 

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, 
            "m_colltnchrgscl.m_msgid = %s", m_colltnchrgscl.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, 
            "m_colltnchrgscl.m_instgpty = %s", m_colltnchrgscl.m_instgpty.c_str());
            
    Trace(L_INFO,  __FILE__,  __LINE__, 
            NULL, "LEAVE CSendBeps381::SetDBKey...");        
}

int CSendBeps381::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "ENTER CSendBeps381::UpdateState");

    string strNpcMsg = "";
	if(!m_colltnchrgscl.write_blob(m_beps381.m_sXMLBuff.c_str(), strNpcMsg, SYS_BEPS)){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"д���ֶα�����:[%s]", m_colltnchrgscl.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}

    string strSQL;
	strSQL += "UPDATE bp_colltnchrgscl t SET t.STATETIME = sysdate, t.PROCSTATE = '08'";
	strSQL += ", t.MESGID = '";
    strSQL += m_sMesgID;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgID;
    strSQL += "', t.NPCMSG='";
    strSQL += strNpcMsg;
    strSQL += "' ";
    
    strSQL += "WHERE t.MSGID = '";
	strSQL += m_colltnchrgscl.m_msgid.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_colltnchrgscl.m_instgpty.c_str();
	strSQL += "' AND t.SRCFLAG = '1'";
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    SETCTX(m_colltnchrgscl);
    int iRet = m_colltnchrgscl.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��,  iRet=%d, %s", iRet, m_colltnchrgscl.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "LEAVE CSendBeps381::UpdateState");
    return iRet;
}

void CSendBeps381::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "ENTER CSendBeps381::UpdateState");
    
    SETCTX(m_colltnchrgslist);

    m_beps381.MsgId = m_colltnchrgscl.m_msgid; 
    m_beps381.InstgDrctPty   = m_colltnchrgscl.m_instgdrctpty; 
    m_beps381.GrpHdrInstgPty = m_colltnchrgscl.m_instgdrctpty; 

    m_beps381.InstdDrctPty   = m_colltnchrgscl.m_instddrctpty;
    m_beps381.GrpHdrInstdPty = m_colltnchrgscl.m_instddrctpty;  
 
    m_beps381.Rmk   = m_colltnchrgscl.m_rmk; 
    m_beps381.SysCd = m_colltnchrgscl.m_syscd; 
    
    int iRet = GetIsoDateTime(m_dbproc, SYS_HVPS, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }
    
    m_beps381.CreDtTm    = m_ISODateTime;
    
    char tmp[64]={0};
    m_beps381.OrgnlMsgId    = m_colltnchrgscl.m_orgnlmsgid;    // ԭ���ı�ʶ��
    m_beps381.OrgnlInstgPty = m_colltnchrgscl.m_orgnlinstgpty; //ԭ����������
    m_beps381.OrgnlBtchNb   = m_colltnchrgscl.m_orgnlbtchnb;   //ԭ�������
    m_beps381.OrgnlTrnsmtDt = m_colltnchrgscl.m_orgnltrnsmtdt; //ԭת������
    
    sprintf(tmp,"%d",m_colltnchrgscl.m_orgnlrtrltd);
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "___tmp=%s", tmp);
    m_beps381.OrgnlRtrLtd = tmp; //ԭ��ִ����
    
    memset(tmp,0,sizeof(tmp));
    sprintf(tmp,"%.2f",m_colltnchrgscl.m_orgnlttlam);
    m_beps381.OrgnlTtlAmt = tmp; //ԭ�ܽ�� 
    
    m_beps381.OrgnlTtlAmtCcy = m_colltnchrgscl.m_currency;
    memset(tmp,0,sizeof(tmp));
    sprintf(tmp,"%d",m_colltnchrgscl.m_orgnlttlnb);
    m_beps381.OrgnlTtlNb = tmp; //ԭ�ܱ���
    
    memset(tmp,0,sizeof(tmp));
    sprintf(tmp,"%.2f", m_colltnchrgscl.m_rcvsndgttlamt);
    m_beps381.RcvgTtlAmt = tmp; //�ɹ������ܽ��
    memset(tmp,0,sizeof(tmp));
    
    sprintf(tmp,"%d",m_colltnchrgscl.m_rcvsndgttlnb);
    m_beps381.RcvgTtlNb = tmp; // �ɹ������ܱ���
    m_beps381.RcvgTtlAmtCcy = m_colltnchrgscl.m_currency;    //�ɹ������ܽ����ҷ���
    m_beps381.OrgnlTxTpCd   = m_colltnchrgscl.m_orgnltxtpcd; //ԭҵ�����ͱ���
    m_beps381.CdtrAgtId     = m_colltnchrgscl.m_cdbtrbrnchid;//�տ����к�
    m_beps381.CdtrNm        = m_colltnchrgscl.m_cdbtrnm;     //�տ�������
    m_beps381.CdtrAcctId    = m_colltnchrgscl.m_cdbtrid;     //�տ����˺�

    //string whereClause;
    //whereClause = "MSGID = '" + m_colltnchrgslist.m_msgid + "'" + "and SRCFLAG ='1'";
    
    string whereClause = "";
    whereClause += " msgid='";
    whereClause += m_colltnchrgscl.m_msgid;
    whereClause += "' and instgpty='";
    whereClause += m_colltnchrgscl.m_instgpty;
    whereClause += "' and srcflag='1' ";
    
    Trace(L_DEBUG, __FILE__, __LINE__, m_sMsgId, 
            "__whereClause=[%s]", whereClause.c_str());
    
    if(0==m_colltnchrgslist.find(whereClause))
    {
        while(0 == m_colltnchrgslist.fetch())
        {
            m_beps381.Sts              = m_colltnchrgslist.m_busistate;//ҵ��״̬
            m_beps381.RjctCd           = m_colltnchrgslist.m_rjctcd;   //ҵ��ܾ�������
            m_beps381.RspsnInfRjctInf  = m_colltnchrgslist.m_rjctinf;  //ҵ��ܾ���Ϣ
            m_beps381.PrcPty           = m_colltnchrgslist.m_rjctprcpty;//ҵ�����������
            m_beps381.TxId             = m_colltnchrgslist.m_txid;     //��ϸ��ʶ��
            m_beps381.DbtrNm           = m_colltnchrgslist.m_dbtrnm;   //�����˻���
            m_beps381.DbtrAcctId       = m_colltnchrgslist.m_dbtrid;   //�������˺�
            m_beps381.RcvgDtlsBrnchId  = m_colltnchrgslist.m_dbtrbrnchid;//�������к�
            sprintf(tmp, "%.2f", m_colltnchrgslist.m_amout);
            Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__tmp=[%s]", tmp);
            m_beps381.Amt              = tmp;//��� 
            m_beps381.AmtCcy           = m_colltnchrgslist.m_currency;//���ҷ���
            m_beps381.OrgnlCtgyPurpCd  = m_colltnchrgslist.m_orgnlctgypurpcd;//ҵ���������
            m_beps381.AddtlInf         = m_colltnchrgslist.m_addtlinf;//����
            
            m_beps381.AddDetail();
        }
        m_colltnchrgslist.closeCursor();
    }
    
    // ���ļ�ͷ
    m_beps381.CreateXMlHeader("BEPS",                       
                    m_colltnchrgscl.m_workdate.c_str(), 
                    m_colltnchrgscl.m_instgdrctpty.c_str(),
                    m_colltnchrgscl.m_instddrctpty.c_str(),
                    "beps.381.001.01",              \
                    m_sMesgID);
 
    

    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "LEAVE CSendBeps381::UpdateState");
    return ;
}

INT32 CSendBeps381::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "ENTER CSendBeps381::doWorkSelf");

    bool bRet = GetMsgIdValue(m_dbproc, m_sMesgID, eRefId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��������");
        PMTS_ThrowException(PRM_FAIL);
    }

    /*��ҵ����л�ȡ����*/
    int iRet = 0;
    
    GetData();
    
    SetData();

    //��ǩ
    AddSign381();
    
    iRet = m_beps381.CreateXml();
    if(RTN_SUCCESS != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    /*�޸�״̬*/
    UpdateState();

    

    m_sMsgTxt = m_beps381.m_sXMLBuff;
    
    AddQueue();
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "LEAVE CSendBeps381::doWorkSelf"); 
    return 0;
}


int CSendBeps381::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "ENTER CSendBeps381::GetData");
    
	SETCTX(m_colltnchrgscl);
	SetDBKey();
  	iRet = m_colltnchrgscl.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��, iRet = %d", iRet);
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    //����ԭҵ��
	/*m_Orgncolltnchrgscl.m_msgid = m_colltnchrgscl.m_orgnlmsgid; 
	m_Orgncolltnchrgscl.m_instgpty = m_colltnchrgscl.m_orgnlinstgpty; 
	m_Orgncolltnchrgscl.m_srcflag = "1";

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, 
        "m_Orgncolltnchrgscl.m_msgid = %s", m_Orgncolltnchrgscl.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, 
        "m_Orgncolltnchrgscl.m_instgpty = %s", m_Orgncolltnchrgscl.m_instgpty.c_str());

  	iRet = m_Orgncolltnchrgscl.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��, iRet = %d", iRet);
        PMTS_ThrowException(DB_NOT_FOUND);
    }*/
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "LEAVE CSendBeps381::GetData"); 
	return iRet;
}


int CSendBeps381::ChargeMB()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBeps381::ChargeMB...");

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBeps381::ChargeMB..."); 
    
    return RTN_SUCCESS;
}

int CSendBeps381::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBeps381::FundSettle...");
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û�[%s]", m_szOprUser);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_sSendOrg);

	m_charge.m_amount = m_colltnchrgscl.m_ttlamt;	//ҵ����
	m_charge.m_iDCFlag = iDEBITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, m_szOprUserNetId);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_sSendOrg);	//������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(RTN_SUCCESS != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FundSettle iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBeps381::FundSettle..."); 
    
    return RTN_SUCCESS;
}

