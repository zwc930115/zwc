/*
 *  sendbeps385.cpp
 *  Description:
 *  Created on: 2012-06-25
 *  Author: __wsh
 */

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps385.h"


CSendBeps385::CSendBeps385(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
}

CSendBeps385::~CSendBeps385()
{
}

//__wsh 2012-06-25 业务处理入口
INT32 CSendBeps385::doWorkSelf(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			m_sMsgId, "Enter CSendBeps385::doWorkSelf");

	int iRet = -1;

	//获取数据
	iRet = GetData();

	//设置XML报文数据
	SetData();

	//构建XML报文
	iRet = BuildPmtsMsg();

	//更新数据库状态
	iRet = UpdateState();

	//发送XML报文
	iRet = AddQueue();

	Trace(L_INFO, __FILE__, __LINE__,
			m_sMsgId, "Leave CSendBeps385::doWorkSelf");

	return iRet;
}

//__wsh 2012-06-25 获取业务数据
int CSendBeps385::GetData(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			m_sMsgId, "Enter CSendBeps385::GetData");

	int iRet = -1;

	//获取汇总表数据
	SETCTX(m_colltncl);
	//主键查找
	m_colltncl.m_msgid    = m_sMsgId;
	m_colltncl.m_instgpty = m_sSendOrg;
	m_colltncl.m_srcflag  = "1";

	iRet = m_colltncl.findByPK();
	if(SQL_SUCCESS != SQL_SUCCESS){
		sprintf(m_sErrMsg,
			"[bp_colltnchrgscl]查询失败[%s][%s] iRet=%d cause=%s",
			m_sMsgId, m_sSendOrg, m_colltncl.GetSqlErr());

		Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId, m_sErrMsg);

		PMTS_ThrowException(DB_FIND_BY_PK_FAIL);
	}

	//获取明细表数据, 一笔业务只有一条明细， 由于TXID未知，不能用主键查询
	SETCTX(m_colltnlist);
	//使用条件查找
	string strSql = "msgid='";
	strSql += m_sMsgId;
	strSql += "' and instgpty='";
	strSql += m_sSendOrg;
	strSql += "' and srcflag='1' ";
	Trace(L_DEBUG, __FILE__, __LINE__, m_sMsgId, strSql.c_str());
	iRet = m_colltnlist.find(strSql);
	if(SQL_SUCCESS == iRet){
		iRet = m_colltnlist.fetch();
		m_colltnlist.closeCursor();
	}

	if(SQL_SUCCESS != SQL_SUCCESS){
		sprintf(m_sErrMsg,
			"[bp_colltnchrgslist]查询失败[%s][%s] iRet=%d cause=%s",
			m_sMsgId, m_sSendOrg, m_colltncl.GetSqlErr());

		Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId, m_sErrMsg);

		PMTS_ThrowException(DB_FIND_BY_PK_FAIL);
	}


	Trace(L_INFO, __FILE__, __LINE__,
			m_sMsgId, "Leave CSendBeps385::GetData");

	return iRet;
}

//__wsh 2012-06-25 设置XML报文数据
void CSendBeps385::SetData(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			m_sMsgId, "Enter CSendBeps385::SetData");

	int iRet = -1;
	//获取报文创建日期时间
	iRet = GetIsoDateTime(m_dbproc, SYS_BEPS, m_ISODateTime);
	if(iRet != RTN_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__,
					NULL, "获取iso datetime失败！");
		PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
	}

	//业务头
	m_cBeps385.MsgId            = m_colltncl.m_msgid;
	m_cBeps385.CreDtTm          = m_ISODateTime;
	m_cBeps385.InstgDrctPty     = m_colltncl.m_instgdrctpty;
	m_cBeps385.GrpHdrInstgPty   = m_colltncl.m_instgdrctpty;
	m_cBeps385.InstdDrctPty     = m_colltncl.m_instddrctpty;
	m_cBeps385.GrpHdrInstdPty   = m_colltncl.m_instddrctpty;
	m_cBeps385.SysCd            = m_colltncl.m_syscd;
	m_cBeps385.Rmk              = m_colltncl.m_rmk;

	//原业务信息
	m_cBeps385.OrgnlMsgId    = m_colltncl.m_orgnlmsgid;    //原报文标识
	m_cBeps385.OrgnlInstgPty = m_colltncl.m_orgnlinstgpty; //原发起行
	m_cBeps385.OrgnlBtchNb   = m_colltncl.m_orgnlbtchnb;   //原批次号
	m_cBeps385.TxId          = m_colltnlist.m_txid;        //原明细标识

	//应答信息
	m_cBeps385.Sts             = m_colltnlist.m_busistate;
	m_cBeps385.RjctCd          = m_colltnlist.m_rjctcd;
	m_cBeps385.RspsnInfRjctInf = m_colltnlist.m_rjctinf;
	m_cBeps385.PrcPty          = m_colltnlist.m_rjctprcpty;

	//明细
	m_cBeps385.DbtrNm     = m_colltnlist.m_dbtrnm;      //付款人名称
	m_cBeps385.DbtrAcctId = m_colltnlist.m_dbtrid;      //付款人账号
	m_cBeps385.DbtrAgtId  = m_colltnlist.m_dbtrbrnchid; //付款行行号

	m_cBeps385.CdtrAgtId  = m_colltncl.m_cdbtrbrnchid;  //收款行行号
	m_cBeps385.CdtrNm     = m_colltncl.m_cdbtrnm;       //收款人名称
	m_cBeps385.CdtrAcctId = m_colltncl.m_cdbtrid;       //收款人账号

	m_cBeps385.Ccy        = m_colltnlist.m_currency;    //货币符号
	char szAmt[32] = {0};
	sprintf(szAmt, "%.2f", m_colltnlist.m_amout);
	m_cBeps385.Amt           = szAmt; //金额
	m_cBeps385.CtgyPurpPrtry = m_colltncl.m_ctgyprtry;//业务类型
	m_cBeps385.PurpPrtry     = m_colltnlist.m_puryprtry; //业务种类

	Trace(L_INFO, __FILE__, __LINE__,
			m_sMsgId, "Leave CSendBeps385::SetData");
}

//__wsh 2012-06-25 385往报加签
void CSendBeps385::AddSign385(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Enter AddSign385");

	char   sSignedStr[4096 + 1] = {0};

	m_cBeps385.getOriSignStr();

	AddSign(m_cBeps385.m_sSignBuff.c_str(),
			sSignedStr,
			RAWSIGN,
			m_colltncl.m_instgdrctpty.c_str());

	m_cBeps385.m_szDigitSign = sSignedStr;

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Leave AddSign385");
}

//__wsh 2012-06-25 构建XML报文
int CSendBeps385::BuildPmtsMsg(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			m_sMsgId, "Enter CSendBeps385::BuildPmtsMsg");

	int iRet = -1;

	//获取通信参与号
	if( !GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS) ){
		Trace(L_ERROR, __FILE__, __LINE__,
				m_sMsgId, "获取通信参与号出错!");
		PMTS_ThrowException(PRM_FAIL);
	}

	//创建消息头
	m_cBeps385.CreateXMlHeader(
				"BEPS",
				m_sWorkDate,
				m_sSendOrg,
				m_colltncl.m_instddrctpty.c_str(),
				"beps.385.001.01",
				m_sMsgRefId);

	//加签
	AddSign385();

	//创建XML报文
	iRet = m_cBeps385.CreateXml();
	if(RTN_SUCCESS != iRet){
		Trace(L_ERROR,  __FILE__,  __LINE__,
				NULL, "创建报文失败,iRet=%d", iRet);
		PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
	}

	m_sMsgTxt = m_cBeps385.m_sXMLBuff.c_str();

	Trace(L_INFO, __FILE__, __LINE__,
			m_sMsgId, "Leave CSendBeps385::BuildPmtsMsg");

	return iRet;
}

int CSendBeps385::UpdateState(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CSendBeps392::UpdateState");

	int iRet = -1;

	string strNpcMsg = "";
	if(!m_colltncl.write_blob(m_cBeps385.m_sXMLBuff.c_str(), strNpcMsg, SYS_BEPS)){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"写大字段表出错:[%s]", m_colltncl.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}

	//更新汇总表状态
	string strSqlCl = " update bp_colltnchrgscl set procstate='";
	strSqlCl += PR_HVBP_08;
	strSqlCl += "', npcmsg='";
	strSqlCl += strNpcMsg;
	strSqlCl += "', mesgid='";
	strSqlCl += m_sMsgRefId;
	strSqlCl += "', mesgrefid='";
	strSqlCl += m_sMsgRefId;
	strSqlCl += "', statetime=sysdate where msgid='";
	strSqlCl += m_colltncl.m_msgid;
	strSqlCl += "' and instgdrctpty='";
	strSqlCl += m_colltncl.m_instgdrctpty;
	strSqlCl += "' and srcflag=1 ";

	Trace(L_DEBUG, __FILE__, __LINE__, m_sMsgId,
			"__strSqlCl=[%s]", strSqlCl.c_str());

	iRet = m_colltncl.execsql(strSqlCl.c_str());
	if(SQL_SUCCESS != iRet){

		sprintf(m_sErrMsg, "[bp_colltnchrgscl]更新出错，iRet=%d cause=%s",
				iRet, m_colltncl.GetSqlErr());

		Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId,
				"更新异常：%s", m_sErrMsg);

		PMTS_ThrowException(
				__FILE__, __LINE__, DB_UPDATE_FAIL, m_sErrMsg);
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CSendBeps392::UpdateState");

	return iRet;
}
