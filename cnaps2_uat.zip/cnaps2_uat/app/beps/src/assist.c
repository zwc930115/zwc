#include "assist.h"
#ifndef WIN32
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#endif

void dump_char (const char *str, void *buf, int len)
{
    int i;
    unsigned char *pkg = (unsigned char *)buf;
    printf ("%s(%d bytes):\n", str, len);
    for (i = 0; i < len; i++)
        printf ("%02x", pkg[i]);
    printf ("\n");
}

void dump_int (const char *str, void *buf, int len)
{
    int i;
    unsigned int *pkg = (unsigned int *)buf;
    printf ("%s(%d ints):\n", str, len);
    for (i = 0; i < len; i++)
        printf ("%08x ", pkg[i]);
    printf ("\n");
}

int str2hex (int len, char *str, unsigned char *hex)
{
    int i, j;
    for (i = 0; i < len; i = i + 2)
    {
        sscanf ((char *) &(str[i]), "%2x", &j);
        hex[i / 2] = j;
    }
    return len / 2;
}

int hex2str(int length,unsigned char *hex,unsigned char *str)
{
	int i,flag,j=0;
	for(i=0;i<length;i++)
	{
		str[j]=hex[i]>>4;
		flag=(int)str[j];
		if(flag<10) {flag+=48;str[j]=(char)flag;}
			else {flag+=55;str[j]=(char)flag;}
		j++;
		str[j]=hex[i]&0x0f;
		flag=(int)str[j];
		if(flag<10) {flag+=48;str[j]=(char)flag;}
		else {flag+=55;str[j]=(char)flag;}
		j++;
	}
	return length*2;
}

void converseStr(void *buf,int byteLen)
{
	int i;
	char temp;
	unsigned char *str = (unsigned char *)buf;

	for (i=0;i<byteLen/2;i++)
	{
		temp=str[i];
		str[i]=str[byteLen-1-i];
		str[byteLen-1-i]=temp;
	}
	return;
}

void convcpy(void *dst, void *src, int bytelen)
{
	int i;
	unsigned char *out = (unsigned char *)dst;
	unsigned char *in = (unsigned char *)src;

	for (i = 0; i < bytelen; i++)
	{
		out[i] = in[bytelen - 1 - i]; 
	}
	return;
}


#if 0
#define rotr32(x,n)   (((x) >> ((int)(n))) | ((x) << (32 - (int)(n))))
#define rotl32(x,n)   (((x) << ((int)(n))) | ((x) >> (32 - (int)(n))))
#define invert32(x)   (rotl32(x, 8) & 0x00ff00ff | rotr32(x, 8) & 0xff00ff00)
#define rotr16(x,n)   (((x) >> ((int)(n))) | ((x) << (16 - (int)(n))))
#define rotl16(x,n)   (((x) << ((int)(n))) | ((x) >> (16 - (int)(n))))
#define invert16(x)   (rotl16(x, 8) & 0x00ff | rotr16(x, 8) & 0xff00)
#endif
void converse(unsigned int *p, int count)
{
	int i;
	for(i = 0; i < count; i++)
		p[i] = invert32(p[i]);
}


#ifdef __BIG_ENDIAN_SYS__
unsigned int htole32(unsigned int n)
{
    unsigned char *q = (unsigned char *)&n;
    return ((unsigned long)q[0]) +
        (((unsigned long)q[1]) << 8) +
        (((unsigned long)q[2]) << 16) +
        (((unsigned long)q[3]) << 24);	
}
unsigned int letoh32(unsigned int n)
{
    unsigned char *q = (unsigned char *)&n;
    return ((unsigned long)q[0]) +
        (((unsigned long)q[1]) << 8) +
        (((unsigned long)q[2]) << 16) +
        (((unsigned long)q[3]) << 24);	
}
#else
unsigned int htole32(unsigned int n)
{
    return n;	
}
unsigned int letoh32(unsigned int n)
{
    return n;
}
#endif


#ifdef WIN32
long
getMsTime (void)
{
    LARGE_INTEGER freq;
    LARGE_INTEGER now;
    
    QueryPerformanceFrequency (&freq);
    QueryPerformanceCounter (&now);
    
    now.QuadPart *= 1000;
    now.QuadPart /= freq.QuadPart;
    return (long) now.QuadPart;
}

LARGE_INTEGER getFILETIMEoffset ()
{
    SYSTEMTIME s;
    FILETIME f;
    LARGE_INTEGER t;
    
    s.wYear = 1970;
    s.wMonth = 1;
    s.wDay = 1;
    s.wHour = 0;
    s.wMinute = 0;
    s.wSecond = 0;
    s.wMilliseconds = 0;
    SystemTimeToFileTime (&s, &f);
    t.QuadPart = f.dwHighDateTime;
    t.QuadPart <<= 32;
    t.QuadPart |= f.dwLowDateTime;
    return (t);
}

//lulu copy from lmbench-3.0
int
gettimeofday (struct timeval *tv, struct timezone *not_used)
{
    LARGE_INTEGER t;
    FILETIME f;
    double microseconds;
    static LARGE_INTEGER offset;
    static double frequencyToMicroseconds;
    static int initialized = 0;
    static BOOL usePerformanceCounter = 0;
    
    if (!initialized)
    {
        LARGE_INTEGER performanceFrequency;
        initialized = 1;
        usePerformanceCounter =
            QueryPerformanceFrequency (&performanceFrequency);
        
        if (usePerformanceCounter)
        {
            QueryPerformanceCounter (&offset);
            frequencyToMicroseconds =
                (double) performanceFrequency.QuadPart / 1000000.;
            
        }
        else
        {
            offset = getFILETIMEoffset ();
            frequencyToMicroseconds = 10.;
        }
    }
    if (usePerformanceCounter)
        QueryPerformanceCounter (&t);
    else
    {
        GetSystemTimeAsFileTime (&f);
        t.QuadPart = f.dwHighDateTime;
        t.QuadPart <<= 32;
        t.QuadPart |= f.dwLowDateTime;
    }
    
    t.QuadPart -= offset.QuadPart;
    microseconds = (double) t.QuadPart / frequencyToMicroseconds;
    t.QuadPart = microseconds;
    tv->tv_sec = t.QuadPart / 1000000;
    tv->tv_usec = t.QuadPart % 1000000;
    return (0);
}
#endif /* WIN32 */

//返回当前时间，单位为秒
double
When ()
{
    struct timeval tp;
    gettimeofday (&tp, NULL);
    return ((double) tp.tv_sec + (double) tp.tv_usec * 1e-6);
}


//same as fgests but '\n'->0
void myfgets(char* buf,int len,FILE* fp)
{
    char *p;
    fgets(buf,len,fp);
    p=strrchr(buf,'\n');
    if(p)
        *p=0;
}

//从标准输入获得用户输入的整数，0x开头的是16进制数，否则是十进制数
int GetInputInt()
{
    char strbuf[17];
    int n;
    
    myfgets(strbuf,16,stdin);
    if (strbuf[0] == '0' && strbuf[1] == 'x')
        sscanf (strbuf + 2, "%x", &n);
    else
        n = atoi (strbuf);
    return n;                    	
}

//从标准输入获得hex
int GetInputBytes(unsigned char *buf, int maxlen)
{
	char *str;
	int len;

	str = (char *)malloc(maxlen * 2 + 1);
    myfgets(str, maxlen * 2 + 1, stdin);
    len = str2hex(strlen(str), str, buf);
	free(str);
	return len;
}

#ifdef WIN32
static int intr_flag = 0;
BOOL __stdcall
w32_intr_handler(DWORD dwCtrlType)
{
    if ( dwCtrlType == CTRL_C_EVENT ) {
        intr_flag = 1;
        return TRUE;
    } else {
        return FALSE;
    }
}

void input_password(char *passwd,int maxlen)
{	
    HANDLE in = CreateFile("CONIN$", GENERIC_READ|GENERIC_WRITE,
        0, NULL, OPEN_EXISTING, 0, NULL);
    HANDLE out = CreateFile("CONOUT$", GENERIC_WRITE,
        0, NULL, OPEN_EXISTING, 0, NULL);
    DWORD mode;
    int ret, bytes;
    char *p;
    
    if (in == INVALID_HANDLE_VALUE || out == INVALID_HANDLE_VALUE)
        printf("Cannot open console. (errno=%d)", GetLastError());
    
    SetConsoleCtrlHandler(w32_intr_handler, TRUE ); /* add handler */
    GetConsoleMode(in, &mode);
    SetConsoleMode(in, mode&~ENABLE_ECHO_INPUT); /* disable echo */
    ret = ReadFile(in, passwd, maxlen, &bytes, 0);
    p=strrchr(passwd,'\r');//'n'?
    if(p)
        *p=0;
    SetConsoleMode(in, mode);			/* enable echo */
    SetConsoleCtrlHandler( w32_intr_handler, FALSE ); /* remove handler */
    if ( intr_flag )
        GenerateConsoleCtrlEvent(CTRL_C_EVENT, 0); /* re-signal */
    WriteFile(out,"\n", 1, &bytes, 0);
    CloseHandle(in);
    CloseHandle(out);
}
#else
//输入口令回显到控制台为*号
void input_password(char *passwd,int maxlen)
{   
    int fd = -1;
    int i  = 0;
    struct termios term, termsave;
    char ch;
    
    fflush(NULL);   
    if ((fd = open("/dev/tty", O_RDWR | O_NOCTTY)) < 0)
    {
        return;
    }
    
    tcgetattr(fd, &term);
    tcgetattr(fd, &termsave);
    term.c_lflag &= ~(ICANON | ECHO | ISIG);
    tcsetattr(fd, TCSANOW, &term);
    read(fd, &ch, 1);
    while((ch != '\n') && (i < maxlen))
    {
        passwd[i] = ch;
        i++;
        tcsetattr(fd, TCSANOW, &termsave);
        write(fd, "*", 1);
        tcsetattr(fd, TCSANOW, &term);
        read(fd, &ch, 1);
    }
    tcsetattr(fd, TCSANOW, &termsave);
    passwd[i] = '\0';
    write(fd, "\n", 1);
    close(fd);
    return;
}
#endif


