/******************************************************************** 
文件名： recvbeps388.cpp
创建人： handongfeng
日  期： 2011-02-23
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif
#include "recvbeps388.h"

CRecvbeps388::CRecvbeps388()
{
    m_colltnchrgscl.m_msgtp = "beps.388.001.01";
    m_colltnchrgslist.m_msgtp = "beps.388.001.01";

}

CRecvbeps388::~CRecvbeps388()
{

}

int CRecvbeps388::Work(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps388::Work()");
 
    // 解析报文
    unPack(szMsg);
    
    UpdateState();
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps388::Work()");
    return OPERACT_SUCCESS;
}


void CRecvbeps388::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps388::SetDBKey...");

	m_colltnchrgscl.m_msgid = m_beps388.OrgnlMsgId; 
	m_colltnchrgscl.m_instgpty = m_beps388.OrgnlInstgPty; 

	m_colltnchrgslist.m_msgid = m_beps388.OrgnlMsgId; 
	m_colltnchrgslist.m_instgpty = m_beps388.OrgnlInstgPty; 

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_colltnchrgscl.m_msgid = %s", m_colltnchrgscl.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_colltnchrgscl.m_instgpty = %s", m_colltnchrgscl.m_instgpty.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps388::SetDBKey...");        
}

int CRecvbeps388::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "ENTER CRecvbeps388::UpdateState");

    SETCTX(m_colltnchrgscl);
    SetDBKey();

    char m_sMsgRefId[20+1] = {0};
    bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);

    string strSQL;
	strSQL += "UPDATE bp_colltnchrgscl t SET t.STATETIME = sysdate, t.PROCSTATE = '08' , t.BUSISTATE = 'PR09'";
	strSQL += ", t.MESGID = '";
    strSQL += m_sMsgRefId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMsgRefId;
    strSQL += "' ";
    
    strSQL += "WHERE t.MSGID = '";
	strSQL += m_colltnchrgscl.m_msgid.c_str();
	strSQL += "' AND t.instgpty = '";
	strSQL += m_colltnchrgscl.m_instgpty.c_str(); 									
	strSQL += "'";
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    int iRet = m_colltnchrgscl.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateState失败, iRet=%d, %s", iRet, m_colltnchrgscl.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }    

	strSQL += "UPDATE bp_colltnchrgslist t SET t.STATETIME = sysdate, t.PROCSTATE = '08' , t.BUSISTATE = 'PR09'";
	strSQL += ", t.MESGID = '";
    strSQL += m_sMsgRefId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMsgRefId;
    strSQL += "' ";
    
    strSQL += "WHERE t.MSGID = '";
	strSQL += m_colltnchrgslist.m_msgid.c_str();
	strSQL += "' AND t.instgpty = '";
	strSQL += m_colltnchrgslist.m_instgpty.c_str(); 									
	strSQL += "'";
    
    iRet = m_colltnchrgscl.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateState失败, iRet=%d, %s", iRet, m_colltnchrgslist.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }   

    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "LEAVE CRecvbeps388::UpdateState");
    return iRet;
}

INT32 CRecvbeps388::unPack(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps388::unPack()");
    
    int iRet = -1;
    
    // 报文是否为空
    if (NULL == szMsg || '\0' == szMsg)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");	
    	PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文为空");
    }
    
    //获取工作日期
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(iRet != RTN_SUCCESS)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");	
    	PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;    

    // 解析报文
    if (OPERACT_SUCCESS != m_beps388.ParseXml(szMsg))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错! iRet= %d", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文解析出错!");
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps388::unPack()");
    return OPERACT_SUCCESS;
}

void CRecvbeps388::CheckSign388()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms388::CheckSign388");

    m_beps388.getOriSignStr();
	
	CheckSign(m_beps388.m_sSignBuff.c_str(),
			m_beps388.m_szDigitSign.c_str(),
			m_beps388.InstgDrctPty.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms388::CheckSign388");
}


void CRecvbeps388::InsertData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbeps388::InsertData()");

    //MSGEID
    char m_MsgRefId[20+1] = {0};
    bool bRet = GetMsgIdValue(m_dbproc, m_MsgRefId, eRefId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "参数错误");
        PMTS_ThrowException(PRM_FAIL);
    }

    m_Bpbizpubntce.m_msgid = m_beps388.MsgId; 
    m_Bpbizpubntce.m_workdate = m_beps388.MsgId.substr(0, 7); 
    m_Bpbizpubntce.m_mesgid = m_MsgRefId; 
    m_Bpbizpubntce.m_mesgrefid = m_MsgRefId; 
    m_Bpbizpubntce.m_instgdrctpty = m_beps388.InstdDrctPty; 
    m_Bpbizpubntce.m_instgpty = m_beps388.GrpHdrInstdPty; 
    m_Bpbizpubntce.m_instddrctpty = m_beps388.InstgDrctPty; 
    m_Bpbizpubntce.m_instdpty = m_beps388.GrpHdrInstgPty; 
    m_Bpbizpubntce.m_syscd = "BEPS"; 
    //m_Bpbizpubntce.m_rmk = ; 
    m_Bpbizpubntce.m_orgnlmsgid = m_beps388.OrgnlMsgId; 
    m_Bpbizpubntce.m_orgnlinstgpty = m_beps388.OrgnlInstgPty; 
    m_Bpbizpubntce.m_orgnlbtchnb = atoi(m_beps388.OrgnlBtchNb.c_str()); 
    m_Bpbizpubntce.m_status = m_beps388.Sts;
    m_Bpbizpubntce.m_rjctcd = m_beps388.RjctCd;
    m_Bpbizpubntce.m_rjcprcpty = m_beps388.PrcPty; 
    m_Bpbizpubntce.m_rjctinf = m_beps388.RjctInf; 
    m_Bpbizpubntce.m_procstate = PR_HVBP_07; //已回执
    m_Bpbizpubntce.m_proctime = ""; 
    m_Bpbizpubntce.m_addtlinf = m_beps388.AddtlInf; 

    SETCTX(m_Bpbizpubntce);
    int iRet = m_Bpbizpubntce.insert();
    if (OPERACT_SUCCESS != iRet)
    { 
        sprintf(m_szErrMsg,"insert() error,error code = [%d],error cause = [%s]",iRet,m_Bpbizpubntce.GetSqlErr());	  
        Trace(L_INFO,  __FILE__,	__LINE__, NULL, m_szErrMsg);	  
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL,m_szErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbeps388::InsertData()");
}
