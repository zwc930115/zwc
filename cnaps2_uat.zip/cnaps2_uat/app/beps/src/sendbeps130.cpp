/******************************************************************** 
�ļ����� sendbeps130.cpp
�����ˣ� hq
��  �ڣ� 2011-04-07
�޸��ˣ� 
��  �ڣ� 
��  ���� CISͨ�û�ִҵ����< beps.130.001.01>���˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps130.h"

using namespace ZFPT;

CSendBeps130::CSendBeps130(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
    memset(m_sPkgNo, 0x00, sizeof(m_sPkgNo));
}

CSendBeps130::~CSendBeps130()
{

}

INT32 CSendBeps130::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps130::doWorkSelf");

    //��ҵ����л�ȡ����
    GetData();
	
    //����������
    UpdatePkg();
    
    //�޸�״̬/NPCMSG
    UpdateSndList(PR_HVBP_03);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps130::doWorkSelf"); 
    return 0;
}

INT32 CSendBeps130::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps130::GetData");

    SETCTX(m_cBpbcsndlist);
    m_cBpbcsndlist.m_dbtrbrnchid = m_sSendOrg;
    m_cBpbcsndlist.m_txid = m_sMsgId;

    iRet = m_cBpbcsndlist.findByPK();
    if (SQLNOTFOUND == iRet)
    {
        sprintf(m_sErrMsg, "С�����ʴ�����ϸ�����Ҳ���ָ��ҵ��[%s][%s]", 
            m_sSendOrg, m_sMsgId);

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    } 	
    else if (SQL_SUCCESS != iRet) 
    {
        sprintf(m_sErrMsg,"��ѯС�����ʴ�����ϸ����������[%d][%s]",
            iRet, m_cBpbcsndlist.GetSqlErr());

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps130::GetData"); 

    return iRet;
}

INT32 CSendBeps130::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps130::CheckValues");

    int iRet = -1;
    
    //������޼��
    iRet = isOutOfLimit(m_dbproc, 
                        m_cBpbcsndlist.m_msgtp.c_str(), 
                        m_cBpbcsndlist.m_purpprtry.c_str(),
                        m_cBpbcsndlist.m_amount, 
                        m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_AMT_OUT_OF_LIMIT, m_sErrMsg);
    }
    
    //�����кż��
    iRet = isBankRight(m_dbproc, m_cBpbcsndlist.m_instddrctpty.c_str(), m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_RECVBANK_CHECK_FAIL, m_sErrMsg);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps130::CheckValues"); 
    return 0;
}

INT32 CSendBeps130::UpdatePkg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps130::UpdatePkg");

    strncpy(m_strAssist.sSendBank, m_cBpbcsndlist.m_instgdrctpty.c_str(), sizeof(m_strAssist.sSendBank) - 1);
    strncpy(m_strAssist.sRecvBank, m_cBpbcsndlist.m_instddrctpty.c_str(), sizeof(m_strAssist.sRecvBank) - 1);
    strncpy(m_strAssist.sMsgType,  m_cBpbcsndlist.m_msgtp.c_str(),        sizeof(m_strAssist.sMsgType)  - 1);
    
    m_strAssist.iPkgRtrltd = 0;
    strncpy(m_strAssist.sPmttpPrtry, "0", sizeof(m_strAssist.sPmttpPrtry) - 1);
    strncpy(m_strAssist.sIssr,       "0", sizeof(m_strAssist.sIssr)       - 1);
    strncpy(m_strAssist.sAcctId,     "0", sizeof(m_strAssist.sAcctId)     - 1);
    strncpy(m_strAssist.sOriMsgTp,   "0", sizeof(m_strAssist.sOriMsgTp)   - 1);
    strncpy(m_strAssist.sOriMsgId,   "0", sizeof(m_strAssist.sOriMsgId)   - 1);
    
    iRet = UpPKGAssist(m_sPkgNo);
    if (iRet != SQL_SUCCESS)
    {
        memcpy(m_sPkgNo, m_cBpbcsndlist.m_msgid.c_str(), sizeof(m_sPkgNo) - 1);
        sprintf(m_sErrMsg,  "UpPKGAssist is error,iRet=[%d][%s]", iRet, m_sPkgNo);
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps130::UpdatePkg");
    return 0;
}

INT32 CSendBeps130::UpdateSndList(LPCSTR sProcstate)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps130::UpdateSndList");

    memset(m_sSqlStr, 0x00, sizeof(m_sSqlStr));
    sprintf(m_sSqlStr, "UPDATE bp_bcoutsendlist t SET t.STATETIME = sysdate,"
                			"t.MSGID = '%s', "
                			"t.PROCSTATE = '%s'" 
                   			" WHERE t.txid = '%s'",
                			m_sPkgNo,
                			sProcstate,
                			m_sMsgId);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sSqlStr=[%s]",m_sSqlStr);

    iRet = m_cBpbcsndlist.execsql(m_sSqlStr);
    if (iRet != SQL_SUCCESS)
    {
        sprintf(m_sErrMsg,  "update bp_bcoutsendlist  is error!iRet=[%d][%s]", iRet, m_cBpbcsndlist.GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        if ( 0 == strcmp(sProcstate, PR_HVBP_95))
        {
            //��������ʱ�����쳣,������쳣������״̬,���ﲻ���쳣
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
        }
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps130::UpdateSndList");
    return 0;
}

INT32 CSendBeps130::SetErrACK(int iErrCode, LPCSTR pErrDesc)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps130::SetErrACK");

	//�޸�״̬Ϊ"���޸�"
    UpdateSndList(PR_HVBP_93);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps130::SetErrACK");
	return 0;
}

int CSendBeps130::ChargeMB()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBeps130::ChargeMB...");

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBeps130::ChargeMB..."); 
    
    return RTN_SUCCESS;
}

int CSendBeps130::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBeps130::FundSettle...");
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û�[%s]", m_szOprUser);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_sSendOrg);

	m_charge.m_amount = m_cBpbcsndlist.m_amount;	//ҵ����
	m_charge.m_iDCFlag = iDEBITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, m_szOprUserNetId);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_sSendOrg);	//������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(RTN_SUCCESS != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FundSettle iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBeps130::FundSettle..."); 
    
    return RTN_SUCCESS;
}

