/******************************************************************** 
�ļ����� sendbeps403.cpp
�����ˣ� aps-lel	
��  �ڣ� 2011-04-07
�޸��ˣ� 
��  �ڣ� 
��  ���� С������beps.403���Ĵ�����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps403.h"


CSendBeps403::CSendBeps403(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{

}

CSendBeps403::~CSendBeps403()
{

}

int CSendBeps403::updateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps403::updateState...");

	SETCTX(m_cBpinvcprtapply);
    string strSQL;
	strSQL += "UPDATE BP_INVCPRTAPPLY  t SET t.PROCTIME = sysdate, t.PROCSTATE = '08'";
	strSQL += ", t.mesgid='";
	strSQL += m_sMsgRefId;
	strSQL += "', t.mesgrefid='";
	strSQL += m_sMsgRefId; 
	strSQL += "' WHERE t.MSGID = '";
	strSQL += m_cBpinvcprtapply.m_msgid.c_str();
	strSQL += "' AND t.instgpty = '";
	strSQL += m_cBpinvcprtapply.m_instgpty.c_str(); 
	strSQL += "' and t.rsflag='1' ";	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());

	iRet = m_cBpinvcprtapply.execsql(strSQL.c_str());
	
    if(RTN_SUCCESS != iRet)
    {
		sprintf(m_sErrMsg,"execsql() error,error code = [%d],error cause = [%s]",iRet,m_cBpinvcprtapply.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_sErrMsg);

    }
   
    m_cBpinvcprtapply.commit();

    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "leave CSendBeps403::updateState...");
    return 0;
}

INT32 CSendBeps403::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps403::doWorkSelf");
    
    /*��ҵ����л�ȡ����*/
    
    GetData();
        
    /*��pmts����*/
    CreatePmtsMsg();
     
    /*�޸�״̬*/
    updateState();
    
    /*����Զ�̶���*/
    AddQueue();
    
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "leave CSendBeps403::doWorkSelf..."); 
    return 0;
}


int CSendBeps403::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps403::GetData...");
	
	SETCTX(m_cBpinvcprtapply);
	
  	m_cBpinvcprtapply.m_instgpty = m_sSendOrg;//���������
  	m_cBpinvcprtapply.m_msgid = m_sMsgId;      
  	m_cBpinvcprtapply.m_rsflag = "1";  
  	
  	iRet = m_cBpinvcprtapply.findByPK();
  	
	if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg,"findBypk() error,error code = [%d],error cause = [%s]",iRet,m_cBpinvcprtapply.GetSqlErr());
		
		Trace(L_INFO,  __FILE__,  __LINE__,NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "leave CSendBeps403::GetData..."); 
    
	return iRet;
}

int CSendBeps403::CreatePmtsMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps403::CreatePmtsMsg...");
    
	bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(PRM_FAIL);
    }

	m_beps403.CreateXMlHeader("BEPS", 
								m_sWorkDate,
								m_sSendOrg,
								m_cBpinvcprtapply.m_instddrctpty.c_str(),
				  				"beps.403.001.01",
				  				m_sMsgRefId);
				  					
	m_beps403.MsgId			     = m_cBpinvcprtapply.m_msgid ;
	m_beps403.CreDtTm 		     = m_sIsoWorkDate ;
	m_beps403.InstgDrctPty	     = m_cBpinvcprtapply.m_instgdrctpty ;
	m_beps403.GrpHdrInstgPty	 = m_cBpinvcprtapply.m_instgdrctpty ;
	m_beps403.InstdDrctPty	     = m_cBpinvcprtapply.m_instddrctpty ;
	m_beps403.GrpHdrInstdPty	 = m_cBpinvcprtapply.m_instddrctpty ;
	m_beps403.SysCd			     = "BEPS";
	m_beps403.Rmk 			     = m_cBpinvcprtapply.m_rmk ;
	m_beps403.CtgyPurpCd		 = m_cBpinvcprtapply.m_ctgypurpcd ;//ҵ���������
	m_beps403.CorprtnId	         = m_cBpinvcprtapply.m_corprtnid ;//��ҵ��ʶ
	m_beps403.UsrId 	         = m_cBpinvcprtapply.m_cusflag ;//�û���ʶ
	m_beps403.InvcDt 	         = m_cBpinvcprtapply.m_invcdt;//ҵ��������
	m_beps403.InvcId             = m_cBpinvcprtapply.m_invcid;//��Ʊ��ʶ
	
	int iRet = m_beps403.CreateXml();
	if (0 != iRet)
	{
		
		sprintf(m_sErrMsg,"�������˱���ʧ��iRet = [%d]! ",iRet);
		
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, m_sErrMsg);
	}
	
	
	m_sMsgTxt = m_beps403.m_sXMLBuff ;
	
	
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "leave CSendBeps403::CreatePmtsMsg..."); 
    
	return iRet;
}

