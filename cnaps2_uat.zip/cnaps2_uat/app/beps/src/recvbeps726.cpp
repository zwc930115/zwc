
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbeps726.h"

#define BC_SEND "SR00"
#define BC_RECV "SR01"

//�˺�ֻ���ڽ��������ı�������ϸ��, ������������
#define FIELD726(FIELD) Trace(L_DEBUG, __FILE__, __LINE__, \
		NULL, "__"#FIELD"=[%s]", (FIELD).c_str());\
		m_strTx2 += m_cBeps726.CHECKVALUE((FIELD))

using namespace ZFPT;

CRecvBeps726::CRecvBeps726()
{
    /*
    memset(m_szTblNm, 0x00, sizeof(m_szTblNm));
    m_strChkSt = "";
    m_bIsBiz   = false;
    m_iBizCnt  = 0;
    m_dCtrlSum = 0.0;
    m_strBizSt = "";
    m_strTx2   = "";
    */
}

CRecvBeps726::~CRecvBeps726()
{
}

//__wsh 2012-10-12 ���Ĵ������
int CRecvBeps726::Work(LPCSTR szMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CRecvBeps726::Work");

  #if 0
	int iRet = -1;

	//����Ԥ���˱���
	UnPack(szMsg);
	
	//���Ԥ����������
	ClearBeforeCheck();

	//Ԥ������ϸ���
	InsertData();

	//��ǩ
	CheckSign726();

	//ִ����ϸԤ����
	iRet = DealBeforeCheck();

	//�ͻ�֪ͨ
	InsertUserInfoTel();
	#endif

	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvBeps726::Work");
	return 0;
}
/*
//__wsh 2012-10-12 ����Ԥ���˱���
int CRecvBeps726::UnPack(LPCSTR szMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CRecvBeps726::UnPack");
	int iRet = -1;

	if(NULL == szMsg || '\0' == szMsg[0]){
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "���ĳ���Ϊ��");
		PMTS_ThrowException(PRM_FAIL);
	}

	//��������
	if (OPERACT_SUCCESS != m_cBeps726.ParseXml(szMsg)){
		Trace(L_ERROR,  __FILE__,  __LINE__,
				NULL, "���Ľ�������! iRet= %d", iRet);

		PMTS_ThrowException(__FILE__, __LINE__,
				OPT_PRS_MSG_FAIL, "���Ľ�������");
	}

	m_strWorkDate = m_sWorkDate;

    //Ԥ��������
	char szTmp[32] = {0}; 
	chgToDate(m_cBeps726.ChckDt.c_str(), szTmp);
	m_strChkDt = szTmp;
    //���Ľ��ղ�����
	m_strInstdDrctPty = m_cBeps726.InstdDrctPty;
    Trim(m_strInstdDrctPty);
    
	//ZFPTLOG.SetLogInfo("726", m_cBeps726.MsgId.c_str());

	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvBeps726::UnPack");
	return iRet;
}

//__wsh 2012-10-12 ���Ԥ��������
int CRecvBeps726::ClearBeforeCheck(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CRecvBeps726::ClearBeforeCheck");
    int iRet = -1;
    
    string strSql = "delete from bp_beforecheck where chkdt='";
    strSql += m_strChkDt;
    strSql += "' and instddrctpty='";
    strSql += m_strInstdDrctPty;
    strSql += "' ";
    
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strSql=[%s]", strSql.c_str());
    
    SETCTX(m_bpbc);
    iRet = m_bpbc.execsql(strSql);
    if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND){
        Trace(L_ERROR, __FILE__, __LINE__, NULL, 
            "[bp_beforecheck]ɾ��ʧ��:%s", m_bpbc.GetSqlErr());
        PMTS_ThrowException(DB_DEL_FAIL);
    }
    //�����ύ
    m_bpbc.commit();
    
    Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvBeps726::ClearBeforeCheck");
					
    return iRet;
}

//__wsh 2012-10-12 Ԥ������ϸ���
int CRecvBeps726::InsertData()
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CRecvBeps726::InsertData");
	int iRet = -1;

	//���������ҵ����Ԥ������ϸ
	m_strTx2 += m_cBeps726.CHECKVALUE(m_cBeps726.NbOfChckInf1);
	int iChkDtls1Num = atoi(m_cBeps726.NbOfChckInf1.c_str());
	this->m_bIsBiz = true;
	for(int iChk1 = 0; iChk1 < iChkDtls1Num; ++iChk1){
		GetChckInfDtls1(iChk1);
	}

	//�����������Ϣ��Ԥ������ϸ
	m_strTx2 += m_cBeps726.CHECKVALUE(m_cBeps726.NbOfChckInf2);
	int iChkDtls2Num = atoi(m_cBeps726.NbOfChckInf2.c_str());
	this->m_bIsBiz = false;
	for(int iChk2 = 0; iChk2 < iChkDtls2Num; ++iChk2){
		GetChckInfDtls2(iChk2);
	}

    Trace(L_DEBUG, __FILE__, __LINE__, 
                NULL, "��ǩ�Ӵ�:[%s]", m_strTx2.c_str());
    
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvBeps726::InsertData");
	return iRet;
}

//__wsh 2012-10-12 ����ҵ����Ԥ������ϸ
//i: �ڵ�����
void CRecvBeps726::GetChckInfDtls1(int i)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CRecvBeps726::GetChckInfDtls1");

	TxTpCd    = m_cBeps726.GetValueFromCycle(
					"ChckInfDtls1", "ChckInfDtls1TxTpCd", i);   //ԭ��������
	FIELD726(TxTpCd);

	SndTtlCnt = m_cBeps726.GetValueFromCycle(
					"ChckInfDtls1", "ChckInfDtls1SndTtlCnt", i);//�����ܱ���
	FIELD726(SndTtlCnt);

	SndTtlAmt = m_cBeps726.GetValueFromCycle(
					"ChckInfDtls1", "SndTtlAmt", i);            //�����ܽ��
	FIELD726(SndTtlAmt);

	RcvTtlCnt = m_cBeps726.GetValueFromCycle(
					"ChckInfDtls1", "ChckInfDtls1RcvTtlCnt", i);//�����ܱ���
	FIELD726(RcvTtlCnt);

	RcvTtlAmt = m_cBeps726.GetValueFromCycle(
					"ChckInfDtls1", "RcvTtlAmt", i);            //�����ܽ��
	FIELD726(RcvTtlAmt);

	//��������Ԥ������ϸ�����
	int iSndTtlCnt = atoi(SndTtlCnt.c_str());
	for(int j = 1; j <= iSndTtlCnt; ++j){
		GetSndDtls1(i, j);
		SetAndAddData(BC_SEND);
	}
	//��������Ԥ������ϸ�����
	int iRcvTtlCnt = atoi(RcvTtlCnt.c_str());
	for(int j = 1; j <= iRcvTtlCnt; ++j){
		GetRcvDtls1(i, j);
		SetAndAddData(BC_RECV);
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvBeps726::GetChckInfDtls1");
}

//__wsh 2012-10-12 ����ҵ����Ԥ����������ϸ
//i: ���ڵ�����
//j: �ӽڵ�����
void CRecvBeps726::GetSndDtls1(int i, int j)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CRecvBeps726::GetSndDtls1");

	OrgnlMsgId   = m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls1", i, "SndDtls1", j, "SndDtls1OrgnlMsgId");   //ԭ���ı�ʶ
	FIELD726(OrgnlMsgId);

	OrgnlInstgPty= m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls1", i, "SndDtls1", j, "SndDtls1OrgnlInstgPty");//ԭ�������
	FIELD726(OrgnlInstgPty);

	OrgnlMT      = m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls1", i, "SndDtls1", j, "SndDtls1OrgnlMT");      //ԭ��������
	FIELD726(OrgnlMT);

	TtlCnt       = m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls1", i, "SndDtls1", j, "SndDtls1TtlCnt");       //���ı���
	FIELD726(TtlCnt);

	Ccy          = "CNY";
	CtrlSum      = m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls1", i, "SndDtls1", j, "SndDtls1CtrlSum");      //�������
	FIELD726(Ccy + CtrlSum);

	PrcSts       = m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls1", i, "SndDtls1", j, "SndDtls1PrcSts");       //����״̬
	FIELD726(PrcSts);

	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvBeps726::GetSndDtls1");
}

//__wsh 2012-10-12 ����ҵ����Ԥ����������ϸ
//i: ���ڵ�����
//j: �ӽڵ�����
void CRecvBeps726::GetRcvDtls1(int i, int j)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CRecvBeps726::GetRcvDtls1");

	OrgnlMsgId   = m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls1", i, "RcvDtls1", j, "RcvDtls1OrgnlMsgId");   //ԭ���ı�ʶ
	FIELD726(OrgnlMsgId);

	OrgnlInstgPty= m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls1", i, "RcvDtls1", j, "RcvDtls1OrgnlInstgPty");//ԭ�������
	FIELD726(OrgnlInstgPty);

	OrgnlMT      = m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls1", i, "RcvDtls1", j, "RcvDtls1OrgnlMT");      //ԭ��������
	FIELD726(OrgnlMT);

	TtlCnt       = m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls1", i, "RcvDtls1", j, "RcvDtls1TtlCnt");       //���ı���
	FIELD726(TtlCnt);

	Ccy          = "CNY";
	CtrlSum      = m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls1", i, "RcvDtls1", j, "RcvDtls1CtrlSum");      //�������
	FIELD726(Ccy + CtrlSum);

	PrcSts       = m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls1", i, "RcvDtls1", j, "RcvDtls1PrcSts");       //����״̬
	FIELD726(PrcSts);

	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Leave CRecvBeps726::GetRcvDtls1");
}

//__wsh 2012-10-12 ������Ϣ��Ԥ������ϸ
//i: �ڵ�����
void CRecvBeps726::GetChckInfDtls2(int i)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CRecvBeps726::GetChckInfDtls2");

	TxTpCd    = m_cBeps726.GetValueFromCycle(
					"ChckInfDtls2", "ChckInfDtls2TxTpCd", i);   //ԭ��������
	FIELD726(TxTpCd);

	SndTtlCnt = m_cBeps726.GetValueFromCycle(
					"ChckInfDtls2", "ChckInfDtls2SndTtlCnt", i);//�����ܱ���
	FIELD726(SndTtlCnt);

	RcvTtlCnt = m_cBeps726.GetValueFromCycle(
					"ChckInfDtls2", "ChckInfDtls2RcvTtlCnt", i);//�����ܱ���
	FIELD726(RcvTtlCnt);

	//��������Ԥ������ϸ�����
	int iSndTtlCnt = atoi(SndTtlCnt.c_str());
	for(int j = 1; j <= iSndTtlCnt; ++j){
		GetSndDtls2(i, j);
		SetAndAddData(BC_SEND);
	}
	//��������Ԥ������ϸ�����
	int iRcvTtlCnt = atoi(RcvTtlCnt.c_str());
	for(int j = 1; j <= iRcvTtlCnt; ++j){
		GetRcvDtls2(i, j);
		SetAndAddData(BC_RECV);
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvBeps726::GetChckInfDtls2");
}

//__wsh 2012-10-12 ������Ϣ��Ԥ����������ϸ
//i: ���ڵ�����
//j: �ӽڵ�����
void CRecvBeps726::GetSndDtls2(int i, int j)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CRecvBeps726::GetSndDtls2");

	OrgnlMsgId   = m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls2", i, "SndDtls2", j, "SndDtls2OrgnlMsgId");    //ԭ���ı�ʶ
	FIELD726(OrgnlMsgId);

	OrgnlInstgPty= m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls2", i, "SndDtls2", j, "SndDtls2OrgnlInstgPty"); //ԭ�������
	FIELD726(OrgnlInstgPty);

	OrgnlMT      = m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls2", i, "SndDtls2", j, "SndDtls2OrgnlMT");       //ԭ��������
	FIELD726(OrgnlMT);

	PrcSts       = m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls2", i, "SndDtls2", j, "SndDtls2PrcSts");        //����״̬
	FIELD726(PrcSts);

	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvBeps726::GetSndDtls2");
}

//__wsh 2012-10-12 ������Ϣ��Ԥ����������ϸ
//i: ���ڵ�����
//j: �ӽڵ�����
void CRecvBeps726::GetRcvDtls2(int i, int j)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CRecvBeps726::GetRcvDtls2");

	OrgnlMsgId   = m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls2", i, "RcvDtls2", j, "RcvDtls2OrgnlMsgId");    //ԭ���ı�ʶ
	FIELD726(OrgnlMsgId);

	OrgnlInstgPty= m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls2", i, "RcvDtls2", j, "RcvDtls2OrgnlInstgPty"); //ԭ�������
	FIELD726(OrgnlInstgPty);

	OrgnlMT      = m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls2", i, "RcvDtls2", j, "RcvDtls2OrgnlMT");       //ԭ��������
	FIELD726(OrgnlMT);

	PrcSts       = m_cBeps726.GetValueFromLiLCycle(
			"ChckInfDtls2", i, "RcvDtls2", j, "RcvDtls2PrcSts");        //����״̬
	FIELD726(PrcSts);

	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvBeps726::GetRcvDtls2");
}

//__wsh 2012-10-12 ��ϸ���
//pSrTp: �����˱�ʶ
void CRecvBeps726::SetAndAddData(const char* pSrTp)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CRecvBeps726::SetAndAddData");

	m_bpbc.m_chkdt       = m_strChkDt;    //��������
	m_bpbc.m_msgtype     = OrgnlMT;       //ԭ��������
	m_bpbc.m_orgmsgid    = OrgnlMsgId;    //ԭ���ı�ʶ
	m_bpbc.m_orgsendbank = OrgnlInstgPty; //ԭ����������
	m_bpbc.m_msgprocstat = PrcSts; //����״̬
	m_bpbc.m_instddrctpty= m_strInstdDrctPty;//���˱���ֱ�Ӳ�����
	m_bpbc.m_sndrcvtp    = pSrTp; //������ʶ
	m_bpbc.m_amt         = m_bIsBiz ? atof(CtrlSum.c_str()) : 0.0; //����Ϣ���Ĳ��Խ���ֵ0.0

	//���ұ���ҵ��, �ҵ����뱾��ҵ����бȽϵó�����״̬��
	//�Ҳ�����״̬Ϊ������
	if(QueryLocalBiz() == SQL_SUCCESS){
		DoCompare();
	}
	else{
		m_strChkSt = PR_BFCH_04;
	}
	m_bpbc.m_chkstat = m_strChkSt; //����״̬

	Trace(L_DEBUG, __FILE__, __LINE__,
			NULL, "���˽��->[%s]", m_strChkSt.c_str());


	SETCTX(m_bpbc);
	int iRet = m_bpbc.insert();
	if(iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[bp_beforecheck]�������:[%s]", m_bpbc.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvBeps726::SetAndAddData");
}

//__wsh 2012-10-12 ����Ԥ����
int CRecvBeps726::DealBeforeCheck(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CRecvBeps726::DealBeforeCheck");
	int iRet = -1;

	//�ύ����
	m_bpbc.commit();

	//����Ѿ����ղ�������726���ģ��������ض�����
	char szSql[256] = {0};
	snprintf(szSql, sizeof(szSql), " chkdt='%s' and instddrctpty='%s' ",
			m_strChkDt.c_str(), m_cBeps726.InstdDrctPty.c_str());
	iRet = m_bpbc.findcount(szSql);
	if(iRet == SQL_SUCCESS){
		Trace(L_INFO, __FILE__, __LINE__, NULL, "�ѽ���:[%d] �����:[%s]",
				m_bpbc.m_iCount, m_cBeps726.TtlNb.c_str());

		if(m_bpbc.m_iCount >= atoi(m_cBeps726.TtlNb.c_str())){
			DealLocalMore();
		}
		else{
			Trace(L_DEBUG, __FILE__, __LINE__, NULL, "δ�����꣬���������ض�!!!");
		}
	}
	else{
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[bp_beforecheck]��ѯ����:%s", m_bpbc.GetSqlErr());
		PMTS_ThrowException(DB_FIND_FAIL);
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvBeps726::DealBeforeCheck");

	iRet = RTN_SUCCESS;

	return iRet;
}

//__wsh 2012-10-15 ���ݱ�������ת����ҵ���
int CRecvBeps726::ToBizTable(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CRecvBeps726::ToBizTable");
	int iRet = RTN_SUCCESS;

	memset(m_szTblNm, 0x00, sizeof(m_szTblNm));
	const char* mt = m_bpbc.m_msgtype.c_str();

#define EQUALMT726(MT) strcmp(mt, MT) == 0
#define LIKEMT726(MT)  strstr(mt, MT) != NULL

	if(EQUALMT726("PKG001") || EQUALMT726("PKG003") || EQUALMT726("PKG005") ||
	   EQUALMT726("PKG007") || EQUALMT726("PKG008") || EQUALMT726("PKG010") ||
	   EQUALMT726("PKG011") || LIKEMT726("beps.121") || LIKEMT726("beps.122") ||
	   LIKEMT726("beps.123")|| LIKEMT726("beps.125") || LIKEMT726("beps.128") ||
	   LIKEMT726("beps.130")|| LIKEMT726("beps.132") || LIKEMT726("beps.134")){
		//����
		m_bpbc.m_sndrcvtp == BC_SEND ? sprintf(m_szTblNm, "BP_BCOUTSNDCL") :
					sprintf(m_szTblNm, "BP_BCOUTRCVCL");
	}
	else if(EQUALMT726("PKG002") || EQUALMT726("PKG004") || EQUALMT726("PKG006") ||
			EQUALMT726("PKG009") || LIKEMT726("beps.124") || LIKEMT726("beps.127") ||
			LIKEMT726("beps.131") || LIKEMT726("beps.133")){
		//���
		m_bpbc.m_sndrcvtp == BC_SEND ? sprintf(m_szTblNm, "BP_BDSNDCL") :
					sprintf(m_szTblNm, "BP_BDRCVCL");
	}
	else if(EQUALMT726("PKG012") || LIKEMT726("beps.380") || LIKEMT726("beps.381") ||
			LIKEMT726("beps.382") || LIKEMT726("beps.383") || LIKEMT726("beps.384")||
			LIKEMT726("beps.385") || LIKEMT726("beps.386") || LIKEMT726("beps.387")){
		//���ո�
		sprintf(m_szTblNm, "BP_COLLTNCHRGSCL");
	}
	else if(EQUALMT726("CMT301") || EQUALMT726("CMT302") ||
			LIKEMT726("ccms.314") || LIKEMT726("ccms.315")){
		//��ѯ�鸴
		sprintf(m_szTblNm, "CM_TRANSINFOQRY");
	}
	else{
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[%s][%s]�Ҳ�����Ӧҵ���", mt, m_bpbc.m_sndrcvtp.c_str());
		PMTS_ThrowException(FAILED);
	}

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__ת�����:[%s][%s]->[%s]",
			mt, m_bpbc.m_sndrcvtp.c_str(), m_szTblNm);

	Trace(L_INFO,  __FILE__, __LINE__,
					NULL, "Leave CRecvBeps726::ToBizTable");
	return iRet;
}

//__wsh 2012-10-15 ��ѯ����ҵ��
int CRecvBeps726::QueryLocalBiz(void)
{
	Trace(L_INFO,  __FILE__, __LINE__,
				NULL, "Enter CRecvBeps726::QueryLocalBiz");
	int iRet = -1;
	//���ݱ������͵õ�ҵ���
	ToBizTable();

	m_dCtrlSum = 0.0;
	m_strBizSt = "";
	m_iBizCnt  = 0;
	m_strChkSt = "";

#define ISTABLE726(TBL) strcmp(TBL, m_szTblNm) == 0

//__MACRO START__����Ǳ��ؼ�¼��ѯ��
#define FINDLOCALCDBIZ(ENTITY) ENTITY o##ENTITY; SETCTX(o##ENTITY); \
	o##ENTITY.m_msgid = m_bpbc.m_orgmsgid; \
	o##ENTITY.m_instgdrctpty = m_bpbc.m_orgsendbank; \
	iRet = o##ENTITY.findByPK(); \
	if(iRet == SQL_SUCCESS){ \
		m_dCtrlSum = o##ENTITY.m_ctrlsum; \
		m_strBizSt = o##ENTITY.m_busistate; \
		m_iBizCnt  = o##ENTITY.m_nboftxs; \
	}
//__MACRO END__

	if( ISTABLE726("BP_BCOUTSNDCL") ){//��������
		FINDLOCALCDBIZ(CBpbcoutsndcl);
	}
	else if( ISTABLE726("BP_BCOUTRCVCL") ){//��������
		FINDLOCALCDBIZ(CBpbcoutrcvcl);
	}
	else if( ISTABLE726("BP_BDSNDCL") ){//�������
		FINDLOCALCDBIZ(CBpbdsndcl);
	}
	else if( ISTABLE726("BP_BDRCVCL") ){//�������
		FINDLOCALCDBIZ(CBpbdrcvcl);
	}
	else if( ISTABLE726("BP_COLLTNCHRGSCL") ){//���ո�
		CBpcolltnchrgscl coll;
		SETCTX(coll);
		string strSql = "";
		strSql.append(" msgid='").append(m_bpbc.m_orgmsgid);
		strSql.append("' and instgpty='").append(m_bpbc.m_orgsendbank);
		strSql += (m_bpbc.m_sndrcvtp == BC_SEND) ? 
		    "' and srcflag='1' " : "' and srcflag > '1'";
		Trace(L_DEBUG, __FILE__, __LINE__, 
		        NULL, "__strSql=[%s]", strSql.c_str());
		iRet = coll.find(strSql);
		if(iRet == SQL_SUCCESS){
		    if( (iRet = coll.fetch()) == SQL_SUCCESS){
    			m_dCtrlSum = coll.m_ttlamt;
    			m_strBizSt = coll.m_busistate;
    		}	
		}
	}
	else if(ISTABLE726("CM_TRANSINFOQRY")){//��ѯ�鸴
		CCmtransinfoqry tiq;
		SETCTX(tiq);
		tiq.m_msgid  = m_bpbc.m_orgmsgid;
		tiq.m_instgindrctpty = m_bpbc.m_orgsendbank;
		tiq.m_sysid  = "BEPS";
		tiq.m_rsflag = m_bpbc.m_sndrcvtp == BC_SEND ? "1" : "2";
		iRet = tiq.findByPK();
		if(iRet == SQL_SUCCESS){
			m_strBizSt = tiq.m_busistate;
		}
	}

	if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[%s]��ѯ����:%d", m_szTblNm, iRet);
		PMTS_ThrowException(DB_FIND_FAIL);
	}

	Trace(L_INFO,  __FILE__, __LINE__,
				NULL, "Leave CRecvBeps726::QueryLocalBiz");
	return iRet;
}

//__wsh 2012-10-15 ״̬�Ƚ�
void CRecvBeps726::DoCompare(void)
{
	Trace(L_INFO,  __FILE__, __LINE__,
				NULL, "Enter CRecvBeps726::DoCompare");

    //ҵ�������,�ԱȽ�״̬; ��Ϣ��ֻ��״̬
	if(m_bIsBiz){
		Trace(L_DEBUG, __FILE__, __LINE__, NULL,
			"���ؽ�[%.02f] ����״̬:[%s]", m_dCtrlSum, m_strBizSt.c_str());

		Trace(L_DEBUG, __FILE__, __LINE__, NULL,
		    "���н�[%.02f] ����״̬:[%s]",
				m_bpbc.m_amt, m_bpbc.m_msgprocstat.c_str());

        if(m_bpbc.m_msgprocstat == PROCESS_PR09){
            //�����оܾ��Ľ����౨�Ĳ���������, ���ֻ��״̬���Խ��
            m_strChkSt = (m_strBizSt == m_bpbc.m_msgprocstat) ?
                        PR_BFCH_01 : PR_BFCH_03;
        }
		else if( m_strBizSt == m_bpbc.m_msgprocstat &&
				AmtEqual(m_dCtrlSum, m_bpbc.m_amt) ){//�������
			m_strChkSt = PR_BFCH_01;
		}
		else if( m_strBizSt == m_bpbc.m_msgprocstat &&
				!AmtEqual(m_dCtrlSum, m_bpbc.m_amt) ){//����
			m_strChkSt = PR_BFCH_02;
		}
		else if( m_strBizSt != m_bpbc.m_msgprocstat &&
				AmtEqual(m_dCtrlSum, m_bpbc.m_amt) ){//״̬����
			m_strChkSt = PR_BFCH_03;
		}
		else{//���״̬����
			m_strChkSt = PR_BFCH_06;
		}
	}
	else{
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "����״̬:[%s] ����״̬[%s]",
				m_strBizSt.c_str(), m_bpbc.m_msgprocstat.c_str());

		m_strChkSt = (m_strBizSt == m_bpbc.m_msgprocstat) ?
				PR_BFCH_01 : PR_BFCH_03;
	}

	Trace(L_INFO,  __FILE__, __LINE__,
				NULL, "Leave CRecvBeps726::DoCompare");
}

//__wsh 2012-10-12 ��ǩ
void CRecvBeps726::CheckSign726()
{
	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CRecvBeps726::CheckSign726");
				            
#define CATSIGN726(FIELD) m_cBeps726.m_sSignBuff += m_cBeps726.CHECKVALUE(FIELD)

    CATSIGN726(m_cBeps726.MsgId);
    CATSIGN726(m_cBeps726.CreDtTm);
    CATSIGN726(m_cBeps726.InstgDrctPty);
    CATSIGN726(m_cBeps726.GrpHdrInstgPty);
    CATSIGN726(m_cBeps726.InstdDrctPty);
    CATSIGN726(m_cBeps726.GrpHdrInstdPty);
    CATSIGN726(m_cBeps726.SysCd);
    CATSIGN726(m_cBeps726.TtlNb);
    CATSIGN726(m_cBeps726.StartNb);
    CATSIGN726(m_cBeps726.EndNb);
    CATSIGN726(m_cBeps726.ChckDt);
    m_cBeps726.m_sSignBuff += m_strTx2;
	CheckSign(m_cBeps726.m_sSignBuff.c_str(),
		m_cBeps726.m_szDigitSign.c_str(),
		m_cBeps726.InstgDrctPty.c_str());

	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Leave CRecvBeps726::CheckSign726");
}

//__wsh 2013-01-13
void ::CRecvBeps726::DealLocalMore(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CRecvBeps726::DealLocalMore");

	char szSql[512] = {0};

	m_bpbc.m_chkdt   = m_strChkDt; //��������
	m_bpbc.m_chkstat = PR_BFCH_05; //����״̬�����ض�

	snprintf(szSql, sizeof(szSql), " finalstatedate='%s' and instgdrctpty='%s'"
			"and busistate in ('PR04', 'PR00', 'PR05' ) and instgdrctpty||msgid not in (select "
			"(orgsendbank || orgmsgid) key from bp_beforecheck where chkdt='%s' and instddrctpty='%s')",
			m_cBeps726.ChckDt.c_str(), m_cBeps726.InstdDrctPty.c_str(),
			m_strChkDt.c_str(), m_cBeps726.InstdDrctPty.c_str());
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__szSql=[%s]", szSql);
	//��������
	GetLocalMoreDebtCtdr(szSql, 1);
	//�������
	GetLocalMoreDebtCtdr(szSql, 2);

	snprintf(szSql, sizeof(szSql), " finalstatedate='%s' and instgdrctpty='%s'"
			"and busistate in ('PR03', 'PR00', 'PR05' ) and instgpty||msgid not in (select "
			"(orgsendbank || orgmsgid) from bp_beforecheck where chkdt='%s' and instddrctpty='%s')",
			m_cBeps726.ChckDt.c_str(), m_cBeps726.InstdDrctPty.c_str(),
			m_strChkDt.c_str(), m_cBeps726.InstdDrctPty.c_str());
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__szSql=[%s]", szSql);
	//���ո�
	GetLocalMoreColltn(szSql);

	snprintf(szSql, sizeof(szSql), " finalstatedate='%s' and instgdrctpty='%s' and sysid='BEPS' "
			"and busistate in ('PR00', 'PR05' ) and instgindrctpty||msgid not in (select "
			"(orgsendbank || orgmsgid) from bp_beforecheck where chkdt='%s' and instddrctpty='%s')",
			m_cBeps726.ChckDt.c_str(), m_cBeps726.InstdDrctPty.c_str(),
			m_strChkDt.c_str(), m_cBeps726.InstdDrctPty.c_str());
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__szSql=[%s]", szSql);
	GetLocalMoreTiq(szSql);


	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Leave CRecvBeps726::DealLocalMore");
}

//__wsh 2013-01-13 �ҳ�����Ǳ��ض�����˽��ף����浽Ԥ���˱���
int CRecvBeps726::GetLocalMoreDebtCtdr(const char* szSql, int iDCFlag)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CRecvBeps726::GetLocalMoreDebtCtdr");

	int iRet = -1;

//MACRO START ��ȡ����Ǳ������������ض��
#define GETLOCALMORE726(ENTITY, SRFLAG) do{ENTITY o##ENTITY; SETCTX(o##ENTITY);\
	iRet = o##ENTITY.find(szSql); \
	if(iRet == SQL_SUCCESS){\
		while(true){\
			iRet = o##ENTITY.fetch();\
			if(iRet == SQL_SUCCESS){\
				m_bpbc.m_msgtype     = o##ENTITY.m_msgtp; \
				m_bpbc.m_orgmsgid    = o##ENTITY.m_msgid; \
				m_bpbc.m_orgsendbank = o##ENTITY.m_instgdrctpty; \
				m_bpbc.m_msgprocstat = o##ENTITY.m_busistate; \
				m_bpbc.m_sndrcvtp    = (SRFLAG); \
				m_bpbc.m_amt         = o##ENTITY.m_ctrlsum; \
				Trace(L_DEBUG, __FILE__, __LINE__, NULL, "{%s, %s, %s}", \
						m_bpbc.m_orgsendbank.c_str(), m_bpbc.m_orgmsgid.c_str(), m_bpbc.m_msgtype.c_str()); \
				iRet = m_bpbc.insert(); \
				if(iRet != SQL_SUCCESS){ \
					Trace(L_ERROR, __FILE__, __LINE__, NULL, \
							"[bp_beforecheck]Insert Fail:[%s]", m_bpbc.GetSqlErr());\
					o##ENTITY.closeCursor();\
					PMTS_ThrowException(DB_INSERT_FAIL);\
				}\
			}\
			else if(iRet == SQLNOTFOUND){\
				o##ENTITY.closeCursor();\
				break; \
			}\
			else{\
				Trace(L_ERROR, __FILE__, __LINE__, NULL, \
						"[%s]Find Fail:[%s]", #ENTITY, o##ENTITY.GetSqlErr());\
				o##ENTITY.closeCursor();\
				PMTS_ThrowException(DB_FIND_FAIL);\
			}\
		}\
	}\
	else{\
		Trace(L_ERROR, __FILE__, __LINE__, NULL, \
				"[%s]Find Fail:[%s]", #ENTITY, o##ENTITY.GetSqlErr());\
		PMTS_ThrowException(DB_FIND_FAIL);\
	} }while(0)
//MACRO END

	if(iDCFlag == 1){
		GETLOCALMORE726(CBpbcoutsndcl, "SR00");
	}
	else{
		GETLOCALMORE726(CBpbdsndcl, "SR00");
	}

	return iRet;
}

//__wsh 2013-01-13 �ҳ����ո����ض�����˽��ף����浽Ԥ���˱���
int CRecvBeps726::GetLocalMoreColltn(const char* szSql)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CRecvBeps726::GetLocalMoreColltn");

	int iRet = -1;

	CBpcolltnchrgscl coll;
	SETCTX(coll);

	iRet = coll.find(szSql);
	if(iRet == SQL_SUCCESS){
		while(true){
			iRet = coll.fetch();
			if(iRet == SQL_SUCCESS){
				m_bpbc.m_msgtype     = coll.m_msgtp;
				m_bpbc.m_orgmsgid    = coll.m_msgid;
				m_bpbc.m_orgsendbank = coll.m_instgdrctpty;
				m_bpbc.m_msgprocstat = coll.m_busistate;
				m_bpbc.m_sndrcvtp    = "SR00";
				m_bpbc.m_amt         = coll.m_ttlamt;

				Trace(L_DEBUG, __FILE__, __LINE__, NULL, "{%s, %s, %s}",
						m_bpbc.m_orgsendbank.c_str(), m_bpbc.m_orgmsgid.c_str(),
						m_bpbc.m_msgtype.c_str());

				iRet = m_bpbc.insert();
				if(iRet != SQL_SUCCESS){
					Trace(L_ERROR, __FILE__, __LINE__, NULL,
						"[bp_beforecheck]Insert Fail:[%s]", m_bpbc.GetSqlErr());
					PMTS_ThrowException(DB_FIND_FAIL);
				}
			}
			else if(iRet == SQLNOTFOUND){
				break;
			}
		}
	}

	if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[bp_colltnchrgscl]��ѯ����:[%s]", coll.GetSqlErr());
		PMTS_ThrowException(DB_FIND_FAIL);
	}


	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Leave CRecvBeps726::GetLocalMoreColltn");

	return iRet;
}

//__wsh 2013-01-13 �ұ���ѯ�鸴���ض�����˽��ף����浽Ԥ���˱���
int CRecvBeps726::GetLocalMoreTiq(const char* szSql)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CRecvBeps726::GetLocalMoreTiq");
	int iRet = -1;

	CCmtransinfoqry tiq;
	SETCTX(tiq);


	iRet = tiq.find(szSql);
	if(iRet == SQL_SUCCESS){
		while(true){
			iRet = tiq.fetch();
			if(iRet == SQL_SUCCESS){
				m_bpbc.m_msgtype     = tiq.m_msgtp;
				m_bpbc.m_orgmsgid    = tiq.m_msgid;
				m_bpbc.m_orgsendbank = tiq.m_instgdrctpty;
				m_bpbc.m_msgprocstat = tiq.m_busistate;
				m_bpbc.m_sndrcvtp    = "SR00";
				m_bpbc.m_amt         = 0.0;
				Trace(L_DEBUG, __FILE__, __LINE__, NULL, "{%s, %s, %s}",
						m_bpbc.m_orgsendbank.c_str(), m_bpbc.m_orgmsgid.c_str(),
						m_bpbc.m_msgtype.c_str());
				iRet = m_bpbc.insert();
				if(iRet != SQL_SUCCESS){
					Trace(L_ERROR, __FILE__, __LINE__, NULL,
						"[bp_beforecheck]Insert Fail:[%s]", m_bpbc.GetSqlErr());
					PMTS_ThrowException(DB_FIND_FAIL);;
				}
			}
			else if(iRet == SQLNOTFOUND){
				break;
			}
		}
	}

	if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[bp_colltnchrgscl]��ѯ����:[%s]", tiq.GetSqlErr());
		PMTS_ThrowException(DB_FIND_FAIL);
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Leave CRecvBeps726::GetLocalMoreTiq");

	return iRet;
}




//__wsh 2012-08-24 �ͻ�֪ͨ
void CRecvBeps726::InsertUserInfoTel(void)
{
    Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBeps726::InsertUserInfoTel");

    char szMsg[512]= {0};

	sprintf(szMsg,	"�յ�С��Ԥ����726����");

    Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBeps726::InsertUserInfoTel");
}

//�ȽϽ��
bool CRecvBeps726::AmtEqual(double dAmt1, double dAmt2)
{
	char szAmt1[48] = {0};
	char szAmt2[48] = {0};
	snprintf(szAmt1, sizeof(szAmt1), "%.02f", dAmt1);
	snprintf(szAmt2, sizeof(szAmt2), "%.02f", dAmt2);
	return ( strcmp(szAmt1, szAmt2) == 0 );
}


*/













