/********************************************************************
文件名：sockettest.cpp
创建人：hq
日  期：2011-05-17
修改人：
日  期：
描  述：SOCKET测试主控
版  本：
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include "exception.h"
#include "connectpool.h"
#include "configparser.h"
#include "thread.h"
#include "logger.h"
#include "pubfunc.h"
#include "sockettestwork.h"
#include "cfg_obj.h"

using namespace ZFPT;

CConnectPool	*g_DBConnPool;
CCfgObj			pCfgFile;

char			g_SendCBSP[128];
int          g_IsConnCBSP;
char         g_IP[16];
char         g_MqTxtPath[256];
char         g_MQmgr[256];

int LoadConfigFile(stuCfgInfo &CfgInfo, int &iLoopNum, string &sTxId, string &szHostIp, string &szMsgTp);

int main(int argc, char **argv)
{
	int  iRet = 0;
	int  iLoopNum = 0;
	
	stuCfgInfo  CfgInfo ;
	
	string szTxId = "";
    string szHostIp = "";
    string szMsgTp = "";

    signal(SIGINT , SIG_IGN);					//屏蔽中断信号
    signal(SIGQUIT, SIG_IGN);					//屏蔽终端退出信号
    signal(SIGALRM, SIG_IGN);					//屏蔽超时信号
    signal(SIGHUP , SIG_IGN);					//屏蔽连接断开信号
    signal(SIGSTOP, SIG_IGN);					//这些信号被忽略
    //signal(SIGCHLD, SIG_IGN);

    try
    {
    	// 加载配置文件
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "加载配置文件...");
    	LoadConfigFile(CfgInfo, iLoopNum, szTxId, szHostIp, szMsgTp);
    	
    	// 初始化日志
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化日志...");
    	ZFPTLOG.setCfgInfo(CfgInfo.szLogPath, "sockettest", CfgInfo.iLogLeave, CfgInfo.dLogMaxSize);
    	 
    	// 创建连接池
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化连接池...");  
        g_DBConnPool = new CConnectPool(CfgInfo.iConPoolMinNum,CfgInfo.iConPoolMaxNum,CfgInfo.iNoConWaitTime);	
          
        iRet= g_DBConnPool->InitPool(CfgInfo.iConPoolSize,CfgInfo.DBUser,CfgInfo.DBKey,CfgInfo.DBName);
        if(iRet != RTN_SUCCESS)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "连接池创建失败");
            exit(0);
        }
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "连接池创建成功");
    
        // 初始化线程池
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化线程池..."); 
        CThreadPool<CSocketTestWork> cPool;
        cPool.start(CfgInfo.iThreadPoolSize, CfgInfo.iThreadPoolTaskSize);
        
    	// 循环发SOCKET
    	for(int k = 0; k < iLoopNum; k++)
    	{
    		CSocketTestWork cSocketTestWork;
    	    printf("**************Currer NO:[%d]\n", k);
        	cSocketTestWork.setData(szHostIp, szTxId, szMsgTp, CfgInfo.iPort);
            
    		while(JOBPOOL_FULL == (iRet = cPool.push(cSocketTestWork)))
            {
                Trace(L_INFO,  __FILE__,  __LINE__, NULL, "任务缓存写满");
    		    
                //注意，因为缓存可能会写满，这里需要等待一下
                sleep(1);
            }
            
            if(0 == iRet)
            {
                Trace(L_INFO,  __FILE__,  __LINE__, NULL, "添加任务成功");
            }
            else
            {
                Trace(L_INFO,  __FILE__,  __LINE__, NULL, "添加任务失败");
            }

            usleep(50000); // 发一笔，等待一下，不然太快，处理不过来
    	}

	}catch(CException &e)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Catch a exception from [%s]",  e.what());
        exit(0);
    }

	setsid();
	return 0;
}

int LoadConfigFile(stuCfgInfo &CfgInfo, int &iLoopNum, string &sTxId, string &szHostIp, string &szMsgTp)
{
    CConfigParser& cCfg = CConfigParser::getInstance();

    strcpy(CfgInfo.path, "../cfg/sockettest.xml");
    cCfg.loadConfig(CfgInfo.path);
    
    strncpy(CfgInfo.szLogPath, cCfg.getOption("LOGPATH"), sizeof(CfgInfo.szLogPath)-1);
    CfgInfo.iPort = atoi(cCfg.getOption("CLIENTPORT"));
    CfgInfo.iLogLeave = atoi(cCfg.getOption("LOGLVL"));

    CfgInfo.iConPoolMinNum = atoi(cCfg.getOption("SCCONNPOOLMINSIZE"));
    CfgInfo.iConPoolMaxNum = atoi(cCfg.getOption("SCCONNPOOLMAXSIZE"));
    CfgInfo.iNoConWaitTime	 = atoi(cCfg.getOption("SCNOCONNWAITTIME"));
    CfgInfo.iConPoolSize = atoi(cCfg.getOption("SCCONNPOOLSIZE"));
    CfgInfo.iThreadPoolSize = atoi(cCfg.getOption("SCTHREADPOOLSIZE"));
    CfgInfo.iThreadPoolTaskSize = atoi(cCfg.getOption("SCTHREADPOOLTASKSIZE"));
    CfgInfo.dLogMaxSize = atof(cCfg.getOption("LOGMAXSIZE"));

    strncpy(CfgInfo.DBUser,cCfg.getOption("DBUSER"),sizeof(CfgInfo.DBUser)-1);
    strncpy(CfgInfo.DBKey,cCfg.getOption("DBKEY"),sizeof(CfgInfo.DBKey)-1);
    strncpy(CfgInfo.DBName,cCfg.getOption("DBNAME"),sizeof(CfgInfo.DBName)-1);

    iLoopNum = atoi(cCfg.getOption("LOOPNUM"));
    sTxId    = cCfg.getOption("LOOPMSGID");
    szMsgTp  = cCfg.getOption("MSGTP");
    szHostIp = cCfg.getOption("CLIENTIP");
    
    return OPERACT_SUCCESS;
}

