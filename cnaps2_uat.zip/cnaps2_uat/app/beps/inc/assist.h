#ifndef __ASSIST_H__
#define __ASSIST_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef WIN32
#include <windows.h>
#include <process.h>
#else
#include <sys/time.h>
#endif

void dump_char (const char *str, void *buf, int bytelen);
void dump_int (const char *str, void *buf, int intlen);
int str2hex (int len, char *str, unsigned char *hex);
int hex2str(int length, unsigned char *hex, unsigned char *str);
void converseStr(void *buf, int byteLen);
void convcpy(void *dst, void *src, int bytelen);

#define rotr32(x,n)   (((x) >> ((int)(n))) | ((x) << (32 - (int)(n))))
#define rotl32(x,n)   (((x) << ((int)(n))) | ((x) >> (32 - (int)(n))))
#define invert32(x)   (rotl32(x, 8) & 0x00ff00ff | rotr32(x, 8) & 0xff00ff00)
#define rotr16(x,n)   (((x) >> ((int)(n))) | ((x) << (16 - (int)(n))))
#define rotl16(x,n)   (((x) << ((int)(n))) | ((x) >> (16 - (int)(n))))
#define invert16(x)   (rotl16(x, 8) & 0x00ff | rotr16(x, 8) & 0xff00)
void converse(unsigned int *p, int count);

unsigned int htole32(unsigned int n);
unsigned int letoh32(unsigned int n);
double When ();

void myfgets(char* buf, int len, FILE* fp);
int GetInputInt();
int GetInputBytes(unsigned char *buf, int maxlen);
void input_password(char *passwd, int maxlen);

#endif

