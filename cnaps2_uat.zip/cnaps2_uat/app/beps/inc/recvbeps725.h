/*
 *  recvbeps725.h
 *  Description: С��ҵ������ر���(beps.725.001.01)����������
 *  Created on: 2012-10-18
 *  Author: __wsh
 */
 
#ifndef RECVBEPS725_H
#define RECVBEPS725_H

#include "recvbepsbase.h"
#include "beps725.h"
#include "bpbchkstate.h"
#include "bpsapbankinfo.h"
#include "cmcheckqry.h" 
#include "bpchklstlist.h"
#include "recvbeps121.h"
#include "recvbeps122.h"
#include "recvbeps123.h"
#include "recvbeps124.h"
#include "recvbeps125.h"
#include "recvbeps127.h"
#include "recvbeps128.h"
#include "recvbeps130.h"
#include "recvbeps131.h"
#include "recvbeps132.h"
#include "recvbeps133.h"
#include "recvbeps134.h"
#include "recvbeps380.h"
#include "recvbeps381.h"
#include "recvbeps382.h"
#include "recvbeps383.h"
#include "recvbeps384.h"
#include "recvbeps385.h"
#include "recvbeps386.h"
#include "recvbeps387.h"
#include "recvbeps388.h"
#include "recvbeps389.h"
#include "recvbeps392.h"
#include "recvbeps393.h"
#include "recvbeps394.h"
#include "recvbeps395.h"
//#include "recvbeps396.h"
#include "recvbeps397.h"
//#include "recvbeps398.h"
#include "recvbeps399.h"
#include "recvbeps401.h"
#include "recvbeps402.h"
#include "recvbeps403.h"
#include "recvbeps404.h"
#include "recvbeps411.h"
#include "recvbeps412.h"
#include "recvbeps414.h"
#include "recvbeps415.h"
#include "recvbeps418.h"
#include "recvbeps419.h"
#include "recvpkg003.h"
#include "recvpkg004.h"
#include "recvpkg005.h"
#include "recvpkg006.h"
#include "recvpkg007.h"
#include "recvpkg008.h"
#include "recvpkg001.h"
#include "recvpkg002.h"
#include "recvpkg009.h"
#include "recvpkg012.h"
#include "recvpkg013.h"
#include "recvbeps721.h"
#include "recvbeps723.h"
#include "recvcmt324.h"
#include "recvcmt325.h"


class CRecvBeps725 : public CRecvBepsBase
{
public:
	CRecvBeps725();

	~CRecvBeps725();
	
	int Work(LPCSTR szMsg);
	
private:
	int  UnPack(LPCSTR szMsg);

	int  Deal(void);

	int  ParseCntt(void);

	int  DumpToRouteRecv(void);

	int  UpdateChkList(LPCSTR sDownState);

	void ChkSign725(void);
	bool CheckIfSend720();
	int Send720(void);
	int DetailProc(const char *szMsg);
	
	bool ChickIfContuine();

private:
	string        m_strChckDt;

	beps725       m_cBeps725;
	
	CBpchklstlist m_bpchklstlist;
	CBpsapbankinfo m_CBpsapbankinfo;
	CMcheckqry      m_checkqry;

	string        m_strCntt;

};

#endif /*RECVBEPS725_H*/

