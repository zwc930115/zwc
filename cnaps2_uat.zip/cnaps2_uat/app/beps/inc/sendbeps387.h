/*
 *  sendbeps387.h
 *  Description:
 *  Created on: 2012-06-25
 *  Author: __wsh
 */

#ifndef SENDBEPS387_H_
#define SENDBEPS387_H_

#include "beps387.h"
#include "sendbepsbase.h"

#include "bpcolltnchrgscl.h"
#include "bpcolltnchrgslist.h"

class CSendBeps387 : public CSendBepsBase
{
public:
    CSendBeps387(const stuMsgHead& Smsg);

    ~CSendBeps387();
    
    INT32  doWorkSelf(void);

private:
	int GetData(void);
	
	void SetData(void);

	void AddSign387(void);

	int BuildPmtsMsg(void);

	int UpdateState(void);

private:
	beps387  m_cBeps387;

	CBpcolltnchrgscl m_colltncl;

	CBpcolltnchrgslist m_colltnlist;

};

#endif



