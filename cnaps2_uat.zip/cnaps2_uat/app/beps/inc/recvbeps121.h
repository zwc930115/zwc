/******************************************************************** 
�ļ����� recvbeps121.h
�����ˣ� handongfeng
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __RECVBEPS121_H__
#define __RECVBEPS121_H__

#include "recvbepsbase.h"
#include "beps121.h"
#include "bpbcoutrecvlist.h"
#include "bpbcoutrcvcl.h"
#include "bpbcoutsendlist.h"
#include "bpbcoutsendlisthis.h"

class CRecvbeps121 : public CRecvBepsBase
{
public:
    CRecvbeps121();
    ~CRecvbeps121();
    int Work(LPCSTR szMsg);
    
private:
    void  CheckSign121();
    INT32 InsertData();
    INT32 SetData(LPCSTR pchMsg);
    INT32 unPack(LPCSTR szMsg);
    void UpdateOrgnlBiz(const string& dbtrbrnchid, const string& txid);
    beps121			    m_cBeps121;
    CBpbcoutrecvlist	m_BpList;
    CBpbcoutrcvcl		m_Bpcl;
    string  m_strOrgnlTable;
	string  m_strOrgnlTxid;
	string  m_strOrgnlDbtrbrnchid;

};

#endif
