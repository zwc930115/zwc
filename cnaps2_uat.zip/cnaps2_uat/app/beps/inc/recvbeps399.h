/******************************************************************** 
文件名： recvbeps399.h
创建人： handongfeng
日  期： 2011-02-23
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __RECVBEPS399_H__
#define __RECVBEPS399_H__

#include "recvbepsbase.h"
#include "beps399.h"
#include "bpbktocstdcntfctn.h"

class CRecvbeps399 : public CRecvBepsBase
{
public:
	CRecvbeps399();
	~CRecvbeps399();
	int Work(LPCSTR szMsg);
    
private:
	INT32 GetParserObj(LPCSTR szMsg);
	INT32 UpdataData();
	void  CheckSign399();
	INT32 InsertData();
	INT32 SetData(LPCSTR pchMsg);
	INT32 unPack(LPCSTR szMsg);
	beps399 m_beps399;
	CBpbktocstdcntfctn  m_Bpbktocstdcntfctn;
};

#endif


