/******************************************************************** 
�ļ����� sendpkg007.h
�����ˣ� handongfeng
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef __SENDPKG007_H__
#define __SENDPKG007_H__

#include "pkg007.h"
#include "bpbcoutsendlist.h"
#include "bpbcoutrecvlist.h"
#include "bpbcoutrecvlisthis.h"

#include "sendbepsbase.h"

class CSendPkg007 : public CSendBepsBase
{
public:
    CSendPkg007(const stuMsgHead& Smsg);
    ~CSendPkg007();
    
    INT32  doWorkSelf();
    
private:
    
    INT32 GetData();
    INT32 CheckValues();
    INT32 ChargeMb();
    INT32 CreateNpcMsg();
    INT32 UpdateSndList(LPCSTR sProcstate);
    INT32 SetErrACK(int iErrCode, LPCSTR pErrDesc);
    INT32 UpdatePkg();
    int FundSettle();

    pkg007 m_pkg007;
    CBpbcoutsendlist	m_cBpbcsndlist;
    CBpbcoutrecvlist    m_Bpbcoutrecvlist;
    CBpbcoutrecvlisthis m_Bpbcoutrecvlisthis;
    bool                m_bInHis;
    char				m_sPkgNo[35 + 1];
};

#endif


