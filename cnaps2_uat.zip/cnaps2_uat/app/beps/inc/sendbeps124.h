/******************************************************************** 
�ļ����� sendbeps124.h
�����ˣ� zys
��  ��   �� 2011-04-14
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __SENDBEPS124_H__
#define __SENDBEPS124_H__

#include "cmt124.h"
#include "beps124.h"
#include "bpbdsndcl.h"
#include "bpbdsendlist.h"
#include "sendbepsbase.h"
#include "pkg004.h"

class CSendBeps124 : public CSendBepsBase
{
public:
    CSendBeps124(const stuMsgHead& Smsg);
    ~CSendBeps124();
    
    INT32  doWorkSelf();
private:
    
    int getData();
    int CheckValues();
    int UpdateSndList(LPCSTR sProcstate);
    int updateState();
	int insertSum();
    void AddSign124();
	int buildPmtsMsg();
    void GetTag2ND(const string& QryVal, const string& QryStr, int& iDepth);
    void CreateXml();
    void CreateCmt();
    string          m_strProcessCode;
    string          m_strNetgDate;
    string          m_strNetgRnd;
    string          m_strDate;
    CBpbdsndcl		m_cbpbdsndcl;
    CBpbdsendlist	m_cbpbdsendlist;
    beps124         m_xml124;
    cmt124          m_cmt124;
};

#endif



