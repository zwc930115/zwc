/******************************************************************** 
文件名： recvbeps382.h
创建人： handongfeng
日  期： 2011-02-23
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __RECVBEPS382_H__
#define __RECVBEPS382_H__

#include "recvbepsbase.h"
#include "beps382.h"
#include "beps381.h"
#include "beps388.h"
#include "beps389.h"
#include "bpbizpubntce.h"
#include "bpcolltnchrgscl.h"
#include "bpcolltnchrgslist.h"

class CRecvbeps382 : public CRecvBepsBase
{
public:
    CRecvbeps382();
    ~CRecvbeps382();
    int Work(LPCSTR szMsg);
    void  CheckSign382();
private:
    INT32 InsertData();
    INT32 SetData(LPCSTR pchMsg);
    INT32 unPack(LPCSTR szMsg);	
	void SendRtuMsg();	
	int CheckArgeeAndUser();
    void AddSign389();
    void InsertReturnData();
    void AddSign388();

    beps382			    m_beps382;
	beps388			    m_beps388;
	beps389				m_beps389;
    CBpbizpubntce m_Bpbizpubntce;
    CBpcolltnchrgscl	m_colltnchrgscl;
    CBpcolltnchrgslist	m_colltnchrgslist;
	
    int					m_iChgTp; /*变更类型:0：新增，1：撤销*/
    int					m_iTotalNum;
    double				m_iTotalAmt;
    string              m_Sign;
    char m_MsgRefId[20+1];

};

#endif


