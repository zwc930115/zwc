/******************************************************************** 
文件名： recvbeps384.h
创建人： aps-lel
日  期： 2011-04-09
修改人： 
日  期： 
描  述：小额来帐beps.384报文处理类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef __RECVBEPS384_H__
#define __RECVBEPS384_H__

#include "recvbepsbase.h"
#include "beps384.h"
#include "beps385.h"
#include "beps388.h"
#include "bpbizpubntce.h"
#include "bpcolltnchrgscl.h"
#include "bpcolltnchrgslist.h"


class CRecvbeps384 : public CRecvBepsBase
{
public:
    CRecvbeps384();
    ~CRecvbeps384();
    int Work(LPCSTR szMsg);
    
private:
	
	//报文入汇总表
    INT32 InsertData();
	
	//表报文入明细表
    INT32 SetData(LPCSTR pchMsg);
	
    INT32 unPack(LPCSTR szMsg);
	
	//核签
	void  CheckSign384();
	int  CheckArgeeAndUser();

	//加签
	int DigitSign();
	
	//组回执报文
int Send385Msg();
	void Send388Msg();
	
    //记录385信息
    int Insert385Data();
    void Insert388Data();
	int AddSign388();

	beps388				m_beps388;
    CBpbizpubntce m_Bpbizpubntce;

    beps384			    m_cBeps384;
	beps385			    m_cBeps385;
    CBpcolltnchrgscl	m_cBpcolltnchrgscl;
    CBpcolltnchrgslist	m_cBpcolltnchrgslist;
	
	int					m_iChgTp; 				//变更类型:0：新增，1：撤销
	char				m_sMsgRefId[20 + 1];	//报文参考号
	char				m_sMsgId[35+1];			//报文标识号
	string				m_strAppData;			//实时回执明细
	string				m_strColltnwrkdt;		//代收付工作日
	string				m_sMsgType ;			//报文类型
	       
};

#endif

