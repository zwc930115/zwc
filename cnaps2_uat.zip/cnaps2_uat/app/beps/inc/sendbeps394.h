/*
 *  sendbeps394.h
 *  Description: �����ͻ���Ϣ��ѯ����beps.394.001.01����������
 *  Created on: 2012-6-4
 *  Author: __wsh
 */

#ifndef SENDBEPS394_H_
#define SENDBEPS394_H_


#include "beps394.h"
#include "sendbepsbase.h"

#include "bpcstacctqrycl.h"
#include "bpcstacctqrylist.h"

class CSendBeps394 : public CSendBepsBase
{
public:
	CSendBeps394(const stuMsgHead& Smsg);

    ~CSendBeps394();

    INT32  doWorkSelf();

private:

    int GetData();

    int CheckValues();

    void AddSign394();

    void SetAcctDtls();
    
    int SetQryInfo(void);

	int BuildPmtsMsg();

    int UpdateState();

private:

    beps394 m_cBeps394;

    CBpcstacctqrycl m_caqcl;

    CBpcstacctqrylist m_caqlist;

};

#endif /* SENDBEPS394_H_ */
