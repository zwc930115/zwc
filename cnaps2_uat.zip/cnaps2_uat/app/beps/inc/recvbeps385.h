/******************************************************************** 
文件名： recvbeps384.h
创建人： aps-lel
日  期： 2011-04-09
修改人： 
日  期： 
描  述：小额来帐beps.384报文处理类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef __RECVBEPS385_H__
#define __RECVBEPS385_H__

#include "recvbepsbase.h"
#include "beps384.h"
#include "beps385.h"
#include "beps389.h"
#include "bpbizpubntce.h"
#include "bpcolltnchrgscl.h"
#include "bpcolltnchrgslist.h"


class CRecvbeps385 : public CRecvBepsBase
{
public:
    CRecvbeps385();
    ~CRecvbeps385();
    int Work(LPCSTR szMsg);
    
private:
	
	//报文入汇总表
    INT32 InsertData();
	
	//表报文入明细表
    INT32 SetData(LPCSTR pchMsg);
	
    INT32 unPack(LPCSTR szMsg);
	
	//核签
	void  CheckSign385();

	//加签
	int DigitSign();
	
	void SendRtuMsg();

	int CheckArgeeAndUser();
	
	void  Insert389Data();

    beps389			    m_cBeps389;
	beps385			    m_cBeps385;
	CBpbizpubntce m_Bpbizpubntce;
    CBpcolltnchrgscl	m_cBpcolltnchrgscl;
    CBpcolltnchrgslist	m_cBpcolltnchrgslist;
	
	int					m_iChgTp; 				//变更类型:0：新增，1：撤销
	char				m_sMsgRefId389[20 + 1];	//报文参考号
	char				m_sMsgId[35+1];			//报文标识号
	string				m_strAppData;			//实时回执明细
	string				m_strColltnwrkdt;		//代收付工作日
	string				m_sMsgType ;			//报文类型
	       
};

#endif

