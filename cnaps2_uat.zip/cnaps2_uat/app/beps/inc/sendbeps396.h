/******************************************************************** 
�ļ����� sendbeps396.h
�����ˣ� handongfeng
��  ��   �� 2011-03-07
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __SENDBEPS396_H__
#define __SENDBEPS396_H__

#include "beps396.h"
#include "sendbepsbase.h"
#include "bpgettx.h"

class CSendBeps396 : public CSendBepsBase
{
public:
    CSendBeps396(const stuMsgHead& Smsg);
    ~CSendBeps396();
    
    INT32  doWorkSelf();
private:
    void SetTag2ND(int& iDepth, const string& QryStr, const string& Tag);
    void SetDBKey();
    int GetData();
    void SetData();
    int UpdateState();
	int InsertSum();
	
    beps396		m_beps396;
    CBpgettx	m_Bpgettx;
};

#endif




