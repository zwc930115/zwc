#ifndef __XMLPACKWORK_H__
#define __XMLPACKWORK_H__

#include "basicapi.h"
#include "pubfunc.h"

class CXmlPackWork
{
public:
    CXmlPackWork();
    ~CXmlPackWork();

    void setData(stPkgTab &_PkgTab);
	
    void clear();
	
    INT32 doWork();

private:
	stPkgTab m_stPkgTab;  
    
};


#endif


