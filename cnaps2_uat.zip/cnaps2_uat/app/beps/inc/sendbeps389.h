/*
 *  sendbeps389.h
 *  Description: ���ո�ҵ���ո���ȷ�ϱ���beps.389.001.01����������
 *  Created on: 2012-06-20
 *  Author: __wsh
 */

#ifndef SENDBEPS389_H__
#define SENDBEPS389_H__

#include "beps389.h"
#include "sendbepsbase.h"
#include "bpbizpubntce.h"

class CSendBeps389 : public CSendBepsBase
{
public:
    CSendBeps389(const stuMsgHead& Smsg);

    ~CSendBeps389();
    
    INT32  doWorkSelf();

private:
    int GetData(void);

    void SetData(void);

    void AddSign389(void);

    int BuildPmtsMsg(void);

    int UpdateState(void);

private:
    beps389 m_cBeps389;

    CBpbizpubntce m_bizpn;
};

#endif



