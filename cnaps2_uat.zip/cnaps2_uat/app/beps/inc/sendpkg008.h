
#ifndef __SENDPKG008_H__
#define __SENDPKG008_H__

#include "pkg008.h"
#include "bpbcoutsendlist.h"
#include "sendbepsbase.h"
#include "bpbcoutsndcl.h"

class CSendPkg008 : public CSendBepsBase
{
public:
    CSendPkg008(const stuMsgHead& Smsg);
    
    ~CSendPkg008();
    
    INT32  doWorkSelf();

private:
    int  GetData(void);

    void FillBizHead(void);

    void FillBizBody(void);

    void SetEl_006(void);

    void SetEl_007(void);

    int  CreateNpcMsg(void);

    int  QryOrgnBiz(void);

    int  UpdatePkgSts(void);

    int  InsertData_cl(void);

    int  UpdateState(void);

    void AddMac008(void);

private:
    pkg008 m_cPkg008;

    string m_strElNo;

    string m_strPkgTp;

    double m_fTtlAmt;

    double m_fTtlAmtOk;

    int    m_iTtlCnt;

    int    m_iTtlCntOk;

    int    m_iBizTp;

    char   m_szPkgNo[35 + 1];

    CBpbcoutsndcl    m_bpsndcl;

    CBpbcoutsendlist m_bpsndlist; 

};

#endif


