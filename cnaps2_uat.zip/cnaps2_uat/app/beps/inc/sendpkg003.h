/*
 *  sendpkg003.h
 *  Description: һ��PKG003����������
 *  Created on: 2012-07-11
 *  Author: __wsh
 */

#ifndef SENDPKG003_H
#define SENDPKG003_H

#include "pkg003.h"
#include "sendbepsbase.h"

#include "bpbcoutsendlist.h"
#include "bpbcoutsndcl.h"


class CSendPkg003 : public CSendBepsBase
{
public:
    CSendPkg003(const stuMsgHead& Smsg);

    ~CSendPkg003();
    
    INT32  doWorkSelf();

private:
    int GetData(void);

    void SetData_cl(void);

    int InsertData_cl(void);

    void FillBizHead(void);

    void FillBizBody(void);

    void FillAppendData(void);

    int CreateNpcMsg(void);

    void AddMac003(void);
    
    int UpdateState(void);

    int CheckValue(void);

private:
    CBpbcoutsndcl    m_bpcl;

    CBpbcoutsendlist m_bplist;

    pkg003 m_cPkg003;

    string m_strAppendData;

    char m_szMsgId[32];
    
};

#endif /*SENDPKG003_H*/


