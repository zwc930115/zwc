/*
 *  recvbeps393.h
 *  Description: 批量签约应答(beps.393.001.01)来报处理类
 *  Created on: 2012-06-26
 *  Author: __wsh
 */

#ifndef RECVBEPS393_H_
#define RECVBEPS393_H_
#include "beps393.h"
#include "recvbepsbase.h"
#include "bpcstctrctmglist.h"
#include "bpcstctrctmgcl.h"
#include "bpcstctrctmg.h"

class CRecvBeps393 : public CRecvBepsBase
{
public:
    CRecvBeps393();

    ~CRecvBeps393();

    int Work(LPCSTR szMsg);

private:
    int UnPack(const char* szMsg);

    void CheckSign393(void);

    void SetData_cl(void);

    int InsertData_cl(void);

    void SetData_list(int iCount);

    int InsertData_list(void);

    int DealCstCtrct(void);

    int AddNewCstCtrct(void);

    int RecallCstCtrct(void);

    void QryOrgnBiz_cl(void);

    void QryOrgnBiz_list(void);

    int UpdateOrgnBiz(void);
    
private:
    beps393  m_cBeps393;

    CBpcstctrctmgcl   m_ccmcl;

    CBpcstctrctmglist m_ccmlist;

    CBpcstctrctmgcl   m_orgnccmcl;

    CBpcstctrctmglist m_orgnccmlist;

    CBpcstctrctmg     m_ccm;

};

#endif /* RECVBEPS393_H_ */

