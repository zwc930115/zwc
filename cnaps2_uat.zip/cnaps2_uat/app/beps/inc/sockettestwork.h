/********************************************************************
文件名：sockettestwork.h
创建人：hq
日  期：2011-05-17
修改人：
日  期：
描  述：SOCKET测试WORK
版  本：
Copyright (c) 2011  YLINK
********************************************************************/

#ifndef __SOCKETTSTWORK_H__
#define __SOCKETTSTWORK_H__

#include "basicapi.h"
#include "logger.h"
#include "pubfunc.h"

class CSocketTestWork
{
public:
    CSocketTestWork();
    ~CSocketTestWork();

    void clear();
        
	int doWork();
    int InsertDb();
	int SendtoHost();
    void setData(string sHostIp, string sTxId, string sMsgTp, int nHostPort);

    char	m_sMsg[256 + 1];
	int     m_nHostPort;
    string  m_szHostIp;
    string  m_szTxId;
    string  m_szMsgTp;

    DBProc  m_dbproc;
    
};

#endif


