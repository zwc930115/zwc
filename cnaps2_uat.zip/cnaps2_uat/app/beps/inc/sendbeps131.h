/******************************************************************** 
�ļ����� sendbeps131.h
�����ˣ� zys
��  ��   �� 2011-04-25
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __SENDBEPS131_H__
#define __SENDBEPS131_H__

#include "beps131.h"
#include "bpbdsndcl.h"
#include "bpbdsendlist.h"
#include "sendbepsbase.h"
class CSendBeps131 : public CSendBepsBase
{
public:
    CSendBeps131(const stuMsgHead& Smsg);
    ~CSendBeps131();
    
    INT32  doWorkSelf();
private:
    
    int getData();
    int CheckValues();
    int UpdateSndList(LPCSTR sProcstate);
	int insertSum();
	int buildPmtsMsg();
    void AddSign131();
	
    CBpbdsndcl		m_cbpbdsndcl;
    CBpbdsendlist	m_cbpbdsendlist;
    beps131         m_xml131;
};

#endif



