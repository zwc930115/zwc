/*
 *  recvpkg013.h
 *  Description: һ��PKG013����������
 *  Created on: 2012-06-07
 *  Author: __wsh
 */

#ifndef __RECVPKG013_H__
#define __RECVPKG013_H__

#include "recvbepsbase.h"
#include "pkg012.h"

#include "bpchckcdtforld.h"
#include "bprealtmcstacctmg.h"
#include "bpcfcaqry.h"

class CRecvPkg013 : public CRecvBepsBase
{
public:
	CRecvPkg013();

	~CRecvPkg013();

	INT32 Work(LPCSTR szMsg);

private:
	int UnPack(const char* szmsg);

	void InitConnCtx(void);

	void GetAddtlField(int iFldLen, string& strDbFld,
			bool bUtf8 = false, bool bAdd = false);

	int CheckValues(void);

	void SetData_ccfl_req(void);

	void SetData_ccfl_ans(void);

	void SetData_ccfl(void);

	int InsertData_ccfl(void);

	void SetData_caq_req(void);

	void SetData_caq_ans(void);

	void SetData_caq(void);

	int InsertData_caq(void);

	void SetData_cfca(void);

	int InsertData_cfca(void);

	int InsertData(void);

	int UpdateOrgnBiz_ccfl(void);

	int UpdateOrgnBiz_caq(void);

	int UpdateOrgnBiz_cfca(void);

	int UpdateOrgnBiz(void);

	int CheckMac013(void);

private:
	pkg012             m_cPkg012;

	CBpchckcdtforld    m_ccfl;

	CBprealtmcstacctmg m_cam;

	CBpcfcaqry         m_cfca;

	string             m_strTp; //ҵ������

	char               m_szTblNm[64];

	CEntityBase*       m_pEntity;

	char*              m_pszAddtl;

	int                m_iAddtlLen; //�����򳤶�

	int                m_iOffset;   //�������ֶ�ƫ��ֵ

	char               m_szBuffer[1024];
};

#endif

