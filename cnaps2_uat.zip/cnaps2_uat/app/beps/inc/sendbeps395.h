/*
 *  sendbeps395.h
 *  Description: �����ͻ���Ϣ��ѯӦ����beps.395.001.01����������
 *  Created on: 2012-06-12
 *  Author: __wsh
 */

#ifndef SENDBEPS395_H_
#define SENDBEPS395_H_


#include "beps395.h"
#include "sendbepsbase.h"

#include "bpcstacctqrycl.h"
#include "bpcstacctqrylist.h"

class CSendBeps395 : public CSendBepsBase
{
public:
	CSendBeps395(const stuMsgHead& Smsg);

    ~CSendBeps395();

    INT32  doWorkSelf();

private:

    int GetData(void);

    int CheckValues(void);

    void AddSign395(void);

    void SetAcctDtls(void);
    
    int SetRespInfo(void);

	int BuildPmtsMsg(void);

    int UpdateState(void);

private:

    beps395 m_cBeps395;

    CBpcstacctqrycl m_caqcl;

    CBpcstacctqrylist m_caqlist;

};

#endif /* SENDBEPS395_H_ */
