#ifndef _RECVBEPS726_H_
#define _RECVBEPS726_H_

#include "recvbepsbase.h"
#include "beps726.h"

#include "bpbeforecheck.h"
#include "bpbcoutsndcl.h"
#include "bpbcoutrcvcl.h"
#include "bpbdsndcl.h"
#include "bpbdrcvcl.h"
#include "bpcolltnchrgscl.h"
#include "cmtransinfoqry.h"


class CRecvBeps726: public CRecvBepsBase
{
public:
	CRecvBeps726();

	~CRecvBeps726();
	
	int Work(LPCSTR szMsg);
	
private:
  /*
	int  UnPack(LPCSTR lpcszMsg);

	int  ClearBeforeCheck(void);

	int  InsertData(void);

	void CheckSign726(void);

	void SetAndAddData(const char* pSrTp);

	void GetChckInfDtls1(int i = 0);
	
	void GetSndDtls1(int i = 0, int j = 0);

	void GetRcvDtls1(int i = 0, int j = 0);

	void GetChckInfDtls2(int i = 0);

	void GetSndDtls2(int i = 0, int j = 0);

	void GetRcvDtls2(int i = 0, int j = 0);

	int  DealBeforeCheck(void);

	int  ToBizTable(void);

	int  QueryLocalBiz(void);

	void DoCompare(void);

	void DealLocalMore(void);

	int  GetLocalMoreDebtCtdr(const char* szSql, int iDCFlag = 1);

	int  GetLocalMoreColltn(const char* szSql);

	int  GetLocalMoreTiq(const char* szSql);

	void InsertUserInfoTel(void);

	bool AmtEqual(double dAmt1, double dAmt2);

private:
	beps726        m_cBeps726;
	CBpbeforecheck m_bpbc;
	string         m_strChkDt;
	string         m_strInstdDrctPty;
	string         m_strTx2;
	//----------------------------
	string TxTpCd;
	string SndTtlCnt;
	string SndTtlAmt;
	string RcvTtlCnt;
	string RcvTtlAmt;

	string OrgnlMsgId;
	string OrgnlInstgPty;
	string OrgnlMT;
	string TtlCnt;
	string Ccy;
	string CtrlSum;
	string PrcSts;
	//---------------------------
	char   m_szTblNm[64];
	string m_strChkSt;   //����״̬
	bool   m_bIsBiz;     //�Ƿ�ҵ���౨��
	int    m_iBizCnt;    //���ش��ҵ�����ҵ�����
	double m_dCtrlSum;   //���ؽ��
	string m_strBizSt;   //����ҵ��״̬
	*/
};

#endif


