#ifndef _RECVBEPSBASE_H_
#define _RECVBEPSBASE_H_

#include "pkgbase.h"
#include "pubfunc.h"
#include "exception.h"
#include "logger.h"
#include "bprecvmsg.h"
#include "cmrecverrmsg.h" 
#include "charge.h"
#include "mqagent.h"
extern MQAgent m_cMQAgent; 
extern DBProc  m_dbproc;


class CRecvBepsBase
{
public:
    CRecvBepsBase();
    virtual ~CRecvBepsBase();

	INT32	doWork(LPCSTR pchMsg);
	INT32	doChildWork(LPCSTR pchMsg);
    INT32	SetData(LPCSTR pchMsg);

    //组附加域字段,没有循环的情况下可用
    void    AddAppData(string& strPmttpprtry, int iArray[], const char* strAppData, string& szDstData, int iArraySize, int iNum=0, int iLen = 0);
	    void SetFieldAsGbk(const string& strVal, char* szField, int iLen);
    void SetFieldAsUtf8(const char* szField, string& strDst);
	/******************************************************************************
	*  Function:   CheckPkgMac
	*  Description:一代报文核押凼数(南洋专用)
	*  Input:      oPkgBase 
	*              pRefStr   20位密押参考值
	               pSendSapBank 发起清算行号
	*  Return:     0：   成功
	*              其他：失败
	*  Others:     无
	*  Author:     aps-lel
	*  Date:       2012-02-16
	*******************************************************************************/
	int CheckPkgMac(pkgbase& oPkgBase,const char *pRefStr,const char* pSendSapBank);
	void SetFieldAsUtf8(char* szField, string& strDst);

    stuPKGAssist m_strAssist;
	
	bool CheckUserState(string mt,string acct);
	void doMd5(string& strSrc, string& strDst);

    //一代打包辅助表的更新
    int UpPKGAssist1(LPTSTR pMsgId);

bool CheckAgreemet(string agrmtnb,string ctrctagrmttp,string dbtrid,string acctsts);
	
	string	m_strBizCode;       //交易码(写错误文件名用,recvbpwork赋值)
	int		m_iMsgVer;			//1:一代报文;2:二代报文	
	string	m_strRcvMsgID;      //来帐MSGID(自拼标识符,删除通讯表用,recvbpwork赋值)
    char	m_sSapBank[14 + 1]; //支付系统默认清算行号
    char	m_sWorkDate[8 + 1]; //小额系统当前工作日期
    char	m_sIsoWorkDate[19 + 1]; //系统工作iso日期
    char	m_sCommHead[42 + 1];//通讯层报文头
    string  m_strSendMsg;       //发送报文串
    int    m_iErrMsgFlag;  //异常消息标志
    bool	m_agreeanduser;
	string m_strErrCode;
	string m_strErrDesc;
    bool m_IsSendMB;

protected:
	
	//业务处理入口函数
	virtual INT32  Work(LPCSTR szMsg) = 0; 
	void     CheckSign(const char *srcSign, const char *dstSign, const char * sSendBankCode, int iFlag = RAWSIGN);
    void     AddSign(const char *srcSign, char *dstSign, int iFlag);
    int AddSign(const char *srcSign, char *dstSign, int iFlag, const char * pSendSapbank);
    
	int		 AddQueue(string msgtx, int length);
	void     DirectInter(LPCSTR cpSendBank, LPCSTR cpRecvBank, LPCSTR cpRecvSapBank, LPCSTR cpTxid, LPCSTR cpNpcMsg, LPCSTR cpIngoingDetailTable = NULL, LPCSTR cpPmtTpPrtry = NULL);
	int		iRet;
	//DBProc	m_dbproc;
	string	m_strMsgID;         //报文MSGID(写错误文件名用,子业务赋值)
	bool	m_bIfOptBigData;    //操作大字段表
	char	m_szErrMsg[1024+1];	//错误描述
	string	m_strWorkDate;		//工作日期
	string	m_strMsgTp;			//报文类型:二代BEPS开头,一代PKG开头
	string	m_szOriSign;
	char m_szOprUser[20+1];//最终操作用户
	char m_szOprUserNetId[20+1]; //用户所属机构
    CCharge m_charge;	//记账及虚拟清算    
    //MQAgent         m_cMQAgent;
    string  m_ErrMsgTp;
	char	m_szIngoingDetailTable[40 + 1];		// 来账明细表名
	char	m_szPmtTpPrtry[6 + 1];				// 业务类型编码
private:
	
    CBprecvmsg		m_cBprecvmsg;       
    CCmrecverrmsg   m_cCmrecverrmsg;
	
	void	GetDBConnect(void);

	void	GetMqConn(void);
	
	INT32	DelBpRecvMsg(void);
	
	INT32	WriteErrTable(LPCSTR pchMsg, int nErrCode, LPCSTR pchErrDesc);

	INT32	WriteErrFile(const char * pchErrText = NULL);
	
    INT32	DoException(LPCSTR pchMsg, int nErrCode, LPCSTR pchErrDesc);

	void	Send990(LPCSTR pchMsg);
void Init();
};

#endif


