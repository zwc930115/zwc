/******************************************************************** 
�ļ����� sendpkg001.h
�����ˣ� handongfeng
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef __SENDPKG001_H__
#define __SENDPKG001_H__

#include "pkg001.h"
#include "bpbcoutsendlist.h"
#include "sendbepsbase.h"

class CSendPkg001 : public CSendBepsBase
{
public:
    CSendPkg001(const stuMsgHead& Smsg);
    ~CSendPkg001();
    
    INT32  doWorkSelf();
    
private:
    
    INT32 GetData();
    INT32 CheckValues();
    INT32 ChargeMb();
    INT32 CreateNpcMsg();
    INT32 UpdateSndList(LPCSTR sProcstate);
    INT32 SetErrACK(int iErrCode, LPCSTR pErrDesc);
    INT32 UpdatePkg();
    int FundSettle();
    CBpbcoutsendlist	m_cBpbcsndlist;
    pkg001 m_pkg001;
    char				m_sPkgNo[35 + 1];
};

#endif


