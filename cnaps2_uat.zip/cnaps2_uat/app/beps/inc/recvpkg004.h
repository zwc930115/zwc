
#ifndef RECVPKG004_H
#define RECVPKG004_H

#include "recvbepsbase.h"
#include "pkg003.h"
#include "pkg008.h"

#include "bpbcoutsendlist.h"
#include "bpbcoutsndcl.h"
#include "bpbdrecvlist.h"
#include "bpbdrcvcl.h"


class CRecvPkg004 : public CRecvBepsBase
{
public:
	CRecvPkg004();

	~CRecvPkg004();

	INT32 Work(LPCSTR szMsg);
    
private:
	int  UnPack(const char* szmsg);

	int  InsertData(void);

	int  InsertData_bc_cl(void);

	int  InsertData_bc_list(void);

	int  InsertData_bd_cl(void);

	int  InsertData_bd_list(void);

	void GetAappendData(void);

	void GetAddtl_30103(void);

	void GetAddtl_20101(void);

	void GetAddtl_30101(void);

	void GetAddtl(int iLen, bool bUtf8=false, bool bAmt=false);

	void FillBizHead(void);

	void FillBizBody(void);

	void SetReply(void);

	int  BuildReplyMsg010(void);

	void ChkMac004(void);

	void AddMac010(void);

	int  DoReply(void);

private:
	pkg003           m_cPkg003;

	pkg008           m_cPkg008;

	CBpbdrcvcl       m_bdrcvcl;

	CBpbdrecvlist    m_bdrcvlist;

	CBpbcoutsndcl    m_bcsndcl;

	CBpbcoutsendlist m_bcsndlist;

	string           m_strNpcMsg;

	string           m_strBizTp;

	string           m_strVal;

	int              m_iCurPos;

	char             m_szMsgId_r[32+1];

	char             m_szTxId_r[32+1];

	char             m_szMessRefId[32+1];

	char             m_szRefId[32+1];

	char             m_szMsgId[32+1];

	char             m_szTxId[32+1];
};

#endif /*RECVPKG004_H*/


