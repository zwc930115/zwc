/******************************************************************** 
文件名： recvbeps386.h
创建人： aps-lel
日  期： 2011-04-09
修改人： 
日  期： 
描  述：小额来帐beps.386报文处理类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef __RECVBEPS386_H__
#define __RECVBEPS386_H__

#include "recvbepsbase.h"
#include "beps386.h"
#include "beps387.h"
#include "beps388.h"
#include "beps389.h"
#include "beps389.h"
#include "bpbizpubntce.h"
#include "bpcolltnchrgscl.h"
#include "bpcolltnchrgslist.h"


class CRecvbeps386 : public CRecvBepsBase
{
public:
    CRecvbeps386();
    ~CRecvbeps386();
    int Work(LPCSTR szMsg);
    
private:
	
	//报文入汇总表
    INT32 InsertData();
	
	//报文入明细表
    INT32 SetData(LPCSTR pchMsg);
	
    INT32 unPack(LPCSTR szMsg);
    void InsertReturnData();

	//核签
	void CheckSign386();

	//组回执报文
	int CreatePmtsMsg();
	void SendRtuMsg();
	int CheckArgeeAndUser();
    int AddSign389();
    int AddSign388();
    int AddSign387();	
	STRING Trim(STRING& sStr);
void Insert387Data();
    beps386			    m_cBeps386;
	beps389			    m_beps389;
	beps387			    m_cBeps387;
	beps388				m_beps388;
    CBpbizpubntce m_Bpbizpubntce;
    CBpcolltnchrgscl	m_cBpcolltnchrgscl;
    CBpcolltnchrgslist	m_cBpcolltnchrgslist;

    CBpcolltnchrgscl	m_colltnchrgscl387;
    CBpcolltnchrgslist	m_colltnchrgslist387;

	int					m_iChgTp; 				//变更类型:0：新增，1：撤销
	char				m_sMsgRefId[20 + 1];	//报文参考号
	char				m_sMsgId[35+1];			//报文标识号
	string				m_strAppData;			//实时回执明细
	string				m_strColltnwrkdt;		//代收付工作日        
    char m_MsgRefId387[20+1];

};

#endif

