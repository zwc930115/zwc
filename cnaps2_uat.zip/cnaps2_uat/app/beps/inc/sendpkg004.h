/*
 *  sendpkg004.h
 *  Description: һ��PKG004����������
 *  Created on: 2012-09-22
 *  Author: __wsh
 */

#ifndef SENDPKG004_H
#define SENDPKG004_H

#include "pkg003.h"
#include "sendbepsbase.h"

#include "bpbdsendlist.h"
#include "bpbdsndcl.h"


class CSendPkg004 : public CSendBepsBase
{
public:
    CSendPkg004(const stuMsgHead& Smsg);

    ~CSendPkg004();
    
    INT32  doWorkSelf();

private:
    int GetData(void);

    void SetData_cl(void);

    int  InsertData_cl(void);

    void FillBizHead(void);

    void FillBizBody(void);

    void FillAppendData(void);

    void FillAddtl_30103(void);

    void FillAddtl_20101(void);

    void FillAddtl_30101(void);

    void AddAddtl(const char* szFmt,int iLen,
    		      bool bGbk = false, bool bAmt = false);

    int  CreateNpcMsg(void);

    void AddMac004(void);
    
    int  UpdateState(void);

    int  CheckValue(void);

private:
    CBpbdsndcl    m_bpcl;

    CBpbdsendlist m_bplist;

    pkg003 m_cPkg003;

    string m_strAppendData;

    string m_strVal;

    string m_strBizTp;

    char m_szPkgNo[32]; //���ı�ʶ
    
    int  m_iAddtlNo;

};

#endif /*SENDPKG004_H*/


