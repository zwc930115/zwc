/******************************************************************** 
�ļ����� sendbeps121.h
�����ˣ� zwy
��  �ڣ� 2011-03-07
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __SENDBEPS123_H__
#define __SENDBEPS123_H__

#include "beps123.h"
#include "bpbcoutsndcl.h"
#include "bpbcoutsendlist.h"
#include "sendbepsbase.h"

class CSendBeps123 : public CSendBepsBase
{
public:
    CSendBeps123(const stuMsgHead& Smsg);
    ~CSendBeps123();
    
    INT32  doWorkSelf();
private:
    
    int getData();
    int CheckValues();
    int UpdateSndList(LPCSTR sProcstate);
	int insertSum();
    void AddSign123();
	int buildPmtsMsg();
    void GetTag2ND(const string& QryVal, const string& QryStr, int& iDepth);
	
    CBpbcoutsndcl    m_cBpbcoutsndcl;
    CBpbcoutsendlist m_cBpbcoutsendlist;
    beps123          m_oBeps123;
};

#endif



