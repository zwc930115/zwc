/*
 *  recvbeps394.h
 *  Description: 批量客户账户查询来报处理类beps.394.001.01
 *  Created on: 2012-6-12
 *  Author: __wsh
 */
#ifndef RECVBEPS394_H_
#define RECVBEPS394_H_

#include "recvbepsbase.h"
#include "beps394.h"
#include "bpcstacctqrylist.h"
#include "bpcstacctqrycl.h"

class CRecvbeps394 : public CRecvBepsBase
{
public:

	CRecvbeps394();

    ~CRecvbeps394();

    int Work(LPCSTR szMsg);

private:

    int UnPack(LPCSTR szMsg);

	int SetData_cl(void);

	int InsertData_cl(void);

	int GetAcctDtls(int iCount);

	int SetData_list(int iCount);

	int InsertData_list(void);

	void CheckSign394(void);
	
private:

    beps394	          m_cBeps394; 

    CBpcstacctqrycl   m_caqcl;

    CBpcstacctqrylist m_caqlist;

};

#endif /* RECVBEPS394_H_ */


