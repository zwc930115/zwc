#ifndef _SENDPKG_H_
#define _SENDPKG_H_

#include "parser121.h"

#include "exception.h"
#include "pubfunc.h"
#include "category.h"
#include "mqagent.h"

#include "bpbcoutsendlist.h"


class CSendPkg
{
public:
    CSendPkg();
    virtual ~CSendPkg();

	void setData(LPCSTR pWrkDate, LPCSTR pSendBank, LPCSTR pRecvBank, LPCSTR pMsgTp, LPCSTR pMsgId);

	INT32 Work();
	
private:
	void GetDBConnect(void);
    
    int AddQueue(LPCSTR pMsgText, int iLength);

	void DoPkg001();
	void DoPkg002();
	void DoPkg003();
	void DoPkg004();
	void DoPkg005();
	void DoPkg006();
	void DoPkg007();

private:

	DBProc	m_dbproc;
	char	m_szErrMsg[1024+1];		//��������
	char	m_sSapBank[14 + 1];		//֧��ϵͳĬ�������к�
	char	m_sWorkDate[8 + 1];		//С��ϵͳ��ǰ��������
	char	m_sIsoWorkDate[19 + 1];	//ϵͳ����iso����
	char	m_sMsgRefId[16 + 1];	//���Ĳο���
	
	string	m_strWrkDate ;
	string	m_strSendBank;
    string	m_strRecvBank;
    string	m_strMsgType ;
	string	m_strMsgID   ;			//�����
	int		m_iMsgNo	 ;
	
	string	m_strMsgTxt  ;
};

#endif


