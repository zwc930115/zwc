/*
 *  sendpkg013.h
 *  Description: һ��PKG013����������
 *  Created on: 2012-06-07
 *  Author: __wsh
 */

#ifndef __SENDPKG013_H__
#define __SENDPKG013_H__

#include "pkg012.h"
#include "sendbepsbase.h"

#include "bprealtmcstacctmg.h"
#include "bpchckcdtforld.h"
#include "bpcfcaqry.h"

class CSendPkg013 : public CSendBepsBase
{
public:
    CSendPkg013(const stuMsgHead& Smsg);
    ~CSendPkg013();
    
    INT32  doWorkSelf();
    
private:
    INT32 GetData_ccfl(void);

    INT32 GetData_caq(void);

    INT32 GetData_cfca(void);

    INT32 GetData(void);

    void FillAppendData_ccfl_req(void);

    void FillAppendData_ccfl_ans(void);

    void FillAppendData_caq_req(void);

    void FillAppendData_caq_ans(void);

    void FillAppendData_cfca(void);

    void FillAppendData(void);

    void FillBizHead(void);

    void FillBizBody(void);

    INT32 GetMsgId(void);

    INT32 CreateNpcMsg(void);

    INT32 UpdateState(void);

private:
    pkg012 m_cPkg012;

    CBprealtmcstacctmg m_cam;

    CBpchckcdtforld m_ccfl;

    CBpcfcaqry m_cfca;

    CEntityBase* m_pEntity;

    char m_szTblNm[64];

    string m_strAppendData;

    string m_strInstgdrctpty;

    string m_strInstddrctpty;

    string m_strWorkDate;

    string m_strRmk;

    string m_strInstgpty;

    string m_strInstdpty;

    string m_strNewMsgId;
};

#endif


