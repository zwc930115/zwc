/******************************************************************** 
文件名： sendpkg011.h
创建人： hq
日  期： 2011-04-18
修改人： 
日  期： 
描  述： PKG008普通借记回执包/PKG011定期借记回执 包往账处理
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef __SENDPKG011_H__
#define __SENDPKG011_H__

#include "pkg008.h"
#include "bpbcoutsendlist.h"
#include "sendbepsbase.h"

class CSendPkg011 : public CSendBepsBase
{
public:
    CSendPkg011(const stuMsgHead& Smsg);
    ~CSendPkg011();
    
    INT32  doWorkSelf();
    
private:
    
    INT32 GetData();
    INT32 CheckValues();
    INT32 ChargeMb();
    INT32 SetErrACK(int iErrCode, LPCSTR pErrDesc);
    INT32 CreateNpcMsg();
	INT32 UpdatePkg();
    INT32 UpdateSndList(LPCSTR sProcstate);
    int   FundSettle();
    
    CBpbcoutsendlist  m_cBpbcsndlist;
    char	          m_sPkgNo[35 + 1];
};

#endif


