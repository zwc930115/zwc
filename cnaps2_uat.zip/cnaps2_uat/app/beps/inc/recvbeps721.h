
#ifndef RECVBEPS721_H
#define RECVBEPS721_H

#include "recvbepsbase.h"
#include "beps721.h"
#include "beps722.h"

#include "bpcheckcl.h"
#include "checkaccount.h"
#include "bpbchkstate.h"
#include "bepschecksum.h"
#include "bpchkhelper.h"
#include "cmcheckqry.h" 
#include "bpsapbankinfo.h"
class CRecvBeps721 : public CRecvBepsBase
{
public:
	CRecvBeps721();

	~CRecvBeps721();

	int Work(LPCSTR szMsg);
	
private:
	int  UnPack(LPCSTR szMsg);

	void SetConnCtx(void);

	int  CheckBChkState(void);

	int  ClearCheckCl(void);

	int  UpdateSapBkChkDt(void);

	int  DoCheck(void);

	int  InsertData(void);

	void GetChckPmtInfDtls(int i = 0);

	void GetChckMsg(int i = 0);

	int  AddCheckCl(void);

	int  QueryLocalSum(void);

	void GetSql(string& strSql, LPCSTR SR);

	int  DoSumCrdtDebt(void);

	int  DoSumColl(LPCSTR SR);

	int  DoSumTiq(LPCSTR SR);

	void DoCompare(void);

	int  ToBizTable(void);

	int  UpdateBChkState(LPCSTR szChkSt);

	int  UpdateBizChkState(LPCSTR szSR, LPCSTR szChkSt);

	int  CallMbCheck(void);

	void ChkSign721(void);

	int  RequestCheckList722(void);

	void AddDtlChckPmt722(LPCSTR szSR);

	void AddDtlChckMsg722(LPCSTR szSR);
	
	bool AmtEqual(double dAmt1, double dAmt2);
	
	bool ChickIfContuine();
private:
	beps721       m_cBeps721;   //721报文解析类
	beps722       m_cBeps722;   //722报文解析类
	CBpcheckcl    m_chkcl;      //小额汇总对账表
	CCheckAccount m_chkacct;    //
	CBpbchkstate  m_bchkst;     //小额对账状态表
	CBepsCheckSum m_chksum;     //汇总汇总对账辅助类
	CBpChkHelper  m_chkhelper;  //小额对账工具类
	CMcheckqry      m_checkqry;
	CBpsapbankinfo  m_sapbankinfo;
		
	string        m_strChkSt;   //对账状态
	string        m_strBizChkSt;//业务对账状态
	string        m_strSSql;    //查询本地往账SQL语句
	string        m_strRSql;    //查询本地来账SQL语句

	string        m_strMT;      //报文类型
	string        m_strInstgpty;//发起行
	string        m_strPrcSts;  //处理状态

	int           m_iTtlCnt;    //汇总交易总笔数
	int           m_iLocalMore; //本地多笔数

	int           m_iSTtlCnt;   //汇总往报笔数
	double        m_dSTtlAmt;   //汇总往报金额
	int           m_iRTtlCnt;   //汇总来报笔数
	double        m_dRTtlAmt;   //汇总来报金额

	int           m_iLocalSTtlCnt; //本地汇总往报笔数
	double        m_dLocalSTtlAmt; //本地汇总往报金额
	int           m_iLocalRTtlCnt; //本地汇总来报笔数
	double        m_dLocalRTtlAmt; //本地汇总来报金额

	char          m_szSTblNm[64];  //当前对账报文往报表名
	char          m_szRTblNm[64];  //当前对账报文来报表名
	char          m_szSLsTblNm[64];//当前往报明细表,借贷记明细用
	char          m_szRLsTblNm[64];//当前来报明细表,借贷记明细用
	bool          m_bIsPmt;

	int           m_iPmtCnt722; //722业务类报文笔数
	int           m_iMsgCnt722; //722信息业报文笔数
};

#endif


