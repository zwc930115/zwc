/******************************************************************** 
�ļ����� recvpkg007.h
�����ˣ� handongfeng
��  �ڣ� 2011-04-15
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifndef __RECVPKG007_H__
#define __RECVPKG007_H__

#include "recvbepsbase.h"
#include "pkg007.h"
#include "bpbcoutrecvlist.h"
#include "bpbcoutrcvcl.h"
#include "bpbcoutsendlist.h"
#include "bpbcoutsendlisthis.h"

class CRecvPkg007 : public CRecvBepsBase
{
public:
	CRecvPkg007();
	~CRecvPkg007();
	INT32 Work(LPCSTR szMsg);
    
private:
	INT32 unPack(LPCSTR szMsg);
	INT32 InsertDb(LPCSTR pchMsg);
    void CreatePkg009();
    void CreateMsgBody();
    void InsertBCsendList(LPCSTR pchMsg);
    void UpdateOrgnlBiz(const string& dbtrbrnchid, const string& txid);
    INT32 CheckAcct();
    int  CheckMac007();
	int FundSettle();
	pkg007         m_pkg007;
	CBpbcoutrcvcl  m_Bpbcoutrcvcl;
    CBpbcoutrecvlist m_Bpbcoutrecvlist;
    string  m_strOrgnlTable;
    string  m_strOrgnlTxid;
    string  m_strOrgnlDbtrbrnchid;
    
};

#endif



