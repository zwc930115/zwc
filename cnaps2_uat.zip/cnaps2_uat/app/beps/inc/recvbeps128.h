#ifndef RECVBEPS128_H
#define RECVBEPS128_H

#include "recvbepsbase.h"
#include "beps128.h"

#include "bpbcoutrecvlist.h"
#include "bpbcoutrcvcl.h"
#include "bpbdsendlist.h"


class CRecvBeps128 : public CRecvBepsBase
{
public:
	CRecvBeps128();

	~CRecvBeps128();

	INT32 Work(LPCSTR szMsg);

private:
	int  UnPack(const char* szmsg);

	int  QryOrgnlBiz(void);

	int  InsertData(void);

	int  InsertData_cl(void);

	int  InsertData_list(void);

	int  UpdateOrgnlBiz(void);
	
	int  UpdateOrgnlBiz_list(void);

	void ChkSign128(void);

	int  CheckValues(void);

	int  FundSettle(void);

	int  ChargeMb(void);


private:
	CBpbcoutrcvcl    m_bcrcvcl;

	CBpbcoutrecvlist m_bcrcvlist;

	CBpbdsendlist    m_orgnlbiz;

	beps128          m_cBeps128;

	string           m_strNpcMsg;
	
};

#endif /*RECVBEPS128_H*/


