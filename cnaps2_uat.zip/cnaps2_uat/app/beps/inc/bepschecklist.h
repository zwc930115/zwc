/******************************************************************** 
文件名： bepsckecklist.h
创建人： hq
日  期： 2011-06-08
修改人： 
日  期： 
描  述： 小额明细对账类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef _BEPSCHECKLIST_H_
#define _BEPSCHECKLIST_H_

#include "basic.h"
#include "connectpool.h"
#include "checkaccount.h"
#include "bepschecksum.h"
#include "bpchklstlist.h"
#include "beps724.h"
#include "mqagent.h"

class CBepsCheckList
{
public:
    
    CBepsCheckList();
    ~CBepsCheckList();

    void doCheckListWork(DBProc &dbProc,
                        int iChkTp, 
                        LPCSTR sChkDt, 
                        LPCSTR sBankCode, 
                        MQAgent &cMQAgent, 
                        LPCSTR sSendQueue);

public:

    int  m_iTtlCnt;        //724明细数目
    
    bool m_bBCoutSnd;      //是否有贷记往账
    bool m_bBCoutRcv;      //是否有贷记来账
    bool m_bCollTnchrgs;   //是否有代收付
    bool m_bBdSnd;         //是否有借记往账
    bool m_bBdRcv;         //是否有借记来账
    bool m_bTransInfoQry;  //是否有查询查复
    
private:

    void CountMsgTp();
    void UpdateState();
    void IsSend724(MQAgent &cMQAgent, LPCSTR sSendQueue);
    void AddDetail724();
    void updateBkChkSt(LPCSTR _sChkSt);
    void CreateHvps724(MQAgent &cMQAgent, LPCSTR sSendQueue);
    void SetAllCtx();
        
    beps724       m_beps724;
    CCheckAccount m_checkaccount;
    CBpchklstlist m_bpchklstlist;
    CBepsCheckSum m_bpchecksum;

    DBProc m_dbproc;
    
    STRING m_szChkDt;      //对账日期
    STRING m_szBkCode;     //清算行号
    STRING m_sCycleDigntr; //循环体数字加签串
};

#endif


