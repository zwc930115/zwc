#ifndef RECVPKG009_H
#define RECVPKG009_H

#include "recvbepsbase.h"
#include "pkg008.h"

#include "bpbdrecvlist.h" 
#include "bpbdrcvcl.h" 

#include "bpbcoutsendlist.h"


class CRecvPkg009 : public CRecvBepsBase
{
public:
	CRecvPkg009();

	~CRecvPkg009();

	INT32 Work(LPCSTR szMsg);

private:
	int  UnPack(const char* szmsg);

	int  QryOrgnlBiz(void);

	int  InsertData(void);

	int  InsertData_cl(void);

	int  InsertData_list(void);

	int  UpdateOrgnlBiz(void);

	void ChkMac009(void);

	int  CheckValues(void);

	int  FundSettle(void);

	int  ChargeMb(void);	
private:
	CBpbdrcvcl       m_bdrcvcl;

	CBpbdrecvlist    m_bdrcvlist;

	CBpbcoutsendlist m_orgnlbiz;

	pkg008           m_cPkg009;
	
	string           m_strNpcMsg;

	char             m_szMsgId[32+1];

	char             m_szTxId[32+1];
};

#endif /*RECVPKG009_H*/


