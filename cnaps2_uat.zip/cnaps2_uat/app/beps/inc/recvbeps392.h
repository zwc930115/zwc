/*
 *  recvbeps392.h
 *  Description: 批量签约(beps.392.001.01)来报处理类
 *  Created on: 2012-5-25
 *  Author: __wsh
 */

#ifndef RECVBEPS392_H_
#define RECVBEPS392_H_

#include "beps392.h"
#include "recvbepsbase.h"

#include "bpcstctrctmgcl.h"
#include "bpcstctrctmglist.h"

class CRecvBeps392 : public CRecvBepsBase
{
public:
	CRecvBeps392();

    ~CRecvBeps392();

    int Work(LPCSTR szMsg);

private:

    INT32 UnPack(LPCSTR szMsg);

    INT32 SetData_cl();

    INT32 InsertData_cl();

    INT32 SetData_list(int iCount);

    INT32 InsertData_list();

    void  CheckSign392();
    
private:

    beps392 m_cBeps392;

    CBpcstctrctmgcl m_ccmcl;

    CBpcstctrctmglist m_ccmlist;

};


#endif /* RECVBEPS392_H_ */
