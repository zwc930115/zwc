/********************************************************************
文件名：sendtomb.cpp
创建人：hpch
日  期：2011-03-03
修改人：
日  期：
描  述：往行内发送报文主控
版  本：
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif


#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include "exception.h"
#include "connectpool.h"
#include "mqagent.h"
#include "configparser.h"
#include "logger.h"
#include "thread.h"
#include "pubfunc.h"
#include "basic.h"
#include "cfg_obj.h"
#include "syscomsendmb.h"
#include "hvrecvmsg.h"

using namespace ZFPT;

//add zwc 20171024
extern MQAgent 		m_cMQAgent;
//add zwc 20171024


class Rout{
public:
	Rout();
	~Rout();
	int Init();
	int PutMsg(const char * sMsg);
	CCfgObj 		pCfgFile;
	
	char			g_MQmgr[256];
	char			g_MqTxtPath[256];
	char			g_SendQueue[128];
	char			g_SendCBSP[128];
	char			g_RecvTel[128];
	int 			g_IsConnCBSP;
	char			g_IP[16];
	int 			g_IsConnPlatm;
	char			szBepsBat[1024];
	
	char g_szBatPutMqN[60];//非实时
	char g_szRtPutMqN[60];//实时
	list<string> listBatMt; 				 //批量消息类型
	
    stuCfgInfo  CfgInfo ;	
	//del by zwc 20171024 修改为外部全局变量
	//MQAgent 		cAgent;
	//del end 
	
	//按照给定分割符分解字符串
	void div_str(const char* s, int iDelim, list<string>& l);
	//获取往报代号
	int get_gen_no(const char* pszmsg);
	//获取清算行号
	char* get_bank_no(const char* pszmsg, int iGenNo, char* buffer);
	//获取消息类型
	char* get_msg_type(const char* pszmsg, int iGenNo, char* buffer);
	//获取往报队列
	char* get_putmqn(const char* pszmsg, char* buffer);
	
	int LoadConfigFile(stuCfgInfo &CfgInfo);
	
};









