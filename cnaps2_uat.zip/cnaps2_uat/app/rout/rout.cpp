/********************************************************************
文件名：sendtomb.cpp
创建人：hpch
日  期：2011-03-03
修改人：
日  期：
描  述：往行内发送报文主控
版  本：
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include "exception.h"
#include "connectpool.h"
#include "mqagent.h"
#include "configparser.h"
#include "logger.h"
#include "thread.h"
#include "pubfunc.h"
#include "basic.h"
#include "cfg_obj.h"
#include "syscomsendmb.h"
#include "hvrecvmsg.h"

#include "rout.h"

using namespace ZFPT;

Rout::Rout()
{

}
Rout::~Rout()
{


}

int Rout::Init()
{
    
    char        sErrDesc[1024]        = {0};
    int         iRet                  = 0;	
	
    try
    {
        //加载配置文件
        LoadConfigFile(CfgInfo);
    	
        //初始化日志
        //ZFPTLOG.setCfgInfo(CfgInfo.szLogPath, "sendtomb", CfgInfo.iLogLeave, CfgInfo.dLogMaxSize);
        
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化日志...");		

        //初始化MQ 
        if(m_cMQAgent.Init(CfgInfo.szMQmgr, CfgInfo.szMqTxtPath) != RTN_SUCCESS)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Init MQ manager failed.");

			return -1;
        }

        if(m_cMQAgent.Init(CfgInfo.szMQmgr, CfgInfo.szMqTxtPath) != RTN_SUCCESS)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Init MQ manager failed.");

			exit(0);
        }        
        
        //读XML配置文件
        iRet = pCfgFile.Init(CfgInfo.szXmlCtgPath);  //配置文件路径
        if(iRet != 0)
        {
            sprintf(sErrDesc, "Failed to Init the node Config Object: ErrCode = %d, ErrInfo = %s", pCfgFile.GetLastErrCode(),pCfgFile.GetLastErrInfo());
        	Trace(L_ERROR,  __FILE__,  __LINE__, NULL,sErrDesc);
        	
        	return -1;
        }
		
        if(iRet == RTN_SUCCESS)
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "连接池创建成功");
        }
        else
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "连接池创建失败");
            
            return -1;
        }

    }catch(CException &e)
    {
        sprintf(sErrDesc, "Catch a exception from [%s]",  e.what());
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);
        
		return -1;
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "开始从发往行内通讯表中取消息");


    return RTN_SUCCESS;
}




int Rout::LoadConfigFile(stuCfgInfo &CfgInfo)
{
    //先读配置，再加载日志程序，所以此函数是不能打印日志的
    
    CConfigParser& cCfg = CConfigParser::getInstance();

    strcpy(CfgInfo.path, ZFPT_CFG_PATH);
    cCfg.loadConfig(CfgInfo.path);

	strncpy(CfgInfo.szXmlCtgPath, cCfg.getOption("XMLCTGPATH"), sizeof(CfgInfo.szXmlCtgPath)-1);
    strncpy(CfgInfo.szLogPath   , cCfg.getOption("LOGPATH")   , sizeof(CfgInfo.szLogPath)-1   );
    CfgInfo.iLogLeave       = atoi(cCfg.getOption("LOGLVL")    );
	CfgInfo.dLogMaxSize     = atof(cCfg.getOption("LOGMAXSIZE"));
	
	strncpy(CfgInfo.szMQmgr    , cCfg.getOption("MQMGR")     , sizeof(CfgInfo.szMQmgr)-1    );
	strncpy(CfgInfo.szMqTxtPath, cCfg.getOption("MQTEXTPATH"), sizeof(CfgInfo.szMqTxtPath)-1);

	memset(g_MQmgr     , 0x00, sizeof(g_MQmgr)    );
	memset(g_SendQueue , 0x00, sizeof(g_SendQueue));
	memset(g_RecvTel , 0x00, sizeof(g_RecvTel));
	memset(g_MqTxtPath , 0x00, sizeof(g_MqTxtPath));
	strncpy(g_MQmgr    , cCfg.getOption("MQMGR")     , sizeof(g_MQmgr)-1    );
    strncpy(g_MqTxtPath, cCfg.getOption("MQTEXTPATH"), sizeof(g_MqTxtPath)-1);
    
	strncpy(szBepsBat, cCfg.getOption("BEPSBAT"), sizeof(szBepsBat)-1);

	strncpy(g_szBatPutMqN, cCfg.getOption("TOPSBAT"), sizeof(g_szBatPutMqN)-1);
	strncpy(g_szRtPutMqN, cCfg.getOption("TOPSONLINE"), sizeof(g_szRtPutMqN)-1);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "g_szBatPutMqN = [%s]", g_szBatPutMqN);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "g_szRtPutMqN = [%s]", g_szRtPutMqN);
    
    return OPERACT_SUCCESS;
}


/******************************************************************************
*  Function:   GetAndPutMsg
*  Description:从发往行内通讯表取消息并将消息发送到行内MQ队列
*  Input:	   无
*  Output:	   
*  Return:	   0   : 操作成功,
			   其他: 操作失败
*  Others:	   无
*  Author:	   zys
*  Date:	   2011-02-21
*******************************************************************************/
int Rout::PutMsg(const char * sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering GetMsg");	

	int    iRet = RTN_FAIL;    

    char pPutQueName[60] = {0};
    
	if(NULL == get_putmqn(sMsg, pPutQueName))
	{
		Trace(L_ERROR, __FILE__, __LINE__,
			NULL, "Invalid message: [%s] can't find the MBFE config!", sMsg); 
		return -1;
	}

    
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "SEND MSGMB MQ:[%s]", pPutQueName);

    iRet = m_cMQAgent.PutMsg(pPutQueName, sMsg, strlen(sMsg));

    if(0 == iRet)
    {	
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "=============================SEND MSG TO MB SUCCESS MQ:[%s]===============================", pPutQueName);
        m_cMQAgent.Commit();
    }
    else
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "*****************************SEND MSG TO MB FALIED  MQ:[%s]*******************************",pPutQueName);
        return -1;
    }


	return 0;
}

//按照给定分割符分解字符串
void Rout::div_str(const char* s, int nDelim, list<string>& l)
{
	if(NULL == s){
		return;
	}

	char buffer[128] = {0};
    int nLen = strlen(s);

	bool bIn = false;
    int iOffset = 0;
    for(int i = 0; i < nLen; ++i){
        if(isspace(s[i])){
            if(i == nLen-1 && bIn){
                l.push_back(buffer);
                printf("buffer: %s\n", buffer);
                break;
            }
            else{
                continue;
			}
        }

        if(s[i] != nDelim){
            buffer[iOffset++] = s[i];
			bIn = true;
        }

        if(s[i] == nDelim || i == nLen-1){
			if(bIn){
				l.push_back(buffer);
				printf("buffer: %s\n", buffer);
				memset(buffer, 0x00, sizeof(buffer));
				iOffset = 0;
				bIn = false;
			}
        }
    }
}


//获取往报代号
int Rout::get_gen_no(const char* pszmsg)
{
	int iGenNo = -1;
	
	if(0 == strncmp(pszmsg, MSG_TAG_2ND, 3)){
		iGenNo = MSG_VER_2ND;
	}
	else if(0 == strncmp(pszmsg, MSG_TAG_1ST, 3)){
		iGenNo = MSG_VER_1ST;
	}
	
	Trace(L_INFO, __FILE__, __LINE__, NULL, "get_gen_no: %d", iGenNo);
	
	return iGenNo;
}

//获取清算行号
char* Rout::get_bank_no(const char* pszmsg, int iGenNo, char* buffer)
{
	int iOffset   = 0; //
	int iBKIDLen  = 0; //
	
	if(MSG_VER_2ND == iGenNo){
		iOffset  = 5;
		iBKIDLen = 14;
	}
	else{
		iOffset  = 18;
		iBKIDLen = 12;
	}
	
	memcpy(buffer, pszmsg + iOffset, iBKIDLen);
	Trim(buffer);
	
	Trace(L_INFO, __FILE__, __LINE__, NULL, "msg: %s get_bank_no: %s", pszmsg, buffer);
	
	return buffer;
}

//获取消息类型
char* Rout::get_msg_type(const char* pszmsg, int iGenNo, char* buffer)
{
	int iOffset = 0;
	int iMtLen  = 0;
	
	if(MSG_VER_2ND == iGenNo){
		iOffset = 58;
		iMtLen  = 20;
	}
	else{
		iOffset = 11;
		iMtLen  = 3;
	}
	
	memcpy(buffer, pszmsg + iOffset, iMtLen);
	Trim(buffer);

	Trace(L_INFO, __FILE__, __LINE__, NULL, "msgtype: %s ", buffer);
	
	return buffer;
}

//获取往报队列, if succeed to get the put queue name return the buffer, 
//or return NULL
char* Rout::get_putmqn(const char* pszmsg, char* buffer)
{
	//获取消息代号
	int iGenNo = get_gen_no(pszmsg);
	if(iGenNo > 0){
		//获取消息类型码
		char szmsgtp[24] = {0};
		
		get_msg_type(pszmsg, iGenNo, szmsgtp);
		Trim(szmsgtp);
		
		list<string>::iterator itrl = find(listBatMt.begin(),listBatMt.end(), szmsgtp);

        if(listBatMt.end() != itrl) 
        {
			strncpy(buffer, g_szBatPutMqN, 60);
        }				
		else
        {
			strncpy(buffer, g_szRtPutMqN, 60);
		}
    }
    else
    {
        Trace(L_INFO, __FILE__, __LINE__, NULL, "get iGenno failed");
    }
	
	return buffer;
}

