/******************************************************************** 
文件名： bepsckecklist.cpp
创建人： hq
日  期： 2011-06-08
修改人： 
日  期： 
描  述： 小额明细对账类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "bepschecklist.h"
#include "exception.h"
#include "logger.h"
#include "pubfunc.h"

using namespace ZFPT;

CBepsCheckList::CBepsCheckList()
{
    m_iTtlCnt        = 0;
    m_szChkDt        = "";
    m_szBkCode       = "";
    m_sCycleDigntr   = "";
    m_bBCoutSnd      = false;
    m_bBCoutRcv      = false;
    m_bCollTnchrgs   = false;
    m_bBdSnd         = false;
    m_bBdRcv         = false;
    m_bTransInfoQry  = false;
}

CBepsCheckList::~CBepsCheckList()
{
    
}

void CBepsCheckList::doCheckListWork(DBProc &dbProc,
                                 int iChkTp, 
                                 LPCSTR sChkDt, 
                                 LPCSTR sBankCode, 
                                 MQAgent &cMQAgent, 
                                 LPCSTR sSendQueue)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsCheckList::doCheckListWork()");

    // 说明；明细对账类型:0收723调用，1其他调用
    
    m_szChkDt     = sChkDt;
    m_szBkCode    = sBankCode;
    m_dbproc.pCtx = dbProc.pCtx;

    // 设置连接
    SetAllCtx();

    //统计报文类型
    if (1 == iChkTp)
    {
    	CountMsgTp();
	}
	
    // 更新小额明细核对表和业务表的状态
	UpdateState();

	// 判断对账是否相符
	IsSend724(cMQAgent, sSendQueue);
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsCheckList::doCheckListWork()");
}

void CBepsCheckList::CountMsgTp()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsCheckList::CountMsgTp()");

    int iRet = -1;
    
    iRet = m_checkaccount.findBpMsgTp(m_szChkDt.c_str(), m_szBkCode.c_str());
    if (SQL_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "查询BP_CHKLSTLIST表失败[%d][%s]",
            iRet, m_checkaccount.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "查BP_CHKLSTLIST表失败");
    }

    while(SQL_SUCCESS == iRet)
    {
    	iRet = m_checkaccount.fetchBpMsgTp();
      	if (SQLNOTFOUND == iRet) 
    	{
    	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "*****CountLocalInfo is over*****");
            break;
    	}
    	else if (SQL_SUCCESS != iRet) 
    	{
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "查询BP_CHKLSTLIST表失败[%d][%s]",
                iRet, m_checkaccount.GetSqlErr());

            m_checkaccount.closeBpCursor();
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "查BP_CHKLSTLIST表失败");
    	}

        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "msgtp[%s],SndRcvTp[%s]", 
            m_checkaccount.m_szMsgTp.c_str(), m_checkaccount.m_szSndRcvTp.c_str());

        if ( "beps.121.001.01" == m_checkaccount.m_szMsgTp 
          || "beps.122.001.01" == m_checkaccount.m_szMsgTp
          || "beps.124.001.01" == m_checkaccount.m_szMsgTp
          || "beps.125.001.01" == m_checkaccount.m_szMsgTp
          || "beps.128.001.01" == m_checkaccount.m_szMsgTp
          || "beps.130.001.01" == m_checkaccount.m_szMsgTp
          || "beps.132.001.01" == m_checkaccount.m_szMsgTp
          || "beps.134.001.01" == m_checkaccount.m_szMsgTp
          || "PKG001" == m_checkaccount.m_szMsgTp
          || "PKG005" == m_checkaccount.m_szMsgTp
          || "PKG007" == m_checkaccount.m_szMsgTp
          || "PKG008" == m_checkaccount.m_szMsgTp
          || "PKG009" == m_checkaccount.m_szMsgTp
          || "PKG010" == m_checkaccount.m_szMsgTp
          || "PKG011" == m_checkaccount.m_szMsgTp )
        {
            if ( "SR00" == m_checkaccount.m_szSndRcvTp )
            {
                m_bBCoutSnd = true;
            }
            else
            {
                m_bBCoutRcv = true;
            }
        }
        else if ( "beps.381.001.01" == m_checkaccount.m_szMsgTp 
               || "beps.383.001.01" == m_checkaccount.m_szMsgTp
               || "beps.385.001.01" == m_checkaccount.m_szMsgTp
               || "beps.387.001.01" == m_checkaccount.m_szMsgTp
               || "PKG012" == m_checkaccount.m_szMsgTp )
        {
            m_bCollTnchrgs = true;
        }
        else if ( "beps.127.001.01" == m_checkaccount.m_szMsgTp 
               || "beps.133.001.01" == m_checkaccount.m_szMsgTp
               || "PKG002" == m_checkaccount.m_szMsgTp
               || "PKG006" == m_checkaccount.m_szMsgTp
               || "PKG003" == m_checkaccount.m_szMsgTp
               || "PKG004" == m_checkaccount.m_szMsgTp )
        {
            if ( "SR00" == m_checkaccount.m_szSndRcvTp )
            {
                m_bBdSnd = true;
            }
            else
            {
                m_bBdRcv = true;
            } 
        }
        else if ( "ccms.314.001.01" == m_checkaccount.m_szMsgTp 
               || "ccms.315.001.01" == m_checkaccount.m_szMsgTp
               || "CMT301" == m_checkaccount.m_szMsgTp
               || "CMT302" == m_checkaccount.m_szMsgTp )
        {
            m_bTransInfoQry = true;
        }
        else
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文类型错误[%s]", 
                m_checkaccount.m_szMsgTp.c_str());
                
            m_checkaccount.closeBpCursor();
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "报文类型错误");
        }
    }
    
    m_checkaccount.closeBpCursor();

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsCheckList::CountMsgTp()");    
}

void CBepsCheckList::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsCheckList::UpdateState()"); 

    int iRet = -1;
    STRING strSQL = "";
    
    //**************************************************************//
    //说明: 因为状态不符不用下载明细，所以仅状态不符时，直接将"大额明
    //细核对表"的状态改为对账相符，然后更新业务表的状态。
    //**************************************************************//

    // 一、更新大额明细核对表HV_CHKLSTLIST
    
    //根据"小额往帐贷记汇总表"更新"小额明细核对表"
    if ( m_bBCoutSnd )
    {
        strSQL = "UPDATE BP_CHKLSTLIST t SET T.CHECKSTATE = ";
        strSQL += " (SELECT CASE WHEN t.PRCSTS = NVL(k.BUSISTATE,'0') AND t.CTRLSUM = k.CTRLSUM THEN '";
        strSQL += PR_CNCH_01;
        strSQL += "' WHEN t.PRCSTS !=  NVL(k.BUSISTATE,'0') AND t.CTRLSUM != k.CTRLSUM THEN '";
        strSQL += PR_CNCH_02;
        strSQL += "' WHEN t.PRCSTS !=  NVL(k.BUSISTATE,'0') THEN '";
        strSQL += PR_CNCH_01;
        strSQL += "' ELSE '";
        strSQL += PR_CNCH_02;
        strSQL += "' END FROM BP_BCOUTSNDCL k ";
        strSQL += " WHERE k.MSGID = t.ORGNLMSGID AND k.INSTGDRCTPTY = t.ORGNLINSTGDRPTY) ";
        strSQL += " WHERE t.ORGNLMSGID || t.ORGNLINSTGDRPTY IN (SELECT k.MSGID || k.INSTGDRCTPTY ";
        strSQL += " FROM BP_BCOUTSNDCL k WHERE k.MSGID = t.ORGNLMSGID AND k.INSTGDRCTPTY = t.ORGNLINSTGDRPTY) ";
        strSQL += " AND t.CHCKDT = '";
        strSQL += m_szChkDt;
        strSQL += "'";
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL[%s]", strSQL.c_str());
        
        iRet = m_bpchklstlist.execsql(strSQL);
        if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新BP_CHKLSTLIST表状态失败[%d][%s]",
                iRet, m_bpchklstlist.GetSqlErr());
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新BP_CHKLSTLIST表状态失败");
        }
    }

    //根据"小额来帐贷记汇总表"更新"小额明细核对表"
    if ( m_bBCoutRcv )
    {
        strSQL = "UPDATE BP_CHKLSTLIST t SET T.CHECKSTATE = ";
        strSQL += " (SELECT CASE WHEN t.PRCSTS = NVL(k.BUSISTATE,'0') AND t.CTRLSUM = k.CTRLSUM THEN '";
        strSQL += PR_CNCH_01;
        strSQL += "' WHEN t.PRCSTS !=  NVL(k.BUSISTATE,'0') AND t.CTRLSUM != k.CTRLSUM THEN '";
        strSQL += PR_CNCH_02;
        strSQL += "' WHEN t.PRCSTS !=  NVL(k.BUSISTATE,'0') THEN '";
        strSQL += PR_CNCH_01;
        strSQL += "' ELSE '";
        strSQL += PR_CNCH_02;
        strSQL += "' END FROM BP_BCOUTRCVCL k ";
        strSQL += " WHERE k.MSGID = t.ORGNLMSGID AND k.INSTGDRCTPTY = t.ORGNLINSTGDRPTY) ";
        strSQL += " WHERE t.ORGNLMSGID || t.ORGNLINSTGDRPTY IN (SELECT k.MSGID || k.INSTGDRCTPTY ";
        strSQL += " FROM BP_BCOUTRCVCL k WHERE k.MSGID = t.ORGNLMSGID AND k.INSTGDRCTPTY = t.ORGNLINSTGDRPTY) ";
        strSQL += " AND t.CHCKDT = '";
        strSQL += m_szChkDt;
        strSQL += "'";
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL[%s]", strSQL.c_str());
        
        iRet = m_bpchklstlist.execsql(strSQL);
        if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新BP_CHKLSTLIST表状态失败[%d][%s]",
                iRet, m_bpchklstlist.GetSqlErr());
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新BP_CHKLSTLIST表状态失败");
        }
    }

    //根据"小额往帐借记汇总表"更新"小额明细核对表"
    if ( m_bBCoutSnd )
    {
        strSQL = "UPDATE BP_CHKLSTLIST t SET T.CHECKSTATE = ";
        strSQL += " (SELECT CASE WHEN t.PRCSTS = NVL(k.BUSISTATE,'0') AND t.CTRLSUM = k.CTRLSUM THEN '";
        strSQL += PR_CNCH_01;
        strSQL += "' WHEN t.PRCSTS !=  NVL(k.BUSISTATE,'0') AND t.CTRLSUM != k.CTRLSUM THEN '";
        strSQL += PR_CNCH_02;
        strSQL += "' WHEN t.PRCSTS !=  NVL(k.BUSISTATE,'0') THEN '";
        strSQL += PR_CNCH_01;
        strSQL += "' ELSE '";
        strSQL += PR_CNCH_02;
        strSQL += "' END FROM BP_BDSNDCL k ";
        strSQL += " WHERE k.MSGID = t.ORGNLMSGID AND k.INSTGDRCTPTY = t.ORGNLINSTGDRPTY) ";
        strSQL += " WHERE t.ORGNLMSGID || t.ORGNLINSTGDRPTY IN (SELECT k.MSGID || k.INSTGDRCTPTY ";
        strSQL += " FROM BP_BDSNDCL k WHERE k.MSGID = t.ORGNLMSGID AND k.INSTGDRCTPTY = t.ORGNLINSTGDRPTY) ";
        strSQL += " AND t.CHCKDT = '";
        strSQL += m_szChkDt;
        strSQL += "'";
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL[%s]", strSQL.c_str());
        
        iRet = m_bpchklstlist.execsql(strSQL);
        if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新BP_CHKLSTLIST表状态失败[%d][%s]",
                iRet, m_bpchklstlist.GetSqlErr());
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新BP_CHKLSTLIST表状态失败");
        }
    }

    //根据"小额来帐借记汇总表"更新"小额明细核对表"
    if ( m_bBCoutRcv )
    {
        strSQL = "UPDATE BP_CHKLSTLIST t SET T.CHECKSTATE = ";
        strSQL += " (SELECT CASE WHEN t.PRCSTS = NVL(k.BUSISTATE,'0') AND t.CTRLSUM = k.CTRLSUM THEN '";
        strSQL += PR_CNCH_01;
        strSQL += "' WHEN t.PRCSTS !=  NVL(k.BUSISTATE,'0') AND t.CTRLSUM != k.CTRLSUM THEN '";
        strSQL += PR_CNCH_02;
        strSQL += "' WHEN t.PRCSTS !=  NVL(k.BUSISTATE,'0') THEN '";
        strSQL += PR_CNCH_01;
        strSQL += "' ELSE '";
        strSQL += PR_CNCH_02;
        strSQL += "' END FROM BP_BDRCVCL k ";
        strSQL += " WHERE k.MSGID = t.ORGNLMSGID AND k.INSTGDRCTPTY = t.ORGNLINSTGDRPTY) ";
        strSQL += " WHERE t.ORGNLMSGID || t.ORGNLINSTGDRPTY IN (SELECT k.MSGID || k.INSTGDRCTPTY ";
        strSQL += " FROM BP_BDRCVCL k WHERE k.MSGID = t.ORGNLMSGID AND k.INSTGDRCTPTY = t.ORGNLINSTGDRPTY) ";
        strSQL += " AND t.CHCKDT = '";
        strSQL += m_szChkDt;
        strSQL += "'";
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL[%s]", strSQL.c_str());
        
        iRet = m_bpchklstlist.execsql(strSQL);
        if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新BP_CHKLSTLIST表状态失败[%d][%s]",
                iRet, m_bpchklstlist.GetSqlErr());
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新BP_CHKLSTLIST表状态失败");
        }
    }
    
    //根据"代收付业务汇总表"更新"小额明细核对表"
    if ( m_bCollTnchrgs )
    {
        strSQL = "UPDATE BP_CHKLSTLIST t SET T.CHECKSTATE = ";
        strSQL += " (SELECT CASE WHEN t.PRCSTS = NVL(k.BUSISTATE,'0') AND t.CTRLSUM = k.TTLAMT THEN '";
        strSQL += PR_CNCH_01;
        strSQL += "' WHEN t.PRCSTS !=  NVL(k.BUSISTATE,'0') AND t.CTRLSUM != k.TTLAMT THEN '";
        strSQL += PR_CNCH_02;
        strSQL += "' WHEN t.PRCSTS !=  NVL(k.BUSISTATE,'0') THEN '";
        strSQL += PR_CNCH_01;
        strSQL += "' ELSE '";
        strSQL += PR_CNCH_02;
        strSQL += "' END FROM BP_COLLTNCHRGSCL k ";
        strSQL += " WHERE k.MSGID = t.ORGNLMSGID AND k.INSTGDRCTPTY = t.ORGNLINSTGDRPTY) ";
        strSQL += " WHERE t.ORGNLMSGID || t.ORGNLINSTGDRPTY IN (SELECT k.MSGID || k.INSTGDRCTPTY ";
        strSQL += " FROM BP_COLLTNCHRGSCL k WHERE k.MSGID = t.ORGNLMSGID AND k.INSTGDRCTPTY = t.ORGNLINSTGDRPTY) ";
        strSQL += " AND t.CHCKDT = '";
        strSQL += m_szChkDt;
        strSQL += "'";
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL[%s]", strSQL.c_str());
        
        iRet = m_bpchklstlist.execsql(strSQL);
        if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新BP_CHKLSTLIST表状态失败[%d][%s]",
                iRet, m_bpchklstlist.GetSqlErr());
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新BP_CHKLSTLIST表状态失败");
        }
    }

    //根据"业务查询信息表"更新"小额明细核对表"
    if ( m_bTransInfoQry)
    {
        strSQL = "UPDATE BP_CHKLSTLIST t SET T.CHECKSTATE = ";
        strSQL += " (SELECT CASE WHEN t.PRCSTS = NVL(k.BUSISTATE,'0') THEN '";
        strSQL += PR_CNCH_01;
        strSQL += "' ELSE '";
        strSQL += PR_CNCH_01;
        strSQL += "' END FROM CM_TRANSINFOQRY k ";
        strSQL += " WHERE k.MSGID = t.ORGNLMSGID AND k.INSTGDRCTPTY = t.ORGNLINSTGDRPTY) ";
        strSQL += " WHERE t.ORGNLMSGID || t.ORGNLINSTGDRPTY IN (SELECT k.MSGID || k.INSTGDRCTPTY ";
        strSQL += " FROM CM_TRANSINFOQRY k WHERE k.MSGID = t.ORGNLMSGID AND k.INSTGDRCTPTY = t.ORGNLINSTGDRPTY) ";
        strSQL += " AND t.CHCKDT = '";
        strSQL += m_szChkDt;
        strSQL += "'";
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL[%s]", strSQL.c_str());
        
        iRet = m_bpchklstlist.execsql(strSQL);
        if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新BP_CHKLSTLIST表状态失败[%d][%s]",
                iRet, m_bpchklstlist.GetSqlErr());
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新BP_CHKLSTLIST表状态失败");
        }
    }

    // 二、更新业务表
    
    //根据"小额明细核对表"更新":小额往帐贷记汇总表"
    if ( m_bBCoutSnd )
    {
        strSQL = "UPDATE BP_BCOUTSNDCL t SET (t.CHECKSTATE,t.BUSISTATE,t.NETGDT,t.NETGRND) =";
        strSQL += " ( SELECT k.CHECKSTATE,k.PRCSTS,k.TXNETGDT,k.TXNETGRND FROM BP_CHKLSTLIST k";
        strSQL += " WHERE k.ORGNLMSGID = t.MSGID AND k.ORGNLINSTGDRPTY = t.INSTGDRCTPTY AND k.CHCKDT = '";
        strSQL += m_szChkDt;
        strSQL += "')";
        strSQL += " WHERE t.MSGID || t.INSTGDRCTPTY IN (SELECT a.ORGNLMSGID || a.ORGNLINSTGDRPTY";
        strSQL += " FROM BP_CHKLSTLIST a WHERE a.ORGNLMSGID = t.MSGID AND a.ORGNLINSTGDRPTY = t.INSTGDRCTPTY AND a.CHCKDT = '";
        strSQL += m_szChkDt;
        strSQL += "')";
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL[%s]", strSQL.c_str());
        
        iRet = m_bpchklstlist.execsql(strSQL);
        if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新BP_BCOUTSNDCL表状态失败[%d][%s]",
                iRet, m_bpchklstlist.GetSqlErr());
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新BP_BCOUTSNDCL表状态失败");
        }
    }

    //根据"小额明细核对表"更新"小额来帐贷记汇总表"
    if ( m_bBCoutRcv )
    {
        strSQL = "UPDATE BP_BCOUTRCVCL t SET (t.CHECKSTATE,t.BUSISTATE,t.NETGDT,t.NETGRND) =";
        strSQL += " ( SELECT k.CHECKSTATE,k.PRCSTS,k.TXNETGDT,k.TXNETGRND FROM BP_CHKLSTLIST k";
        strSQL += " WHERE k.ORGNLMSGID = t.MSGID AND k.ORGNLINSTGDRPTY = t.INSTGDRCTPTY AND k.CHCKDT = '";
        strSQL += m_szChkDt;
        strSQL += "')";
        strSQL += " WHERE t.MSGID || t.INSTGDRCTPTY IN (SELECT a.ORGNLMSGID || a.ORGNLINSTGDRPTY";
        strSQL += " FROM BP_CHKLSTLIST a WHERE a.ORGNLMSGID = t.MSGID AND a.ORGNLINSTGDRPTY = t.INSTGDRCTPTY AND a.CHCKDT = '";
        strSQL += m_szChkDt;
        strSQL += "')";
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL[%s]", strSQL.c_str());
        
        iRet = m_bpchklstlist.execsql(strSQL);
        if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新BP_BCOUTRCVCL表状态失败[%d][%s]",
                iRet, m_bpchklstlist.GetSqlErr());
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新BP_BCOUTRCVCL表状态失败");
        }
    }

    //根据"小额明细核对表"更新":小额往帐借记汇总表"
    if ( m_bBdSnd )
    {
        strSQL = "UPDATE BP_BDSNDCL t SET (t.CHECKSTATE,t.BUSISTATE,t.NETGDT,t.NETGRND) =";
        strSQL += " ( SELECT k.CHECKSTATE,k.PRCSTS,k.TXNETGDT,k.TXNETGRND FROM BP_CHKLSTLIST k";
        strSQL += " WHERE k.ORGNLMSGID = t.MSGID AND k.ORGNLINSTGDRPTY = t.INSTGDRCTPTY AND k.CHCKDT = '";
        strSQL += m_szChkDt;
        strSQL += "')";
        strSQL += " WHERE t.MSGID || t.INSTGDRCTPTY IN (SELECT a.ORGNLMSGID || a.ORGNLINSTGDRPTY";
        strSQL += " FROM BP_CHKLSTLIST a WHERE a.ORGNLMSGID = t.MSGID AND a.ORGNLINSTGDRPTY = t.INSTGDRCTPTY AND a.CHCKDT = '";
        strSQL += m_szChkDt;
        strSQL += "')";
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL[%s]", strSQL.c_str());
        
        iRet = m_bpchklstlist.execsql(strSQL);
        if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新BP_BDSNDCL表状态失败[%d][%s]",
                iRet, m_bpchklstlist.GetSqlErr());
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新BP_BDSNDCL表状态失败");
        }
    }

    //根据"小额明细核对表"更新"小额来帐借记汇总表"
    if ( m_bBdRcv )
    {
        strSQL = "UPDATE BP_BDRCVCL t SET (t.CHECKSTATE,t.BUSISTATE,t.NETGDT,t.NETGRND) =";
        strSQL += " ( SELECT k.CHECKSTATE,k.PRCSTS,k.TXNETGDT,k.TXNETGRND FROM BP_CHKLSTLIST k";
        strSQL += " WHERE k.ORGNLMSGID = t.MSGID AND k.ORGNLINSTGDRPTY = t.INSTGDRCTPTY AND k.CHCKDT = '";
        strSQL += m_szChkDt;
        strSQL += "')";
        strSQL += " WHERE t.MSGID || t.INSTGDRCTPTY IN (SELECT a.ORGNLMSGID || a.ORGNLINSTGDRPTY";
        strSQL += " FROM BP_CHKLSTLIST a WHERE a.ORGNLMSGID = t.MSGID AND a.ORGNLINSTGDRPTY = t.INSTGDRCTPTY AND a.CHCKDT = '";
        strSQL += m_szChkDt;
        strSQL += "')";
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL[%s]", strSQL.c_str());
        
        iRet = m_bpchklstlist.execsql(strSQL);
        if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新BP_BDRCVCL表状态失败[%d][%s]",
                iRet, m_bpchklstlist.GetSqlErr());
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新BP_BDRCVCL表状态失败");
        }
    }
    
    //根据"小额明细核对表"更新"代收付业务汇总表"
    if ( m_bCollTnchrgs )
    {
        strSQL = "UPDATE BP_COLLTNCHRGSCL t SET (t.CHECKSTATE,t.BUSISTATE,t.NETGDT,t.NETGRND) =";
        strSQL += " ( SELECT k.CHECKSTATE,k.PRCSTS,k.TXNETGDT,k.TXNETGRND FROM BP_CHKLSTLIST k";
        strSQL += " WHERE k.ORGNLMSGID = t.MSGID AND k.ORGNLINSTGDRPTY = t.INSTGDRCTPTY AND k.CHCKDT = '";
        strSQL += m_szChkDt;
        strSQL += "')";
        strSQL += " WHERE t.MSGID || t.INSTGDRCTPTY IN (SELECT a.ORGNLMSGID || a.ORGNLINSTGDRPTY";
        strSQL += " FROM BP_CHKLSTLIST a WHERE a.ORGNLMSGID = t.MSGID AND a.ORGNLINSTGDRPTY = t.INSTGDRCTPTY AND a.CHCKDT = '";
        strSQL += m_szChkDt;
        strSQL += "')";
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL[%s]", strSQL.c_str());
        
        iRet = m_bpchklstlist.execsql(strSQL);
        if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新BP_COLLTNCHRGSCL表状态失败[%d][%s]",
                iRet, m_bpchklstlist.GetSqlErr());
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新BP_COLLTNCHRGSCL表状态失败");
        }
    }

    //根据"小额明细核对表"更新"业务查询信息表"
    if ( m_bTransInfoQry )
    {
        strSQL = "UPDATE CM_TRANSINFOQRY t SET (t.CHECKSTATE,t.BUSISTATE) =";
        strSQL += " ( SELECT k.CHECKSTATE,k.PRCSTS FROM BP_CHKLSTLIST k";
        strSQL += " WHERE k.ORGNLMSGID = t.MSGID AND k.ORGNLINSTGDRPTY = t.INSTGDRCTPTY AND k.CHCKDT = '";
        strSQL += m_szChkDt;
        strSQL += "')";
        strSQL += " WHERE t.MSGID || t.INSTGDRCTPTY IN (SELECT a.ORGNLMSGID || a.ORGNLINSTGDRPTY";
        strSQL += " FROM BP_CHKLSTLIST a WHERE a.ORGNLMSGID = t.MSGID AND a.ORGNLINSTGDRPTY = t.INSTGDRCTPTY AND a.CHCKDT = '";
        strSQL += m_szChkDt;
        strSQL += "')";
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL[%s]", strSQL.c_str());
        
        iRet = m_bpchklstlist.execsql(strSQL);
        if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新CM_TRANSINFOQRY表状态失败[%d][%s]",
                iRet, m_bpchklstlist.GetSqlErr());
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新CM_TRANSINFOQRY表状态失败");
        }
    }

    // 三、本地少和下载标志
    
    // 更新状态为初始的为本地少
    strSQL = "UPDATE BP_CHKLSTLIST SET CHECKSTATE = '";
    strSQL += PBC_LOCALLESS_04;
    strSQL += "' WHERE CHCKDT = '";
    strSQL += m_szChkDt;
    strSQL += "' AND INSTDDRCTPTY = '";
    strSQL += m_szBkCode;
    strSQL += "' AND CHECKSTATE = '";
    strSQL += PBC_INIT_00;
    strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL[%s]", strSQL.c_str());

    iRet = m_bpchklstlist.execsql(strSQL);
    if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新BP_CHKLSTLIST表状态失败[%d][%s]",
            iRet, m_bpchklstlist.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新BP_CHKLSTLIST表状态失败");
    }

    // 对账相符的，更新下载标志为已下载
    strSQL = "UPDATE BP_CHKLSTLIST SET ISDOWNLOAD = '1' WHERE CHCKDT = '";
    strSQL += m_szChkDt;
    strSQL += "' AND INSTDDRCTPTY = '";
    strSQL += m_szBkCode;
    strSQL += "' AND CHECKSTATE = '";
    strSQL += PR_CNCH_01;
    strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL[%s]", strSQL.c_str());

    iRet = m_bpchklstlist.execsql(strSQL);
    if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新BP_CHKLSTLIST表状态失败[%d][%s]",
            iRet, m_bpchklstlist.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新BP_CHKLSTLIST表状态失败");
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsCheckList::UpdateState()");
}

void CBepsCheckList::IsSend724(MQAgent &cMQAgent, LPCSTR sSendQueue)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsCheckList::IsSend724()"); 

    int iRet      = -1;
    int iCount724 = 0;
    int iCount    = 0;
    
    STRING szFindSql = "";

    // 查询条件:对账日期+行号+状态不为"对账相符"
    szFindSql = " CHCKDT = '";
    szFindSql += m_szChkDt;
    szFindSql += "' and INSTDDRCTPTY = '";
    szFindSql += m_szBkCode;
    szFindSql += "' and CHECKSTATE <> '";
    szFindSql += PR_CNCH_01;
    szFindSql += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "szFindSql=[%s]", szFindSql.c_str());

    iRet = m_bpchklstlist.find(szFindSql);
    if (SQL_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "查询BP_CHKLSTLIST表失败[%d][%s]", 
            iRet, m_bpchklstlist.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "查询BP_CHKLSTLIST表失败");
    }

    while(SQL_SUCCESS == iRet)
    {
    	iRet = m_bpchklstlist.fetch();
      	if (SQLNOTFOUND == iRet) 
    	{
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "*****Checklist account is over*****");
            break;
    	}
    	else if (SQL_SUCCESS != iRet) 
    	{
            Trace(L_ERROR, __FILE__, __LINE__, NULL, "查询BP_CHKLSTLIST表失败[%d][%s]", 
                iRet, m_bpchklstlist.GetSqlErr());

            m_bpchklstlist.closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "查询BP_CHKLSTLIST表失败");
    	}

        iCount++;
        
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "msgtp[%s],sndflag[%s],msgid[%s],bank[%s]", 
              m_bpchklstlist.m_orgnlmsgtp.c_str(),m_bpchklstlist.m_sndrcvtp.c_str(),
              m_bpchklstlist.m_orgnlmsgid.c_str(),m_bpchklstlist.m_orgnlinstgdrpty.c_str());

        //往账，本地少，不下载明细
        if ( "SR00" == m_bpchklstlist.m_sndrcvtp && PBC_LOCALLESS_04 == m_bpchklstlist.m_checkstate )
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "本地少往账，不下载明细");
        }
        else
        {
            iCount724++;
            m_iTtlCnt++;
        
    		//组724中的循环部分
            AddDetail724();

            //724报文中，最多包含1000笔明细,满1000笔，就发送
            if(0 == iCount724%1000)
            {   
            	CreateHvps724(cMQAgent, sSendQueue); //多次发送存在问题，未解决
            	m_iTtlCnt = 0;
            	m_beps724.m_pXMLProc.Reset();
            	m_sCycleDigntr = "";
            }
        }
    }
 
    m_bpchklstlist.closeCursor();

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "对账不符笔数[%d]下载明细笔数[%d]", iCount, iCount724); 
    
	// 如果不平，发送724报文下载明细
    if ( 0 < iCount724 )
    {
        // 更新与中心对账表中的状态为"14:发出明细下载申请"
		updateBkChkSt(PBC_CHKSNDLST_14);
		
        // 组大额业务下载申请报文,并发送
        if(0 != iCount724%1000)
        {
            CreateHvps724(cMQAgent, sSendQueue); //多次发送存在问题，未解决
        }
    }
    // 如果不平，且全部是少往账
    else if ( 0 < iCount)
    {
        // 更新与中心对账表中的状态为"13:对帐不平"
		updateBkChkSt(PBC_CHKNOCNFRM_13);
    }
    // 如果平，进行汇总核对
    else 
    {
        m_bpchecksum.doCheckSumWork(m_dbproc, 
	                            1, 
	                            m_szChkDt.c_str(),
	                            m_szBkCode.c_str(),
	                            cMQAgent,
	                            sSendQueue);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsCheckList::IsSend724()");
}

void CBepsCheckList::AddDetail724()
{
    m_beps724.AddNodeToSubcycle("SndRcvTp"      , m_bpchklstlist.m_sndrcvtp.c_str());
    m_beps724.AddNodeToSubcycle("OrgnlMsgId"    , m_bpchklstlist.m_orgnlmsgid.c_str());
    m_beps724.AddNodeToSubcycle("OrgnlInstgPty" , m_bpchklstlist.m_orgnlinstgdrpty.c_str());
    m_beps724.AddNodeToSubcycle("OrgnlMT"       , m_bpchklstlist.m_orgnlmsgtp.c_str());

    m_beps724.AddSubcycleToNode("DwnldReqTxsDtls");   

    m_sCycleDigntr += Trim(m_bpchklstlist.m_sndrcvtp) + "|";
    m_sCycleDigntr += Trim(m_bpchklstlist.m_orgnlmsgid) + "|";
    m_sCycleDigntr += Trim(m_bpchklstlist.m_orgnlinstgdrpty) + "|";
    m_sCycleDigntr += Trim(m_bpchklstlist.m_orgnlmsgtp) + "|";
}

void CBepsCheckList::updateBkChkSt(LPCSTR _sChkSt)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CBepsCheckList::updateBkChkSt()");

    int iRet = -1;
    
    iRet = m_checkaccount.upBpBChkState(m_szBkCode.c_str(), m_szChkDt.c_str(), _sChkSt);
    if ( iRet != SQL_SUCCESS )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "更新BP_BCHKSTATE表失败[%d][%s]", 
            iRet, m_checkaccount.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新BP_BCHKSTATE表失败");
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CBepsCheckList::updateBkChkSt()");
}

void CBepsCheckList::CreateHvps724(MQAgent &cMQAgent, LPCSTR sSendQueue)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBepsCheckList::CreateHvps724()");

    char sBankNo[14 + 1] = {0};
    char sMesgId[20 + 1] = {0};
    char sMsgId[35 + 1] = {0};
    char sISODateTime[19 + 1] = {0};
    char sTemp[128 + 1] = {0};
    int  iRet = -1;
    char sSignedStr[4096 + 1]    = {0};
    string szDgtSgntr = "";
	
    strncpy(sBankNo, m_szBkCode.c_str(), sizeof(sBankNo) - 1);
    
    // 报文头赋值
    if ( !GetMsgIdValue(m_dbproc, sMesgId, eRefId,  SYS_BEPS, sBankNo) )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "取报文参考号失败");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_SYS_PARA_FAIL, "取报文参考号失败");
    }
    
    m_beps724.CreateXMlHeader("BEPS",
                              m_szChkDt.c_str(),
                              m_szBkCode.c_str(),
                              "000000000000",
                              "beps.724.001.01",
                              sMesgId);
                              
    // 报文体赋值
    if ( !GetMsgIdValue(m_dbproc, sMsgId, eMsgId,  SYS_BEPS, sBankNo) )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "取报文标识号失败");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_SYS_PARA_FAIL, "取报文标识号失败");
    }
    GetIsoDateTime(m_dbproc, SYS_BEPS, sISODateTime);
    
    m_beps724.MsgId           = sMsgId;         //报文标识号
    m_beps724.CreDtTm         = sISODateTime;   //报文发送时间
    m_beps724.InstgDrctPty    = m_szBkCode;     //发起直接参与机构
    m_beps724.GrpHdrInstgPty  = m_szBkCode;     //发起参与机构
    m_beps724.InstdDrctPty    = "000000000000"; //接收直接参与机构
    m_beps724.GrpHdrInstdPty  = "000000000000"; //接收参与机构
    m_beps724.SysCd           = "BEPS";         //系统编号

    sprintf(sTemp, "%d", m_iTtlCnt);
    m_beps724.NbOfTxs         = sTemp;          //明细数目

    // 加签
    szDgtSgntr = Trim(m_beps724.NbOfTxs) + "|" + Trim(m_sCycleDigntr);

    char *sOrigenStr = new char[szDgtSgntr.length() + 1];
    strcpy(sOrigenStr, szDgtSgntr.c_str());
	
	signTrim(sOrigenStr);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sOrigenStr=[%s]", sOrigenStr);
	
    iRet = digitSign(m_dbproc, sOrigenStr, sSignedStr, SYS_BEPS, RAWSIGN);
	if ( RTN_SUCCESS != iRet)
	{ 
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "724加签失败[%d]", iRet);
        //测试时，暂时不抛异常
		//PMTS_ThrowException(__FILE__, __LINE__, OPT_DIGITSIGN_FAIL, "724加签失败");
	}
    m_beps724.m_szDigitSign = sSignedStr;
    
    // 组报文
    iRet = m_beps724.CreateXml();
    if (0 != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "组724报文失败[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, "组724报文失败");    
    }

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sXMLBuff[%s]", m_beps724.m_sXMLBuff.c_str());
    
    // 发送报文
	iRet = cMQAgent.PutMsg(sSendQueue, m_beps724.m_sXMLBuff.c_str(), (int)m_beps724.m_sXMLBuff.length());
	if (0 != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "将724报文PUTMQ失败[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_MQ_ADD_FAIL, "将724报文PUTMQ失败");    
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBepsCheckList::CreateHvps724()");
}

void CBepsCheckList::SetAllCtx()
{
    int iRet = -1;

    iRet = m_bpchklstlist.setctx(m_dbproc);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }
    
    iRet = m_checkaccount.setctx(m_dbproc);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }
}

