/******************************************************************** 
�ļ����� recvcmt320.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-04-28
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvcmt320.h"

using namespace ZFPT;

CRecvCmt320::CRecvCmt320()
{
    m_strMsgTp	  = "CMT320";
    memset(m_sOldMsgId, 0x00, sizeof(m_sOldMsgId));
}


CRecvCmt320::~CRecvCmt320()
{
	
}

void CRecvCmt320::GetOrgBuss()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt320::GetOrgBuss()");	

    SETCTX(m_Orgncmpmtrtrcl);
    
    string strSQL = "";
    strSQL += "MSGID = '";
    strSQL += m_sOldMsgId;
    strSQL += "' and INSTGDRCTPTY = '";
    strSQL += m_cmt320.sOldsendsapbk;
    strSQL += "' and RSFLAG = '1";
    strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());	
    
    int iRet = m_Orgncmpmtrtrcl.find(strSQL.c_str());
    if(SQL_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���α�ʧ��[%d]",iRet);	
        PMTS_ThrowException( DB_OPT_FAIL);    
    }

    iRet = m_Orgncmpmtrtrcl.fetch();
    if (SQL_SUCCESS != iRet )
    {
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Fetch��ϸ�����ݷ�������[%d][%s]",iRet, m_Orgncmpmtrtrcl.GetSqlErr());
        //m_Orgncmpmtrtrcl.closeCursor();
		//PMTS_ThrowException(DB_NOT_FOUND);               
    }    
    m_Orgncmpmtrtrcl.closeCursor();

    
	if(0 == strcmp("0", m_cmt320.sRebacktype))
	{
        SETCTX(m_OrgnCmpmtrtrlist);

        strSQL = "";
        strSQL += "MSGID = '";
        strSQL += m_sOldMsgId;
        strSQL += "' and INSTGDRCTPTY = '";
        strSQL += m_cmt320.sOldsendsapbk;
        strSQL += "'";
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());	
        
        int iRet = m_OrgnCmpmtrtrlist.find(strSQL.c_str());
        if(SQL_SUCCESS != iRet)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���α�ʧ��[%d]",iRet);	
            PMTS_ThrowException( DB_OPT_FAIL);    
        }

        iRet = m_OrgnCmpmtrtrlist.fetch();
        if (SQL_SUCCESS != iRet )
        {
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Fetch��ϸ�����ݷ�������[%d][%s]",iRet, m_OrgnCmpmtrtrlist.GetSqlErr());
            //m_OrgnCmpmtrtrlist.closeCursor();
    		//PMTS_ThrowException(DB_NOT_FOUND);               
        }    
        m_OrgnCmpmtrtrlist.closeCursor();

    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt320::GetOrgBuss()");	
}

INT32 CRecvCmt320::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt320::Work()");	

	// ��������
	unPack(sMsg);

    GetOrgBuss();
    
	// ����ҵ������Ϣ��CM_TRANSREPEAL
	InsertDb(sMsg);

	// �޸�ԭ��������ҵ��״̬
	UpdateDb();

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt320::work()");

	return RTN_SUCCESS;
}

INT32 CRecvCmt320::unPack(LPCSTR sMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt320::unPack");	

    int iRet = RTN_FAIL;
    char sMsgId[35 + 1] = { 0 };

    // �����Ƿ�Ϊ��
    if (NULL == sMsg || '\0' == sMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }

    // ��������
    iRet = m_cmt320.ParseCmt(sMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������,iRet[%d]", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
    }

    sprintf(m_sOldMsgId, "%8s%08s", m_cmt320.sOldrebackdate, m_cmt320.sOldmssno);

    // ���ı�ʶ�š�ϵͳ���
    sprintf(sMsgId, "%8s%08s", m_cmt320.sConsigndate, m_cmt320.sReplyno);
    m_strMsgID	  = sMsgId;

    ZFPTLOG.SetLogInfo("1320", sMsgId);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt320::unPack");	

    return RTN_SUCCESS;
}

INT32 CRecvCmt320::InsertDb(LPCSTR pchMsg)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt320::InsertDb");	

    char sMesgID[20+1] = {0};
    bool bRet = GetMsgIdValue(m_dbproc, sMesgID, eRefId, SYS_HVPS);
    if(false == bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡsMesgIDʧ��");
        PMTS_ThrowException(PRM_FAIL);         
    }
    
    m_cmpmtrtrcl.m_wrkdate = m_cmt320.sConsigndate ; 
    m_cmpmtrtrcl.m_consigndate = m_cmt320.sConsigndate ; 
    m_cmpmtrtrcl.m_sysid = "BEPS" ; 
    m_cmpmtrtrcl.m_msgtp = "CMT320" ; 
    m_cmpmtrtrcl.m_msgid = m_strMsgID ; 
    m_cmpmtrtrcl.m_instgdrctpty =  m_cmt320.sOldrecvbk; 
    m_cmpmtrtrcl.m_instgindrctpty = m_cmt320.sOldrecvsapbk  ; 
    m_cmpmtrtrcl.m_instddrctpty = m_cmt320.sOldsendbk; 
    m_cmpmtrtrcl.m_instdindrctpty =  m_cmt320.sOldsendsapbk; 
    m_cmpmtrtrcl.m_rsflag = "2" ; 
    m_cmpmtrtrcl.m_rspflag = "1" ; 
    //m_cmpmtrtrcl.m_mbmsg = m_cmt320. ; 
    //m_cmpmtrtrcl.m_npcmsg = m_cmt320. ; 
    m_cmpmtrtrcl.m_mesgid = m_cmt320.GetHeadMesgID() ; 
    m_cmpmtrtrcl.m_mesgrefid = m_cmt320.GetHeadMesgReqNo() ; 
    m_cmpmtrtrcl.m_procstate = PR_HVBP_33; 
    //m_cmpmtrtrcl.m_statetime = m_cmt320. ; 

	
    //0 �����˻� 1 �����˻�
    if(1 == atoi(m_cmt320.sRebacktype))
    {
		m_cmpmtrtrcl.m_busistate = PROCESS_PR23; 
	}
    else
    {
		m_cmpmtrtrcl.m_busistate = PROCESS_PR25; 
	}	

	if(m_cmt320.sReplyflag == "2")
	{
		m_cmpmtrtrcl.m_busistate = PROCESS_PR09; 
	}
	
    //m_cmpmtrtrcl.m_processcode = m_cmt320. ; 
    //m_cmpmtrtrcl.m_rjctinf = m_cmt320. ; 
    m_cmpmtrtrcl.m_orgninstgdrctpty = m_cmt320.sOldsendbk ; 
    m_cmpmtrtrcl.m_orgnlmsgid = m_sOldMsgId; 
    m_cmpmtrtrcl.m_orgnlmsgnmid = m_Orgncmpmtrtrcl.m_orgnlmsgnmid; 
    m_cmpmtrtrcl.m_returntype = m_cmt320.sRebacktype; 
    m_cmpmtrtrcl.m_printno = 0 ; 
    m_cmpmtrtrcl.m_retunstat = m_cmt320.sReplyflag ; 
    //m_cmpmtrtrcl.m_rtinfo = m_cmt320.sRemark ; 
	SetGbkToUtf8(m_cmt320.sRemark,m_cmpmtrtrcl.m_rtinfo);

    SETCTX(m_cmpmtrtrcl);
    int iRet = m_cmpmtrtrcl.insert();
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Save CMT302[%s]", m_strMsgID.c_str());	

    if(SQL_SUCCESS != iRet)
    {
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "������ʧ��[%d][%s]",
		    iRet, m_cmpmtrtrcl.GetSqlErr());
		//PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "������ʧ��");    
    }
    m_cmpmtrtrcl.commit();

    
	if(0 == strcmp("0", m_cmt320.sRebacktype))
	{
        m_cmpmtrtrlist.m_orgnltxid = m_OrgnCmpmtrtrlist.m_orgnltxid; 
        m_cmpmtrtrlist.m_orgninstgdrctpty = m_OrgnCmpmtrtrlist.m_orgninstgdrctpty ; 
        m_cmpmtrtrlist.m_orgninstgindrctpty = m_OrgnCmpmtrtrlist.m_orgninstgindrctpty ; 
        m_cmpmtrtrlist.m_orgninstddrctpty = m_OrgnCmpmtrtrlist.m_orgninstddrctpty ; 
        m_cmpmtrtrlist.m_orgninstdindrctpty = m_OrgnCmpmtrtrlist.m_orgninstdindrctpty ; 
        m_cmpmtrtrlist.m_ctgypurp = m_OrgnCmpmtrtrlist.m_ctgypurp ; 
        m_cmpmtrtrlist.m_busistate = m_cmpmtrtrcl.m_busistate;
        //m_cmpmtrtrlist.m_processcode = m_cmt320. ; 
        //m_cmpmtrtrlist.m_mbmsgid = m_cmt320. ; 
        m_cmpmtrtrlist.m_msgid = m_strMsgID ; 
        m_cmpmtrtrlist.m_instgdrctpty = m_cmt320.sOldsendsapbk ; 
        m_cmpmtrtrlist.m_orgnlmsgid = m_sOldMsgId; 	
        m_cmpmtrtrlist.m_rsflag = "2";
        
        SETCTX(m_cmpmtrtrlist);
        int iRet = m_cmpmtrtrlist.insert();
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Save CMT302 list[%s]", m_strMsgID.c_str());	
        
        if(SQL_SUCCESS != iRet)
        {
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "������ʧ��[%d][%s]",
    		    iRet, m_cmpmtrtrlist.GetSqlErr());
    		//PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "������ʧ��");    
        }
	}
    
    m_cmpmtrtrcl.commit();

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt320::InsertDb");	

    return RTN_SUCCESS;
}


INT32 CRecvCmt320::UpdateDb(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt320::UpdateDb");

	string strSQL;
	int iRet = -1;

	if(m_cmt320.sReplyflag == "1")
	{
		strSQL	= "UPDATE CM_PMTRTRCL t SET t.busistate = '";
		strSQL += m_cmpmtrtrcl.m_busistate;
		strSQL += "',t.PROCSTATE = '33',t.RSPFLAG='1', t.RETUNSTAT = '";
		strSQL += m_cmt320.sReplyflag;
		strSQL += "' WHERE t.msgid = '";
		strSQL += m_sOldMsgId;
		strSQL += "' AND t.INSTGDRCTPTY = '";
		strSQL += m_cmt320.sOldsendsapbk; 
		strSQL += "' and RSFLAG <> '2'";
		Trace(L_DEBUG,	__FILE__,  __LINE__, NULL, strSQL.c_str());

	}
	else
	{
		strSQL	= "UPDATE CM_PMTRTRCL t SET t.busistate = '";
		strSQL += m_cmpmtrtrcl.m_busistate;
		strSQL += "',t.PROCSTATE = '23',t.RSPFLAG='1', t.RETUNSTAT = '";
		strSQL += m_cmt320.sReplyflag;
		strSQL += "' WHERE t.msgid = '";
		strSQL += m_sOldMsgId;
		strSQL += "' AND t.INSTGDRCTPTY = '";
		strSQL += m_cmt320.sOldsendsapbk; 
		strSQL += "' and RSFLAG <> '2'";
		Trace(L_DEBUG,	__FILE__,  __LINE__, NULL, strSQL.c_str());


	}

	
    SETCTX(m_cmpmtrtrcl);
	iRet = m_cmpmtrtrcl.execsql(strSQL.c_str());
    if (iRet != SQL_SUCCESS)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]",iRet, m_cmpmtrtrcl.GetSqlErr());
		//PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
	}

    return RTN_SUCCESS;


    //����ԭҵ��
    if (m_cmpmtrtrcl.m_retunstat=="2")
    {
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "��ͬ���˻�.");
        return -1;
    }
    
	strSQL  = "UPDATE BP_BCOUTSNDCL t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_33;
    strSQL += "', t.STATETIME = sysdate";
	strSQL += " WHERE t.msgid = '";
	strSQL += m_Orgncmpmtrtrcl.m_orgnlmsgid;
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_Orgncmpmtrtrcl.m_orgninstgdrctpty; 
	strSQL += "' ";
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, strSQL.c_str());
	
	iRet = m_cmpmtrtrcl.execsql(strSQL.c_str());
    if (iRet != SQL_SUCCESS)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]",iRet, m_cmpmtrtrcl.GetSqlErr());
		//PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
	}

	if(0 == strcmp("0", m_cmt320.sRebacktype))//����ֻ������ϸ���е�һ��
	{
        strSQL = "";
    	strSQL += "UPDATE BP_BCOUTSENDLIST t SET t.PROCSTATE = '";
        strSQL += PR_HVBP_33;
        strSQL += "', t.STATETIME = sysdate ";
    	strSQL += " WHERE t.txid = '";
    	strSQL += m_OrgnCmpmtrtrlist.m_orgnltxid;
    	strSQL += "' AND t.INSTGDRCTPTY = '";
    	strSQL += m_OrgnCmpmtrtrlist.m_orgninstgdrctpty; 
    	strSQL += "' ";
    	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, strSQL.c_str());
    	
    	iRet = m_cmpmtrtrcl.execsql(strSQL.c_str());
        if (iRet != SQL_SUCCESS)
    	{
    		Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]",iRet, m_cmpmtrtrcl.GetSqlErr());
    		//PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
    	}
	}
    else//���������ı�ʶ��������
    {
        strSQL = "";
        strSQL = "UPDATE BP_BCOUTSENDLIST t SET t.PROCSTATE = '";
        strSQL += PR_HVBP_33;
        strSQL += "', t.STATETIME = sysdate ";
        strSQL += " WHERE t.MSGID = '";
        strSQL += m_Orgncmpmtrtrcl.m_orgnlmsgid;
        strSQL += "' AND t.INSTGDRCTPTY = '";
        strSQL += m_Orgncmpmtrtrcl.m_orgninstgdrctpty; 
        strSQL += "' ";
        
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, strSQL.c_str());

        iRet = m_cmpmtrtrcl.execsql(strSQL.c_str());
        if (iRet != SQL_SUCCESS)
        {
            Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]",iRet, m_cmpmtrtrcl.GetSqlErr());
            //PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
        }
    }
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt320::UpdateDb");

	return RTN_SUCCESS;
}


