/******************************************************************** 
�ļ����� recvccms992.cpp
�����ˣ� lj
��  �ڣ� 2011-03-29
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvccms992.h"
#include "syssequence_generation.h"

using namespace ZFPT;

CRecvCcms992::CRecvCcms992()
{
    m_strMsgTp	  = "ccms.992.001.01";
}


CRecvCcms992::~CRecvCcms992()
{
	
}

INT32 CRecvCcms992::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms992::Work()");	
	
	return 0;
	// ��������
	//unPack(sMsg);
	
	//SetData();

	//InsertDb();
	
	// ���·���״̬
	//UpdateOrgState();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms992::work()");
	
	return RTN_SUCCESS;
}

INT32 CRecvCcms992::unPack(LPCSTR sMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms992::unPack");	

    int iRet = RTN_FAIL;

    // �����Ƿ�Ϊ��
    if (NULL == sMsg || '\0' == sMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }

    // ��������
    iRet = m_ccms992.ParseXml(sMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������,iRet[%d]", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
    }

    ZFPTLOG.SetLogInfo("992",m_ccms992.OrigSndDt.c_str());
    

    // ��ȡ��������

	iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;      

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms992::unPack");	

    return RTN_SUCCESS;
}

INT32 CRecvCcms992::SetData()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms992::SetData");	

	m_Cmchckreqrspn.m_row_id                            =   GetSeqNo();
	m_Cmchckreqrspn.m_workdate                          =   m_strWorkDate;
	m_Cmchckreqrspn.m_instgindrctpty                    =   "PMTS";
	m_Cmchckreqrspn.m_instdindrctpty                    = 	m_ccms992.OrigSndNd;
	m_Cmchckreqrspn.m_origsndnd                         =   m_ccms992.OrigSndNd;//ԭ���ķ���ڵ�
	m_Cmchckreqrspn.m_origsndsvsrnm                     =   m_ccms992.OrigSndSvsrNm;//ԭ���ͷ�������
	m_Cmchckreqrspn.m_origsndlinemgrnm                  =   m_ccms992.OrigSndLineMgrNm;//ԭ������й�������
	m_Cmchckreqrspn.m_rcvroadnm                         =   m_ccms992.RcvRoadNm;// ����ͨ������ԭ����ͨ������
	m_Cmchckreqrspn.m_origsnddt                         =   m_ccms992.OrigSndDt;// ԭ�����ķ���ʱ��
	m_Cmchckreqrspn.m_rspnnd                            =   m_ccms992.RspnNd;// Ӧ��ڵ�
	m_Cmchckreqrspn.m_rspnsvcrnm                        =   m_ccms992.RspnSvcrNm;// Ӧ���������
	m_Cmchckreqrspn.m_rspnlinemgr                       =   m_ccms992.RspnLineMgr;//Ӧ����й�����
	m_Cmchckreqrspn.m_rcvlinenm                         =   m_ccms992.RcvLineNm;// ���ն�Զ�̶�����
	m_Cmchckreqrspn.m_msgtp                             =   "ccms.992.001.01";
	m_Cmchckreqrspn.m_rspflag                           =   "1";
	m_Cmchckreqrspn.m_mesgid                            =   m_ccms992.m_PMTSHeader.getMesgID();
	m_Cmchckreqrspn.m_mesgrefid                         =   m_ccms992.m_PMTSHeader.getMesgRefID();
	m_Cmchckreqrspn.m_procstate                         =   "01";//������
  
	int iCycle = 0;
	
	char *pCycleNode = "LdFctrInf";
	
	iCycle = m_ccms992.GetNodeCountByName("LdFctrInf");
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, " iCycle = %d",iCycle);

	for(int i = 0;i < iCycle;i++)
	{
			m_ccms992.RspnLclLineNm = m_ccms992.GetValueFromCycle(pCycleNode,"RspnLclLineNm",i);//  Ӧ�𷽱��ض�����
			m_ccms992.LdFctr = m_ccms992.GetValueFromCycle(pCycleNode,"LdFctr",i);// ����ϵ��
			
			m_Cmchckreqrspn.m_ldfctrinf  = "/RspnLclLineNm/"+m_ccms992.RspnLclLineNm+":";
			m_Cmchckreqrspn.m_ldfctrinf += "/LdFctr/"+m_ccms992.LdFctr;
			
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, " m_ccms992.RspnLclLineNm = %s",m_ccms992.RspnLclLineNm.c_str());	
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, " m_ccms992.LdFctr = %s",m_ccms992.LdFctr.c_str());
	}
  
  Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms992::SetData");	
  return RTN_SUCCESS;
}


INT32 CRecvCcms992::InsertDb()
{    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms992::InsertDb");	

	// ��������
	SETCTX(m_Cmchckreqrspn);

	// �������ݿ�
	int iRet = m_Cmchckreqrspn.insert();
	if (0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Cmchckreqrspn��ʧ��[%d][%s]",
		    iRet, m_Cmchckreqrspn.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "����Cmchckreqrspn��ʧ��");
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms992::InsertDb");	

    return RTN_SUCCESS;
}

INT32 CRecvCcms992::UpdateOrgState()
{
  Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvCcms992::UpdateOrgState...");
  
     string strSQL;
  
     strSQL += "UPDATE CM_CHCKREQRSPN t SET t.RSPFLAG = '1' ";
     strSQL += " WHERE t.SNDND = '";
     strSQL += m_ccms992.OrigSndNd;
     strSQL += "' AND t.SNDSVCRNM = '";
     strSQL += m_ccms992.OrigSndSvsrNm;
     strSQL += "' AND t.SNDLINEMGRNM = '";
     strSQL += m_ccms992.OrigSndLineMgrNm;//ԭ������й�������                  
     strSQL += "' AND T.MESGREFID='";
     strSQL += m_Cmchckreqrspn.m_mesgrefid;
     strSQL += "' ";
     Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
  
     int iRet = m_Cmchckreqrspn.execsql(strSQL.c_str());
     if(RTN_SUCCESS != iRet)
     {
         Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "UpdateState error:[%d]", iRet);
         PMTS_ThrowException(DB_UPDATE_FAIL);
     }
  
     Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvCcms992::UpdateOrgState...");
    return RTN_SUCCESS;
}

int CRecvCcms992::GetSeqNo(void)
{

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvCcms992::GetSeqNo");

	int nSeq = 0;

	CSyssequence_generation _seqgen;

	SETCTX(_seqgen);

	_seqgen.m_tablename = "cm_chckreqrspn";

	Trace(L_DEBUG, __FILE__, __LINE__, NULL,
			"_seqgen.m_tablename=[%s]", _seqgen.m_tablename.c_str());

	int iRet = _seqgen.findByPK();

	if (iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[sys_sequence_generation] find error[%s]", _seqgen.GetSqlErr());
		PMTS_ThrowException(DB_FIND_FAIL);
	}

	if (_seqgen.m_snvalue >= _seqgen.m_maxvalue
			|| _seqgen.m_snvalue < _seqgen.m_minvalue){
		nSeq = _seqgen.m_minvalue;
	}
	else{
		nSeq = _seqgen.m_snvalue + 1;
	}

	Trace(L_INFO, __FILE__, __LINE__, NULL, "nSeq=[%d]", nSeq);
	_seqgen.m_snvalue = nSeq;
	iRet = _seqgen.updatestate();
	if (iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[sys_sequence_generation] update error[%s]", _seqgen.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvCcms992::GetSeqNo");

	return nSeq;
}

