/******************************************************************** 
文件名： recvccms801.cpp
创建人： hq
日  期： 2011-03-19
修改人： hdf
日  期：
描  述： 系统状态变更通知报文<ccms.801.001.02>
版  本：
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "hvpschangeday.h"
#include "recvccms801.h"
#include "mqagent.h"
#include "sysmbchkst.h"

using namespace ZFPT;

CRecvCcms801::CRecvCcms801()
{
	m_strMsgTp	=	"ccms.801.001.02";
	memset(m_sOrgnlSysDt, 0x00, sizeof(m_sOrgnlSysDt));
	memset(m_sCurSysDt, 0x00, sizeof(m_sCurSysDt));
	memset(m_sNxtSysDt, 0x00, sizeof(m_sNxtSysDt));
	memset(m_sfeastflg, 0x00, sizeof(m_sfeastflg));
    memset(m_szHeadInstdDrctPty, 0x00, sizeof(m_szHeadInstdDrctPty));
	m_iSysCd = 0;
	m_bFlag = false;
}


CRecvCcms801::~CRecvCcms801()
{

}

INT32 CRecvCcms801::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms801::Work()");

	//1、解析报文
	unPack(sMsg);

	//2、修改清算行信息表
	if( UpdateDB(sMsg) == 1 )
	{
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "处理完毕");
	    return RTN_SUCCESS;
	}
	
    if(true == m_bFlag)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "处理完毕");
        return RTN_SUCCESS;
    }
    	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms801::work()");

	return RTN_SUCCESS;
}


INT32 CRecvCcms801::unPack(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms801::unPack");	

	int iRet = RTN_FAIL;

	// 报文是否为空
	if (NULL == sMsg || '\0' == sMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文为空");
	}

	// 解析报文
	iRet = m_ccms801.ParseXml(sMsg);
	if (RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错,iRet[%d]", iRet);
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文解析出错");
	}

    ZFPTLOG.SetLogInfo("801", m_ccms801.MsgId.c_str());
    
	// 报文标识号/日期/系统编号
	m_strMsgID	=	m_ccms801.MsgId;
	chgToDate(m_ccms801.OrgnlSysDt.c_str()  , m_sOrgnlSysDt);
	chgToDate(m_ccms801.CurSysDt.c_str()    , m_sCurSysDt);
	chgToDate(m_ccms801.NxtSysDt.c_str()    , m_sNxtSysDt);
	chgSysCd(m_ccms801.SysCd.c_str()        , m_iSysCd);
    strncpy(m_szHeadInstdDrctPty            , m_ccms801.m_PMTSHeader.getOrigReceiver(),sizeof(m_szHeadInstdDrctPty)-1);    
    trim(m_szHeadInstdDrctPty);
       
	// 节假日标志HF00：节假日HF01：非节假日
	if (m_ccms801.HldayFlg == "HF01")
	{
		strcpy(m_sfeastflg, "0");
	}
	else
	{
		strcpy(m_sfeastflg, "1");
	}
		
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms801::unPack");	

	return RTN_SUCCESS;
}

void CRecvCcms801::InsertHvbkchkst()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms801::InsertHvbkchkst");
    
    SETCTX(m_Hvbkchkst);
    m_Hvbkchkst.m_checkdate     = m_ccms801.CurSysDt;
    m_Hvbkchkst.m_sapbank       = m_szHeadInstdDrctPty; 
    m_Hvbkchkst.m_checkstate    = "00"; 

    int iRet = m_Hvbkchkst.insert();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "添加Hv_bkchkst记录失败iRet=%d, %s", iRet, m_Hvbkchkst.GetSqlErr());
        PMTS_ThrowException(DB_INSERT_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms801::InsertHvbkchkst");
}

void CRecvCcms801::GetHvbkchkst()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms801::GetHvbkchkst");

    SETCTX(m_Hvbkchkst);
    
    m_Hvbkchkst.m_checkdate = m_ccms801.OrgnlSysDt;
    m_Hvbkchkst.m_sapbank   = m_szHeadInstdDrctPty; 

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_checkdate = [%s], m_sapbank = [%s]", 
        m_Hvbkchkst.m_checkdate.c_str(), m_Hvbkchkst.m_sapbank.c_str());
    
    int iRet = m_Hvbkchkst.findByPK();
    if(SQL_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "获取Hv_bkchkst记录失败, [%d][%s]",
                iRet, m_Hvbkchkst.GetSqlErr());
        
        PMTS_ThrowException(DB_GET_DATA_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms801::GetHvbkchkst");
}

void CRecvCcms801::InsertHvsapwtchgedt()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms801::InsertHvbkchkst");
    
    SETCTX(m_Hvsapwtchgedt);
    
    m_Hvsapwtchgedt.m_sapbank       = m_szHeadInstdDrctPty; 
    m_Hvsapwtchgedt.m_predate       = m_sOrgnlSysDt; 
    m_Hvsapwtchgedt.m_workdate      = m_sCurSysDt; 
    m_Hvsapwtchgedt.m_sysstate      = m_ccms801.CurSysSts; 
    m_Hvsapwtchgedt.m_changetype    = "0" ; 
    m_Hvsapwtchgedt.m_nextdate      = m_sNxtSysDt; 
    m_Hvsapwtchgedt.m_postscript    = m_ccms801.Rmk; 
    //m_Hvsapwtchgedt.m_updatetime ; 
    m_Hvsapwtchgedt.m_changestate   = "0"; 
    m_Hvsapwtchgedt.m_feastflg      = m_sfeastflg;

    Trace(L_DEBUG, __FILE__,  __LINE__, NULL, "m_ccms801.m_predate  =[%s]", m_ccms801.OrgnlSysDt.c_str());
    Trace(L_DEBUG, __FILE__,  __LINE__, NULL, "m_ccms801.m_workdate =[%s]", m_ccms801.CurSysDt.c_str());
    Trace(L_DEBUG, __FILE__,  __LINE__, NULL, "m_ccms801.m_nextdate =[%s]", m_ccms801.NxtSysDt.c_str());
    
    int iRet = m_Hvsapwtchgedt.insert();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "添加Hv_sapwtchgedt记录失败iRet=%d, %s", iRet, m_Hvsapwtchgedt.GetSqlErr());
        PMTS_ThrowException(DB_INSERT_FAIL);
    }
            
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms801::InsertHvbkchkst");
}

INT32 CRecvCcms801::UpdateDB(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms801::UpdateDB");
    	
	if ( "HVPS" == m_ccms801.SysCd )
	{
		return ChangeHVPSDay();
	}
	else if ( "BEPS" == m_ccms801.SysCd )
	{
		return ChangeBEPSDay();
	}
	else if ( "IBPS" == m_ccms801.SysCd )
	{
	    Trace(L_ERROR, __FILE__, __LINE__, NULL, "系统编号[%s]", m_ccms801.SysCd.c_str());
	}
	else
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "系统编号错误[%s]", m_ccms801.SysCd.c_str());
		PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "系统编号错误");
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms801::UpdateDB");

	return RTN_SUCCESS;
}

INT32 CRecvCcms801::ChangeHVPSDay()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms801::ChangeHVPSDay");
    int iRet = 0;
    char szSqlStr[1024] = { 0 };

	memset(szSqlStr, NULL_CHAR, sizeof(szSqlStr));
	
	//更新系统状态
	SETCTX(m_Hvsapbankinfo);
	m_Hvsapbankinfo.m_sapbank = m_szHeadInstdDrctPty;
    Trace(L_DEBUG, __FILE__, __LINE__, NULL,
    		"m_Hvsapbankinfo.m_sapbank=[%s]", m_Hvsapbankinfo.m_sapbank.c_str());
	iRet = m_Hvsapbankinfo.findByPK();
    if(iRet != SQL_SUCCESS){
    	Trace(L_ERROR, __FILE__, __LINE__, NULL,
    			"[hv_sapbankinfo]查询失败:[%s]", m_Hvsapbankinfo.GetSqlErr());
    	PMTS_ThrowException(DB_FIND_FAIL);
    }
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "报文当前工作日期及状态[%s][%s]",
        m_sCurSysDt, m_ccms801.CurSysSts.c_str());
        
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "系统当前工作日期及状态[%s][%s]",
        m_Hvsapbankinfo.m_workdate.c_str(), m_Hvsapbankinfo.m_sysstate.c_str()); 
           
    int iWdCmp = strncmp(m_sCurSysDt, m_Hvsapbankinfo.m_workdate.c_str(), 8);
    int iStCmp = atoi(m_ccms801.CurSysSts.c_str()) - atoi(m_Hvsapbankinfo.m_sysstate.c_str());
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
            "iWdCmp = [%d], iStCmp = [%d]", iWdCmp, iStCmp);
            
    if ( iWdCmp < 0 ){
    	Trace(L_INFO, __FILE__, __LINE__,
    			NULL, "当前工作日期比系统工作日期 小，不作更新!");
    	return 1;
    }
    else if (iWdCmp == 0 && iStCmp < 0){
    	Trace(L_INFO, __FILE__, __LINE__,
    			NULL, "相同工作日，当前状态比系统状态 小，不作更新!");
    	return 1;
    }
    
    //只有营业准备时才改日期
    if(m_ccms801.CurSysSts == "00"){
		sprintf(szSqlStr, "UPDATE HV_SAPBANKINFO SET WORKDATE = '%s', "
							"PREDATE = '%s', "
							"NEXTDATE = '%s', "
							"SYSSTATE = '%s', "
							"STATETIME = sysdate "
							"where SAPBANK = '%s' ",
							m_sCurSysDt,
							m_sOrgnlSysDt,
							m_sNxtSysDt,
							m_ccms801.CurSysSts.c_str(),
							m_szHeadInstdDrctPty);
    }
    else{
    	sprintf(szSqlStr, "UPDATE HV_SAPBANKINFO SET WORKDATE = '%s', "
							"SYSSTATE = '%s', "
							"STATETIME = sysdate "
							"where SAPBANK = '%s' ",
							m_sCurSysDt,
							m_ccms801.CurSysSts.c_str(),
							m_szHeadInstdDrctPty);
    }
	
    Trace(L_INFO, __FILE__, __LINE__, NULL, "szSqlStr=[%s]", szSqlStr);
    
    iRet = m_Hvsapbankinfo.execsql(szSqlStr);
    if ( SQL_SUCCESS != iRet )
    {
    	Trace(L_ERROR, __FILE__, __LINE__, NULL, 
    	        "更新HV_SAPBANKINFO表失败[%d][%s]", iRet, m_Hvsapbankinfo.GetSqlErr());
    	 
    	PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新HV_SAPBANKINFO表失败");
    }
    
	//如果变更状态为“日终”，需插入一笔当日对账状态（方便日切参考）
	if( "40" == m_ccms801.CurSysSts )
    {
        InsertHvbkchkst();
        m_bFlag = true;
        
        Trace(L_INFO, __FILE__, __LINE__, NULL, "m_Hvbkchkst插入记录成功,提前结束");
    }
    else if( "00" == m_ccms801.CurSysSts )  //日切:前提是对账成功后才能日切
    {
        //InsertHvsapwtchgedt();

        GetHvbkchkst();
        
        
        //提交事物，防止日切不过
        m_Hvsapbankinfo.commit();
        
        CHvpsChangeDay HvChgeDay;
        iRet = HvChgeDay.doChangeWork(m_dbproc, 0, 0, m_szHeadInstdDrctPty, m_sOrgnlSysDt, m_sCurSysDt);
        if(RTN_SUCCESS != iRet)
    	{
    	    Trace(L_ERROR, __FILE__, __LINE__, NULL, "大额日切失败, iRet=%d", iRet);
    		PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "HVPS doChangeWork error!");
    	}
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms801::ChangeHVPSDay");
    
    return RTN_SUCCESS;
}

INT32 CRecvCcms801::ChangeBEPSDay()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms801::ChangeBEPSDay");
	int iRet = 0;
    char szSqlStr[1024] = { 0 };

	memset(szSqlStr, NULL_CHAR, sizeof(szSqlStr));
	
	SETCTX(m_Bpsapbankinfo);
	m_Bpsapbankinfo.m_sapbank = m_szHeadInstdDrctPty;
    Trace(L_DEBUG, __FILE__, __LINE__, NULL,
    		"m_Bpsapbankinfo.m_sapbank=[%s]", m_Bpsapbankinfo.m_sapbank.c_str());
	iRet = m_Bpsapbankinfo.findByPK();
    if(iRet != SQL_SUCCESS){
    	Trace(L_ERROR, __FILE__, __LINE__, NULL,
    			"[bp_sapbankinfo]查询失败:[%s]", m_Bpsapbankinfo.GetSqlErr());
    	PMTS_ThrowException(DB_FIND_FAIL);
    }
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "报文当前工作日期及状态[%s][%s]",
        m_sCurSysDt, m_ccms801.CurSysSts.c_str());
        
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "系统当前工作日期及状态[%s][%s]",
        m_Bpsapbankinfo.m_workdate.c_str(), m_Bpsapbankinfo.m_sysstate.c_str()); 
           
    int iWdCmp = strncmp(m_sCurSysDt, m_Bpsapbankinfo.m_workdate.c_str(), 8);
    int iStCmp = atoi(m_ccms801.CurSysSts.c_str()) - atoi(m_Bpsapbankinfo.m_sysstate.c_str());
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
            "iWdCmp = [%d], iStCmp = [%d]", iWdCmp, iStCmp);
    
    //小额只比对工作日期
    if ( iWdCmp < 0 ){
    	Trace(L_INFO, __FILE__, __LINE__,
    			NULL, "当前工作日期比系统工作日期小，不作更新!");
    	return 1;
    }

	sprintf(szSqlStr, "UPDATE BP_SAPBANKINFO SET WORKDATE = '%s', "
						"PREDATE = '%s', "
						"NEXTDATE = '%s', "
						"SYSSTATE = '%s', "
						"FEASTFLAG = '%s', "
						"STATETIME = sysdate "
						"where SAPBANK = '%s' ",
						m_sCurSysDt,
						m_sOrgnlSysDt,
						m_sNxtSysDt,
						m_ccms801.CurSysSts.c_str(),
						m_sfeastflg,
						m_szHeadInstdDrctPty);
	
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "szSqlStr=[%s]", szSqlStr);
	
	iRet = m_Bpsapbankinfo.execsql(szSqlStr);
	if ( SQL_SUCCESS != iRet )
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "更新BP_SAPBANKINFO表失败[%d][%s]",
		    iRet, m_Bpsapbankinfo.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新BP_SAPBANKINFO表失败");
	}

    if(m_ccms801.CurSysDt <= m_ccms801.OrgnlSysDt)
    {
        Trace(L_INFO, __FILE__, __LINE__, NULL, "系统当前日期与原系统日期相同");
        m_bFlag = true;
        return RTN_SUCCESS;
    }

    insertChkst();
    
    //提交事物，防止日切不过
    m_Bpsapbankinfo.commit();

    iRet = m_BpChgDay.doChangeWork(m_dbproc, 0, m_szHeadInstdDrctPty, m_sOrgnlSysDt, m_sCurSysDt);
	if(RTN_SUCCESS != iRet)
	{
	    Trace(L_ERROR, __FILE__, __LINE__, NULL, "小额日切失败, iRet=%d", iRet);
		PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "BEPS doChangeWork error!");
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms801::ChangeBEPSDay");
    
    return RTN_SUCCESS;
}


void CRecvCcms801::insertChkst()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms801::insertChkst()");

	int iRet = 0;

	/*此处新添与行内对账状态记录，以使节后第一天可以申请节假日业务与行内对账*/
	//日期需要转换成yyyymmdd格式
	char szChkDt[16] = {0};
	chgToDate(m_ccms801.OrgnlSysDt.c_str(), szChkDt);

	CSysmbchkst mcs;
	SETCTX(mcs);
	mcs.m_checkdate = szChkDt; //对账日期
	mcs.m_sapbank   = m_szHeadInstdDrctPty; //对账清算行
	mcs.m_sysflag   = "1"; //小额标志
	mcs.m_checkstate= "00"; //对账状态, 初始态
	mcs.m_handflag  = "0"; //是否手工发起, 否
	const char* szSr[2] = {"0", "1"}; //往来标识
	for(int j = 0; j < 2; ++j){
		mcs.m_srflag = szSr[j];
		iRet = mcs.insert();
		if(iRet != SQL_SUCCESS && iRet != DUPLICATE_KEY){
			Trace(L_ERROR, __FILE__, __LINE__, NULL,
					"[sys_mbchkst]插入失败:%s", mcs.GetSqlErr());
			PMTS_ThrowException(DB_INSERT_FAIL);
		}
	}

	/*节假日不与人行对账，不新增小额对账记录 非节假日0，节假日1*/
	if (m_Bpsapbankinfo.m_feastflag == "1"){
		Trace(L_INFO, __FILE__, __LINE__, NULL,
				"节假日标志:[%s] 节假日不对账，不新增对账记录", m_Bpsapbankinfo.m_feastflag.c_str());
		return;
	}

    SETCTX(m_Bpbchkstate);
    
	//增加对账状态表记录

	m_Bpbchkstate.m_workdate    = m_sCurSysDt;
	m_Bpbchkstate.m_chkdate     = m_ccms801.OrgnlSysDt; //对账日期
	m_Bpbchkstate.m_pkbknode    = m_szHeadInstdDrctPty;
	m_Bpbchkstate.m_feastflag   = m_sfeastflg;
	m_Bpbchkstate.m_checkstate  = "00";
	//m_Bpbchkstate.m_dealcode ;
	//m_Bpbchkstate.m_dealdesc ;
	//m_Bpbchkstate.m_remark = "";

	iRet = m_Bpbchkstate.insert();
	if ( SQL_SUCCESS != iRet)
	{
		if (DUPLICATE_KEY == iRet)
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL, "插入对账状态表记录重复,忽略");
		}
		else
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL, "插入对账状态表记录出错,iRet=[%d] %s", iRet, m_Bpbchkstate.GetSqlErr());
			PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "插入对账状态表记录出错");
		}
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms801::insertChkst()");
}

