/******************************************************************** 
�ļ����� recvccms917.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-03-05
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvccms917.h"
CRecvCcms917::CRecvCcms917()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms917::CRecvCcms917()");	
    m_msgtp = "ccms.917.001.01";
}


CRecvCcms917::~CRecvCcms917()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms917::~CRecvCcms917()");		
}

INT32 CRecvCcms917::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms917::Work()");

	//1����������
	unPack(sMsg);
	
	//2����Ա��ֵ
	SetData(sMsg);

    InsertData();
    
					  
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms917::work()");

	return RTN_SUCCESS;
}

INT32 CRecvCcms917::unPack(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms917::unPack");	

	int iRet = RTN_FAIL;

	//1�������Ƿ�Ϊ��
	if (NULL == sMsg || '\0' == sMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
	}

	/*//2����ȡ���������
	if (RTN_SUCCESS != GetParserObj(sMsg))
	{
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRSMSG_FAIL, "��ȡ���������ʧ��");
	}*/

    
	//3����������
	iRet = m_cParser917.ParseXml(sMsg);
	if (RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= %d", iRet);	
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
	}
	
	iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;

    ZFPTLOG.SetLogInfo("917", m_cParser917.MsgId.c_str());
	
	m_strMsgID	=	m_cParser917.MsgId;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms917::unPack");	

	return RTN_SUCCESS;
}


/*INT32 CRecvCcms917::GetParserObj(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms917::GetParserObj");

	// �ж��ǵڼ������� ����ֻ�ж���
	int iVer = JudgeMsgVer(sMsg);
	if (MSG_VER_2ND == iVer)
	{
		// ��������
		m_cParser917.Init(MSG_VER_2ND, 917);
		m_bsischngntfctn.m_msgtp = m_msgtp;
	}
	else
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "JudgeMsgVer iVer=[%d]", iVer);
		return RTN_FAIL;
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms917::GetParserObj");

	return RTN_SUCCESS;
}*/

/*
CC00������
CC01�����
CC02������
EF00��������Ч
EF01��ָ��������Ч
*/
INT32 CRecvCcms917::SetData(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms917::SetData");

    /*SETCTX(m_bsischngntfctn);
    int iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;      

    //���ܱ�
    m_bsischngntfctn.m_msgid = m_cParser917.MsgId; 
    m_bsischngntfctn.m_wrkdate = m_strWorkDate ; 
    m_bsischngntfctn.m_sysid = m_cParser917.SysCd; 
    m_bsischngntfctn.m_rmk = m_cParser917.Rmk; 
    m_bsischngntfctn.m_chngnb = m_cParser917.ChngNb; 
    //m_bsischngntfctn.m_statetime = m_cParser917. ;ʵ���ำֵ

    m_bsischngntfctn.m_instgdrctpty = m_cParser917.InstgDrctPty; 
    m_bsischngntfctn.m_instgindrctpty = m_cParser917.GrpHdrInstgPty; 
    m_bsischngntfctn.m_instddrctpty = m_cParser917.InstdDrctPty; 
    m_bsischngntfctn.m_instdindrctpty = m_cParser917.GrpHdrInstdPty ; 

    m_bsischngntfctn.m_bktpchngnb = atoi(m_cParser917.BkTpChngNb.c_str()); 
    m_bsischngntfctn.m_ccpcchngnb = atoi(m_cParser917.CCPCChngNb.c_str()); 
    m_bsischngntfctn.m_citychngnb = atoi(m_cParser917.CityChngNb.c_str()); 

    iRet = m_bsischngntfctn.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "����cm_bsischngntfctn��ʧ��, iRet=%d, %s", iRet, m_bsischngntfctn.GetSqlErr());
        PMTS_ThrowException(DB_INSERT_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCcms917::SetData");*/
	return RTN_SUCCESS;
}

INT32 CRecvCcms917::InsertCmcpcchng()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms917::InsertCmcpcchng");
    
		char m_sTempDate[8+1];

    //����Cm_cpcchng��
    SETCTX(m_ccpcchng);
    int iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;
    int iNum = atoi(m_cParser917.CCPCChngNb.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iNum[%d]",iNum);
    for(int i = 0; i < iNum; i++)
    {
				memset(m_sTempDate, 0x00, sizeof(m_sTempDate));

        //��ϸ��
        m_ccpcchng.m_listid = i;
        m_ccpcchng.m_nodecode = m_cParser917.GetValueFromCycle("CCPCChngInf", "CCPCChngInfNdCd", i);
        m_ccpcchng.m_ndname = m_cParser917.GetValueFromCycle("CCPCChngInf", "NdNm", i);
        m_ccpcchng.m_nodetype = m_cParser917.GetValueFromCycle("CCPCChngInf", "NdTp", i);
        string strTemp = m_cParser917.GetValueFromCycle("CCPCChngInf", "CCPCChngInfCityCd", i);
        m_ccpcchng.m_citycd = atoi(strTemp.c_str());
        m_ccpcchng.m_procstate = "34";
        //m_ccpcchng.m_proctime ʵ���ำֵ
        m_ccpcchng.m_msgid = m_cParser917.MsgId; 
        m_ccpcchng.m_wrkdate = m_strWorkDate ; 
        m_ccpcchng.m_msgtp = m_msgtp;
        m_ccpcchng.m_sysid = m_cParser917.SysCd; 
        m_ccpcchng.m_rmk = m_cParser917.Rmk; 
        m_ccpcchng.m_chngnb = m_cParser917.ChngNb; 
        //m_ccpcchng.m_statetime = m_cParser917. ;ʵ���ำֵ
        m_ccpcchng.m_chngtp = m_cParser917.GetValueFromCycle("CCPCChngInf", "CCPCChngInfChngTp", i);
        m_ccpcchng.m_fctvtp = m_cParser917.GetValueFromCycle("CCPCChngInf", "CCPCChngInfFctvTp", i); 

        chgToDate(m_cParser917.GetValueFromCycle("CCPCChngInf", "CCPCChngInfFctvDt", i).c_str()	, m_sTempDate);
        m_ccpcchng.m_fctvdt = m_sTempDate;
 
				memset(m_sTempDate, 0x00, sizeof(m_sTempDate));
        chgToDate(m_cParser917.GetValueFromCycle("CCPCChngInf", "CCPCChngInfIfctvDt", i).c_str()	, m_sTempDate);
        m_ccpcchng.m_ifctvdt = m_sTempDate;

        int iRet = m_ccpcchng.insert();
		if(DUPLICATE_KEY == iRet)//������ͻ �����˳�
		{
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "����cm_ccpcchng��ʧ��, iRet=%d, %s", iRet, m_ccpcchng.GetSqlErr());
		    continue;
        }
        else if(OPERACT_SUCCESS != iRet)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����cm_ccpcchng��ʧ��, iRet=%d, %s", iRet, m_ccpcchng.GetSqlErr());
            PMTS_ThrowException(DB_INSERT_FAIL); 
        }
    }        
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCcms917::InsertCmcpcchng");
    return RTN_SUCCESS;
}

INT32 CRecvCcms917::InsertCmcitychng()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms917::InsertCmcitychng");

		char m_sTempDate[8+1];

    //����Cm_citychng��
    SETCTX(m_citychng); 
    int iNum = atoi(m_cParser917.CityChngNb.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iNum[%d]",iNum);
    for(int i = 0; i < iNum; i++)
    {
        //��ϸ��
        m_citychng.m_listid = i;
        m_citychng.m_citycode = m_cParser917.GetValueFromCycle("CityChngInf", "CityChngInfCityCd", i);
        m_citychng.m_nodecode = m_cParser917.GetValueFromCycle("CityChngInf", "CityChngInfNdCd", i);
        m_citychng.m_cityname = m_cParser917.GetValueFromCycle("CityChngInf", "CityNm", i);
        m_citychng.m_citytp= m_cParser917.GetValueFromCycle("CityChngInf", "CityTp", i);
        m_citychng.m_nodecode= m_cParser917.GetValueFromCycle("CityChngInf", "CityChngInfNdCd", i);
        m_citychng.m_procstate = "34";
        //m_citychng.m_proctimeʵ���ำֵ;
        m_citychng.m_msgid = m_cParser917.MsgId;
        m_citychng.m_wrkdate = m_strWorkDate ; 
        m_citychng.m_msgtp = m_msgtp;
        m_citychng.m_sysid = m_cParser917.SysCd; 
        m_citychng.m_rmk = m_cParser917.Rmk; 
        m_citychng.m_chngnb = m_cParser917.ChngNb; 
        //m_citychng.m_statetime = m_cParser917. ;ʵ���ำֵ
        m_citychng.m_chngtp = m_cParser917.GetValueFromCycle("CityChngInf", "CityChngInfChngTp", i);
        m_citychng.m_fctvtp = m_cParser917.GetValueFromCycle("CityChngInf", "CityChngInfFctvTp", i); 

				memset(m_sTempDate, 0x00, sizeof(m_sTempDate));
        chgToDate(m_cParser917.GetValueFromCycle("CityChngInf", "CityChngInfFctvDt", i).c_str()	, m_sTempDate);
        m_citychng.m_fctvdt = m_sTempDate;

				memset(m_sTempDate, 0x00, sizeof(m_sTempDate));
        chgToDate(m_cParser917.GetValueFromCycle("CityChngInf", "CityChngInfIfctvDt", i).c_str()	, m_sTempDate);
        m_citychng.m_ifctvdt = m_sTempDate;

        int iRet = 0;
        iRet = m_citychng.insert();
        if(DUPLICATE_KEY == iRet)//������ͻ �����˳�
		{
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "����cm_citychng��ʧ��, iRet=%d, %s", iRet, m_citychng.GetSqlErr());
		    continue;
        }
        else if(OPERACT_SUCCESS != iRet)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����cm_citychng��ʧ��, iRet=%d, %s", iRet, m_citychng.GetSqlErr());
            PMTS_ThrowException(DB_INSERT_FAIL);
        }
    }   
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCcms917::InsertCmcitychng");
    return RTN_SUCCESS;
}

INT32 CRecvCcms917::InsertCmbktpchng()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms917::InsertCmbktpchng");
        
		char m_sTempDate[8+1];

    //����cm_bktpchng��
    SETCTX(m_bktpchng);   
    int iNum = atoi(m_cParser917.BkTpChngNb.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iNum[%d]",iNum);
    for(int i = 0; i < iNum; i++)
    {
        //��ϸ��  
        m_bktpchng.m_chngtp = m_cParser917.GetValueFromCycle("BkTpChngInf", "BkTpChngInfChngTp", i);
        m_bktpchng.m_fctvtp = m_cParser917.GetValueFromCycle("BkTpChngInf", "BkTpChngInfFctvTp", i); 

				memset(m_sTempDate, 0x00, sizeof(m_sTempDate));
        chgToDate(m_cParser917.GetValueFromCycle("BkTpChngInf", "BkTpChngInfFctvDt", i).c_str()	, m_sTempDate);
        m_bktpchng.m_fctvdt = m_sTempDate;

				memset(m_sTempDate, 0x00, sizeof(m_sTempDate));
        chgToDate(m_cParser917.GetValueFromCycle("BkTpChngInf", "BkTpChngInfIfctvDt", i).c_str()	, m_sTempDate);
        m_bktpchng.m_ifctvdt = m_sTempDate;

        m_bktpchng.m_listid = i;
        m_bktpchng.m_banktype = m_cParser917.GetValueFromCycle("BkTpChngInf", "BkTpCd", i);
        m_bktpchng.m_banktypename = m_cParser917.GetValueFromCycle("BkTpChngInf", "BkTpNm", i);
        m_bktpchng.m_msgid = m_cParser917.MsgId;
        string strTemp = m_cParser917.GetValueFromCycle("BkTpChngInf", "TpCd", i);
        m_bktpchng.m_tpcd = atoi(strTemp.c_str());
        m_bktpchng.m_tpnm = m_cParser917.GetValueFromCycle("BkTpChngInf", "TpNm", i);
        m_bktpchng.m_procstate = "34";
        //m_bktpchng.m_proctimeʵ���ำֵ;
        m_bktpchng.m_msgid = m_cParser917.MsgId;
        m_bktpchng.m_wrkdate = m_strWorkDate ; 
        m_bktpchng.m_msgtp = m_msgtp;
        m_bktpchng.m_sysid = m_cParser917.SysCd; 
        m_bktpchng.m_rmk = m_cParser917.Rmk; 
        m_bktpchng.m_chngnb = m_cParser917.ChngNb; 
        //m_bktpchng.m_statetime = m_cParser917. ;ʵ���ำֵ

        int iRet = 0;
        iRet = m_bktpchng.insert();
        if(DUPLICATE_KEY == iRet)//������ͻ �����˳�
		{
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "����cm_bktpchng��ʧ��, iRet=%d, %s", iRet, m_bktpchng.GetSqlErr());
		    continue;
        }
        else if(OPERACT_SUCCESS != iRet)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����cm_bktpchng��ʧ��, iRet=%d, %s", iRet, m_bktpchng.GetSqlErr());
            //PMTS_ThrowException(DB_INSERT_FAIL);   
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���м����ڸü�¼����Ҫ����");       
        }
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCcms917::InsertCmbktpchng");
    return RTN_SUCCESS;
}

INT32 CRecvCcms917::InsertData(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms917::InsertData");

	InsertCmcpcchng();
	
    InsertCmcitychng();
	
	InsertCmbktpchng();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms917::InsertData");
	
	return RTN_SUCCESS;
}

/*************************************************
//��Чʱ�䵽ʱ���õ�
//�����ϸ ���ܱ�ִ�в������,��ϵ��ִ�и��²���
INT32 CRecvCcms917::UpdateState(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms917::UpdateState");

	SETCTX(m_bsischngntfctn);
    int iRet = m_bsischngntfctn.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "�����ʧ��, iRet=%d", iRet);
        return iRet;
    }
    
    SETCTX(m_ccpcchng);
    int iRet = m_ccpcchng.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "��������ʧ��, iRet=%d", iRet);
        return iRet;            
    }

    SETCTX(m_bankinfo);
    m_bktpchng.strSQL;
	strSQL += "UPDATE cm_bankinfo t SET ";
	strSQL += "' t.BBNKCODE = '";
    strSQL += m_bankinfo.m_bbnkcode;
	strSQL += "' t.PROCSTATE = '";
	strSQL += m_bankinfo.m_procstate;   //��Ϊ������д�˶�Ϊ��ʱ����,��������дδ��Ч
	strSQL += "' t.PROCTIME = '";
    strSQL += m_bankinfo.m_proctime;              //���ݿ�������洢����ʵ��,����д�ϵ�ǰ�Ĺ���ʱ��
    strSQL += "' ";
    
	strSQL += " WHERE t.BANKCODE = '";
	strSQL += m_bankinfo.m_bankcode;
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	
    iRet = m_bankinfo.execsql(strSQL.c_str());
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "���±�ʧ��, iRet=%d", iRet);
        return iRet;            
    }
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms917::UpdateState");

	return RTN_SUCCESS;
}
*******************************/


