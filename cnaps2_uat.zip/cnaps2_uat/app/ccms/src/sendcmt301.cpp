/******************************************************************** 
�ļ����� sendcmt301.cpp
�����ˣ� hq
��  �ڣ� 2011-07-01
�޸��ˣ� 
��  �ڣ� 
��  ���� CMT302��ѯ�����˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt301.h"

using namespace ZFPT;

CSendCmt301::CSendCmt301(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{
	memset(strSql,0x00,sizeof(strSql));
}

CSendCmt301::~CSendCmt301()
{

}

int CSendCmt301::doWorkSelf()
{
   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt301::doWork...");
	
	
    // ��ȡ����
    GetData();

    // �鱨��
    CreateNpcMsg();
    
    // �޸�״̬
    UpdateState();

    // ���ͱ���
    AddQueue(m_cmt301.m_strCmtmsg.c_str(), m_cmt301.m_strCmtmsg.length());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt301::doWork..."); 
    return RTN_SUCCESS;
}

int CSendCmt301::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt301::GetData...");

    SETCTX(m_CTransQry);
    SetDBKey();
    
    int iRet = m_CTransQry.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��[%d][%s]",
            iRet, m_CTransQry.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt301::GetData...");
    return SQL_SUCCESS;
}

void CSendCmt301::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt301::SetDBKey...");
    SETCTX(m_CTransQry);
    char szSys[4+1] = {0};
    char strSqlRun[1024]={0};
    int iRet=-1;
    strncpy(szSys, m_szSysFlagNO, 4);
    
    StrUpperCase(szSys);
    m_CTransQry.m_sysid        = szSys;
	m_CTransQry.m_msgid        = m_szMsgFlagNO; 
	m_CTransQry.m_instgindrctpty = m_szSndNO;
	m_CTransQry.m_rsflag       = m_szSrcflg;

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sysid=[%s]",m_CTransQry.m_sysid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_msgid=[%s]",m_CTransQry.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_instgindrctpty=[%s]",m_CTransQry.m_instgindrctpty.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt301::SetDBKey...");
}

void CSendCmt301::CreateNpcMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt301::CreateNpcMsg...");

    char SndCCPCNode[4 + 1] = {0};	
    char RcvCCPCNode[4 + 1] = {0};
    int  iSysCd = 1;
    int  iRet   = -1;

    strncpy(m_cmt301.sQuerydate,      m_CTransQry.m_wrkdate.c_str(),        sizeof(m_cmt301.sQuerydate) - 1);
    strncpy(m_cmt301.sQuerybank,      m_CTransQry.m_instgindrctpty.c_str(), sizeof(m_cmt301.sQuerybank) - 1);
    strncpy(m_cmt301.sSendsapbk,      m_CTransQry.m_instgdrctpty.c_str(),   sizeof(m_cmt301.sSendsapbk) - 1);
    strncpy(m_cmt301.sQueryno,        m_CTransQry.m_msgid.c_str() + 8,      sizeof(m_cmt301.sQueryno)   - 1);
    strncpy(m_cmt301.sReplybank,      m_CTransQry.m_instdindrctpty.c_str(), sizeof(m_cmt301.sReplybank) - 1);
    strncpy(m_cmt301.sRecvsapbk,      m_CTransQry.m_instddrctpty.c_str(),   sizeof(m_cmt301.sRecvsapbk) - 1);
    if(0 == STRNCASECMP("HVPS",m_szSysFlagNO,4))
    {
        m_cmt301.sOldtradetype[0] = '1';//1:���ҵ�� 2:С��ҵ�� 3:����ҵ�� 4:���˳���ҵ�� 5:ͬ�������ҵ��
        strncpy(m_cmt301.sOldconsigndate, m_CTransQry.m_orgnlmsgid.c_str(),     sizeof(m_cmt301.sOldconsigndate) - 1);
        strncpy(m_cmt301.sOldsendbank,    m_CTransQry.m_orgnlinstgdrctpty.c_str(), sizeof(m_cmt301.sOldsendbank)    - 1);
        strncpy(m_cmt301.sOldrecvbank,    m_CTransQry.m_orgninstdindrctpty.c_str(), sizeof(m_cmt301.sOldrecvbank)    - 1);
        strncpy(m_cmt301.sOldtxssno,      m_CTransQry.m_orgnlmsgid.c_str() + 8, sizeof(m_cmt301.sOldtxssno)      - 1);
    }
    else
    {
        m_cmt301.sOldtradetype[0] = '2';
        strncpy(m_cmt301.sOldconsigndate, m_CTransQry.m_orgnltxmsgid.c_str(),     sizeof(m_cmt301.sOldconsigndate) - 1);
        strncpy(m_cmt301.sOldsendbank,    m_CTransQry.m_orgninstgindrctpty.c_str(), sizeof(m_cmt301.sOldsendbank)    - 1);
        strncpy(m_cmt301.sOldrecvbank,    m_CTransQry.m_orgninstdindrctpty.c_str(), sizeof(m_cmt301.sOldrecvbank)    - 1);
        strncpy(m_cmt301.sOldtxssno,      m_CTransQry.m_orgnltxmsgid.c_str() + 8, sizeof(m_cmt301.sOldtxssno)      - 1);
    }
    
    strncpy(m_cmt301.sOldcur,         m_CTransQry.m_qryccy.c_str(),         sizeof(m_cmt301.sOldcur) - 1);
    m_cmt301.dOldamount = m_CTransQry.m_qryamt;
    strncpy(m_cmt301.sRemark,         m_CTransQry.m_msgcnt.c_str(),         sizeof(m_cmt301.sRemark) - 1);

    GetSapBkToCCPC(m_dbproc, m_cmt301.sSendsapbk, SndCCPCNode);
    GetSapBkToCCPC(m_dbproc, m_cmt301.sRecvsapbk, RcvCCPCNode);
    strncpy(m_cmt301.sSendcenter,    SndCCPCNode,                           sizeof(m_cmt301.sSendcenter) - 1);
    strncpy(m_cmt301.sRecvcenter,    RcvCCPCNode,                           sizeof(m_cmt301.sRecvcenter) - 1);
                         
    chgSysCd(m_CTransQry.m_sysid.c_str(), iSysCd);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iSysCd[%d]", iSysCd);
    iRet = m_cmt301.CreateCmt("301",
                           	  m_cmt301.sSendsapbk,
                           	  m_cmt301.sRecvsapbk,
                           	  m_sMesgId.c_str(),
                           	  m_sMesgId.c_str(), 
                           	  m_CTransQry.m_wrkdate.c_str(),
                           	  "0",
                           	  iSysCd);
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�鱨��ʧ��,iRet[%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
	m_CTransQry.closeCursor();
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt301::CreateNpcMsg...");
}

int CSendCmt301::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt301::UpdateState...");

    string strSQL;
    
    string strNpcMsg = "";
    int nSysID = m_CTransQry.m_sysid == "BEPS" ? SYS_BEPS : SYS_HVPS;
	if(!m_CTransQry.write_blob(m_cmt301.m_strCmtmsg.c_str(), strNpcMsg, nSysID)){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"д���ֶα�����:[%s]", m_CTransQry.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}

    //���ｫί��������Ϊ��̬����д�����ݿ� �������
    char szIOSdate[10 + 1] = {0};
    chgToISODate(m_CTransQry.m_consigndate.c_str(), szIOSdate);
    
	strSQL += "UPDATE cm_transinfoqry t SET t.PROCSTATE = '";
	strSQL += PR_HVBP_08;
	strSQL += "', t.npcmsg='";
	strSQL += strNpcMsg;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
	strSQL += "', t.FINALSTATEDATE = '";
    strSQL += szIOSdate;
    strSQL += "', t.STATETIME = sysdate ";
    
	strSQL += " WHERE  t.MSGTP = '";                        //t.rsflag = '0' AND
	strSQL += m_CTransQry.m_msgtp.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_CTransQry.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_CTransQry.m_instgindrctpty.c_str(); 									
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	
    int iRet = m_CTransQry.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��[%d][%s]", 
            iRet, m_CTransQry.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt301::UpdateState...");
     m_CTransQry.closeCursor();
    return SQL_SUCCESS;
}


