/********************************************************************
�ļ�����send317.cpp
�����ˣ�handongfeng
��  �ڣ�2011.01.14
��  ����
��  ����
Copyright (c) 2009  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif


#include "sendccms317.h"
#include "category.h"


extern CConnectPool *g_DBConnPool;
extern CCategory g_LogObj;

using namespace ZFPT;

CSendCcms317::CSendCcms317(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{

}

CSendCcms317::~CSendCcms317()
{

}

void CSendCcms317::SetDBKey()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms317::SetDBKey...");
	
	m_Hvsndlist.m_msgtp = m_szMsgType; 
	m_Hvsndlist.m_msgid = m_szMsgFlagNO; 
	m_Hvsndlist.m_instgdrctpty = m_szSndNO; 
	m_Hvsndlist.m_rsflag = "1";
	
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgType = %s", m_szMsgType);
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgFlagNO = %s", m_szMsgFlagNO);
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndNO = %s", m_szSndNO);
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms317::SetDBKey...");
	return;
}

void CSendCcms317::SetData()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms317::SetData...");
	char sTm[7] = {0}; 
	getSysTime(sTm);
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "sTm = %s", sTm);
	char temp[21] = {0};
	sprintf(temp, "%s.%s.%s.%s",  "ccms", m_szMsgType, "001", "01");
	sprintf(m_MsgTypeCode, "%-20s", temp);
	
	m_cParser317.m_PMTSHeader.setVerID("02");
	m_cParser317.m_PMTSHeader.setOrigSender(m_Hvsndlist.m_instgdrctpty.c_str());
	m_cParser317.m_PMTSHeader.setOrigSenderSID("CCMS");
	m_cParser317.m_PMTSHeader.setOrigReceiver(m_Hvsndlist.m_instddrctpty.c_str());
	m_cParser317.m_PMTSHeader.setOrigReceiverSID("CCMS");
	m_cParser317.m_PMTSHeader.setOrigSendDate(m_Hvsndlist.m_workdate.c_str());
	m_cParser317.m_PMTSHeader.setOrigSendTime(sTm);
	m_cParser317.m_PMTSHeader.setStructType(m_szMsgTypeFlag);
	m_cParser317.m_PMTSHeader.setMesgRefID(m_Hvsndlist.m_mesgrefid.c_str());
	m_cParser317.m_PMTSHeader.setMesgID(m_Hvsndlist.m_mesgid.c_str());
	m_cParser317.m_PMTSHeader.setMesgPriority(m_Hvsndlist.m_mesgrefid.c_str());
	m_cParser317.m_PMTSHeader.setMesgDirection("U");
	
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms317::SetData...");
	return;
}

int CSendCcms317::GetData()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms317::GetData...");
	m_Hvsndlist.setctx(m_dbproc);
	
	SetDBKey();
	int iRet = m_Hvsndlist.findByPK();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms317::GetData...");
	return iRet;
}

int CSendCcms317::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms317::UpdateState...");
    SetDBKey();
    if(OPERACT_SUCCESS != m_Hvsndlist.setstate("08", m_sMesgId, m_sEndtoEnd))
    {
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��");
        return OPERACT_FAILED;
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms317::UpdateState...");
    return OPERACT_SUCCESS;
}

int CSendCcms317::doWorkSelf()
{
   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms317::doWork...");

    //��ȡ���ݿ�����
    int iRet = g_DBConnPool->GetConnect(m_dbproc);
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ���ݿ�����ʧ��");
        return ERR_DB_CONNT_FAILE;	
    }

    iRet = GetData();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��");
        return ERR_DB_GETDATA_FAILE;	
    }


    m_cParser317.Init(m_iVersion, atoi(m_szMsgType));
    
    SetData();
    
    AddSign317();
    
    iRet = m_cParser317.CreateMsg();
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        return ERR_CREATE_MSG_FAILE;
    }
    
    iRet = AddQueue( m_cParser317.m_MsgTxt.c_str(), m_cParser317.m_MsgTxt.length());
    if(iRet != OPERACT_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��MQ��������ʧ��");
        return ERR_MQ_ADD_FAILE;
    }

    iRet = UpdateState();
    if(iRet != OPERACT_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��");
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms317::doWork..."); 
    return OPERACT_SUCCESS;
}

void CSendCcms317::AddSign317()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms317::AddSign317");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_cParser317.getOriSignStr();
	
	AddSign(m_cParser317.m_sSignBuff.c_str(), 
					m_sSignBuff, 
					RAWSIGN);
	
	m_cParser317.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms317::AddSign317");
}



