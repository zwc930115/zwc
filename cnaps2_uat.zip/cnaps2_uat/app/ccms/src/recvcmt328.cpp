/******************************************************************** 
�ļ����� recvcmt328.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-04-28
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvcmt328.h"

using namespace ZFPT;

CRecvCmt328::CRecvCmt328()
{
    m_strMsgTp	  = "CMT328";
    memset(m_sOldMsgId, 0x00, sizeof(m_sOldMsgId));
    memset(m_szProcState, 0x00, sizeof(m_szProcState));
}

CRecvCmt328::~CRecvCmt328()
{
	
}

INT32 CRecvCmt328::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt328::Work()");	

	// ��������
	unPack(sMsg);

    GetOrgnBuss();

	InsertDb(sMsg);
    
    UpdateDB();

    if( 0 == strcmp("2", m_cmt328.sFlag) )
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "״̬Ϊ����ֹ��,�˳�");	
        return RTN_SUCCESS;
    }
    
	//UpdateState();

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt328::work()");

	return RTN_SUCCESS;
}

void CRecvCmt328::UpdateDB()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt328::UpdateDB()");

	string strSQL;
	int iRet = -1;

	strSQL += "UPDATE bp_CstBdPCxlCl t SET t.RSPFLAG = '";
    strSQL += "1";
    strSQL += "', t.StopPmtSts = '";
	strSQL += m_cmt328.sFlag;
	strSQL += "', t.STATETIME = sysdate";
	strSQL += " WHERE t.RSFLAG <> '2' AND t.msgid = '";
	strSQL += m_cOrgnBpcstbdpcxlcl.m_msgid;
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_cOrgnBpcstbdpcxlcl.m_instgdrctpty; 
	strSQL += "'";
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, strSQL.c_str());
	
    SETCTX(m_cOrgnBpcstbdpcxlcl);
	iRet = m_cOrgnBpcstbdpcxlcl.execsql(strSQL.c_str());
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL, "Update failed, sqlcode=[%d]", iRet);
	}
	else if (iRet != SQL_SUCCESS)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]",iRet, m_cOrgnBpcstbdpcxlcl.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
	}
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt328::UpdateDB()");
}

void CRecvCmt328::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt328::UpdateState()");

    int iRet = 0;
    string strSQL;
    if(RTN_SUCCESS != strcmp("0", m_cmt328.sOldpacktype))
    {
        SETCTX(m_cBpbdsndcl);
    	strSQL += "UPDATE bp_BDSNDCL t SET t.Procstate = '";
        strSQL += m_szProcState;
        strSQL += "', t.BusiState = '";
        strSQL += PROCESS_PR21;
    	strSQL += "', t.STATETIME = sysdate WHERE t.msgid = '";
    	strSQL += m_cBpbdsndcl.m_msgid;
    	strSQL += "' AND t.INSTGDRCTPTY = '";
    	strSQL += m_cBpbdsndcl.m_instgdrctpty;
    	strSQL += "'";
    	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, strSQL.c_str());
    	
        iRet = m_cBpbdsndcl.execsql(strSQL);
        if (iRet != SQL_SUCCESS)
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]", iRet, m_cBpbdsndcl.GetSqlErr());
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
		}
		
        SETCTX(m_cBpbdsendlist);
        strSQL = "";
    	strSQL += "UPDATE bp_BDSENDLIST t SET t.Procstate = '";
        strSQL += m_szProcState;
        strSQL += "', t.BusiState = '";
        strSQL += PROCESS_PR21;
    	strSQL += "', t.STATETIME = sysdate WHERE t.msgid = '";
    	strSQL += m_cBpbdsndcl.m_msgid;
    	strSQL += "' AND t.INSTGDRCTPTY = '";
    	strSQL += m_cBpbdsndcl.m_instgdrctpty;    	
    	strSQL += "'";
    	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, strSQL.c_str());
    	
    	iRet = m_cBpbdsendlist.execsql(strSQL);
        if (iRet != SQL_SUCCESS)
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]", iRet, m_cBpbdsendlist.GetSqlErr());
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
		}
		    	
	}
    else
    {
        SETCTX(m_cBpbdsendlist);
        strSQL = "";
    	strSQL += "UPDATE bp_BDSENDLIST t SET t.Procstate = '";
        strSQL += m_szProcState;
        strSQL += "', t.BusiState = '";
        strSQL += PROCESS_PR21;
    	strSQL += "', t.STATETIME = sysdate  WHERE t.TxId = '";
    	strSQL += m_cOrgnBpcstbdpcxllist.m_orgnlpmtinfid;
    	strSQL += "' AND t.INSTGDRCTPTY = '";
    	strSQL += m_cBpbdsndcl.m_instgdrctpty;
    	strSQL += "' AND t.msgid = '";
    	strSQL += m_cBpbdsndcl.m_msgid;    	
    	strSQL += "'";
    	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, strSQL.c_str());
    	
    	iRet = m_cBpbdsendlist.execsql(strSQL);
        if (iRet != SQL_SUCCESS)
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]", iRet, m_cBpbdsendlist.GetSqlErr());
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
		}
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt328::UpdateState()");
}

INT32 CRecvCmt328::unPack(LPCSTR sMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt328::unPack");	

    int iRet = RTN_FAIL;
    char sMsgId[35 + 1] = { 0 };

    // �����Ƿ�Ϊ��
    if (NULL == sMsg || '\0' == sMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }

    // ��������
    iRet = m_cmt328.ParseCmt(sMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������,iRet[%d]", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
    }

    sprintf(m_sOldMsgId, "%8s%08s", m_cmt328.sOldconsigndate, m_cmt328.sOldsendmssno);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cmt328.sOldconsigndate=%s m_cmt328.sOldsendmssno=%s m_sOldMsgId=%s",
                                                m_cmt328.sOldconsigndate, m_cmt328.sOldsendmssno,m_sOldMsgId);	

    // ���ı�ʶ�š�ϵͳ���
    sprintf(sMsgId, "%8s%08s", m_cmt328.sConsigndate, m_cmt328.sRecvmssno);
    m_strMsgID = sMsgId;
    ZFPTLOG.SetLogInfo("328", m_strMsgID.c_str());
            
    // ��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS,m_cmt328.sOldsendsapbk);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;  

    if(RTN_SUCCESS ==strcmp(m_cmt328.sFlag,"1"))//1 ��ֹ��  2 ����ֹ����
    {
        strcpy(m_szProcState,PR_HVBP_25);
    }
    else
    {
        strcpy(m_szProcState,PR_HVBP_26);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt328::unPack");	

    return RTN_SUCCESS;
}

void CRecvCmt328::GetOrgnBuss()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt328::GetOrgnBuss");	
    
    SETCTX(m_cOrgnBpcstbdpcxlcl);
    m_cOrgnBpcstbdpcxlcl.m_msgid = m_sOldMsgId;
    m_cOrgnBpcstbdpcxlcl.m_instgpty = m_cmt328.sOldsendbank;
    m_cOrgnBpcstbdpcxlcl.m_rsflag = "1";

    int iRet = m_cOrgnBpcstbdpcxlcl.findByPK();
    if (SQL_SUCCESS != iRet) 
	{
	    m_cOrgnBpcstbdpcxlcl.m_rsflag = "0";
	    iRet = m_cOrgnBpcstbdpcxlcl.findByPK();
	    if (SQL_SUCCESS != iRet) 
	    {
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ѯ���ҵ��ֹ�����ܱ���������[%s], [%s], [%d][%s]", 
    		        m_cOrgnBpcstbdpcxlcl.m_msgid.c_str(), m_cOrgnBpcstbdpcxlcl.m_instgpty.c_str(), iRet, m_cOrgnBpcstbdpcxlcl.GetSqlErr());
    		PMTS_ThrowException(DB_NOT_FOUND);
	    }
	}

    if(RTN_SUCCESS == strcmp("0", m_cmt328.sOldpacktype))
    {
        SETCTX(m_cOrgnBpcstbdpcxllist);
        m_cOrgnBpcstbdpcxllist.m_msgid = m_sOldMsgId;
        m_cOrgnBpcstbdpcxllist.m_instgpty = m_cmt328.sOldsendbank;
        m_cOrgnBpcstbdpcxllist.m_rsflag = "2";

        string strSQL = "MSGID = '" + m_cOrgnBpcstbdpcxllist.m_msgid + "' and orgcdtrbrnchid = '" + m_cOrgnBpcstbdpcxllist.m_instgpty + "'";
        iRet = m_cOrgnBpcstbdpcxllist.find(strSQL);
        if (SQL_SUCCESS != iRet) 
    	{
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ѯ���ҵ��ֹ����ϸ����������[%s], [%s], [%d][%s]", 
    		        m_cOrgnBpcstbdpcxllist.m_msgid.c_str(), m_cOrgnBpcstbdpcxllist.m_instgpty.c_str(), iRet, m_cOrgnBpcstbdpcxllist.GetSqlErr());
    		PMTS_ThrowException(DB_NOT_FOUND);
    	}

    	int iRetCode = m_cOrgnBpcstbdpcxllist.fetch();	
    	if (SQLNOTFOUND == iRetCode) 
    	{
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL,  "�Ҳ���ָ��ҵ��[%s], [%s], [%d][%s]", 
    		                                            m_cOrgnBpcstbdpcxllist.m_msgid.c_str(), 
    		                                            m_cOrgnBpcstbdpcxllist.m_instgpty.c_str(), 
    		                                            iRet, 
    		                                            m_cOrgnBpcstbdpcxllist.GetSqlErr());
    		
    		PMTS_ThrowException(DB_NOT_FOUND);		
    	}	
	}
	
    SETCTX(m_cBpbdsndcl);
    m_cBpbdsndcl.m_msgid = m_cOrgnBpcstbdpcxlcl.m_orgnlmsgid;
    m_cBpbdsndcl.m_instgdrctpty = m_cOrgnBpcstbdpcxlcl.m_orgnlinstgpty;

    iRet = m_cBpbdsndcl.findByPK();
    if (SQL_SUCCESS != iRet) 
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ѯ���ҵ����ܱ���������m_cBpbdsndcl.m_msgid[%s], m_cBpbdsndcl.m_instgdrctpty[%s], [%d][%s]",
		    m_cBpbdsndcl.m_msgid.c_str(), m_cBpbdsndcl.m_instgdrctpty.c_str(), iRet, m_cBpbdsndcl.GetSqlErr());
		
		PMTS_ThrowException(DB_NOT_FOUND);
	}	

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt328::GetOrgnBuss");	
}


static string stringTrim(string inStr, const char*char2trim="\r\n \t")
{
    char2trim = char2trim==NULL?"\r\n \t":char2trim;
    if (inStr.size()<=0)
        return inStr;
    string::size_type pos = inStr.find_first_not_of(char2trim);
    if (pos!=string::npos)
        inStr.erase(0, pos);

    pos = inStr.find_last_not_of(char2trim);
    if (pos!=string::npos)
        inStr.erase(pos+1);
    return inStr;
}


INT32 CRecvCmt328::InsertDb(LPCSTR pchMsg)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt328::InsertDb");	

    m_cBpcstbdpcxlcl.m_workdate = m_cmt328.sConsigndate ; 
    m_cBpcstbdpcxlcl.m_consigdate = m_cmt328.sConsigndate ; 
    m_cBpcstbdpcxlcl.m_msgtp = "CMT328" ; 

    //m_cBpcstbdpcxlcl.m_mesgid = stringTrim(m_cmt328.m_CMTHeaderMap.mesgID); 
    //m_cBpcstbdpcxlcl.m_mesgrefid = stringTrim(m_cmt328.m_CMTHeaderMap.mesgReqNo);
    
    m_cBpcstbdpcxlcl.m_msgid = m_strMsgID ; 
    m_cBpcstbdpcxlcl.m_instgdrctpty = m_cmt328.sOldrecvsapbk ; 
    m_cBpcstbdpcxlcl.m_instgpty = m_cmt328.sOldrecvbank ; 
    m_cBpcstbdpcxlcl.m_instddrctpty = m_cmt328.sOldsendsapbk ; 
    m_cBpcstbdpcxlcl.m_instdpty = m_cmt328.sOldsendbank ; 
    m_cBpcstbdpcxlcl.m_grpcxlid = m_cmt328.sOldpacktype ; 
    m_cBpcstbdpcxlcl.m_orgnlmsgid = m_cOrgnBpcstbdpcxlcl.m_orgnlmsgid ; 
    m_cBpcstbdpcxlcl.m_orgnlinstgpty = m_cmt328.sOldsendbank; 
    m_cBpcstbdpcxlcl.m_orgnmsgtp = m_cOrgnBpcstbdpcxlcl.m_orgnmsgtp;
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBpcstbdpcxlcl.m_orgnmsgtp=%s", m_cBpcstbdpcxlcl.m_orgnmsgtp.c_str());
    
    m_cBpcstbdpcxlcl.m_procstate = "04" ; 
    //m_cBpcstbdpcxlcl.m_statetime = m_cmt328. ; 
    m_cBpcstbdpcxlcl.m_stoppmtsts = m_cmt328.sFlag ;
    
    m_cBpcstbdpcxlcl.m_osqlmsgid = m_cOrgnBpcstbdpcxlcl.m_msgid; 
    m_cBpcstbdpcxlcl.m_osqinstgpty = m_cOrgnBpcstbdpcxlcl.m_instgdrctpty; 
    m_cBpcstbdpcxlcl.m_osqmsgtp = m_cOrgnBpcstbdpcxlcl.m_msgtp; 
    m_cBpcstbdpcxlcl.m_rsflag = "2";
    m_cBpcstbdpcxlcl.m_rspflag = "1";
    
    // ��������
	SETCTX(m_cBpcstbdpcxlcl);

	// �������ݿ�
	int iRet = m_cBpcstbdpcxlcl.insert();
	if (0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "������ʧ��[%d][%s]",iRet, m_cBpcstbdpcxlcl.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "������ʧ��");
	}    

    if(RTN_SUCCESS == strcmp("0", m_cmt328.sOldpacktype))
    {
        m_cBpcstbdpcxllist.m_instgpty = m_cmt328.sOldrecvsapbk ; 
        m_cBpcstbdpcxllist.m_msgid = m_strMsgID ; 
        m_cBpcstbdpcxllist.m_orgnlmsgid = m_cOrgnBpcstbdpcxlcl.m_orgnlmsgid; 
        m_cBpcstbdpcxllist.m_orgnlpmtinfid = m_cmt328.sOldsendmssno ; 
        m_cBpcstbdpcxllist.m_orgnlprtry = m_cmt328.sOldpacktype ; 
        m_cBpcstbdpcxllist.m_orgdbtrbrnchid = m_cmt328.sOldrecvbank; 
        m_cBpcstbdpcxllist.m_orgcdtrbrnchid = m_cmt328.sOldsendbank; 
        //m_cBpcstbdpcxllist.m_rmtinf = m_cmt328.sRemark ; 
		SetGbkToUtf8(m_cmt328.sRemark, m_cBpcstbdpcxllist.m_rmtinf);
        //m_cBpcstbdpcxllist.m_mbmsgid = m_cmt328.sOldconsigndate ; 
        m_cBpcstbdpcxllist.m_rsflag = "2";
        m_cBpcstbdpcxllist.m_orgnlpmtinfid =  m_cOrgnBpcstbdpcxllist.m_orgnlpmtinfid;
        // ��������
    	SETCTX(m_cBpcstbdpcxllist);

    	// �������ݿ�
    	int iRet = m_cBpcstbdpcxllist.insert();
    	if (0 != iRet)
    	{
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "������ʧ��[%d][%s]",iRet, m_cBpcstbdpcxllist.GetSqlErr());
    		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "������ʧ��");
    	}    
    }
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt328::InsertDb");	

    return RTN_SUCCESS;
}



