/********************************************************************
�ļ�����sendccms903.cpp
�����ˣ�hq
��  �ڣ�2011.01.14
��  ��������֤���֪ͨ����<ccms.903.001.02>���˴���
��  ����
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendccms903.h"

using namespace ZFPT;

CSendCcms903::CSendCcms903(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{

}

CSendCcms903::~CSendCcms903()
{

}

INT32 CSendCcms903::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms903::doWorkSelf...");

    int iRet = RTN_FAIL;

    // ��ȡ����
    GetData();

    // �鱨��
    CreateMsg();

    // ���ͱ���
    AddQueue(m_ccms903.m_sXMLBuff.c_str(), m_ccms903.m_sXMLBuff.length());

    // ��������״̬
    UpdateState();

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms903::doWorkSelf..."); 
    return RTN_SUCCESS;
}

INT32 CSendCcms903::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms903::GetData...");

    SETCTX(m_cmbndcert);

    m_cmbndcert.m_msgid = m_szMsgFlagNO; 
    m_cmbndcert.m_instgindrctpty = m_szSndNO;
    m_cmbndcert.m_rsflag = "1";

    int iRet = m_cmbndcert.findByPK();
    if (0 != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "findByPK error[%d][%s]", 
            iRet, m_cmbndcert.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms903::GetData...");
    return iRet;
}

INT32 CSendCcms903::CreateMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms903::CreateMsg...");

    int iSysflg = -1;
    int iRet = -1;
    chgSysCd(m_szSysFlagNO,iSysflg); 
    iRet = GetIsoDateTime(m_dbproc, iSysflg, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }
    //������
    m_ccms903.MsgId          = m_cmbndcert.m_msgid;        //���ı�ʶ��
    m_ccms903.CreDtTm        = m_ISODateTime;              //���ķ���ʱ��
    m_ccms903.InstgDrctPty   = m_cmbndcert.m_instgdrctpty; //����ֱ�Ӳ������
    m_ccms903.GrpHdrInstgPty = m_cmbndcert.m_instgdrctpty; //����������=����ֱ�Ӳ������

    m_ccms903.InstdDrctPty   = m_cmbndcert.m_instddrctpty; //����ֱ�Ӳ������
    m_ccms903.GrpHdrInstdPty = m_cmbndcert.m_instddrctpty; //���ղ������=����ֱ�Ӳ������

    m_ccms903.SysCd          = "CCMS";                     //ϵͳ���
    m_ccms903.Rmk            = m_cmbndcert.m_rmkinf;       //��ע
    m_ccms903.ChgTp          = m_cmbndcert.m_chgtp;        //�������

    // �鱨��ͷ
    m_ccms903.CreateXMlHeader("CCMS", 
                            m_cmbndcert.m_wrkdate.c_str(),
                            m_cmbndcert.m_instgdrctpty.c_str(),
                            m_cmbndcert.m_instddrctpty.c_str(),
                            "ccms.903.001.02",
                            m_sMesgId.c_str());
                            
    // ��ǩ
    AddSign903();

    // �鱨��
    iRet = m_ccms903.CreateXml();
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CreateMsg error,iRet[%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sXMLBuff=[%s]", m_ccms903.m_sXMLBuff.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms903::CreateMsg...");
    return RTN_SUCCESS;
}

void CSendCcms903::AddSign903()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms903::AddSign903...");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_ccms903.getOriSignStr();
	
	AddSign(m_ccms903.m_sSignBuff.c_str(), 
					sSignedStr, 
					DETACHEDSIGN,
					m_cmbndcert.m_instgdrctpty.c_str());
	
	m_ccms903.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms903::AddSign903...");
}

INT32 CSendCcms903::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms903::UpdateState...");

    string strSQL;

    strSQL += "UPDATE CM_BNDDIGCERT t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_08;
    strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
    strSQL += "', t.MESGREFID = '";
    strSQL += m_sMesgId;
    strSQL += "', t.STATETIME = sysdate";

    strSQL += " WHERE t.MSGID = '";
    strSQL += m_szMsgFlagNO;									
    strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());

    int iRet = m_cmbndcert.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����CM_BNDDIGCERT��ʧ��[%d][%s]", 
            iRet, m_cmbndcert.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms903::UpdateState...");
    return RTN_SUCCESS;
}


