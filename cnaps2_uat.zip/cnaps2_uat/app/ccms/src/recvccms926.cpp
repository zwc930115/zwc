/******************************************************************** 
�ļ����� recvccms926.cpp
�����ˣ� hhc
��  �ڣ� 2012-04-27
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2012  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvccms926.h"
CRecvCcms926::CRecvCcms926()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms926::CRecvCcms926()");	
    m_msgtp = "ccms.926.001.01";
}


CRecvCcms926::~CRecvCcms926()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms926::~CRecvCcms926()");		
}

INT32 CRecvCcms926::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms926::Work()");

	//��������
	unPack(sMsg);

    InsertData();    
					  
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms926::work()");

	return RTN_SUCCESS;
}

INT32 CRecvCcms926::unPack(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms926::unPack");	

	int iRet = RTN_FAIL;

	// �����Ƿ�Ϊ��
	if (NULL == sMsg || '\0' == sMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
	}

	// ��������
	iRet = m_cParser926.ParseXml(sMsg);
	if (RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= %d", iRet);	
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
	}

    ZFPTLOG.SetLogInfo("926", m_cParser926.MsgId.c_str());
	
	m_strMsgID	=	m_cParser926.MsgId;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms926::unPack");	

	return RTN_SUCCESS;
}

INT32 CRecvCcms926::InsertCmtxamtlmt()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms926::InsertCmtxamtlmt");
    
    int    iRet = RTN_FAIL;
    string strChngTp = "";
    string strAmt = "";
    string strSql = "";
    
    //����cm_txamtlmt��
    SETCTX(m_cmtxamtlmt);
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;
    int iNum = m_cParser926.GetNodeCountByName("TxAmtUpperLmtInf");
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iNum[%d]", iNum);
    for(int i = 0; i < iNum; i++)
    {
    	 //��ϸ��
        m_cmtxamtlmt.m_syscode = m_cParser926.SysCd;
        m_cmtxamtlmt.m_biztype = m_cParser926.GetValueFromCycle("TxAmtUpperLmtInf", "TxTp", i);
        m_cmtxamtlmt.m_msgtype = m_cParser926.GetValueFromCycle("TxAmtUpperLmtInf", "MT", i);
        m_cmtxamtlmt.m_recvbank = m_cParser926.GetValueFromCycle("TxAmtUpperLmtInf", "RcvBk", i);
        m_cmtxamtlmt.m_sendbank = m_cParser926.GetValueFromCycle("TxAmtUpperLmtInf", "SndrBk", i);
        m_cmtxamtlmt.m_procstate = "35";// 35:����Ч 
        m_cmtxamtlmt.m_chklevel = atoi(m_cParser926.GetValueFromCycle("TxAmtUpperLmtInf", "ChckLvl", i).c_str()); 
        strAmt = m_cParser926.GetValueFromCycle("TxAmtUpperLmtInf", "AmtUpperLmt", i);
        m_cmtxamtlmt.m_amtlmt = atof(strAmt.substr(4).c_str()); 
        
        strChngTp = m_cParser926.GetValueFromCycle("TxAmtUpperLmtInf", "ChngTp", i);
    	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strChngTp[%s]", strChngTp.c_str());
    	if (0 == strncmp(strChngTp.c_str(), "CC00", 4))// ����
    	{
			iRet = m_cmtxamtlmt.insert();
			if(DUPLICATE_KEY == iRet)//������ͻ �����˳�
			{
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, "����cm_cmtxamtlmt��ʧ��, iRet=%d, %s", iRet, m_cmtxamtlmt.GetSqlErr());
			    continue;
	        }
	        else if(OPERACT_SUCCESS != iRet)
			{
				Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����cm_cmtxamtlmt��ʧ��, iRet=%d, %s", iRet,  m_cmtxamtlmt.GetSqlErr());
				PMTS_ThrowException(DB_INSERT_FAIL);     
			}
    	}
    	else 
    	{
	    	if (0 == strncmp(strChngTp.c_str(), "CC01", 4))// ���
	    	{
		    	strSql = "";
		    	strSql += "update cm_txamtlmt set amtlmt = ";
		    	strSql += strAmt.substr(4);
		    	strSql += " where syscode = '";
		    	strSql += m_cmtxamtlmt.m_syscode;
		    	strSql += "' and sendbank = '";
		    	strSql += m_cmtxamtlmt.m_sendbank;
		    	strSql += "' and recvbank = '";
		    	strSql += m_cmtxamtlmt.m_recvbank;
		    	strSql += "' and msgtype = '";
		    	strSql += m_cmtxamtlmt.m_msgtype;
		    	strSql += "' and biztype = '";
		    	strSql += m_cmtxamtlmt.m_biztype;
		    	strSql += "'";
	    	}
	    	else //if (0 == strncmp(strChngTp.c_str(), "CC02", 4))// ����
	    	{
		    	strSql = "";
		    	strSql += "update cm_txamtlmt set procstate = '";
		    	strSql += "36";// ����
		    	strSql += "' where syscode = '";
		    	strSql += m_cmtxamtlmt.m_syscode;
		    	strSql += "' and sendbank = '";
		    	strSql += m_cmtxamtlmt.m_sendbank;
		    	strSql += "' and recvbank = '";
		    	strSql += m_cmtxamtlmt.m_recvbank;
		    	strSql += "' and msgtype = '";
		    	strSql += m_cmtxamtlmt.m_msgtype;
		    	strSql += "' and biztype = '";
		    	strSql += m_cmtxamtlmt.m_biztype;
		    	strSql += "'";
	    	}
		    	
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=[%s]", strSql.c_str());
	
		    iRet = m_cmtxamtlmt.execsql(strSql.c_str());
		    if(OPERACT_SUCCESS != iRet)
		    {
		        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "���±�ʧ��, iRet=%d", iRet);
		        return iRet;            
		    }
    	}
    }        
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCcms926::InsertCmtxamtlmt");
    return RTN_SUCCESS;
}

INT32 CRecvCcms926::InsertCmtamtuplmtlist()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms926::InsertCmtamtuplmtlist");

    int    iRet = RTN_FAIL;
    string strAmt = "";
    
    //����Cm_tamtuplmtlist��
    SETCTX(m_cmtamtuplmtlist); 
    int iNum = m_cParser926.GetNodeCountByName("TxAmtUpperLmtInf");
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iNum[%d]",iNum);
    for(int i = 0; i < iNum; i++)
    {
        //��ϸ��
        m_cmtamtuplmtlist.m_msgid = m_cParser926.MsgId;
        m_cmtamtuplmtlist.m_listid = i;
        m_cmtamtuplmtlist.m_workdate = m_strWorkDate ; 
        m_cmtamtuplmtlist.m_msgtp = m_msgtp;
        m_cmtamtuplmtlist.m_syscd = m_cParser926.SysCd;
        m_cmtamtuplmtlist.m_rmk = m_cParser926.Rmk; 
        m_cmtamtuplmtlist.m_chngtp = m_cParser926.GetValueFromCycle("TxAmtUpperLmtInf", "ChngTp", i);
        m_cmtamtuplmtlist.m_msgtype = m_cParser926.GetValueFromCycle("TxAmtUpperLmtInf", "MT", i);
        m_cmtamtuplmtlist.m_biztype = m_cParser926.GetValueFromCycle("TxAmtUpperLmtInf", "TxTp", i);
        m_cmtamtuplmtlist.m_sendbank = m_cParser926.GetValueFromCycle("TxAmtUpperLmtInf", "SndrBk", i);
        m_cmtamtuplmtlist.m_recvbank= m_cParser926.GetValueFromCycle("TxAmtUpperLmtInf", "RcvBk", i);
        m_cmtamtuplmtlist.m_chklevel = atoi(m_cParser926.GetValueFromCycle("TxAmtUpperLmtInf", "ChckLvl", i).c_str()); 
        strAmt = m_cParser926.GetValueFromCycle("TxAmtUpperLmtInf", "AmtUpperLmt", i);
        m_cmtamtuplmtlist.m_amtlmt = atof(strAmt.substr(4).c_str()); 
        m_cmtamtuplmtlist.m_procstate = "35";
        
        iRet = m_cmtamtuplmtlist.insert();
        if(DUPLICATE_KEY == iRet)//������ͻ �����˳�
		{
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "����cm_tamtuplmtlist��ʧ��, iRet=%d, %s", iRet, m_cmtamtuplmtlist.GetSqlErr());
		    continue;
        }
        else if(OPERACT_SUCCESS != iRet)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����cm_tamtuplmtlist��ʧ��, iRet=%d, %s", iRet, m_cmtamtuplmtlist.GetSqlErr());
            PMTS_ThrowException(DB_INSERT_FAIL);  
        }
    }   
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCcms926::InsertCmtamtuplmtlist");
    
    return RTN_SUCCESS;
}

INT32 CRecvCcms926::InsertData(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms926::InsertData");

	InsertCmtxamtlmt();
	
    InsertCmtamtuplmtlist();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms926::InsertData");
	
	return RTN_SUCCESS;
}

