/********************************************************************
�ļ�����sendcmt519.cpp
�����ˣ�aps-lel	
��  �ڣ�2011.04.20
��  ����С��ҵ��״̬��ѯ����
��  ����
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt519.h"

extern CConnectPool *g_DBConnPool;

using namespace ZFPT;

CSendCmt519::CSendCmt519(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{

}

CSendCmt519::~CSendCmt519()
{

}

void CSendCmt519::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt519::SetDBKey...");
    
	m_Cmtransstqry.m_msgid = m_szMsgFlagNO; //���ı�ʶ��
	m_Cmtransstqry.m_instgindrctpty = m_szSndNO; //ԭ����������=����������
    m_Cmtransstqry.m_sysid = m_szSysFlagNO;//ϵͳ��ʶ��
  
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgFlagNO = %s", m_szMsgFlagNO);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndNO = %s", m_szSndNO);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSysFlagNO = %s", m_szSysFlagNO);
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt519::SetDBKey...");
    return;
}

void CSendCmt519::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt519::SetData...");
    char sTm[7] = {0}; 
	char szQueryno[8+1] = {0};
    
	bool bRet = GetMsgIdValue(m_dbproc,szQueryno,eInfoId,SYS_BEPS);//ȡ��ѯ���
    if(true != bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "GetMsgIdValue failed");
        PMTS_ThrowException(OPT_GET_MSGID_FAIL);
    }

	 //ί������
	strncpy(m_cmt519.sConsigndate,m_Cmtransstqry.m_consigndate.c_str(),sizeof(m_cmt519.sConsigndate)-1);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cmt519.sConsigndate[%s]",m_cmt519.sConsigndate);

	//��ѯ���к�
	strncpy(m_cmt519.sQuerybank,m_Cmtransstqry.m_instgdrctpty.c_str(),sizeof(m_cmt519.sQuerybank)-1);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cmt519.sQuerybank[%s]",m_cmt519.sQuerybank);

	//��ѯ��� 
	m_cmt519.iQueryno     = atoi(szQueryno);
	 
    //ԭ�����ͺ�
	strncpy(m_cmt519.sOldpacktype,m_Cmtransstqry.m_orimsgtp.c_str(),sizeof(m_cmt519.sOldpacktype)-1);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cmt519.sOldpacktype[%s]",m_cmt519.sOldpacktype);

	//ԭ��ί������
	strncpy(m_cmt519.sOldpackdate,m_Cmtransstqry.m_rptmsgid.substr(0,8).c_str(),sizeof(m_cmt519.sOldpackdate)-1);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cmt519.sOldpackdate[%s]",m_cmt519.sOldpackdate);

	//ԭ�����
	strncpy(m_cmt519.sOldpackno,m_Cmtransstqry.m_rptmsgid.substr(8).c_str(),sizeof(m_cmt519.sOldpackno)-1);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cmt519.sOldpackno[%s]",m_cmt519.sOldpackno);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt519::SetData...");
    return;
}

int CSendCmt519::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt519::GetData...");

    SetDBKey();

    SETCTX(m_Cmtransstqry);
    
    int iRet = m_Cmtransstqry.findByPK();
    
  	if (SQLNOTFOUND == iRet)
	{
		sprintf(m_sErrMsg, "�Ҳ���ָ��ҵ��[%s], [%s], [%d][%s]", 
		    m_szSndNO, m_szMsgFlagNO, iRet, m_Cmtransstqry.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	} 	
	else if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg, "��ѯ���ܱ���������[%s], [%s], [%d][%s]",
		    m_szSndNO, m_szMsgFlagNO, iRet, m_Cmtransstqry.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt519::GetData...");
    
    return iRet;
}

int CSendCmt519::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt519::UpdateState...");
	
    SetDBKey();
	
    string strSQL;
	strSQL += "UPDATE CM_TRANSSTQRY t SET t.PROCSTATE = '";
	strSQL += PR_HVBP_08;// �ѷ���
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
    strSQL += "', t.STATETIME = sysdate ";
    
	strSQL += " WHERE t.SYSID = '";
	strSQL += m_Cmtransstqry.m_sysid.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_Cmtransstqry.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Cmtransstqry.m_instgindrctpty.c_str(); 									
	strSQL += "'";
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL = %s", strSQL.c_str());
	
    int iRet= m_Cmtransstqry.execsql(strSQL.c_str());
 
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��iRet=[%d], [%s]", iRet, m_Cmtransstqry.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
        
    }
     
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt519::UpdateState...");
    return OPERACT_SUCCESS;
}

int CSendCmt519::doWorkSelf()
{
   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt519::doWork...");

	int iRet = RTN_FAIL;

    
    GetData();
    
    SetData();
    	
    iRet =  m_cmt519.CreateCmt("519", 
                                m_szSndNO, 
                                m_Cmtransstqry.m_instddrctpty.c_str(),
                                m_sMesgId.c_str(), 
                                m_sMesgId.c_str(), 
                                m_Cmtransstqry.m_wrkdate.c_str(), 
                                "");
	
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }

    AddQueue( m_cmt519.m_strCmtmsg, m_cmt519.m_strCmtmsg.length());

    UpdateState();
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt519::doWork..."); 
    
    return OPERACT_SUCCESS;
}


