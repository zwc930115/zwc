/********************************************************************
�ļ�����sendccms310.cpp
�����ˣ�aps-lel
��  �ڣ�2011.03.31
��  ����
��  ����
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendccms310.h"


CSendCcms310::CSendCcms310(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{

}

CSendCcms310::~CSendCcms310()
{

}

void CSendCcms310::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms310::SetDBKey...");
    
    m_Cmcnotsgninfbiz.m_instgpty = m_szSndNO;         //����������
    m_Cmcnotsgninfbiz.m_msgid    = m_szMsgFlagNO;     //ϵͳ��ʶ�� 
    m_Cmcnotsgninfbiz.m_srcflag  = m_szSrcflg;
   	m_Cmcnotsgninfbiz.m_syscd    = m_szSysFlagNO;     //ϵͳID  
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndNO = [%s]", m_szSndNO);
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgFlagNO = [%s]", m_szMsgFlagNO);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Cmcnotsgninfbiz.m_srcflag  = [%s]", m_Cmcnotsgninfbiz.m_srcflag.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms310::SetDBKey...");
    return;
}

void CSendCcms310::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms310::SetData..."); 	
	
	//ȡ���ķ���ʱ��
	int iSysflg = -1;
    int iRet = -1;
    chgSysCd(m_szSysFlagNO,iSysflg); 
    iRet = GetIsoDateTime(m_dbproc, iSysflg, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_ISODateTime = %s", m_ISODateTime);
	char szchmtlen[8+1] = {0}; 
	char szSyscd[4+1] = {0};
    strcpy(szSyscd,m_Cmcnotsgninfbiz.m_syscd.c_str());
    StrUpperCase_ZFPT(szSyscd);

    // ���ļ�ͷ
    m_ccms310.CreateXMlHeader(szSyscd,                        \
                                m_Cmcnotsgninfbiz.m_workdate.c_str(), \
                                m_Cmcnotsgninfbiz.m_instgdrctpty.c_str(),\
                                m_Cmcnotsgninfbiz.m_instddrctpty.c_str(),\
                                "ccms.310.001.01",              \
                               m_sMesgId.c_str()); 
  
	m_ccms310.InstgDrctPty                  = m_Cmcnotsgninfbiz.m_instgdrctpty; //����ֱ�Ӳ������
	m_ccms310.GrpHdrInstgPty                = m_Cmcnotsgninfbiz.m_instgpty;     //����������
	m_ccms310.InstdDrctPty                  = m_Cmcnotsgninfbiz.m_instddrctpty; //����ֱ�Ӳ������
	m_ccms310.GrpHdrInstdPty                = m_Cmcnotsgninfbiz.m_instdpty;     //���ղ������
    
	m_ccms310.MsgId                         = m_Cmcnotsgninfbiz.m_msgid;        //���ı�ʶ��    
	m_ccms310.CreDtTm                       = m_ISODateTime;                    //���ķ���ʱ��
	
	m_ccms310.SysCd                         = m_Cmcnotsgninfbiz.m_syscd;	  	//ϵͳ���
	m_ccms310.Rmk                           = m_Cmcnotsgninfbiz.m_rmk;		    //��ע
	m_ccms310.TxTpCd                        = m_Cmcnotsgninfbiz.m_txtpcd;		//ҵ�����ͱ���
	m_ccms310.Titl                          = m_Cmcnotsgninfbiz.m_titl;			//��Ϣ����
	m_ccms310.CmonNotSgntrInfBizInfCntt     = m_Cmcnotsgninfbiz.m_cntt;			//��Ϣ����
	m_ccms310.AttchmtLen                    = itoa(szchmtlen,m_Cmcnotsgninfbiz.m_attchmtlen);	//��������
	m_ccms310.AttchmtNm                     = m_Cmcnotsgninfbiz.m_attchmtnm;	//��������
	m_ccms310.AttchmtCnttCntt               = m_Cmcnotsgninfbiz.m_attchmtcntt;	//��������
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms310::SetData...");
	m_Cmcnotsgninfbiz.closeCursor();
    return;
}

int CSendCcms310::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms310::GetData...");
	
	SETCTX(m_Cmcnotsgninfbiz);
	    
    SetDBKey();
    /*
    char strSql[1024]={0};
    sprintf(strSql ,"INSTGPTY='%s' and MSGID='%s' and srcflag='%s' "
                    ,m_Cmcnotsgninfbiz.m_instgpty.c_str()
                    ,m_Cmcnotsgninfbiz.m_msgid.c_str()
                    ,m_Cmcnotsgninfbiz.m_srcflag.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=[%s]",strSql);
	int iRet = m_Cmcnotsgninfbiz.find(strSql);
	if(0 != iRet)
	{
		sprintf( m_sErrMsg,"find error,error code =[%d] error cause = [%s]",iRet,m_Cmcnotsgninfbiz.GetSqlErr());
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_sErrMsg);
		PMTS_ThrowException(__FILE__,__LINE__,DB_NOT_FOUND,m_sErrMsg);
	}
	iRet = m_Cmcnotsgninfbiz.fetch();
	if(iRet ==SQLNOTFOUND)
	{
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������");
        m_Cmcnotsgninfbiz.closeCursor();
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "m_Cmcnotsgninfbizû���ҵ�����������ԭҵ��");
	}
	*/
	
	m_isFromBank = false;
	
	int iRet = m_Cmcnotsgninfbiz.findByPK();
	if(RTN_SUCCESS != iRet)
	{
	    m_isFromBank = true;
	    m_szSrcflg[0] = '0';
	    m_Cmcnotsgninfbiz.m_srcflag = m_szSrcflg;
	    iRet = m_Cmcnotsgninfbiz.findByPK();
    	if(0 != iRet)
    	{
    		sprintf( m_sErrMsg,"findByPK() error,error code =[%d] error cause = [%s]",iRet,m_Cmcnotsgninfbiz.GetSqlErr());
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_sErrMsg);
    		PMTS_ThrowException(__FILE__,__LINE__,DB_NOT_FOUND,m_sErrMsg);
        }
	}
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms310::GetData...");
	
    return iRet;
}

int CSendCcms310::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms310::UpdateState...");
	
	SETCTX(m_Cmcnotsgninfbiz);
	
    SetDBKey();
	
    string strSQL;
	
	strSQL = "UPDATE cm_cnotsgninfbiz  t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_08;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
    strSQL += "' , t.PROCTIME = sysdate ";   
	strSQL += " WHERE t.MSGID = '";
	strSQL += m_Cmcnotsgninfbiz.m_msgid.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_Cmcnotsgninfbiz.m_instgpty.c_str(); 									
	strSQL += "' AND t.SRCFLAG = '";
	strSQL += m_szSrcflg;
	strSQL += "' ";
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	
	int iRet = m_Cmcnotsgninfbiz.execsql(strSQL.c_str());
	
    if(RTN_SUCCESS != iRet)
    {	  
	   sprintf( m_sErrMsg,"execsql() error,error code =[%d] error cause = [%s]",iRet,m_Cmcnotsgninfbiz.GetSqlErr());
	   Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_sErrMsg);
	   PMTS_ThrowException(__FILE__,__LINE__,DB_UPDATE_FAIL,m_sErrMsg);

    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms310::UpdateState...");
	
    return RTN_SUCCESS;
}

int CSendCcms310::doWorkSelf()
{
   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms310::doWork...");

    int iRet = 0;

    GetData();

    SetData();
	
    iRet = m_ccms310.CreateXml();
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
  
    AddQueue( m_ccms310.m_sXMLBuff.c_str(), m_ccms310.m_sXMLBuff.length());

    UpdateState();
    
    if(m_isFromBank)
    {
        m_szSrcflg[0] = '1';
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms310::doWork..."); 
    return RTN_SUCCESS;
}



