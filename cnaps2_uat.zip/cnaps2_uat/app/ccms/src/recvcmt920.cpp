/******************************************************************** 
�ļ����� recvcmt920.cpp
�����ˣ� hdf
��  �ڣ� 2011-05-18
�޸��ˣ� 
��  �ڣ� 
��  ���� ������˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvcmt920.h"
#include "bpbcoutsendlist.h"
#include "cmcnotsgninfbiz.h"
#include "syscbbabankcode.h"
#include "bpcfcaqry.h"
#include "bepsErrFormater.hpp"

using namespace ZFPT;

CRecvCmt920::CRecvCmt920()
{
    m_strMsgTp = "CMT920";
}

CRecvCmt920::~CRecvCmt920()
{

}


INT32 CRecvCmt920::Work(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt920::doWork()");

    // ��������
    unPack(pchMsg);
   
    // ����ԭҵ��
    UpdateState();	
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt920::doWork()");

    return RTN_SUCCESS;
}



INT32 CRecvCmt920::unPack(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt920::unPack()");
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "receive msg = [%s]",pchMsg);
    // 1�������Ƿ�Ϊ��
    if (NULL == pchMsg || '\0' == pchMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_strBizCode.c_str(), "����Ϊ��");
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }
    
    int iRet = RTN_FAIL;
    
    // 3����������
    iRet = m_cCmt920.ParseCmt(pchMsg);

    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CRecvCmt920::Work(): ��������ʧ��");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������!");
    }

    m_strTemp = m_strTemp + m_cCmt920.sOrgConsigndate + m_cCmt920.sOrgpkgserno;
    
    ZFPTLOG.SetLogInfo("920", m_strTemp.c_str());
   
    // ��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
  
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");
        PMTS_ThrowException(OPT_GET_DATE_FAIL);
    }
    m_strWorkDate   =   m_sWorkDate;
     
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt920::unPack()");	
    
    return RTN_SUCCESS;
}

void CRecvCmt920::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt920::UpdateState()");

    int iNo = atoi(m_cCmt920.sOrgpkgno);
    switch(iNo)
    {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 11:
        {
            UpdateBcoutState(iNo);
            break;
        }
        case 2:
        case 4:
        case 6:
        case 9:
        {
            UpdateBdState(iNo);
            break;
        }
        case 12:
        {
            UpdateState012();
            break;
        }
        case 13:
        {
            UpdateState013();
            break;
        }
        default:
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "δ�ҵ���Ӧ���ĺ�[%d]", iNo);
            break;
        }
    }
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCmt920::UpdateState()");
    return ;
}

void CRecvCmt920::UpdateBcoutState(int iNo)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt920::UpdateBcoutState()");

    string strSQL;
    
    SETCTX(m_entitybase);

    char sProcstate[3] = {0};
    TransProcStates(m_cCmt920.sProstate, sProcstate);
    string strBizState = "";
    To2NdBizState(m_cCmt920.sProstate, strBizState);
    //__wsh 2012-07-25 ��������ͳһתΪISODATE��ʽ�洢
    char szIsoDt[32] = {0};
    char szFsdt[32] = {0};
    string strNetNo = "";
    chgToISODate(m_cCmt920.sConsigndate, szFsdt);
    if(strlen(m_cCmt920.sNtdate)>=8){
        chgToISODate(m_cCmt920.sNtdate, szIsoDt);
        strNetNo = m_cCmt920.sNtno;
    }
    else if(iNo != 3){
        chgToISODate(m_cCmt920.sConsigndate, szIsoDt);
        strNetNo = "0";
    }
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
        "__��������[%s], �����[%s]", szIsoDt, m_cCmt920.sNtno);

	strSQL = strSQL + "UPDATE BP_BCOUTSNDCL t SET t.PROCSTATE = '" + sProcstate + "'";
	strSQL += ", t.netgdt='";
	strSQL += szIsoDt;
	strSQL += "', t.netgrnd='";
	strSQL += strNetNo;
	strSQL += "', t.finalstatedate='";
	strSQL += szFsdt;
	strSQL += "', t.busistate='";
	strSQL += strBizState;
    strSQL += "', t.STATETIME = sysdate";

    // ������Ϣ��ʽ��
    if(strcmp(CBpErrFmt::parse(m_cCmt920.sProcode).c_str(),"02")==0 || strcmp(CBpErrFmt::parse(m_cCmt920.sProcode).c_str(),"03")==0)
    {
    	strSQL += ", t.RJCTINF = ' ' ";
    }
    else
    {
    	strSQL += ", t.RJCTINF = '" + CBpErrFmt::parse(m_cCmt920.sProcode) + "' ";
	}
    strSQL += " WHERE t.MSGID = '";
	strSQL += m_strTemp.c_str();
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_cCmt920.sOrgIsdficode;
	//strSQL += "' AND t.PROCSTATE <= '" ;
	//strSQL += sProcstate;
	strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    int iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
            iRet, m_entitybase.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    strSQL = "";
	strSQL = strSQL + "UPDATE BP_BCOUTSENDLIST t SET t.PROCSTATE = '" + sProcstate + "'";
	strSQL += ", t.netgdt='";
	strSQL += szIsoDt;
	strSQL += "', t.netgrnd='";
	strSQL += strNetNo;
    strSQL += "', t.STATETIME = sysdate";

    // ������Ϣ��ʽ��
    strSQL += ", t.RJCTINF = '" + CBpErrFmt::parse(m_cCmt920.sProcode) + "' ";

    strSQL += " WHERE t.MSGID = '";
	strSQL += m_strTemp.c_str();
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_cCmt920.sOrgIsdficode;
	//strSQL += "' AND t.PROCSTATE <= '";
	//strSQL += sProcstate;
	strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet && 1403 != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
            iRet, m_entitybase.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sProcstate[%s],iNo[%d]", sProcstate, iNo);
    
    if(string(sProcstate) == PR_HVBP_15
        && (iNo == 8 || iNo == 10 || iNo == 11) )
    {
        string setitem = " procstate = '07',busistate = '";
        setitem += PROCESS_PR05;
        setitem += "'";
        PubOriSql("BP_BDRCVCL", "BP_BCOUTSENDLIST", setitem.c_str(), "k.ORGNLMSGID||k.ORIINSTGDRCTPTY");
        PubOriSql("BP_BDRECVLIST", "BP_BCOUTSENDLIST", setitem.c_str(), "k.ORGNLMSGID||k.ORIINSTGDRCTPTY");
    }

    if(strncmp(sProcstate,PR_HVBP_16,2) == 0)//���ҵ�������Ŷӣ���֪ͨ�ͻ�
    {
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ҵ�������Ŷӣ�֪ͨ�ͻ�");
		string sTempPkgNo = "";
		sTempPkgNo += "PKG";
		sTempPkgNo += m_cCmt920.sOrgpkgno;
		
	}

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCmt920::UpdateBcoutState()");
}

void CRecvCmt920::UpdateBdState(int iNo)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt920::UpdateBdState()");

    string strSQL;
    
    SETCTX(m_entitybase);
    
    char szIsoDt[32] = {0};
    char szFsdt[32] = {0};
    string strNetNo = "";
    chgToISODate(m_cCmt920.sConsigndate, szFsdt);
    if(strlen(m_cCmt920.sNtdate)>=8 && iNo == 9){
        chgToISODate(m_cCmt920.sNtdate, szIsoDt);
        strNetNo = m_cCmt920.sNtno;
    }
    else if(iNo == 9){
        chgToISODate(m_cCmt920.sConsigndate, szIsoDt);
        strNetNo = "0";
    }

    char sProcstate[3] = {0};
    TransProcStates(m_cCmt920.sProstate, sProcstate);
    
    string strBizState = "";
    To2NdBizState(m_cCmt920.sProstate, strBizState);
    
    if(0 == strcmp(m_cCmt920.sRcvnoteno,m_cCmt920.sOrgIsdficode))
    {
            //PKG002/PKG006/PKG004
            int iOrgPkgNo = atoi(m_cCmt920.sOrgpkgno);
            if ( (iOrgPkgNo==2||iOrgPkgNo==4||iOrgPkgNo==6) && string(sProcstate) == PR_HVBP_02)
            {
                // ��Ǳ���NPCת����Ӧ�ñ�ɴ���ִ.
                sprintf(sProcstate, PR_HVBP_06);
            }
            
        	strSQL = strSQL + "UPDATE BP_BDSNDCL t SET t.PROCSTATE = '" + sProcstate + "'";
            strSQL += ", t.STATETIME = sysdate";
            strSQL += ", t.netgdt = '";
            strSQL += szIsoDt;
            strSQL += "', t.netgrnd = '";
            strSQL += strNetNo;
            strSQL += "', t.finalstatedate='";
            strSQL += szFsdt;
            strSQL += "', t.busistate='";
            strSQL += strBizState;
            
            // ������Ϣ��ʽ��
            strSQL += "', t.RJCTINF = '" + CBpErrFmt::parse(m_cCmt920.sProcode) + "' ";
        
            strSQL += " WHERE t.MSGID = '";
        	strSQL += m_strTemp.c_str();
        	strSQL += "' AND t.INSTGDRCTPTY = '";
        	strSQL += m_cCmt920.sOrgIsdficode;	
        	//strSQL += "' AND t.PROCSTATE <= '";
        	//strSQL += sProcstate;
        	strSQL += "'";
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
            
            int iRet = m_entitybase.execsql(strSQL.c_str());
            if(RTN_SUCCESS != iRet)
            {
                Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
                    iRet, m_entitybase.GetSqlErr());
                PMTS_ThrowException(DB_UPDATE_FAIL);
            }
        
            strSQL = "";
        	strSQL = strSQL + "UPDATE BP_BDSENDLIST t SET t.PROCSTATE = '" + sProcstate + "'";
            strSQL += ", t.STATETIME = sysdate";
        
            // ������Ϣ��ʽ��
            strSQL += ", t.RJCTINF = '" + CBpErrFmt::parse(m_cCmt920.sProcode) + "' ";
        
            strSQL += " WHERE t.MSGID = '";
        	strSQL += m_strTemp.c_str();
        	strSQL += "' AND t.INSTGDRCTPTY = '";
        	strSQL += m_cCmt920.sOrgIsdficode;
        	//strSQL += "' AND t.PROCSTATE <= '";
        	//strSQL += sProcstate;
        	strSQL += "'";
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
            
            iRet = m_entitybase.execsql(strSQL.c_str());
            if(RTN_SUCCESS != iRet)
            {
                Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
                    iRet, m_entitybase.GetSqlErr());
                PMTS_ThrowException(DB_UPDATE_FAIL);
            }
            
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sProcstate[%s],iNo[%d]", sProcstate, iNo);
            if(string(sProcstate) == PR_HVBP_15
                 && iNo == 9)
            {
                string setitem = " procstate = '07',busistate = '";
                setitem += PROCESS_PR05;
                setitem += "'";
                PubOriSql("BP_BCOUTRECVLIST", "BP_BDSENDLIST", setitem.c_str(), "k.ORGNLMSGID||k.ORIINSTGDRCTPTY");
                PubOriSql("BP_BCOUTRCVCL", "BP_BDSENDLIST", setitem.c_str(), "k.ORGNLMSGID||k.ORIINSTGDRCTPTY");
            }        
        
    }
    else
    {
        	strSQL = strSQL + "UPDATE BP_BDRCVCL t SET t.PROCSTATE = '" + sProcstate + "'";
            strSQL += ", t.STATETIME = sysdate";
            strSQL += ", t.netgdt = '";
            strSQL += szIsoDt;
            strSQL += "', t.netgrnd = '";
            strSQL += strNetNo;
            strSQL += "', t.finalstatedate='";
            strSQL += szFsdt;
            strSQL += "', t.busistate='";
            strSQL += strBizState;
            
            // ������Ϣ��ʽ��
            strSQL += "', t.RJCTINF = '" + CBpErrFmt::parse(m_cCmt920.sProcode) + "' ";
        
            strSQL += " WHERE t.MSGID = '";
        	strSQL += m_strTemp.c_str();
        	strSQL += "' AND t.INSTGDRCTPTY = '";
        	strSQL += m_cCmt920.sOrgIsdficode;	
        	//strSQL += "' AND t.PROCSTATE <= '";
        	//strSQL += sProcstate;
        	strSQL += "'";
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
            
            int iRet = m_entitybase.execsql(strSQL.c_str());
            if(RTN_SUCCESS != iRet)
            {
                Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
                    iRet, m_entitybase.GetSqlErr());
                PMTS_ThrowException(DB_UPDATE_FAIL);
            }
        
            strSQL = "";
        	strSQL = strSQL + "UPDATE BP_BDRECVLIST t SET t.PROCSTATE = '" + sProcstate + "'";
            strSQL += ", t.STATETIME = sysdate";
        
            // ������Ϣ��ʽ��
            strSQL += ", t.RJCTINF = '" + CBpErrFmt::parse(m_cCmt920.sProcode) + "' ";
        
            strSQL += " WHERE t.MSGID = '";
        	strSQL += m_strTemp.c_str();
        	strSQL += "' AND t.INSTGDRCTPTY = '";
        	strSQL += m_cCmt920.sOrgIsdficode;
        	//strSQL += "' AND t.PROCSTATE <= '";
        	//strSQL += sProcstate;
        	strSQL += "'";
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
            
            iRet = m_entitybase.execsql(strSQL.c_str());
            if(RTN_SUCCESS != iRet)
            {
                Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
                    iRet, m_entitybase.GetSqlErr());
                PMTS_ThrowException(DB_UPDATE_FAIL);
            }
            
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sProcstate[%s],iNo[%d]", sProcstate, iNo);
            
    }


    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCmt920::UpdateBdState()");
}


void CRecvCmt920::UpdateState012()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt920::UpdateState012()");

    string strSQL;
    
    SETCTX(m_entitybase);

    char sProcstate[3] = {0};
    TransProcStates(m_cCmt920.sProstate, sProcstate);

    //��Ϊ012��ͬҵ�����ͷŲ�ͬ��������ʱ����ҵ�����ͣ���������ȫ�����£���������
	strSQL = strSQL + "UPDATE BP_COLLTNCHRGSCL t SET t.PROCSTATE = '" + sProcstate + "'";
    strSQL += ", t.STATETIME = sysdate";

    // ������Ϣ��ʽ��
    strSQL += ", t.RJCTINF = '" + CBpErrFmt::parse(m_cCmt920.sProcode) + "' ";

    strSQL += " WHERE t.MSGID = '";
	strSQL += m_strTemp.c_str();
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_cCmt920.sOrgIsdficode;
	//strSQL += "' AND t.PROCSTATE <= '";
	//strSQL += sProcstate;
	strSQL += "'";
	

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    int iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
            iRet, m_entitybase.GetSqlErr());
        //PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    strSQL = "";
	strSQL = strSQL + "UPDATE BP_COLLTNCHRGSLIST t SET t.PROCSTATE = '" + sProcstate + "'";
    strSQL += ", t.STATETIME = sysdate";

    // ������Ϣ��ʽ��
    strSQL += ", t.RJCTINF = '" + CBpErrFmt::parse(m_cCmt920.sProcode) + "' ";

    strSQL += " WHERE t.MSGID = '";
	strSQL += m_strTemp.c_str();
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_cCmt920.sOrgIsdficode;	
	//strSQL += "' AND t.PROCSTATE <= '";
	//strSQL += sProcstate;
	strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
            iRet, m_entitybase.GetSqlErr());
        //PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    strSQL = "";
    strSQL = "UPDATE CM_CNOTSGNINFBIZ t SET t.PROCTIME = sysdate, t.PROCSTATE = '";   
    strSQL = strSQL + sProcstate + "',t.RJCTCD = '";
    strSQL += m_cCmt920.sProcode;
    // ������Ϣ��ʽ��
    strSQL += "', t.RJCTINF = '" + CBpErrFmt::parse(m_cCmt920.sProcode) + "' ";

    strSQL += " WHERE t.MSGID = '";
	strSQL += m_strTemp.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_cCmt920.sOrgIsdficode;
    strSQL += "' ";
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_entitybase.execsql failed:[%d][%s]",iRet,m_entitybase.GetSqlErr());
        //PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "m_entitybase.execsql failed!");
    }    
	// modify 2012-7-9
    CBpcfcaqry m_CBpcfcaqry;
    SETCTX(m_CBpcfcaqry);
    strSQL = "";
    strSQL = "UPDATE BP_CFCAQRY t SET t.STATETIME = sysdate, t.PROCSTATE = '";   
    strSQL = strSQL + sProcstate + "' ";
    
    // ������Ϣ��ʽ��
    strSQL += ", t.RJCTINF = '" + CBpErrFmt::parse(m_cCmt920.sProcode) + "' ";

    strSQL += " WHERE t.MSGID = '";
	strSQL += m_strTemp.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_cCmt920.sOrgIsdficode;
    strSQL += "' ";
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    iRet = m_CBpcfcaqry.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_entitybase.execsql failed:[%d][%s]",iRet,m_entitybase.GetSqlErr());
        //PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "m_entitybase.execsql failed!");
    }    
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCmt920::UpdateState012()");
}
void CRecvCmt920::UpdateState013()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt920::UpdateState012()");

    string strSQL;
    
    SETCTX(m_entitybase);

    char sProcstate[3] = {0};
    TransProcStates(m_cCmt920.sProstate, sProcstate);

    strSQL = "";
    strSQL = "UPDATE BP_CHCKCDTFORLD t SET t.PROCTIME = sysdate, t.PROCSTATE = '";   
    strSQL = strSQL + sProcstate + "' ";
    
    // ������Ϣ��ʽ��
    strSQL += ", t.RJCTINF = '" + CBpErrFmt::parse(m_cCmt920.sProcode) + "' ";

    strSQL += " WHERE t.MSGID = '";
	strSQL += m_strTemp.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_cCmt920.sOrgIsdficode;
    strSQL += "' ";
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    int iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_entitybase.execsql failed:[%d][%s]",iRet,m_entitybase.GetSqlErr());
        //PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "m_entitybase.execsql failed!");
    } 
       
	strSQL = "";
    strSQL = "UPDATE BP_REALTMCSTACCTMG t SET t.PROCTIME = sysdate, t.PROCSTATE = '";   
    strSQL = strSQL + sProcstate + "' ";
    
    // ������Ϣ��ʽ��
    strSQL += ", t.RJCTINF = '" + CBpErrFmt::parse(m_cCmt920.sProcode) + "' ";

    strSQL += " WHERE t.MSGID = '";
	strSQL += m_strTemp.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_cCmt920.sOrgIsdficode;
    strSQL += "' ";
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_entitybase.execsql failed:[%d][%s]",iRet,m_entitybase.GetSqlErr());
        //PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "m_entitybase.execsql failed!");
    }    
	//
	strSQL = "";
    strSQL = "UPDATE BP_CFCAQRY t SET t.STATETIME = sysdate, t.PROCSTATE = '";  
    strSQL = strSQL + sProcstate + "' ";
    
    // ������Ϣ��ʽ��
    strSQL += ", t.RJCTINF = '" + CBpErrFmt::parse(m_cCmt920.sProcode) + "' ";

    strSQL += " WHERE t.MSGID = '";
	strSQL += m_strTemp.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_cCmt920.sOrgIsdficode;
    strSQL += "' ";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=[%s]",strSQL.c_str());
    iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
            iRet, m_entitybase.GetSqlErr());
        //PMTS_ThrowException(DB_UPDATE_FAIL);
    }
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCmt920::UpdateState012()");
}
/******************************************************************************
*  Function:   InsertComsendmb
*  Description:������ͨѶ��
*  Input:      ��
*  Output:     
*  Return:     0   : �����ɹ�,
               ����: ����ʧ��
*  Others:     ��
*  Author:     hhc
*  Date:       2012-04-19
*******************************************************************************/
void CRecvCmt920::InsertComsendmb(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt920::InsertComsendmb()");
	
	int    iRet = RTN_FAIL;
	string strRval = "";
    
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt920.sOrgpkgno[%s]", m_cCmt920.sOrgpkgno);
	
    if( 0 == strcmp("001", m_cCmt920.sOrgpkgno) || 0 == strcmp("005", m_cCmt920.sOrgpkgno)
     || 0 == strcmp("007", m_cCmt920.sOrgpkgno) )
	{
		CBpbcoutsendlist cBpbcoutsendlist;
		
		string strSql = "";
		strSql = " MSGID = '";
		strSql += m_strTemp;
		strSql += "' and INSTGDRCTPTY = '";
		strSql += m_cCmt920.sOrgIsdficode;
		strSql += "'";
		
		Trace(L_DEBUG,  __FILE__,	__LINE__, NULL, "__strSql=[%s]", strSql.c_str());
		

		SETCTX(cBpbcoutsendlist);
			
		iRet = cBpbcoutsendlist.find(strSql);
		
		if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "cBpbcoutsendlist find fail:  [%d][%s]", 
				iRet, cBpbcoutsendlist.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		while(0 == cBpbcoutsendlist.fetch())
		{
			iRet = GetTagVal(strRval, cBpbcoutsendlist.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, "txid[%s]", cBpbcoutsendlist.m_txid.c_str());
				m_strMsgID = cBpbcoutsendlist.m_txid;
				//m_strReserve = cBpbcoutsendlist.m_reserve; //�����ڷ�920ʱ�����ڻ�ȡԭ��������
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cBpbcoutsendlist.m_mbmsgid.c_str(), 22);
        			}
			else if(-2 == iRet)
			{
				Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "ԭҵ�����ڷ���ϵͳ��Ϊ��,����ת��������");
				break;
			}
		}
		
		cBpbcoutsendlist.closeCursor();
	}
	else
	{
		int    iRet    = OPERACT_FAILED;
		string strRsflag = "";// �����˱�ʶ
		string strRval = "";
		string strWhere = "";
		
		CSyscbbabankcode cSyscbbabankcode;
		
		strWhere += "bankcode = '";
		strWhere += m_strTemp;
		strWhere += "'";
	
		SETCTX(cSyscbbabankcode);
	
		iRet = cSyscbbabankcode.find(strWhere);
		if (SQL_SUCCESS != iRet) 
	    {
	        sprintf(m_szErrMsg, "cSyscbbabankcode.find():��ѯsys_cbbabankcode��¼��, [%d][%s]",
	        		iRet, cSyscbbabankcode.GetSqlErr()); 
			
	        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
	        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
	    }
		
		while(SQL_SUCCESS == iRet)
		{
			iRet = cSyscbbabankcode.fetch();	
			if (SQLNOTFOUND == iRet) 
			{
				strRsflag = "2";// ��������
				cSyscbbabankcode.closeCursor();
				break;
			}
			else if (SQL_SUCCESS != iRet) 
			{
				sprintf(m_szErrMsg, "cSyscbbabankcode.fetch():��ȡsys_cbbabankcode��¼��, [%d][%s]",
						iRet, cSyscbbabankcode.GetSqlErr()); 
				
				Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
				PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
			}
			
			strRsflag = "0";// ���ڷ���
		}
		cSyscbbabankcode.closeCursor();
		
		if( 0 == strcmp("012", m_cCmt920.sOrgpkgno) )
		{
			CCmcnotsgninfbiz cCmcnotsgninfbiz;
			
			cCmcnotsgninfbiz.m_msgid    = m_strTemp;
			cCmcnotsgninfbiz.m_instgpty	= m_cCmt920.sOrgIsdficode;
			cCmcnotsgninfbiz.m_srcflag	= strRsflag;
			
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cCmcnotsgninfbiz.m_msgid    = [%s]", cCmcnotsgninfbiz.m_msgid.c_str());
		    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cCmcnotsgninfbiz.m_instgpty = [%s]", cCmcnotsgninfbiz.m_instgpty.c_str());
		    
		    SETCTX(cCmcnotsgninfbiz);
			
			iRet = cCmcnotsgninfbiz.findByPK();
			if (SQLNOTFOUND == iRet) 
		    {
		        sprintf(m_szErrMsg, "cCmcnotsgninfbiz.find():��ѯCM_CNOTSGNINFBIZδ�ҵ�����,����Ϊ���ո�����,����Ҫת��������"); 
				
		        Trace(L_INFO,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		        
		        return;
		    }
			if(OPERACT_SUCCESS != iRet)
			{
				 sprintf(m_szErrMsg, "cCmcnotsgninfbiz findByPK fail:  [%d][%s]", 
					 iRet, cCmcnotsgninfbiz.GetSqlErr());
				 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
				 PMTS_ThrowException(DB_GET_DATA_FAIL);
			}
			
			iRet = GetTagVal(strRval, cCmcnotsgninfbiz.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cCmcnotsgninfbiz.m_mbmsgid.c_str(), 22);
			
				//�жϼ�ֱ���������ֱ����������ͨѶ�� by add zql 
				if(cCmcnotsgninfbiz.m_srcflag == "0")
				{
				    DirectInter(cCmcnotsgninfbiz.m_instgpty.c_str(), 
				    			cCmcnotsgninfbiz.m_instddrctpty.c_str(), 
				    			cCmcnotsgninfbiz.m_instdpty.c_str(), 
				    			pchMsg, 
					    		cCmcnotsgninfbiz.m_syscd.c_str());
				}
			}
			else if(-2 == iRet)
			{
				Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "ԭҵ�����ڷ���ϵͳ��Ϊ��,����ת��������");
			}
		}
		else//����������ͨѶ��
		{
	        Trace(L_INFO, __FILE__, __LINE__, NULL, "������������[%s]", m_cCmt920.sOrgpkgno);
		}
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt920::InsertComsendmb()");
}

void CRecvCmt920::PubOriSql(LPCSTR sUpTable, LPCSTR sOriTable, LPCSTR sSetItem, LPCSTR sColNm)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvCmt920::PubOriSql()");
    char sUpSql[1024] = {0};
    
    sprintf(sUpSql, "UPDATE %s t SET "
					" %s "
                    " WHERE t.MSGID||t.INSTGDRCTPTY in "
                    " (SELECT %s "
                    " FROM %s k"
                    " WHERE k.MSGID = '%s' "
                    " AND k.INSTGDRCTPTY = '%s') ", 
                    sUpTable,
                    sSetItem,
                    sColNm,
                    sOriTable,
					m_strTemp.c_str(),
                    m_cCmt920.sOrgIsdficode);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sUpSql=%s", sUpSql);
    int iRet = m_entitybase.execsql(sUpSql);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_entitybase.execsql failed:[%d][%s]",iRet,m_entitybase.GetSqlErr());
        //PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "m_entitybase.execsql failed!");
    } 
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt920::PubOriSql()");
}

void CRecvCmt920::To2NdBizState(LPCSTR szProcSt, string& strBizState)
{
    string strTmp = szProcSt;
    if(strTmp == "01"){//�Ѿܾ�
        strBizState = "PR09";
    }
    else if(strTmp == "02"){//�ѷ���
        strBizState = "PR00";
    }
    else if(strTmp == "03"){//������
        strBizState = "PR03";
    }
    else if(strTmp == "14"){//�ѳ���
        strBizState = "PR32";
    }
    else{
        strBizState = szProcSt;
    }
    /*04	���Ŷ�
    05	������
    06	�ѳ���
    10	�ѻ�ִ
    11	�Ѿܸ�
    12	�ѳ���
    13	��ֹ��
    */
}
