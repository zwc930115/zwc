/********************************************************************
�ļ�����sendcmt311.cpp
�����ˣ�xiaocuiming
��  �ڣ�2011.06.27
��  ��������������볷������
��  ����
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt311.h"

using namespace ZFPT;

CSendCmt311::CSendCmt311(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{
}

CSendCmt311::~CSendCmt311()
{

}

int CSendCmt311::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt311::doWorkSelf...");

    int iRet = RTN_FAIL;

    // ��ȡ����
    GetData();

    // ���ĸ�ֵ
    SetData();

    // �鱨��
    buildCmtMsg();

    // ��������״̬
    UpdateState();

    // ���ͱ���
    AddQueue(m_cCmt311.m_strCmtmsg, m_cCmt311.m_strCmtmsg.length());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt311::doWorkSelf..."); 
    return RTN_SUCCESS;
}



void CSendCmt311::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt311::SetDBKey...");

    m_CmTrRepeal.m_sysid = m_szSysFlagNO; 
    m_CmTrRepeal.m_msgid = m_szMsgFlagNO; 
    m_CmTrRepeal.m_instgdrctpty = m_szSndNO; 

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSysFlagNO = [%s]", m_szSysFlagNO);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgFlagNO = [%s]", m_szMsgFlagNO);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndNO = [%s]", m_szSndNO);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt311::SetDBKey...");
    return;
}

int CSendCmt311::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt311::GetData...");

    SETCTX(m_CmTrRepeal);

    //������ֵ
    SetDBKey();

    //��ѯ����
    int iRet = m_CmTrRepeal.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��iRet = [%d], [%s]", iRet, m_CmTrRepeal.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt311::GetData...");
    return iRet;
}


void CSendCmt311::SetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt311::SetData...");

    strncpy(m_cCmt311.sConsigndate, m_CmTrRepeal.m_consigndate.c_str(), sizeof(m_cCmt311.sConsigndate) -1);

    //**************** �����������ʱȥ���ı�ʶ�ŵ���ŵ���� *******************************

    char sMsssno[8 +1] = {0};
    strncpy(sMsssno, m_CmTrRepeal.m_msgid.c_str() + 8, 8);
    m_cCmt311.iMsssno = atoi(sMsssno);//���������
    
    //*************************************************
    string strTemp;
    strTemp = m_CmTrRepeal.m_orgnlmsgid.substr(0, 8);
    strncpy(m_cCmt311.sOldconsigndate, strTemp.c_str(), sizeof(m_cCmt311.sOldconsigndate) - 1);//ԭί������
    strncpy(m_cCmt311.sOldtradetype, "1", sizeof(m_cCmt311.sOldtradetype) -1);//ԭ�������� = ԭҵ������
    strncpy(m_cCmt311.sOldsendbk, m_CmTrRepeal.m_instgdrctpty.c_str(), sizeof(m_cCmt311.sOldsendbk) - 1);//ԭ�����к� = ����������
    strTemp.erase();
    strTemp = m_CmTrRepeal.m_orgnlmsgid.substr(8, 8);
    m_cCmt311.iOldtxssno = atoi(strTemp.c_str());//����֧���������
    strncpy(m_cCmt311.sRemark, m_CmTrRepeal.m_rmkinf.c_str(), sizeof(m_cCmt311.sRemark) - 1);//����

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt311::SetData...");
}
int CSendCmt311::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt311::buildCmtMsg...");

    int iRet = m_cCmt311.CreateCmt("311", m_szSndNO, m_CmTrRepeal.m_instddrctpty.c_str(), m_sMesgId.c_str(), m_sMesgId.c_str(), m_CmTrRepeal.m_wrkdate.c_str(), "3");
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt231::buildCmtMsg...");
    return iRet;
}
int CSendCmt311::UpdateState()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt311::UpdateState...");

    string strSQL;

    strSQL += "UPDATE CM_TRANSREPEAL t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_08;
    strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
    strSQL += "', t.MESGREFID = '";
    strSQL += m_sMesgId;
    strSQL += "', t.STATETIME = sysdate ";

    strSQL += " WHERE t.SYSID = '";
    strSQL += m_szSysFlagNO;
    strSQL += "' AND t.MSGID = '";
    strSQL += m_szMsgFlagNO;
    strSQL += "' AND t.INSTGDRCTPTY = '";
    strSQL += m_szSndNO; 									
    strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=[%s]", strSQL.c_str());

    int iRet = m_CmTrRepeal.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "UpdateState error:[%d]", iRet);
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt311::UpdateState...");
    return iRet;
}

