/********************************************************************
�ļ�����sendccms319.h
�����ˣ�aps-lel
��  �ڣ�2011.04.02
��  ����
��  ����
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendccms319.h"


CSendCcms319::CSendCcms319(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{
	m_strOrigenlist = "";
}

CSendCcms319::~CSendCcms319()
{

}

void CSendCcms319::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms319::SetDBKey...");
    
    m_cmpmtrtrcl.m_sysid = m_szSysFlagNO;//ϵͳ��ʶ�� 
	m_cmpmtrtrcl.m_msgid = m_szMsgFlagNO; //���ı�ʶ��
	m_cmpmtrtrcl.m_instgindrctpty = m_szSndNO;//
	 m_cmpmtrtrcl.m_rsflag=m_szSrcflg;

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgFlagNO = %s", m_szMsgFlagNO);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndNO = %s", m_szSndNO);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cmpmtrtrcl.m_instgindrctpty = %s", m_cmpmtrtrcl.m_instgindrctpty.c_str());

    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms319::SetDBKey...");
    return;
}

void CSendCcms319::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms319::SetData...");
	
    int iSysflg = -1;
    int iRet = -1;
    chgSysCd(m_szSysFlagNO,iSysflg); 
    iRet = GetIsoDateTime(m_dbproc, iSysflg, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }
    
    char sTm[7] = {0}; 
	
    getSysTime(sTm);
	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "sTm = %s", sTm);
	char szSyscd[4+1] = {0};
    strcpy(szSyscd,m_cmpmtrtrcl.m_sysid.c_str());
    StrUpperCase_ZFPT(szSyscd);

    // ���ļ�ͷ
    m_ccms319.CreateXMlHeader(szSyscd,                        \
                                m_cmpmtrtrcl.m_wrkdate.c_str(), \
                                m_cmpmtrtrcl.m_instgdrctpty.c_str(),\
                                m_cmpmtrtrcl.m_instddrctpty.c_str(),\
                                "ccms.319.001.01",              \
                                m_sMesgId.c_str()); 


	m_ccms319.MsgId           = m_cmpmtrtrcl.m_msgid  ;//���ı�ʶ��
	m_ccms319.CreDtTm         = m_ISODateTime         ;//���ķ���ʱ��
	m_ccms319.GrpHdrMmbId     = m_cmpmtrtrcl.m_instgdrctpty     ;// ����ֱ�Ӳ��������
	m_ccms319.GrpHdrId        = m_cmpmtrtrcl.m_instgindrctpty   ;// �����������к�
	m_ccms319.MmbId           = m_cmpmtrtrcl.m_instddrctpty     ;// ����ֱ�Ӳ��������
	m_ccms319.Id              = m_cmpmtrtrcl.m_instdindrctpty   ;//���ղ�������к�
	m_ccms319.OrgnlMsgId      = m_cmpmtrtrcl.m_orgnlmsgid       ;//ԭ���ı�ʶ��
	m_ccms319.OrgnlMsgNmId    = m_cmpmtrtrcl.m_orgnlmsgnmid     ;//ԭ�������ʹ���
	//m_ccms319.AddtlInf        = m_cmpmtrtrcl.m_returntype      ;//�˻�����/�˻�Ӧ��״̬/����
	string tmp = "/F44/"+m_cmpmtrtrcl.m_returntype;
	m_ccms319.SetAddtlInf(0,tmp.c_str());//�˻�����
	tmp = "/F45/"+m_cmpmtrtrcl.m_retunstat;
	m_ccms319.SetAddtlInf(1,tmp.c_str());//�˻�Ӧ��״̬ PR23����ʾ�������˻أ���PR09����ʾ�Ѿܾ���
	tmp = "/H01/"+m_cmpmtrtrcl.m_rtinfo;
	m_ccms319.SetAddtlInf(2,tmp.c_str());//����
	if((0 == STRNCASECMP(m_cmpmtrtrcl.m_sysid.c_str(),"BEPS",4))&&(0 == STRNCASECMP(m_cmpmtrtrcl.m_returntype.c_str(),"RP01",4)))
	{
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "�����˻�");
		AddDetail();
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms319::SetData...");
    return;
}

int CSendCcms319::GetData()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms319::GetData...");

	SETCTX(m_cmpmtrtrcl);

	SetDBKey();

	int iRet = m_cmpmtrtrcl.findByPK();
	
	if(RTN_SUCCESS != iRet)
	{
	   sprintf( m_sErrMsg,"findByPK() error,error code =[%d] error cause = [%s]",iRet,m_cmpmtrtrcl.GetSqlErr());
	   Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_sErrMsg);
	   PMTS_ThrowException(__FILE__,__LINE__,DB_NOT_FOUND,m_sErrMsg);
			
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms319::GetData...");
	
	return iRet;
}

int CSendCcms319::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms319::UpdateState...");
    SetDBKey();
    string strSQL;
	strSQL += "UPDATE CM_PMTRTRCL t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_08;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
    strSQL += "', t.STATETIME = sysdate ";
    
	strSQL += " WHERE t.SYSID = '";
	strSQL += m_cmpmtrtrcl.m_sysid.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_cmpmtrtrcl.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_cmpmtrtrcl.m_instgindrctpty.c_str(); 	
	strSQL += "' AND t.RSFLAG = '";
	strSQL += m_cmpmtrtrcl.m_rsflag.c_str(); 								
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	
	int iRet = m_cmpmtrtrcl.execsql(strSQL.c_str());
	
    if(RTN_SUCCESS != iRet)
    {	  
	   sprintf( m_sErrMsg,"execsql() error,error code =[%d] error cause = [%s]",iRet,m_cmpmtrtrcl.GetSqlErr());
	   Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_sErrMsg);
	   PMTS_ThrowException(__FILE__,__LINE__,DB_UPDATE_FAIL,m_sErrMsg);

    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms319::UpdateState...");
    return RTN_SUCCESS;
}

int CSendCcms319::doWorkSelf()
{
   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms319::doWork...");

    int iRet = 0;

    GetData();

    SetData();
    
    AddSign319();
	
    iRet = m_ccms319.CreateXml();
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    AddQueue( m_ccms319.m_sXMLBuff.c_str(), m_ccms319.m_sXMLBuff.length());

    UpdateState();

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms319::doWork..."); 
    return RTN_SUCCESS;
}


void CSendCcms319::AddDetail()
{
	SETCTX(m_cmpmtrtrlist);
	STRING strSql;
	strSql = "msgid";
	strSql += " = '"+ m_cmpmtrtrcl.m_msgid +"'";
	strSql += " and rsflag = '1'" ;
	//strSql += " and orgnlmsgid = '" ;
	//strSql += m_cmpmtrtrcl.m_orgnlmsgid + "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql[%s].", strSql.c_str());
	
	if(SQL_SUCCESS == m_cmpmtrtrlist.find(strSql))
	{
		while(SQL_SUCCESS == m_cmpmtrtrlist.fetch())
		{			
			m_ccms319.AddNodeToSubcycle("OrgnlInstrId",m_cmpmtrtrlist.m_orgnlmsgid.c_str());//ԭ���ı�ʶ��	
			m_ccms319.OrgnlInstrId = m_cmpmtrtrlist.m_orgnlmsgid;
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_orgnlmsgid[%s].",  m_cmpmtrtrlist.m_orgnlmsgid.c_str());
			m_ccms319.AddNodeToSubcycle("OrgnlTxId",m_cmpmtrtrlist.m_orgnltxid.c_str());//ԭ��ϸ��ʶ��
			m_ccms319.OrgnlTxId = m_cmpmtrtrlist.m_orgnltxid;
			
			m_ccms319.AddNodeToSubcycle("TxInfAndStsMmbId", m_cmpmtrtrlist.m_orgninstgdrctpty.c_str());//ԭ����ֱ�Ӳ������			
			m_ccms319.TxInfAndStsMmbId = m_cmpmtrtrlist.m_orgninstgdrctpty;
						
			m_ccms319.AddNodeToSubcycle("TxInfAndStsId",m_cmpmtrtrlist.m_orgninstgindrctpty.c_str());//ԭ������������		
			m_ccms319.TxInfAndStsId = m_cmpmtrtrlist.m_orgninstgindrctpty;
						
			m_ccms319.AddNodeToSubcycle("ClrSysMmbIdMmbId",m_cmpmtrtrlist.m_orgninstddrctpty.c_str());//ԭ����ֱ�Ӳ��������
			m_ccms319.ClrSysMmbIdMmbId = m_cmpmtrtrlist.m_orgninstddrctpty;
						
			m_ccms319.AddNodeToSubcycle("BrnchIdId",m_cmpmtrtrlist.m_orgninstdindrctpty.c_str());//ԭ���ղ�������к�
			m_ccms319.BrnchIdId = m_cmpmtrtrlist.m_orgninstdindrctpty;
						
			m_ccms319.AddNodeToSubcycle("Prtry",m_cmpmtrtrlist.m_ctgypurp.c_str());//ԭҵ�����ͱ���
			m_ccms319.Prtry = m_cmpmtrtrlist.m_ctgypurp;
						
			m_ccms319.AddSubcycleToNode("TxInfAndSts");		
			m_ccms319.AddTxStr();
		}
		m_cmpmtrtrlist.closeCursor();
	}
	
}

void CSendCcms319::AddSign319()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendCcms319::AddSign319...");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_ccms319.getOriSignStr();
	
	AddSign(m_ccms319.m_sSignBuff.c_str(), 
					sSignedStr, 
					RAWSIGN,
					m_ccms319.GrpHdrMmbId.c_str());
	
	m_ccms319.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendCcms319::AddSign319...");
}


