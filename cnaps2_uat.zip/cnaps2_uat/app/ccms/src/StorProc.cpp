/********************************************************************
文件名：StorProc.cpp
创建人：hdf
日  期：2011.01.14
修改人：hdf
日  期：
描  述：
版  本：
Copyright (c) 2009  YLINK
********************************************************************/
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "StorProc.h"
#include "logger.h"
#include "exception.h"
#include "pubfunc.h"

extern CConnectPool *g_DBConnPool;
using namespace ZFPT;

CStorProc::CStorProc()
{
}

CStorProc::~CStorProc()
{
}

void CStorProc::GetDBConnect(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CStorProc::GetDBConnect");	

    if(0 != g_DBConnPool->GetConnect(m_dbproc))
    {
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取数据库连接失败");
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "获取数据库连接失败");
    }
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CStorProc::GetDBConnect");		
}

int CStorProc::doWork()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CStorProc::doWork");
    
    /*SqlProccess("hv_trofacsndlist", "hv_trofacsndlisthis");
    SqlProccess("hv_sndexchglist", "hv_sndexchglisthis");
    SqlProccess("hv_trofacrcvlist", "hv_trofacrcvlisthis");
    SqlProccess("hv_rcvexchglist", "hv_rcvexchglisthis");
    SqlProccess("bp_bdsendlist", "bp_bdsendlisthis");
    SqlProccess("bp_bdsndcl", "bp_bdsndclhis");
    SqlProccess("bp_bcoutsendlist", "bp_bcoutsendlisthis");
    SqlProccess("bp_bcoutsndcl", "bp_bcoutsndclhis");
    SqlProccess("bp_bdrcvcl", "bp_bdrcvclhis");
    SqlProccess("bp_bcoutrecvlist", "bp_bcoutrecvlisthis");
    SqlProccess("bp_bcoutrcvcl", "bp_bcoutrcvclhis");*/
    /*SqlProccess("hv_trofacsndlist", "hv_trofacsndlisthis");
    SqlProccess("hv_trofacsndlist", "hv_trofacsndlisthis");
    SqlProccess("hv_trofacsndlist", "hv_trofacsndlisthis");
    SqlProccess("hv_trofacsndlist", "hv_trofacsndlisthis");
    SqlProccess("hv_trofacsndlist", "hv_trofacsndlisthis");
    SqlProccess("hv_trofacsndlist", "hv_trofacsndlisthis");
    SqlProccess("hv_trofacsndlist", "hv_trofacsndlisthis");*/

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CStorProc::doWork");

    return RTN_SUCCESS;
}

int CStorProc::SqlProccess(string SrcTable, string DstTable)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CStorProc::SqlProccess");

    /*SETCTX(m_BaseSql);
    int iRet = m_BaseSql.execsql("insert into " + DstTable + " select * from " + SrcTable);
    if(RTN_SUCCESS != iRet)
    {
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "插入数据库失败SrcTable=%s, DstTable=%s", SrcTable.c_str(), DstTable.c_str());
    }*/

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CStorProc::SqlProccess");
    return RTN_SUCCESS;
}

