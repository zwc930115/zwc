/********************************************************************
�ļ�����sendccms318.h
�����ˣ�aps-lel
��  �ڣ�2011.04.02
��  ����
��  ����
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendccms318.h"


CSendCcms318::CSendCcms318(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{

}

CSendCcms318::~CSendCcms318()
{
	
}

void CSendCcms318::SetDBKey()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms318::SetDBKey...");
	
	m_cmpmtrtrcl.m_sysid = m_szSysFlagNO;//ϵͳ��ʶ�� 
	m_cmpmtrtrcl.m_msgid = m_szMsgFlagNO; //���ı�ʶ��
	m_cmpmtrtrcl.m_instgindrctpty = m_szSndNO;// 
	m_cmpmtrtrcl.m_rsflag = m_szSrcflg;
	
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgFlagNO = %s", m_szMsgFlagNO);
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndNO = %s", m_szSndNO);
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgFlagNO = %s", m_szMsgFlagNO);
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms318::SetDBKey...");
	return;
}

void CSendCcms318::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms318::SetData...");
	
    int iSysflg = -1;
    int iRet = -1;
    chgSysCd(m_szSysFlagNO,iSysflg); 
    iRet = GetIsoDateTime(m_dbproc, iSysflg, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }	
    char sTm[7] = {0}; 
	
    getSysTime(sTm);
	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "sTm = %s", sTm);

    // ���ļ�ͷ
    m_ccms318.CreateXMlHeader(m_szSysFlagNO,                        \
                                m_cmpmtrtrcl.m_wrkdate.c_str(), \
                                m_cmpmtrtrcl.m_instgdrctpty.c_str(),\
                                m_cmpmtrtrcl.m_instddrctpty.c_str(),\
                                "ccms.318.001.01",              \
                                m_sMesgId.c_str()); 

	
	m_ccms318.MsgId    = m_cmpmtrtrcl.m_msgid ;//���ı�ʶ��
	m_ccms318.CreDtTm  = m_ISODateTime ;//���ķ���ʱ��
	m_ccms318.NbOfTxs   =  "1"                          ;//�̶���дΪ1
	m_ccms318.SttlmMtd    = "CLRG"                            ;//�̶���дΪCLRG
	m_ccms318.GrpHdrMmbId    = m_cmpmtrtrcl.m_instgdrctpty ;//����ֱ�Ӳ��������
	m_ccms318.GrpHdrId     = m_cmpmtrtrcl.m_instgindrctpty;//�����������к�
	m_ccms318.MmbId          = m_cmpmtrtrcl.m_instddrctpty;//����ֱ�Ӳ��������
	m_ccms318.Id            = m_cmpmtrtrcl.m_instdindrctpty;//���ղ�������к�
	m_ccms318.OrgnlMsgId     = m_cmpmtrtrcl.m_orgnlmsgid;//ԭ���ı�ʶ��
	m_ccms318.OrgnlMsgNmId    = m_cmpmtrtrcl.m_orgnlmsgnmid;//ԭ�������ʹ���
	m_ccms318.OthrId         = m_cmpmtrtrcl.m_orgninstgdrctpty;//ԭ���ķ��������
	string tmp = "/F44/"+m_cmpmtrtrcl.m_returntype;
	m_ccms318.SetAddtlInf(0,tmp.c_str());//�˻�����  RP00�������˻�  RP01�������˻�
	tmp = "/H01/"+m_cmpmtrtrcl.m_rtinfo;
	m_ccms318.SetAddtlInf(1,tmp.c_str());//����
	
	if (0 == strcmp("RP01",m_cmpmtrtrcl.m_returntype.c_str()))//��ʾ�����˻�
	{
	    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms318::AddDetail...");
		AddDetail();
		//Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms318::AddDetail...");
	}

	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms318::SetData...");
    return;
}

int CSendCcms318::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms318::GetData...");
    
	SETCTX(m_cmpmtrtrcl);

    SetDBKey();
	
    int iRet = m_cmpmtrtrcl.findByPK();
		
	if(RTN_SUCCESS != iRet)
	{
	   sprintf( m_sErrMsg,"findByPK() error,error code =[%d] error cause = [%s]",iRet,m_cmpmtrtrcl.GetSqlErr());
	   Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_sErrMsg);
	   PMTS_ThrowException(__FILE__,__LINE__,DB_NOT_FOUND,m_sErrMsg);
			
	}
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms318::GetData...");
    return iRet;
}

int CSendCcms318::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms318::UpdateState...");
    SetDBKey();
    string strSQL;
	strSQL += "UPDATE CM_PMTRTRCL t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_08;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
    strSQL += "' , t.STATETIME = sysdate ";
    
	strSQL += " WHERE t.SYSID = '";
	strSQL += m_szSysFlagNO;
    strSQL += "' AND t.MSGID = '";
	strSQL += m_cmpmtrtrcl.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_cmpmtrtrcl.m_instgindrctpty.c_str(); 
	strSQL += "' AND t.RSFLAG = '";	
	strSQL += m_cmpmtrtrcl.m_rsflag.c_str(); 								
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	
	int iRet = m_cmpmtrtrcl.execsql(strSQL.c_str());
	
    if(RTN_SUCCESS != iRet)
    {	  
	   sprintf( m_sErrMsg,"execsql() error,error code =[%d] error cause = [%s]",iRet,m_cmpmtrtrcl.GetSqlErr());
	   Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_sErrMsg);
	   PMTS_ThrowException(__FILE__,__LINE__,DB_UPDATE_FAIL,m_sErrMsg);

    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms318::UpdateState...");
    return RTN_SUCCESS;
}

int CSendCcms318::doWorkSelf()
{
   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms318::doWork...");

    int iRet = 0;

    GetData();

    SetData();
    
    AddSign318();
	
    iRet = m_ccms318.CreateXml();
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    AddQueue( m_ccms318.m_sXMLBuff.c_str(), m_ccms318.m_sXMLBuff.length());

    UpdateState();
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms318::doWork..."); 
    return RTN_SUCCESS;
}

void CSendCcms318::AddDetail()
{
	SETCTX(m_cmpmtrtrlist);
	STRING strSql;
	strSql = "msgid";
	strSql += " = '"+ m_cmpmtrtrcl.m_msgid +"'";
	strSql += " and ORGNLMSGID = '" ;
	strSql += m_cmpmtrtrcl.m_orgnlmsgid + "' ";
	strSql += " and rsflag = '1'" ;
	 Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql = [%s]", strSql.c_str());
	if(SQL_SUCCESS == m_cmpmtrtrlist.find(strSql))
	{
		while(SQL_SUCCESS ==m_cmpmtrtrlist.fetch())
		{
			
			m_ccms318.AddNodeToSubcycle("OrgnlTxId",m_cmpmtrtrlist.m_orgnltxid.c_str());//ԭ��ϸ��ʶ��
			m_ccms318.OrgnlTxId = m_cmpmtrtrlist.m_orgnltxid;	                  ;
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cmpmtrtrlist.m_orgnltxid=[%s]", m_cmpmtrtrlist.m_orgnltxid.c_str());
			m_ccms318.AddNodeToSubcycle("RtrdIntrBkSttlmAmt","200.00");//�̶���дΪ200.00	    
			m_ccms318.AddNodeToSubcycle("Ccy","CNY");	
			m_ccms318.AddNodeToSubcycle("TxInfMmbId", m_cmpmtrtrlist.m_orgninstgdrctpty.c_str());//ԭ����ֱ�Ӳ������	
			m_ccms318.TxInfMmbId = m_cmpmtrtrlist.m_orgninstgdrctpty;		
			m_ccms318.AddNodeToSubcycle("TxInfId",m_cmpmtrtrlist.m_orgninstgindrctpty.c_str());//ԭ������������
			m_ccms318.TxInfId = m_cmpmtrtrlist.m_orgninstgindrctpty;		
			m_ccms318.AddNodeToSubcycle("ClrSysMmbIdMmbId",m_cmpmtrtrlist.m_orgninstddrctpty.c_str());//ԭ����ֱ�Ӳ��������
			m_ccms318.ClrSysMmbIdMmbId = m_cmpmtrtrlist.m_orgninstddrctpty;
			m_ccms318.AddNodeToSubcycle("BrnchIdId",m_cmpmtrtrlist.m_orgninstdindrctpty.c_str());//ԭ���ղ�������к�	
			m_ccms318.BrnchIdId = m_cmpmtrtrlist.m_orgninstdindrctpty;
			m_ccms318.AddNodeToSubcycle("Prtry",m_cmpmtrtrlist.m_ctgypurp.c_str());//ԭ���ղ�������к�	
			m_ccms318.Prtry = m_cmpmtrtrlist.m_ctgypurp;
			m_ccms318.AddSubcycleToNode("TxInf");
			m_ccms318.AddTxStr();
		}
		m_cmpmtrtrlist.closeCursor();
	}

	
}

void CSendCcms318::AddSign318()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendCcms318::AddSign318...");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_ccms318.getOriSignStr();
	
	AddSign(m_ccms318.m_sSignBuff.c_str(), 
					sSignedStr, 
					RAWSIGN,
					m_ccms318.GrpHdrMmbId.c_str());
	
	m_ccms318.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendCcms318::AddSign318...");
}


