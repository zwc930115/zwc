/******************************************************************** 
文件名： ProcessPayment.cpp
创建人： hdf
日  期： 2013-03-13
修改人： hdf
日  期： 
描  述： 处理批量代付回执包
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "ProcessPayment.h"
using namespace ZFPT;

extern char		g_SendQueue[128];
extern MQAgent m_cMQAgent;
extern DBProc m_dbproc;
extern char szMaxPayDay[3];//退汇期限

CProcessPayment::CProcessPayment()
{
    m_dTotalAmt = 0.00;
    m_iTotalNum = 0;
    m_iOrgnDbNum = 0;
    m_iFacNum = 0;
}

CProcessPayment::~CProcessPayment()
{

}

void CProcessPayment::AddQueue(string msgtx, int length)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CProcessPayment::AddQueue...");

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "消息内容:msgtx = %s  length=%d  g_SendQueue = [%s]", msgtx.c_str(), length, g_SendQueue);
    int iRet = m_cMQAgent.PutMsg(g_SendQueue, msgtx.c_str(), length);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "往MQ发送消息失败！");
        PMTS_ThrowException(OPT_MQ_ADD_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CProcessPayment::AddQueue...");
}

INT32 CProcessPayment::Work()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CProcessPayment::Work()");

    try
    {
        SETCTX(m_BpBcList);
        int iRet = m_BpBcList.findcount("remark2 = 'PKG012'");
        if (0 == m_BpBcList.m_iCount)
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "无代付业务");
            return 0;
        }
        ProcessPkg012();
        m_BpBcList.commit();
        m_cMQAgent.Commit();
    }
    catch (...)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "创建代付回执包失败");
        m_BpBcList.rollback();
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CProcessPayment::work()");

    return RTN_SUCCESS;
}

void CProcessPayment::UpdateCurReturnDay(int iCurReturnDay)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CProcessPayment::UpdateCurReturnDay");

    char sCurReturnDay[4] = {0};
    itoa(sCurReturnDay, iCurReturnDay);

    string strSQL;
    strSQL += "UPDATE Bp_bcoutsendlist t SET t.STATETIME = sysdate, t.reserve = '";
    strSQL += sCurReturnDay;
    strSQL += "' ";

    strSQL += " WHERE t.TXID = '";
    strSQL += m_BpBcList.m_txid.c_str();
    strSQL += "' AND t.DBTRBRNCHID = '";
    strSQL += m_BpBcList.m_dbtrbrnchid.c_str();
    strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());

    int iRet = m_BpBcList.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "修改发送状态失败iRet=%d, %s", iRet, m_BpBcList.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }   

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CProcessPayment::UpdateCurReturnDay");
}

void CProcessPayment::ProcessPkg012()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CProcessPayment::ProcessPkg012");

    string strCurFacNo = "--";//当前要素号,"--"只为表示第一次运行
    string strCurPackNo = "--";//当前包号,"--"只为表示第一次运行
    int iFlag = 0;

    //查找原代付业务
    SETCTX(m_BpBcList);
    SETCTX(m_colltnchrgslist);
    string strSQL;
    strSQL = "remark2 = 'PKG012' order by ORGNLMSGID,oritxid ";
    int iRet = m_BpBcList.find(strSQL);//按原代付业务包序号+原代付业务对要素集号排序
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "打开游标失败[%d][%s]",iRet,m_BpBcList.GetSqlErr());        
        return;
    }
    while (0 == m_BpBcList.fetch())
    {
        //判断是否该创建回执包
        int iMaxReturnDay = atoi(szMaxPayDay);
        int iCurReturnDay = atoi(m_BpBcList.m_reserve.c_str());
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "贷记表中原代付业务当前期限为[%d]最大返回期限为[%d]",iCurReturnDay,iMaxReturnDay);        
        if (iCurReturnDay < iMaxReturnDay)
        {
            //更新当前期限
            iCurReturnDay++;
            UpdateCurReturnDay(iCurReturnDay);
            continue;
        }

        //标志进入创建组包过程
        iFlag = 1;

        //开始创建回执包
        if ( (m_BpBcList.m_orgnlmsgid == strCurPackNo) && (m_BpBcList.m_oritxid != strCurFacNo) && (strCurFacNo != "--") )//看下此相同要素集号是否完成
        {
            ++m_iOrgnDbNum;
            m_dOrgnFacAmt += m_colltnchrgslist.m_amout;
            FillFactInfo();
            m_pkg012.AddBussiness();
            ++m_iFacNum;
            m_strTempAppData = "";
            m_iOrgnDbNum = 0;
            m_dOrgnFacAmt = 0;
        }
        if ( (m_BpBcList.m_orgnlmsgid != strCurPackNo) && (strCurPackNo != "--") )//看下此相同包号是否完成
        {
            FillHeadInfo();

            //更新原代付表状态
            UpDateOrgn012();

            //初始数据
            m_strTempAppData = "";
            m_iFacNum = 0;
            m_iOrgnDbNum = 0;
            m_dOrgnFacAmt = 0;
        }
        strCurFacNo = m_BpBcList.m_oritxid;
        strCurPackNo = m_BpBcList.m_orgnlmsgid;

        string whereClause1;
        whereClause1 += "MSGID = '";
        whereClause1 += strCurPackNo;
        whereClause1 += "' and BTCHNB = '";
        whereClause1 += strCurFacNo;
        whereClause1 += "' and txid = '";
        whereClause1 += m_BpBcList.m_addtlinf2;
        whereClause1 += "'";
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "whereClause1 = [%s]",whereClause1.c_str()); 
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "查找包号为[%s]要素号为[%s]明细号为[%s]的记录", m_BpBcList.m_orgnlmsgid.c_str(), m_BpBcList.m_oritxid.c_str(), m_BpBcList.m_addtlinf2.c_str());

        iRet = m_colltnchrgslist.find(whereClause1);
        if(OPERACT_SUCCESS != iRet)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "打开游标失败[%d][%s]",iRet,m_colltnchrgslist.GetSqlErr());        
            return;
        }
        if (0 == m_colltnchrgslist.fetch())
        {
            //如果没有被退汇并且已清算
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_BpBcList.m_processcode[%s]  m_BpBcList.m_busistate[%s]",m_BpBcList.m_processcode.c_str(), m_BpBcList.m_busistate.c_str()); 
            if("00" == m_BpBcList.m_processcode && PR_HVBP_19 == m_BpBcList.m_busistate)
            {
                ++m_iTotalNum;
                m_dTotalAmt += m_colltnchrgslist.m_amout;
            }

            char szTemp[117 +1] = {0};
            sprintf(szTemp, "%08s%-32s%015.0f%-60s",
                                m_colltnchrgslist.m_txid.substr(0, 16).c_str(),
                                m_colltnchrgslist.m_cdtrid.c_str(),
                                m_colltnchrgslist.m_amout,
                                m_BpBcList.m_processcode.c_str(),
                                m_BpBcList.m_rjctinf.c_str()
                                );
            m_strTempAppData.append(szTemp);
        }
        else
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "关键数据未查到到,严重!!");
            PMTS_ThrowException(OPT_TRADE_CHECK__FAIL);
        }
        m_colltnchrgslist.closeCursor();

        ++m_iOrgnDbNum;
        m_dOrgnFacAmt += m_colltnchrgslist.m_amout;
    } 
    m_BpBcList.closeCursor();

    if (1 == iFlag)//有过组包过程
    {
        //创建完最后一次
        FillFactInfo();
        m_pkg012.AddBussiness();
        ++m_iFacNum;
        FillHeadInfo();

        //更新原代付表状态
        UpDateOrgn012();

        //更新贷记表完成标志
        UpDateOrgnCD();
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CProcessPayment::ProcessPkg012");
}

void CProcessPayment::FillFactInfo()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CProcessPayment::FillFactInfo");

    char szAppData[130 + 1] = {0};
    sprintf(szAppData, "%-8s%08s%-12s%-12s%-32s%-12s%015.0f%015.0f%08d%08d",
                        m_colltnchrgslist.m_consigdate.c_str(),
                        m_colltnchrgslist.m_btchnb.c_str(),
                        m_colltnchrgslist.m_dbtrbrnchid.c_str(),
                        m_colltnchrgslist.m_dbtrbrnchid.c_str(),
                        m_colltnchrgslist.m_dbtrid.c_str(),
                        m_colltnchrgslist.m_cdtrmmbid.c_str(),
                        m_dOrgnFacAmt,
                        m_dTotalAmt,
                        m_iTotalNum,
                        m_iOrgnDbNum);
    string strAppData = szAppData + m_strTempAppData;

    m_pkg012.m_szCurElementNo = "005";
    strncpy(m_pkg012.stBizBody005.szTrxsType,m_colltnchrgslist.m_ctgyprtry.c_str(),sizeof(m_pkg012.stBizBody005.szTrxsType)-1); 
    strncpy(m_pkg012.stBizBody005.szOdfiCode,m_colltnchrgslist.m_instdpty.c_str(),sizeof(m_pkg012.stBizBody005.szOdfiCode)-1); 
    strncpy(m_pkg012.stBizBody005.szRdfiCode,m_colltnchrgslist.m_instgpty.c_str(),sizeof(m_pkg012.stBizBody005.szRdfiCode)-1); 
    strncpy(m_pkg012.stBizBody005.szConsignDate,m_colltnchrgslist.m_consigdate.c_str(),sizeof(m_pkg012.stBizBody005.szConsignDate)-1); 
    strncpy(m_pkg012.stBizBody005.szTxssNo,m_colltnchrgslist.m_btchnb.c_str(),sizeof(m_pkg012.stBizBody005.szTxssNo)-1); 

    char szBuff[128] = {0};               
    itoa(szBuff, strAppData.length(), 0);
    strncpy(m_pkg012.stBizBody005.szAppLen,szBuff,sizeof(m_pkg012.stBizBody005.szAppLen)-1); 
    strncpy(m_pkg012.stBizBody005.szAppData,strAppData.c_str(),sizeof(m_pkg012.stBizBody005.szAppData)-1);     
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "原代付要素号[%s]组装完成附加域[%s]",m_colltnchrgslist.m_btchnb.c_str(), strAppData.c_str()); 

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CProcessPayment::FillFactInfo");
}

void CProcessPayment::FillHeadInfo()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CProcessPayment::FillHeadInfo");

    //取msgid
    char szchMsgId[32 +1] = {0};
    bool bRet = GetMsgIdValue(m_dbproc, szchMsgId, eMsgId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "参数错误");
        PMTS_ThrowException(PRM_FAIL);
    }
    char sWorkDate[9] = {0};
    strncpy(sWorkDate, szchMsgId, 8);

    //取通信级标识号
    char m_sMsgRefId[256] = {0};
    if(!GetMsgIdValue(m_dbproc,m_sMsgRefId,eRefId,SYS_BEPS))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取通信级标识号错误!");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_MESGREFID_FAIL, "获取通信级标识号错误!");
    }

    strncpy(m_pkg012.stPkgHead012.szPkgType,"012",sizeof(m_pkg012.stPkgHead012.szPkgType)-1); 
    strncpy(m_pkg012.stPkgHead012.szOdfiCode,m_colltnchrgslist.m_instddrctpty.c_str(),sizeof(m_pkg012.stPkgHead012.szOdfiCode)-1); 
    strncpy(m_pkg012.stPkgHead012.szRdfiCode,m_colltnchrgslist.m_instgdrctpty.c_str(),sizeof(m_pkg012.stPkgHead012.szRdfiCode)-1); 
    strncpy(m_pkg012.stPkgHead012.szPkgCDate, m_colltnchrgslist.m_consigdate.c_str(), sizeof(m_pkg012.stPkgHead012.szPkgCDate) - 1);
    strncpy(m_pkg012.stPkgHead012.szPkgserNo,szchMsgId+8,sizeof(m_pkg012.stPkgHead012.szPkgserNo)-1); 
    strncpy(m_pkg012.stPkgHead012.szSoFlag,"0",sizeof(m_pkg012.stPkgHead012.szSoFlag)-1); /*辖内分发标志		    1n*/     
    strncpy(m_pkg012.stPkgHead012.szTradetype,"40503",sizeof(m_pkg012.stPkgHead012.szTradetype)-1); /*业务类型号			    5n*/   

    char szBuff[128]                 = {0};
    itoa(szBuff, m_iFacNum, 0) ;          /*明细信息数目			4n*/
    strncpy(m_pkg012.stPkgHead012.szDetailCnt,szBuff,sizeof(m_pkg012.stPkgHead012.szDetailCnt)-1); 
    strncpy(m_pkg012.stPkgHead012.szAppData,"",sizeof(m_pkg012.stPkgHead012.szAppData)-1); /*包附加数据*/

    //2. 组报文头
    m_pkg012.CreateMsgHeader("012",
        m_colltnchrgslist.m_instddrctpty.c_str(),
        m_colltnchrgslist.m_instgdrctpty.c_str(),
        m_sMsgRefId,
        m_sMsgRefId,
        sWorkDate,
        "1");
    //加押
    char szMac[40 + 1] = {0};
    string strCodeMac;//取加押串
    m_pkg012.GetMacStr(m_pkg012, strCodeMac);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "__strCodeMac = [%s]", strCodeMac.c_str());
    //......
    memcpy(m_pkg012.stPkgHead012.szPkgDest, szMac, sizeof(szMac)-1);

    //4. 组报文尾
    m_pkg012.CreateMsgTail();

    //5. 组报文
    m_pkg012.CreateMsg();

    AddQueue(m_pkg012.m_szMsgText, m_pkg012.m_szMsgText.length());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CProcessPayment::FillHeadInfo");
}

void CProcessPayment::UpDateOrgn012()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CProcessPayment::UpDateOrgn012");

    //MSGID+发起直接参与机构为条件更新此包里的所有明细汇总状态
    string strSQL;
    strSQL += "UPDATE Bp_colltnchrgslist t SET t.STATETIME = sysdate, t.PROCSTATE = '";
    strSQL += PR_HVBP_07;
    strSQL += "' ";

    strSQL += " WHERE t.MSGID = '";
    strSQL += m_colltnchrgslist.m_msgid.c_str();
    strSQL += "' AND t.INSTGDRCTPTY = '";
    strSQL += m_colltnchrgslist.m_instgdrctpty.c_str(); 									
    strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());

    SETCTX(m_colltnchrgslist);
    int iRet = m_colltnchrgslist.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "修改明细表状态失败iRet=%d, %s", iRet, m_colltnchrgslist.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }   

    strSQL = "";
    strSQL += "UPDATE BP_COLLTNCHRGSCL t SET t.STATETIME = sysdate, t.PROCSTATE = '";
    strSQL += PR_HVBP_07;
    strSQL += "' ";

    strSQL += " WHERE t.MSGID = '";
    strSQL += m_colltnchrgslist.m_msgid.c_str();
    strSQL += "' AND t.INSTGDRCTPTY = '";
    strSQL += m_colltnchrgslist.m_instgdrctpty.c_str(); 									
    strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());

    iRet = m_colltnchrgslist.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "修改汇总表状态失败iRet=%d, %s", iRet, m_colltnchrgslist.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }   

    Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CProcessPayment::UpDateOrgn012");
}

void CProcessPayment::UpDateOrgnCD()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CProcessPayment::UpDateOrgnCD");

    //条件:发起直接参与机构/付款清算行+原业务为代付业务
    string strSQL;
    strSQL += "UPDATE BP_BCOUTSENDLIST SET STATETIME = sysdate, remark2 = 'PKG012_40503'";

    strSQL += " WHERE remark2 = 'PKG012' and reserve >= '";
    strSQL += szMaxPayDay;
    strSQL += "'";

    /*strSQL += " WHERE remark2 = 'PKG012' and INSTGDRCTPTY = '";
    strSQL += m_BpBcList.m_instgdrctpty.c_str();
    strSQL += "' AND msgid = '";
    strSQL += m_BpBcList.m_msgid.c_str();
    strSQL += "'";*/
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());

    SETCTX(m_BpBcList);
    int iRet = m_BpBcList.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "修改明细表状态失败iRet=%d, %s", iRet, m_BpBcList.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }   


    Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CProcessPayment::UpDateOrgnCD");
}
