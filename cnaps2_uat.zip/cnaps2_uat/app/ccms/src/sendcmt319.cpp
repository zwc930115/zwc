/******************************************************************** 
�ļ����� sendcmt319.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt319.h"

using namespace ZFPT;

CSendCmt319::CSendCmt319(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{
}

CSendCmt319::~CSendCmt319()
{
}

INT32 CSendCmt319::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt319::doWorkSelf");

    GetData();
    
    SetData();

    buildCmtMsg();
    
    UpdateState();

    // ���ͱ���
    AddQueue(m_cmt319.m_strCmtmsg.c_str(), m_cmt319.m_strCmtmsg.length());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt319::doWorkSelf"); 
    return 0;
}

INT32 CSendCmt319::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt319::SetData");
    
    strncpy(m_cmt319.sConsigndate,          m_cmpmtrtrcl.m_consigndate.c_str(),  sizeof(m_cmt319.sConsigndate)-1);    //ί������              CHAR(8)      NOT NULL 
    strncpy(m_cmt319.sOldsendsapbk,         m_cmpmtrtrcl.m_instgindrctpty.c_str(),   sizeof(m_cmt319.sOldsendsapbk)-1);    //�˻�����������        12n          NOT NULL
    strncpy(m_cmt319.sOldmssno,             m_cmpmtrtrcl.m_msgid.c_str()+8,   sizeof(m_cmt319.sOldmssno)-1);         //�˻��������          8n           NOT NULL
    strncpy(m_cmt319.sOldrecvsapbk,         m_cmpmtrtrcl.m_instdindrctpty.c_str(),   sizeof(m_cmt319.sOldrecvsapbk)-1);    //�˻�Ӧ��������        12n          NOT NULL
    strncpy(m_cmt319.sRebacktype,           m_cmpmtrtrcl.m_returntype.c_str(), sizeof(m_cmt319.sRebacktype)-1);       //�˻�����               1n          NOT NULL
    strncpy(m_cmt319.sOldrecvbk,            m_cmpmtrtrcl.m_instddrctpty.c_str(),  sizeof(m_cmt319.sOldrecvbk)-1);       //�˻�Ӧ����            12n            NULL
    strncpy(m_cmt319.sOldsendbk,            m_cmpmtrtrcl.m_instgdrctpty.c_str(),  sizeof(m_cmt319.sOldsendbk)-1);       //�˻�������            12n            NULL
    
    strncpy(m_cmt319.sOldpacktype,          m_cmpmtrtrcl.m_orgnlmsgnmid.c_str()+3,    sizeof(m_cmt319.sOldpacktype)-1);      //ԭ�����ͺ�             3n            NULL
    strncpy(m_cmt319.sOldpackdate,          m_cmpmtrtrcl.m_orgnlmsgid.c_str(),    sizeof(m_cmt319.sOldpackdate)-1);      //ԭ��ί������           8n            NULL
    strncpy(m_cmt319.sOldpackno,            m_cmpmtrtrcl.m_orgnlmsgid.c_str()+8,  sizeof(m_cmt319.sOldpackno)-1);        //ԭ�����               8n            NULL
    //strncpy(m_cmt319.sTextkey,     ,sizeof(m_cmt319.sTextkey)-1);         //��Ѻ                   40x           NULL
    strncpy(m_cmt319.sRemark,     m_cmpmtrtrcl.m_rtinfo.c_str(),    sizeof(m_cmt319.sRemark)-1);          //�˻����븽��           60g           NULL

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt319::SetData"); 
    return 0;
}

int CSendCmt319::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt319::getData");

	SETCTX(m_cmpmtrtrcl);

    m_cmpmtrtrcl.m_sysid = "BEPS";
  	m_cmpmtrtrcl.m_instgindrctpty = m_szSndNO;
  	m_cmpmtrtrcl.m_msgid        = m_szMsgFlagNO;
  	m_cmpmtrtrcl.m_rsflag      = "1";
  	
  	int iRet = m_cmpmtrtrcl.findByPK();
  	if (SQLNOTFOUND == iRet)
	{
		sprintf(m_sErrMsg, "�Ҳ���ָ��ҵ��[%s], [%s], [%d][%s]", 
		    m_szSndNO, m_szMsgFlagNO, iRet, m_cmpmtrtrcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	} 	
	else if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg, "��ѯ���ܱ���������[%s], [%s], [%d][%s]",
		    m_szSndNO, m_szMsgFlagNO, iRet, m_cmpmtrtrcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}

    if("0" == m_cmpmtrtrcl.m_returntype)
    {
        SETCTX(m_cmpmtrtrlist);
	    STRING strSql;
	    strSql = "msgid";
	    strSql += " = '"+ m_cmpmtrtrcl.m_msgid +"'";
	    //strSql += " and ORGNLMSGID = '" ;
	    //strSql += m_cmpmtrtrcl.m_orgnlmsgid + "' ";
	    strSql += " and rsflag = '1' and instgdrctpty = '" ;
	    strSql += m_szSndNO;
	    strSql += + "' ";
	    
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql = [%s]", strSql.c_str());
	    if(SQL_SUCCESS == m_cmpmtrtrlist.find(strSql))
	    {
		    m_cmpmtrtrlist.fetch();
		    
		    strncpy(m_cmt319.sOldconsigndate,       m_cmpmtrtrlist.m_orgnltxid.c_str(), sizeof(m_cmt319.sOldconsigndate)-1);   //ԭί������             8n            NULL 
    	    m_cmt319.iOldtxssno = atoi(m_cmpmtrtrlist.m_orgnltxid.c_str()+8);             //ԭ֧���������         8n            NULL 
            strncpy(m_cmt319.sTradecode,            m_cmpmtrtrlist.m_ctgypurp.c_str(),  sizeof(m_cmt319.sTradecode)-1);        //ԭҵ�����ͺ�           5n            NULL

		    m_cmpmtrtrlist.closeCursor();
	    }
	    else
	    {
    		sprintf(m_sErrMsg, "��ѯ��ϸ����������[%s], [%s], [%s]",
    		    m_cmpmtrtrcl.m_orgnlmsgid.c_str(), m_cmpmtrtrcl.m_msgid.c_str(), m_cmpmtrtrlist.GetSqlErr());
    		
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
    		
    		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    	}  
 
    }
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt319::getData"); 
    
	return iRet;
}
int CSendCmt319::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt123::buildCmtMsg...");

    int iRet = m_cmt319.CreateCmt("319", m_szSndNO, m_cmpmtrtrcl.m_instddrctpty.c_str(), m_sMesgId.c_str(), m_sMesgId.c_str(), m_cmpmtrtrcl.m_wrkdate.c_str(), "0");
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt319::buildCmtMsg...");
    return iRet;
}
int CSendCmt319::UpdateState(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendCmt319::UpdateDb");

	string strSQL;
	strSQL += "UPDATE CM_PMTRTRCL t SET t.Procstate = '";
  strSQL += PR_HVBP_08;
  strSQL += "', t.MESGID = '";
  strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
	strSQL += "' , t.STATETIME = sysdate  WHERE t.msgid = '";
	strSQL += m_cmpmtrtrcl.m_msgid;
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_cmpmtrtrcl.m_instgindrctpty; 
	strSQL += "' AND t.RSFLAG = '";
	strSQL += m_cmpmtrtrcl.m_rsflag; 
	strSQL += "'";
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, strSQL.c_str());
	
    SETCTX(m_cmpmtrtrcl);
	int iRet = m_cmpmtrtrcl.execsql(strSQL.c_str());
	if (iRet != SQL_SUCCESS)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]",
		    iRet, m_cmpmtrtrcl.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
	}
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendCmt319::UpdateDb");
    return RTN_SUCCESS;
}




