/******************************************************************** 
�ļ����� recvccms915.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-03-05
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvccms915.h"

using namespace ZFPT;
CRecvCcms915::CRecvCcms915()
{

}


CRecvCcms915::~CRecvCcms915()
{
	
}

INT32 CRecvCcms915::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms915::Work()");
	
	//1����������
	unPack(sMsg);

	//2����Ա��ֵ
	SetData(sMsg);
					  
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms915::work()");
	
	return RTN_SUCCESS;
}



INT32 CRecvCcms915::unPack(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms915::unPack");	

	int iRet = RTN_FAIL;

	//1�������Ƿ�Ϊ��
	if (NULL == sMsg || '\0' == sMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
	}

    m_authrtychgntctnlist.m_msgtp = m_cParser915.m_PMTSHeader.getMesgType();
    
	//2����������
	iRet = m_cParser915.ParseXml(sMsg);
	if (RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= %d", iRet);	
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
	}

    ZFPTLOG.SetLogInfo("915", m_cParser915.MsgId.c_str());

	m_strMsgID	=	m_cParser915.MsgId;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms915::unPack");	

	return RTN_SUCCESS;
}

INT32 CRecvCcms915::SetData(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms915::SetData");
    int iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;      
        
    int iNum = m_cParser915.GetNodeCountByName("AuthrtyInf");
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iNum[%d]",iNum);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "MsgId[%s]",m_cParser915.MsgId.c_str());
    int iLoop = 1;
    for(int i = 0; i < iNum; i++)
    {
        //��ϸ��
        m_authrtychgntctnlist.m_wrkdate = m_strWorkDate ; 
        m_authrtychgntctnlist.m_sysid = m_cParser915.SysCd; 
        m_authrtychgntctnlist.m_msgid = m_cParser915.MsgId;     
        m_authrtychgntctnlist.m_msgtp = "ccms.915.001.01";//m_cParser915.m_PMTSHeader.getMesgType();
        m_authrtychgntctnlist.m_chngtp = m_cParser915.GetValueFromCycle("AuthrtyInf", "ChngTp", i);//m_cParser915.ChngTp;
        m_authrtychgntctnlist.m_fctvtp = m_cParser915.GetValueFromCycle("AuthrtyInf", "FctvTp", i);//m_cParser915.FctvTp;
        m_authrtychgntctnlist.m_fctvdt = m_cParser915.GetValueFromCycle("AuthrtyInf", "FctvDt", i);//m_cParser915.fctvdt;
        m_authrtychgntctnlist.m_ifctvdt = m_cParser915.GetValueFromCycle("AuthrtyInf", "IfctvDt", i);//m_cParser915.ifctvdt;
        m_authrtychgntctnlist.m_sendbank = m_cParser915.GetValueFromCycle("AuthrtyInf", "InitPtcpt", i);
        m_authrtychgntctnlist.m_recvbank = m_cParser915.GetValueFromCycle("AuthrtyInf", "RcvPtcpt", i);
        
        int iSum = m_cParser915.GetInLoopNodeCnt("AuthrtyInf",i,"BizAuthrtyInf");
        
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iSum[%d]",iSum);
        
        for(int j = 0; j < iSum; j++)
        {
            m_authrtychgntctnlist.m_listid = iLoop ++;
            m_authrtychgntctnlist.m_msgno= m_cParser915.GetValueFromLiLCycle("AuthrtyInf",i,"BizAuthrtyInf",j,"MT"); //m_cParser915.MT;
            m_authrtychgntctnlist.m_msgtype = m_cParser915.GetValueFromLiLCycle("AuthrtyInf",i,"BizAuthrtyInf",j,"TxTpCd"); //m_cParser915.TxTpCd ;
            m_authrtychgntctnlist.m_authrtysgncd = m_cParser915.GetValueFromLiLCycle("AuthrtyInf",i,"BizAuthrtyInf",j,"AuthrtySgnCd"); //m_cParser915.AuthrtySgnCd;
            string strTemp = m_cParser915.GetValueFromLiLCycle("AuthrtyInf",i,"BizAuthrtyInf",j,"AuthrtyWght");
            m_authrtychgntctnlist.m_authrtywght = atoi(strTemp.c_str());//atoi(m_cParser915.AuthrtyWght);        
            m_authrtychgntctnlist.m_procstate = "36"; //��ʱ��Ч����,��������д����Ч
            //m_authrtychgntctnlist.m_proctime//���ݿ�������洢����ʵ��,����д�ϵ�ǰ�Ĺ���ʱ��
            
            //��ϵ��
            m_authrtyinfo.m_syscode = m_cParser915.SysCd;
            m_authrtyinfo.m_sendbank = m_authrtychgntctnlist.m_sendbank;
            m_authrtyinfo.m_recvbank = m_authrtychgntctnlist.m_recvbank;
            m_authrtyinfo.m_msgno= m_authrtychgntctnlist.m_msgno; //m_cParser915.MT;
            m_authrtyinfo.m_msgtype = m_authrtychgntctnlist.m_msgtype; //m_cParser915.TxTpCd ;
            m_authrtyinfo.m_authrtysgncd = m_authrtychgntctnlist.m_authrtysgncd; //m_cParser915.AuthrtySgnCd ;
            m_authrtyinfo.m_authrtywght = m_authrtychgntctnlist.m_authrtywght; // atoi(m_cParser915.AuthrtyWght);
            
            if(0 == STRNCASECMP("AS00",m_authrtychgntctnlist.m_authrtysgncd.c_str(),4))//AS00:������AS01:��ֹ
            {
            	m_authrtyinfo.m_status = "35"; //34 δ��Ч��35����Ч��36 ��ע��
            }
            else
            { 
            	m_authrtyinfo.m_status = "36"; 
            } 
          
            m_authrtyinfo.m_proctime = m_sWorkDate;//���ݿ�������洢����ʵ��,����д�ϵ�ǰ�Ĺ���ʱ��
            
            /*
            CC00������
            CC01�����
            CC02������
            EF00��������Ч
            EF01��ָ��������Ч
            */

		        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_listid[%d]",m_authrtychgntctnlist.m_listid);

            int iRet = 0;
            if( 0 == strcmp(m_authrtychgntctnlist.m_chngtp.c_str(), "CC00") )
            {
                InsertData();

            }
            else if(    (0==strcmp(m_authrtychgntctnlist.m_chngtp.c_str(), "CC01"))  || (0 == strcmp(m_authrtychgntctnlist.m_chngtp.c_str(), "CC02"))   )
            {
                UpdataState();
            }
            else
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ԫ�ز���ȷ, m_authrtychgntctnlist.m_chngtp=%s", m_authrtychgntctnlist.m_chngtp.c_str());
                PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "����Ԫ�ز���ȷ");
            }       
        }

    }    
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCcms915::SetData");
	return RTN_SUCCESS;
}

//�����ϸ ���ܱ��͹�ϵ����ִ�в������
INT32 CRecvCcms915::InsertData(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms915::InsertData");
	
    
    SETCTX(m_authrtychgntctnlist);
    int iRet = m_authrtychgntctnlist.insert();
    if(DUPLICATE_KEY == iRet)//������ͻ �����˳�
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����cm_authrtychgntctnlist��ʧ��, iRet=%d, %s", iRet , m_authrtychgntctnlist.GetSqlErr());
	}
    else if( RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����cm_authrtychgntctnlist��ʧ��, iRet=%d, %s", iRet , m_authrtychgntctnlist.GetSqlErr());
        PMTS_ThrowException(DB_INSERT_FAIL);          
    }

    SETCTX(m_authrtyinfo);
    iRet = m_authrtyinfo.insert();
    if(DUPLICATE_KEY == iRet)//������ͻ �����˳�
    {
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����m_authrtyinfo��ʧ��, iRet=%d, %s", iRet , m_authrtyinfo.GetSqlErr());
    }
    else if( RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����cm_authrtyinfo��ʧ��, iRet=%d, %s", iRet , m_authrtyinfo.GetSqlErr());
        PMTS_ThrowException(DB_INSERT_FAIL);           
    }
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms915::InsertData");
	
	return RTN_SUCCESS;
}

//�����ϸ ���ܱ�ִ�в������,��ϵ��ִ�и��²���
INT32 CRecvCcms915::UpdataState()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms915::UpdataState");

    SETCTX(m_authrtychgntctnlist);
    int iRet = m_authrtychgntctnlist.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "����cm_authrtychgntctnlist�����ʧ��, iRet=%d, %s", iRet , m_authrtychgntctnlist.GetSqlErr());
        //PMTS_ThrowException(DB_INSERT_FAIL);            
    }

    char szWght[2+1] = {0};
    sprintf(szWght,"%02d",m_authrtyinfo.m_authrtywght);
    
    SETCTX(m_authrtyinfo);
    string strSQL;
	strSQL += "UPDATE cm_authrtyinfo t SET ";
	strSQL += " t.SYSCODE = '";
    strSQL += m_authrtyinfo.m_syscode;
	strSQL += "' , t.AUTHRTYSGNCD = '";
	strSQL += m_authrtyinfo.m_authrtysgncd;   //��ʱ��Ч����,��������д����Ч
	strSQL += "' , t.AUTHRTYWGHT = ";
	strSQL += szWght;
	strSQL += " , t.STATUS = '";
	strSQL += m_authrtyinfo.m_status;	
	strSQL += "' , t.PROCTIME = sysdate ";//���ݿ�������洢����ʵ��,����д�ϵ�ǰ�Ĺ���ʱ��
   
	strSQL += " WHERE t.SENDBANK = '";
	strSQL += m_authrtyinfo.m_sendbank;
	strSQL += "' AND t.RECVBANK = '";
	strSQL += m_authrtyinfo.m_recvbank;
	strSQL += "' AND  t.MSGNO = '";
	strSQL += m_authrtyinfo.m_msgno;
	strSQL += "' AND t.MSGTYPE = '";
	strSQL += m_authrtyinfo.m_msgtype;	
	strSQL += "'";
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=[%s]", strSQL.c_str());
	
    iRet = m_authrtyinfo.execsql(strSQL.c_str());
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "����cm_authrtyinfo��ʧ��, iRet=%d, %s", iRet , m_authrtyinfo.GetSqlErr());
        //PMTS_ThrowException(DB_UPDATE_FAIL);   
       Trace(L_INFO,  __FILE__,  __LINE__, NULL, "����cm_authrtyinfo��ʱû���ҵ����ݣ����������쳣����");         
    }
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms915::UpdataState");

	return RTN_SUCCESS;
}
