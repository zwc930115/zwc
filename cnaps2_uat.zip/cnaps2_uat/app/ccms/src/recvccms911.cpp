
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvccms911.h"
#include "entitybase.h"
#include "hvsndexchglist.h"
#include "hvtrofacsndlist.h"
#include "hvpvpsetofac.h"
#include "hvdraft.h"
#include "hvmnetstlcl.h"
#include "hvmnetstlmcxl.h"
#include "bpbcoutsendlist.h"
#include "bpbcoutsndcl.h"
#include "bpbdsendlist.h"
#include "bpbdsndcl.h"
#include "bpcolltnchrgslist.h"
#include "bpgettx.h"
#include "bprealtmcstacctmg.h"
#include "bpinvcprtapply.h"
#include "bpinvcprtrspn.h"
#include "bpcstbdpcxlcl.h"
#include "bpcstpmtcxl.h"
#include "bpchckcdtforld.h"
#include "cmfreeinfo.h"
#include "cmtransrepeal.h"
#include "cmcnotsgninfbiz.h"
#include "cmtransinfoqry.h"
#include "cmtransstqry.h"
#include "cmpmtrtrcl.h"
#include "cmbnddigcert.h"
#include "cmlogon.h"
#include "saacctinfqryrspn.h"
#include "sanetdbtlmtdstrbtnmgmt.h"
#include "sanetgqmgmt.h"
#include "bpbizpubntce.h"
#include "bpcolltnchrgscl.h"
#include "bpcstctrctmgcl.h"
#include "bpcstacctqrycl.h"
#include "bpbktocstdcntfctn.h"
#include "salqdtytfr.h"
#include "saintrbklnmgmt.h"
#include "sapibklnqryappl.h"
#include "bpgettx.h"
#include "sabalwrngmg.h"
	
using namespace ZFPT;

CRecvCcms911::CRecvCcms911()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms911::CRecvCcms911()");		
	
	memset(m_sMsgTp,0x00,sizeof(m_sMsgTp));
	m_strProcSts = "";
    m_strApiState = "";
    
    m_strMsgTp = "ccms.911.001.02";
    
    memset(m_strStrRsp,0x00,sizeof(m_strStrRsp));
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms911::CRecvCcms911()");	
}


CRecvCcms911::~CRecvCcms911()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms911::~CRecvCcms911()");	
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms911::~CRecvCcms911()");		
}

INT32 CRecvCcms911::Work(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "CRecvCcms911::doWork()");		
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "i get a msg[%s]", pchMsg);	

    // ��������
    unPack(pchMsg);

	TransProcSts(atoi(m_sMsgTp));
	
    // ��������
    UpdateData();
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms911::doWork()");
	
    return RTN_SUCCESS;
}



INT32 CRecvCcms911::unPack(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms911::unPack()");
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]", pchMsg);

	int  iRet = RTN_FAIL;

	// �����Ƿ�Ϊ��
	if (NULL == pchMsg || '\0' == pchMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
	}

    // ��������
    if (RTN_SUCCESS != m_ccms911.ParseXml(pchMsg))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������!");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������!");
    }

	ZFPTLOG.SetLogInfo("911", m_ccms911.MsgId.c_str());
    
	m_strMsgID = m_ccms911.MsgId;

	if ( 6 == m_ccms911.MT.length() )
	{
	    memcpy(m_sMsgTp, m_ccms911.MT.c_str(), 6);
	}
	else
	{
        memcpy(m_sMsgTp, m_ccms911.MT.c_str() + 5, 3);
	}
	
	// ��ȡ��������
	iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
    if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
		PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
	}
	
	m_strWorkDate = m_sWorkDate;  
	
	printf("m_ccms911.MsgId      = [%s]\n" ,   m_ccms911.MsgId    .c_str());   //ͨ�ż���ʶ�� 
	printf("m_ccms911.OrigSndr   = [%s]\n" ,   m_ccms911.OrigSndr .c_str());   //���ķ�����   
	printf("m_ccms911.RjctInf    = [%s]\n" ,   m_ccms911.RjctInf  .c_str());   //ҵ��ܾ���Ϣ 
	printf("m_ccms911.MsgRefId   = [%s]\n" ,   m_ccms911.MsgRefId .c_str());   //ͨ�ż��ο���	
	printf("m_ccms911.OrigSndDt  = [%s]\n" ,   m_ccms911.OrigSndDt.c_str());   //���ķ������� 
	printf("m_ccms911.PrcCd      = [%s]\n" ,   m_ccms911.PrcCd    .c_str());   //ҵ������   
	printf("m_ccms911.MT         = [%s]\n" ,   m_ccms911.MT       .c_str());   //�������ʹ���  

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms911::unPack()");	
    
    return RTN_SUCCESS;
}
	
/******************************************************************************
*  Function:   UpdateData
*  Description:���±�
*  Input:      ��
*  Output:     
*  Return:     0   : �����ɹ�,
               ����: ����ʧ��
*  Others:     ��
*  Author:     xlz
*  Date:       2011-03-04
*******************************************************************************/
INT32 CRecvCcms911::UpdateData(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms911::UpdateData()");
	
	int iRet;
	char sSqlStr[4096];  	
	
	char szPrcDt[32] = {0};
    memset(szPrcDt, 0x00, sizeof(szPrcDt));
    chgToISODate(m_ccms911.OrigSndDt.c_str(), szPrcDt);
    
	printf("ԭ���ı��======m_sMsgTp = [%s]\n",m_sMsgTp);
	// ****************** ���� ******************
	//�ͻ�������ҵ����/���ڻ���������ҵ����
	if( 0 == strcmp("111"   , m_sMsgTp) || 0 == strcmp("112"   , m_sMsgTp)
     || 0 == strcmp("CMT100", m_sMsgTp) || 0 == strcmp("CMT101", m_sMsgTp)
     || 0 == strcmp("CMT102", m_sMsgTp) || 0 == strcmp("CMT103", m_sMsgTp)
     || 0 == strcmp("CMT105", m_sMsgTp) || 0 == strcmp("CMT108", m_sMsgTp)
     || 0 == strcmp("CMT121", m_sMsgTp) || 0 == strcmp("CMT122", m_sMsgTp)
     || 0 == strcmp("CMT123", m_sMsgTp) || 0 == strcmp("CMT124", m_sMsgTp) )
	{
		CHvsndexchglist  cHvsndexchglist;
		
        SETCTX(cHvsndexchglist);
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE HV_SNDEXCHGLIST t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ", //and t.MESGREFID = '%s'
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),     
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                         
						m_ccms911.MsgId.c_str());
                        
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cHvsndexchglist.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��HV_SNDEXCHGLIST����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"update hv_sndexchglist  is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
	    }
	}
	//��ʱת�˱���
    else if( 0 == strcmp("141"   , m_sMsgTp) || 0 == strcmp("CMT232", m_sMsgTp) 
          || 0 == strcmp("CMT407", m_sMsgTp) || 0 == strcmp("CMT408", m_sMsgTp) )
	{
		CHvtrofacsndlist  cHvtrofacsndlist;
		
        SETCTX(cHvtrofacsndlist);
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE HV_TROFACSNDLIST t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ", //and t.MESGREFID = '%s'  
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),     
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                         
						m_ccms911.MsgId.c_str());
                        
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cHvtrofacsndlist.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��HV_TROFACSNDLIST����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE HV_TROFACSNDLIST  is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
	    }
	}
	//PVP����������Ϣ����
	else if( 0 == strcmp("143" ,m_sMsgTp) )
	{
		CHvpvpsetofac    cHvpvpsetofac;
		
        SETCTX(cHvpvpsetofac);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE HV_PVPSETOFAC t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ", //and t.MESGREFID = '%s'
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),   
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                             
						m_ccms911.MsgId.c_str());
                        
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cHvpvpsetofac.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��HV_PVPSETOFAC����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE HV_PVPSETOFAC  is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
	    }
	}
	//�����������л�Ʊ�ʽ���/���л�Ʊ�����˻�ҵ����
	else if( 0 == strcmp("151" ,m_sMsgTp) || 0 == strcmp("153" ,m_sMsgTp) )
	{
		CHvdraft  cHvdraft;
		
        SETCTX(cHvdraft);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE HV_DRAFT t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ",  // and t.MESGREFID = '%s'
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),   
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                             
						m_ccms911.MsgId.c_str());
                        
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cHvdraft.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��HV_DRAFT����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE HV_DRAFT  is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
	    }
	}
	//����������㱨��
	else if( 0 == strcmp("631", m_sMsgTp) )
	{
		CHvmnetstlcl  cHvmnetstlcl;
		
        SETCTX(cHvmnetstlcl);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE HV_MNETSTLCL t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ", //  and t.MESGREFID = '%s'
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),   
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                             
						m_ccms911.MsgId.c_str());
                        
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cHvmnetstlcl.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��HV_MNETSTLCL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE HV_MNETSTLCL  is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
	    }
	}
	//��߾���ҵ�������뱨��
	else if( 0 == strcmp("634", m_sMsgTp) )
	{/*
		CHvmnetstlmcxl    cHvmnetstlmcxl;
		
        SETCTX(cHvmnetstlmcxl);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE HV_MNETSTLMCXL t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MSGID = '%s'", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),   
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                             
						m_ccms911.MsgId.c_str());
                        
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cHvmnetstlmcxl.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��HV_MNETSTLMCXL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE HV_MNETSTLMCXL is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
	    }*/
	}
	// ****************** С��� ******************
	//�ͻ�������ͨ����ҵ����/���ڻ���������ͨ����ҵ����
	//ʵʱ����ҵ����/���ڴ���ҵ����
	//��ͨ���ҵ���ִ����/CISͨ�û�ִҵ����
	//ʵʱ���ҵ���ִ����/���ڽ��ҵ���ִ����
	else if( 0 == strcmp("121",    m_sMsgTp) || 0 == strcmp("122",    m_sMsgTp)
 	      || 0 == strcmp("123",    m_sMsgTp) || 0 == strcmp("125",    m_sMsgTp)
 	      || 0 == strcmp("128",    m_sMsgTp) || 0 == strcmp("130",    m_sMsgTp)
	      || 0 == strcmp("132",    m_sMsgTp) || 0 == strcmp("134",    m_sMsgTp)
	      || 0 == strcmp("PKG001", m_sMsgTp) || 0 == strcmp("PKG005", m_sMsgTp)
	      || 0 == strcmp("PKG007", m_sMsgTp) || 0 == strcmp("PKG008", m_sMsgTp)
	      || 0 == strcmp("PKG009", m_sMsgTp) || 0 == strcmp("PKG010", m_sMsgTp)
	      || 0 == strcmp("PKG011", m_sMsgTp) )
	{
    	CBpbcoutsndcl cBpbcoutsndcl;
    	
        SETCTX(cBpbcoutsndcl);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE BP_BCOUTSNDCL t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.netgdt = '%s', "
                        "t.netgrnd= '0', "
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ",   // and t.MESGREFID = '%s'
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        szPrcDt,
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cBpbcoutsndcl.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_BCOUTSNDCL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE BP_BCOUTSNDCL is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
	    }
	    //ͬʱ��Ҫ������ϸ״̬ΪCNAPS���ܾ�
	    CBpbcoutsendlist cBpbcoutsendlist;
	    SETCTX(cBpbcoutsendlist);
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
	    char sqlStrWhere[1024*4]={0};
	    sprintf(sqlStrWhere,"MESGID = '%s' ",m_ccms911.MsgId.c_str()); 
        Trace(L_ERROR, __FILE__, __LINE__, NULL,"sqlStrWhere=[%s]",sqlStrWhere);
        iRet = cBpbcoutsndcl.find(sqlStrWhere);
        if(0 == iRet)
        {
        	iRet = cBpbcoutsndcl.fetch();
        	if(0 == iRet)
        	{
        		sprintf(sSqlStr,"UPDATE BP_BCOUTSENDLIST SET PROCSTATE='%s',"
        		         "netgdt='%s', netgrnd='0', "
        		         "RJCTINF= '%s' where MSGID='%s' AND INSTGDRCTPTY='%s'",
        		        m_strProcSts.c_str(),
        		        szPrcDt,
        		        m_ccms911.RjctInf.c_str(), 
        		        cBpbcoutsndcl.m_msgid.c_str(),
                        cBpbcoutsndcl.m_instgdrctpty.c_str());
                Trace(L_ERROR, __FILE__, __LINE__, NULL,"sSqlStr=[%s]",sSqlStr);
                iRet = cBpbcoutsndcl.execsql(sSqlStr);
			    if (iRet == SQLNOTFOUND)
			    {
			    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_BCOUTSENDLIST����û���ҵ�����msgid=[%s]",cBpbcoutsndcl.m_msgid.c_str());
			    }
			    else if (iRet != SQL_SUCCESS)
			    {
			        sprintf(m_szErrMsg,  
						"UPDATE BP_BCOUTSENDLIST is error!iRet=[%d]", iRet);
					
			        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
					
			        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
			    }
        	}
        	cBpbcoutsndcl.closeCursor();
        }
        else
        {
        	Trace(L_ERROR, __FILE__, __LINE__, NULL,"����ϸ����û���ҷ��������ļ�¼���޷�����ϸ��״̬");
        }
	     
	}
	//ʵʱ���ǻ�ִҵ����/��ͨ���ҵ����
	//ʵʱ���ҵ����/���ڽ��ҵ����
	else if( 0 == strcmp("124" ,m_sMsgTp) || 0 == strcmp("127" ,m_sMsgTp) 
	      || 0 == strcmp("131" ,m_sMsgTp) || 0 == strcmp("133" ,m_sMsgTp)
	      || 0 == strcmp("PKG002" ,m_sMsgTp) || 0 == strcmp("PKG006" ,m_sMsgTp)
	      || 0 == strcmp("PKG003" ,m_sMsgTp) || 0 == strcmp("PKG004" ,m_sMsgTp)
	      || 0 == strcmp("PKG009" ,m_sMsgTp) )
	{
    	CBpbdsndcl cBpbdsndcl;
    	
        SETCTX(cBpbdsndcl);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));

		sprintf(sSqlStr, "UPDATE BP_BDSNDCL t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.netgdt = '%s', "
                        "t.netgrnd= '0', "
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ",   //and t.MESGREFID = '%s'
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        szPrcDt,
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cBpbdsndcl.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_BDSNDCL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE BP_BDSNDCL is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
	    }
	    //ͬʱ������ϸ��״̬
	    CBpbdsendlist  m_CBpbdsendlist;
	    SETCTX(m_CBpbdsendlist);
	    char StrSqlRun[512]={0};
	    sprintf(StrSqlRun," MESGID='%s' ",m_ccms911.MsgId.c_str());
	    iRet = cBpbdsndcl.find(StrSqlRun);
	    if(iRet!=0)
	    {
	    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "û���ҵ�����������ԭҵ��MESGID=[%s]",m_ccms911.MsgId.c_str());
			PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
	    }
	    while(cBpbdsndcl.fetch()==0)
	    {
	    	char updateSql[512]={0};
	    	sprintf(updateSql,"UPDATE BP_BDSENdLIST t SET "
	    	                   "t.STATETIME = sysdate,"
		                       "t.BUSISTATE = '%s', "
		                       "t.PROCSTATE = '%s', "
		                       "t.PROCESSCODE = '%s',"
		                       "t.RJCTINF = '%s' "
		                       " WHERE t.MSGID = '%s' ",
		                        m_strApiState.c_str(),
		                        m_strProcSts.c_str(),    
		                        m_ccms911.PrcCd.c_str(),
		                        m_ccms911.RjctInf.c_str(),                            
								cBpbdsndcl.m_msgid.c_str());
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "updateSql = [%s]",updateSql);
		    
		    iRet = cBpbdsndcl.execsql(updateSql);
		    if (iRet == SQLNOTFOUND)
		    {
		    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_BDSNDCL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
		    }
		    else if (iRet != SQL_SUCCESS)
		    {
		        sprintf(m_szErrMsg,  
					"UPDATE BP_BDSENdLIST is error!iRet=[%d]", iRet);
				
		        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
				
		        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
		    }
	    }
	}
	//��������ҵ����/��������ҵ���ִ����
	//��������ҵ����/��������ҵ���ִ����
	//ʵʱ����ҵ����/ʵʱ����ҵ���ִ����
	//ʵʱ����ҵ����/ʵʱ����ҵ���ִ����
	//388/389/390/391/392/393/394/395��δ��
	else if( 0 == strcmp("380" ,m_sMsgTp) || 0 == strcmp("381" ,m_sMsgTp) 
	      || 0 == strcmp("382" ,m_sMsgTp) || 0 == strcmp("383" ,m_sMsgTp)
	      || 0 == strcmp("384" ,m_sMsgTp) || 0 == strcmp("385" ,m_sMsgTp)
	      || 0 == strcmp("386" ,m_sMsgTp) || 0 == strcmp("387" ,m_sMsgTp) )
	{
    	CBpcolltnchrgslist cBpcolltnchrgslist;
    	
        SETCTX(cBpcolltnchrgslist);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE BP_COLLTNCHRGSCL t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.netgdt = '%s', "
                        "t.netgrnd= '0', "
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ", //and t.MESGREFID = '%s'
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        szPrcDt,
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cBpcolltnchrgslist.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_COLLTNCHRGSLIST����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE BP_COLLTNCHRGSLIST is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
	    }
	    //���911��������˵���û�ִһ����ʧ�ܵ����ʧ�ܵ����������Ӧ�Ļ�Ӧ��ʶ
	    UpdateRsp();
	  
	}

	else if(0 == strcmp("389" ,m_sMsgTp) || 0 == strcmp("388" ,m_sMsgTp))  //����С��389 388 by add zql 
	{
		CBpbizpubntce m_CBpbizpubntce;
    	
        SETCTX(m_CBpbizpubntce);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE BP_BIZPUBNTCE t SET "
						"t.PROCTIME = sysdate,"
                        "t.STATUS = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ", //and t.MESGREFID = '%s'
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = m_CBpbizpubntce.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_BIZPUBNTCE����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE BP_BIZPUBNTCE is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
	    }
	    //����һ���Ի�Ӧ��ʶ���޸� by add zql 2012 -6-28
	    //UpdateRsp();
	}
	//������޶���Ѻ/���Ŷ�ȷ����������
	else if( 0 == strcmp("353" ,m_sMsgTp) )
	{
		CSanetgqmgmt  cSanetgqmgmt;
		
        SETCTX(cSanetgqmgmt);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE SA_NETDBTLMTDSTRBTNMGMT t SET "
						"t.proctime = sysdate,"
                        "t.PROCSTATE = '%s', "
                        "t.PRCCD = '%s', "
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ", // and t.MESGREFID = '%s'
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cSanetgqmgmt.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��SA_NETGQMGMT����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE SA_NETGQMGMT is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	}
	//�����ɿ��ѯ����/�����ɿ�֪ͨ����
	//397,399û�з���Ȩ��,����Ҫ����
	//add zql 20120629
	else if(0 == strcmp("392" ,m_sMsgTp) || 0 == strcmp("393" ,m_sMsgTp) )
	{
		CBpcstctrctmgcl  m_CBpcstctrctmgcl;
		
        SETCTX(m_CBpcstctrctmgcl);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE BP_CSTCTRCTMGCL t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s' "
                        " WHERE t.MESGID = '%s' ", //and t.MESGREFID = '%s'
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),                               
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	   
	    iRet = m_CBpcstctrctmgcl.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_CSTCTRCTMGCL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE BP_CSTCTRCTMGCL is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	    if(0 == strcmp("393" ,m_sMsgTp))
	    {
	     	UpdateOriBus();//���� 393ԭҵ��
		}
	}
	//add zql 20120629
	else if(0 == strcmp("394" ,m_sMsgTp) || 0 == strcmp("395" ,m_sMsgTp) )
	{
		CBpcstacctqrycl  m_CBpcstacctqrycl;
		
        SETCTX(m_CBpcstacctqrycl);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE BP_CSTACCTQRYCL t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s' "
                        " WHERE t.MESGID = '%s'  and t.srcflag !='2' ", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),                               
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = m_CBpcstacctqrycl.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_CSTACCTQRYCL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE BP_CSTACCTQRYCL is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }	
	}
	else if( 0 == strcmp("398" ,m_sMsgTp) )
	{
		CBpbktocstdcntfctn  m_CBpbktocstdcntfctn;
		
        SETCTX(m_CBpbktocstdcntfctn);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE BP_BKTOCSTDCNTFCTN t SET "
						"t.PROCTIME = sysdate,"
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCLINF = '%s'"
                        " WHERE t.MESGID = '%s' AND RSFLAG = '1' ", 
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = m_CBpbktocstdcntfctn.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_BKTOCSTDCNTFCTN����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE BP_BKTOCSTDCNTFCTN is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	}
	//�ͻ��˻�ʵʱ��ѯ����/�ͻ��˻�ʵʱ��ѯӦ����
	else if( 0 == strcmp("401" ,m_sMsgTp) || 0 == strcmp("402" ,m_sMsgTp) )
	{
		CBprealtmcstacctmg  cBprealtmcstacctmg;
		
        SETCTX(cBprealtmcstacctmg);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE BP_REALTMCSTACCTMG t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cBprealtmcstacctmg.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_REALTMCSTACCTMG����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE BP_REALTMCSTACCTMG is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	}
	//��Ʊ��ӡ���뱨��
	else if( 0 == strcmp("403" ,m_sMsgTp) )
	{
		CBpinvcprtapply  cBpinvcprtapply;
		
        SETCTX(cBpinvcprtapply);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE BP_INVCPRTAPPLY t SET "
						"t.PROCTIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s', "
                        "t.RJCTINF = '%s' "
                        " WHERE t.MESGID = '%s' ", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),      
						m_ccms911.RjctInf.c_str(),                        
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cBpinvcprtapply.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_INVCPRTAPPLY����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE BP_INVCPRTAPPLY is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	}
	//��Ʊ��ӡ��Ӧ����:����ԭ���뱨��
	else if( 0 == strcmp("404" ,m_sMsgTp))
	{
		CBpinvcprtrspn  cBpinvcprtrspn;
		
        SETCTX(cBpinvcprtrspn);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE BP_INVCPRTRSPN t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cBpinvcprtrspn.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_INVCPRTRSPN����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE BP_INVCPRTRSPN is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	}
	//�����Ŷӹ���֪ͨ���뱨��
	else if( 0 == strcmp("407" ,m_sMsgTp))
	{
		CSanetdbtlmtdstrbtnmgmt  cSanetdbtlmtdstrbtnmgmt;
		
        SETCTX(cSanetdbtlmtdstrbtnmgmt);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE SA_NETDBTLMTDSTRBTNMGMT t SET "
						"t.STATETIME = sysdate,"
                        "t.PROCSTATE = '%s', "
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ", 
                        m_strProcSts.c_str(),    
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cSanetdbtlmtdstrbtnmgmt.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��SA_NETDBTLMTDSTRBTNMGMT����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE SA_NETDBTLMTDSTRBTNMGMT is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	}
	//���ҵ��ֹ�����뱨��/���ҵ��ֹ��Ӧ����
	else if( 0 == strcmp("411" ,m_sMsgTp) || 0 == strcmp("412" ,m_sMsgTp) )
	{
		CBpcstbdpcxlcl  cBpcstbdpcxlcl;
		
        SETCTX(cBpcstbdpcxlcl);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE BP_CSTBDPCXLCL t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' and t.RSFLAG = '1'", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cBpcstbdpcxlcl.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_CSTBDPCXLCL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE BP_CSTBDPCXLCL is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	}
	//ʵʱҵ��������뱨��
	//ʵʱҵ�����Ӧ����(û����Ȩ��,������)
	else if( 0 == strcmp("413" ,m_sMsgTp) )
	{
		CBpcstpmtcxl  cBpcstpmtcxl;
		
        SETCTX(cBpcstpmtcxl);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE BP_CSTPMTCXL t SET "
						"t.PROCTIME = sysdate,"
                        "t.PRCSTS = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PRCCD = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cBpcstpmtcxl.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_CSTPMTCXL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE BP_CSTPMTCXL is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	}
	//֧ƱȦ���������/֧ƱȦ�����Ӧ����
	else if( 0 == strcmp("418" ,m_sMsgTp) || 0 == strcmp("419" ,m_sMsgTp) )
	{
		CBpchckcdtforld  cBpchckcdtforld;
		
        SETCTX(cBpchckcdtforld);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE BP_CHCKCDTFORLD t SET "
						"t.STATETIME = sysdate,"
                        "t.PROCSTATE = '%s', "
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ", 
                        m_strProcSts.c_str(), 
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cBpchckcdtforld.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_CHCKCDTFORLD����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE BP_CHCKCDTFORLD is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	}
	// ****************** �������� ******************
	//���ɸ�ʽ����
	else if( 0 == strcmp("303" ,m_sMsgTp) || 0 == strcmp("CMT303" ,m_sMsgTp) )
	{
		CCmfreeinfo  cCmfreeinfo;
		
        SETCTX(cCmfreeinfo);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE CM_FREEINFO t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cCmfreeinfo.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��CM_FREEINFO����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE CM_FREEINFO is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	}
	//ҵ�������뱨��
	else if( 0 == strcmp("307" ,m_sMsgTp) )
	{
		CCmtransrepeal  cCmtransrepeal;
		
        SETCTX(cCmtransrepeal);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE CM_TRANSREPEAL t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cCmtransrepeal.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��CM_TRANSREPEAL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE CM_TRANSREPEAL is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	}
    //ͨ�÷�ǩ����Ϣҵ����
	else if( 0 == strcmp("310" ,m_sMsgTp) || 0 == strcmp("311" ,m_sMsgTp)
	      || 0 == strcmp("312" ,m_sMsgTp) || 0 == strcmp("313" ,m_sMsgTp)
	      || 0 == strcmp("PKG012" ,m_sMsgTp) )
	{
		CCmcnotsgninfbiz cCmcnotsgninfbiz;
		
        SETCTX(cCmcnotsgninfbiz);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE CM_CNOTSGNINFBIZ t SET "
						"t.PROCTIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        //"t.PROCESSCODE = '%s',"//�ñ�û������ֶ�
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        //m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cCmcnotsgninfbiz.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��cm_cnotsgninfbiz����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"update cm_cnotsgninfbiz is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	}
	else if(0 == strcmp("376" ,m_sMsgTp) || 0 == strcmp("377" ,m_sMsgTp))
	{
		CSalqdtytfr m_CSalqdtytfr;
		SETCTX(m_CSalqdtytfr);
		memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE SA_LQDTYTFR t SET "
						"t.PROCTIME = sysdate,"
                        "t.PROCSTATE = '%s' "
                        " WHERE t.MESGID = '%s' ", 
                        m_strProcSts.c_str(),                              
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = m_CSalqdtytfr.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��SA_LQDTYTFR����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE SA_LQDTYTFR is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	}
	//ҵ���ѯ����/ҵ��鸴����
	else if( 0 == strcmp("314" ,   m_sMsgTp) || 0 == strcmp("315"   , m_sMsgTp) 
	      || 0 == strcmp("CMT301", m_sMsgTp) || 0 == strcmp("CMT302", m_sMsgTp) )
	{
		CCmtransinfoqry  cCmtransinfoqry;
		
        SETCTX(cCmtransinfoqry);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
	    
		sprintf(sSqlStr, "UPDATE CM_TRANSINFOQRY t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cCmtransinfoqry.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��CM_TRANSINFOQRY����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE CM_TRANSINFOQRY is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	}
	//ҵ��״̬��ѯ���뱨��
	else if( 0 == strcmp("316" ,m_sMsgTp) || 0 == strcmp("CMT651" ,m_sMsgTp) )
	{
		CCmtransstqry  cCmtransstqry;
		
        SETCTX(cCmtransstqry);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE CM_TRANSSTQRY t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cCmtransstqry.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��CM_TRANSSTQRY����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE CM_TRANSSTQRY is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	}
	//ҵ���˻����뱨��/ҵ���˻�Ӧ����
	else if( 0 == strcmp("318" ,m_sMsgTp) || 0 == strcmp("319" ,m_sMsgTp) 
		  || 0 == strcmp("CMT313" ,m_sMsgTp)  || 0 == strcmp("CMT314" ,m_sMsgTp) )
	{
		CCmpmtrtrcl  cCmpmtrtrcl;
		
        SETCTX(cCmpmtrtrcl);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE CM_PMTRTRCL t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cCmpmtrtrcl.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��CM_PMTRTRCL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE CM_PMTRTRCL is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	}
	//����֤��󶨹���֪ͨ����/����֤���������뱨��
	else if( 0 == strcmp("903" ,m_sMsgTp) ||0 == strcmp("919" ,m_sMsgTp) )
	{
		CCmbnddigcert  cCmbnddigcert;
		
        SETCTX(cCmbnddigcert);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE CM_BNDDIGCERT t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' ", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cCmbnddigcert.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��CM_BNDDIGCERT����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE CM_BNDDIGCERT is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	}
	//�����ʻ���Ϣ��ѯ
	else if( 0 == strcmp("366" ,m_sMsgTp))
	{/*
		CSaacctinfqryrspn  cSaacctinfqryrspn;
		
        SETCTX(cSaacctinfqryrspn);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE SA_ACCTINFQRYRSPN t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MSGID = '%s'", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cSaacctinfqryrspn.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��SA_ACCTINFQRYRSPN����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE SA_ACCTINFQRYRSPN is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }*/
	}
	//��¼�˳����뱨��
	else if( 0 == strcmp("805" ,m_sMsgTp))
	{/*
		CCmlogon  cCmlogon;
		
        SETCTX(cCmlogon);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE CM_LOGON t SET "
						"t.STATETIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MSGID = '%s'", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = cCmlogon.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��CM_LOGON����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE CM_LOGON is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }*/
	}
	else if(0 == strcmp("374" ,m_sMsgTp))
	{
		CSaintrbklnmgmt   m_cSaintrbklnmgmt ;
		
        SETCTX(m_cSaintrbklnmgmt);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE sa_intrbklnmgmt t SET "
						"t.PROCTIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' and INSTGINDRCTPTY = '%s' and WORKDATE = '%s'", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str(),
						m_ccms911.OrigSndr.c_str(),
						m_ccms911.OrigSndDt.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = m_cSaintrbklnmgmt.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��sa_intrbklnmgmt����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE sa_intrbklnmgmt is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }

	}
	else if(0 == strcmp("614" ,m_sMsgTp))
	{
		CSapibklnqryappl  m_sapibkln;
		
        SETCTX(m_sapibkln);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE sa_pibklnqryappl t SET "
						"t.PROCTIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' and INSTGINDRCTPTY = '%s' and WORKDATE = '%s'", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str(),
						m_ccms911.OrigSndr.c_str(),
						m_ccms911.OrigSndDt.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = m_sapibkln.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��sa_pibklnqryappl����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE sa_pibklnqryappl is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }

	}		
	else if(0 == strcmp("361" ,m_sMsgTp))
	{
		CSabalwrngmg	m_Sabalwrngmg;
		
        SETCTX(m_Sabalwrngmg);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE sa_balwrngmg t SET "
						"t.PROCTIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' and INSTGINDRCTPTY = '%s' and WORKDATE = '%s'", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str(),
						m_ccms911.OrigSndr.c_str(),
						m_ccms911.OrigSndDt.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = m_Sabalwrngmg.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��sa_balwrngmg����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE sa_balwrngmg is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }

	}	
	else if(0 == strcmp("396" ,m_sMsgTp))
	{
		CBpgettx	m_Bpgettx;
		
        SETCTX(m_Bpgettx);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE bp_gettx t SET "
						"t.PROCTIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MESGID = '%s' and INSTGDRCTPTY = '%s' and WORKDATE = '%s' AND RSFLAG = '1'", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str(),
						m_ccms911.OrigSndr.c_str(),
						m_ccms911.OrigSndDt.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = m_Bpgettx.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��bp_gettx����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE bp_gettx is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }

	}		
	else if(0 == strcmp("368" ,m_sMsgTp))
	{
		CBpgettx	m_Bpgettx;
		
        SETCTX(m_Bpgettx);
        
	    memset(sSqlStr, NULL_CHAR, sizeof(sSqlStr));
		
		sprintf(sSqlStr, "UPDATE sa_lqdtyqryappl t SET "
						"t.PROCTIME = sysdate,"
                        "t.BUSISTATE = '%s', "
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s',"
                        "t.RSPFLAG = '1' "
                        " WHERE t.MESGID = '%s' and INSTGDRCTPTY = '%s' and WORKDATE = '%s' ", 
                        m_strApiState.c_str(),
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						m_ccms911.MsgId.c_str(),
						m_ccms911.OrigSndr.c_str(),
						m_ccms911.OrigSndDt.c_str());
	                                
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr = [%s]",sSqlStr);
	    
	    iRet = m_Bpgettx.execsql(sSqlStr);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��sa_lqdtyqryappl����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE sa_lqdtyqryappl is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }

	}			
	else 
	{
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��֧�ֵı�������[%s]", m_sMsgTp);
        PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "��֧�ֵı�������");
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms911::UpdateData()");
	
    return RTN_SUCCESS;
}
	


void CRecvCcms911::TransProcSts(int nMsgType)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms911::TransProcSts()");
  
    m_strProcSts  = PR_HVBP_14;//�Ѿܾ� 
    m_strApiState = PROCESS_PR09;//�Ѿܾ� 

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms911::TransProcSts()");
}

/******************************************************************************
*  Function:   InsertComsendmb
*  Description:������ͨѶ��
*  Input:      ��
*  Output:     
*  Return:     0   : �����ɹ�,
               ����: ����ʧ��
*  Others:     ��
*  Author:     hhc
*  Date:       2012-02-10
*******************************************************************************/
INT32 CRecvCcms911::InsertComsendmb(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms911::InsertComsendmb()");
	
	int    iRet = RTN_FAIL;
	char   sSqlStr[4096] = {0}; 
	string strRval = "";
	 	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ԭ���ı�� [%s]", m_sMsgTp);
	if( 0 == strcmp("111" ,m_sMsgTp) || 0 == strcmp("112" ,m_sMsgTp) 
	 || 0 == strcmp("CMT100" ,m_sMsgTp) || 0 == strcmp("CMT101" ,m_sMsgTp) 
	 || 0 == strcmp("CMT102" ,m_sMsgTp) || 0 == strcmp("CMT105" ,m_sMsgTp) 
	 || 0 == strcmp("CMT108" ,m_sMsgTp) || 0 == strcmp("CMT121" ,m_sMsgTp) 
	 || 0 == strcmp("CMT122" ,m_sMsgTp) || 0 == strcmp("CMT123" ,m_sMsgTp) 
	 || 0 == strcmp("CMT124" ,m_sMsgTp) || 0 == strcmp("CMT229" ,m_sMsgTp) )
	{
		CHvsndexchglist cHvsndexchglist;
		
		string strSql = "";
		strSql = " MESGID = '";
		strSql += m_ccms911.MsgId;
		strSql += "' and INSTGDRCTPTY = '";
		strSql += m_ccms911.OrigSndr + "'";

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql[%s]", strSql.c_str());
		
		SETCTX(cHvsndexchglist);
			
		iRet = cHvsndexchglist.find(strSql);
		if(OPERACT_SUCCESS != iRet)
		{
			 sprintf(m_szErrMsg, "cBpbcoutsendlist find fail:  [%d][%s]", 
				 iRet, cHvsndexchglist.GetSqlErr());
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		while(0 == cHvsndexchglist.fetch())
		{
			iRet = GetTagVal(strRval, cHvsndexchglist.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cHvsndexchglist.m_mbmsgid.c_str(), 22);
		    
				//�жϼ�ֱ���������ֱ����������ͨѶ�� by add zql 
				if(cHvsndexchglist.m_msgdirect == "0")
				{
				    DirectInter(cHvsndexchglist.m_instgindrctpty.c_str(), 
				    			cHvsndexchglist.m_instdindrctpty.c_str(),
				    			cHvsndexchglist.m_instddrctpty.c_str(), 
				    			pchMsg);
			    }
			}
			else if(-2 == iRet)
			{
				Trace(L_INFO,  __FILE__,	__LINE__, NULL, "ԭҵ�����ڷ���ϵͳ��Ϊ�գ��ñ�ҵ���ɿͻ��˷��𣬲���ת�����ڡ�");
				// PMTS_ThrowException(OTH_ERR);
			}
		}
		
		cHvsndexchglist.closeCursor();
	}
    else if(0 == strcmp("143" ,m_sMsgTp) )
	{
		CHvpvpsetofac    cHvpvpsetofac;
		
		string strSql = "";
		strSql = " MESGID = '";
		strSql += m_ccms911.MsgId;
		strSql += "' and INSTGDRCTPTY = '";
		strSql += m_ccms911.OrigSndr;
		strSql += "' and MSGTP = 'hvps.143.001.01'";

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql[%s]", strSql.c_str());
		
		SETCTX(cHvpvpsetofac);
			
		iRet = cHvpvpsetofac.find(strSql);
		if(OPERACT_SUCCESS != iRet)
		{
			 sprintf(m_szErrMsg, "cBpbcoutsendlist find fail:  [%d][%s]", 
				 iRet, cHvpvpsetofac.GetSqlErr());
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		while(0 == cHvpvpsetofac.fetch())
		{
			iRet = GetTagVal(strRval, cHvpvpsetofac.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cHvpvpsetofac.m_mbmsgid.c_str(), 22);
		    
				//�жϼ�ֱ���������ֱ����������ͨѶ�� by add zql 
				if(cHvpvpsetofac.m_msgdirect =="0")
				{
				    DirectInter(cHvpvpsetofac.m_instgindrctpty.c_str(), 
				    			cHvpvpsetofac.m_instdindrctpty.c_str(),
				    			cHvpvpsetofac.m_instddrctpty.c_str(), 
				    			pchMsg);
			    }
			}
			else if(-2 == iRet)
			{
				Trace(L_INFO,  __FILE__,	__LINE__, NULL, "ԭҵ�����ڷ���ϵͳ��Ϊ�գ��ñ�ҵ���ɿͻ��˷��𣬲���ת�����ڡ�");
				// PMTS_ThrowException(OTH_ERR);
			}
		}
		
		cHvpvpsetofac.closeCursor();
	}
	else if( 0 == strcmp("121",    m_sMsgTp) || 0 == strcmp("122",    m_sMsgTp)  
		  || 0 == strcmp("125",    m_sMsgTp)
		  || 0 == strcmp("PKG001", m_sMsgTp) || 0 == strcmp("PKG005", m_sMsgTp)
	      || 0 == strcmp("PKG007", m_sMsgTp) )
	{
		CBpbcoutsndcl cBpbcoutsndcl;
		
		CBpbcoutsendlist cBpbcoutsendlist;
		
		char szMsgid[35 + 1] = {0};
		
		string strSql = "";
		strSql = " MESGID = '";
		strSql += m_ccms911.MsgRefId;
		strSql += "' and INSTGDRCTPTY = '";
		strSql += m_ccms911.OrigSndr;
		strSql += "' ";

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql[%s]", strSql.c_str());
		
		SETCTX(cBpbcoutsndcl);
		SETCTX(cBpbcoutsendlist);	
		iRet = cBpbcoutsndcl.find(strSql);
		if(OPERACT_SUCCESS != iRet)
		{
			 sprintf(m_szErrMsg, "cBpbcoutsendlist find fail:  [%d][%s]", 
				 iRet, cBpbcoutsndcl.GetSqlErr());
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
		
		
		while(0 == cBpbcoutsndcl.fetch())
		{
			char tempmsgid[35+1]={0};
			char tempinstgdrctpty[14+1];
		
			strncpy(szMsgid, cBpbcoutsndcl.m_msgid.c_str(), sizeof(szMsgid)-1);
			
			strcpy(tempmsgid,cBpbcoutsndcl.m_msgid.c_str());
			strcpy(tempinstgdrctpty,cBpbcoutsndcl.m_instgdrctpty.c_str());
			char tempSql[1024]={0};
			sprintf(tempSql, "UPDATE BP_BCOUTSENDLIST t SET "
						"t.STATETIME = sysdate,"
                        "t.PROCSTATE = '%s', "
                        "t.PROCESSCODE = '%s',"
                        "t.RJCTINF = '%s'"
                        " WHERE t.MSGID = '%s' and t.INSTGDRCTPTY = '%s'", 
                        m_strProcSts.c_str(),    
                        m_ccms911.PrcCd.c_str(),
                        m_ccms911.RjctInf.c_str(),                            
						cBpbcoutsndcl.m_msgid.c_str(),
                        cBpbcoutsndcl.m_instgdrctpty.c_str());
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "tempSql = [%s]",tempSql);
	    
		    iRet = cBpbcoutsendlist.execsql(tempSql);
		    if (iRet == SQLNOTFOUND)
		    {
		    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_BCOUTSENDLIST����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
		    }
		    else if (iRet != SQL_SUCCESS)
		    {
		        sprintf(m_szErrMsg,  
					"UPDATE BP_BCOUTSENDLIST is error!iRet=[%d]", iRet);
				
		        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
				
		        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
		    }
		}
		
		cBpbcoutsndcl.closeCursor();
		
		strSql = "";
		strSql = " MSGID = '";
		strSql += szMsgid;
		strSql += "' and INSTGDRCTPTY = '";
		strSql += m_ccms911.OrigSndr + "'";

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql[%s]", strSql.c_str());
		
		SETCTX(cBpbcoutsendlist);
			
		iRet = cBpbcoutsendlist.find(strSql);
		if(OPERACT_SUCCESS != iRet)
		{
			 sprintf(m_szErrMsg, "cBpbcoutsendlist find fail:  [%d][%s]", 
				 iRet, cBpbcoutsendlist.GetSqlErr());
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		while(0 == cBpbcoutsendlist.fetch())
		{
			iRet = GetTagVal(strRval, cBpbcoutsendlist.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, "txid[%s]", cBpbcoutsendlist.m_txid.c_str());
				m_strMsgID = cBpbcoutsendlist.m_txid;
				
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cBpbcoutsendlist.m_mbmsgid.c_str(), 22);
	        
			    //�жϼ�ֱ���������ֱ����������ͨѶ�� by add zql 
			    if(cBpbcoutsendlist.m_srcflag =="0")
			    {
					DirectInter(cBpbcoutsendlist.m_dbtrbrnchid.c_str(),
								cBpbcoutsendlist.m_cdtrbrnchid.c_str(),
								cBpbcoutsendlist.m_instddrctpty.c_str(), 
								pchMsg);
				}
			}
			else if(-2 == iRet)
			{
				Trace(L_INFO,  __FILE__,	__LINE__, NULL, "ԭҵ�����ڷ���ϵͳ��Ϊ�գ��ñ�ҵ���ɿͻ��˷��𣬲���ת�����ڡ�");
				// PMTS_ThrowException(OTH_ERR);
			}
		}
		
		cBpbcoutsendlist.closeCursor();
	}
	else if( 0 == strcmp("303" ,m_sMsgTp) || 0 == strcmp("CMT303" ,m_sMsgTp) )
	{
		CCmfreeinfo cCmfreeinfo;
		
		string strSql = "";
		strSql = " MESGID = '";
		strSql += m_ccms911.MsgId;
		strSql += "' and INSTGDRCTPTY = '";
		strSql += m_ccms911.OrigSndr + "'";

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql[%s]", strSql.c_str());
		
		SETCTX(cCmfreeinfo);
			
		iRet = cCmfreeinfo.find(strSql);
		if(OPERACT_SUCCESS != iRet)
		{
			 sprintf(m_szErrMsg, "cBpbcoutsendlist find fail:  [%d][%s]", 
				 iRet, cCmfreeinfo.GetSqlErr());
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		while(0 == cCmfreeinfo.fetch())
		{
			iRet = GetTagVal(strRval, cCmfreeinfo.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cCmfreeinfo.m_mbmsgid.c_str(), 22);
			
				//�жϼ�ֱ���������ֱ����������ͨѶ�� by add zql 
				//if(NULL != strstr(cCmfreeinfo.m_msgcnt.c_str(), "/REF/TFS ref./REFEND/"))
				if(strlen(cCmfreeinfo.m_mbmsgid.c_str()) == 22)
				{
				    DirectInter(cCmfreeinfo.m_instgindrctpty.c_str(), 
				    			cCmfreeinfo.m_instdindrctpty.c_str(), 
				    			cCmfreeinfo.m_instddrctpty.c_str(), 
				    			pchMsg, 
				    			cCmfreeinfo.m_sysid.c_str());
				}
			}
			else if(-2 == iRet)
			{
				Trace(L_INFO,  __FILE__,	__LINE__, NULL, "ԭҵ�����ڷ���ϵͳ��Ϊ�գ��ñ�ҵ���ɿͻ��˷��𣬲���ת�����ڡ�");
				// PMTS_ThrowException(OTH_ERR);
			}
		}
		
		cCmfreeinfo.closeCursor();
	}
	else if( 0 == strcmp("310", m_sMsgTp) || 0 == strcmp("311", m_sMsgTp) 
		  || 0 == strcmp("312", m_sMsgTp) || 0 == strcmp("313", m_sMsgTp)
     	  || 0 == strcmp("PKG012", m_sMsgTp) )
	{
		CCmcnotsgninfbiz cCmcnotsgninfbiz;
		
		string strSql = "";
		strSql = " MESGID = '";
		strSql += m_ccms911.MsgId;
		strSql += "' and INSTGDRCTPTY = '";
		strSql += m_ccms911.OrigSndr + "'";

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql[%s]", strSql.c_str());
		
		SETCTX(cCmcnotsgninfbiz);
			
		iRet = cCmcnotsgninfbiz.find(strSql);
		if(OPERACT_SUCCESS != iRet)
		{
			 sprintf(m_szErrMsg, "cBpbcoutsendlist find fail:  [%d][%s]", 
				 iRet, cCmcnotsgninfbiz.GetSqlErr());
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		while(0 == cCmcnotsgninfbiz.fetch())
		{
			iRet = GetTagVal(strRval, cCmcnotsgninfbiz.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cCmcnotsgninfbiz.m_mbmsgid.c_str(), 22);
			
				//�жϼ�ֱ���������ֱ����������ͨѶ�� by add zql 
				if(cCmcnotsgninfbiz.m_srcflag == "0")
				{
				    DirectInter(cCmcnotsgninfbiz.m_instgpty.c_str(), 
				    			cCmcnotsgninfbiz.m_instddrctpty.c_str(), 
				    			cCmcnotsgninfbiz.m_instdpty.c_str(), 
				    			pchMsg, 
					    		cCmcnotsgninfbiz.m_syscd.c_str());
				}
			}
			else if(-2 == iRet)
			{
				Trace(L_INFO,  __FILE__,	__LINE__, NULL, "ԭҵ�����ڷ���ϵͳ��Ϊ�գ��ñ�ҵ���ɿͻ��˷��𣬲���ת�����ڡ�");
				// PMTS_ThrowException(OTH_ERR);
			}
		}
		
		cCmcnotsgninfbiz.closeCursor();
	}	
	else if( 0 == strcmp("314", m_sMsgTp) || 0 == strcmp("315", m_sMsgTp)
	      || 0 == strcmp("CMT301", m_sMsgTp) || 0 == strcmp("CMT302", m_sMsgTp) )
	{
		CCmtransinfoqry cCmtransinfoqry;
		
		string strSql = "";
		strSql = " MESGID = '";
		strSql += m_ccms911.MsgId;
		strSql += "' and INSTGDRCTPTY = '";
		strSql += m_ccms911.OrigSndr + "'";

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql[%s]", strSql.c_str());
		
		SETCTX(cCmtransinfoqry);
			
		iRet = cCmtransinfoqry.find(strSql);
		if(OPERACT_SUCCESS != iRet)
		{
			 sprintf(m_szErrMsg, "cCmtransinfoqry find fail:  [%d][%s]", 
				 iRet, cCmtransinfoqry.GetSqlErr());
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		while(0 == cCmtransinfoqry.fetch())
		{
			iRet = GetTagVal(strRval, cCmtransinfoqry.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cCmtransinfoqry.m_mbmsgid.c_str(), 22);
		    
				//�жϼ�ֱ���������ֱ����������ͨѶ�� by add zql 
				//if(cCmtransinfoqry.m_qrytp == "QT01")
				if(strlen(cCmtransinfoqry.m_mbmsgid.c_str()) ==22)
				{
				    DirectInter(cCmtransinfoqry.m_instgindrctpty.c_str(),
				                cCmtransinfoqry.m_instdindrctpty.c_str(), 
				    			cCmtransinfoqry.m_instddrctpty.c_str(), 
				    			pchMsg, 
				    			cCmtransinfoqry.m_sysid.c_str());
			    }
			}
			else if(-2 == iRet)
			{
				Trace(L_INFO,  __FILE__,	__LINE__, NULL, "ԭҵ�����ڷ���ϵͳ��Ϊ�գ��ñ�ҵ���ɿͻ��˷��𣬲���ת�����ڡ�");
				// PMTS_ThrowException(OTH_ERR);
			}
		}
		
		cCmtransinfoqry.closeCursor();
	}
	else//����������ͨѶ��
	{
        Trace(L_INFO, __FILE__, __LINE__, NULL, "������������[%s]", m_sMsgTp);
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms911::InsertComsendmb()");
	
    return RTN_SUCCESS;
}

void CRecvCcms911::UpdateRsp()
{	
	
	if(0 == strcmp("381", m_sMsgTp) || 0 == strcmp("385", m_sMsgTp))
	{

		return;
		char strSQL[1024]={0};
		CBpcolltnchrgscl m_BpColltnchrgscl;
		SETCTX(m_BpColltnchrgscl);
		sprintf(strSQL," MESGID='%s'  ",m_ccms911.MsgId.c_str());
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL = [%s]",strSQL);
        int iRet = m_BpColltnchrgscl.find(strSQL);
        if (iRet != 0)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_COLLTNCHRGSCL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    	PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
	    }
	    iRet = m_BpColltnchrgscl.fetch();
	    if(iRet == SQLNOTFOUND)
		{
			Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������");
            m_BpColltnchrgscl.closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
		}
	    memset(strSQL,0x00,sizeof(strSQL));
	    sprintf(strSQL," MSGID='%s' and INSTGPTY ='%s' ",
						m_BpColltnchrgscl.m_orgnlmsgid.c_str(),
                        m_BpColltnchrgscl.m_orgnlinstgpty.c_str());
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL = [%s]",strSQL);
        iRet = m_BpColltnchrgscl.find(strSQL);
        if (iRet != 0)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_COLLTNCHRGSCL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    	PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
	    }
	    iRet = m_BpColltnchrgscl.fetch();
	    if(iRet == SQLNOTFOUND)
		{
			Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������");
            m_BpColltnchrgscl.closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
		}
	    //����ҵ������ԭҵ���ԭҵ��״̬              
		sprintf (m_strStrRsp,"UPDATE BP_COLLTNCHRGSCL t SET "
						"t.RSPFLAG = '1' "
                        " WHERE t.MSGID = '%s' and t.INSTGPTY = '%s'",                          
						m_BpColltnchrgscl.m_msgid.c_str(),
                        m_BpColltnchrgscl.m_instgpty.c_str());
                        
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strStrRsp = [%s]",m_strStrRsp);
	    
	    iRet = m_BpColltnchrgscl.execsql(m_strStrRsp);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_COLLTNCHRGSCL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE BP_COLLTNCHRGSCL is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	    m_BpColltnchrgscl.closeCursor();
	}
	if(0 == strcmp("383", m_sMsgTp) || 0 == strcmp("387", m_sMsgTp))
	{
		return;
		char strSQL[1024]={0};
		CBpcolltnchrgscl m_BpColltnchrgscl;
		SETCTX(m_BpColltnchrgscl);
		sprintf(strSQL," MESGID='%s' ",m_ccms911.MsgId.c_str());
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL = [%s]",strSQL);
        int iRet = m_BpColltnchrgscl.find(strSQL);
        if (iRet != 0)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_COLLTNCHRGSCL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    	PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
	    }
	    iRet = m_BpColltnchrgscl.fetch();
	    if(iRet == SQLNOTFOUND)
		{
			Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������");
            m_BpColltnchrgscl.closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
		}
	    memset(strSQL,0x00,sizeof(strSQL));
	    sprintf(strSQL," MSGID='%s' and INSTGPTY ='%s' ",
						m_BpColltnchrgscl.m_orgnlmsgid.c_str(),
                        m_BpColltnchrgscl.m_orgnlinstgpty.c_str());
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL = [%s]",strSQL);
        iRet = m_BpColltnchrgscl.find(strSQL);
        if (iRet != 0)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_COLLTNCHRGSCL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    	PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
	    }
	    iRet = m_BpColltnchrgscl.fetch();
	    if(iRet == SQLNOTFOUND)
		{
			Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������");
            m_BpColltnchrgscl.closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
		}
	    //����ҵ������ԭҵ���ԭҵ��״̬              
		sprintf (m_strStrRsp,"UPDATE BP_COLLTNCHRGSCL t SET "
						"t.RSPFLAG = '2' "
                        " WHERE t.MSGID = '%s' and t.INSTGPTY = '%s'",                          
						m_BpColltnchrgscl.m_msgid.c_str(),
                        m_BpColltnchrgscl.m_instgpty.c_str());
                        
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strStrRsp = [%s]",m_strStrRsp);
	    
	    iRet = m_BpColltnchrgscl.execsql(m_strStrRsp);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_COLLTNCHRGSCL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE BP_COLLTNCHRGSCL is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	    m_BpColltnchrgscl.closeCursor();
	}
	if(0 == strcmp("388", m_sMsgTp))
	{
		char strSQL[1024]={0};
		CBpbizpubntce m_CBpbizpubntce;
		//CBpcolltnchrgscl m_BpColltnchrgscl;
		SETCTX(m_CBpbizpubntce);
		sprintf(strSQL," MESGID = '%s'  ",m_ccms911.MsgId.c_str());
      	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL = [%s]",strSQL);      
      	int iRet = m_CBpbizpubntce.find(strSQL);    
      	if (iRet != 0)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_BIZPUBNTCE����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    	PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
	    }
	    iRet = m_CBpbizpubntce.fetch();
	    if(iRet == SQLNOTFOUND)
		{
			Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������");
            m_CBpbizpubntce.closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "m_CBpbizpubntceû���ҵ�����������ԭҵ��");
		}
	    memset(strSQL,0x00,sizeof(strSQL));
	    sprintf(strSQL," MSGID ='%s' and INSTGPTY='%s' ",
	                    m_CBpbizpubntce.m_orgnlmsgid.c_str(),
	                    m_CBpbizpubntce.m_orgnlinstgpty.c_str());  
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL = [%s]",strSQL);                 
	    CBpcolltnchrgscl m_BpColltnchrgscl;
	    SETCTX(m_BpColltnchrgscl);   
	    m_BpColltnchrgscl.find(strSQL);  
	    if (iRet != 0)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_cOLLTNCHRGSCL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    	PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
	    }
	    iRet = m_BpColltnchrgscl.fetch();
		if(iRet == SQLNOTFOUND)
		{
			Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������");
            m_BpColltnchrgscl.closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "m_BpColltnchrgsclû���ҵ�����������ԭҵ��");
		} 
		sprintf (m_strStrRsp,"UPDATE BP_COLLTNCHRGSCL t SET "
						"t.RSPFLAG = '2' "
                        " WHERE t.MSGID = '%s' and t.INSTGPTY = '%s'",                          
						m_BpColltnchrgscl.m_msgid.c_str(),
                        m_BpColltnchrgscl.m_instgpty.c_str());
                        
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strStrRsp = [%s]",m_strStrRsp);
	    
	    iRet = m_BpColltnchrgscl.execsql(m_strStrRsp);
	    if (iRet == SQLNOTFOUND)
	    {
	    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_COLLTNCHRGSCL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
	    }
	    else if (iRet != SQL_SUCCESS)
	    {
	        sprintf(m_szErrMsg,  
				"UPDATE BP_COLLTNCHRGSCL is error!iRet=[%d]", iRet);
			
	        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
			
	        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	    }
	    m_CBpbizpubntce.closeCursor();
	    m_BpColltnchrgscl.closeCursor();
	}
	if(0 == strcmp("389", m_sMsgTp))
	{
		CBpbizpubntce m_CBpbizpubntce;
        SETCTX(m_CBpbizpubntce);
		char strsql[1024] = {0}; 
		sprintf(strsql,"  MESGID = '%s' ",m_ccms911.MsgId.c_str());
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strsql = [%s]",strsql);
		int iRet = m_CBpbizpubntce.find(strsql);
		if(iRet != 0)
		{
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "û���ҵ�����������ԭҵ��MESGID =[%s],iRet=[%d],sqlErr=[%s]"
			, m_ccms911.MsgId.c_str()
			,iRet
			,m_CBpbizpubntce.GetSqlErr());
			PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
		}
		iRet = m_CBpbizpubntce.fetch();
		if(iRet == SQLNOTFOUND)
		{
			Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������");
            m_CBpbizpubntce.closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
		}
		memset(strsql,0x00,sizeof(strsql));
		sprintf(strsql," MSGID = '%s' and INSTGPTY = '%s'",m_CBpbizpubntce.m_orgnlmsgid.c_str(),m_CBpbizpubntce.m_orgnlinstgpty.c_str());
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strsql = [%s]",strsql);
		 
		CBpcolltnchrgscl m_CBpcolltnchrgscl;
		SETCTX(m_CBpcolltnchrgscl);
		iRet = m_CBpcolltnchrgscl.find(strsql);
		if(iRet != 0)
		{
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "û���ҵ�����������ԭҵ��MSGID =[%s],INSTGPTY=[%s]", m_CBpbizpubntce.m_orgnlmsgid.c_str(),m_CBpbizpubntce.m_orgnlinstgpty.c_str());
			PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
		}
		iRet = m_CBpcolltnchrgscl.fetch();
		if(iRet == SQLNOTFOUND)
		{
			Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������");
            m_CBpcolltnchrgscl.closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "m_CBpcolltnchrgsclû���ҵ�����������ԭҵ��");
		}
		char strmsgtp[35+1]={0};
		strcpy(strmsgtp,m_CBpcolltnchrgscl.m_msgtp.c_str());
		char orimsgtp[3+1]={0};
		strncpy(orimsgtp,strmsgtp+5,3);
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "orimsgtp =[%s]", orimsgtp);
		if(strcmp(orimsgtp,"381") == 0 || strcmp(orimsgtp,"385") == 0)
		{
			sprintf(m_strStrRsp, "UPDATE BP_COLLTNCHRGSCL t SET "
	                    "t.rspflag = '2' "
	                    " WHERE t.MSGID='%s' and t.INSTGDRCTPTY = '%s' ",
						m_CBpcolltnchrgscl.m_msgid.c_str(),
	                    m_CBpcolltnchrgscl.m_instgpty.c_str());
	     	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strStrRsp = [%s]",m_strStrRsp);
	    
		    int iRet = m_CBpcolltnchrgscl.execsql(m_strStrRsp);
		    if (iRet == SQLNOTFOUND)
		    {
		    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_COLLTNCHRGSCL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
		    }
		    else if (iRet != SQL_SUCCESS)
		    {
		        sprintf(m_szErrMsg,  
					"UPDATE BP_COLLTNCHRGSCL is error!iRet=[%d]", iRet);
				
		        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
				
		        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
		    } 
	    }
	    if(strcmp(orimsgtp,"382") == 0 || strcmp(orimsgtp,"386") == 0)
		{
			sprintf(m_strStrRsp, "UPDATE BP_COLLTNCHRGSCL t SET "
	                    "t.rspflag = '5' "
	                    " WHERE t.MSGID= '%s' and t.INSTGDRCTPTY = '%s' ",
						m_CBpcolltnchrgscl.m_msgid.c_str(),
	                    m_CBpcolltnchrgscl.m_instgpty.c_str());
	       	int iRet = m_CBpcolltnchrgscl.execsql(m_strStrRsp);
		    if (iRet == SQLNOTFOUND)
		    {
		    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_COLLTNCHRGSCL����û���ҵ�����orgnlmsgid=[%s],orgnlinstgpty=[%s]",m_CBpbizpubntce.m_orgnlmsgid.c_str(),m_CBpbizpubntce.m_orgnlinstgpty.c_str());
		    }
		    else if (iRet != SQL_SUCCESS)
		    {
		        sprintf(m_szErrMsg,  
					"UPDATE BP_COLLTNCHRGSCL is error!iRet=[%d]", iRet);
				
		        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
				
		        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
		    }   
	    }
	    m_CBpbizpubntce.closeCursor();
	    m_CBpcolltnchrgscl.closeCursor();
	}
	
}
void CRecvCcms911::UpdateOriBus()
{
	CBpcstctrctmgcl  m_CBpcstctrctmgcl;
		
    SETCTX(m_CBpcstctrctmgcl);
    
    char oriSql[1024]={0};
	
	sprintf(oriSql," MESGID = '%s' ",m_ccms911.MsgId.c_str());
	                           
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "oriSql = [%s]",oriSql);
	int iRet  =  m_CBpcstctrctmgcl.find(oriSql); 
	if(0 !=iRet)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_CSTCTRCTMGCL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "��BP_CSTCTRCTMGCL����û���ҵ�����");
	}
	iRet  =  m_CBpcstctrctmgcl.fetch();
	if(iRet == SQLNOTFOUND)
	{
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������");
        m_CBpcstctrctmgcl.closeCursor();
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "m_CBpcolltnchrgsclû���ҵ�����������ԭҵ��");
	}
	memset(oriSql,0x00,sizeof(oriSql));
	//MSGID, INSTGPTY, SRCFLAG, QRYOROPRTP
	sprintf(oriSql,"UPDATE BP_CSTCTRCTMGCL t SET "
					"t.STATETIME = sysdate,"
                    "t.BUSISTATE = '%s', "
                    "t.PROCSTATE = '%s' "
                    " WHERE t.MSGID = '%s' and t.INSTGPTY = '%s'", 
                    m_strApiState.c_str(),
                    m_strProcSts.c_str(),                               
					m_CBpcstctrctmgcl.m_orgnlmsgid.c_str(),
                    m_CBpcstctrctmgcl.m_orgnlinstgpty.c_str());
    iRet = m_CBpcstctrctmgcl.execsql(oriSql);
    if (iRet == SQLNOTFOUND)
    {
    	Trace(L_ERROR, __FILE__, __LINE__, NULL,"��BP_CSTCTRCTMGCL����û���ҵ�����[%s]",m_ccms911.MsgId.c_str());
    }
    else if (iRet != SQL_SUCCESS)
    {
        sprintf(m_szErrMsg,  
			"UPDATE BP_CSTCTRCTMGCL is error!iRet=[%d]", iRet);
		
        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg);
		
        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
    }
    m_CBpcstctrctmgcl.closeCursor();
}
