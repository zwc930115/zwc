/********************************************************************
�ļ�����send315.cpp
�����ˣ�handongfeng
��  �ڣ�2011.01.14
��  ����
��  ����
Copyright (c) 2009  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendccms315.h"

CSendCcms315::CSendCcms315(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{
}

CSendCcms315::~CSendCcms315()
{

}

void CSendCcms315::AddSign315()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms315::AddSign315");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_ccms315.getOriSignStr();
	
	AddSign(m_ccms315.m_sSignBuff.c_str(), 
					sSignedStr, 
					RAWSIGN,
					m_ccms315.InstgDrctPty.c_str());
	
	m_ccms315.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms315::AddSign315");
}


void CSendCcms315::SetDBKey()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms315::SetDBKey...");
	
	string  strSys = "";
	
	strSys = m_szSysFlagNO;
	
	Upper(strSys);
	m_Cmtransqry.m_sysid = strSys;
	m_Cmtransqry.m_msgid = m_szMsgFlagNO; 
	m_Cmtransqry.m_instgindrctpty = m_szSndNO;
	m_Cmtransqry.m_rsflag = "1";
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Cmtransqry.m_sysid = [%s]", m_Cmtransqry.m_sysid.c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Cmtransqry.m_msgid = [%s]", m_Cmtransqry.m_msgid.c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Cmtransqry.m_instgindrctpty = [%s]", m_Cmtransqry.m_instgindrctpty.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms315::SetDBKey...");
	return;
}

void CSendCcms315::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms315::SetData...");
    
    char sAmount[255] = {0};
    int iSysflg = -1;
    int iRet = -1;
    chgSysCd(m_szSysFlagNO,iSysflg); 
    iRet = GetIsoDateTime(m_dbproc, iSysflg, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }
    char szSyscd[4+1] = {0};
    strcpy(szSyscd,m_Cmtransqry.m_sysid.c_str());
    StrUpperCase_ZFPT(szSyscd);
    
    // �鱨��ͷ
    m_ccms315.CreateXMlHeader(szSyscd,                        \
                                m_Cmtransqry.m_wrkdate.c_str(), \
                                m_Cmtransqry.m_instgdrctpty.c_str(),\
                                m_Cmtransqry.m_instddrctpty.c_str(),\
                                "ccms.315.001.01",              \
                                m_sMesgId.c_str()); 

	m_ccms315.MsgId				= m_Cmtransqry.m_msgid;
	m_ccms315.CreDtTm			= m_ISODateTime;
	m_ccms315.InstgDrctPty		= m_Cmtransqry.m_instgdrctpty;
	m_ccms315.GrpHdrInstgPty		= m_Cmtransqry.m_instgindrctpty;
	m_ccms315.InstdDrctPty		= m_Cmtransqry.m_instddrctpty;
	m_ccms315.GrpHdrInstdPty		= m_Cmtransqry.m_instdindrctpty;
	m_ccms315.SysCd				= m_Cmtransqry.m_sysid;
	m_ccms315.Rmk				= "";
	m_ccms315.BizRspnOrgnlMsgId	= m_Cmtransqry.m_qorgnlmsgid;
	m_ccms315.BizRspnOrgnlInstgPty= m_Cmtransqry.m_qorgnlinstgdrctpty;
	m_ccms315.BizRspnOrgnlMT    = "ccms.314.001.01";

	if (strcmp(m_Cmtransqry.m_sysid.c_str(), "HVPS") == 0)
	{
		m_ccms315.QryTp				= "";
	}
	else
	{
		m_ccms315.QryTp				= m_Cmtransqry.m_qrytp;
	}
    
    /*С��鸴*/
    if( "BEPS" == m_Cmtransqry.m_sysid && "QT01" == m_Cmtransqry.m_qrytp )
    {
     	m_ccms315.OrgnlInfOrgnlMsgId	= m_Cmtransqry.m_orgnlmsgid;
	    m_ccms315.OrgnlInfOrgnlInstgPty = m_Cmtransqry.m_orgnlinstgdrctpty;
	    m_ccms315.OrgnlInfOrgnlMT       = m_Cmtransqry.m_orgnlmsgtp;   
        
	    m_ccms315.InstgIndrctPty	= m_Cmtransqry.m_orgninstgindrctpty;
	    m_ccms315.InstdIndrctPty	= m_Cmtransqry.m_orgninstdindrctpty;
	    m_ccms315.OrgnlTxId			= m_Cmtransqry.m_orgnltxmsgid;
	    m_ccms315.OrgnlTxTpCd		= m_Cmtransqry.m_oripmttpprtry;
	}
	else
	{
	    m_ccms315.OrgnlInfOrgnlMsgId	= m_Cmtransqry.m_orgnlmsgid;
	    m_ccms315.OrgnlInfOrgnlInstgPty = m_Cmtransqry.m_orgnlinstgdrctpty;
	    m_ccms315.OrgnlInfOrgnlMT       = m_Cmtransqry.m_orgnlmsgtp;
	}
	
	m_ccms315.Ccy	   = m_Cmtransqry.m_qryccy;
	m_ccms315.OrgnlAmt = ftoa(sAmount,m_Cmtransqry.m_qryamt, 2);
	m_ccms315.Cntt     = m_Cmtransqry.m_msgcnt;
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms315::SetData...");
    return;
}

int CSendCcms315::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms315::GetData...");
    m_Cmtransqry.setctx(m_dbproc);

    SetDBKey();
    char strSql[1024*4]={0};
    sprintf(strSql,"MSGID='%s' and INSTGINDRCTPTY='%s' and SYSID='%s' ",
                    m_Cmtransqry.m_msgid.c_str(),
                    m_Cmtransqry.m_instgindrctpty.c_str(),
                    m_Cmtransqry.m_sysid.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=[%s]",strSql);
    int iRet = m_Cmtransqry.find(strSql);
    if(iRet !=0) 
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��,iRet=%d, %s", iRet, m_Cmtransqry.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);	
	}
	iRet = m_Cmtransqry.fetch();
	if(iRet ==SQLNOTFOUND)
	{
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������");
        m_Cmtransqry.closeCursor();
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "cm_transinfoqryû���ҵ�����������ҵ��");
	}              
    //int iRet = m_Cmtransqry.findByPK();
   /* if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��,iRet=%d, %s", iRet, m_Cmtransqry.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }
	*/
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms315::GetData...");
    return iRet;
}

int CSendCcms315::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms315::UpdateState...");
    
    string strNpcMsg = "";
	int nSysID = m_Cmtransqry.m_sysid == "BEPS" ? SYS_BEPS : SYS_HVPS;
	if(!m_Cmtransqry.write_blob(m_ccms315.m_sXMLBuff.c_str(), strNpcMsg, nSysID)){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"д���ֶα�����:[%s]", m_Cmtransqry.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}

    //���ｫί��������Ϊ��̬����д�����ݿ� �������
    char szIOSdate[10 + 1] = {0};
    chgToISODate(m_Cmtransqry.m_consigndate.c_str(), szIOSdate);
    
	SetDBKey();
    string strSQL;
	strSQL += "UPDATE cm_transinfoqry t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_08;
    strSQL += "', t.npcmsg='";
    strSQL += strNpcMsg;
	strSQL += "', t.RSPFLAG = '1', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
	strSQL += "', t.FINALSTATEDATE = '";
    strSQL += szIOSdate;
    strSQL += "', t.statetime = sysdate";
    
	strSQL += " WHERE t.MSGTP = '";
	strSQL += m_Cmtransqry.m_msgtp.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_Cmtransqry.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Cmtransqry.m_instgindrctpty.c_str(); 									
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    int iRet = m_Cmtransqry.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��,iRet=%d, %s", iRet, m_Cmtransqry.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms315::UpdateState...");
    return RTN_SUCCESS;
}


int CSendCcms315::UpdateOriState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms315::UpdateOriState...");

    string strSQL;
	strSQL += "UPDATE cm_transinfoqry t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_31 ; 
    strSQL += "', t.RSPFLAG = '1', t.statetime=sysdate";
	strSQL += " WHERE t.RSFLAG = '2'";
    strSQL += " AND t.SYSID = '";
	strSQL += m_Cmtransqry.m_sysid.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_Cmtransqry.m_qorgnlmsgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Cmtransqry.m_qorgnlinstgdrctpty.c_str(); 									
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    int iRet = m_Cmtransqry.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��,iRet=%d, %s", iRet, m_Cmtransqry.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms315::UpdateOriState...");
    return RTN_SUCCESS;
}



int CSendCcms315::doWorkSelf()
{
   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms315::doWork...");

    int iRet = 0;

    GetData();
    
    SetData();

    //��ǩ
    if(2 == m_iVersion)
    {
        AddSign315();
    }

    iRet = m_ccms315.CreateXml();
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    UpdateState();
    
    //�յ�900ȷ�ϱ��ĺ����޸�������ѯ��״̬��
    //UpdateOriState();
    
    AddQueue(m_ccms315.m_sXMLBuff.c_str(), m_ccms315.m_sXMLBuff.length());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms315::doWork..."); 
    return RTN_SUCCESS;
}


