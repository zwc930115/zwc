/******************************************************************** 
文件名： recvcmt310.h
创建人： handongfeng
日  期： 2011-04-28
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 


#ifndef _RECVCMT310_H_
#define _RECVCMT310_H_

#include "recvccmsbase.h"
#include "cmt310.h"
#include "hvsealerr.h"

class CRecvCmt310 : public CRecvCcmsBase
{
	
public:
	CRecvCmt310();
	~CRecvCmt310();

	//业务入口函数
	INT32 Work(LPCSTR sMsg);

	//解析报文串
	INT32 unPack(LPCSTR sMsg);

    void  UpdateOrgnBuss();
    
private:
    cmt310          m_cmt310;
    CHvsealerr      m_hvsealerr;

};

#endif


