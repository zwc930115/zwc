/********************************************************************
�ļ�����send315.h
�����ˣ�handongfeng
��  �ڣ�2011.01.14
��  ����
��  ����
Copyright (c) 2009  YLINK
********************************************************************/
#ifndef __SENDCCMS315_H__
#define __SENDCCMS315_H__

#include "sendccmsbase.h"
#include "ccms315.h"
#include "cmtransinfoqry.h"

class CSendCcms315 : public CSendCcmsBase
{
public:
	CSendCcms315(const stuMsgHead& Smsg);
	~CSendCcms315();
	int doWorkSelf();
private:
	void AddSign315();
	void SetData();
	int GetData();
	void SetDBKey();
	int UpdateState();
	int UpdateOriState();

private:
	CCmtransinfoqry m_Cmtransqry;
	ccms315         m_ccms315;
};

#endif


