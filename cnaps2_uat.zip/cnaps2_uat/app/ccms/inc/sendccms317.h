/********************************************************************
�ļ�����send317.h
�����ˣ�handongfeng
��  �ڣ�2011.01.14
��  ����
��  ����
Copyright (c) 2009  YLINK
********************************************************************/
#ifndef __SENDCCMS317_H__
#define __SENDCCMS317_H__

#include "sendccmsbase.h"
//#include "parser317.h"
#include "cmtransstqry.h"

class CSendCcms317 : public CSendCcmsBase
{
public:
	CSendCcms317(const stuMsgHead& Smsg);
	~CSendCcms317();
	int doWorkSelf();
private:
	void SetData();
	int GetData();
	int UpdateState();
	void AddSign317();

private:
	CCmtransstqry m_Hvsndlist;
	PARSER317 m_cParser317;
};

#endif


