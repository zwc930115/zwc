/********************************************************************
�ļ�����send805.h
�����ˣ�handongfeng
��  �ڣ�2011.01.14
��  ����
��  ����
Copyright (c) 2009  YLINK
********************************************************************/

#ifndef __SENDCCMS805_H__
#define __SENDCCMS805_H__

#include "sendccmsbase.h"
#include "ccms805.h"
#include "cmlogon.h"
#include "hvsapbankinfo.h"
#include "bpsapbankinfo.h"

class CSendCcms805 : public CSendCcmsBase
{
public:
	CSendCcms805(const stuMsgHead& Smsg);
	~CSendCcms805();
	int doWorkSelf();
private:
	void AddSign805();
	void SetData();
	int GetData();
	void SetDBKey();
	int UpdateState();
	
	void	UnPack(LPCSTR szMsg);
	
	void	PackIbpsXML();
	
	void	CheckValues();
	
	void	SetOrigenStr();
	
	void	SetReturnClient();
	
	ccms805	 occms805;
private:
	CCmlogon  oCCmlogon;
	ccms805   m_ccms805;
	
	CHvsapbankinfo m_Hvsapbankinfo;
	CBpsapbankinfo m_Bpsapbankinfo;
};

#endif


