/********************************************************************
�ļ�����send991.h
�����ˣ�handongfeng
��  �ڣ�2011.01.14
��  ����
��  ����
Copyright (c) 2009  YLINK
********************************************************************/

#ifndef __SENDCCMS991_H__
#define __SENDCCMS991_H__

#include "sendccmsbase.h"
#include "ccms991.h"
#include "cmchckreqrspn.h"
#include "time.h"
class CSendCcms991 : public CSendCcmsBase
{
public:
    CSendCcms991(const stuMsgHead& Smsg);
    ~CSendCcms991();
    int doWorkSelf();
private:
    void SetData();
    int GetData();
    int UpdateState();
    void SetDBKey();
private:
    time_t stingToTime(const char * szTime);
    CCmchckreqrspn m_Cmchckreqrspn;
    ccms991     m_ccms991;
};

#endif



