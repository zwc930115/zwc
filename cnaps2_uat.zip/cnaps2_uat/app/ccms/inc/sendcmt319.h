/******************************************************************** 
�ļ����� sendcmt319.h
�����ˣ� handonfeng
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef __SENDCMT319_H__
#define __SENDCMT319_H__

#include "cmt319.h"
#include "cmpmtrtrcl.h"
#include "cmpmtrtrlist.h"
#include "sendccmsbase.h"

class CSendCmt319 : public CSendCcmsBase
{
public:
    CSendCmt319(const stuMsgHead& Smsg);
    ~CSendCmt319();
    
    int  doWorkSelf();
    
private:
    int buildCmtMsg();
	int GetData();
	INT32 SetData();
    int UpdateState();

    cmt319              m_cmt319;
    CCmpmtrtrcl m_cmpmtrtrcl;
	CCmpmtrtrlist m_cmpmtrtrlist;
};

#endif


