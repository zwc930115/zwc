#ifndef __RECVCCMSWORK_H__
#define __RECVCCMSWORK_H__

#include "basicapi.h"

class CRecvCcmsWork
{
public:
    CRecvCcmsWork();
    ~CRecvCcmsWork();

    void setData(LPTSTR lpMsgID, int iErrMsgFlag = 0, UINT32 len = 0, LPCSTR data = NULL, LPCSTR lpTrsCode = NULL, LPCSTR lpMsgFile = NULL);

	INT32 GetMsg(void);
	
    void clear();
	
    INT32 doWork();

private:
    string m_sTrsCode;  //交易码如CMT101
    string m_sMsgFile;  //处理文件报文
    VCHAR  m_vData;     //报文内容，只要内存够大，都可以放下
    string m_strMsgID;  //MSGID
    int    m_iErrMsgFlag;  //异常消息标志
};


#endif


