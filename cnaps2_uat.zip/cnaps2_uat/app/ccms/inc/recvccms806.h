/********************************************************************
�ļ�����recvccms806.h
�����ˣ�handongfeng
��  �ڣ�2010.04.10
�޸��ˣ�
��  �ڣ�
��  ����
��  ����
Copyright (c) 2010  YLINK
********************************************************************/

#ifndef _RECVCCMS806_H_
#define _RECVCCMS806_H_

#include "recvccmsbase.h"
#include "ccms806.h"
#include "cmlogon.h"
#include "bpsapbankinfo.h"
#include "hvsapbankinfo.h"

class CRecvCcms806  : public CRecvCcmsBase
{
public:
    CRecvCcms806();
	
    ~CRecvCcms806(){};
	
private:
    INT32 Work(LPCSTR szMsg);
	
    void UnPack(LPCSTR szMsg);

    virtual INT32 SetData(LPCSTR pchMsg);
    
    virtual INT32 InsertData(void);
    
	//void	CheckValues();
	
    void UpdateSate();

    int GetLogOn();

    void SetLogOnKey();
    
	ccms806	occms806;
    CCmlogon    oCmlogon;
    CHvsapbankinfo m_Hvsapbankinfo;
    CBpsapbankinfo m_Bpsapbankinfo;
    string m_state;
};



#endif 

