/********************************************************************
�ļ�����recvccms803.h
�����ˣ�handongfeng
��  �ڣ�2011.01.14
��  ����
��  ����
Copyright (c) 2009  YLINK
********************************************************************/
#ifndef __RECVCCMS803_H__
#define __RECVCCMS803_H__

#include "recvccmsbase.h"
#include "ccms803.h"
#include "cmbankstat.h" 
#include "cmnodestat.h" 

class CRecvCcms803:public CRecvCcmsBase
{   
	
public:
	CRecvCcms803();
	~CRecvCcms803(){};
private:
	INT32 Work(LPCSTR szMsg);
    
	INT32 SetData(LPCSTR pchMsg);

    char* chgBankStatus(char const * _pIBankStatus, char* pOBankStatus);
    
	void UnPack(LPCSTR  szMsg);

	INT32 InsertData();

    void SetNodeStat(string strBankCode);

    int SetBankStat(string &strBankCode);
    
	CCmbankstat oCBankstat;
	CCmnodestat oCmnodestat;
	ccms803 oCcms803;
 
};

#endif


