/********************************************************************
文件名：sendhvpsbase.h
创建人：handongfeng
日  期：2011.01.14
描  述：
版  本：
Copyright (c) 2009  YLINK
********************************************************************/
#ifndef __SENDCCMSBASE_H__
#define __SENDCCMSBASE_H__

#include "pubfunc.h"
#include "logger.h"
#include "exception.h"
#include "cmrecvmsg.h"

#include "mqagent.h"

using namespace ZFPT;

class CSendCcmsBase
{
public:
    CSendCcmsBase(const stuMsgHead& Smsg);
    virtual ~CSendCcmsBase();

    int doWork();
	
    void GetTag1ST(const string& QryVal, string& OutVal, const string& QryStr);

	void GetSapBkToCCPC(DBProc &dbproc, string sSapBank, char* sCCPCCode);

    void SendToMB(stuSndMsg SndMsg);

    char    m_MQMsgId[64];
    
protected:
	virtual int doWorkSelf() = 0;
	
	virtual int GetData() = 0;
	
    virtual int UpdateState() = 0;

	void InitSysParam();

	int AddQueue(string msgtx, int length);

	int AddSign(const char *srcSign, char *dstSign, int iFlag,const char * pSendSapbank);
	
	DBProc m_dbproc;
    char m_szMsgFlagNO[29];   //报文标识号
    char m_szMsgType[3+1];    //报文格式
    char m_szMsgTypeFlag[3+1];//报文编号
    char m_MsgTypeCode[21];   //
    char m_szSndNO[15];       //发起参与机构
    char m_szSysFlagNO[5];    //系统标识号
    int m_iVersion;
    char m_szConsignDate[8 + 1];//委托日期
    char m_szMsgSerial[28 - 8 + 1];
    string m_sMesgId; //通讯级ID
    string m_sEndtoEnd;//端到端标识号
    char m_ISODateTime[19+1];//系统时间
	char m_sWorkDate[8 + 1];
    char m_sErrMsg[1024+1];
	string m_strSendMsg;
	char m_szOprUser[20+1];//最终操作用户
	char m_szOprUserNetId[20+1]; //用户所属机构
	char m_szSrcflg[1+1];//业务来源标志
	
	
private:    
	MQAgent         m_cMQAgent;
	
    CCmrecvmsg		m_cmrecv;

	void			GetDBConnect(void);
	
	void			GetMqConn(void);
};

#endif

