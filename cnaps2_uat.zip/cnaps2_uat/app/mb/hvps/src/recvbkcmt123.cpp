/******************************************************************** 
�ļ����� recvcmt123.cpp
�����ˣ� aps-xcm
��  �ڣ� 2011-06-23
�޸��ˣ� 
��  �ڣ� 
��  ���� ������˴������л�Ʊ�����ʽ𻮻ر���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 


#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkcmt123.h"

using namespace ZFPT;

CRecvBkCmt123::CRecvBkCmt123()
{
    m_strMsgTp = "CMT123";
}

CRecvBkCmt123::~CRecvBkCmt123()
{

}


INT32 CRecvBkCmt123::unPack(LPCSTR sMsg)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvBkCmt123::unPack...");
    Trace(L_INFO, __FILE__, __LINE__, NULL, "receive sMsg[%s]", sMsg);
    // 1�������Ƿ�Ϊ��
    if(NULL == sMsg || '\0' == sMsg)
    {
        Trace(L_ERROR, __FILE__, __LINE__, m_strBizCode.c_str(), "����Ϊ��");
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");   
    }

    int iRet = RTN_FAIL;

    //2.��������

    iRet = m_cCmt123.ParseCmt(sMsg);

    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "���Ľ���ʧ��");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ���ʧ��");
    }

    char szTxssno[8 + 1] = {0};
    sprintf(szTxssno, "%08d", m_cCmt123.iTxssno);
    // ���ı�ʶ��,����д�����ļ�����
    m_strMsgID = m_cCmt123.sConsigndate;
    m_strMsgID += szTxssno;
    ZFPTLOG.SetLogInfo("123", m_strMsgID.c_str());

	/*
    //��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ȡ��������ʧ��");
        PMTS_ThrowException(OPT_GET_DATE_FAIL);
    }
    */
    m_strWorkDate = m_sWorkDate;

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvBkCmt123::unPack...");

    return RTN_SUCCESS;
}


INT32 CRecvBkCmt123::SetData(LPCSTR pchMsg)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvBkCmt123::SetData...");

    m_cHvrcvexchglist.m_workdate        = m_strWorkDate;//��������
    m_cHvrcvexchglist.m_consigndate     = m_cCmt123.sConsigndate;//ί������
    m_cHvrcvexchglist.m_msgtp           = m_strMsgTp;//��������
	m_cHvrcvexchglist.m_mesgid         = m_cCmt123.GetHeadMesgID();
	m_cHvrcvexchglist.m_mesgrefid      = m_cCmt123.GetHeadMesgReqNo();
    m_cHvrcvexchglist.m_msgid           = m_strMsgID;//���ı�ʶ��
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgID= [%s]",m_strMsgID.c_str());
    //m_cHvrcvexchglist.m_endtoendid     = ;//�˵��˱�ʶ��
    m_cHvrcvexchglist.m_instgdrctpty     = m_cCmt123.sSendsapbk;//����ֱ�Ӳ������
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSendsapbk= [%s]",m_cCmt123.sSendsapbk);
    m_cHvrcvexchglist.m_instgindrctpty   = m_cCmt123.sSendbank;//����������
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSendbank= [%s]",m_cCmt123.sSendbank);
    m_cHvrcvexchglist.m_instddrctpty     = m_cCmt123.sRecvsapbk;//����ֱ�Ӳ������
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sRecvsapbk= [%s]",m_cCmt123.sRecvsapbk);
    m_cHvrcvexchglist.m_instdindrctpty   = m_cCmt123.sRecvbank;//���ղ������
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sRecvbank= [%s]",m_cCmt123.sRecvbank);
    m_cHvrcvexchglist.m_sttlmprty        = m_cCmt123.GetPayPRI();//ҵ�����ȼ�
    m_cHvrcvexchglist.m_dbtmmbid        = m_cCmt123.sSendsapbk;//�����������к�
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSendsapbk= [%s]",m_cCmt123.sSendsapbk);
    //m_cHvrcvexchglist.m_dbtnm            = m_cCmt123.sPayername;//����������
    SetGbkToUtf8(m_cCmt123.sPayername, m_cHvrcvexchglist.m_dbtnm);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayername= [%s]",m_cCmt123.sPayername);
    m_cHvrcvexchglist.m_dbtracctid       = m_cCmt123.sPayeracc;//�������˺�
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayeracc= [%s]",m_cCmt123.sPayeracc);
    m_cHvrcvexchglist.m_dbtid            = m_cCmt123.sPayopenbk;//�����к� �== �����˿����к�
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayopenbk= [%s]",m_cCmt123.sPayopenbk);
    m_cHvrcvexchglist.m_dbtrissr         = m_cCmt123.sPayopenbk;//�����˿����к�
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayopenbk= [%s]",m_cCmt123.sPayopenbk);
    m_cHvrcvexchglist.m_cdtmmbid        = m_cCmt123.sRecvsapbk;//�տ������к�
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sRecvsapbk= [%s]",m_cCmt123.sRecvsapbk);
    //m_cHvrcvexchglist.m_cdtrnm           = ;//�տ�������
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayeename= [%s]",);
    //m_cHvrcvexchglist.m_cdtracctid       = m_cCmt123.sPayeeacc;//�տ����˺�
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayeeacc= [%s]",m_cCmt123.sPayeeacc);
    m_cHvrcvexchglist.m_cdtid            = m_cCmt123.sPayeeopenbk;//�տ����к�
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayeeopenbk= [%s]",m_cCmt123.sPayeeopenbk);
    m_cHvrcvexchglist.m_cdtrissr         = m_cCmt123.sPayeeopenbk;//�տ��˿������к�
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayeeopenbk= [%s]",m_cCmt123.sPayeeopenbk);
    m_cHvrcvexchglist.m_procstate        = PR_HVBP_08;//����״̬
    m_cHvrcvexchglist.m_amount           = m_cCmt123.dAmount;//���׽��
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "dAmount= [%f]",m_cCmt123.dAmount);
    m_cHvrcvexchglist.m_currency         = m_cCmt123.sCur;//���ҷ���
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sCur= [%s]",m_cCmt123.sCur);
    
    m_cHvrcvexchglist.m_ctgypurpprtry  = "12300";//ҵ�����ͱ���
    //m_cHvrcvexchglist.m_finalstatedate = ;//��������
    m_cHvrcvexchglist.m_purpprtry        = "12300";//ҵ���������
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sTradetype= [%s]",);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sRecvcenter= [%s]",m_cCmt123.sRecvsenter);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSendcenter= [%s]",m_cCmt123.sSendsenter);
    m_cHvrcvexchglist.m_msgdirect = "0";
	
    m_cHvrcvexchglist.m_busistate        = "";//ҵ��״̬
    //m_cHvrcvexchglist.m_processcode    = ;//ҵ������
    //m_cHvrcvexchglist.m_rjctinf        = ;//ҵ��ܾ���Ϣ
    //m_cHvrcvexchglist.m_acctstate      = ;//����״̬
    //m_cHvrcvexchglist.m_statetime      = ;//����״̬���ʱ��
    //m_cHvrcvexchglist.m_acstatetime    = ;//����״̬���ʱ��
    //m_cHvrcvexchglist.m_acctregnum     = ;//������ˮ��
    //m_cHvrcvexchglist.m_checkstate     = ;//��NPC����״̬
    //m_cHvrcvexchglist.m_mbcheckstate   = ;//�����ڶ���״̬
    
    m_cHvrcvexchglist.m_ustrdstr        += "30B:";//������
    m_cHvrcvexchglist.m_ustrdstr        += m_cCmt123.sBilldate;
    m_cHvrcvexchglist.m_ustrdstr        += ":21A:";
    m_cHvrcvexchglist.m_ustrdstr        += m_cCmt123.sBillno;
    m_cHvrcvexchglist.m_ustrdstr        += ":C10:";
    m_cHvrcvexchglist.m_ustrdstr        += m_cCmt123.sDraftmac;
    m_cHvrcvexchglist.m_ustrdstr        += ":33C:";
    char szTemp[15 + 1] = {0};
    sprintf(szTemp, "%f", m_cCmt123.dTicketamount);
    m_cHvrcvexchglist.m_ustrdstr        += szTemp;
    m_cHvrcvexchglist.m_ustrdstr        += ":CNV:";
    memset(szTemp, 0, 16);
    sprintf(szTemp, "%f", m_cCmt123.dSapamount);
    m_cHvrcvexchglist.m_ustrdstr        += szTemp;
    m_cHvrcvexchglist.m_ustrdstr         += ":59E:";
    m_cHvrcvexchglist.m_ustrdstr        += m_cCmt123.sLastholdno;
    m_cHvrcvexchglist.m_ustrdstr        += ":59D:";
    m_cHvrcvexchglist.m_ustrdstr        += m_cCmt123.sLastholdname;
    m_cHvrcvexchglist.m_ustrdstr        += ":30C:";
    m_cHvrcvexchglist.m_ustrdstr        += m_cCmt123.sTippaydate;
    //m_cHvrcvexchglist.m_addinfo              = m_cCmt123.sRemark;//��ע
    SetGbkToUtf8(m_cCmt123.sRemark, m_cHvrcvexchglist.m_addinfo);
    //m_cHvrcvexchglist.m_reserve        = ;//������
    //m_cHvrcvexchglist.m_npcmsg         = ;//NPC����
    //m_cHvrcvexchglist.m_mbmsg          = ;//MB����
    //int m_printno                      = ;//��ӡ����
    //m_cHvrcvexchglist.m_iststatetime   = ;//���ʱ��
    //m_cHvrcvexchglist.m_isrbflg        = ;//�Ƿ��˻��־
    //m_cHvrcvexchglist.m_recvdest       = ;//����Ŀ��
    //m_cHvrcvexchglist.m_dbtaddr        = m_cCmt123.sPayeraddr;//�����˵�ַ
    SetGbkToUtf8(m_cCmt123.sPayeraddr, m_cHvrcvexchglist.m_dbtaddr);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayeraddr= [%s]",m_cCmt123.sPayeraddr);
    //m_cHvrcvexchglist.m_cdtaddr          = ;//�տ��˵�ַ
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayeeaddr= [%s]",m_cCmt122.sPayeeaddr);
    //m_cHvrcvexchglist.m_srcflag        = "0";//������־ 0:���� 1:���˲���

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkCmt123::SetData...");

    return RTN_SUCCESS;
}


INT32 CRecvBkCmt123::InsertData(void)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvBkCmt123::InsertData...");

    int iRet = RTN_FAIL;
    
    //��������
    iRet = m_cHvrcvexchglist.setctx(m_dbproc);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, m_strMsgID.c_str(), "setctx error");
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }

    //�������ݿ�
    if(RTN_SUCCESS != m_cHvrcvexchglist.insert())
    {
        sprintf(m_szErrMsg, "������ʻ����ϸ��hv_rcvexchglist��������ʧ��[%s], [%d][%s]",
            m_strMsgID.c_str(), iRet, m_cHvrcvexchglist.GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
        
    }

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvBkCmt123::InsertData...");

    return RTN_SUCCESS;
    
}

INT32 CRecvBkCmt123::Work(LPCSTR sMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkCmt123::Work()");

    // 1.��������
    unPack(sMsg);
    
    // 2.��m_cHvrcvexchglist�ĳ�Ա��ֵ
    SetData(sMsg);

    AddMac();

    buildCmtMsg();

    // 4.����������ʻ����ϸ��hv_rcvexchglist����������
    InsertData();    
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkCmt123::Work()");

    return RTN_SUCCESS;
}

int CRecvBkCmt123::ChkMac()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkCmt123::ChkMac...");
	int iRet = -1;
	
	m_cCmt123.SetSeal();//��ȡ��Ѻ��

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt123.sRecvsapbk[%s]",m_cCmt123.sRecvsapbk);
	
    iRet = CheckMac(m_dbproc,m_cCmt123.GetMacStr(),m_cCmt123.m_Seal.c_str(),m_cCmt123.sRecvsapbk);
    if(0 != iRet)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ChkMac failed");
    	PMTS_ThrowException(OPT_CHECKSIGN_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]",m_cCmt123.m_szMacStr);
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkCmt123::ChkMac..."); 
    
    return RTN_SUCCESS;
}

int CRecvBkCmt123::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvbkCmt123::buildCmtMsg...");

    int iRet = m_cCmt123.CreateCmt("123", m_cHvrcvexchglist.m_instgdrctpty.c_str(), m_cHvrcvexchglist.m_instddrctpty.c_str(), m_strMsgID.c_str(), m_strMsgID.c_str(), m_cHvrcvexchglist.m_workdate.c_str(), m_cHvrcvexchglist.m_sttlmprty.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }

    m_bifmac = true;
    m_macMsg = m_cCmt123.m_strCmtmsg;
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvbkCmt123::buildCmtMsg...");
    return iRet;
}

int CRecvBkCmt123::AddMac()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbkCmt123::AddMac...");
	int iRet = -1;
	
	m_cCmt123.SetSeal();//获取密押串

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt123.sSendsapbk[%s]",m_cCmt123.sSendsapbk);
	
    iRet = CodeMac(m_dbproc,m_cCmt123.m_Seal.c_str(),m_cCmt123.m_szMacStr);
    if(0 != iRet)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "AddMac failed");
    	PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]",m_cCmt123.m_szMacStr);
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbkCmt123::AddMac..."); 
    
    return RTN_SUCCESS;
}

