/******************************************************************** 
�ļ����� recv712.cpp
�����ˣ� yszhong
��  �ڣ� 2011-03-18
�޸��ˣ� 
��  �ڣ� 
��  ���� ������˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkhvps712.h"

using namespace ZFPT;

CRecvBkHvps712::CRecvBkHvps712()
{

    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps712::CRecvBkHvps712()");
}


CRecvBkHvps712::~CRecvBkHvps712()
{
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps712::~CRecvBkHvps712()");
}

INT32 CRecvBkHvps712::Work(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps712::doWork()");
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "level CRecvBkHvps712::doWork()");

	//do nothing
	return RTN_SUCCESS;
}



