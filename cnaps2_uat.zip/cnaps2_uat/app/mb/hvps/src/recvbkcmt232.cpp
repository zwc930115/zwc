/******************************************************************** 
�ļ����� recvcmt232.cpp
�����ˣ� aps-hhc
��  �ڣ� 2012-04-10
�޸��ˣ� 
��  �ڣ� 
��  ���� ��ʱת�ʽ��֪ͨ����
��  ���� 
Copyright (c) 2012  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkcmt232.h"

using namespace ZFPT;

CRecvBkCmt232::CRecvBkCmt232()
{
    m_strMsgTp = "CMT232";
}

CRecvBkCmt232::~CRecvBkCmt232()
{

}

INT32 CRecvBkCmt232::Work(LPCSTR sMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkCmt232::Work()");

    // 1.��������
    unPack(sMsg);
    
    // 2.��m_cHvtrofacsndlist�ĳ�Ա��ֵ
    SetData(sMsg);

	// 3.��Ѻ
	ChkMac();
    
    // 4.����������ʼ�ʱת�˱�hv_trofacrcvlist����������
    InsertData();
	
	string instdpty="";
	STRING strSql="";
    char szTempAmount[30] = {0};
	sprintf(szTempAmount,".2f",m_cCmt232.dAmount);
	if("CRDT"==m_cHvtrofacrcvlist.m_cdcode)
	{
	    instdpty = m_cCmt232.sIsdficode;

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "�����ʶΪ���ǣ�����ͷ����");
		
		strSql = "UPDATE SYS_SAPBANKINFO  SET ALIMIT = ALIMIT + ";
	}
	else
	{
	    instdpty = m_cCmt232.sOsdficode;      

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "�����ʶΪ��ǣ��۳�ͷ����");
		
		strSql = "UPDATE SYS_SAPBANKINFO  SET ALIMIT = ALIMIT - ";
	}
	
	strSql += szTempAmount;
	strSql += " WHERE SAPBANK ='";	
	strSql += m_cHvtrofacrcvlist.m_instddrctpty + "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=[%s]",strSql.c_str());
	
	int iRet = m_cHvtrofacrcvlist.execsql(strSql);
	
	if(iRet != RTN_SUCCESS)
	{
		sprintf(m_szErrMsg,"execsql() error,error code = [%d] error cause =[%s]",iRet,m_cHvtrofacrcvlist.GetSqlErr());
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException( __FILE__,__LINE__,DB_UPDATE_FAIL,m_szErrMsg);
	}

	// 5.�жϼ�ֱ���������ֱ����������ͨѶ��
	DirectInter(m_cHvtrofacrcvlist.m_instgindrctpty.c_str(), 
				m_cHvtrofacrcvlist.m_instdindrctpty.c_str(),
				instdpty.c_str(), 
				sMsg);
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkCmt232::Work()");

    return RTN_SUCCESS;
}

INT32 CRecvBkCmt232::unPack(LPCSTR sMsg)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvBkCmt232::unPack...");
    Trace(L_INFO, __FILE__, __LINE__, NULL, "receive sMsg[%s]", sMsg);
    // 1�������Ƿ�Ϊ��
    if(NULL == sMsg || '\0' == sMsg)
    {
        Trace(L_ERROR, __FILE__, __LINE__, m_strBizCode.c_str(), "����Ϊ��");
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");   
    }

    int iRet = RTN_FAIL;

    //2.��������

    iRet = m_cCmt232.ParseCmt(sMsg);

    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "���Ľ���ʧ��");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ���ʧ��");
    }

    char szTxssno[8 + 1] = {0};
    sprintf(szTxssno, "%08d", m_cCmt232.iTxssno);
    
    // ���ı�ʶ��,����д�����ļ�����
    m_strMsgID = m_cCmt232.sConsigndate;
    m_strMsgID += szTxssno;
    ZFPTLOG.SetLogInfo("232", m_strMsgID.c_str());

	/*
    //��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS,m_cCmt232.GetHeadDestAddr());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ȡ��������ʧ��");
        PMTS_ThrowException(OPT_GET_DATE_FAIL);
    }
    */
    m_strWorkDate = m_sWorkDate;

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvBkCmt232::unPack...");

    return RTN_SUCCESS;
}


INT32 CRecvBkCmt232::SetData(LPCSTR pchMsg)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvBkCmt232::SetData...");

    char DbSapBank[15] = {0};
    char CDSapBank[15] = {0};
    int iRet = GetSapBank(m_dbproc, m_cCmt232.sOsdficode, DbSapBank);
    int iRet1 = GetSapBank(m_dbproc, m_cCmt232.sIsdficode, CDSapBank); 
    if(iRet != 0 || iRet1 != 0)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, 
            "��ȡ��������Ϣʧ��m_cCmt232.sOsdficode[%s],iRet[%d],m_cCmt232.sIsdficode[%s],iRet1[%d]",
            m_cCmt232.sOsdficode,iRet,m_cCmt232.sIsdficode,iRet1);
        PMTS_ThrowException(PRM_FAIL);        
    }
    
    m_cHvtrofacrcvlist.m_cdtmmbid = CDSapBank ; 
    //m_cHvtrofacrcvlist.m_cdtrnm = m_cCmt232.sPayeename ; 
	SetGbkToUtf8(m_cCmt232.sPayeename, m_cHvtrofacrcvlist.m_cdtrnm);
    m_cHvtrofacrcvlist.m_cdtid = m_cCmt232.sIsdficode ; 
    m_cHvtrofacrcvlist.m_cdtracctid = m_cCmt232.sPayeeacc ; 
    m_cHvtrofacrcvlist.m_cdtrissr = m_cCmt232.sPayeeopenbk ; 

    char szTmp[30] = {0};
    m_cHvtrofacrcvlist.m_tranmunum = itoa(szTmp, m_cCmt232.iTxsbatno) ; 
    m_cHvtrofacrcvlist.m_currency = m_cCmt232.sCur; 
    m_cHvtrofacrcvlist.m_amount = m_cCmt232.dAmount ; 
    m_cHvtrofacrcvlist.m_ctgypurpprtry =  m_cCmt232.sOprttype; 
    m_cHvtrofacrcvlist.m_purpprtry = m_cCmt232.sOprttype; 
    m_cHvtrofacrcvlist.m_procstate = PR_HVBP_08 ; 

    //m_cHvtrofacrcvlist.m_processcode = m_cCmt232. ; 
    //m_cHvtrofacrcvlist.m_rjctinf = m_cCmt232. ; 
    //m_cHvtrofacrcvlist.m_acctstate = m_cCmt232. ; 
    //m_cHvtrofacrcvlist.m_acstatetime = m_cCmt232. ; 
    //m_cHvtrofacrcvlist.m_acctregnum = m_cCmt232. ; 
    //m_cHvtrofacrcvlist.m_dupacregnum = m_cCmt232. ; 
   // m_cHvtrofacrcvlist.m_checkstate = PR_HVBP_00 ; 
    //m_cHvtrofacrcvlist.m_mbcheckstate = PR_HVBP_00 ; 
    //m_cHvtrofacrcvlist.m_mbmsg = "" ; 
    //char m_sorimbmsg[32 + 1] = m_cCmt232. ; 
    //m_cHvtrofacrcvlist.m_npcmsg = m_cCmt232. ; 
    //char m_sorinpcmsg[32 + 1] = m_cCmt232. ; 
    //m_cHvtrofacrcvlist.m_reserve = m_cCmt232. ; 
    //m_cHvtrofacrcvlist.m_iststatetime = m_cCmt232. ; 
    //m_cHvtrofacrcvlist.m_dbtaddr = m_cCmt232. ; 
    //m_cHvtrofacrcvlist.m_cdtaddr = m_cCmt232. ; 
    //m_cHvtrofacrcvlist.m_isrbflg = m_cCmt232. ; 
    //m_cHvtrofacrcvlist.m_recvdest = m_cCmt232. ; 
    m_cHvtrofacrcvlist.m_srcflag = '0' ; 
    //m_cHvtrofacrcvlist.m_remark = m_cCmt232.sRemark ; 
	SetGbkToUtf8(m_cCmt232.sRemark, m_cHvtrofacrcvlist.m_remark);
    m_cHvtrofacrcvlist.m_workdate = m_strWorkDate ; 
    m_cHvtrofacrcvlist.m_consigndate = m_strWorkDate ; 
    m_cHvtrofacrcvlist.m_msgtp = "CMT232" ; 
    m_cHvtrofacrcvlist.m_mesgid = m_cCmt232.GetHeadMesgID() ; 
    m_cHvtrofacrcvlist.m_mesgrefid = m_cCmt232.GetHeadMesgReqNo() ; 
    m_cHvtrofacrcvlist.m_msgid = m_strMsgID ; 
    if(strncmp(m_cCmt232.sTallyflag,"0",sizeof(m_cCmt232.sTallyflag)-1)==0)
    {
        m_cHvtrofacrcvlist.m_cdcode = "DBIT";
        m_cHvtrofacrcvlist.m_instddrctpty = DbSapBank ; 
        m_cHvtrofacrcvlist.m_instdindrctpty = m_cCmt232.sOsdficode ; 
    }
    else
    {
        m_cHvtrofacrcvlist.m_cdcode = "CRDT";
        m_cHvtrofacrcvlist.m_instddrctpty = CDSapBank ; 
        m_cHvtrofacrcvlist.m_instdindrctpty = m_cCmt232.sIsdficode ; 
    }
    m_cHvtrofacrcvlist.m_instgdrctpty = m_cCmt232.sBankcode ; 
    m_cHvtrofacrcvlist.m_instgindrctpty = m_cCmt232.sBankcode ; 
    m_cHvtrofacrcvlist.m_spjoinmmbid = m_cCmt232.sBankcode ; 
    //m_cHvtrofacrcvlist.m_rmk = m_cCmt232.sRemark ; 
	SetGbkToUtf8(m_cCmt232.sRemark, m_cHvtrofacrcvlist.m_rmk);
    //m_cHvtrofacrcvlist.m_endtoendid = m_cCmt232. ; 
    //m_cHvtrofacrcvlist.m_sttlmprty = m_cCmt232.GetPayPRI() ; 
    m_cHvtrofacrcvlist.m_dbtmmbid = DbSapBank; 
    //m_cHvtrofacrcvlist.m_dbtnm = m_cCmt232.sPayername ; 
	SetGbkToUtf8(m_cCmt232.sPayername, m_cHvtrofacrcvlist.m_dbtnm);
    m_cHvtrofacrcvlist.m_dbtracctid = m_cCmt232.sPayeracc ; 
    m_cHvtrofacrcvlist.m_dbtid = m_cCmt232.sOsdficode ; 
    m_cHvtrofacrcvlist.m_dbtrissr = m_cCmt232.sPayopenbk ;   
    //m_cHvtrofacrcvlist.m_rmk = m_cCmt232.sRemark ;    

    char isodate[10+1] = {0};
    chgToISODate(m_cHvtrofacrcvlist.m_consigndate.c_str(), isodate);
    //m_cHvtrofacrcvlist.m_finalstatedate = isodate ; 
    m_cHvtrofacrcvlist.m_busistate = "" ; 

    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CF1:" + m_cCmt232.sBondcode+ ":";

    memset(szTmp, 0x00, sizeof(szTmp));
    ftoa(szTmp, m_cCmt232.dBondamount, 2);
    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CNM:" + szTmp + ":";

    memset(szTmp, 0x00, sizeof(szTmp));
    ftoa(szTmp, m_cCmt232.dSetamount, 2);
    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CNQ:" + szTmp + ":";
    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CJ8:" + m_cCmt232.sSetdate + ":";

    memset(szTmp, 0x00, sizeof(szTmp));
    ftoa(szTmp, m_cCmt232.dSetrate, 2);    
    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CNR:" + szTmp + ":";

    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CF2:" + m_cCmt232.sBondordercode + ":";

    memset(szTmp, 0x00, sizeof(szTmp));
    ftoa(szTmp, m_cCmt232.dNetamount, 2);   
    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CNN:" + szTmp + ":";

    memset(szTmp, 0x00, sizeof(szTmp));
    ftoa(szTmp, m_cCmt232.dBondrate, 2);       
    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CNP:" + szTmp + ":";

    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CCF:" + m_cCmt232.sOsdficodeccpc + ":";
    m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr + "CCG:" + m_cCmt232.sIsdficodeccpc + ":";
    
    // ����ͨѶ���ֶθ�ֵ
	m_strCdCode = ":cdcode:" + m_cHvtrofacrcvlist.m_cdcode;
	
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvBkCmt232::SetData...");
    return RTN_SUCCESS;
    
}

INT32 CRecvBkCmt232::InsertData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvBkCmt232::InsertData...");

    SETCTX(m_cHvtrofacrcvlist);
    int iRet = m_cHvtrofacrcvlist.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "����������ϸ��ʧ��iRet[%d][%s]", iRet, m_cHvtrofacrcvlist.GetSqlErr());
        PMTS_ThrowException(DB_INSERT_FAIL);
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvBkCmt232::InsertData...");
    return RTN_SUCCESS;    
}

int CRecvBkCmt232::ChkMac()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkCmt232::ChkMac...");
	int iRet = -1;
	
	m_cCmt232.SetSeal();//��ȡ��Ѻ��
	
	string instdpty="";
	if("CRDT"==m_cHvtrofacrcvlist.m_cdcode)
	{
	    instdpty = m_cCmt232.sIsdficode;
	}
	else
	{
	    instdpty = m_cCmt232.sOsdficode;      
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt232.sRecvsapbk[%s]",instdpty.c_str());
	
    iRet = CheckMac(m_dbproc,m_cCmt232.GetMacStr(),m_cCmt232.m_Seal.c_str(),instdpty.c_str());
    if(0 != iRet)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ChkMac failed");
    	PMTS_ThrowException(OPT_CHECKSIGN_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]",m_cCmt232.m_szMacStr);
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkCmt232::ChkMac..."); 
    
    return RTN_SUCCESS;
}
