/******************************************************************** 
�ļ����� recv710.cpp
�����ˣ� yszhong
��  �ڣ� 2011-03-18
�޸��ˣ� 
��  �ڣ� 
��  ���� ������˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkhvps710.h"

using namespace ZFPT;

CRecvBkHvps710::CRecvBkHvps710()
{
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps710::CRecvBkHvps710()");
}


CRecvBkHvps710::~CRecvBkHvps710()
{
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps710::~CRecvBkHvps710()");
}

INT32 CRecvBkHvps710::Work(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps710::doWork()");
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "level CRecvBkHvps710::doWork()");

	//do nothing
	return RTN_SUCCESS;
}



