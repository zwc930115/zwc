/********************************************************************
�ļ�����recvhvps841.cpp
�����ˣ�aps-hdf
��  �ڣ�2011-09-14
�޸��ˣ�
��  �ڣ�
��  �������CMT841���ʱ��Ĵ�����

��  ����
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkcmt841.h" 
#include "hvsapbankinfo.h"

using namespace ZFPT;

CRecvBkCmt841::CRecvBkCmt841()
{
	m_bCheckState = false;
	memset(m_bkchkst_checkdate, NULL_CHAR, sizeof(m_bkchkst_checkdate));
}

CRecvBkCmt841::~CRecvBkCmt841()
{

}

/******************************************************************************
*  Function:   CRecvBkCmt841::Save841msg
*  Description:CMT841���ܶ�������ҵ����
*  Input:      pchMsg �յ��ı���
*  Output:     ��
*  Return:     ��
*  Others:     ���ܶ���֮ǰ�ȱ���841���ģ��Ա�������·�������ж���
*  Author:     aps-hdf
*  Date:       2011-06-20
*******************************************************************************/
void CRecvBkCmt841::Save841msg(const char * pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt841::Save841msg()");

    int iRet = RTN_FAIL;

    // ��������
    oCCmrecverrmsg.setctx(m_dbproc);

    // ����������쳣���ֶθ�ֵ
    oCCmrecverrmsg.m_msgtext    = pchMsg;
    oCCmrecverrmsg.m_wrkdate    = m_cmt841.sConsigndate;
	oCCmrecverrmsg.m_msgtp      = "CMT841"; 
    oCCmrecverrmsg.m_procstate  = "00"; 
    oCCmrecverrmsg.m_proctimes  = 0; 
    oCCmrecverrmsg.m_errdesc    = "��ʼ����ǰ�Զ�����841����"; 

	Trace(L_INFO,	__FILE__,  __LINE__, NULL, "oCCmrecverrmsg.m_msgtext:[%s]", pchMsg);
	Trace(L_INFO,	__FILE__,  __LINE__, NULL, "oCCmrecverrmsg.m_wrkdate:[%s]", oCCmrecverrmsg.m_wrkdate.c_str());
	Trace(L_INFO,	__FILE__,  __LINE__, NULL, "oCCmrecverrmsg.m_msgtp:[%s]", m_strBizCode.c_str());

    // ����������쳣�������¼
    oCCmrecverrmsg.setctx(m_dbproc);    
    iRet = oCCmrecverrmsg.insert();
    if (0 != iRet)
    {
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "oCCmrecverrmsg.insert() error:%d", iRet);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);
    }
	oCCmrecverrmsg.commit();
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt841::Save841msg()");
}


INT32 CRecvBkCmt841::Work(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt841::doWork()");

	//��������ͨѶ���ֶθ�ֵ
	m_strMsgTp = "CMT841"; 
	m_strMsgID = m_strRcvMsgID;

    // 1.��������
    unPack(pchMsg);
    
	Save841msg(pchMsg);   
	
	EndDay(pchMsg);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt841::doWork()");

    return RTN_SUCCESS;
}

INT32 CRecvBkCmt841::unPack(LPCSTR sMsg)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvBkCmt841::unPack...");
    Trace(L_INFO, __FILE__, __LINE__, NULL, "receive sMsg[%s]", sMsg);
    
    // 1�������Ƿ�Ϊ��
    if(NULL == sMsg || '\0' == sMsg)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "����Ϊ��");
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");   
    }

    int iRet = RTN_FAIL;

    //2.��������

    iRet = m_cmt841.ParseCmt(sMsg);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "���Ľ���ʧ��");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ���ʧ��");
    }
        
    // ���ı�ʶ��,����д�����ļ�����
    ZFPTLOG.SetLogInfo("841", m_cmt841.sConsigndate);

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvBkCmt841::unPack...");

    return RTN_SUCCESS;
}

/******************************************************************************
*  Function:   CRecvBkCmt841::UnPackMsg
*  Description:CMT841��������
*  Input:      strMsg �յ��ı���
*  Output:     ��
*  Return:     ��
*  Others:     ��
*  Author:     aps-hdf
*  Date:       2011-09-014
*******************************************************************************/
void CRecvBkCmt841::UnPackMsg(const char *strMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt841::UnPackMsg()");
    const int BuffSize = 22 + 1;
    int iListCnt = 0; //������Ŀ��
    stTotalDetail *pTotalDetail = NULL;
    char strTmp[BuffSize];
    char strTmp1[BuffSize];
    memset(strTmp, NULL_CHAR, sizeof(strTmp));
    memset(strTmp1, NULL_CHAR, sizeof(strTmp1));
    
	oCHvcolcheck.m_consigndate = m_cmt841.sConsigndate;
	oCHvcolcheck.m_sapbank = m_cmt841.sSapbank;

    iListCnt = m_cmt841.iOtxitemcnt;
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iListCnt:[%d]", iListCnt);

    // �����ʷ��������ϸ 
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "�����ʷ��������ϸ");    
    if (iListCnt > 0)
    {
        pTotalDetail = (stTotalDetail *)m_cmt841.strOtxtotaldtl.c_str();		

		for (int i = 0; i < iListCnt; i++)
        {
            // ���ܶ�����ϸ�� 
            // ��ϸ���а�˳������֧���౨�ĵĻ�����ϸ��Ϣ 
            switch(i)
            {
                // CMT100 
                case 0:
                {
					oCHvchecklist.m_cmtno = "CMT100";
                    break;
                }
                case 1:
                {
					oCHvchecklist.m_cmtno = "CMT101";
                    break;                
                }
                case 2:
                {
					oCHvchecklist.m_cmtno = "CMT102";
                    break;                
                }                
                case 3:
                {
					oCHvchecklist.m_cmtno = "CMT103";
                    break;                
                }                
                case 4:
                {
					oCHvchecklist.m_cmtno = "CMT109";
                    break;                
                }                                 
                case 5:
                {
					oCHvchecklist.m_cmtno = "CMT121";
                    break;                
                }                  
                case 6:
                {
					oCHvchecklist.m_cmtno = "CMT122";
                    break;                
                }
                case 7:
                {
					oCHvchecklist.m_cmtno = "CMT123";
                    break;                
                }
                case 8:
                {
					oCHvchecklist.m_cmtno = "CMT124";
                    break;                
                } 
                
                case 9:
                {
					oCHvchecklist.m_cmtno = "CMT105";
                    break;                
                }                
                case 10:
                {
					oCHvchecklist.m_cmtno = "CMT108";
                    break;                
                }
                default:
                {
                    pTotalDetail++;
                    continue;
                }
                
            }			

            memset(strTmp, NULL_CHAR, sizeof(strTmp));
            memcpy(strTmp, pTotalDetail->TotalCnt, TOTAL_CNT_LEN);
            memset(strTmp1, NULL_CHAR, sizeof(strTmp1));
            memcpy(strTmp1, pTotalDetail->TotalMoney, TOTAL_MONEY_LEN);            
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strTmp:[%s]", strTmp);
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strTmp1:[%s]", strTmp1);

			oCHvchecklist.m_otxtotalcnt = atoi(strTmp);
			oCHvchecklist.m_otxtotalamnt = atof(strTmp1);
			oCHvchecklist.m_consigndate = m_cmt841.sConsigndate;
			oCHvchecklist.m_sapbank = m_cmt841.sSapbank;
			
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "oCHvchecklist.m_cmtno:[%s]", oCHvchecklist.m_cmtno.c_str());
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "oCHvchecklist.m_consigndate:[%s]", oCHvchecklist.m_consigndate.c_str());
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "oCHvchecklist.m_sapbank:[%s]", oCHvchecklist.m_sapbank.c_str());
			
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "oCHvchecklist.m_otxtotalcnt:[%d]", oCHvchecklist.m_otxtotalcnt);
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "oCHvchecklist.m_otxtotalamnt:[%f]", oCHvchecklist.m_otxtotalamnt);

			//CMT841���ʻ�����ϸ���
            InsertToListDB(_SEND);
            pTotalDetail++;
        }

    }

    oCHvcolcheck.m_itxtotalcnt = m_cmt841.iItxtotalcnt;
	oCHvcolcheck.m_itxtotalamnt = atof(m_cmt841.sItxtotalamnt); 
    iListCnt = 0;
    iListCnt = m_cmt841.iItxitemcnt;

    //�����ʷ��������ϸ
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "�����ʷ��������ϸ");        
    if (iListCnt > 0)
    {    
        pTotalDetail = (stTotalDetail *)m_cmt841.strItxtotaldtl.c_str();
        
        for (int i = 0; i < iListCnt; i++)
        {
            // ���ܶ�����ϸ�� 
			oCHvchecklist.m_consigndate = m_cmt841.sConsigndate;
			oCHvchecklist.m_sapbank = m_cmt841.sSapbank;
            
            // ��ϸ���а�˳������֧���౨�ĵĻ�����ϸ��Ϣ 
            switch(i)
            {
                // CMT100 
                case 0:
                {
					oCHvchecklist.m_cmtno = "CMT100";
                    break;
                    
                }
                case 1:
                {
					oCHvchecklist.m_cmtno = "CMT101";
                    break;                
                }
                case 2:
                {
					oCHvchecklist.m_cmtno = "CMT102";
                    break;                
                }                
                case 3:
                {
					oCHvchecklist.m_cmtno = "CMT103";
                    break;                
                }                
                case 4:
                {
					oCHvchecklist.m_cmtno = "CMT109";
                    break;                
                }                                 
                case 5:
                {
					oCHvchecklist.m_cmtno = "CMT121";
                    break;                
                }                  
                case 6:
                {
					oCHvchecklist.m_cmtno = "CMT122";
                    break;                
                }
                case 7:
                {
					oCHvchecklist.m_cmtno = "CMT123";
                    break;                
                }
                case 8:
                {
					oCHvchecklist.m_cmtno = "CMT124";
                    break;                
                } 
                
                case 9:
                {
					oCHvchecklist.m_cmtno = "CMT105";
                    break;                
                }                
                case 10:
                {
					oCHvchecklist.m_cmtno = "CMT108";
                    break;                
                }
                default:
                {
                    pTotalDetail++;
                    continue;
                }                
            }

            memset(strTmp, NULL_CHAR, sizeof(strTmp));
            memcpy(strTmp, pTotalDetail->TotalCnt, TOTAL_CNT_LEN);
            memset(strTmp1, NULL_CHAR, sizeof(strTmp1));
            memcpy(strTmp1, pTotalDetail->TotalMoney, TOTAL_MONEY_LEN);            
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strTmp:[%s]", strTmp);
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strTmp1:[%s]", strTmp1);
			
			oCHvchecklist.m_itxtotalcnt = atoi(strTmp);
			cl_itxtotalcnt = oCHvchecklist.m_itxtotalcnt;

			oCHvchecklist.m_itxtotalamnt = atof(strTmp1)/100;
			cl_itxtotalamnt = oCHvchecklist.m_itxtotalamnt;

			//CMT841���ʻ�����ϸ���
            InsertToListDB(_RECV);
            pTotalDetail++;
        }
    }
    
    // ��ʱת�������,������......

	/*
    m_cmtMsg.GetBusinessData(0)->GetTag("CDQ", db_HVCheckcl.);
    m_cmtMsg.GetBusinessData(0)->GetTag("CLU", db_HVCheckcl.);   
*/
/*
    memset(strTmp, NULL_CHAR, sizeof(strTmp)); 
    iListCnt = 0;
    m_cmtMsg.GetBusinessData(0)->GetTag("CDQ", strTmp, TRUE);
    iListCnt = atoi(strTmp);
    
    // �⼴ʱת�ʻ�����ϸ 
    if (iListCnt > 0)
    {
        pList = new char[iListCnt * sizeof(stTotalDetail) + 1];
        
        if (NULL == pList)
        {
            sprintf(m_sTemp, "CRecvBkCmt841::UnPackMsg.�⼴ʱת�ʻ�����ϸ,�����ڴ�ʧ��." );
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_sTemp);			
			PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, m_sTemp);
        }
        memset(pList, NULL_CHAR, (iListCnt * sizeof(stTotalDetail) + 1));
        m_cmtMsg.GetBusinessData(0)->GetTag("CLU", pList, TRUE);
        pTotalDetail = (stTotalDetail *)pList;

        for (int i = 0; i < iListCnt; i++)
        {
            // ���ܶ�����ϸ��
			oCHvchecklist.m_consigndate = m_consigndate;
			oCHvchecklist.m_sapbank = sz_sapbank;

            // ��ϸ���а�˳������֧���౨�ĵĻ�����ϸ��Ϣ 
            switch(i%3)
            {
                // CMT232 
                case 0:
                {
					oCHvchecklist.m_cmtno = "CMT232";
                    break;
                    
                }
                case 1:
                {
					oCHvchecklist.m_cmtno = "CMT407";
                    break;                
                }
                case 2:
                {
					oCHvchecklist.m_cmtno = "CMT408";
                    break;                
                }                
                default:
                {
                    continue;
                }
                
            }

            // ����ౣ�浽�����ֶ�,�����ౣ�浽�����ֶ� 
            if (i < 3)
            {
                memset(strTmp, NULL_CHAR, sizeof(strTmp));
                memcpy(strTmp, pTotalDetail->TotalCnt, TOTAL_CNT_LEN);
				oCHvchecklist.m_otxtotalcnt = atoi(strTmp);
                  
				memset(strTmp, NULL_CHAR, sizeof(strTmp));
				memcpy(strTmp, pTotalDetail->TotalMoney, TOTAL_MONEY_LEN);
				oCHvchecklist.m_otxtotalamnt = atof(strTmp);

				//CMT841���ʻ�����ϸ���
                InsertToListDB(_SEND);
            }
            else
            {
                memset(strTmp, NULL_CHAR, sizeof(strTmp));
                memcpy(strTmp, pTotalDetail->TotalCnt, TOTAL_CNT_LEN);
                oCHvchecklist.m_itxtotalcnt = atoi(strTmp);
                cl_itxtotalcnt = oCHvchecklist.m_itxtotalcnt;

				memset(strTmp, NULL_CHAR, sizeof(strTmp));
				memcpy(strTmp, pTotalDetail->TotalMoney, TOTAL_MONEY_LEN);
				oCHvchecklist.m_itxtotalamnt = atof(strTmp);
				cl_itxtotalamnt = oCHvchecklist.m_itxtotalamnt;

				//CMT841���ʻ�����ϸ���
                InsertToListDB(_RECV);		
            }            
            pTotalDetail++;
        }

		delete []pList;
		pList = NULL;
    }
*/
    //memcpy(m_strSapBank, db_HVCheckcl.sSapbank, BANKCODE_LEN);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt841::UnPackMsg()");
}

/******************************************************************************
*  Function:   CRecvBkCmt841::InsertListDB
*  Description:CMT841���ʻ�����ϸ���
*  Input:      DetailType ��ϸ����
*  Output:     ��
*  Return:     ��
*  Others:     ��oChvcheckentity.db_HVCheckList�ṹ�е����ݴ洢��������ϸ����
*  Author:     aps-hdf
*  Date:       2011-06-07
*******************************************************************************/
void CRecvBkCmt841::InsertToListDB(Detail_Type DetailType)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt841::InsertToListDB()"); 

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Detail_Type[%d]",DetailType);
/*    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_consigndate.c_str()[%s]",oCHvchecklist.m_consigndate.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sapbank.c_str()    [%s]",oCHvchecklist.m_sapbank.c_str()    );
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cmtno.c_str()      [%s]",oCHvchecklist.m_cmtno.c_str()      );
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_otxtotalcnt        [%d]",oCHvchecklist.m_otxtotalcnt        );
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_otxtotalamnt       [%f]",oCHvchecklist.m_otxtotalamnt       );
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_itxtotalcnt        [%d]",oCHvchecklist.m_itxtotalcnt        );
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_itxtotalamnt       [%f]",oCHvchecklist.m_itxtotalamnt       );
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_naotxtotalcnt      [%d]",oCHvchecklist.m_naotxtotalcnt      );
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_naotxtotalamnt     [%f]",oCHvchecklist.m_naotxtotalamnt     );
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_naitxtotalcnt      [%d]",oCHvchecklist.m_naitxtotalcnt      );
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_naitxtotalamnt     [%f]",oCHvchecklist.m_naitxtotalamnt     );
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_mbotxtotalcn       [%d]",oCHvchecklist.m_mbotxtotalcn       );
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_mbotxtotalamnt     [%f]",oCHvchecklist.m_mbotxtotalamnt     );
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_mbitxtotalcnt      [%d]",oCHvchecklist.m_mbitxtotalcnt      );
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_mbitxtotalamnt     [%f]",oCHvchecklist.m_mbitxtotalamnt     );
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "end--------------------------------\n");
*/

    Chvcheckentity tChvcheckentity;
    SETCTX(tChvcheckentity);
    tChvcheckentity.m_consigndate = oCHvchecklist.m_consigndate; 
    tChvcheckentity.m_sapbank = oCHvchecklist.m_sapbank; 
    tChvcheckentity.m_cmtno = oCHvchecklist.m_cmtno;     
    tChvcheckentity.m_otxtotalcnt = oCHvchecklist.m_otxtotalcnt; 
    tChvcheckentity.m_otxtotalamnt = oCHvchecklist.m_otxtotalamnt; 
    tChvcheckentity.m_itxtotalcnt = oCHvchecklist.m_itxtotalcnt; 
    tChvcheckentity.m_itxtotalamnt = oCHvchecklist.m_itxtotalamnt; 
    tChvcheckentity.m_naotxtotalcnt = oCHvchecklist.m_naotxtotalcnt; 
    tChvcheckentity.m_naotxtotalamnt = oCHvchecklist.m_naotxtotalamnt; 
    tChvcheckentity.m_naitxtotalcnt = oCHvchecklist.m_naitxtotalcnt; 
    tChvcheckentity.m_naitxtotalamnt = oCHvchecklist.m_naitxtotalamnt; 
        
	int iRet = 0;	
    if (_SEND == DetailType)
    {
		iRet = tChvcheckentity.insertCheckList();
        if(DUPLICATE_KEY == iRet)  
        {
            sprintf(m_szErrMsg, "CRecvBkCmt841::InsertToListDB.����hv_checklist���ظ�.[%s],[%s][%s],[%s].",
                  tChvcheckentity.m_consigndate.c_str(), tChvcheckentity.m_sapbank.c_str(), tChvcheckentity.m_cmtno.c_str(),tChvcheckentity.GetSqlErr());

			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);
        } 
        if (0 != iRet)
        {
            sprintf(m_szErrMsg,"CRecvBkCmt841::InsertToListDB.[%s][%d].",tChvcheckentity.m_errmsg.c_str(),iRet);
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);			
			PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);  
        }
		//�ύ����
		tChvcheckentity.commit();
    }

    if (_RECV == DetailType)
    {
		oCHvchecklist.setctx(m_dbproc);
		string strSQL="";
		strSQL += "select *from hv_checklist where SAPBANK = '";
	    strSQL += oCHvchecklist.m_sapbank;
		strSQL +="' AND CMTNO = '";
	    strSQL += oCHvchecklist.m_cmtno;
		strSQL +="' AND CONSIGNDATE = '";
	    strSQL += oCHvchecklist.m_consigndate;
		strSQL +="'";

		iRet = oCHvchecklist.execsql(strSQL.c_str());
    	if (SQLNOTFOUND == iRet)
        {
			int iret = 0;
			iret = tChvcheckentity.insert();
	        if(0 != iret)  
		    {
			    sprintf(m_szErrMsg, "CRecvBkCmt841::InsertToListDB.����hv_checklist��ʧ��.[%s],[%s][%s],[%s].",
				      tChvcheckentity.m_consigndate.c_str(), tChvcheckentity.m_sapbank.c_str(), oCHvchecklist.m_cmtno.c_str(),tChvcheckentity.m_errmsg.c_str());
				Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
				PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);
			} 
			//�ύ����
			tChvcheckentity.commit();
        }
        else if (0 == iRet)
        {
			CHvchecklist m_CHvchecklist;
			m_CHvchecklist.m_consigndate = oCHvchecklist.m_consigndate;
			m_CHvchecklist.m_sapbank	 = oCHvchecklist.m_sapbank;
			m_CHvchecklist.m_cmtno		 = oCHvchecklist.m_cmtno;

			m_CHvchecklist.setctx(m_dbproc);
    		iRet = m_CHvchecklist.findByPK();
	        if (0 != iRet)
		    {
				Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "CRecvBkCmt841::InsertToListDB.findbypk error");			
				PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "CRecvBkCmt841::InsertToListDB.findbypk error");
		    }

			m_CHvchecklist.m_itxtotalcnt = cl_itxtotalcnt;
			m_CHvchecklist.m_itxtotalamnt = cl_itxtotalamnt;

			m_CHvchecklist.setctx(m_dbproc); 
			iRet = m_CHvchecklist.updatestate(); 
	        if (0 != iRet)
		    {
		        sprintf(m_szErrMsg, 
			          "CRecvBkCmt841::InsertToListDB.����hv_checklist��ʧ��.[%s],[%s],[%s],[%d].",
					  m_CHvchecklist.m_consigndate.c_str(), m_CHvchecklist.m_sapbank.c_str(), m_CHvchecklist.m_cmtno.c_str(),iRet);
				Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);			
				PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);
		    } 
			m_CHvchecklist.commit();
		}
		else 
		{
            sprintf(m_szErrMsg, "CRecvBkCmt841::InsertToListDB.����hv_checklist��ʧ��.[%d]",iRet);
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);			
			PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);
		}
    }

  	Trace(L_INFO,  __FILE__,	__LINE__, NULL, "leaving CRecvBkCmt841::InsertToListDB()");
}

/******************************************************************************
*  Function:   CRecvBkCmt841::statLocalData()
*  Description:ͳ�Ʊ��ػ�������
*  Input:      ��
*  Output:     ��
*  Return:     ��
*  Others:     ���������ݴ洢�����ʻ��ܱ���
*  Author:     aps-hdf
*  Date:       2011-06-07
*******************************************************************************/
void CRecvBkCmt841::statLocalData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt841::statLocalData()");
    
	char   db_CmtNo[6 + 1];
	int iRet = 0;
    
    /* ��ͳ�Ƶı��ػ������ݰ���֧����100,101,102,103,105,108,109,121,122,123,124��11�ֱ��� */
    /* ͳ��֧���౨��100,101,102,103,105,108,109,121,122,123,124 */
    for (int i = 0; i <= 10; i++)
    {
        memset(db_CmtNo, NULL_CHAR, sizeof(db_CmtNo));
        switch (i)
        {
            case 0:
            {
                memcpy(db_CmtNo, "CMT100", 6);
                break;
            }
            case 1:
            {
                memcpy(db_CmtNo, "CMT101", 6);
                break;
            }            
            case 2:
            {
                memcpy(db_CmtNo, "CMT102", 6);
                break;
            }
            case 3:
            {
                memcpy(db_CmtNo, "CMT103", 6);
                break;
            }
            case 4:
            {
                memcpy(db_CmtNo, "CMT105", 6);
                break;
            }
            case 5:
            {
                memcpy(db_CmtNo, "CMT108", 6);
                break;
            }
            case 6:
            {
                memcpy(db_CmtNo, "CMT109", 6);
                break;                
            }                                 
            case 7:
            {
                memcpy(db_CmtNo, "CMT121", 6);
                break;                
            }                  
            case 8:
            {
                memcpy(db_CmtNo, "CMT122", 6);
                break;                
            }
            case 9:
            {
                memcpy(db_CmtNo, "CMT123", 6);
                break;                
            }
            case 10:
            {
                memcpy(db_CmtNo, "CMT124", 6);
                break;                
            }             
            default:
            {
                break;
            }
        }

		oChvcheckentity.m_sendConsigndate = m_cmt841.sConsigndate;
		oChvcheckentity.m_sendSapbank = m_cmt841.sSapbank;
		oChvcheckentity.m_sendMsgTp = db_CmtNo;

        /* ͳ�Ʊ��������������� */
		oChvcheckentity.setctx(m_dbproc);
		iRet = oChvcheckentity.QryLocalData();
        if ((0 != iRet) && (SQLNOTFOUND != iRet))
        {
            sprintf(m_szErrMsg,"CRecvBkCmt841::statLocalData.ͳ�ƴ����ϸ��ʧ��.[%d]",iRet);
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);
        }
		Trace(L_INFO,	__FILE__,  __LINE__, NULL, "CRecvBkCmt841::statLocalData.ͳ�ƴ����ϸ���ɹ�.");


        /* ���µ����ܶ�����ϸ�� */
		oCHvchecklist.m_cmtno = db_CmtNo;
		oCHvchecklist.m_consigndate = m_cmt841.sConsigndate;
		oCHvchecklist.m_sapbank = m_cmt841.sSapbank;
		
    	oCHvchecklist.setctx(m_dbproc);
		iRet = oCHvchecklist.findByPK();		
    	if ((0 != iRet) && (SQLNOTFOUND != iRet))
        {
			sprintf(m_szErrMsg, "CRecvBkCmt841::statLocalData.����ԭҵ��ʧ��.[%s],[%s][%s],[%s].",
				      oCHvchecklist.m_consigndate.c_str(), oCHvchecklist.m_sapbank.c_str(), oCHvchecklist.m_cmtno.c_str(),oCHvchecklist.GetSqlErr());
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);
        }

		oCHvchecklist.m_naotxtotalcnt = oChvcheckentity.m_sendTotalCnt;		//���������ܱ���
		oCHvchecklist.m_naotxtotalamnt = oChvcheckentity.m_sendTotalMoney;	//���������ܽ��
		oCHvchecklist.m_naitxtotalcnt = oChvcheckentity.m_recvTotalCnt;		//���������ܱ���
		oCHvchecklist.m_naitxtotalamnt = oChvcheckentity.m_recvTotalMoney;	//���������ܽ��

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "2----------statLocalData()----------------------\n");
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_consigndate.c_str()[%s]",oCHvchecklist.m_consigndate.c_str());
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sapbank.c_str()	[%s]",oCHvchecklist.m_sapbank.c_str()	 );
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cmtno.c_str()		[%s]",oCHvchecklist.m_cmtno.c_str() 	 );
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_naotxtotalcnt		[%d]",oCHvchecklist.m_naotxtotalcnt 	 );
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_naotxtotalamnt 	[%f]",oCHvchecklist.m_naotxtotalamnt	 );
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_naitxtotalcnt		[%d]",oCHvchecklist.m_naitxtotalcnt 	 );
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_naitxtotalamnt 	[%f]",oCHvchecklist.m_naitxtotalamnt	 );
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "end--------------------------------\n");
 		
		oCHvchecklist.setctx(m_dbproc);
		iRet = oCHvchecklist.updatestate();
        if ((0 != iRet)&& (SQLNOTFOUND != iRet))
        {
            sprintf(m_szErrMsg, "CRecvBkCmt841::statLocalData.���¶��ʻ�����ϸ��ʧ��.[%d],[%s].", iRet, db_CmtNo);
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);			
			PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);
        }
		Trace(L_INFO,	__FILE__,  __LINE__, NULL, "CRecvBkCmt841::statLocalData.���¶��ʻ�����ϸ���ɹ�.");
    }
	oCHvchecklist.commit();

	/*���»��ܱ�*/
	oChvcheckentity.m_sapbank = m_cmt841.sSapbank;
	oChvcheckentity.m_consigndate = m_cmt841.sConsigndate;
	Trace(L_INFO,	__FILE__,  __LINE__, NULL, "CRecvBkCmt841::statLocalData.m_sapbank[%s].",oChvcheckentity.m_sapbank.c_str());
	Trace(L_INFO,	__FILE__,  __LINE__, NULL, "CRecvBkCmt841::statLocalData.m_consigndate[%s].",oChvcheckentity.m_consigndate.c_str());

	oChvcheckentity.setctx(m_dbproc);
	iRet = oChvcheckentity.upcolcheck();
	if (SQLNOTFOUND == iRet)
    {
        sprintf(m_szErrMsg, "CRecvBkCmt841::statLocalData.���¶��ʻ��ܱ����������ܽ���¼������.sz_consigndate[%s],sz_sapbank[%s],err[%s]."
			, m_cmt841.sConsigndate, m_cmt841.sSapbank,oChvcheckentity.m_errmsg.c_str());
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_szErrMsg);
    }
    if (0 != iRet)
    {
        sprintf(m_szErrMsg,"CRecvBkCmt841::statLocalData.���¶��ʻ��ܱ����������ܽ��ʧ��.[%d],[%s]",iRet,oChvcheckentity.m_errmsg.c_str());
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);		
		PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);
    }
	oChvcheckentity.commit();
	Trace(L_INFO,	__FILE__,  __LINE__, NULL, "CRecvBkCmt841::statLocalData.���¶��ʻ��ܱ����������ܽ��ɹ�.");

  	Trace(L_INFO,  __FILE__,	__LINE__, NULL, "leaving CRecvBkCmt841::statLocalData()");
}

/******************************************************************************
*  Function:   CRecvBkCmt841::compareData()
*  Description:CMT841���ʱȽϱ�����MBFE��������
*  Input:      ��
*  Output:     ��
*  Return:     ��
*  Others:     �Ƚϻ��ܽ���Ƿ���ͬ
*  Author:     aps-hdf
*  Date:       2011-06-07
*******************************************************************************/
void CRecvBkCmt841::compareData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt841::compareData()");

    STRING sz_checkState;
	int iRet = 0;

    /* ������ϸ��¼���жԱ� */
    oChvcheckentity.setctx(m_dbproc);
	iRet = oChvcheckentity.comparechecklist();
    if (0 != iRet)
    {
        sprintf(m_szErrMsg,"CRecvBkCmt841::compareData.��ѯ���ʻ��ܱ�ʧ��.[%d][%s]",iRet, oChvcheckentity.GetSqlErr());
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);		
		PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);
    }

    if (0 == oChvcheckentity.m_TotalCount)
    {
        //����������MBFE�������,����ƽ/
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "CRecvBkCmt841::compareData. ����ƽ,�������д���");        
		sz_checkState = SAP_CHECK_STATE_SUCCESS;
        m_bCheckState = true;        
    }
    else 
    {
        //����������MBFE���ݲ����,���ʲ�ƽ,������ϸ����/    
		Trace(L_INFO,	__FILE__,  __LINE__, NULL, "CRecvBkCmt841::compareData. ���ʲ�ƽ");
		sz_checkState= SAP_CHECK_STATE_NO_BALANCE;
        m_bCheckState = false;                
    }

    oChvcheckentity.m_checkState = "01";

    //����������ϸ����MBFE����״̬/
	iRet = oChvcheckentity.updatesendstate();
    if ((0 != iRet) && (SQLNOTFOUND != iRet))
    {
        sprintf(m_szErrMsg, "CRecvBkCmt841::compareData.������ƽ,����������ϸ��ʧ��.[%d]",iRet);
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);			
		PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);
    }

    //����������ϸ����MBFE����״̬/
	iRet = oChvcheckentity.updaterecvstate();	
    if ((0 != iRet) && (SQLNOTFOUND != iRet))
    {
        sprintf(m_szErrMsg, "CRecvBkCmt841::compareData.������ƽ,����������ϸ��ʧ��.[%d]",iRet);
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);			
		PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);
    }

    //�޸������ж���״̬/
    UpdateSapState(sz_checkState);
    
	oChvcheckentity.commit();
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt841::compareData()");
    return;
}    
void CRecvBkCmt841::UpdateSapState(STRING sProState)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkCmt841::UpdateSapState");

    chgToISODate(m_cmt841.sConsigndate, m_bkchkst_checkdate);
    
    string strSQL;
	strSQL += "UPDATE HV_BKCHKST t SET t.STATETIME = sysdate, t.CHECKSTATE = '";
	strSQL += sProState;
    strSQL += "' ";
    
	strSQL += " WHERE t.CHECKDATE = '";
	strSQL += m_bkchkst_checkdate;
    strSQL += "' AND t.SAPBANK = '";
	strSQL += m_cmt841.sSapbank;									
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());

	SETCTX(oCHvbkchkst);
    int iRet = oCHvbkchkst.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��iRet=%d, %s", iRet, oCHvbkchkst.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }   
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkCmt841::UpdateSapState");
    return;
}

/******************************************************************************
*  Function:   CRecvBkCmt841::sendCMT659
*  Description:��֯CMT659����,д����MBFEͨѸ��
*  Input:      ��
*  Output:     ��
*  Return:     ��
*  Others:     ��
*  Author:     aps-hdf
*  Date:       2011-06-07
*******************************************************************************/
void CRecvBkCmt841::sendCMT659()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt841::sendCMT659()");
    char strMesgID[20 + 1];  //���Ĳο���
    char strMsgID[20 + 1];     //���ı�ʶ��
    int iMsgLen = 0;            //���Ĵ����� 
    int iRet = 0;

    /* CMT���� */
    memset(strMesgID, NULL_CHAR, sizeof(strMesgID));
    memset(strMsgID, NULL_CHAR, sizeof(strMsgID));
    
    /* ��ñ��Ĳο��� */
    GetMsgIdValue(m_dbproc, strMsgID, eMsgId,  SYS_HVPS);
    GetMsgIdValue(m_dbproc, strMesgID, eRefId,  SYS_HVPS);
    
    /* ��CMT�������� */
	memcpy(ocmt659.sBankno,m_cmt841.sSapbank,12);
	memcpy(ocmt659.sConsigndate,m_cmt841.sConsigndate,8);
	memcpy(ocmt659.sTradetype,"1",1);
        
    /* ȡ������Ҫ���ص���ϸCMT��Ŀ */
	oChvcheckentity.setctx(m_dbproc);
	iRet = oChvcheckentity.selsendchecklist();
    if (0 != iRet)
    {
        sprintf(m_szErrMsg,"CRecvBkCmt841::buildCMT659.��ѯ���ʻ�����ϸ��������ϸʧ��.[%d]",iRet);
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);		
		PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);
    }    

    /* ȡ������Ҫ���ص���ϸCMT��Ŀ*/
	iRet = oChvcheckentity.selrecvchecklist();
    if (0 != iRet)
    {
        sprintf(m_szErrMsg,"CRecvBkCmt841::buildCMT659.��ѯ���ʻ�����ϸ��������ϸʧ��.[%d]",iRet);
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);		
		PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);
    }    

	ocmt659.iCmtcount = oChvcheckentity.m_dlsendcount + oChvcheckentity.m_dlrecvcount;
	Trace(L_INFO,	__FILE__,  __LINE__, NULL, "�ܱ���:[%d].���˱���:[%d],���˱���:[%d]",ocmt659.iCmtcount,oChvcheckentity.m_dlsendcount,oChvcheckentity.m_dlrecvcount);
    
	//��ȡ��Ҫ���ص�CMT�б�
	oChvcheckentity.setctx(m_dbproc);
	iRet = oChvcheckentity.getcmtnolist();
    if (0 != iRet)
    {
        sprintf(m_szErrMsg,"CRecvBkCmt841::buildCMT659.��ȡ��Ҫ���ص�CMT�б�ʧ��.[%d]",iRet);
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);		
		PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);
    }    

	ocmt659.strCmtlist = oChvcheckentity.strCmtNoList;
    
    iRet = ocmt659.CreateCmt("659",
                       	  m_cmt841.sSapbank,
                       	  "0000",
                       	  strMesgID,
                       	  strMesgID, 
                       	  m_cmt841.sConsigndate,
                       	  "0");
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�鱨��ʧ��,iRet[%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
	Trace(L_INFO,	__FILE__,  __LINE__, NULL, "���ɵ�CMT659��������[%s]",ocmt659.m_strCmtmsg.c_str());

    /* ֱ�ӷ���ʧ�ܺ�,д����NPCͨѶ�� */
	oCCmcomsend.m_procstate = "01";
	oCCmcomsend.m_sendtimes = 0;
	oCCmcomsend.m_syscode = "01";
	oCCmcomsend.m_wrkdate = m_cmt841.sConsigndate;
	oCCmcomsend.m_msgtp = "CMT659";
	oCCmcomsend.m_sendbankcode = m_cmt841.sSapbank;
	oCCmcomsend.m_recvbankcode = "0000";
	oCCmcomsend.m_msgid = strMsgID;

 	string sMsgData="";
 	char sMsgLen[9]={0};
 	sprintf(sMsgLen,"%08d",ocmt659.m_strCmtmsg.length()+2);
 	sMsgData = sMsgLen;
 	sMsgData+=ocmt659.m_strCmtmsg;
	sMsgData+="\n\r";
	oCCmcomsend.m_msgtext = sMsgData;

	oCCmcomsend.setctx(m_dbproc);
	iRet = oCCmcomsend.insert();
    if (0 != iRet)
    {
        sprintf(m_szErrMsg,"CRecvBkCmt841::sendCMT659.����NPCͨѶ��ʧ��.[%d]",iRet);
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);		
		PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);
    }
	oCCmcomsend.commit();
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt841::sendCMT659()");
}

/******************************************************************************
*  Function:   CHvRecvCmtMsg::changeDate()
*  Description:����ƽ�Ժ�������д���
*  Input:      changeType ��������: 1 �������� 2 ǿ������
               strSapBank �����к�, strConsigndate ί������
*  Output:     ��
*  Return:     ��
*  Others:     �������д洢����
*  Author:     aps-hdf
*  Date:       2011-06-08
*******************************************************************************/
void CRecvBkCmt841::changeDate(int changeType,char *strSapBank, char * strConsigndate)
{
    char sz_Consigndate[8 + 1];
	int iRet = 0;
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt841::changeDate()");
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "CRecvBkCmt841::changeDate, ��������:[%d].",changeType);
   
	CHvsapbankinfo chvsapbankinfo;
	chvsapbankinfo.m_sapbank = strSapBank;
	chvsapbankinfo.setctx(m_dbproc);
	iRet = chvsapbankinfo.findByPK();
	if (iRet != 0)
    {
		Trace(L_INFO,  __FILE__,  __LINE__, NULL,"ȡ��һ������ǰʧ��");  
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, "ȡ��һ������ǰʧ��");
    }
    /* �������д洢���� */
    oChvcheckentity.HvChangeDate(NORMAL_CHANGE, strSapBank, (char*)chvsapbankinfo.m_predate.c_str());
			
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "CRecvBkCmt841::changeDate:ִ�����д洢���̳ɹ�.");
    
	Trace(L_INFO,  __FILE__,	__LINE__, NULL, "leaving CRecvBkCmt841::changeDate()");
    return;
}

/******************************************************************************
*  Function:   CRecvBkCmt841::InsertToDB()
*  Description:CMT841���ʻ������
*  Input:      ��
*  Output:     ��
*  Return:     ��
*  Others:     ��db_HVCheckcl�ṹ�е����ݴ洢�����ʻ��ܱ���
*  Author:     aps-hdf
*  Date:       2011-06-07
*******************************************************************************/
void CRecvBkCmt841::InsertToDB()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt841::InsertToDB()");

	int iRet = 0;	
	oCHvcolcheck.setctx(m_dbproc);

    oCHvcolcheck.m_consigndate = m_cmt841.sConsigndate;
    oCHvcolcheck.m_sapbank = m_cmt841.sSapbank;
    oCHvcolcheck.m_otxtotalcnt = m_cmt841.iOtxtotalcnt;
    oCHvcolcheck.m_otxtotalamnt = atof(m_cmt841.sOtxtotalamnt)/100; 
    oCHvcolcheck.m_itxtotalcnt = m_cmt841.iItxtotalcnt;
    oCHvcolcheck.m_itxtotalamnt = atof(m_cmt841.sItxtotalamnt)/100; 
    
	iRet = oCHvcolcheck.insert();
    if(DUPLICATE_KEY == iRet)  
    {
		sprintf(m_szErrMsg, "CRecvBkCmt841::InsertToDB.��������ܶ��ʻ��ܱ��ظ�.[%s],[%s].", m_cmt841.sConsigndate, m_cmt841.sSapbank);
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);		
		PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);
    }                    
    if (0 != iRet)
    {
        sprintf(m_szErrMsg,"CRecvBkCmt841::InsertToDB.��������ܶ��ʻ��ܱ�ʧ��.[%d]",iRet);
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);		
		PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);
    }
	oCHvcolcheck.commit();

  	Trace(L_INFO,  __FILE__,	__LINE__, NULL, "leaving CRecvBkCmt841::InsertToDB()");
}

/******************************************************************************
*  Function:   CRecvBkCmt841::EndDay
*  Description:CMT841���ܶ�������ҵ����
*  Input:      strMsg �յ��ı���,���ΪNULL���ʾ���ڲ����̴��������¶���.
               strSapBank ��Ҫ���ʵ������к�,strConsigndate ��Ҫ���¶��ʵ�ί������ 
*  Output:     ��
*  Return:     ��
*  Others:     �ڲ����̴������ֹ����ʴ�strSapBank,strConsigndate����strMsg����Ϊ
               ��,���������strSapBank,strConsigndate����������.
*  Author:     aps-hdf
*  Date:       2011-06-07
*******************************************************************************/
void CRecvBkCmt841::EndDay(const char *strMsg, const char *strSapBank, char *strConsigndate)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkCmt841::EndDay");

    if ((NULL == strMsg)&&(NULL == strSapBank)&&(NULL == strConsigndate))
    {
        sprintf(m_szErrMsg, "CRecvBkCmt841::EndDay.�޷������ı���.");
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, m_szErrMsg);
    }

    if((NULL == strMsg)&&((NULL == strSapBank)||(NULL == strConsigndate)))
    {
        sprintf(m_szErrMsg, "CRecvBkCmt841::EndDay.�޷������ı���.");
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, m_szErrMsg);
    }

    int iCheckState = 0; 
    int iRet = 0;
    char db_checkState[2 + 1];
    
    if(strMsg != NULL)
    {
        UnPackMsg(strMsg);

        /*00����ʼ01�����˳ɹ� 02: ���гɹ� 10���յ����ܶ��� 12: �յ���ϸ����13: ���ʲ�ƽ 14��������ϸ��������
        15�������ֹ����� 16:�ֹ�������ϸ���� 18: �����ֹ����� 19:ǿ���ֹ����� 20:����ʧ��*/
        UpdateSapState("10");

        InsertToDB();
    }
    else
    {
        memcpy(m_cmt841.sConsigndate, strConsigndate, 8);
        memcpy(m_cmt841.sSapbank, strSapBank, 12);
	}

	SETCTX(oCHvbkchkst);
	oCHvbkchkst.m_checkdate = m_bkchkst_checkdate;
	oCHvbkchkst.m_sapbank = m_cmt841.sSapbank;
	iRet = oCHvbkchkst.findByPK();
    if (0 != iRet)
    {
        sprintf(m_szErrMsg,"CRecvBkCmt841::EndDay.��ѯ��������ж���״̬��ʧ��.[%d][%s][%s]",iRet,oCHvbkchkst.m_checkdate.c_str(),oCHvbkchkst.m_sapbank.c_str());
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);		
		PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_szErrMsg);
    }                         
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "CRecvBkCmt841::EndDay.��ѯ��������ж���״̬���ɹ�.");

    memset(db_checkState, NULL_CHAR, sizeof(db_checkState));
	strncpy(db_checkState,oCHvbkchkst.m_checkstate.c_str(),2);
    iCheckState = atoi(db_checkState);
	
    /* ���������ж���״̬���в���*/
    switch (iCheckState)
    {
        case I_SAP_CHECK_STATE_INIT:
        {
            sprintf(m_szErrMsg, "CRecvBkCmt841::EndDay.��ʼ״̬�������ֹ�����.");
			Trace(L_INFO,	__FILE__,  __LINE__, NULL, m_szErrMsg);
            break;
        }
        case I_SAP_CHECK_STATE_SUCCESS:
        {
            sprintf(m_szErrMsg, "CRecvBkCmt841::EndDay.������ƽ�������ֹ�����.");
			Trace(L_INFO,	__FILE__,  __LINE__, NULL, m_szErrMsg);
            break;
        }
        case I_SAP_CHECK_STATE_CHANGED:
        {
            sprintf(m_szErrMsg, "CRecvBkCmt841::EndDay.��������ɲ������ֹ�����.");
			Trace(L_INFO,	__FILE__,  __LINE__, NULL, m_szErrMsg);
            break;
        }        
        case I_SAP_CHECK_STATE_RECV841:
        {
            // ͳ�Ʊ��ػ������� 
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "CRecvBkCmt841::EndDay.ͳ�Ʊ��ػ�������.");
            statLocalData();

            // �Ƚϻ������� 
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "CRecvBkCmt841::EndDay.�Ƚϻ�������.");
            compareData();
            
            if (true == m_bCheckState)
            {	
                //1. ����Ķ���
                //......
                
				//4. ����
                Trace(L_INFO,	__FILE__,  __LINE__, NULL, "��ƽ�����д���");
                changeDate(NORMAL_CHANGE, m_cmt841.sSapbank, m_cmt841.sConsigndate);                
            }
            else
            {
                // ����������MBFE���ݲ����,���ʲ�ƽ,������ϸ����    
				Trace(L_INFO,	__FILE__,  __LINE__, NULL, "CRecvBkCmt841::EndDay. ���ʲ�ƽ,������ϸ����");
				
                // �޸������ж���״̬ 
				UpdateSapState(SAP_CHECK_STATE_SEND659);
                
                // ���ʲ�ƽ��Ҫ������ϸ���� 
				Trace(L_INFO,	__FILE__,  __LINE__, NULL, "CRecvBkCmt841::EndDay.���ʲ�ƽ��Ҫ������ϸ����.");
                sendCMT659();            
            
            }
            break;
        }
        case I_SAP_CHECK_STATE_SEND659:
        {
            sprintf(m_szErrMsg, "CRecvBkCmt841::EndDay.��ϸ����������,��ȴ��������ֹ�����.");
			Trace(L_INFO,	__FILE__,  __LINE__, NULL, m_szErrMsg);			
			PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, m_szErrMsg);
            
            break;
        }
        case I_SAP_CHECK_STATE_MANUAL:
        case I_SAP_CHECK_STATE_RECV689:
        {
            // ͳ�Ʊ��ػ������� 
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "CRecvBkCmt841::EndDay.ͳ�Ʊ��ػ�������.");
            statLocalData();

            // �Ƚϻ������� 
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "CRecvBkCmt841::EndDay.�Ƚϻ�������.");
            compareData();

            if (true == m_bCheckState)
            {	
                //1. ����Ķ���
                //......
				//4. ����
                Trace(L_INFO,	__FILE__,  __LINE__, NULL, "��ƽ�����д���");
                changeDate(NORMAL_CHANGE, m_cmt841.sSapbank, m_cmt841.sConsigndate);                      
            }
            else
            {
				Trace(L_INFO,	__FILE__,  __LINE__, NULL, "CRecvBkCmt841::EndDay. ���ʲ�ƽ");
				
                // �޸������ж���״̬ 
				UpdateSapState(SAP_CHECK_STATE_NO_BALANCE);
            }
            break;
        }
        case I_SAP_CHECK_STATE_M_SEND659:
        {
			UpdateSapState(SAP_CHECK_STATE_SEND659);

            sendCMT659();
            break;
        }
        case I_SAP_CHECK_STATE_NORMAL_CHANGE:
        {
            changeDate(NORMAL_CHANGE, m_cmt841.sSapbank, m_cmt841.sConsigndate);
            break;
        }        
        case I_SAP_CHECK_STATE_FORCE_CHANGE:
        {
            changeDate(FORCE_CHANGE, m_cmt841.sSapbank, m_cmt841.sConsigndate);
            break;
        }
        case I_SAP_CHECK_STATE_CHANGEFAIL:
        {
            sprintf(m_szErrMsg, 
                  "CRecvBkCmt841::EndDay. ���������[%s],����[%s],����״̬��״̬Ϊ�ֹ�����ʧ��,�����û�֪ͨ��Ϣ���ٴ���.",
                  m_cmt841.sSapbank, m_cmt841.sConsigndate);
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, m_szErrMsg);
        }
        default:
        {
            sprintf(m_szErrMsg, "CRecvBkCmt841::EndDay. ��������ж���״̬��״̬�Ƿ�[%s].",
                  db_checkState);
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, m_szErrMsg);
        }
        
    }
            
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkCmt841::EndDay");
    return;
}


