/******************************************************************** 
�ļ����� recv714.cpp
�����ˣ� yszhong
��  �ڣ� 2011-03-18
�޸��ˣ� 
��  �ڣ� 
��  ���� ������˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkhvps714.h"

using namespace ZFPT;

CRecvBkHvps714::CRecvBkHvps714()
{

    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps714::CRecvBkHvps714()");
}


CRecvBkHvps714::~CRecvBkHvps714()
{
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps714::~CRecvBkHvps714()");
}

INT32 CRecvBkHvps714::Work(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps714::doWork()");
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "level CRecvBkHvps714::doWork()");

	//do nothing
	return RTN_SUCCESS;
}



