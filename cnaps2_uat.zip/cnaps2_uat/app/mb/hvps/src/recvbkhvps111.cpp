/******************************************************************** 
�ļ����� recv111.cpp
�����ˣ� yszhong
��  �ڣ� 2011-03-18
�޸��ˣ� 
��  �ڣ� 
��  ���� ������˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkhvps111.h"

using namespace ZFPT;

CRecvBkHvps111::CRecvBkHvps111()
{
    m_iMsgVer  = 2;
    m_strMsgTp = "hvps.111.001.01";
    m_strMsgDirect = "";

    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps111::CRecvBkHvps111()");
}


CRecvBkHvps111::~CRecvBkHvps111()
{
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps111::~CRecvBkHvps111()");
}

INT32 CRecvBkHvps111::Work(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps111::doWork()");

	
	// 1.��������
	unPack(pchMsg);
	
	// 2.��m_cHvrcvexchglist�ĳ�Ա��ֵ
	SetData(pchMsg);
	
	// 3.����������ʻ����ϸ��hv_rcvexchglist����������
	InsertData();
		
	// 4.��ǩ
	CheckSign111();
	

	
	if( NULL != strstr(m_cHvps111.CtgyPurpPrtry.c_str(),"A105") )//������˻����ѯԭҵ��
	{
	    UpdateOrgData();
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps111::doWork()");
	
	return RTN_SUCCESS;
}



INT32 CRecvBkHvps111::unPack(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps111::unPack()");
    
    // 1�������Ƿ�Ϊ��
    if (NULL == pchMsg || '\0' == pchMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_strBizCode.c_str(), "����Ϊ��");
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }
    
    int iRet = RTN_FAIL;
    
    // 3����������
    iRet = m_cHvps111.ParseXml(pchMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CRecvBkHvps111::Work(): ��������ʧ��");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������!");
    }
    
    // ��ȡUstrd�ֶε�ֵ
    GetUstrdData(m_cHvps111.Ustrd);

    ZFPTLOG.SetLogInfo("111", m_cHvps111.MsgId.c_str());
    
    // ���ı�ʶ��,����д�����ļ�����
    m_strMsgID = m_cHvps111.MsgId;
        
    m_strWorkDate   =   m_sWorkDate;
     
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps111::unPack()");	
    
    return RTN_SUCCESS;
}

void CRecvBkHvps111::CheckSign111()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps111::CheckSign111()");
	
	m_cHvps111.getOriSignStr();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSignBuff = [%s]", m_cHvps111.m_sSignBuff.c_str());	
	
	CheckSign(m_cHvps111.m_sSignBuff.c_str(),
			m_cHvps111.m_szDigitSign.c_str(),
			m_cHvps111.DbtrAgtMmbId.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSignBuff = [%s]", m_cHvps111.m_sSignBuff.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps111::CheckSign111()");
}

/******************************************************************************
*  Function:   GetUstrdData
*  Description:��ȡUstrd�ֶε�ֵ
*  Input:	   ��
*  Output:	   
*  Return:	   0   : �����ɹ�,
			   ����: ����ʧ��
*  Others:	   ��
*  Author:	   zys
*  Date:	   2011-05-12
*******************************************************************************/
void CRecvBkHvps111::GetUstrdData(string &strUstrd)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps111::GetUstrdData()");

    strUstrd.clear();
    
    typedef map<string, string>::iterator mapUstrdIter;
    int iUstrdSum   = m_cHvps111.m_pXMLProc.m_PMTSUstrdDataMap.size();
    mapUstrdIter it = m_cHvps111.m_pXMLProc.m_PMTSUstrdDataMap.begin();

    for(; it != m_cHvps111.m_pXMLProc.m_PMTSUstrdDataMap.end(); ++it)
    {
        strUstrd += it->second;

        strUstrd += ":";
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps111::GetUstrdData()");

}

/******************************************************************************
*  Function:   SetData
*  Description:
*  Input:      ��
*  Output:     
*  Return:     0   : �����ɹ�,
               ����: ����ʧ��
*  Others:     ��
*  Author:     zys
*  Date:       2011-02-17
*******************************************************************************/
INT32 CRecvBkHvps111::SetData(LPCSTR pchMsg)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps111::SetData()");
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "receive msg len = [%d]", strlen(pchMsg));
    string strTemp;
    m_cHvrcvexchglist.m_consigndate  = m_cHvps111.MsgId.substr(0, 8);               // ί������:�������ĵ��ڹ�������
    m_cHvrcvexchglist.m_mesgid       = m_cHvps111.m_PMTSHeader.getMesgID();       //ͨ�ż���ʶ��
    m_cHvrcvexchglist.m_mesgrefid    = m_cHvps111.m_PMTSHeader.getMesgRefID();    //ͨ�ż��ο���

    //==============================m_cHvrcvexchglist�ֶ�==============================
    //m_cHvrcvexchglist.m_finalstatedate = m_strWorkDate;                // ��������       
    m_cHvrcvexchglist.m_purpprtry      = m_cHvps111.PurpPrtry;         // ҵ���������
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_purpprtry = %s", m_cHvrcvexchglist.m_purpprtry.c_str());
    m_cHvrcvexchglist.m_busistate      = "";                 // ҵ��״̬   
    m_cHvrcvexchglist.m_processcode    = "";                           // ҵ������
    m_cHvrcvexchglist.m_rjctinf        = "";                           // ҵ��ܾ���Ϣ
    m_cHvrcvexchglist.m_acctstate      = "";                           // ����״̬
    m_cHvrcvexchglist.m_acctregnum     = "";                           // ������ˮ��
    m_cHvrcvexchglist.m_checkstate     = PR_HVBP_00;                  // ��NPC����״̬
    m_cHvrcvexchglist.m_mbcheckstate   = PR_HVBP_00;                  // �����ڶ���״̬
    //m_cHvrcvexchglist.m_ustrdstr       = m_cHvps111.Ustrd;             // ������  
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_ustrdstr = [%s]", m_cHvrcvexchglist.m_ustrdstr.c_str());
    m_cHvrcvexchglist.m_reserve        = "";                           // ������
    m_cHvrcvexchglist.m_npcmsg         = pchMsg;                       // NPC����
    m_cHvrcvexchglist.m_mbmsg          = "";                           // MB����
    m_cHvrcvexchglist.m_printno        = 0;                            // ��ӡ����
    m_cHvrcvexchglist.m_workdate       = m_strWorkDate;                // ��������
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_workdate = [%s]", m_cHvrcvexchglist.m_workdate.c_str());
    m_cHvrcvexchglist.m_msgtp          = m_strMsgTp;                   // ��������
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_msgtp = [%s]", m_cHvrcvexchglist.m_msgtp.c_str());
    m_cHvrcvexchglist.m_msgid          = m_cHvps111.MsgId;           // ���ı�ʶ��
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_msgid = [%s]", m_cHvrcvexchglist.m_msgid.c_str());
    m_cHvrcvexchglist.m_endtoendid     = m_cHvps111.EndToEndId;      // �˵��˱�ʶ��
    m_cHvrcvexchglist.m_instgdrctpty   = m_cHvps111.DbtrAgtMmbId;    // ����ֱ�Ӳ������=����������
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_instgdrctpty = [%s]", m_cHvrcvexchglist.m_instgdrctpty.c_str());
    m_cHvrcvexchglist.m_instgindrctpty = m_cHvps111.DbtrAgtId;       // ����������=������	
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_instgindrctpty = [%s]", m_cHvrcvexchglist.m_instgindrctpty.c_str());
    m_cHvrcvexchglist.m_instddrctpty   = m_cHvps111.CdtrAgtMmbId;    // ����ֱ�Ӳ������=�տ�������
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_instddrctpty = [%s]", m_cHvrcvexchglist.m_instddrctpty.c_str());
    m_cHvrcvexchglist.m_instdindrctpty = m_cHvps111.CdtrAgtId;       // ���ղ������=�տ���
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_instdindrctpty = [%s]", m_cHvrcvexchglist.m_instdindrctpty.c_str());

    m_cHvrcvexchglist.m_sttlmprty      = m_cHvps111.SttlmPrty;                // ҵ�����ȼ�
    m_cHvrcvexchglist.m_dbtmmbid      = m_cHvps111.DbtrAgtMmbId;    // �����������к�
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_dbtrmmbid = [%s]", m_cHvrcvexchglist.m_dbtrmmbid.c_str());
    m_cHvrcvexchglist.m_dbtnm          = m_cHvps111.DbtrNm;          // ����������
    m_cHvrcvexchglist.m_dbtracctid     = m_cHvps111.DbtrAcctId;      // �������ʺ�
    m_cHvrcvexchglist.m_dbtid          = m_cHvps111.DbtrAgtId;       // �������к�
    m_cHvrcvexchglist.m_dbtrissr       = m_cHvps111.DbtrAcctIssr;    // �����˿������к�
    m_cHvrcvexchglist.m_cdtmmbid      = m_cHvps111.CdtrAgtMmbId;    // �տ��������к�
    m_cHvrcvexchglist.m_cdtrnm         = m_cHvps111.CdtrNm;          // �տ��˻���
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_dbtnm = [%s]", m_cHvrcvexchglist.m_dbtnm.c_str());
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cdtrnm = [%s]", m_cHvrcvexchglist.m_cdtrnm.c_str());
    m_cHvrcvexchglist.m_cdtracctid     = m_cHvps111.CdtrAcctId;      // �տ����ʺ�
    m_cHvrcvexchglist.m_cdtid          = m_cHvps111.CdtrAgtId;       // �տ����к�
    m_cHvrcvexchglist.m_cdtrissr       = m_cHvps111.CdtrAcctIssr;    // �տ��˿������к�
    m_cHvrcvexchglist.m_procstate      = PR_HVBP_08;                  // ����״̬:11������
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_procstate = [%s]", m_cHvrcvexchglist.m_procstate.c_str());
    m_cHvrcvexchglist.m_amount         = atof(m_cHvps111.IntrBkSttlmAmt.c_str());     // ���׽��
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_amount = [%f]", m_cHvrcvexchglist.m_amount);
    m_cHvrcvexchglist.m_currency       = m_cHvps111.Ccy;             // ���ҷ���
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_currency = [%s]", m_cHvrcvexchglist.m_currency.c_str());
    m_cHvrcvexchglist.m_ctgypurpprtry  = m_cHvps111.CtgyPurpPrtry;   // ҵ�����ͱ���
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_ctgypurpprtry = [%s]", m_cHvrcvexchglist.m_ctgypurpprtry.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_iststatetime = [%s]", m_cHvrcvexchglist.m_iststatetime.c_str());
    //m_cHvrcvexchglist.m_isrbflg        = m_cParser111.CtgyPurpPrtry;   // �Ƿ��˻��־
    //m_cHvrcvexchglist.m_recvdest       = m_cParser111.CtgyPurpPrtry;   // ����Ŀ��
    m_cHvrcvexchglist.m_dbtaddr        = m_cHvps111.DbtrAdrLine;     // �����˵�ַ
    m_cHvrcvexchglist.m_cdtaddr        = m_cHvps111.CdtrAdrLine;     // �տ��˵�ַ
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_dbtaddr = [%s]", m_cHvrcvexchglist.m_dbtaddr.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cdtaddr = [%s]", m_cHvrcvexchglist.m_cdtaddr.c_str());
    m_cHvrcvexchglist.m_clrmbid1       = m_cHvps111.ClrMbId1;//�н����1
    m_cHvrcvexchglist.m_clrmbid1name   = m_cHvps111.ClrMbId1Nm;// �н����1����
    m_cHvrcvexchglist.m_clrmbid2       = m_cHvps111.ClrMbId2;//�н����2
    m_cHvrcvexchglist.m_clrmbid2name   = m_cHvps111.ClrMbId2Nm;//�н����2����
    m_cHvrcvexchglist.m_dbtrlssrnm     = m_cHvps111.DbtrAcctIssrNm;// �����˿���������
    m_cHvrcvexchglist.m_cdtrlssrnm     = m_cHvps111.CbtrAcctIssrNm;//�տ��˿���������
    m_cHvrcvexchglist.m_msgdirect      = "0";//�տ��˿���������
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_srcflag = [%s]", m_cHvrcvexchglist.m_srcflag.c_str());
    
    int iCount = m_cHvps111.m_pXMLProc.m_PMTSUstrdDataMap.size();
    for(int i = 0;i < iCount ;i++)
    {
        strTemp = m_cHvps111.GetUstrd(i);
        
        if(NULL != strstr(strTemp.c_str(),"/H01/"))
        {
            GetTagVal(m_cHvrcvexchglist.m_rmk , strTemp, "/H01/"); //��ע
            m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp + ":";
            continue;

        }
        else if(NULL != strstr(strTemp.c_str(),"/H02/"))
        {
            GetTagVal(m_cHvrcvexchglist.m_remark, strTemp, "/H02/"); //��ע2
            m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp + ":";
            continue;

        }
        else if(NULL != strstr(strTemp.c_str(),"/H03/"))
        {
 			GetTagVal(m_cHvrcvexchglist.m_addinfo, strTemp, "/H03/"); //����
            m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp + ":";
            continue;

        }
        else if(NULL != strstr(strTemp.c_str(),"/H04/"))
        {
            GetTagVal(m_cHvrcvexchglist.m_addinfo2, strTemp, "/H04/"); //����2
            m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp + ":";
            continue;

        }
        else if(NULL != strstr(strTemp.c_str(),"/C00/"))
        {
            GetTagVal(m_cHvrcvexchglist.m_finalstatedate, strTemp, "/C00/"); //��������
            m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            continue;

        }
        
        if(NULL != strstr(m_cHvps111.CtgyPurpPrtry.c_str(),"A111"))//��ҵ��Ʊ
        {
        
            if(NULL != strstr(strTemp.c_str(),"/C03/"))
            {
                // ��Ʊ����
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
             if(NULL != strstr(strTemp.c_str(),"/D15/"))
            {
                // ��Ʊ���
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/B18/"))
            {
                // �������˺�
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/B15/"))
            {
                // ����������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/D16/"))
            {
                // ʵ�ʽ�����
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/D17/"))
            {
                // ������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "δ֪����Ϣ:strTemp = [%s]",strTemp.c_str());
            }
            
        }
        if(NULL != strstr(m_cHvps111.CtgyPurpPrtry.c_str(),"A109"))//ί���տ�
        {
        
            if(NULL != strstr(strTemp.c_str(),"/C0C/"))
            {
                // Ʊ������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            if(NULL != strstr(strTemp.c_str(),"/F1A/"))
            {
                // ƾ֤����
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "δ֪����Ϣ:strTemp = [%s]",strTemp.c_str());
            }
            
        }
        if(NULL != strstr(m_cHvps111.CtgyPurpPrtry.c_str(),"A110"))//���ճи�
        {
        
            if(NULL != strstr(strTemp.c_str(),"/C0D/"))
            {
                // Ʊ������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/D38/"))
            {
                //  �⳥���
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/D39/"))
            {
                //  �ܸ����
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/D0M/"))
            {
                //   ԭ�н��
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/D0N/"))
            {
                //  ֧�����
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/D0O/"))
            {
                //  �ึ���
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            
            else
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "δ֪����Ϣ:strTemp = [%s]",strTemp.c_str());
            }
            
        }
        else if(NULL != strstr(m_cHvps111.CtgyPurpPrtry.c_str(),"A105"))//�˻�
        {
        
            if(NULL != strstr(strTemp.c_str(),"/E51/"))
            {
                // ԭ���ı�ʶ��
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
                m_cHvsndexchglist.m_msgid = strTemp.c_str()+strlen("/E51/");//Ϊ����ԭҵ��ֵ����

            }
            else if(NULL != strstr(strTemp.c_str(),"/A70/"))
            {
                // ԭ����������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
                m_cHvsndexchglist.m_instgindrctpty = strTemp.c_str()+strlen("/A70/");//Ϊ����ԭҵ��ֵ����
            }
            else if(NULL != strstr(strTemp.c_str(),"/F40/"))
            {
                // ԭ�������ʹ���
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H20/"))
            {
                //   �˻�ԭ��
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }      
            else
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "δ֪����Ϣ:strTemp = [%s]",strTemp.c_str());
            }
        }
        else if(NULL != strstr(m_cHvps111.CtgyPurpPrtry.c_str(),"A113"))//�羳֧��
        {
            if(NULL != strstr(strTemp.c_str(),"/C14/"))
            {
                //  ����ҵ��ί������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/F56/"))
            {
                // ���ñ���
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/D63/"))
            {
                // �����е��շ�
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/D64/"))
            {
                // �ձ��е��շ�
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H19/"))
            {
                // �羳ҵ����
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H32/"))
            {
                // �տ�������2 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H33/"))
            {
                // �տ�������3 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H34/"))
            {
                // �տ��˵�ַ2 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H35/"))
            {
                // �տ��˵�ַ3 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H36/"))
            {
                // �տ��˵�ַ4 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H37/"))
            {
                // �տ��˵�ַ5 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/B29/"))
            {
                // �տ����˺�2 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            } 
            else if(NULL != strstr(strTemp.c_str(),"/H38/"))
            {
                // ����������2 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H39/"))
            {
                // ����������3 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H40/"))
            {
                // �����˵�ַ2 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H41/"))
            {
                // �����˵�ַ3 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/H42/"))
            {
                // �����˵�ַ4 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            } 
            else if(NULL != strstr(strTemp.c_str(),"/H43/"))
            {
                // �����˵�ַ5 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/B30/"))
            {
                // �������˺�2 
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
            }         
            else
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "δ֪����Ϣ:strTemp = [%s]",strTemp.c_str());
            }
        }        
        else if(NULL != strstr(m_cHvps111.CtgyPurpPrtry.c_str(),"A201"))//֧Ʊ
        {
        
            if(NULL != strstr(strTemp.c_str(),"/C17/"))
            {
                //  ��Ʊ����
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";

            }
            else if(NULL != strstr(strTemp.c_str(),"/B21/"))
            {
                // ��Ʊ������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";

            }
            else if(NULL != strstr(strTemp.c_str(),"/D30/"))
            {
                // Ʊ�ݽ��
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";

            }
            else if(NULL != strstr(strTemp.c_str(),"/D0A/"))
            {
                // �Ƽ�
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";

            }      
            else if(NULL != strstr(strTemp.c_str(),"/E41/"))
            {
                // Ʊ������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";

            }      
            else
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "δ֪����Ϣ:strTemp = [%s]",strTemp.c_str());
            }
        }
        else if(NULL != strstr(m_cHvps111.CtgyPurpPrtry.c_str(),"A202") && 
                NULL != strstr(m_cHvps111.PurpPrtry.c_str(),"02901" ))//������ҵ���л�Ʊ&&���л�Ʊ�ʽ��ƴ�
        {
        
            if(NULL != strstr(strTemp.c_str(),"/C10/"))
            {
                //  ��Ʊ����
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";

            }
            else if(NULL != strstr(strTemp.c_str(),"/E15/"))
            {
                // ��Ʊ��Ѻ
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";

            }
            else if(NULL != strstr(strTemp.c_str(),"/F51/"))
            {
                //  ��Ʊ����
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";

            }
            else if(NULL != strstr(strTemp.c_str(),"/B13/"))
            {
                //Ʊ����ص��տ�������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";

            }      
            
            else if(NULL != strstr(strTemp.c_str(),"/A07/"))
            {
                // �ֽ��Ʊ�Ҹ���
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";

            }      
            else
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "δ֪����Ϣ:strTemp = [%s]",strTemp.c_str());
            }
       }
        else if(NULL != strstr(m_cHvps111.CtgyPurpPrtry.c_str(),"A202")&&
                NULL != strstr(m_cHvps111.PurpPrtry.c_str(),"02902" ))//������ҵ���л�Ʊ&&���л�Ʊ�ʽ�����
        {
        
            if(NULL != strstr(strTemp.c_str(),"/C10/"))
            {
                //  ��Ʊ����
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }
            else if(NULL != strstr(strTemp.c_str(),"/E15/"))
            {
                // ��Ʊ��Ѻ
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }
            else if(NULL != strstr(strTemp.c_str(),"/D14/"))
            {
                //  ��Ʊ���
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }
            else if(NULL != strstr(strTemp.c_str(),"/A59/"))
            {
                //��Ʊǩ�����к�
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }      
            else if(NULL != strstr(strTemp.c_str(),"/B11/"))
            {
                // ��Ʊ�������˺�
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }      
            else if(NULL != strstr(strTemp.c_str(),"/B17/"))
            {
                //��Ʊ����������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }      
            else if(NULL != strstr(strTemp.c_str(),"/B13/"))
            {
                // Ʊ����ص��տ�������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }      
            else if(NULL != strstr(strTemp.c_str(),"/D31/"))
            {
                //  ������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }      
            else
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "δ֪����Ϣ:strTemp = [%s]",strTemp.c_str());
            }
        }
        else if(NULL != strstr(m_cHvps111.CtgyPurpPrtry.c_str(),"A202")&&
                NULL != strstr(m_cHvps111.PurpPrtry.c_str(),"02903" ))//������ҵ���л�Ʊ&&���л�Ʊ�ʽ���໮��
        {
        
            if(NULL != strstr(strTemp.c_str(),"/C10/"))
            {
                //  ��Ʊ����
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }
            else if(NULL != strstr(strTemp.c_str(),"/E15/"))
            {
                // ��Ʊ��Ѻ
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }
            else if(NULL != strstr(strTemp.c_str(),"/D14/"))
            {
                //  ��Ʊ���
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }
            else if(NULL != strstr(strTemp.c_str(),"/A60/"))
            {
                //����Ʊ�˿�����
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }      
            else if(NULL != strstr(strTemp.c_str(),"/B12/"))
            {
                //  ����Ʊ���˺�
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }      
            else if(NULL != strstr(strTemp.c_str(),"/B22/"))
            {
                //  ����Ʊ������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }      
            else if(NULL != strstr(strTemp.c_str(),"/D11/"))
            {
                //   ʵ�ʽ�����
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }      
            else if(NULL != strstr(strTemp.c_str(),"/C19/"))
            {
                //   ��ʾ��������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }      
            else
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "δ֪����Ϣ:strTemp = [%s]",strTemp.c_str());
            }
        }
        else if(NULL != strstr(m_cHvps111.CtgyPurpPrtry.c_str(),"A202")&&
                 NULL != strstr(m_cHvps111.PurpPrtry.c_str(),"02904" ))//������ҵ���л�Ʊ&&���л�Ʊ�ʽ�δ���˻�
        {
             if(NULL != strstr(strTemp.c_str(),"/C10/"))
             {
                 //  ��Ʊ����
                 m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
         
             }
             else if(NULL != strstr(strTemp.c_str(),"/E15/"))
             {
                 // ��Ʊ��Ѻ
                 m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
         
             }
             else if(NULL != strstr(strTemp.c_str(),"/B13/"))
             {
                 //  Ʊ����ص��տ�������
                 m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
         
             }
             else if(NULL != strstr(strTemp.c_str(),"/A07/"))
             {
                 //�ֽ��Ʊ�Ҹ���
                 m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
         
             }      
             else
             {
                 Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "δ֪����Ϣ:strTemp = [%s]",strTemp.c_str());
             }
        }
        else if(NULL != strstr(m_cHvps111.CtgyPurpPrtry.c_str(),"A203"))//���л�Ʊ
        {
        
            if(NULL != strstr(strTemp.c_str(),"/C03/"))
            {
                //  ��Ʊ����
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }
            else if(NULL != strstr(strTemp.c_str(),"/D15/"))
            {
                //  ��Ʊ���
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }
            else if(NULL != strstr(strTemp.c_str(),"/B18/"))
            {
                // �������˺�
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }      
            else if(NULL != strstr(strTemp.c_str(),"/B15/"))
            {
                //����������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }      
            else if(NULL != strstr(strTemp.c_str(),"/D16/"))
            {
                // ʵ�ʽ�����
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }
            else if(NULL != strstr(strTemp.c_str(),"/D17/"))
            {
                //������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }      
            else if(NULL != strstr(strTemp.c_str(),"/F52/"))
            {
                // Ʊ������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }  
        }    
        else if(NULL != strstr(m_cHvps111.CtgyPurpPrtry.c_str(),"A204"))//���б�Ʊ
        {
        
            if(NULL != strstr(strTemp.c_str(),"/C03/"))
            {
                //  ��Ʊ����
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }
            else if(NULL != strstr(strTemp.c_str(),"/D15/"))
            {
                //  ��Ʊ���
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }
            else if(NULL != strstr(strTemp.c_str(),"/B18/"))
            {
                // �������˺�
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }      
            else if(NULL != strstr(strTemp.c_str(),"/B15/"))
            {
                //����������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }      
            else if(NULL != strstr(strTemp.c_str(),"/D16/"))
            {
                // ʵ�ʽ�����
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }

            else if(NULL != strstr(strTemp.c_str(),"/D17/"))
            {
                //������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }      
            else if(NULL != strstr(strTemp.c_str(),"/F52/"))
            {
                // Ʊ������
                m_cHvrcvexchglist.m_ustrdstr = m_cHvrcvexchglist.m_ustrdstr +  strTemp +":";
        
            }      
            else
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "δ֪����Ϣ:strTemp = [%s]",strTemp.c_str());
            }
        }
        else
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "δ֪��ҵ������:strTemp = [%s]",strTemp.c_str());
        }
    }
        
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps111::SetData()");

    return RTN_SUCCESS;
}

/******************************************************************************
*  Function:   InsertData
*  Description:������ʻ����ϸ��hv_rcvexchglist�����¼
*  Input:      ��
*  Output:     
*  Return:     0   : �����ɹ�,
               ����: ����ʧ��
*  Others:     ��
*  Author:     zys
*  Date:       2011-02-17
*******************************************************************************/
INT32 CRecvBkHvps111::InsertData(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps111::InsertData()");

    int iRet = RTN_FAIL;

	//1����������
    iRet = m_cHvrcvexchglist.setctx(m_dbproc);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_strMsgID.c_str(), "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }

	//2���������ݿ�
	iRet = m_cHvrcvexchglist.insert();
    if (RTN_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg, "������ʻ����ϸ��hv_rcvexchglist��������ʧ��[%s], [%d][%s]", 
            m_strMsgID.c_str(), iRet, m_cHvrcvexchglist.GetSqlErr());
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps111::InsertData()");

    return RTN_SUCCESS;
}

int CRecvBkHvps111::ChargeMB()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkHvps111::ChargeMB...");

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkHvps111::ChargeMB..."); 
    
    return RTN_SUCCESS;
}

int CRecvBkHvps111::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkHvps111::FundSettle...");
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_cHvrcvexchglist.m_instdindrctpty.c_str());

	m_charge.m_amount = m_cHvrcvexchglist.m_amount;	//ҵ����
	m_charge.m_iDCFlag = iCREDITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, m_szOprUserNetId);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_cHvrcvexchglist.m_instdindrctpty.c_str());	//����������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(RTN_SUCCESS != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FundSettle iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkHvps111::FundSettle..."); 
    
    return RTN_SUCCESS;
}

int CRecvBkHvps111::UpdateOrgData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkHvps111::UpdateOrgData...");
    
    SETCTX(m_cHvsndexchglist);
	int iRet = m_cHvsndexchglist.findByPK();
	if(RTN_SUCCESS != iRet)
	{
		if (iRet == SQLNOTFOUND){
			SETCTX(m_cHvsndexchglisthis);
			m_cHvsndexchglisthis.m_msgid = m_cHvsndexchglist.m_msgid;
			m_cHvsndexchglisthis.m_instdindrctpty = m_cHvsndexchglist.m_instgindrctpty;
			iRet = m_cHvsndexchglisthis.findByPK();
			if (iRet != SQL_SUCCESS){
				if (iRet != SQLNOTFOUND){
					Trace(L_ERROR,  __FILE__,  __LINE__, NULL,
							"��ȡ����ʧ��, iRet = %d, [%s]", iRet, m_cHvsndexchglisthis.GetSqlErr());
					PMTS_ThrowException(DB_FIND_FAIL);
				}
				else{
					Trace(L_INFO, __FILE__, __LINE__, NULL, "�Ҳ���ԭҵ��!");
					return 0;
				}
			}
			else{
				m_strOrgnlTable = "hv_sndexchglisthis";
				//m_strMsgDirect  = m_cHvsndexchglisthis.m_msgdirect.c_str();
			}
		}
		else{
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL,
					"��ȡ����ʧ��, iRet = %d, [%s]", iRet, m_cHvsndexchglist.GetSqlErr());
			PMTS_ThrowException(DB_FIND_FAIL);
		}
	}
	else{
		m_strOrgnlTable = "hv_sndexchglist";
		//m_strMsgDirect  = m_cHvsndexchglist.m_msgdirect.c_str();
	}
	
	string strSQL;
	strSQL += " UPDATE ";
	strSQL += m_strOrgnlTable;
	strSQL += " t SET t.ISRBFLG = '1' ";
	strSQL += " WHERE t.MSGID = '";
	strSQL += m_cHvsndexchglist.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_cHvsndexchglist.m_instgindrctpty.c_str(); 									
	strSQL += "' ";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());
	
	 iRet = m_cHvsndexchglist.execsql(strSQL.c_str());
    if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL, "Update failed,SQLNOTFOUND, sqlcode=[%d]", iRet);
	}
	else if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��iRet=%d, %s", iRet, m_cHvsndexchglist.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}  
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkHvps111::UpdateOrgData..."); 
    return RTN_SUCCESS;
    
}




