/******************************************************************** 
�ļ����� recv141.cpp
�����ˣ� yszhong
��  �ڣ� 2011-03-18
�޸��ˣ� 
��  �ڣ� 
��  ���� ������˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkhvps141.h"

using namespace ZFPT;

CRecvBkHvps141::CRecvBkHvps141()
{
    m_iMsgVer  = 2;
    m_strMsgTp = "hvps.141.001.01";
    m_strSignSub = "";

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps141::CRecvBkHvps141()");
}

CRecvBkHvps141::~CRecvBkHvps141()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps141::~CRecvBkHvps141()");
}

INT32 CRecvBkHvps141::Work(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps141::doWork()");
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "recvMsg=[%s]",pchMsg);
	// 1.��������
	unPack(pchMsg);
	
	// 2.��m_cHvtrofacrcvlist�ĳ�Ա��ֵ
	SetData(pchMsg);
	
	// 3.������ʱת�˱�hv_trofacsndlist����������
	InsertData();
	
	// 4.��ǩ
	CheckSign141();
	
	string instdpty="";
	STRING strSql="";
	if("CRDT"==m_cHvtrofacrcvlist.m_cdcode)
	{
	    instdpty = m_cParser141.CdtrId;

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "�����ʶΪ���ǣ�����ͷ����");
		
		strSql = "UPDATE SYS_SAPBANKINFO  SET ALIMIT = ALIMIT + ";
	}
	else
	{
	    instdpty = m_cParser141.DbtrId;   

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "�����ʶΪ��ǣ��۳�ͷ����");
		
		strSql = "UPDATE SYS_SAPBANKINFO  SET ALIMIT = ALIMIT - ";
	}
	
	strSql += m_cParser141.IntrBkSttlmAmt;
	strSql += " WHERE SAPBANK ='";	
	strSql += m_cHvtrofacrcvlist.m_instddrctpty + "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=[%s]",strSql.c_str());
	
	int iRet = m_cHvtrofacrcvlist.execsql(strSql);
	
	if(iRet != RTN_SUCCESS)
	{
		sprintf(m_szErrMsg,"execsql() error,error code = [%d] error cause =[%s]",iRet,m_cHvtrofacrcvlist.GetSqlErr());
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException( __FILE__,__LINE__,DB_UPDATE_FAIL,m_szErrMsg);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps141::doWork()");
	
	return RTN_SUCCESS;
}

INT32 CRecvBkHvps141::unPack(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps141::unPack()");
    
    // 1�������Ƿ�Ϊ��
    if (NULL == pchMsg || '\0' == pchMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_strBizCode.c_str(), "����Ϊ��");
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }
    
    int iRet = RTN_FAIL;
    
    // 3����������
    iRet = m_cParser141.ParseXml(pchMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CRecvBkHvps141::Work(): ��������ʧ��");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������!");
    }

    ZFPTLOG.SetLogInfo("141", m_cParser141.MsgId.c_str());
    
    // ���ı�ʶ��,����д�����ļ�����
    m_strMsgID = m_cParser141.MsgId;

    m_strWorkDate = m_sWorkDate;
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps141::unPack()");    
    
    return RTN_SUCCESS;
}

void CRecvBkHvps141::CheckSign141()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps141::CheckSign141()");
	
	m_cParser141.getOriSignStr();
	m_cParser141.m_sSignBuff += m_strSignSub;
	CheckSign(m_cParser141.m_sSignBuff.c_str(),
						m_cParser141.m_szDigitSign.c_str(),
						m_cParser141.InstgAgtMmbId.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps141::CheckSign141()");
}

/******************************************************************************
*  Function:   SetData
*  Description:
*  Input:      ��
*  Output:     
*  Return:     0   : �����ɹ�,
               ����: ����ʧ��
*  Others:     ��
*  Author:     zys
*  Date:       2011-02-17
*******************************************************************************/
INT32 CRecvBkHvps141::SetData(LPCSTR pchMsg)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps141::SetData()");
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "pchMsg=[%s]", pchMsg);
    
    string strTemp;
    
    char DbSapBank[15] = {0};
    char CDSapBank[15] = {0};
    int iRet = GetSapBank(m_dbproc, m_cParser141.DbtrId.c_str(), DbSapBank);
    int iRet1 = GetSapBank(m_dbproc, m_cParser141.CdtrId.c_str(), CDSapBank); 
    if(iRet != 0 || iRet1 != 0)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, 
            "��ȡ��������Ϣʧ��m_cParser141.DbtrId.c_str()[%s],iRet[%d],m_cParser141.CdtrId.c_str()[%s],iRet1[%d]",
            m_cParser141.DbtrId.c_str(),iRet,m_cParser141.CdtrId.c_str(),iRet1);
        PMTS_ThrowException(PRM_FAIL);        
    }
    
    //==============================m_cHvtrofacrcvlist�ֶ�==============================
    m_cHvtrofacrcvlist.m_msgid            = m_cParser141.MsgId;        // ���ı�ʶ��
    m_cHvtrofacrcvlist.m_instgdrctpty     = m_cParser141.InstgAgtMmbId;// ����ֱ�Ӳ������=����������
    m_cHvtrofacrcvlist.m_workdate         = m_strWorkDate;             // ��������

    m_cHvtrofacrcvlist.m_srcflag = "1";

    m_cHvtrofacrcvlist.m_consigndate  = m_cParser141.MsgId.substr(0, 8);                 //ί������:�������ĵ��ڹ�������
    
    m_cHvtrofacrcvlist.m_mesgid       = m_cParser141.m_PMTSHeader.getMesgID();       // ͨ�ż���ʶ��
    m_cHvtrofacrcvlist.m_mesgrefid    = m_cParser141.m_PMTSHeader.getMesgRefID();    // ͨ�ż��ο���
    
    m_cHvtrofacrcvlist.m_msgtp            = m_strMsgTp;                // ��������
    m_cHvtrofacrcvlist.m_endtoendid       = m_cParser141.EndToEndId;   // �˵��˱�ʶ��
    //m_cHvtrofacrcvlist.m_msgdirect        = "2";                       // ҵ����Դ0:MB1:PMTS2:NPC
    Trim(m_cParser141.m_PMTSHeader.getOrigSender());
    m_cHvtrofacrcvlist.m_instgindrctpty   = m_cParser141.InstgAgtMmbId;   // ����������
    Trim(m_cParser141.m_PMTSHeader.getOrigReceiver());
    
    //m_cHvtrofacrcvlist.m_instddrctpty     = m_cParser141.m_PMTSHeader.getOrigReceiver();    // ����ֱ�Ӳ������:����������
    //m_cHvtrofacrcvlist.m_instdindrctpty   = m_cParser141.m_PMTSHeader.getOrigReceiver();       // ���ղ������:�������к�
    m_cHvtrofacrcvlist.m_spjoinmmbid      = m_cParser141.InstgAgtMmbId; 	// ���������߻���
    m_cHvtrofacrcvlist.m_dbtmmbid         = m_cParser141.DbtrMmbId;    // �����������к�
    m_cHvtrofacrcvlist.m_dbtnm            = m_cParser141.DbtrNm;       // ����������
    m_cHvtrofacrcvlist.m_dbtracctid       = m_cParser141.DbtrAcctId;   // �������ʺ�
    m_cHvtrofacrcvlist.m_dbtid            = m_cParser141.DbtrId;       // �������к�
    m_cHvtrofacrcvlist.m_dbtrissr         = m_cParser141.DbtrAcctIssr; // �����˿������к�
    m_cHvtrofacrcvlist.m_dbtrlssrnm         = m_cParser141.DbtrAcctIssrNm; // �����˿������к�
    m_cHvtrofacrcvlist.m_cdtmmbid         = m_cParser141.CdtrMmbId;    // �տ��������к�
    m_cHvtrofacrcvlist.m_cdtrnm           = m_cParser141.CdtrNm;       // R�տ��˻���
    m_cHvtrofacrcvlist.m_cdtid            = m_cParser141.CdtrId;       // �տ����к�
    m_cHvtrofacrcvlist.m_cdtracctid       = m_cParser141.CdtrAcctId;   // �տ����ʺ�
    m_cHvtrofacrcvlist.m_cdtrissr         = m_cParser141.CdtrAcctIssr; // �տ��˿������к�
    m_cHvtrofacrcvlist.m_cdtrlssrnm         = m_cParser141.CdtrAcctIssrNm; // �տ��˿������к�
    m_cHvtrofacrcvlist.m_currency         = m_cParser141.Ccy;          // ���ҷ���
    m_cHvtrofacrcvlist.m_amount           = atof(m_cParser141.IntrBkSttlmAmt.c_str());     // ���׽��
    m_cHvtrofacrcvlist.m_ctgypurpprtry    = m_cParser141.Prtry;        // ҵ�����ͱ���
    m_cHvtrofacrcvlist.m_procstate        = PR_HVBP_08;               //����״̬:11������
    char isodate[10+1] = {0};
    chgToISODate(m_cHvtrofacrcvlist.m_consigndate.c_str(), isodate);
    //m_cHvtrofacrcvlist.m_finalstatedate   = isodate;             // ��������
    m_cHvtrofacrcvlist.m_busistate        = "";              // ҵ��״̬:PR04��������
    //m_cHvtrofacrcvlist.m_processcode      = "";                        // ҵ������
    m_cHvtrofacrcvlist.m_rjctinf          = "";                        // ҵ��ܾ���Ϣ
    m_cHvtrofacrcvlist.m_acctstate        = "";                        // ����״̬
    m_cHvtrofacrcvlist.m_acctregnum       = "";                        // ������ˮ��
    //m_cHvtrofacrcvlist.m_reacregnum       = "";                      // ������ˮ��
    //m_cHvtrofacrcvlist.m_checkstate       = PR_HVBP_00;               // ��NPC����״̬
    m_cHvtrofacrcvlist.m_mbcheckstate     = PR_HVBP_00;               // �����ڶ���״̬
    m_cHvtrofacrcvlist.m_ustrdstr         = m_cParser141.Ustrd;        // ������
    m_cHvtrofacrcvlist.m_mbmsg            = "";                        // MB����
    m_cHvtrofacrcvlist.m_npcmsg           = pchMsg;                    // NPC����
    m_cHvtrofacrcvlist.m_reserve          = "";                        // ������
    m_cHvtrofacrcvlist.m_printno          = 0;                         // ��ӡ����
    m_cHvtrofacrcvlist.m_dbtaddr          = m_cParser141.DbtrAdrLine;  // �����˵�ַ
    m_cHvtrofacrcvlist.m_cdtaddr          = m_cParser141.CdtrAdrLine;  // �տ��˵�ַ
    m_cHvtrofacrcvlist.m_isrbflg          = "";                        // �Ƿ��˻��־

	//3����ҵ���������ֵĸ�����

    int iCount = m_cParser141.m_pXMLProc.m_PMTSUstrdDataMap.size();
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iCount = [%d]",iCount);
    
    string strVal = "";
    for(int iDepth = 0;iDepth < iCount ;iDepth++)
    {

    	strVal.clear();

        strTemp = m_cParser141.GetUstrd(iDepth);

        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strTemp = [%s]",strTemp.c_str());
        
        if(NULL != strstr(strTemp.c_str(),"/F25/"))
        {
            GetTagVal(m_cHvtrofacrcvlist.m_purpprtry , strTemp, "/F25/"); //ҵ���������
            m_strSignSub += m_cParser141.CHECKVALUE(m_cHvtrofacrcvlist.m_purpprtry);
            m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp + ":";
            continue;
        
        }
        else if(NULL != strstr(strTemp.c_str(),"/E48/"))
        {
            GetTagVal(m_cHvtrofacrcvlist.m_tranmunum, strTemp, "/E48/"); //�������κ�
            m_strSignSub += m_cParser141.CHECKVALUE(m_cHvtrofacrcvlist.m_tranmunum);
            m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";
            continue;
        
        }
        else if(NULL != strstr(strTemp.c_str(),"/F31/"))
        {
            GetTagVal(m_cHvtrofacrcvlist.m_cdcode, strTemp, "/F31/"); //�����ʶ
            m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";
            
		    if (0 == strTemp.length())
		    {
		        sprintf(m_szErrMsg, "�����ʶΪ��");
		        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		        PMTS_ThrowException(__FILE__, __LINE__, DATA_FAIL, m_szErrMsg);
		    }
		    
    		m_cHvtrofacrcvlist.m_cdcode           = strTemp.substr(5);
    		
    		// ����ͨѶ���ֶθ�ֵ
    		m_strCdCode = ":cdcode:" + m_cHvtrofacrcvlist.m_cdcode;
    		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]", m_strCdCode.c_str());
    
            continue;
        
        }
        else if(NULL != strstr(strTemp.c_str(),"/H01/"))
        {
            GetTagVal(m_cHvtrofacrcvlist.m_rmk, strTemp, "/H01/"); //��ע
            m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";
            continue;
        }
        else if(NULL != strstr(strTemp.c_str(),"/C00/"))
        {
            GetTagVal(m_cHvtrofacrcvlist.m_finalstatedate, strTemp, "/C00/"); //��������
            m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";
            continue;
        
        }
    
        if("G101" == m_cHvtrofacrcvlist.m_ctgypurpprtry ||
        	"G102" == m_cHvtrofacrcvlist.m_ctgypurpprtry ||
        	"G103" == m_cHvtrofacrcvlist.m_ctgypurpprtry )//�����г����׽���||ծȯ�г����׽���||ծȯ���С��Ҹ������滮��
        {
            
            if(NULL != strstr(strTemp.c_str(),"/E40/")) //ծȯ/��Ʊ����
            {
            	GetTagVal(strVal, strTemp, "/E40/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp + ":";            
            }
            else if(NULL != strstr(strTemp.c_str(),"/D14/")) //ծȯ/��Ʊ���
            {
            	GetTagVal(strVal, strTemp, "/D14/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";            
            }
            else if(NULL != strstr(strTemp.c_str(),"/D32/")) //���۽��
            {
            	GetTagVal(strVal, strTemp, "/D32/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";           
            }
            else if(NULL != strstr(strTemp.c_str(),"/D33/")) //ծȯ/��Ʊ��Ϣ
            {
            	GetTagVal(strVal, strTemp, "/D33/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";           
            }
            else if(NULL != strstr(strTemp.c_str(),"/D11/")) // �ع����ڽ����
            {
            	GetTagVal(strVal, strTemp, "/D11/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";            
            }
            else if(NULL != strstr(strTemp.c_str(),"/D34/")) // �ع���Ϣ
            {
            	GetTagVal(strVal, strTemp, "/D34/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/C19/")) //�ع�������
            {
            	GetTagVal(strVal, strTemp, "/C19/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";
            }
        }

        else if("G106" == m_cHvtrofacrcvlist.m_ctgypurpprtry) //��㽻���г�����
        {            
            if(NULL != strstr(strTemp.c_str(),"/F58/")) //  ��㽻�ױ���
            {
            	GetTagVal(strVal, strTemp, "/F58/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp + ":";            
            }
        }

        else if(("G109" == m_cHvtrofacrcvlist.m_ctgypurpprtry) && ("03501" == m_cHvtrofacrcvlist.m_purpprtry)) //��Ѻ����&&����֧��
        {            
            if(NULL != strstr(strTemp.c_str(),"/D35/")) //��Ѻծȯ�����
            {
            	GetTagVal(strVal, strTemp, "/D35/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp + ":";            
            }
            else if(NULL != strstr(strTemp.c_str(),"/A07/")) //�������к�
            {
            	GetTagVal(strVal, strTemp, "/A07/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";            
            }
            else if(NULL != strstr(strTemp.c_str(),"/E50/")) //ԭ���ı�ʶ��
            {
            	GetTagVal(strVal, strTemp, "/E50/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";           
            }
            else if(NULL != strstr(strTemp.c_str(),"/A70/")) //ԭ����������
            {
            	GetTagVal(strVal, strTemp, "/A70/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";           
            }
            else if(NULL != strstr(strTemp.c_str(),"/F60/")) // ҵ��״̬
            {
            	GetTagVal(strVal, strTemp, "/F60/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";            
            }
        }

        else if(("G109" == m_cHvtrofacrcvlist.m_ctgypurpprtry) && ("03502" == m_cHvtrofacrcvlist.m_purpprtry)) //��Ѻ����&&���ʿۿ�
        {   
            
            if(NULL != strstr(strTemp.c_str(),"/D36/")) // ���ʱ���
            {
            	GetTagVal(strVal, strTemp, "/D36/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp + ":";            
            }
            else if(NULL != strstr(strTemp.c_str(),"/D35/")) //��Ѻծȯ�����
            {
            	GetTagVal(strVal, strTemp, "/D35/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";            
            }
            else if(NULL != strstr(strTemp.c_str(),"/A07/")) //�������к�
            {
            	GetTagVal(strVal, strTemp, "/A07/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";           
            }
            else if(NULL != strstr(strTemp.c_str(),"/D37/")) // ������Ϣ
            {
            	GetTagVal(strVal, strTemp, "/D37/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";           
            }
            else if(NULL != strstr(strTemp.c_str(),"/F59/")) //  ��������
            {
            	GetTagVal(strVal, strTemp, "/F59/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";            
            }
        }

		else if(("G107" == m_cHvtrofacrcvlist.m_ctgypurpprtry) || ("G108" == m_cHvtrofacrcvlist.m_ctgypurpprtry)) //�ʽ�ؽ���"��"�����Զ����
        { 
            
            if(NULL != strstr(strTemp.c_str(),"/E39/")) // ҵ��Э���
            {
            	GetTagVal(strVal, strTemp, "/E39/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp + ":";            
            }
            else if(NULL != strstr(strTemp.c_str(),"/F50/")) //���������ʶ
            {
            	GetTagVal(strVal, strTemp, "/F50/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";            
            }
            else if(NULL != strstr(strTemp.c_str(),"/F61/")) //ҵ��״̬
            {
            	GetTagVal(strVal, strTemp, "/F61/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";           
            }
            else if(NULL != strstr(strTemp.c_str(),"/G00/")) // ҵ��ܾ�������
            {
            	GetTagVal(strVal, strTemp, "/G00/");
            	m_strSignSub += m_cParser141.CHECKVALUE(strVal);
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";           
            }
        }        
    }     
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvtrofacrcvlist.m_cdcode=%s", m_cHvtrofacrcvlist.m_cdcode.c_str());
    if("CRDT" == m_cHvtrofacrcvlist.m_cdcode)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "\"CRDT\" == m_cHvtrofacrcvlist.m_cdcode");
        m_cHvtrofacrcvlist.m_instddrctpty = CDSapBank ; 
        m_cHvtrofacrcvlist.m_instdindrctpty = m_cParser141.CdtrId ; 
    }
    else
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "\"CRDT\" != m_cHvtrofacrcvlist.m_cdcode");
        m_cHvtrofacrcvlist.m_instddrctpty = DbSapBank ; 
        m_cHvtrofacrcvlist.m_instdindrctpty = m_cParser141.DbtrId ; 
    }
    
    //m_cHvtrofacrcvlist.m_recvdest         = "";                        // ����Ŀ��
    //m_cHvtrofacrcvlist.m_rsflag           = "1";                       // �ո����־:0����1����2�տ�:�����    
    
    //m_cHvtrofacrcvlist.m_statetime      = m_cHvtrofacrcvlist.CtgyPurpPrtry;   // ����״̬���ʱ��
    //m_cHvtrofacrcvlist.m_acstatetime    = m_cHvtrofacrcvlist.CtgyPurpPrtry;   // ����״̬���ʱ��
    //m_cHvtrofacrcvlist.m_iststatetime   = m_cHvtrofacrcvlist.CtgyPurpPrtry;   // ���ʱ��
    //m_cHvtrofacrcvlist.m_inputtime   = m_cHvtrofacrcvlist.CtgyPurpPrtry;   // ¼��ʱ��
    //m_cHvtrofacrcvlist.m_checktime   = m_cHvtrofacrcvlist.CtgyPurpPrtry;   // ����ʱ��
    //m_cHvtrofacrcvlist.m_granttime   = m_cHvtrofacrcvlist.CtgyPurpPrtry;   // ��Ȩʱ��
    //m_cHvtrofacrcvlist.m_inputoper   = m_cHvtrofacrcvlist.CtgyPurpPrtry;   // ¼��Ա
    //m_cHvtrofacrcvlist.m_checkoper   = m_cHvtrofacrcvlist.CtgyPurpPrtry;   // ����Ա
    //m_cHvtrofacrcvlist.m_grantoper   = m_cHvtrofacrcvlist.CtgyPurpPrtry;   // ��ȨԱ
    //==============================m_cHvtrofacrcvlist�ֶ�==============================
    
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__sub sign=[%s]", m_strSignSub.c_str());    
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps141::SetData()");
    
    return RTN_SUCCESS;
}

/******************************************************************************
*  Function:   InsertData
*  Description:��ʱת��ҵ���hv_trofacsndlist�����¼
*  Input:      ��
*  Output:     
*  Return:     0   : �����ɹ�,
               ����: ����ʧ��
*  Others:     ��
*  Author:     zys
*  Date:       2011-02-17
*******************************************************************************/
INT32 CRecvBkHvps141::InsertData(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps141::InsertData()");

    int iRet = RTN_FAIL;

    iRet = m_cHvtrofacrcvlist.setctx(m_dbproc);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_strMsgID.c_str(), "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }
    iRet = m_cHvtrofacrcvlist.insert();
    if (RTN_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg, "��ʱת��ҵ���hv_trofacrcvlist��������ʧ��[%s], [%d][%s]", 
            m_strMsgID.c_str(), iRet, m_cHvtrofacrcvlist.GetSqlErr());
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps141::InsertData()");

    return RTN_SUCCESS;
}

	
int CRecvBkHvps141::ChargeMB()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkHvps141::ChargeMB...");

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkHvps141::ChargeMB..."); 
	
	return RTN_SUCCESS;
}
