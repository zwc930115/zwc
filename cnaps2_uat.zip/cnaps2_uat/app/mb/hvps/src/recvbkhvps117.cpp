/******************************************************************** 
�ļ����� recv117.cpp
�����ˣ� zwc
��  ��   �� 2017-11-08
�޸��ˣ� 
��  �ڣ� 
��  ���� ���ڻ���������ҵ�����˱��Ĵ���(hvps.117.001.01)
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkhvps117.h"

using namespace ZFPT;

CRecvBkHvps117::CRecvBkHvps117()
{
	m_iMsgVer	=	2;
	m_strMsgTp	=	"hvps.117.001.01";
	m_strMsgDirect = "";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps117::CRecvBkHvps117()");	
}


CRecvBkHvps117::~CRecvBkHvps117()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps117::~CRecvBkHvps117()");		
}

INT32 CRecvBkHvps117::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps117::Work()");	
	
	int iRet = RTN_FAIL;
	
	// 1.��������
	unPack(sMsg);
	
	// 2.��ǩ
	CheckSign117();

    // 3.����ԭҵ��
	UpdateOriData();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps117::work()");
	
	return RTN_SUCCESS;
}



INT32 CRecvBkHvps117::unPack(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps117::unPack");	

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "receive msg len = [%d]", strlen(sMsg));
    
    int iRet = RTN_FAIL;

	//1�������Ƿ�Ϊ��
	if (NULL == sMsg || '\0' == sMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
	}

	//3����������
	iRet = m_cParser117.ParseXml(sMsg);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ParseXml[%d]", iRet);
	if (RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= %d", iRet);	
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
	}

    ZFPTLOG.SetLogInfo("117", m_cParser117.MsgId.c_str());
    
	m_strWorkDate	=	m_sWorkDate;

	m_strMsgID	=	m_cParser117.MsgId;

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps117::unPack");	

	return RTN_SUCCESS;
}

void CRecvBkHvps117::CheckSign117()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps117::CheckSign117()");
	
	m_cParser117.getOriSignStr();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSignBuff = [%s]", m_cParser117.m_sSignBuff.c_str());	
	
	CheckSign(m_cParser117.m_sSignBuff.c_str(),
						m_cParser117.m_szDigitSign.c_str(),
						m_cParser117.MmbId.c_str());
		
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps117::CheckSign117()");
}

/******************************************************************************
*  Function:   UpdateOriData
*  Description:
*  Input:      ��
*  Output:     
*  Return:     0   : �����ɹ�,
               ����: ����ʧ��
*  Others:     ��
*  Author:     zwc
*  Date:       2017-11-08
*******************************************************************************/
INT32	CRecvBkHvps117::UpdateOriData()
{
    char selectStr[200]={0};
    SETCTX(m_cHvrcvexchglist);

    sprintf(selectStr," MSGID='%s' and MSGTP='%s' and INSTDDRCTPTY='%s'",
             m_cParser117.OrgnlMsgId.c_str(),
             m_cParser117.OrgnlMsgNmId.c_str(),
             m_cParser117.MmbId.c_str());

    int rc = m_cHvrcvexchglist.find(selectStr);
	if(rc != 0)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "û���ҵ�����������ԭ���ף�selectStr =[%s]",selectStr);
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭ����");
	}
	rc = m_cHvrcvexchglist.fetch();
	if(rc ==SQLNOTFOUND)
	{
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������iRet=[%d]",rc);
	    //m_cHvrcvexchglist.closeCursor();
	    PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "m_cHvrcvexchglistû���ҵ�����������ԭҵ��");
	}


    if (m_cParser117.StsId == "PR10")
    {

        m_cHvrcvexchglist.m_procstate  = PR_HVBP_07;
        m_cHvrcvexchglist.m_busistate  = m_cParser117.StsId; 
    }
    else 
    {
    	m_cHvrcvexchglist.m_processcode= m_cParser117.Prtry;
        m_cHvrcvexchglist.m_procstate  = PR_HVBP_07;
        m_cHvrcvexchglist.m_busistate  = m_cParser117.StsId; 
        m_cHvrcvexchglist.m_rjctinf    = m_cParser117.AddtlInf2;
    }
    
    rc = m_cHvrcvexchglist.updatestate();
    if (rc != SQL_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CRecvBkHvps132::UpdateOriData(): ����ԭ����ʧ��");
        return RTN_FAIL;
    }
    
    m_cHvrcvexchglist.closeCursor();
    return RTN_SUCCESS;

}


