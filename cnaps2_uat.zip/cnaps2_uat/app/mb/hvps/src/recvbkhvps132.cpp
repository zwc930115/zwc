
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkhvps132.h"

using namespace ZFPT;

CRecvBkHvps132::CRecvBkHvps132()
{
}

CRecvBkHvps132::~CRecvBkHvps132()
{
}

// ҵ����ں���
INT32 CRecvBkHvps132::Work(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps132::doWork()");

	unPack(pchMsg);

	CheckSign132();

	UpdateOriData();

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps132::doWork()");
	
	return RTN_SUCCESS;
}

// �������Ĵ�
INT32 CRecvBkHvps132::unPack(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps132::unPack()");
    
    // 1�������Ƿ�Ϊ��
    if (NULL == pchMsg || '\0' == pchMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_strBizCode.c_str(), "����Ϊ��");
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }
    
    int iRet = RTN_FAIL;
    
    // 3����������
    iRet = m_hvps132.ParseXml(pchMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CRecvBkHvps132::Work(): ��������ʧ��");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������!");
    }

    ZFPTLOG.SetLogInfo("132", m_hvps132.MsgId.c_str());
    
    // ���ı�ʶ��,����д�����ļ�����
    m_strMsgID = m_hvps132.MsgId;

    m_strWorkDate = m_sWorkDate;
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps132::unPack()");    
    
    return RTN_SUCCESS;
}

// �������ݿ�
INT32 CRecvBkHvps132::UpdateOriData(void)
{
    char selectStr[200]={0};
    SETCTX(m_cHvtrofacrcvlist);
    //m_cHvtrofacrcvlist.m_instdindrctpty = m_hvps132.MmbId;          //����ֱ�Ӳ������к�
    //m_cHvtrofacrcvlist.m_msgid          = m_hvps132.OrgnlMsgId;     //ԭ���ı�ʶ��
    //m_cHvtrofacrcvlist.m_msgtp          = m_hvps132.OrgnlMsgNmId;   // ԭ�������ʹ���

    //int rc = m_cHvtrofacrcvlist.findByPK();
    //if (rc == SQLNOTFOUND)
    //{
    //    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CRecvBkHvps132::UpdateOriData(): ԭ���ײ�����");
    //    return RTN_FAIL;
    //}
    //else if (rc != SQL_SUCCESS)
    //{
    //    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CRecvBkHvps132::UpdateOriData(): ��ѯԭ����ʧ��");
    //    return RTN_FAIL;
    //}
    
    sprintf(selectStr," MSGID='%s' and MSGTP='%s' and INSTDDRCTPTY='%s'",
             m_hvps132.OrgnlMsgId.c_str(),
             m_hvps132.OrgnlMsgNmId.c_str(),
             m_hvps132.MmbId.c_str());

		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "m_hvps132.MsgId=[%s]",m_hvps132.MsgId.c_str());
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "selectStr=[%s]",selectStr);


    int rc = m_cHvtrofacrcvlist.find(selectStr);
	if(rc != 0)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "û���ҵ�����������ԭ���ף�selectStr =[%s]",selectStr);
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭ����");
	}
	rc = m_cHvtrofacrcvlist.fetch();
	if(rc ==SQLNOTFOUND)
	{
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������iRet=[%d]",rc);
	    //m_cHvtrofacrcvlist.closeCursor();
	    PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "m_cHvtrofacrcvlistû���ҵ�����������ԭҵ��");
	}

    m_cHvtrofacrcvlist.m_orgnlmsgid = m_hvps132.OrgnlMsgId; 
	m_cHvtrofacrcvlist.m_rspmsgtp   = "hvps.132.001.01";
	m_cHvtrofacrcvlist.m_rspmsgid   = m_hvps132.MsgId;

    char sISODateTime[100] = {0};
    GetIsoDateTime(m_dbproc, SYS_BEPS, sISODateTime);
    m_cHvtrofacrcvlist.m_rspdate    = sISODateTime;

    if (m_hvps132.StsId == "PR02")
    {
    	m_cHvtrofacrcvlist.m_rspway     = "00";
    	m_cHvtrofacrcvlist.m_rejectcode = "";
        m_cHvtrofacrcvlist.m_procstate  = "07";
        m_cHvtrofacrcvlist.m_busistate  = m_hvps132.StsId; 
    }
    else 
    {
    	m_cHvtrofacrcvlist.m_rspway     = "01";
    	m_cHvtrofacrcvlist.m_rejectcode = m_hvps132.Prtry;
        m_cHvtrofacrcvlist.m_procstate  = "07";
        m_cHvtrofacrcvlist.m_busistate  = m_hvps132.StsId; 
        m_cHvtrofacrcvlist.m_rjctinf    = m_hvps132.AddtlInf2;
    }
    
    rc = m_cHvtrofacrcvlist.updatestate();
    if (rc != SQL_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CRecvBkHvps132::UpdateOriData(): ����ԭ����ʧ��");
        return RTN_FAIL;
    }
    
    m_cHvtrofacrcvlist.closeCursor();
    return RTN_SUCCESS;
}

// ��ǩ
void CRecvBkHvps132::CheckSign132()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkHvps132::CheckSign132()");

    m_hvps132.getOriSignStr();

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSignBuff = [%s]", m_hvps132.m_sSignBuff.c_str());	

    CheckSign(m_hvps132.m_sSignBuff.c_str(),
    		m_hvps132.m_szDigitSign.c_str(),
    		m_hvps132.MmbId.c_str());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSignBuff = [%s]", m_hvps132.m_sSignBuff.c_str());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkHvps132::CheckSign132()");
}


