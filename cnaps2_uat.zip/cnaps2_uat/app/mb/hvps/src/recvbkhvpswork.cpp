
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "pubfunc.h"
#include "logger.h"
#include "recvbkhvpswork.h"
#include "recvbkhvpsbase.h"
#include "recvbkhvps111.h"
#include "recvbkhvps112.h"
//add by zwc 20171108 
#include "recvbkhvps115.h" 
#include "recvbkhvps116.h"
#include "recvbkhvps117.h"
#include "recvbkhvps118.h"
//add end
#include "recvbkhvps132.h"
#include "recvbkhvps141.h"
#include "recvbkhvps142.h"
#include "recvbkhvps144.h"
#include "recvbkhvps152.h"
#include "recvbkhvps154.h"
#include "recvbkhvps632.h"
#include "recvbkhvps633.h"
#include "recvbkhvps635.h"
#include "hvrecvmsg.h"
#include "recvbkcmt100.h"
#include "recvbkcmt101.h"
#include "recvbkcmt102.h"
#include "recvbkcmt103.h"
#include "recvbkcmt105.h"
#include "recvbkcmt108.h"
#include "recvbkcmt110.h"
#include "recvbkcmt121.h"
#include "recvbkcmt122.h"
#include "recvbkcmt123.h"
#include "recvbkcmt124.h"
#include "recvbkcmt253.h"
#include "recvbkcmt231.h"
#include "recvbkcmt725.h"
#include "recvbkcmt841.h"

#include "recvbkhvps143.h"
#include "recvbkhvps151.h"
#include "recvbkhvps153.h"
#include "recvbkhvps710.h"
#include "recvbkhvps712.h"
#include "recvbkhvps714.h"

using namespace ZFPT;

extern CConnectPool *g_DBConnPool;
extern int		g_IsConnPlatm;

CRecvbkHvpsWork::CRecvbkHvpsWork()
{
    m_sTrsCode    = "";
    m_sMsgFile    = "";
    m_strRcvMsgID = "";
}

CRecvbkHvpsWork::~CRecvbkHvpsWork()
{

}

void CRecvbkHvpsWork::setData(LPTSTR lpMsgID, int iErrMsgFlag, UINT32 len, LPCSTR data, LPCSTR lpTrsCode, LPCSTR lpMsgFile)
{    
    if(NULL != data && 0 != len)
    {
        m_vData.resize(len + 1, 0);
    
        memset(&m_vData[0], 0, len * sizeof(char));
        memcpy(&m_vData[0], data, len);
    }
    
    if(lpTrsCode != NULL)
    {
        m_sTrsCode = lpTrsCode;
    }
    
    if(lpMsgFile != NULL)
    {
        m_sMsgFile = lpMsgFile;
    }
    
    if (NULL != lpMsgID)
    {
        m_strRcvMsgID = lpMsgID;
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_strRcvMsgID = %s", m_strRcvMsgID.c_str());
    }

    m_iErrMsgFlag = iErrMsgFlag;
    
}

void CRecvbkHvpsWork::clear()
{

}

INT32 CRecvbkHvpsWork::doWork()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbkHvpsWork::doWork()");

    // 大报文消息没传过来，需要从来帐通讯表取消息
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_vData.size() = %d ", m_vData.size());
    int iRet		= -1;
	int iBizCode	= -1; 
	int iVersion	= -1;

    //取业务码   
    iBizCode = GetBizCode(&m_vData[0], iVersion);
	
    if (-1 == iBizCode)
    {
        return RTN_FAIL;
    }
   Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iBizCode = %d", iBizCode);

    char szchBizCode[MAX_BIZ_CODE_LEN + 1] = {0};  // 业务码
    sprintf(szchBizCode, "%d", iBizCode);

    CRecvbkHvpsBase *pRecvHvps = NULL;

    switch( iBizCode )
    {
        case HV_1ST_100:               
            {
                pRecvHvps = new CRecvBkCmt100;
				break;
            }
        case HV_1ST_101:               
            {
                pRecvHvps = new CRecvBkCmt101;
				break;
            }           
        case HV_1ST_102:               
            {
                pRecvHvps = new CRecvBkCmt102;
				break;
            }     
        case HV_1ST_103:               
            {
                pRecvHvps = new CRecvBkCmt103;
				break;
            }  
        case HV_1ST_105:               
            {
                pRecvHvps = new CRecvBkCmt105;
				break;
            } 
        case HV_1ST_108:               
            {
                pRecvHvps = new CRecvBkCmt108;
				break;
            }
        case HV_1ST_110:
            {
                pRecvHvps = new CRecvBkCmt110;
				break;
            }
        case HV_1ST_121:
            {
                pRecvHvps = new CRecvBkCmt121;
				break;
            }
        case HV_1ST_122:
            {
                pRecvHvps = new CRecvBkCmt122;
				break;
            }
        case HV_1ST_123:
            {
                pRecvHvps = new CRecvBkCmt123;
				break;
            }
        case HV_1ST_124:
            {
                pRecvHvps = new CRecvBkCmt124;
				break;
            }
        case HV_1ST_231:
            {
                pRecvHvps = new CRecvBkCmt231;
				break;
            }
        case SP_1ST_253:               
            {
                pRecvHvps = new CRecvBkCmt253;
				break;
            }
        case HV_2ND_111:
            {
                pRecvHvps = new CRecvBkHvps111;
				break;
            }  
        case HV_2ND_112:
            {
                pRecvHvps = new CRecvBkHvps112;
				break;
            }   
		//add by zwc 20171108
        case HV_2ND_115:
            {
                pRecvHvps = new CRecvBkHvps115;
				break;
            }  
		case HV_2ND_116:
            {
                pRecvHvps = new CRecvBkHvps116;
				break;
            } 
		case HV_2ND_117:
            {
                pRecvHvps = new CRecvBkHvps117;
				break;
            } 
		case HV_2ND_118:
            {
                pRecvHvps = new CRecvBkHvps118;
				break;
            } 
	    //add end
		case HV_2ND_132:
            {
                pRecvHvps = new CRecvBkHvps132;
				break;
            } 
		case HV_2ND_141:
            {
                pRecvHvps = new CRecvBkHvps141;
				break;
            }           
        case HV_2ND_142:
            {
                pRecvHvps = new CRecvBkHvps142;
				break;
            }     
        case HV_2ND_143:
            {
                pRecvHvps = new CRecvBkHvps143;
				break;
            }         
        case HV_2ND_144:
            {
                pRecvHvps = new CRecvBkHvps144;
				break;
            }       
        case HV_2ND_151:
            {
                pRecvHvps = new CRecvBkHvps151;
				break;
            }          
		case HV_2ND_152:
            {
                pRecvHvps = new CRecvBkHvps152;
				break;
            }
        case HV_2ND_153:
            {
                pRecvHvps = new CRecvBkHvps153;
				break;
            }          
		case HV_2ND_154:
            {
                pRecvHvps = new CRecvBkHvps154;
				break;
            }
        case HV_2ND_632:
            {
                pRecvHvps = new CRecvBkHvps632;
				break;
            }
        case HV_2ND_633:
            {
                pRecvHvps = new CRecvBkHvps633;
				break;
            }
        case HV_2ND_635:
            {
                pRecvHvps = new CRecvBkHvps635;
				break;
            }
    
        case HV_1ST_725:
            {
                pRecvHvps = new CRecvBkCmt725;
				break;
            }
        case HV_1ST_841:
            {
                pRecvHvps = new CRecvBkCmt841;
				break;
            }      
        case HV_2ND_710:
            {
                pRecvHvps = new CRecvBkHvps710;
				break;
            }
        case HV_2ND_712:
            {
                pRecvHvps = new CRecvBkHvps712;
				break;
            }
        case HV_2ND_714:
            {
                pRecvHvps = new CRecvBkHvps714;
				break;
            }		
        default:
            return RTN_FAIL;
    }

    pRecvHvps->m_strBizCode  = szchBizCode;
    pRecvHvps->m_strRcvMsgID = m_strRcvMsgID;
    pRecvHvps->m_iErrMsgFlag = m_iErrMsgFlag;
    pRecvHvps->m_iMsgVer	 = iVersion;
    
    ZFPTLOG.SetLogInfo(pRecvHvps->m_strBizCode.c_str(), NULL);


		pRecvHvps->doWork(&m_vData[0]);

    if (NULL != pRecvHvps)
    {
        delete pRecvHvps;
        pRecvHvps = NULL;
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecv::doWork()");

    return RTN_SUCCESS;
}

/******************************************************************************
*  Function:   GetMsg
*  Description:从来帐通讯表取消息
*  Input:	   无
*  Output:	   
*  Return:	   0   : 操作成功,
			   其他: 操作失败
*  Others:	   无
*  Author:	   zys
*  Date:	   2011-02-21
*******************************************************************************/
INT32 CRecvbkHvpsWork::GetMsg(void)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "entering CRecvbkHvpsWork::GetMsg()");

    int    iRet = RTN_FAIL;
    DBProc cDBProc;
    
    // 获取数据库连接
    iRet = g_DBConnPool->GetConnect(cDBProc);
    if(0 != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "GetConnect failed");
    
        return iRet;
    }

    CHvrecvmsg cHvrecvmsg;
    iRet= cHvrecvmsg.setctx(cDBProc);
    if (0 != iRet)
    {
        g_DBConnPool->PutConnect(cDBProc);//释放连接
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "cHvrecvmsg.setctx error[%d]", iRet);
        return iRet;
    }

    cHvrecvmsg.m_msgid  = m_strRcvMsgID;
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_strRcvMsgID = %s", m_strRcvMsgID.c_str());

    // 从来帐通讯表取消息
    iRet = cHvrecvmsg.findByPK();
    if (RTN_SUCCESS == iRet)
    {
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "pRecvmsg->findByPK() 成功");	
    	m_vData.resize(cHvrecvmsg.m_msgtext.length() + 1, 0);	
    	memset(&m_vData[0], 0, cHvrecvmsg.m_msgtext.length() * sizeof(char));
        memcpy(&m_vData[0], cHvrecvmsg.m_msgtext.c_str(), cHvrecvmsg.m_msgtext.length());
    }
    else
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "cHvrecvmsg.findByPKfailed[%d]", iRet);
    }

    //释放连接
    g_DBConnPool->PutConnect(cDBProc);

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "leaving CRecvbkHvpsWork::GetMsg()");

    return iRet;
}


