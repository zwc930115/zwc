/******************************************************************** 
�ļ����� recvcmt100.cpp
�����ˣ� aps-lel
��  �ڣ� 2011-05-18
�޸��ˣ� 
��  �ڣ� 
��  ���� ������˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkcmt100.h"

using namespace ZFPT;

CRecvBkCmt100::CRecvBkCmt100()
{
    m_strMsgTp = "CMT100";
}


CRecvBkCmt100::~CRecvBkCmt100()
{

}

INT32 CRecvBkCmt100::Work(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt100::doWork()");

    // 1.��������
    unPack(pchMsg);

    
    // 2.��m_cHvrcvexchglist�ĳ�Ա��ֵ
    SetData(pchMsg);

    AddMac();

    buildCmtMsg(pchMsg);
    
    // 3.����������ʻ����ϸ��hv_rcvexchglist����������
    InsertData();    
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt100::doWork()");

    return RTN_SUCCESS;
}

INT32 CRecvBkCmt100::unPack(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt100::unPack()");
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "receive msg = [%s]",pchMsg);


    // 1�������Ƿ�Ϊ��
    if (NULL == pchMsg || '\0' == pchMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_strBizCode.c_str(), "����Ϊ��");
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }
    
    int iRet = RTN_FAIL;
    
    // 3����������
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Start ParseCmt");
    iRet = m_cCmt100.ParseCmt(pchMsg);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "End ParseCmt[%d]", iRet);

    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CRecvBkCmt100::Work(): ��������ʧ��");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������!");
    }

    char szTxssno[9] = {0};
    sprintf(szTxssno,"%08d",m_cCmt100.iTxssno);    
    // ���ı�ʶ��,����д�����ļ�����
    m_strMsgID = m_cCmt100.sConsigndate;
    m_strMsgID += szTxssno;

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "start SetLogInfo");
    ZFPTLOG.SetLogInfo("100", m_strMsgID.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "end SetLogInfo");

    // ��ȡ��������
    /*
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Start GetWorkDate");
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS, m_cCmt100.sRecvsapbk);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "End GetWorkDate[%s][%d]", m_sWorkDate, iRet);
  
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");
        PMTS_ThrowException(OPT_GET_DATE_FAIL);
    }
    */
    m_strWorkDate   =   m_sWorkDate;
     
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt100::unPack()");	
    
    return RTN_SUCCESS;
}


INT32 CRecvBkCmt100::SetData(LPCSTR pchMsg)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt100::SetData()");
    
	m_cHvrcvexchglist.m_workdate       = m_strWorkDate;//��������
    m_cHvrcvexchglist.m_consigndate    = m_cCmt100.sConsigndate;//ί������
    m_cHvrcvexchglist.m_msgtp          = m_strMsgTp;//��������
    m_cHvrcvexchglist.m_msgid          = m_strMsgID;//���ı�ʶ��

	m_cHvrcvexchglist.m_mesgid         = m_cCmt100.GetHeadMesgID();
	m_cHvrcvexchglist.m_mesgrefid      = m_cCmt100.GetHeadMesgReqNo();
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgID= [%s]",m_strMsgID.c_str());
    //m_cHvrcvexchglist.m_endtoendid     = ;//�˵��˱�ʶ��
    m_cHvrcvexchglist.m_instgdrctpty   = m_cCmt100.sSendsapbk;//����ֱ�Ӳ������
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSendsapbk= [%s]",m_cCmt100.sSendsapbk);

    m_cHvrcvexchglist.m_instgindrctpty = m_cCmt100.sSendbank;//����������
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSendbank= [%s]",m_cCmt100.sSendbank);

    m_cHvrcvexchglist.m_instddrctpty   = m_cCmt100.sRecvsapbk;//����ֱ�Ӳ������
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sRecvsapbk= [%s]",m_cCmt100.sRecvsapbk);

    m_cHvrcvexchglist.m_instdindrctpty = m_cCmt100.sRecvbank;//���ղ������
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sRecvbank= [%s]",m_cCmt100.sRecvbank);

    m_cHvrcvexchglist.m_sttlmprty      = m_cCmt100.GetPayPRI();//ҵ�����ȼ�
    m_cHvrcvexchglist.m_dbtmmbid      = m_cCmt100.sSendsapbk;//�����������к�
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSendsapbk= [%s]",m_cCmt100.sSendsapbk);

    //m_cHvrcvexchglist.m_dbtnm          = m_cCmt100.sPayername;//����������
    SetGbkToUtf8(m_cCmt100.sPayername, m_cHvrcvexchglist.m_dbtnm);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayername= [%s]",m_cCmt100.sPayername);

    m_cHvrcvexchglist.m_dbtracctid     = m_cCmt100.sPayeracc;//�������ʺ�
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayeracc= [%s]",m_cCmt100.sPayeracc);

    m_cHvrcvexchglist.m_dbtid          = m_cCmt100.sSendbank;//�������к�
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSendbank= [%s]",m_cCmt100.sSendbank);

    m_cHvrcvexchglist.m_dbtrissr       = m_cCmt100.sPayopenbk;//�����˿������к�
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayopenbk= [%s]",m_cCmt100.sPayopenbk);

    m_cHvrcvexchglist.m_cdtmmbid      = m_cCmt100.sRecvsapbk;//�տ��������к�
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sRecvsapbk= [%s]",m_cCmt100.sRecvsapbk);

    //m_cHvrcvexchglist.m_cdtrnm         = m_cCmt100.sPayeename;//�տ��˻���
    SetGbkToUtf8(m_cCmt100.sPayeename, m_cHvrcvexchglist.m_cdtrnm);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayeename= [%s]",m_cCmt100.sPayeename);

    m_cHvrcvexchglist.m_cdtracctid     = m_cCmt100.sPayeeacc;//�տ����ʺ�
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayeeacc= [%s]",m_cCmt100.sPayeeacc);

    m_cHvrcvexchglist.m_cdtid          = m_cCmt100.sRecvbank;//�տ����к�
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sRecvbank= [%s]",m_cCmt100.sRecvbank);

    m_cHvrcvexchglist.m_cdtrissr       = m_cCmt100.sPayeeopenbk;//�տ��˿������к�
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPayeeopenbk= [%s]",m_cCmt100.sPayeeopenbk);

    m_cHvrcvexchglist.m_procstate      = PR_HVBP_08;//����״̬
    m_cHvrcvexchglist.m_amount         = m_cCmt100.dAmount;//���׽��
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "dAmount= [%f]",m_cCmt100.dAmount);

    m_cHvrcvexchglist.m_currency       = m_cCmt100.sCur;//���ҷ���
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sCur= [%s]",m_cCmt100.sCur);

    m_cHvrcvexchglist.m_msgdirect = "0";//����״̬

    //m_cHvrcvexchglist.m_ctgypurpprtry  = ;//ҵ�����ͱ���
    char isodate[10+1] = {0};
    chgToISODate(m_cHvrcvexchglist.m_consigndate.c_str(), isodate);
    //m_cHvrcvexchglist.m_finalstatedate = isodate;//��������
    m_cHvrcvexchglist.m_purpprtry      = m_cCmt100.sTradetype;//ҵ���������
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sTradetype= [%s]",m_cCmt100.sTradetype);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sRecvcenter= [%s]",m_cCmt100.sRecvcenter);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSendcenter= [%s]",m_cCmt100.sSendcenter);
    m_cHvrcvexchglist.m_busistate        = "";//ҵ��״̬

    Trim(m_cCmt100.sRemark);
    SetGbkToUtf8(m_cCmt100.sRemark,    m_cHvrcvexchglist.m_addinfo);
    SetGbkToUtf8(m_cCmt100.sPayeraddr, m_cHvrcvexchglist.m_dbtaddr);
    SetGbkToUtf8(m_cCmt100.sPayeeaddr, m_cHvrcvexchglist.m_cdtaddr);

    //m_cHvrcvexchglist.m_srcflag        = "0";//������־ 0:���� 1:���˲���
        
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt100::SetData()");

    return RTN_SUCCESS;
}

INT32 CRecvBkCmt100::InsertData(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt100::InsertData()");

    int iRet = RTN_FAIL;


	//1����������
    iRet = m_cHvrcvexchglist.setctx(m_dbproc);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_strMsgID.c_str(), "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }

	//2���������ݿ�
	iRet = m_cHvrcvexchglist.insert();
    if (RTN_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg, "������ʻ����ϸ��hv_rcvexchglist��������ʧ��[%s], [%d][%s]", 
            m_strMsgID.c_str(), iRet, m_cHvrcvexchglist.GetSqlErr());
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
    }
    //add by aps-lel ���� start
	iRet = m_cHvrcvexchglist.findByPK();
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cdtrnm= [%s][%d]",m_cHvrcvexchglist.m_cdtrnm.c_str(),iRet);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_dbtaddr= [%s]",m_cHvrcvexchglist.m_dbtaddr.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cdtaddr= [%s]",m_cHvrcvexchglist.m_cdtaddr.c_str());
   //end
   
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt100::InsertData()");

    return RTN_SUCCESS;
}

int CRecvBkCmt100::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkCmt100::FundSettle...");
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û�[%s]", m_szOprUser);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_cCmt100.sRecvbank);

	m_charge.m_amount = m_cCmt100.dAmount;	//ҵ����
	m_charge.m_iDCFlag = iCREDITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, m_szOprUserNetId);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_cCmt100.sRecvbank);	//������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(RTN_SUCCESS != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FundSettle iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkCmt100::FundSettle..."); 
    
    return RTN_SUCCESS;
}

int CRecvBkCmt100::ChkMac()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkCmt100::ChkMac...");
		
	int iRet = -1;
	
	m_cCmt100.SetSeal();//��ȡ��Ѻ��
	

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt100.sRecvsapbk[%s]",m_cCmt100.sRecvsapbk);
	
    iRet = CheckMac(m_dbproc,m_cCmt100.GetMacStr(),m_cCmt100.m_Seal.c_str(),m_cCmt100.sRecvsapbk);
    if(0 != iRet)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ChkMac failed");
    	PMTS_ThrowException(OPT_CHECKSIGN_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]",m_cCmt100.m_szMacStr);
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkCmt100::ChkMac..."); 
    
    return RTN_SUCCESS;
}


int CRecvBkCmt100::buildCmtMsg(LPCSTR pchMsg)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvbkCmt100::buildCmtMsg...");

    int iRet = m_cCmt100.CreateCmt("100", m_cHvrcvexchglist.m_instgdrctpty.c_str(), m_cHvrcvexchglist.m_instddrctpty.c_str(), m_cCmt100.m_szmesgID, m_cCmt100.m_szmesgID, m_cCmt100.m_szWorkDate, m_cHvrcvexchglist.m_sttlmprty.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }

    Trace(L_INFO, __FILE__, __LINE__, NULL, "source msg[%s]",pchMsg);

    m_bifmac = true;
    m_macMsg = m_cCmt100.m_strCmtmsg;
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "mac msg[%s]",m_cCmt100.m_strCmtmsg.c_str());
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvbkCmt100::buildCmtMsg...");
    return iRet;
}


int CRecvBkCmt100::AddMac()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbkCmt100::AddMac...");
	int iRet = -1;
	
	m_cCmt100.SetSeal();//获取密押串

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt100.sSendsapbk[%s]",m_cCmt100.sSendsapbk);
	
    //iRet = CodeMac(m_dbproc,m_cCmt100.m_Seal.c_str(),m_cCmt100.sSendsapbk,m_cCmt100.m_szMacStr);
    iRet = CodeMac(m_dbproc,m_cCmt100.m_Seal.c_str(),m_cCmt100.m_szMacStr);
    if(0 != iRet)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "AddMac failed");
    	//PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]",m_cCmt100.m_szMacStr);
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbkCmt100::AddMac..."); 
    
    return RTN_SUCCESS;
}

