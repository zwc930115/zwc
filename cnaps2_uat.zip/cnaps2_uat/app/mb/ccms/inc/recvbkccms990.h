/******************************************************************** 
�ļ����� recvccms990.h
�����ˣ� xlz
��  �ڣ� 2011-03-08
�޸��ˣ� hq
��  �ڣ� 
��  ���� ͨ�ż�ȷ�ϱ���<ccms.990.001.02>���˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef _RECVCCMS990_H_BK
#define _RECVCCMS990_H_BK

#include "recvbkccmsbase.h"
#include "ccms990.h"
#include "entitybase.h"
#include "bpbcoutsndcl.h"
#include "bpbdsndcl.h"
#include "bpcolltnchrgscl.h"
#include "bpinvcprtrspn.h"
#include "bpcstbdpcxlcl.h"
#include "bpchckcdtforld.h"
#include "cmcnotsgninfbiz.h"
#include "cmtransinfoqry.h"
#include "cmpmtrtrcl.h"
#include "hvsndexchglist.h"
#include "hvpvpsetofac.h"
#include "bpbcoutsndcl.h"
#include "bpbcoutsendlist.h"
#include "cmfreeinfo.h"

class CRecvBkCcms990 : public CRecvbkCcmsBase
{
	
public:
    CRecvBkCcms990();
    ~CRecvBkCcms990();
    
    int unPack(LPCSTR sMsg); 
    int UpdateData(void);
	int Work(LPCSTR szMsg);
	
	void TransProcSts();
    void PubUpSql(LPCSTR sTableNm, LPCSTR sTimeNm, LPCSTR sPrcCdNm="PROCESSCODE", LPCSTR sPrcStsNm="PROCSTATE");
    void PubUpSql_(LPCSTR sTableNm, LPCSTR sTimeNm);//��PROCESSCODE�ֶβ�����
    void PubListSql(CEntityBase* oDbDetail, LPCSTR sTableNm, int sType=0);
	void  PubOriSql(LPCSTR sUpTable, LPCSTR sOriTable, LPCSTR sTimeNm, LPCSTR sColNm, LPTSTR sUpSql);
    void BpBcSndSql(int sType);
    void BpBdSndSql(int sType);
    void BpColltSql(int sType);
    void BpIncvpSql();
    void BpcstbdSql();
    void BpchckcSql();
    void CmCnotsSql();
    void CmTrInQsSql();
    void CmPmtrtSql();
    INT32 InsertComsendmb(LPCSTR pchMsg);
    
private:
    ccms990          m_ccms990;
	CEntityBase      m_centitybase;
    CBpbcoutsndcl    m_bpbcsndcl;
    CBpbdsndcl       m_bpbdsndcl;
    CBpcolltnchrgscl m_bpcoll;
    CBpinvcprtrspn   m_bpinvc;
    CBpcstbdpcxlcl   m_bpcstb;
    CBpchckcdtforld  m_bpchck;
    CCmcnotsgninfbiz m_cmcnot;
    CCmtransinfoqry  m_cmtrinq;
    CCmpmtrtrcl      m_cmpmtr;
    
    
    char	m_sMsgTp[6 + 1];	     //ԭ��������
    STRING	m_strProcSts;            //ҵ����״̬ 2λ
    char    m_sSqlStr[2048 + 1];     //����ҵ����SQL
	char    m_sListSql[2048 + 1];    //ҵ���Ӧ����ϸ��SQL
	char    m_sOriSql[2048 + 1];     //ԭҵ��SQL
    char    m_sOriListSql[2048 + 1]; //ԭҵ����ϸ��SQL
};

#endif


