/********************************************************************
�ļ�����recvcmt314.cpp
�����ˣ�xiaocuiming
��  �ڣ�2011.07.04
��  �����������ҵ���˻�Ӧ����
��  ����
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkcmt314.h"

using namespace ZFPT;


CRecvBkCmt314::CRecvBkCmt314()
{
    m_iMsgVer = 1;
    m_strMsgTp = "CMT314";   
    memset(m_sOldMsgid, 0x00, sizeof(m_sOldMsgid));
}

CRecvBkCmt314::~ CRecvBkCmt314()
{

}

INT32 CRecvBkCmt314::Work(LPCSTR sMsg)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvBkCmt314::Work...");

    //��������
    unPack(sMsg);

    QryOldTrade();
    
    //��ֵ
    SetData(sMsg);

    //�������ݿ�
    InsertData();

    Trace(L_INFO, __FILE__, __LINE__, NULL, "m_cCmt314.sRespflag[%s]", m_cCmt314.sRespflag);
	if('1' == m_cCmt314.sRespflag[0])
	{
	    m_ProState = PR_HVBP_32;
	}
	else
	{
	    m_ProState = PR_HVBP_33;
	}
	
    UpdateData();
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvBkCmt314::Work...");
    return RTN_SUCCESS;

}

INT32 CRecvBkCmt314::unPack(LPCSTR sMsg)
{
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt314::unPack...");	

	int iRet = RTN_FAIL;

	//1�������Ƿ�Ϊ��
	if (NULL == sMsg || '\0' == sMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��! ");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��! ");
	}
	
	//2����������
	iRet = m_cCmt314.ParseCmt(sMsg);
	if (RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= %d", iRet);	
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������! ");	
	}
    char sMsgidTemp[35 + 1] = {0};
    bool bRet = GetMsgIdValue(m_dbproc, sMsgidTemp, 1, SYS_HVPS);
    if(TRUE != bRet)
    {
        Trace(L_INFO, __FILE__, __LINE__, NULL, "��ȡ���ı�ʶ��ʧ��");
        PMTS_ThrowException(OPT_GET_MSGID_FAIL);
    }
    
    //����д�����ļ�����
    m_strMsgID = sMsgidTemp;
	//������־�ļ����ı�ʶ��
	ZFPTLOG.SetLogInfo("1314", m_strMsgID.c_str());
	
	//4����ȡ��������
	iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS,g_SapBank);	
    if(iRet != RTN_SUCCESS)
    {
         Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
         PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;      
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkCmt314::unPack...");	

	return RTN_SUCCESS;

    
}


void CRecvBkCmt314::QryOldTrade()//��ѯԭ����ҵ��
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt314::QryOldTrade()");

    sprintf(m_sOldMsgid, "%s%08d", m_cCmt314.sOldconsigndate, m_cCmt314.iOldmssno);
    
    m_Oricmpmtrtrcl.m_msgid = m_sOldMsgid;
    m_Oricmpmtrtrcl.m_instgindrctpty =  m_cCmt314.sRecvbank;
    m_Oricmpmtrtrcl.m_sysid = "HVPS";
    m_Oricmpmtrtrcl.m_rsflag="2";

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt314.sOldconsigndate[%s]", m_cCmt314.sOldconsigndate);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt314.iOldmssno[%d]", m_cCmt314.iOldmssno);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sOldMsgid[%s]", m_sOldMsgid);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_Oricmpmtrtrcl.m_instgindrctpty[%s]", m_Oricmpmtrtrcl.m_instgindrctpty.c_str());
    
    SETCTX(m_Oricmpmtrtrcl);
    int iRet = m_Oricmpmtrtrcl.findByPK();   
    
    if (iRet == SQLNOTFOUND)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL,"����ʱδ�ҵ�����");
    }    
    else if (OPERACT_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg,"findByPK error ,error code = [%d],error cause = [%s]", iRet,m_Oricmpmtrtrcl.GetSqlErr());		
        Trace(L_INFO,  __FILE__,  __LINE__,NULL, m_szErrMsg);		
        PMTS_ThrowException(__FILE__, __LINE__, DB_FIND_BY_PK_FAIL, m_szErrMsg);
    } 
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leave CRecvBkCmt314::QryOldTrade()");

}

INT32 CRecvBkCmt314::SetData(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt314::SetData...");	

	m_cmpmtrtrcl.m_wrkdate = m_sWorkDate;//�������� 			 
	m_cmpmtrtrcl.m_consigndate = m_sWorkDate;//ί������ 		 
	m_cmpmtrtrcl.m_sysid = "HVPS";	// ϵͳ��ʶ��
	m_cmpmtrtrcl.m_msgtp =  m_strMsgTp;				 
	m_cmpmtrtrcl.m_msgid = m_strMsgID;				 
	m_cmpmtrtrcl.m_instgdrctpty = m_cCmt314.sSendsapbk;//����ֱ�Ӳ�������� 	 
	m_cmpmtrtrcl.m_instgindrctpty = m_cCmt314.sSendbank; //�����������к� 		 
	m_cmpmtrtrcl.m_instddrctpty = m_cCmt314.sRecvsapbk;	//����ֱ�Ӳ��������  	 
	m_cmpmtrtrcl.m_instdindrctpty = m_cCmt314.sRecvbank;//���ղ�������к� 
	m_cmpmtrtrcl.m_rsflag = "1";//������־ 1:��2:��				 
	m_cmpmtrtrcl.m_rspflag = "1"; //��Ӧ״̬0δ��Ӧ1�ѻ�Ӧ			 
	//m_cmpmtrtrcl.m_mbmsg;	//MB���� ��Ϊ��			 
	//m_cmpmtrtrcl.m_npcmsg;	//NPC���� ��Ϊ��			 
	m_cmpmtrtrcl.m_mesgid = m_cCmt314.GetHeadMesgID(); //ͨ�ż���ʶ��				 
	m_cmpmtrtrcl.m_mesgrefid = m_cCmt314.GetHeadMesgReqNo(); //ͨ�ż��ο���  			 
	m_cmpmtrtrcl.m_procstate = PR_HVBP_08;//����״̬ OPR_RECVND01 ��������			 
	//m_cmpmtrtrcl.m_statetime;	//��Ĭ��ֵ		 
	//m_cmpmtrtrcl.m_busistate;//ҵ��״̬��			 
	//m_cmpmtrtrcl.m_processcode;		 
	//m_cmpmtrtrcl.m_rjctinf; //ҵ��ܾ���Ϣ 
	m_cmpmtrtrcl.m_orgninstgdrctpty = m_cCmt314.sRecvbank;	//ԭ���������
	m_cmpmtrtrcl.m_orgnlmsgid = m_sOldMsgid;//ԭ���ı�ʶ��
	m_cmpmtrtrcl.m_orgnlmsgnmid = "CMT313";//ԭ�������ʹ���  
	m_cmpmtrtrcl.m_returntype = "RP00";//�˻�����  RP00�������˻�  RP01�������˻�  
	//m_cmpmtrtrcl.m_printno;	//��ӡ����	
	m_cmpmtrtrcl.m_retunstat = m_cCmt314.sReturnstat;//�˻�Ӧ��״̬ 
	m_cmpmtrtrcl.m_rtinfo =  m_cCmt314.sRemark;//����	
	m_cmpmtrtrcl.m_otrantype = m_cCmt314.sOldtradetype;
	m_cmpmtrtrcl.m_orgcurrency = m_cCmt314.sOldcur;
	m_cmpmtrtrcl.m_orgamt = m_cCmt314.dOldamount;

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkCmt314::SetData...");	

	return RTN_SUCCESS;
}


INT32 CRecvBkCmt314::InsertData(void)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvBkCmt314::InsertData...");

    //1����������
	SETCTX(m_cmpmtrtrcl);

	//2���������ݿ�
	int iRet = m_cmpmtrtrcl.insert();
	
	if (0 != iRet)
	{
		sprintf(m_szErrMsg,"insert error,error code = [%d] error cause =[%s]",iRet,m_cmpmtrtrcl.GetSqlErr());
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkCmt314::InsertData...");

	return RTN_SUCCESS;
}

void CRecvBkCmt314::UpdateData(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt314::UpdateData()");

    SETCTX(m_Oricmpmtrtrcl);
    int iRet = RTN_FAIL;    	
    
    string strWhere = "";

    //����ԭ�����˻�ҵ����ܱ�
    strWhere = "MSGID = '";
    strWhere += m_Oricmpmtrtrcl.m_msgid+ "' and ";
    strWhere += "INSTGINDRCTPTY = '";
    strWhere += m_Oricmpmtrtrcl.m_instgindrctpty + "' and ";
    strWhere += "SYSID = '";
    strWhere += m_Oricmpmtrtrcl.m_sysid ;
    strWhere += "' and RSFLAG <> '1'";
    
    UpdateOriTrade("CM_PMTRTRCL",m_ProState.c_str(),"PROCSTATE",strWhere.c_str(), 1);

    //����ԭ�����˻�ҵ����ϸ��    
    strWhere = "MSGID = '";
    strWhere += m_Oricmpmtrtrcl.m_msgid + "' and ";
    strWhere += "INSTGDRCTPTY = '";
    strWhere += m_Oricmpmtrtrcl.m_instgdrctpty + "'";
    
    //UpdateOriTrade("CM_PMTRTRLIST",PR_HVBP_20,"PROCSTATE",strWhere.c_str(), 1);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt314::UpdateData()");
}

void CRecvBkCmt314::UpdateOrgData(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt314::UpdateOrgData()");

    int iRet = RTN_FAIL;    	

    memcpy(m_szOldMsgNo, m_Oricmpmtrtrcl.m_orgnlmsgnmid.c_str() + 3, 3);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szOldMsgNo = [%s]",m_szOldMsgNo);
    
    string strWhere = "";
    
    //���´��ҵ��
    if( 0 == strcmp("100" ,m_szOldMsgNo) || 0 == strcmp("101" ,m_szOldMsgNo) ||
        0 == strcmp("102" ,m_szOldMsgNo) || 0 == strcmp("103" ,m_szOldMsgNo) ||
        0 == strcmp("105" ,m_szOldMsgNo) || 0 == strcmp("108" ,m_szOldMsgNo) ||
        0 == strcmp("121" ,m_szOldMsgNo) || 0 == strcmp("122" ,m_szOldMsgNo) ||
        0 == strcmp("123" ,m_szOldMsgNo) || 0 == strcmp("124" ,m_szOldMsgNo)
        )
    {
        
        //���´�����˻����ϸ��        
        strWhere = "MSGID = '";
        strWhere += m_Oricmpmtrtrcl.m_orgnlmsgid + "' and ";
        strWhere += "INSTGINDRCTPTY = '";
        strWhere += m_Oricmpmtrtrcl.m_orgninstgdrctpty + "'";

        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strWhere = [%s]",strWhere.c_str());
        
        UpdateOriTrade("HV_SNDEXCHGLIST",m_ProState.c_str(),"PROCSTATE",strWhere.c_str());
        
    }
    else if( 0 == strcmp("223" ,m_szOldMsgNo) ||
             0 == strcmp("231" ,m_szOldMsgNo))
    {
        //���´�����˼�ʱת�˱�       
        strWhere = "MSGID = '";
        strWhere += m_Oricmpmtrtrcl.m_orgnlmsgid + "' and ";
        strWhere += "INSTGINDRCTPTY = '";
        strWhere += m_Oricmpmtrtrcl.m_orgninstgdrctpty + "'";

        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strWhere = [%s]",strWhere.c_str());
        
        UpdateOriTrade("HV_TROFACSNDLIST",m_ProState.c_str(),"PROCSTATE",strWhere.c_str());
    }
    //����С�����ҵ��
    else if( 0 == strcmp("001" ,m_szOldMsgNo) || 0 == strcmp("003" ,m_szOldMsgNo)||
             0 == strcmp("005" ,m_szOldMsgNo) || 0 == strcmp("007" ,m_szOldMsgNo)||
             0 == strcmp("009" ,m_szOldMsgNo))
    {
        
        //����С����ǻ��ܱ�    
        strWhere = "MSGID = '";
        strWhere += m_Oricmpmtrtrcl.m_orgnlmsgid + "' and ";
        strWhere += "INSTGINDRCTPTY = '";
        strWhere += m_Oricmpmtrtrcl.m_orgninstgdrctpty + "'";

        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strWhere = [%s]",strWhere.c_str());
        
        UpdateOriTrade("BP_BCOUTSNDCL",m_ProState.c_str(),"PROCSTATE",strWhere.c_str());

        //����С�������ϸ��
        UpdateOriTrade("BP_BCOUTSENDLIST",m_ProState.c_str(),"PROCSTATE",strWhere.c_str());

    }		
    //����С����ҵ��
    else if( 0 == strcmp("002" ,m_szOldMsgNo) || 0 == strcmp("004" ,m_szOldMsgNo)||
             0 == strcmp("006" ,m_szOldMsgNo) || 0 == strcmp("008" ,m_szOldMsgNo)||
             0 == strcmp("010" ,m_szOldMsgNo) || 0 == strcmp("011" ,m_szOldMsgNo))
    {
        
        //����С���ǻ��ܱ�    
        strWhere = "MSGID = '";
        strWhere += m_Oricmpmtrtrcl.m_orgnlmsgid + "' and ";
        strWhere += "INSTGINDRCTPTY = '";
        strWhere += m_Oricmpmtrtrcl.m_orgninstgdrctpty + "'";

        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strWhere = [%s]",strWhere.c_str());
        
        UpdateOriTrade("BP_BDSNDCL",m_ProState.c_str(),"PROCSTATE",strWhere.c_str());
        
        UpdateOriTrade("BP_BDSENDLIST",m_ProState.c_str(),"PROCSTATE",strWhere.c_str());     
    }		

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt314::UpdateOrgData()");


}
	
void CRecvBkCmt314::UpdateOriTrade(LPCSTR pTableNm , LPCSTR  pProcState ,LPCSTR pField,LPCSTR pWhere , int iFlag)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt314::UpdateOriTrade()");

    int iRet = RTN_FAIL;
    string strSql = "";
    
    strSql = "update ";
    strSql += pTableNm ;
    strSql += " set ";
    if(0 == iFlag)
    {
        
        strSql += pField;
        strSql += " = '";
        strSql += pProcState;
        strSql += "', STATETIME = sysdate ";
    }
    else
    {
        strSql += " RSPFLAG = '1', retunstat = '";
        strSql += m_cCmt314.sReturnstat;
        strSql += "'";
    }

    strSql += " where ";
    strSql += pWhere;
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSql = [%s]",strSql.c_str());
    
    SETCTX(m_Oricmpmtrtrcl);    
    iRet = m_Oricmpmtrtrcl.execsql(strSql);
    if (iRet == SQLNOTFOUND)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL,"����ʱδ�ҵ�����[%s]", strSql.c_str());
    }
    else if (iRet != SQL_SUCCESS)
    {
        sprintf(m_szErrMsg,  "����ԭҵ��ʧ��[%d][%s]", 
            iRet,  m_Oricmpmtrtrcl.GetSqlErr());          
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
    }
   
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt314::UpdateOriTrade()");

}

