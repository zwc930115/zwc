/********************************************************************
文件名：recvbkccmswork.cpp
创建人：zhj
日  期：2011-03-03
修改人：
日  期：
描  述：ccms来帐线程工作类
版  本：
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif


#include "pubfunc.h"
#include "logger.h"
//#include "recvbkccmswork.h"


#include "cmrecvmsg.h"
#include "recvbkccmsbase.h"
#include "recvbkccms303.h"
//#include "recvbkccms307.h"
#include "recvbkccms314.h"
#include "recvbkccms315.h"
#include "recvbkccms316.h"
#include "recvbkccms308.h"
#include "recvbkccms310.h"
#include "recvbkccms311.h"
#include "recvbkccms312.h"
#include "recvbkccms313.h"
#include "recvbkccms317.h"
#include "recvbkccms318.h"
#include "recvbkccms319.h"
#include "recvbkccms900.h"
#include "recvbkccms903.h"
#include "recvbkccms990.h"
#include "recvbkccms991.h"
#include "recvbkccms919.h"
#include "recvbkcmt301.h"
#include "recvbkcmt302.h"
#include "recvbkcmt303.h"
#include "recvbkcmt312.h"
#include "recvbkcmt322.h"
#include "recvbkcmt920.h"
#include "recvbkcmt313.h"
#include "recvbkcmt314.h"
#include "recvbkcmt319.h"
#include "recvbkcmt320.h"
#include "recvbkcmt681.h"
#include "recvbkccmswork.h"
#include "recvbkcmt327.h"
#include "recvbkcmt328.h"

#include "recvbkccms307.h"

using namespace ZFPT;

extern CConnectPool *g_DBConnPool;
extern int		g_IsConnPlatm;

CRecvbkCcmsWork::CRecvbkCcmsWork()
{    

    m_sMsgFile = "";
    m_strMsgID = "";		
}

CRecvbkCcmsWork::~CRecvbkCcmsWork()
{	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "in ~CRecvbkCcmsWork()");   
}

void CRecvbkCcmsWork::setData(LPTSTR lpMsgID, int iErrMsgFlag, UINT32 len, LPCSTR data, LPCSTR lpTrsCode, LPCSTR lpMsgFile)
{
    
    if(NULL != data && 0 != len)
    {
        m_vData.resize(len + 1, 0);
    
        memset(&m_vData[0], 0, len * sizeof(char));
        memcpy(&m_vData[0], data, len);
    }
    
    
    if(lpMsgFile != NULL)
    {
        m_sMsgFile = lpMsgFile;
    }
    
    if (NULL != lpMsgID)
    {
        m_strMsgID = lpMsgID;
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgID = %s", m_strMsgID.c_str());	
    }

    m_iErrMsgFlag = iErrMsgFlag;
}

void CRecvbkCcmsWork::clear()
{
	
}

INT32 CRecvbkCcmsWork::doWork()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcmsWork::doWork()");	

    // 大报文消息没传过来，需要从来帐通讯表取消息

	int iRet = -1;
	int iBizCode	= -1; 
	int iVersion	= -1;
	
// 	if (0 == m_vData.size()) //当报文长度大于2000时,work从表里取;小于2000时,通过setdata设置
//     {
//         Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "0 == m_vData.size()");	
// 		return RTN_FAIL;   
//     }   
//     
//     Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "是否连接统一支付平台 0:未连接;1:已连接 g_IsConnPlatm = [%d]" ,g_IsConnPlatm);	
//     char sCommHead[42+1] = {0};
// 
//     Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "OK");	
//     if( 1 == g_IsConnPlatm)
//     {
// 	    //取通讯报文头  add by xlz 0712	    
// 	    strncpy(sCommHead , &m_vData[0] ,42);
// 	    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "通讯报文头 sCommHead = [%s]" ,sCommHead);	
// 	    
// 	    //取业务码   
// 	    iBizCode = GetBizCode(&m_vData[0] + 42, iVersion);
// 	}
// 	else
// 	{
		//取业务码   
	    iBizCode = GetBizCode(&m_vData[0], iVersion);
//	}
	if (-1 == iBizCode)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iBizCode 未取到");
        return RTN_FAIL;
    }
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iBizCode = %d", iBizCode);
    
    char szchBizCode[4 + 1] = {0};  // 业务码
    sprintf(szchBizCode, "%d", iBizCode);

	CRecvbkCcmsBase *PRecvCcms = NULL;
		//307 919 991 316报文未处理 占时直接return 对于宏定义占时用HV开头
    switch( iBizCode )
    {
        case HV_2ND_303:
        {
            PRecvCcms = new CRecvBkCcms303;
            break;
        }
        case HV_2ND_307:
        {
          PRecvCcms = new CRecvBkCcms307;
          break;
        }        
/*        
        case HV_2ND_307:
        {
          PRecvCcms = new CRecvbkCcms307;
          break;
        }
*/           
       
        case HV_2ND_314:
        {
            PRecvCcms = new CRecvBkCcms314;
            break;
        }
        case HV_2ND_315:
        {
            PRecvCcms = new CRecvBkCcms315;
            break;
        }     
        case HV_2ND_316:
        {
            PRecvCcms = new CRecvBkCcms316;
            break;
        } 		
        case CM_2ND_308:
        {
            PRecvCcms = new CRecvBkCcms308;
            break;
        }
        case CM_2ND_310:
        {
            PRecvCcms = new CRecvBkCcms310;
            break;
        }
        case CM_2ND_311:
        {
            PRecvCcms = new CRecvBkCcms311;
            break;
        }
        case CM_2ND_312:
        {
            PRecvCcms = new CRecvBkCcms312;
            break;
        }
        case CM_2ND_313:
        {
            PRecvCcms = new CRecvBkCcms313;
            break;
        }      
        case CM_2ND_317:
        {
            PRecvCcms = new CRecvBkCcms317;
            break;
        }
        case CM_2ND_318:
        {
            PRecvCcms = new CRecvBkCcms318;
            break;
        }	        
        case CM_2ND_319:
        {
            PRecvCcms = new CRecvBkCcms319;
            break;
        }			
        case CM_1ST_320:
        {
            PRecvCcms = new CRecvBkCmt320;
            break;
        }              
        case CM_2ND_900:
        {
            PRecvCcms = new CRecvBkCcms900;
            break;
        }
        case CM_2ND_903:
        {
            PRecvCcms = new CRecvBkCcms903;
            break;
        }

        case CM_2ND_990:
        {
            PRecvCcms = new CRecvBkCcms990;
            break;
        }
        case CM_1ST_303:
        {
            PRecvCcms = new CRecvBkCmt303;
            break;
        }
        case CM_1ST_301:
        {
            PRecvCcms = new CRecvBkCmt301;
            break;
        }
        case CM_1ST_302:
        {
            PRecvCcms = new CRecvBkCmt302;
            break;
        }
        case CM_1ST_312:
        {
            PRecvCcms = new CRecvBkCmt312;
            break;
        }
        case CM_1ST_313:
        {   
            PRecvCcms = new CRecvBkCmt313;
            break;    
        }
        case CM_1ST_314:
        {   
            PRecvCcms = new CRecvBkCmt314;
            break;    
        }
        case CM_1ST_319:
        {   
            PRecvCcms = new CRecvBkCmt319;
            break;    
        }        
        case CM_1ST_322:
        {
            PRecvCcms = new CRecvBkCmt322;
            break;
        }     
        case CM_1ST_327:
        {
            PRecvCcms = new CRecvBkCmt327;
            break;
        }   
        case CM_1ST_328:
        {
            PRecvCcms = new CRecvBkCmt328;
            break;
        }  		
        case CM_1ST_681:
        {
            PRecvCcms = new CRecvBkCmt681;
            break;
        }
		case CM_1ST_920:
        {
            PRecvCcms = new CRecvBkCmt920;
            break;
        }        
		case CM_2ND_991:
        {
            PRecvCcms = new CRecvBkccms991;
            break;
        }  		
		case 919:
        {
            PRecvCcms = new CRecvBkccms919;
            break;
        }  		
        default:
            return RTN_FAIL;
    }

	PRecvCcms->m_strBizCode  = szchBizCode;
	PRecvCcms->m_strRcvMsgID = m_strMsgID;
    PRecvCcms->m_iErrMsgFlag = m_iErrMsgFlag;
    PRecvCcms->m_iMsgVer	 = iVersion;
    
	ZFPTLOG.SetLogInfo(PRecvCcms->m_strBizCode.c_str(), NULL);
	
// 	if( 1 == g_IsConnPlatm)
// 	{
// 		strncpy(PRecvCcms->m_sCommHead , sCommHead , 42 );
// 		PRecvCcms->doWork(&m_vData[0]+42);
// 	}
// 	else
// 	{
		PRecvCcms->doWork(&m_vData[0]);
//	}	
	
				
	if (NULL != PRecvCcms)
	{
		delete PRecvCcms;
		PRecvCcms = NULL;
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcmsWork::doWork()");

    return RTN_SUCCESS;
}

/******************************************************************************
*  Function:   GetMsg
*  Description:从来帐通讯表取消息
*  Input:	   无
*  Output:	   
*  Return:	   0   : 操作成功,
			   其他: 操作失败
*  Others:	   无
*  Author:	   zys
*  Date:	   2011-02-21
*******************************************************************************/
INT32 CRecvbkCcmsWork::GetMsg(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcmsWork::GetMsg");	

	int    iRet = RTN_FAIL;
	DBProc cDBProc;

	// 获取数据库连接
	iRet = g_DBConnPool->GetConnect(cDBProc);
	if(0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "GetConnect failed");
		return iRet;	
	}

	CCmrecvmsg cCmrecvmsg;
	iRet= cCmrecvmsg.setctx(cDBProc);
	if (0 != iRet)
	{
		g_DBConnPool->PutConnect(cDBProc);//释放连接
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "cCmrecvmsg.setctx error[%d]", iRet);	
		return iRet;
	}

	cCmrecvmsg.m_msgid  = m_strMsgID;
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_strMsgID = %s", m_strMsgID.c_str());	
	
	// 从来帐通讯表取消息
	iRet = cCmrecvmsg.findByPK();
	if (RTN_SUCCESS == iRet)
	{
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "cCmrecvmsg.findByPK success");	
		m_vData.resize(cCmrecvmsg.m_msgtext.length() + 1, 0);	
		memset(&m_vData[0], 0, cCmrecvmsg.m_msgtext.length() * sizeof(char));
		memcpy(&m_vData[0], cCmrecvmsg.m_msgtext.c_str(), cCmrecvmsg.m_msgtext.length());
	}
	else
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "cCmrecvmsg.findByPKfailed[%d]", iRet);
	}

	//释放连接
	g_DBConnPool->PutConnect(cDBProc);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcmsWork::GetMsg");

	return iRet;
}


