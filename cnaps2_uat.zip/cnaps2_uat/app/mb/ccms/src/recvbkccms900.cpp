/******************************************************************** 
�ļ����� recvccms900.cpp
�����ˣ� xlz
��  �ڣ� 2011-03-08
�޸��ˣ� hq
��  �ڣ� 
��  ���� ͨ�ô���ȷ�ϱ���<ccms.900.001.02>���˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkccms900.h"
#include "bpbcoutsendlist.h"
#include "cmfreeinfo.h"
#include "cmcnotsgninfbiz.h"
#include "cmtransinfoqry.h"
#include "syscbbabankcode.h"
#include "hvpvpsetofac.h"
#include "bpbizpubntce.h" 
#include "bpcolltnchrgscl.h"
#include "cmpmtrtrcl.h"
#include "cmpmtrtrlist.h"
#include "bpcstbdpcxlcl.h"
#include "bpcstbdpcxllist.h"
#include "bpbdsendlist.h"
using namespace ZFPT;

CRecvBkCcms900::CRecvBkCcms900()
{
	memset(m_sMsgTp,      0x00, sizeof(m_sMsgTp));
	memset(m_sMsgChl,      0x00, sizeof(m_sMsgChl));
	memset(m_sProcSts,    0x00, sizeof(m_sProcSts));
	memset(m_sSqlStr,     0x00, sizeof(m_sSqlStr));
	memset(m_sListSql,    0x00, sizeof(m_sListSql));
	memset(m_sOriSql,     0x00, sizeof(m_sOriSql));
    memset(m_sOriListSql, 0x00, sizeof(m_sOriListSql));
    
    memset(m_sOriRspSql,  0x00, sizeof(m_sOriRspSql));   //���ڸ��»�Ӧ��ʶ
    m_strMsgTp = "ccms.900.001.02";
}


CRecvBkCcms900::~CRecvBkCcms900()
{

}

int CRecvBkCcms900::Work(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms900::doWork()");			
	
	// ��������
	unPack(pchMsg);
	
	// ��ǩ
	CheckSign900();
	
	// ��NPC����״̬תΪ��ƽ̨�Ĵ���״̬
	TransProcStates(m_ccms900.PrcSts.c_str(), m_sProcSts); 
	
	// ��������
	UpdateData();
	
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms900::doWork()");
	return RTN_SUCCESS;
}

void CRecvBkCcms900::unPack(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms900::unPack()");
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]", pchMsg);

	int  iRet = RTN_FAIL;

	// �����Ƿ�Ϊ��
	if (NULL == pchMsg || '\0' == pchMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
	}

	// ��������
	iRet = m_ccms900.ParseXml(pchMsg);
	if (RTN_SUCCESS != iRet)
	{
		sprintf(m_szErrMsg, "��������ʧ��[%d]", iRet);
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, m_szErrMsg);
	}

    ZFPTLOG.SetLogInfo("900", m_ccms900.MsgId.c_str());
    
	m_strMsgID = m_ccms900.MsgId;

	if ( 6 == m_ccms900.OrgnlMT.length() )
	{
	    memcpy(m_sMsgTp, m_ccms900.OrgnlMT.c_str(), 6);
	}
	else
	{
        memcpy(m_sMsgTp, m_ccms900.OrgnlMT.c_str() + 5, 3);
        memcpy(m_sMsgChl, m_ccms900.OrgnlMT.c_str(), 4);
	}
	
	// ��ȡ��������
	iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS,
			m_ccms900.InstdDrctPty.c_str());
    if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
		PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
	}
	
	m_strWorkDate = m_sWorkDate;  

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms900::unPack()");
}


void CRecvBkCcms900::UpdateData(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms900::UpdateData()");

	int  iRet = -1;

	// ���ݱ������������SQL
	if( 0 == strcmp("121",    m_sMsgTp) || 0 == strcmp("122",    m_sMsgTp)  
	 || 0 == strcmp("123",    m_sMsgTp) || 0 == strcmp("125",    m_sMsgTp)
	 || 0 == strcmp("128",    m_sMsgTp) || 0 == strcmp("130",    m_sMsgTp)
	 //|| 0 == strcmp("132",    m_sMsgTp) || 0 == strcmp("134",    m_sMsgTp)
	 || (0 == strcmp("132",    m_sMsgTp) && 0 == strcmp("beps",    m_sMsgChl))
	 || 0 == strcmp("134",    m_sMsgTp)
	 || 0 == strcmp("PKG001", m_sMsgTp) || 0 == strcmp("PKG005", m_sMsgTp)
     || 0 == strcmp("PKG007", m_sMsgTp) || 0 == strcmp("PKG008", m_sMsgTp)
     || 0 == strcmp("PKG009", m_sMsgTp) || 0 == strcmp("PKG010", m_sMsgTp)
     || 0 == strcmp("PKG011", m_sMsgTp) )
	{
		PubUpSql("BP_BCOUTSNDCL", "STATETIME");      /*�������ʻ��ܱ�*/
		PubListSql("BP_BCOUTSENDLIST", "STATETIME"); /*����������ϸ��*/
		if(m_ccms900.PrcSts == PROCESS_PR03)
		{
			UpdateOriStateSap();
		}

		if( (0 == strcmp("128",    m_sMsgTp) || 0 == strcmp("130",    m_sMsgTp)
	      || 0 == strcmp("132",    m_sMsgTp) || 0 == strcmp("134",    m_sMsgTp)
	      || 0 == strcmp("PKG008", m_sMsgTp) || 0 == strcmp("PKG009", m_sMsgTp)
	      || 0 == strcmp("PKG010", m_sMsgTp) || 0 == strcmp("PKG011", m_sMsgTp)) 
	      && m_ccms900.PrcSts == PROCESS_PR09 )
    	{
    	    //��ִʧ��,����ԭҵ��
    	    PubOriSql("BP_BCOUTSNDCL",    "BP_BCOUTSENDLIST", "STATETIME", "k.ORGNLMSGID||k.ORIINSTGDRCTPTY", m_sOriSql);
    	    PubOriSql("BP_BCOUTSENDLIST", "BP_BCOUTSENDLIST", "STATETIME", "k.ORGNLMSGID||k.ORIINSTGDRCTPTY", m_sOriListSql);
    	}
	}
	else if(0 == strcmp("124",    m_sMsgTp) || 0 == strcmp("127",    m_sMsgTp) 
	     || 0 == strcmp("131",    m_sMsgTp) || 0 == strcmp("133",    m_sMsgTp)
	     || 0 == strcmp("PKG002", m_sMsgTp) || 0 == strcmp("PKG006", m_sMsgTp)
         || 0 == strcmp("PKG004", m_sMsgTp) || 0 == strcmp("PKG009", m_sMsgTp) )
	{
		if ( (0 == strcmp("02", m_sProcSts)) // PR_HVBP_02 NPC��ת��
		 && ( 0 == strcmp("127",	m_sMsgTp) || 0 == strcmp("131",    m_sMsgTp)
	       || 0 == strcmp("133",	m_sMsgTp) || 0 == strcmp("PKG002", m_sMsgTp)
           || 0 == strcmp("PKG004", m_sMsgTp) || 0 == strcmp("PKG006", m_sMsgTp)) )
		{
			strcpy(m_sProcSts, "06");// PR_HVBP_06 ����ִ
		}
		
		PubUpSql("BP_BDSNDCL", "STATETIME");      /*������ʻ��ܱ�*/
	    PubListSql("BP_BDSENDLIST", "STATETIME"); /*���������ϸ��*/
		if(m_ccms900.PrcSts == PROCESS_PR03)
		{
			Updatebp_bcoutrcvcl_list();
		}
	    if( (0 == strcmp("124",    m_sMsgTp) ||  0 == strcmp("PKG009", m_sMsgTp)) 
	      && m_ccms900.PrcSts == PROCESS_PR09 )
    	{
    	    //��ִʧ��,����ԭҵ��
    	    PubOriSql("BP_BDSNDCL",    "BP_BDSENDLIST", "STATETIME", "k.ORGNLMSGID||k.ORIINSTGDRCTPTY", m_sOriSql);
    	    PubOriSql("BP_BDSENDLIST", "BP_BDSENDLIST", "STATETIME", "k.ORGNLMSGID||k.ORIINSTGDRCTPTY", m_sOriListSql);
    	}
	}
	else if( 0 == strcmp("380" ,m_sMsgTp) || 0 == strcmp("381" ,m_sMsgTp) 
	      || 0 == strcmp("382" ,m_sMsgTp) || 0 == strcmp("383" ,m_sMsgTp)
	      || 0 == strcmp("384" ,m_sMsgTp) || 0 == strcmp("385" ,m_sMsgTp)
	      || 0 == strcmp("386" ,m_sMsgTp) || 0 == strcmp("387" ,m_sMsgTp) )
	{
	    PubUpSql("BP_COLLTNCHRGSCL", "STATETIME");     /*���ո�ҵ����ܱ�*/
       // PubListSql("BP_COLLTNCHRGSLIST", "STATETIME"); /*���ո�ҵ����ϸ��*/
       //���´��ո�ҵ���Ӧ��ʶ       
       PubOriRspSql("BP_COLLTNCHRGSCL", "BP_COLLTNCHRGSCL", "k.ORGNLMSGID||k.ORGNLINSTGPTY", m_sOriRspSql);
      
	    if( (0 == strcmp("381" ,m_sMsgTp) || 0 == strcmp("383" ,m_sMsgTp))
	      && m_ccms900.PrcSts == PROCESS_PR09 )
		{
		    //��ִʧ��,����ԭҵ��
		    PubOriSql("BP_COLLTNCHRGSCL",   "BP_COLLTNCHRGSLIST", "STATETIME", "k.ORGNLMSGID||k.ORGNLINSTGPTY", m_sOriSql);
		    //PubOriSql("BP_COLLTNCHRGSLIST", "BP_COLLTNCHRGSLIST", "STATETIME", "k.ORGNLMSGID||k.ORGNLINSTGPTY", m_sOriListSql);
		}
	}
	else if(0 == strcmp("389",m_sMsgTp) || 0 == strcmp("388",m_sMsgTp))  //����С��389 388
	{
		PubUpSql("BP_BIZPUBNTCE", "PROCTIME"); 
		if(0 == strcmp("388",m_sMsgTp))
		{
			PubOriRspSql("BP_COLLTNCHRGSCL","BP_BIZPUBNTCE", "k.ORGNLMSGID||k.ORGNLINSTGPTY", m_sOriRspSql);
		}
		if(0 == strcmp("389",m_sMsgTp))
		{
			PubOriRspSql("BP_COLLTNCHRGSCL","BP_BIZPUBNTCE", "k.ORGNLMSGID||k.ORGNLINSTGPTY", m_sOriRspSql);
		}
	}
	//add 2012-6-29  zql 
	else if( 0 == strcmp("392" ,m_sMsgTp) || 0 == strcmp("393" ,m_sMsgTp))
	{
		PubUpSql("BP_CSTCTRCTMGCL", "STATETIME");
		if(0 == strcmp("393" ,m_sMsgTp))
		{
			 PubOriSql("BP_CSTCTRCTMGCL", "BP_CSTCTRCTMGCL", "STATETIME", "k.ORGNLMSGID||k.ORGNLINSTGPTY", m_sOriSql);
		}
	}
	else if(0 == strcmp("394" ,m_sMsgTp) || 0 == strcmp("395" ,m_sMsgTp))
	{
		PubUpSql("BP_CSTACCTQRYCL", "STATETIME");
		if(0 == strcmp("395" ,m_sMsgTp))
		{
			PubOriSql("BP_CSTACCTQRYCL", "BP_CSTACCTQRYCL", "STATETIME", "k.ORGNLMSGID||k.ORGNLINSTGPTY", m_sOriSql);
		}
	}
	else if( 0 == strcmp("396" ,m_sMsgTp) )
	{
	    PubUpSql("BP_GETTX", "PROCTIME");
	}
	else if (0 == strcmp("398" ,m_sMsgTp) )
	{
		PubUpSql("BP_BKTOCSTDCNTFCTN", "PROCTIME");
	}
	else if( 0 == strcmp("401" ,m_sMsgTp) || 0 == strcmp("402" ,m_sMsgTp) )
	{
	    PubUpSql("BP_REALTMCSTACCTMG", "PROCTIME");
	}
	else if( 0 == strcmp("403" ,m_sMsgTp) )
	{
	    PubUpSql("BP_INVCPRTAPPLY", "PROCTIME");
	}
	else if( 0 == strcmp("404" ,m_sMsgTp))
	{
	    PubOriSql("BP_INVCPRTAPPLY", "BP_INVCPRTRSPN", "PROCTIME", "k.ORGNLMSGID||k.ORGNLINSTGPTY", m_sOriSql);
	}
	else if( 0 == strcmp("411" ,m_sMsgTp) || 0 == strcmp("412" ,m_sMsgTp) )
	{
	    PubUpSql("BP_CSTBDPCXLCL", "STATETIME");

	    if ( 0 == strcmp("412" ,m_sMsgTp) && m_ccms900.PrcSts == PROCESS_PR00) //�������뱨��
	    {
	        PubOriSql("BP_CSTBDPCXLCL", "BP_CSTBDPCXLCL", "STATETIME", "k.OSQLMSGID||k.OSQINSTGPTY", m_sOriSql);
	        //Ϊ������ֹ�����ܹ����ܾ�����0Ԫ�Ľ�ǻ�ִ�����ﲻ����ԭ�������ҵ���״̬��
	        UpdateOriState();
	    }
	}
	else if( 0 == strcmp("350" ,m_sMsgTp))
	{
		PubUpSql("SA_NTRYLIMTQRY", "PROCTIME");
	}
	else if( 0 == strcmp("353" ,m_sMsgTp))
	{
		PubUpSql("SA_NETDBTLMTDSTRBTNMGMT", "PROCTIME");
	}
    else if( 0 == strcmp("354" ,m_sMsgTp))
    {
	    PubUpSql("SA_DBTWRNAPP", "PROCTIME");
    }
    else if( 0 == strcmp("361" ,m_sMsgTp))
    {
        PubUpSql("SA_BALWRNGMG", "PROCTIME");
    }
    else if( 0 == strcmp("365" ,m_sMsgTp) || 0 == strcmp("363" ,m_sMsgTp))
    {
        PubUpSql("SA_QAINFOQRY", "PROCTIME");
    }
    else if( 0 == strcmp("368" ,m_sMsgTp))
    {
        PubUpSql("SA_LQDTYQRYAPPL", "PROCTIME");
    }
    else if( 0 == strcmp("371" ,m_sMsgTp))
    {
        PubUpSql("SA_ACCTMGMTAPPL", "PROCTIME");
    }
    else if( 0 == strcmp("373" ,m_sMsgTp))
    {
        PubUpSql("SA_FNDSOFPOOLMGMT", "PROCTIME");
    }
    else if( 0 == strcmp("374" ,m_sMsgTp) || 0 == strcmp("375" ,m_sMsgTp))
    {
        PubUpSql("SA_INTRBKLNMGMT", "PROCTIME");
        if ( 0 == strcmp("375", m_sMsgTp)
		   && m_ccms900.PrcSts == PROCESS_PR05 ) //���²�ѯ����
	    {
	        PubOriSql("SA_INTRBKLNMGMT", "SA_INTRBKLNMGMT", "PROCTIME", "k.ORGNLMSGID||k.ORGNLINSTGPTY", m_sOriSql);
	    }
    }
    else if (0 == strcmp("376" ,m_sMsgTp) || 0 == strcmp("377" ,m_sMsgTp))
    {
    	 PubUpSql("SA_LQDTYTFR", "PROCTIME");
    }
    else if( 0 == strcmp("407" ,m_sMsgTp) )
    {
        PubUpSql("SA_NETGQMGMT", "PROCTIME");
    }
    else if( 0 == strcmp("614" ,m_sMsgTp))
    {
        PubUpSql("SA_PIBKLNQRYAPPL", "PROCTIME");
    }
    else if( 0 == strcmp("418" ,m_sMsgTp) || 0 == strcmp("419" ,m_sMsgTp) )
	{
	    PubUpSql("BP_CHCKCDTFORLD", "PROCTIME");

	    if ( 0 == strcmp("419" ,m_sMsgTp) && m_ccms900.PrcSts == PROCESS_PR00 ) //�������뱨��
	    {
	        PubOriSql("BP_CHCKCDTFORLD", "BP_CHCKCDTFORLD", "PROCTIME", "k.ORGNLMSGID||k.ORGNLINSTGPTY", m_sOriSql);  //��ʱע��
	    }
	}
	else if( 0 == strcmp("303" ,m_sMsgTp) || 0 == strcmp("CMT303" ,m_sMsgTp) )
	{
		
		PubUpSql("CM_FREEINFO", "STATETIME"); /*���ɸ�ʽ*/
	}
	else if( 0 == strcmp("310" ,m_sMsgTp) || 0 == strcmp("311" ,m_sMsgTp)
	      || 0 == strcmp("312" ,m_sMsgTp) || 0 == strcmp("313" ,m_sMsgTp)
	      || 0 == strcmp("PKG012" ,m_sMsgTp) )
	{
	    PubUpSql("CM_CNOTSGNINFBIZ", "PROCTIME");
        
	    if ( (0 == strcmp("311" ,m_sMsgTp) || 0 == strcmp("313" ,m_sMsgTp))
	       && m_ccms900.PrcSts == PROCESS_PR00 ) //�������뱨��
	    {
            PubOriSql("CM_CNOTSGNINFBIZ", "CM_CNOTSGNINFBIZ", "PROCTIME", "k.ORGNLMSGID||k.ORGNLINSTGPTY", m_sOriSql);
	    }
	}
	else if( 0 == strcmp("314",    m_sMsgTp) || 0 == strcmp("315",    m_sMsgTp)
	      || 0 == strcmp("CMT301", m_sMsgTp) || 0 == strcmp("CMT302", m_sMsgTp) )
	{
		PubUpSql("CM_TRANSINFOQRY", "STATETIME"); /*��ѯ�鸴*/

		if ( (0 == strcmp("315", m_sMsgTp) || 0 == strcmp("CMT302", m_sMsgTp))
		   && m_ccms900.PrcSts == PROCESS_PR00 ) //���²�ѯ����
	    {
	        PubOriSql("CM_TRANSINFOQRY", "CM_TRANSINFOQRY", "STATETIME", "k.QORGNLMSGID||k.QORGNLINSTGDRCTPTY", m_sOriSql);
	    }
	}
	else if( 0 == strcmp("318" ,m_sMsgTp) || 0 == strcmp("319" ,m_sMsgTp) )
	{
	    PubUpSql("CM_PMTRTRCL", "STATETIME");

	    if ( 0 == strcmp("319" ,m_sMsgTp) && m_ccms900.PrcSts == PROCESS_PR00 ) //�������뱨��
	    {
	        PubOriSql("CM_PMTRTRCL", "CM_PMTRTRCL", "STATETIME", "k.ORGNLMSGID||k.ORGNINSTGDRCTPTY", m_sOriSql);
	        //UpdateOriState();
	    }
	}
	else if( 0 == strcmp("903" ,m_sMsgTp) ||0 == strcmp("919" ,m_sMsgTp) )
	{
	    PubUpSql("CM_BNDDIGCERT", "STATETIME");
	}
	else if( 0 == strcmp("143" ,m_sMsgTp) )
	{
	    PubUpSql("HV_PVPSETOFAC", "STATETIME");
	}
	else if(0 == strcmp("132",    m_sMsgTp) && 0 == strcmp("hvps",    m_sMsgChl))
  {
  	  //PubUpSql("HV_TROFACRCVLST", "STATETIME");
  }
	else
	{
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��֧�ֵı�������[%s]", m_sMsgTp);
        PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "��֧�ֵı�������");
	}

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSqlStr     = [%s]", m_sSqlStr);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sListSql    = [%s]", m_sListSql);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sOriSql     = [%s]", m_sOriSql);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sOriListSql = [%s]", m_sOriListSql);
    
    SETCTX(m_entitybase);
    
    // ����ҵ���״̬....����ҵ������ܱ�,ֻ����ϸ��BP_BCOUTSNDCL

    if (NULL != m_sSqlStr && '\0' != m_sSqlStr && 0 < strlen(m_sSqlStr) )
    {
        iRet = m_entitybase.execsql(m_sSqlStr);
    	if (iRet == SQLNOTFOUND)
    	{
    		Trace(L_ERROR, __FILE__, __LINE__, NULL,"����ʱδ�ҵ�����[%s][%s]", 
    		    m_sMsgTp, m_ccms900.OrgnlMsgId.c_str());
    	}
    	else if (iRet != SQL_SUCCESS)
    	{
    		sprintf(m_szErrMsg,  "����ԭҵ��ʧ��[%d][%s][%s]", 
    		    iRet, m_sMsgTp, m_entitybase.GetSqlErr());
    		    
    		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
    		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
    	}
    }
    
        // ������ϸ��
    if (NULL != m_sListSql && '\0' != m_sListSql && 0 < strlen(m_sListSql) )
    {
        iRet = m_entitybase.execsql(m_sListSql);
    	if (iRet == SQLNOTFOUND)
    	{
    		Trace(L_ERROR, __FILE__, __LINE__, NULL,"����ʱδ�ҵ�����[%s][%s]", 
    		    m_sMsgTp, m_ccms900.OrgnlMsgId.c_str());
    	}
    	else if (iRet != SQL_SUCCESS)
    	{
    		sprintf(m_szErrMsg,  "����ԭҵ��ʧ��[%d][%s][%s]", 
    		    iRet, m_sMsgTp, m_entitybase.GetSqlErr());
    		    
    		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
    		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
    	}
    }

    // ����ԭҵ��
    if (NULL != m_sOriSql && '\0' != m_sOriSql && 0 < strlen(m_sOriSql) )
    {
        iRet = m_entitybase.execsql(m_sOriSql);
    	if (iRet == SQLNOTFOUND)
    	{
    		Trace(L_ERROR, __FILE__, __LINE__, NULL,"����ʱδ�ҵ�����[%s][%s]", 
    		    m_sMsgTp, m_ccms900.OrgnlMsgId.c_str());
    	}
    	else if (iRet != SQL_SUCCESS)
    	{
    		sprintf(m_szErrMsg,  "����ԭҵ��ʧ��[%d][%s][%s]", 
    		    iRet, m_sMsgTp, m_entitybase.GetSqlErr());
    		    
    		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
    		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
    	}
    }

    // ����ԭҵ����ϸ
    if (NULL != m_sOriListSql && '\0' != m_sOriListSql && 0 < strlen(m_sOriListSql) )
    {
        iRet = m_entitybase.execsql(m_sOriListSql);
    	if (iRet == SQLNOTFOUND)
    	{
    		Trace(L_ERROR, __FILE__, __LINE__, NULL,"����ʱδ�ҵ�����[%s][%s]", 
    		    m_sMsgTp, m_ccms900.OrgnlMsgId.c_str());
    	}
    	else if (iRet != SQL_SUCCESS)
    	{
    		sprintf(m_szErrMsg,  "����ԭҵ��ʧ��[%d][%s][%s]", 
    		    iRet, m_sMsgTp, m_entitybase.GetSqlErr());
    		    
    		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
    		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
    	}
    }
    //�������ڸ���ԭҵ���ʶ��ִ��SQL by add zql 
    if(NULL != m_sOriRspSql && '\0' != m_sOriRspSql && 0 < strlen(m_sOriRspSql))
    {
    	iRet = m_entitybase.execsql(m_sOriRspSql);
    	if (iRet == SQLNOTFOUND)
    	{
    		Trace(L_ERROR, __FILE__, __LINE__, NULL,"����ʱδ�ҵ�����[%s][%s]", 
    		    m_sMsgTp, m_ccms900.OrgnlMsgId.c_str());
    	}
    	else if (iRet != SQL_SUCCESS)
    	{
    		sprintf(m_szErrMsg,  "����ԭҵ���Ӧ��ʧ��[%d][%s][%s]", 
    		    iRet, m_sMsgTp, m_entitybase.GetSqlErr());
    		    
    		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
    		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
    	}
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms900::UpdateData()");
}

void CRecvBkCcms900::PubUpSql(LPCSTR sTableNm, LPCSTR sTimeNm)
{
    if ( 0 == strcmp(sTableNm, "CM_FREEINFO") || 0 == strcmp(sTableNm, "SA_NTRYLIMTQRY") )    //0 :δ��Ӧ 1������Ӧ
    {
        sprintf(m_sSqlStr,  "UPDATE %s t SET"
							" t.busistate = '%s', t.procstate = '%s',"
							" t.%s = sysdate, t.processcode = '%s',"
 							" t.rjctinf = '%s'  WHERE t.RSFLAG<>'2' AND t.MSGID = '%s'"
							" AND t.INSTGINDRCTPTY = '%s' ",
							sTableNm,
							m_ccms900.PrcSts.c_str(),
							m_sProcSts,
							sTimeNm,
							m_ccms900.PrcCd.c_str(),
							m_ccms900.RjctInf.c_str(),
							m_ccms900.OrgnlMsgId.c_str(),
							m_ccms900.OrgnlInstgPty.c_str());
        
    }
    else if ( 0 == strcmp(sTableNm, "CM_TRANSINFOQRY") )
    {
        sprintf(m_sSqlStr,  "UPDATE %s t SET"
							" t.busistate = '%s', t.procstate = '%s',"
							" t.%s = sysdate, t.processcode = '%s',"
 							" t.rjctinf = '%s', t.finalstatedate = '%s'  WHERE t.RSFLAG<>'2' AND t.MSGID = '%s'"
							" AND t.INSTGINDRCTPTY = '%s' ",
							sTableNm,
							m_ccms900.PrcSts.c_str(),
							m_sProcSts,
							sTimeNm,
							m_ccms900.PrcCd.c_str(),
							m_ccms900.RjctInf.c_str(),
							m_ccms900.PrcDt.c_str(),
							m_ccms900.OrgnlMsgId.c_str(),
							m_ccms900.OrgnlInstgPty.c_str());
        
    }   
    else if ( 0 == strcmp(sTableNm, "SA_NTRYLIMTQRY"))    //0 :δ��Ӧ 1������Ӧ
    {
        sprintf(m_sSqlStr,  "UPDATE %s t SET"
							" t.busistate = '%s', t.procstate = '%s',"
							" t.%s = sysdate, t.processcode = '%s',"
 							" t.rjctinf = '%s'  WHERE t.MSGID = '%s'"
							" AND t.INSTGINDRCTPTY = '%s' ",
							sTableNm,
							m_ccms900.PrcSts.c_str(),
							m_sProcSts,
							sTimeNm,
							m_ccms900.PrcCd.c_str(),
							m_ccms900.RjctInf.c_str(),
							m_ccms900.OrgnlMsgId.c_str(),
							m_ccms900.OrgnlInstgPty.c_str());
        
    }
    else if ( 0 == strcmp(sTableNm, "SA_ACCTMGMTAPPL") || 0 == strcmp(sTableNm, "SA_NETDBTLMTDSTRBTNMGMT") )
    {
        sprintf(m_sSqlStr,  "UPDATE %s t SET"
							" t.procstate = '%s',"
							" t.%s = sysdate, t.PRCCD = '%s',"
 							" t.rjctinf = '%s' WHERE t.MSGID = '%s'"
							" AND t.INSTGPTY = '%s' ",
							sTableNm,
							m_sProcSts,
							sTimeNm,
							m_ccms900.PrcCd.c_str(),
							m_ccms900.RjctInf.c_str(),
							m_ccms900.OrgnlMsgId.c_str(),
							m_ccms900.OrgnlInstgPty.c_str());
        
    }
    else if ( 0 == strcmp(sTableNm, "CM_PMTRTRCL")  )
    {
        sprintf(m_sSqlStr,  "UPDATE %s t SET"
							" t.procstate = '%s', t.%s = sysdate, "
 							" t.rjctinf = '%s' WHERE t.MSGID = '%s'"
							" AND t.INSTGINDRCTPTY = '%s' AND t.RSFLAG<> '2' ",
							sTableNm,
							m_sProcSts,
							sTimeNm,
							m_ccms900.RjctInf.c_str(),
							m_ccms900.OrgnlMsgId.c_str(),
							m_ccms900.OrgnlInstgPty.c_str());
        
    }
    else if (0 == strcmp(sTableNm, "SA_LQDTYTFR"))
    {
    	sprintf(m_sSqlStr,  "UPDATE %s t SET"
							" t.procstate = '%s', t.%s = sysdate "
 							" WHERE t.MSGID = '%s'"
							" AND t.INSTGDRCTPTY = '%s'",
							sTableNm,
							m_sProcSts,
							sTimeNm,
							m_ccms900.OrgnlMsgId.c_str(),
							m_ccms900.OrgnlInstgPty.c_str());
	}
    else if(0 == strcmp(sTableNm, "SA_INTRBKLNMGMT"))
    {
    	sprintf(m_sSqlStr,  "UPDATE %s t SET"
							" t.procstate = '%s', t.%s = sysdate, "
 							" t.rjctinf = '%s' , t.BUSISTATE = '%s' "
 							", t.PROCESSCODE = '%s', t.RJINF = '%s'  "
 							"WHERE t.MSGID = '%s'"
							" AND t.INSTGINDRCTPTY = '%s'",
							sTableNm,
							m_sProcSts,
							sTimeNm,
							m_ccms900.RjctInf.c_str(),
							m_ccms900.PrcSts.c_str(),
							m_ccms900.PrcCd.c_str(),
							m_ccms900.RjctInf.c_str(),
							m_ccms900.OrgnlMsgId.c_str(),
							m_ccms900.OrgnlInstgPty.c_str());
    }
    else if (0 == strcmp(sTableNm, "CM_CNOTSGNINFBIZ"))
    {
        sprintf(m_sSqlStr,  "UPDATE %s t SET"
							" t.procstate = '%s', t.%s = sysdate, "
 							" t.rjctinf = '%s' WHERE t.SRCFLAG<>'2' AND t.MSGID = '%s'"
							" AND t.INSTGPTY = '%s'",
							sTableNm,
							m_sProcSts,
							sTimeNm,
							m_ccms900.RjctInf.c_str(),
							m_ccms900.OrgnlMsgId.c_str(),
							m_ccms900.OrgnlInstgPty.c_str());
        
    }
    else if ( 0 == strcmp(sTableNm, "BP_REALTMCSTACCTMG") || 0 == strcmp(sTableNm, "BP_CHCKCDTFORLD") )
    {
        sprintf(m_sSqlStr,  "UPDATE %s t SET"
							" t.procstate = '%s', t.%s = sysdate, "
 							" t.rjctinf = '%s' WHERE t.SRCFLAG<>'2' AND t.MSGID = '%s'"
							" AND t.INSTGPTY = '%s'",
							sTableNm,
							m_sProcSts,
							sTimeNm,
							m_ccms900.RjctInf.c_str(),
							m_ccms900.OrgnlMsgId.c_str(),
							m_ccms900.OrgnlInstgPty.c_str());
        
    }
    else if ( 0 == strcmp(sTableNm, "BP_GETTX") || 0 == strcmp(sTableNm, "BP_INVCPRTAPPLY") )
    {
        sprintf(m_sSqlStr,  "UPDATE %s t SET"
							" t.procstate = '%s', t.%s = sysdate "
							" WHERE t.MSGID = '%s'"
							" AND t.INSTGPTY = '%s'",
							sTableNm,
							m_sProcSts,
							sTimeNm,
							m_ccms900.OrgnlMsgId.c_str(),
							m_ccms900.OrgnlInstgPty.c_str());
        
    }
    else if(0 == strcmp(sTableNm, "BP_BKTOCSTDCNTFCTN"))
    {
    	sprintf(m_sSqlStr,  "UPDATE %s t SET"
							" t.procstate = '%s', t.%s = sysdate "
							" WHERE t.MSGID = '%s'"
							" AND t.INSTGDRCTPTY = '%s'",
							sTableNm,
							m_sProcSts,
							sTimeNm,
							m_ccms900.OrgnlMsgId.c_str(),
							m_ccms900.OrgnlInstgPty.c_str());
    }
    else if ( 0 == strcmp(sTableNm, "BP_CSTBDPCXLCL") )
    {
        sprintf(m_sSqlStr,  "UPDATE %s t SET"
				" t.procstate = '%s', t.busistate='%s', t.processcode='%s', t.rjctinf='%s', t.%s = sysdate "
				" WHERE t.MSGID = '%s'"
				" AND t.INSTGPTY = '%s' AND t.RSFLAG = '1' ",
				sTableNm,
				m_sProcSts,
				m_ccms900.PrcSts.c_str(),
				m_ccms900.PrcCd.c_str(),
				m_ccms900.RjctInf.c_str(),
				sTimeNm,
				m_ccms900.OrgnlMsgId.c_str(),
				m_ccms900.OrgnlInstgPty.c_str());
        
    }
    else if(0 == strcmp(sTableNm,"BP_BIZPUBNTCE") )   //����С��389 388
    {
    	 sprintf(m_sSqlStr,  "UPDATE %s t SET"
							" t.procstate = '%s', t.%s = sysdate "
							" WHERE t.MSGID = '%s'"
							" AND t.INSTGPTY = '%s' ",
							sTableNm,
							m_sProcSts,
							sTimeNm,
							m_ccms900.OrgnlMsgId.c_str(),
							m_ccms900.OrgnlInstgPty.c_str());
    }
    else if(0 == strcmp(sTableNm, "CM_BNDDIGCERT"))
    {
    	sprintf(m_sSqlStr,  "UPDATE %s t SET t.procstate = '%s', t.%s = sysdate, "
    					"t.BUSISTATE='%s', t.PROCESSCODE='%s', t.RJCTINF='%s' "
						" WHERE t.MSGID = '%s' AND t.INSTGDRCTPTY = '%s'",
						sTableNm,
						m_sProcSts,
						sTimeNm,
						m_ccms900.PrcSts.c_str(),
						m_ccms900.PrcCd.c_str(),
						m_ccms900.RjctInf.c_str(),
						m_ccms900.OrgnlMsgId.c_str(),
						m_ccms900.OrgnlInstgPty.c_str());
    }
    else if ( 0 == strcmp(sTableNm, "SA_BALWRNGMG")
            || 0 == strcmp(sTableNm, "SA_LQDTYQRYAPPL") || 0 == strcmp(sTableNm, "SA_FNDSOFPOOLMGMT")
            || 0 == strcmp(sTableNm, "SA_PIBKLNQRYAPPL") || 0 == strcmp(sTableNm, "SA_DBTWRNAPP") 
            || 0 == strcmp(sTableNm, "SA_NETGQMGMT") )
    {
        sprintf(m_sSqlStr,  "UPDATE %s t SET"
							" t.procstate = '%s', t.%s = sysdate, "
        					" t.busistate = '%s', t.processcode='%s', t.rjctinf='%s' "
							" WHERE t.MSGID = '%s'"
							" AND t.INSTGDRCTPTY = '%s'",
							sTableNm,
							m_sProcSts,
							sTimeNm,
							m_ccms900.PrcSts.c_str(),
							m_ccms900.PrcCd.c_str(),
							m_ccms900.RjctInf.c_str(),
							m_ccms900.OrgnlMsgId.c_str(),
							m_ccms900.OrgnlInstgPty.c_str());
        
    }
    else if (  0 == strcmp(sTableNm, "SA_QAINFOQRY") )
    {
        sprintf(m_sSqlStr,  "UPDATE %s t SET"
                            " t.procstate = '%s', t.%s = sysdate, t.rjctinf = '%s',t.rspflag ='1' "
                            " WHERE t.MSGID = '%s'"
                            " AND t.instgdrctpty = '%s'",
                            sTableNm,
                            m_sProcSts,
                            sTimeNm,
                            m_ccms900.RjctInf.c_str(),
                            m_ccms900.OrgnlMsgId.c_str(),
                            m_ccms900.OrgnlInstgPty.c_str());
    }
    //add by zql 20120629
    else if( 0 == strcmp(sTableNm, "BP_CSTCTRCTMGCL"))
    {
    	sprintf(m_sSqlStr,  "UPDATE %s t SET"
                            " t.procstate = '%s', t.%s = sysdate "
                            " WHERE t.MSGID = '%s' AND t.SRCFLAG='1' "
                            " AND t.instgdrctpty = '%s'",
                            sTableNm,
                            m_sProcSts,
                            sTimeNm,
                            m_ccms900.OrgnlMsgId.c_str(),
                            m_ccms900.OrgnlInstgPty.c_str());
	}
	//add by zql 20120629
	else if(0 == strcmp(sTableNm, "BP_CSTACCTQRYCL"))
	{
		sprintf(m_sSqlStr,  "UPDATE %s t SET"
                            " t.procstate = '%s', t.%s = sysdate "
                            " WHERE t.MSGID = '%s'"
                            " AND t.instgdrctpty = '%s' and t.SRCFLAG !='2' ",
                            sTableNm,
                            m_sProcSts,
                            sTimeNm,
                            m_ccms900.OrgnlMsgId.c_str(),
                            m_ccms900.OrgnlInstgPty.c_str());
	}
	else if( (0 == strcmp(sTableNm, "BP_BCOUTSNDCL") && 0 != strcmp("PKG003", m_sMsgTp) && 0 != strcmp("123", m_sMsgTp)) || 
	    ((0 == strcmp("124", m_sMsgTp) ||  0 == strcmp("PKG009", m_sMsgTp)) && 0 == strcmp(sTableNm, "BP_BDSNDCL")) )
	{
	    string strNetRnd = m_ccms900.PrcSts == "PR09" ? "0" : m_ccms900.NetgRnd;
	    sprintf(m_sSqlStr,  "UPDATE %s t SET"
                            " t.busistate = '%s', t.procstate = '%s',"
                            " t.processcode = '%s', t.%s = sysdate,"
                            " t.rjctinf = '%s', t.finalstatedate = '%s', "
                            " t.netgdt = '%s', t.netgrnd = '%s' "
                            " WHERE t.MSGID = '%s' AND t.INSTGDRCTPTY = '%s'",
                            sTableNm,
                            m_ccms900.PrcSts.c_str(),
                            m_sProcSts,
                            m_ccms900.PrcCd.c_str(),
                            sTimeNm,
                            m_ccms900.RjctInf.c_str(),
                            m_ccms900.PrcDt.c_str(),
                            m_ccms900.PrcDt.c_str(),
                            strNetRnd.c_str(),
                            m_ccms900.OrgnlMsgId.c_str(),
                            m_ccms900.OrgnlInstgPty.c_str());
	}
    else
    {
        sprintf(m_sSqlStr,  "UPDATE %s t SET"
                            " t.busistate = '%s', t.procstate = '%s',"
                            " t.processcode = '%s', t.%s = sysdate,"
                            " t.rjctinf = '%s', t.finalstatedate = '%s' "
                            " WHERE t.MSGID = '%s' AND t.INSTGDRCTPTY = '%s'",
                            sTableNm,
                            m_ccms900.PrcSts.c_str(),
                            m_sProcSts,
                            m_ccms900.PrcCd.c_str(),
                            sTimeNm,
                            m_ccms900.RjctInf.c_str(),
                            m_ccms900.PrcDt.c_str(),
                            m_ccms900.OrgnlMsgId.c_str(),
                            m_ccms900.OrgnlInstgPty.c_str());
    }
}

void CRecvBkCcms900::PubListSql(LPCSTR sTableNm, LPCSTR sTimeNm)
{
	/*if( 0 == strcmp("121",    m_sMsgTp))
	{
		sprintf(m_sListSql, "UPDATE %s t SET"
						" t.busistate = '%s', t.procstate = '%s',"
						" t.processcode = '%s', t.%s = sysdate,"
						" t.rjctinf = '%s', t.finalstatedate = '%s',"
						" t.netgdt = '%s', t.netgrnd = '%s'"
						" WHERE t.MSGID = '%s' AND t.INSTGDRCTPTY = '%s'",
						sTableNm,
						m_ccms900.PrcSts.c_str(),
						m_sProcSts,
						m_ccms900.PrcCd.c_str(),
						sTimeNm,
						m_ccms900.RjctInf.c_str(),
						m_ccms900.PrcDt.c_str(),
						m_ccms900.PrcDt.c_str(),
						m_ccms900.NetgRnd.c_str(),
						m_ccms900.OrgnlMsgId.c_str(),
						m_ccms900.OrgnlInstgPty.c_str());
	}*/
	sprintf(m_sListSql, "UPDATE %s t SET"
						" t.busistate = '%s', t.procstate = '%s',"
						" t.processcode = '%s', t.%s = sysdate,"
						" t.rjctinf = '%s', t.finalstatedate = '%s',"
						" t.netgdt = '%s', t.netgrnd = '%s'"
						" WHERE t.MSGID = '%s' AND t.INSTGDRCTPTY = '%s'",
						sTableNm,
						m_ccms900.PrcSts.c_str(),
						m_sProcSts,
						m_ccms900.PrcCd.c_str(),
						sTimeNm,
						m_ccms900.RjctInf.c_str(),
						m_ccms900.PrcDt.c_str(),
						m_ccms900.PrcDt.c_str(),
						m_ccms900.NetgRnd.c_str(),
						m_ccms900.OrgnlMsgId.c_str(),
						m_ccms900.OrgnlInstgPty.c_str());
						
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]", m_sListSql);
}

void CRecvBkCcms900::PubOriSql(LPCSTR sUpTable, LPCSTR sOriTable, LPCSTR sTimeNm, LPCSTR sColNm, LPTSTR sUpSql)
{
	if(0 == strcmp("393" ,m_sMsgTp))
	{
		 //�����ټӻ�Ӧ��ʶ
		sprintf(sUpSql, "UPDATE %s t SET "
					"t.%s = sysdate,"
                    "t.PROCSTATE = '07' "
                    " WHERE t.MSGID||t.INSTGDRCTPTY in "
                    " (SELECT %s "
                    " FROM %s k"
                    " WHERE k.MSGID = '%s' "
                    " AND k.INSTGDRCTPTY = '%s') and SRCFLAG = '2'", 
                    sUpTable,
                    sTimeNm,
                    sColNm,
                    sOriTable,
					m_ccms900.OrgnlMsgId.c_str(),
                    m_ccms900.OrgnlInstgPty.c_str());
	}
	else if (0 == strcmp("404" ,m_sMsgTp))
	{
		sprintf(sUpSql, "UPDATE %s t SET "
						"t.%s = sysdate,"
						"t.RSPFLAG ='3',"
	                    "t.PROCSTATE = '07' "
	                    " WHERE t.MSGID||t.INSTGDRCTPTY in "
	                    " (SELECT %s "
	                    " FROM %s k"
	                    " WHERE k.MSGID = '%s' "
	                    " AND k.INSTGDRCTPTY = '%s')", 
	                    sUpTable,
	                    sTimeNm,
	                    sColNm,
	                    sOriTable,
						m_ccms900.OrgnlMsgId.c_str(),
	                    m_ccms900.OrgnlInstgPty.c_str());
	}
	else if (0 == strcmp("315" ,m_sMsgTp) || 0 == strcmp("CMT302" ,m_sMsgTp)
	        || 0 == strcmp("319" ,m_sMsgTp) || 0 == strcmp("375" ,m_sMsgTp) )
	{
		sprintf(sUpSql, "UPDATE %s t SET "
						"t.%s = sysdate,"
	                    "rspflag='1'"                           //"t.PROCSTATE = '%s',"
	                    //"t.rjctinf = '%s' "
	                    " WHERE t.MSGID||t.INSTGINDRCTPTY in "
	                    " (SELECT %s "
	                    " FROM %s k"
	                    " WHERE k.RSFLAG <> '2' AND k.MSGID = '%s' "
	                    " AND k.INSTGINDRCTPTY = '%s') AND RSFLAG = '2' ", 
	                    sUpTable,
	                    sTimeNm,
	                    //m_sProcSts,
	                    //m_ccms900.RjctInf.c_str(),
	                    sColNm,
	                    sOriTable,
						m_ccms900.OrgnlMsgId.c_str(),
	                    m_ccms900.OrgnlInstgPty.c_str());
	}
	else if (  0 == strcmp("412" ,m_sMsgTp) )
	{
		sprintf(sUpSql, "UPDATE %s t SET "
						"t.%s = sysdate,"
	                    "rspflag='1'"          
	                    " WHERE t.MSGID||t.INSTGPTY in "
	                    " (SELECT %s "
	                    " FROM %s k"
	                    " WHERE k.RSFLAG <> '2' AND k.MSGID = '%s' "
	                    " AND k.INSTGPTY = '%s') AND RSFLAG = '2' ", 
	                    sUpTable,
	                    sTimeNm, 
	                    sColNm,
	                    sOriTable,
						m_ccms900.OrgnlMsgId.c_str(),
	                    m_ccms900.OrgnlInstgPty.c_str());
	}
	else if (0 == strcmp("395" ,m_sMsgTp) )
	{
		sprintf(sUpSql, "UPDATE %s t SET "
						"t.%s = sysdate,"
	                    "rspflag='1'"                           //"t.PROCSTATE = '%s',"
	                    //"t.rjctinf = '%s' "
	                    " WHERE t.MSGID||t.INSTGPTY in "
	                    " (SELECT %s "
	                    " FROM %s k"
	                    " WHERE k.srcflag <> '2' AND k.MSGID = '%s' "
	                    " AND k.INSTGDRCTPTY = '%s') AND srcflag = '2' ", 
	                    sUpTable,
	                    sTimeNm,
	                    //m_sProcSts,
	                    //m_ccms900.RjctInf.c_str(),
	                    sColNm,
	                    sOriTable,
						m_ccms900.OrgnlMsgId.c_str(),
	                    m_ccms900.OrgnlInstgPty.c_str());
	}
	else if( 0 == strcmp("311" ,m_sMsgTp) || 0 == strcmp("313" ,m_sMsgTp) )
	{
		sprintf(sUpSql, "UPDATE %s t SET "
						"t.%s = sysdate,"
	                    "rspflag='1'"                           //"t.PROCSTATE = '%s',"
	                    //"t.rjctinf = '%s' "
	                    " WHERE t.MSGID||t.INSTGPTY in "
	                    " (SELECT %s "
	                    " FROM %s k"
	                    " WHERE k.SRCFLAG <> '2' AND k.MSGID = '%s' "
	                    " AND k.INSTGPTY = '%s') AND SRCFLAG = '2' ",
	                    sUpTable,
	                    sTimeNm,
	                    //m_sProcSts,
	                    //m_ccms900.RjctInf.c_str(),
	                    sColNm,
	                    sOriTable,
						m_ccms900.OrgnlMsgId.c_str(),
	                    m_ccms900.OrgnlInstgPty.c_str());	    
	}
	else if( 0 == strcmp("375", m_sMsgTp)){
		sprintf(sUpSql, "UPDATE %s t SET "
						"t.%s = sysdate, t.rspflag='1', "
						"t.PROCSTATE = '%s' "
						" WHERE t.MSGID||t.INSTGDRCTPTY in "
						" (SELECT %s "
						" FROM %s k"
						" WHERE k.MSGID = '%s' "
						" AND k.INSTGDRCTPTY = '%s')",
						sUpTable,
						sTimeNm,
						m_sProcSts,
						sColNm,
						sOriTable,
						m_ccms900.OrgnlMsgId.c_str(),
						m_ccms900.OrgnlInstgPty.c_str());
	}
	else if( 0 == strcmp("419", m_sMsgTp)){
		sprintf(sUpSql, "UPDATE %s t SET "
				"t.%s = sysdate,"
				"t.PROCSTATE = '07' "
				" WHERE t.MSGID||t.INSTGDRCTPTY in "
				" (SELECT %s "
				" FROM %s k"
				" WHERE k.MSGID = '%s' "
				" AND k.INSTGDRCTPTY = '%s') AND SRCFLAG='2' ",
				sUpTable,
				sTimeNm,
				sColNm,
				sOriTable,
				m_ccms900.OrgnlMsgId.c_str(),
				m_ccms900.OrgnlInstgPty.c_str());
	}
	else
	{
		sprintf(sUpSql, "UPDATE %s t SET "
						"t.%s = sysdate,"
	                    "t.PROCSTATE = '%s' "
	                    " WHERE t.MSGID||t.INSTGDRCTPTY in "
	                    " (SELECT %s "
	                    " FROM %s k"
	                    " WHERE k.MSGID = '%s' "
	                    " AND k.INSTGDRCTPTY = '%s')", 
	                    sUpTable,
	                    sTimeNm,
	                    m_sProcSts,
	                    sColNm,
	                    sOriTable,
						m_ccms900.OrgnlMsgId.c_str(),
	                    m_ccms900.OrgnlInstgPty.c_str());
	}
}

/******************************************************************************
*  Function:   InsertComsendmb
*  Description:������ͨѶ��
*  Input:      ��
*  Output:     
*  Return:     0   : �����ɹ�,
               ����: ����ʧ��
*  Others:     ��
*  Author:     hhc
*  Date:       2012-02-08
*******************************************************************************/
void CRecvBkCcms900::InsertComsendmb(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms900::InsertComsendmb()");
	
	int    iRet = RTN_FAIL;
	string strRval = "";
    
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sMsgTp[%s]", m_sMsgTp);
	
    if( 0 == strcmp("121",    m_sMsgTp) || 0 == strcmp("122",    m_sMsgTp)  
	 || 0 == strcmp("125",    m_sMsgTp)
	 || 0 == strcmp("PKG001", m_sMsgTp) || 0 == strcmp("PKG005", m_sMsgTp)
     || 0 == strcmp("PKG007", m_sMsgTp) )
	{
		CBpbcoutsendlist cBpbcoutsendlist;
		
		string strSql = "";
		strSql = " MSGID = '";
		strSql += m_ccms900.OrgnlMsgId + "' and INSTGDRCTPTY = '";
		strSql += m_ccms900.OrgnlInstgPty + "'";

		SETCTX(cBpbcoutsendlist);
			
		iRet = cBpbcoutsendlist.find(strSql);
		
		if(OPERACT_SUCCESS != iRet)
		{
		 sprintf(m_szErrMsg, "cBpbcoutsendlist find fail:  [%d][%s]", 
			 iRet, cBpbcoutsendlist.GetSqlErr());
		 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
		 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		while(0 == cBpbcoutsendlist.fetch())
		{
			// ���ӶԼ�ֱ�����жϣ���������ڵ����������ͨѶ�����򲻲��� by add zql 2102-6-6s
			if(cBpbcoutsendlist.m_srcflag == "0")    
			{
				iRet = GetTagVal(strRval, cBpbcoutsendlist.m_reserve, ":orimsgsys:");
				if(0 == iRet)
				{
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "txid[%s]", cBpbcoutsendlist.m_txid.c_str());
					m_strMsgID = cBpbcoutsendlist.m_txid;
					
					strcpy(m_szDisSys, strRval.c_str());
					strncpy(m_szOrgnlMbMsgId, cBpbcoutsendlist.m_mbmsgid.c_str(), 22);
	        		
				}
				else if(-2 == iRet)
				{
					Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "ԭҵ�����ڷ���ϵͳ��Ϊ��");
					PMTS_ThrowException(OTH_ERR);
				}
			}
		}
		
		cBpbcoutsendlist.closeCursor();
	}
	else
	{
		m_strMsgID = m_ccms900.OrgnlMsgId;
		int    iRet    = OPERACT_FAILED;
		string strRsflag = "";// �����˱�ʶ
		string strRval = "";
		string strWhere = "";
		
		CSyscbbabankcode cSyscbbabankcode;
		
		strWhere += "bankcode = '";
		strWhere += m_ccms900.OrgnlInstgPty;
		strWhere += "'";
	
		SETCTX(cSyscbbabankcode);
	
		iRet = cSyscbbabankcode.find(strWhere);
		if (SQL_SUCCESS != iRet) 
	    {
	        sprintf(m_szErrMsg, "cSyscbbabankcode.find():��ѯsys_cbbabankcode��¼��, [%d][%s]",
	        		iRet, cSyscbbabankcode.GetSqlErr()); 
			
	        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
	        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
	    }
		
		while(SQL_SUCCESS == iRet)
		{
			iRet = cSyscbbabankcode.fetch();	
			if (SQLNOTFOUND == iRet) 
			{
				strRsflag = "0";// ���ڷ���
				cSyscbbabankcode.closeCursor();
				break;
			}
			else if (SQL_SUCCESS != iRet) 
			{
				sprintf(m_szErrMsg, "cSyscbbabankcode.fetch():��ȡsys_cbbabankcode��¼��, [%d][%s]",
						iRet, cSyscbbabankcode.GetSqlErr()); 
				
				Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
				PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
			}
			
			strRsflag = "2";// ��������
		}
		cSyscbbabankcode.closeCursor();
			
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strRsflag = [%s]", strRsflag.c_str());
		if( 0 == strcmp("303" ,m_sMsgTp) || 0 == strcmp("CMT303" ,m_sMsgTp) )
		{
			char strTss[100]={0};
			GetSysparm(m_dbproc,"22",strTss);
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strTss=[%s]",strTss);
			
			CCmfreeinfo cCmfreeinfo;
			
			cCmfreeinfo.m_msgid          = m_ccms900.OrgnlMsgId; 
			cCmfreeinfo.m_instgindrctpty = m_ccms900.OrgnlInstgPty;  
			cCmfreeinfo.m_sysid          = m_ccms900.SysCd;// ϵͳ��ʶ�� ���:HVPS С��:BEPS
			cCmfreeinfo.m_rsflag         = strRsflag;
		    
		    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cCmfreeinfo.m_msgid          = [%s]", cCmfreeinfo.m_msgid.c_str());
		    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cCmfreeinfo.m_sysid          = [%s]", cCmfreeinfo.m_sysid.c_str());
		    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cCmfreeinfo.m_instgindrctpty = [%s]", cCmfreeinfo.m_instgindrctpty.c_str());
	    
			SETCTX(cCmfreeinfo);
			
			iRet = cCmfreeinfo.findByPK();
		    if(SQLNOTFOUND == iRet)
		    {
		    	sprintf(m_szErrMsg, "δ�ҵ����ݣ�����ת�������ڡ�");
				Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
				
				return;
			}
			if(OPERACT_SUCCESS != iRet)
			{
				 sprintf(m_szErrMsg, "cCmfreeinfo findByPK fail:  [%d][%s]", 
					 iRet, cCmfreeinfo.GetSqlErr());
				 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
				 PMTS_ThrowException(DB_GET_DATA_FAIL);
			}
			
			iRet = GetTagVal(strRval, cCmfreeinfo.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cCmfreeinfo.m_mbmsgid.c_str(), 22);
			}
			else if(-2 == iRet)
			{
				Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "ԭҵ�����ڷ���ϵͳ��Ϊ��");
				PMTS_ThrowException(OTH_ERR);
			}
		}
		else if( 0 == strcmp("310" ,m_sMsgTp) || 0 == strcmp("311" ,m_sMsgTp)
		      || 0 == strcmp("312" ,m_sMsgTp) || 0 == strcmp("313" ,m_sMsgTp)
	     	  || 0 == strcmp("PKG012", m_sMsgTp) )
		{
			CCmcnotsgninfbiz cCmcnotsgninfbiz;
			
			cCmcnotsgninfbiz.m_msgid    = m_ccms900.OrgnlMsgId;
			cCmcnotsgninfbiz.m_instgpty	= m_ccms900.OrgnlInstgPty;
			cCmcnotsgninfbiz.m_srcflag	= strRsflag;
			cCmcnotsgninfbiz.m_syscd    = m_ccms900.SysCd;
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cCmcnotsgninfbiz.m_msgid    = [%s]", cCmcnotsgninfbiz.m_msgid.c_str());
		    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cCmcnotsgninfbiz.m_instgpty = [%s]", cCmcnotsgninfbiz.m_instgpty.c_str());
		    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cCmcnotsgninfbiz.m_srcflag  = [%s]", cCmcnotsgninfbiz.m_srcflag.c_str());
		    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cCmcnotsgninfbiz.m_sysid    = [%s]", cCmcnotsgninfbiz.m_syscd.c_str());
		    SETCTX(cCmcnotsgninfbiz);
			
			iRet = cCmcnotsgninfbiz.findByPK();
		    if(SQLNOTFOUND == iRet)
		    {
		    	sprintf(m_szErrMsg, "δ�ҵ����ݣ�����ת�������ڡ�");
				Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
				
				return;
			}
			if(OPERACT_SUCCESS != iRet)
			{
				 sprintf(m_szErrMsg, "cCmcnotsgninfbiz findByPK fail:  [%d][%s]", 
					 iRet, cCmcnotsgninfbiz.GetSqlErr());
				 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
				 PMTS_ThrowException(DB_GET_DATA_FAIL);
			}
			
			iRet = GetTagVal(strRval, cCmcnotsgninfbiz.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cCmcnotsgninfbiz.m_mbmsgid.c_str(), 22);
			}
			else if(-2 == iRet)
			{
				Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "ԭҵ�����ڷ���ϵͳ��Ϊ��");
				PMTS_ThrowException(OTH_ERR);
			}
		}	
		else if( 0 == strcmp("314",    m_sMsgTp) || 0 == strcmp("315",    m_sMsgTp)
		      || 0 == strcmp("CMT301", m_sMsgTp) || 0 == strcmp("CMT302", m_sMsgTp) )
		{
			CCmtransinfoqry cCmtransinfoqry;
	
			cCmtransinfoqry.m_msgid          = m_ccms900.OrgnlMsgId; 
			cCmtransinfoqry.m_instgindrctpty = m_ccms900.OrgnlInstgPty; 
			cCmtransinfoqry.m_sysid          = m_ccms900.SysCd;// ϵͳ��ʶ�� ���:HVPS С��:BEPS
			cCmtransinfoqry.m_rsflag         = strRsflag;
			
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cCmtransinfoqry.m_msgid          = [%s]", cCmtransinfoqry.m_msgid.c_str());
		    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cCmtransinfoqry.m_sysid          = [%s]", cCmtransinfoqry.m_sysid.c_str());
		    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cCmtransinfoqry.m_instgindrctpty = [%s]", cCmtransinfoqry.m_instgindrctpty.c_str());
	    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cCmtransinfoqry.m_rsflag         = [%s]", cCmtransinfoqry.m_rsflag.c_str());
			SETCTX(cCmtransinfoqry);
		
		    iRet = cCmtransinfoqry.findByPK();
		    if(SQLNOTFOUND == iRet)
		    {
		    	sprintf(m_szErrMsg, "δ�ҵ����ݣ�����ת�������ڡ�");
				Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
				
				return;
			}
		    if(OPERACT_SUCCESS != iRet)
		    {
		    	sprintf(m_szErrMsg, "��ȡ����ʧ��, iRet = %d", iRet, cCmtransinfoqry.GetSqlErr());
				Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		
				PMTS_ThrowException(DB_NOT_FOUND);
		    }
			
			iRet = GetTagVal(strRval, cCmtransinfoqry.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cCmtransinfoqry.m_mbmsgid.c_str(), 22);

			}
			else if(-2 == iRet)
			{
				Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "ԭҵ�����ڷ���ϵͳ��Ϊ��");
				PMTS_ThrowException(OTH_ERR);
			}
		}
		else if (0 == strcmp("143",m_sMsgTp))      //����������ͨѶ�� by add zql 2012-6-27
		{
			CHvpvpsetofac   m_chvpvpsetofac;
			m_chvpvpsetofac.m_msgid             = m_ccms900.OrgnlMsgId;
			m_chvpvpsetofac.m_instgindrctpty	= m_ccms900.OrgnlInstgPty;
			m_chvpvpsetofac.m_msgtp	            = m_ccms900.OrgnlMT;
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_chvpvpsetofac.m_msgid    = [%s]", m_chvpvpsetofac.m_msgid.c_str());
		    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_chvpvpsetofac.m_instgindrctpty = [%s]", m_chvpvpsetofac.m_instgindrctpty.c_str());
		    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_chvpvpsetofac.m_msgtp = [%s]", m_chvpvpsetofac.m_msgtp.c_str());
		    SETCTX(m_chvpvpsetofac);
			
			char strSQL[1024]={0};
			sprintf(strSQL,"msgid ='%s' and INSTGINDRCTPTY='%s' ",m_chvpvpsetofac.m_msgid.c_str(),m_chvpvpsetofac.m_instgindrctpty.c_str());
			Trace(L_INFO, __FILE__, __LINE__, NULL, "strSQL=[%s]", strSQL);
			iRet = m_chvpvpsetofac.find(strSQL);
		    if(0 != iRet)
		    {
		    	sprintf(m_szErrMsg, "δ�ҵ����ݣ�����ת�������ڡ�");
				Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
				
				return;
			}
			iRet = m_chvpvpsetofac.fetch();
			if(iRet ==SQLNOTFOUND)
			{
				Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������");
		        m_chvpvpsetofac.closeCursor();
		        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "m_chvpvpsetofacû���ҵ�����������ԭҵ��");
			}
			/*
			if(OPERACT_SUCCESS != iRet)
			{
				 sprintf(m_szErrMsg, "m_chvpvpsetofac findByPK fail:  [%d][%s]", 
					 iRet, m_chvpvpsetofac.GetSqlErr());
				 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
				 PMTS_ThrowException(DB_GET_DATA_FAIL);
			}
			*/
			iRet = GetTagVal(strRval, m_chvpvpsetofac.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, m_chvpvpsetofac.m_mbmsgid.c_str(), 22);
			
			}
			else if(-2 == iRet)
			{
				Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "ԭҵ�����ڷ���ϵͳ��Ϊ��");
				PMTS_ThrowException(OTH_ERR);
			}
			m_chvpvpsetofac.closeCursor();
		}
		else//����������ͨѶ��
		{
	        Trace(L_INFO, __FILE__, __LINE__, NULL, "������������[%s]", m_sMsgTp);
		}
		
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms900::InsertComsendmb()");
}	
	
void CRecvBkCcms900::CheckSign900()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms900::CheckSign900");
	
	m_ccms900.getOriSignStr();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSignBuff = [%s]", m_ccms900.m_sSignBuff.c_str());

	CheckSign(m_ccms900.m_sSignBuff.c_str(),
			m_ccms900.m_szDigitSign.c_str(),
			m_ccms900.InstgDrctPty.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms900::CheckSign900");
}
/******************************************************************************
*  Function:   PubOriRspSql
*  Description:����С�����ҵ���Ӧ��ʶ ���ݴ�������и���
*  Input:      ��
*  Output:     
*  Return:     
               
*  Others:     ��
*  Author:     zql 
*  Date:       2012-06-28
*******************************************************************************/
void CRecvBkCcms900::PubOriRspSql(LPCSTR sUpTable, LPCSTR sOriTable, LPCSTR sColNm, LPTSTR sUpSql)
{	
	//
	char temprsp[1+1]={0};
	char temp[8+1]={0};
	strcpy(temp,m_ccms900.PrcCd.c_str());
	strncpy(temprsp,temp+3,1);
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "temprsp = [%s]", temprsp);
	//
	char tempmsgtps[3+1]={0};
	char tempmsgid[35+1]={0};
	char tempinstgpty[14+1]={0};
		
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ԭ��������=[%s]" ,tempmsgtps);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "msgid = [%s] ,instgpty=[%s]", tempmsgid,tempinstgpty);
	if(0 == strcmp("388",m_sMsgTp) && (0 == strcmp(temprsp,"I") || 0 ==strcmp(temprsp,"W")))
	{
		GetOriMsgTps(tempmsgid,tempinstgpty,tempmsgtps);
		if(strcmp(tempmsgtps,"380")==0 ||strcmp(tempmsgtps,"384")==0)
		{
			sprintf(sUpSql, "UPDATE %s t SET "
	                "t.rspflag = '3' "
	                " WHERE t.MSGID= '%s' and t.INSTGDRCTPTY = '%s'",
	                sUpTable,
					tempmsgid,
	                tempinstgpty);
	    }
	   
    }
    else if(0 == strcmp("388",m_sMsgTp) && (0 == strcmp(temprsp,"O") || 0 ==strcmp(temprsp,"S")))
	{
		GetOriMsgTps(tempmsgid,tempinstgpty,tempmsgtps);
		if(strcmp(tempmsgtps,"380")==0 ||strcmp(tempmsgtps,"384")==0)
		{
			sprintf(sUpSql, "UPDATE %s t SET "
	                "t.rspflag = '2' "
	                " WHERE t.MSGID= '%s' and t.INSTGDRCTPTY = '%s'",
	                sUpTable,
					tempmsgid,
	                tempinstgpty);
	       Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sUpSql=[%s]" ,sUpSql);
	    }
    }
    else if(0 == strcmp("389",m_sMsgTp) && (0 == strcmp(temprsp,"I") || 0 ==strcmp(temprsp,"W")))
    {
		GetOriMsgTps(tempmsgid,tempinstgpty,tempmsgtps);
		if(strcmp(tempmsgtps,"381") == 0 || strcmp(tempmsgtps,"385") == 0)
		{
			sprintf(sUpSql, "UPDATE %s t SET "
	                "t.rspflag = '3' "
	                " WHERE t.MSGID= '%s' and t.INSTGDRCTPTY = '%s'",
	                sUpTable,
					tempmsgid,
	                tempinstgpty);
	         Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sUpSql=[%s]" ,sUpSql);
	    }
	    if(strcmp(tempmsgtps,"382") == 0 || strcmp(tempmsgtps,"386") == 0)
		{
			sprintf(sUpSql, "UPDATE %s t SET "
	                "t.rspflag = '6' "
	                " WHERE t.MSGID= '%s' and t.INSTGDRCTPTY = '%s'",
	                sUpTable,
					tempmsgid,
	                tempinstgpty);
	         Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sUpSql=[%s]" ,sUpSql);
	    }
	}
	else if(0 == strcmp("389",m_sMsgTp) && (0 == strcmp(temprsp,"O") || 0 ==strcmp(temprsp,"S")))
	{
		GetOriMsgTps(tempmsgid,tempinstgpty,tempmsgtps);
		if(strcmp(tempmsgtps,"381") == 0 || strcmp(tempmsgtps,"385") == 0)
		{
			sprintf(sUpSql, "UPDATE %s t SET "
	                "t.rspflag = '2' "
	                " WHERE t.MSGID= '%s' and t.INSTGDRCTPTY = '%s'",
	                sUpTable,
					tempmsgid,
	                tempinstgpty);
	         Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sUpSql=[%s]" ,sUpSql);
	    }
	    if(strcmp(tempmsgtps,"382") == 0 || strcmp(tempmsgtps,"386") == 0)
		{
			sprintf(sUpSql, "UPDATE %s t SET "
	                "t.rspflag = '5' "
	                " WHERE t.MSGID= '%s' and t.INSTGDRCTPTY = '%s'",
	                sUpTable,
					tempmsgid,
	                tempinstgpty);
	        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sUpSql=[%s]" ,sUpSql);
	    }
	}
	else if((0 == strcmp("381",m_sMsgTp) ||0 == strcmp("385",m_sMsgTp) ) 
	      && (0 == strcmp(temprsp,"I") || 0 ==strcmp(temprsp,"W")))
	{
		/*char tempmsgid[35+1]={0};
		char tempinstgpty[14+1]={0};
		char tempmsgtps[3+1]={0};*/
		GetReturnTps(tempmsgid,tempinstgpty,tempmsgtps);
		
		sprintf(sUpSql, "UPDATE %s t SET "
                    "t.rspflag = '6' "
                    " WHERE t.MSGID= '%s' and t.INSTGDRCTPTY = '%s' ", 
                    sUpTable,
					tempmsgid,
                    tempinstgpty);
         Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sUpSql=[%s]" ,sUpSql);
	}
	else if((0 == strcmp("381",m_sMsgTp) ||0 == strcmp("385",m_sMsgTp) ) 
	      && (0 == strcmp(temprsp,"O") || 0 ==strcmp(temprsp,"S")))
	{
		/*char tempmsgid[35+1]={0};
		char tempinstgpty[14+1]={0};
		char tempmsgtps[3+1]={0};
		*/
		GetReturnTps(tempmsgid,tempinstgpty,tempmsgtps);
		sprintf(sUpSql, "UPDATE %s t SET "
                    "t.rspflag = '5' "
                    " WHERE t.MSGID= '%s' and t.INSTGDRCTPTY = '%s' ", 
                    sUpTable,
					tempmsgid,
                    tempinstgpty);
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sUpSql=[%s]" ,sUpSql);
	}
	else if ( (0 == strcmp("383",m_sMsgTp) || 0 == strcmp("387",m_sMsgTp))
	         && (0 == strcmp(temprsp,"I") || 0 ==strcmp(temprsp,"W")))
	{
		/*char tempmsgid[35+1]={0};
		char tempinstgpty[14+1]={0};
		char tempmsgtps[3+1]={0};*/
		GetReturnTps(tempmsgid,tempinstgpty,tempmsgtps);
		sprintf(sUpSql, "UPDATE %s t SET "
                    "t.rspflag = '3' "
                    " WHERE t.MSGID= '%s' and t.INSTGDRCTPTY = '%s' ", 
                    sUpTable,
					tempmsgid,
                    tempinstgpty);
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sUpSql=[%s]" ,sUpSql);
	}
	else if((0 == strcmp("383",m_sMsgTp) ||0 == strcmp("387",m_sMsgTp) )
	     && (0 == strcmp(temprsp,"O") || 0 ==strcmp(temprsp,"S")))
	{
		/*char tempmsgid[35+1]={0};
		char tempinstgpty[14+1]={0};
		char tempmsgtps[3+1]={0};*/
		GetReturnTps(tempmsgid,tempinstgpty,tempmsgtps);
		sprintf(sUpSql, "UPDATE %s t SET "
                    "t.rspflag = '2' "
                    " WHERE t.MSGID= '%s' and t.INSTGDRCTPTY = '%s' ", 
                    sUpTable,
					tempmsgid,
                    tempinstgpty);
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sUpSql=[%s]" ,sUpSql);
	}
}

void CRecvBkCcms900::GetOriMsgTps(char* msgid,char* instgpty,char* orimsgtps)
{
	char temprsp[1+1]={0};
	char temp[8+1]={0};
	char orimsgtp[3+1]={0};
	
	CBpbizpubntce m_CBpbizpubntce;
	SETCTX(m_CBpbizpubntce);
	
	strcpy(temp, m_ccms900.PrcCd.c_str());
	strncpy(temprsp, temp+3, 1);
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "temprsp = [%s],prcCd=[%s]",temprsp, m_ccms900.PrcCd.c_str());
	
	char strsql[1024] = {0}; 
	sprintf(strsql," MSGID = '%s' and INSTGPTY = '%s'",m_ccms900.OrgnlMsgId.c_str(),m_ccms900.OrgnlInstgPty.c_str());
	int iRet = m_CBpbizpubntce.find(strsql);
	if(iRet != 0)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "û���ҵ���������strsql =[%s]��ԭҵ��MSGID =[%s],INSTGPTY=[%s],iRet=[%d],err=[%s]", strsql,m_ccms900.OrgnlMsgId.c_str(),m_ccms900.OrgnlInstgPty.c_str(),iRet,m_CBpbizpubntce.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
	}
	iRet = m_CBpbizpubntce.fetch();
	if(iRet ==SQLNOTFOUND)
	{
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������");
        m_CBpbizpubntce.closeCursor();
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "m_CBpbizpubntceû���ҵ�����������ԭҵ��");
	}
	memset(strsql,0x00,sizeof(strsql));
	sprintf(strsql," MSGID = '%s' and INSTGPTY = '%s'",m_CBpbizpubntce.m_orgnlmsgid.c_str(),m_CBpbizpubntce.m_orgnlinstgpty.c_str());
	CBpcolltnchrgscl m_CBpcolltnchrgscl;
	SETCTX(m_CBpcolltnchrgscl);
	iRet = m_CBpcolltnchrgscl.find(strsql);
	if(iRet != 0)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "û���ҵ�����������ԭҵ��ORGNLMSGID =[%s],ORGNLINSTGPTY=[%s]", m_CBpbizpubntce.m_orgnlmsgid.c_str(),m_CBpbizpubntce.m_orgnlinstgpty.c_str());
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
	}
	iRet = m_CBpcolltnchrgscl.fetch();
	if(iRet ==SQLNOTFOUND)
	{
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������");
        m_CBpcolltnchrgscl.closeCursor();
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "m_CBpbizpubntceû���ҵ�����������ԭҵ��");
	}
	char strmsgtp[35+1]={0};
	strcpy(strmsgtp,m_CBpcolltnchrgscl.m_msgtp.c_str());
	strncpy(orimsgtp,strmsgtp+5,3);
	strcpy(orimsgtps,orimsgtp);
	strcpy(msgid,m_CBpcolltnchrgscl.m_msgid.c_str());
	strcpy(instgpty,m_CBpcolltnchrgscl.m_instgpty.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "orimsgtp =[%s],ORGNLINSTGPTY=[%s],orimsgtps=[%s]", orimsgtp,m_CBpbizpubntce.m_orgnlinstgpty.c_str(),orimsgtps);
    m_CBpcolltnchrgscl.closeCursor();
    m_CBpbizpubntce.closeCursor();
}
	

void CRecvBkCcms900::GetReturnTps(char* msgid,char* instgpty,char* orimsgtps)
{
	char orimsgtp[3+1]={0};
	CBpcolltnchrgscl m_CBpcolltnchrgscl;
	SETCTX(m_CBpcolltnchrgscl);
	char strsql[1024] = {0}; 
	sprintf(strsql," MSGID = '%s' and INSTGPTY = '%s'",m_ccms900.OrgnlMsgId.c_str(),m_ccms900.OrgnlInstgPty.c_str());
	int iRet = m_CBpcolltnchrgscl.find(strsql);
	if(iRet != 0)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "û���ҵ�����������ԭҵ��MSGID =[%s],INSTGPTY=[%s],iRet=[%d],sqlErr=[%s]",m_ccms900.OrgnlMsgId.c_str(),m_ccms900.OrgnlInstgPty.c_str(),iRet,m_CBpcolltnchrgscl.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
	}
	iRet = m_CBpcolltnchrgscl.fetch();
	if(iRet ==SQLNOTFOUND)
	{
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������");
        m_CBpcolltnchrgscl.closeCursor();
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "m_CBpbizpubntceû���ҵ�����������ԭҵ��");
	}
	memset(strsql,0x00,sizeof(strsql));
	sprintf(strsql," MSGID = '%s' and INSTGPTY = '%s'",m_CBpcolltnchrgscl.m_orgnlmsgid.c_str(),m_CBpcolltnchrgscl.m_orgnlinstgpty.c_str());
	iRet = m_CBpcolltnchrgscl.find(strsql);
	if(iRet != 0)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "û���ҵ�����������ԭҵ��ORGNLMSGID =[%s],ORGNLINSTGPTY=[%s]", m_ccms900.OrgnlMsgId.c_str(),m_ccms900.OrgnlInstgPty.c_str());
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
	}
	iRet = m_CBpcolltnchrgscl.fetch();
	if(iRet ==SQLNOTFOUND)
	{
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������");
        m_CBpcolltnchrgscl.closeCursor();
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "m_CBpbizpubntceû���ҵ�����������ԭҵ��");
	}
	char strmsgtp[35+1]={0};
	strcpy(strmsgtp,m_CBpcolltnchrgscl.m_msgtp.c_str());
	strncpy(orimsgtp,strmsgtp+5,3);
	strcpy(orimsgtps,orimsgtp);
	strcpy(msgid,m_CBpcolltnchrgscl.m_msgid.c_str());
	strcpy(instgpty,m_CBpcolltnchrgscl.m_instgpty.c_str());
	m_CBpcolltnchrgscl.closeCursor();
	//m_CBpcolltnchrgscl.closeCursor();
}


void CRecvBkCcms900::UpdateOriState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter  CRecvBkCcms900::UpdateOriState");
	char OriSql[1024]={0};
	string tablename = "";
	string procstate = "";
	int iRet = -1;
	
	if(0 == strcmp("319" ,m_sMsgTp))
	{
		CCmpmtrtrcl   m_cmpmtrtrcl;
		CCmpmtrtrlist m_cmpmtrtrlist;
		
	    m_cmpmtrtrcl.m_sysid = m_ccms900.SysCd;//ϵͳ��ʶ�� 
		m_cmpmtrtrcl.m_msgid = m_ccms900.OrgnlMsgId; //���ı�ʶ��
		m_cmpmtrtrcl.m_instgindrctpty = m_ccms900.OrgnlInstgPty;//
		m_cmpmtrtrcl.m_rsflag="1";

		SETCTX(m_cmpmtrtrcl);

	    iRet = m_cmpmtrtrcl.findByPK();
		if(RTN_SUCCESS != iRet)
		{
		   m_cmpmtrtrcl.m_rsflag="0";
		   
		   iRet = m_cmpmtrtrcl.findByPK();
		   
		   if(RTN_SUCCESS != iRet)
		   {
    		   sprintf( m_szErrMsg,"findByPK() error,error code =[%d] error cause = [%s]",iRet,m_cmpmtrtrcl.GetSqlErr());
    		   Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_szErrMsg);
    		   PMTS_ThrowException(__FILE__,__LINE__,DB_NOT_FOUND,m_szErrMsg);
		    }	
		}
		
		if(m_cmpmtrtrcl.m_retunstat == "PR09" )
		{
		    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "319���ľܾ��˻أ�leave UpdateOriState");
		    return;
		}
		
		m_cmpmtrtrcl.m_msgid = m_cmpmtrtrcl.m_orgnlmsgid; //���ı�ʶ��
		m_cmpmtrtrcl.m_instgindrctpty = m_cmpmtrtrcl.m_orgninstgdrctpty;//
		m_cmpmtrtrcl.m_rsflag="2";

	    iRet = m_cmpmtrtrcl.findByPK();
		if(RTN_SUCCESS != iRet)
		{
    	   sprintf( m_szErrMsg,"findByPK() error,error code =[%d] error cause = [%s]",iRet,m_cmpmtrtrcl.GetSqlErr());
    	   Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_szErrMsg);
    	   PMTS_ThrowException(__FILE__,__LINE__,DB_NOT_FOUND,m_szErrMsg);
		}	
		
	
		if(m_cmpmtrtrcl.m_retunstat == "PR09")
		{
			return;
		}
		else if(m_cmpmtrtrcl.m_retunstat == "PR23")//�����˻�
		{
			if(m_ccms900.SysCd == "HVPS")
			{
				tablename = "HV_RCVEXCHGLIST";
				procstate = PR_HVBP_33;
			}
			else
			{
				tablename = "BP_BCOUTRCVCL";
				procstate = PR_HVBP_32;
				
				UpdateOriSql("BP_BCOUTRECVLIST",PR_HVBP_33,m_cmpmtrtrcl.m_orgnlmsgid.c_str(),m_cmpmtrtrcl.m_orgninstgdrctpty.c_str(),OriSql,"all");
    			iRet = ExeOriSql(OriSql);
    			if(RTN_SUCCESS != iRet)
    			{
    				UpdateOriSql("BP_BCOUTRECVLISTHIS",PR_HVBP_33,m_cmpmtrtrcl.m_orgnlmsgid.c_str(),m_cmpmtrtrcl.m_orgninstgdrctpty.c_str(),OriSql,"all");
    				iRet = ExeOriSql(OriSql);
    				if(RTN_SUCCESS != iRet)
    				{
    				    Trace(L_ERROR, __FILE__, __LINE__, NULL, "�Ҳ���ԭҵ��");
    			        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
    				}
    			}
			}	
			UpdateOriSql(tablename.c_str(),procstate.c_str(),m_cmpmtrtrcl.m_orgnlmsgid.c_str(),m_cmpmtrtrcl.m_orgninstgdrctpty.c_str(),OriSql);
			iRet = ExeOriSql(OriSql);
			if(RTN_SUCCESS != iRet)
			{
				tablename +="HIS";
				UpdateOriSql(tablename.c_str(),procstate.c_str(),m_cmpmtrtrcl.m_orgnlmsgid.c_str(),m_cmpmtrtrcl.m_orgninstgdrctpty.c_str(),OriSql);
				iRet = ExeOriSql(OriSql);
				if(RTN_SUCCESS != iRet)
				{
				    Trace(L_ERROR, __FILE__, __LINE__, NULL, "�Ҳ���ԭҵ��");
			        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
				}
			}
		}
		else if(m_cmpmtrtrcl.m_retunstat == "PR25")
		{
			tablename = "BP_BCOUTRCVCL";
			procstate = PR_HVBP_31;
			UpdateOriSql(tablename.c_str(),procstate.c_str(),m_cmpmtrtrcl.m_orgnlmsgid.c_str(),m_cmpmtrtrcl.m_orgninstgdrctpty.c_str(),OriSql);
			iRet = ExeOriSql(OriSql);
			if(RTN_SUCCESS != iRet)
			{
				tablename +="HIS";
				UpdateOriSql(tablename.c_str(),procstate.c_str(),m_cmpmtrtrcl.m_orgnlmsgid.c_str(),m_cmpmtrtrcl.m_orgninstgdrctpty.c_str(),OriSql);
				iRet = ExeOriSql(OriSql);
				if(RTN_SUCCESS != iRet)
				{
				    Trace(L_ERROR, __FILE__, __LINE__, NULL, "�Ҳ���ԭҵ��");
			        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
				}
			}

			SETCTX(m_cmpmtrtrlist);
			STRING strSql;
			strSql = "msgid";
			strSql += " = '"+ m_cmpmtrtrcl.m_msgid +"'";
			strSql += " and rsflag = '1'" ;
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql[%s].", strSql.c_str());
			
			if(SQL_SUCCESS == m_cmpmtrtrlist.find(strSql))
			{
				while(SQL_SUCCESS == m_cmpmtrtrlist.fetch())
				{			
					tablename = "BP_BCOUTRECVLIST";
					procstate = PR_HVBP_33;
					UpdateOriSql(tablename.c_str(),procstate.c_str(),m_cmpmtrtrlist.m_orgnlmsgid.c_str(),m_cmpmtrtrlist.m_orgninstgdrctpty.c_str(),OriSql,m_cmpmtrtrlist.m_orgnltxid.c_str());
					iRet = ExeOriSql(OriSql);
					if(RTN_SUCCESS != iRet)
					{
						tablename +="HIS";
						UpdateOriSql(tablename.c_str(),procstate.c_str(),m_cmpmtrtrlist.m_orgnlmsgid.c_str(),m_cmpmtrtrlist.m_orgninstgdrctpty.c_str(),OriSql,m_cmpmtrtrlist.m_orgnltxid.c_str());
						iRet = ExeOriSql(OriSql);
						if(RTN_SUCCESS != iRet)
						{
						    Trace(L_ERROR, __FILE__, __LINE__, NULL, "�Ҳ���ԭҵ��");
			                PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
						}
					}
				}
				m_cmpmtrtrlist.closeCursor();
			}
		}	
	}	
	else if(0 == strcmp("412" ,m_sMsgTp))	
	{
	    CBpcstbdpcxlcl		m_cBpcstbdpcxlcl;
    	CBpcstbdpcxllist	m_cBpcstbdpcxllist;
    	
    	m_cBpcstbdpcxlcl.m_instgpty = m_ccms900.OrgnlInstgPty;
      	m_cBpcstbdpcxlcl.m_msgid    = m_ccms900.OrgnlMsgId;
        m_cBpcstbdpcxlcl.m_rsflag   = "1";
        
        SETCTX(m_cBpcstbdpcxlcl);
        iRet = m_cBpcstbdpcxlcl.findByPK();
    
      	if (SQL_SUCCESS != iRet) 
	    {
	        m_cBpcstbdpcxlcl.m_rsflag   = "0";
	        iRet = m_cBpcstbdpcxlcl.findByPK();
	        if (SQL_SUCCESS != iRet) 
	        {
        		sprintf(m_szErrMsg, "��ѯ���ҵ��ֹ�����ܱ���������[%s], [%s], [%d][%s]",
        		    m_cBpcstbdpcxlcl.m_instgpty.c_str(), m_cBpcstbdpcxlcl.m_msgid.c_str(), iRet, m_cBpcstbdpcxlcl.GetSqlErr());
        		
        		Trace(L_ERROR,  __FILE__,  __LINE__, m_cBpcstbdpcxlcl.m_msgid.c_str(), m_szErrMsg);
        		
        		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_szErrMsg);
            }
    	}
    	
    	if(m_cBpcstbdpcxlcl.m_stoppmtsts == "SS02")
    	{
    	    return;
    	}
    	else if(m_cBpcstbdpcxlcl.m_stoppmtsts == "SS00")
    	{
    	    tablename = "BP_BDRCVCL";
			procstate = PR_HVBP_26;
    	    
    	    UpdateOriSql(tablename.c_str(),procstate.c_str(),m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(),m_cBpcstbdpcxlcl.m_orgnlinstgpty.c_str(),OriSql);
			iRet = ExeOriSql(OriSql);
			if(RTN_SUCCESS != iRet)
			{
				tablename +="HIS";
				UpdateOriSql(tablename.c_str(),procstate.c_str(),m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(),m_cBpcstbdpcxlcl.m_orgnlinstgpty.c_str(),OriSql);
				iRet = ExeOriSql(OriSql);
				if(RTN_SUCCESS != iRet)
				{
				    Trace(L_ERROR, __FILE__, __LINE__, NULL, "�Ҳ���ԭҵ��");
			        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
				}
			}
			
			tablename ="BP_BDRECVLIST";
			procstate = PR_HVBP_25;
    	    UpdateOriSql(tablename.c_str(),procstate.c_str(),m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(),m_cBpcstbdpcxlcl.m_orgnlinstgpty.c_str(),OriSql,"all");
			iRet = ExeOriSql(OriSql);
			if(RTN_SUCCESS != iRet)
			{
				tablename +="HIS";
				UpdateOriSql(tablename.c_str(),procstate.c_str(),m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(),m_cBpcstbdpcxlcl.m_orgnlinstgpty.c_str(),OriSql,"all");
				iRet = ExeOriSql(OriSql);
				if(RTN_SUCCESS != iRet)
				{
				    Trace(L_ERROR, __FILE__, __LINE__, NULL, "�Ҳ���ԭҵ��");
			        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
				}
			}	
    	}
    	else if(m_cBpcstbdpcxlcl.m_stoppmtsts=="SS01")
    	{
    		//����ֹ�������»��ܱ�
    	    /*tablename = "BP_BDRCVCL";
			procstate = PR_HVBP_27;
    	    
    	    UpdateOriSql(tablename.c_str(), procstate.c_str(),
    	    		m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(), m_cBpcstbdpcxlcl.m_orgnlinstgpty.c_str(),OriSql);
			iRet = ExeOriSql(OriSql);
			if(RTN_SUCCESS != iRet)
			{
				tablename +="HIS";
				UpdateOriSql(tablename.c_str(), procstate.c_str(),
						m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(), m_cBpcstbdpcxlcl.m_orgnlinstgpty.c_str(),OriSql);
				iRet = ExeOriSql(OriSql);
				if(RTN_SUCCESS != iRet)
				{
				    Trace(L_ERROR, __FILE__, __LINE__, NULL, "�Ҳ���ԭҵ��");
			        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
				}
			}*/
			
        	SETCTX(m_cBpcstbdpcxllist);
        	STRING strSql;
            strSql =  " instgpty = '";
            strSql += m_cBpcstbdpcxlcl.m_instgpty;
            strSql += "' and msgid = '";
            strSql += m_cBpcstbdpcxlcl.m_msgid;
            strSql += "' and orgnlmsgid = '";
            strSql += m_cBpcstbdpcxlcl.m_orgnlmsgid;
            strSql += "' and rsflag = '1' ";
            Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql=%s", strSql.c_str());
            
            tablename ="BP_BDRECVLIST";
			procstate = PR_HVBP_25;
            
            if(SQL_SUCCESS == m_cBpcstbdpcxllist.find(strSql))
			{
				while(SQL_SUCCESS == m_cBpcstbdpcxllist.fetch())
				{	
				    UpdateOriSql(tablename.c_str(),procstate.c_str(),m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(),m_cBpcstbdpcxlcl.m_orgnlinstgpty.c_str(),OriSql,m_cBpcstbdpcxllist.m_orgnlpmtinfid.c_str());
        			iRet = ExeOriSql(OriSql);
        			if(RTN_SUCCESS != iRet)
        			{
        				tablename +="HIS";
        				UpdateOriSql(tablename.c_str(),procstate.c_str(),m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(),m_cBpcstbdpcxlcl.m_orgnlinstgpty.c_str(),OriSql,m_cBpcstbdpcxllist.m_orgnlpmtinfid.c_str());
        				iRet = ExeOriSql(OriSql);
        				if(RTN_SUCCESS != iRet)
        				{
        				    Trace(L_ERROR, __FILE__, __LINE__, NULL, "�Ҳ���ԭҵ��");
        			        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
        				}
        			}	
			    }
			    m_cBpcstbdpcxllist.closeCursor();
			}
    	}
	}	
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving  CRecvBkCcms900::UpdateOriState");
}

void CRecvBkCcms900::UpdateOriSql(LPCSTR sTableNm, LPCSTR sProcstate, LPCSTR sMsgid, LPCSTR sInstgdrctpty, LPTSTR m_sSqlStr, LPCSTR other )
{
	 Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvBkCcms900::UpdateOriSql");
	 
	 memset(m_sSqlStr,0x00,1024);
	 
	 if ( 0 == strcmp(sTableNm, "HV_RCVEXCHGLIST") 
	 	  || 0 == strcmp(sTableNm, "HV_RCVEXCHGLISTHIS") )    
     {
        sprintf(m_sSqlStr,  " UPDATE %s t SET"
							" t.procstate = '%s'"
 							" WHERE t.MSGID = '%s'"
							" AND t.INSTGINDRCTPTY = '%s' ",
							sTableNm,
							sProcstate,
							sMsgid,
							sInstgdrctpty);
        
     }
     if ( 0 == strcmp(sTableNm, "BP_BCOUTRCVCL")|| 0 == strcmp(sTableNm, "BP_BCOUTRCVCLHIS") ||
          0 == strcmp(sTableNm, "BP_BDRCVCL") || 0 == strcmp(sTableNm, "BP_BDRCVCLHIS") )    
     {
        sprintf(m_sSqlStr,  " UPDATE %s t SET"
							" t.procstate = '%s'"
 							" WHERE t.MSGID = '%s'"
							" AND t.INSTGDRCTPTY = '%s' ",
							sTableNm,
							sProcstate,
							sMsgid,
							sInstgdrctpty);
        
     }
	 if ( 0 == strcmp(sTableNm, "BP_BCOUTRECVLIST") || 0 == strcmp(sTableNm, "BP_BCOUTRECVLISTHIS") )
	 {
	    //all��ʾ�����˻�
	    if(0 == strcmp(other, "all") )
	    {
	          sprintf(m_sSqlStr,  " UPDATE %s t SET"
    							" t.procstate = '%s'"
     							" WHERE t.MSGID = '%s'"
    							" AND t.DBTRBRNCHID = '%s' ",
    							sTableNm,
    							sProcstate,
    							sMsgid,
    							sInstgdrctpty);
	    }
	    else
	    {
    	 	 sprintf(m_sSqlStr,  " UPDATE %s t SET"
    							" t.procstate = '%s'"
     							" WHERE t.MSGID = '%s'"
    							" AND t.DBTRBRNCHID = '%s' "
    							" AND t.TXID= '%s'",
    							sTableNm,
    							sProcstate,
    							sMsgid,
    							sInstgdrctpty,
    							other);
		}
	 }	
	 if ( 0 == strcmp(sTableNm, "BP_BDRECVLIST") || 0 == strcmp(sTableNm, "BP_BDRECVLISTHIS") )
	 {
	    //all��ʾ�����˻�
	    if(0 == strcmp(other, "all") )
	    {
	          sprintf(m_sSqlStr,  " UPDATE %s t SET"
    							" t.procstate = '%s'"
     							" WHERE t.MSGID = '%s'"
    							" AND t.INSTGDRCTPTY = '%s' ",    //�����������Ǽ�η��𣬶�ֹ��ҵ����ֱ�η���ʱ����������ϸ�����Ҳ���ԭҵ��,�޸Ĳ����������к�Ϊ����ֱ�Ӳ�����
    							sTableNm,
    							sProcstate,
    							sMsgid,
    							sInstgdrctpty);
	    }
	    else
	    {
    	 	 sprintf(m_sSqlStr,  " UPDATE %s t SET"
    							" t.procstate = '%s'"
     							" WHERE t.MSGID = '%s'"
    							" AND t.INSTGDRCTPTY = '%s' "    //�����������Ǽ�η��𣬶�ֹ��ҵ����ֱ�η���ʱ����������ϸ�����Ҳ���ԭҵ��,�޸Ĳ����������к�Ϊ����ֱ�Ӳ�����
    							" AND t.TXID= '%s'",
    							sTableNm,
    							sProcstate,
    							sMsgid,
    							sInstgdrctpty,
    							other);	        
	    }
	 }
	 Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving  CRecvBkCcms900::UpdateOriSql");
}

INT32 CRecvBkCcms900::ExeOriSql(LPCSTR m_sSqlStr)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvBkCcms900::ExeOriSql");
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSqlStr	 = [%s]", m_sSqlStr);

	SETCTX(m_entitybase);

    int iRet = -1;

	if (NULL != m_sSqlStr && '\0' != m_sSqlStr && 0 < strlen(m_sSqlStr) )
	{
		iRet = m_entitybase.execsql(m_sSqlStr);
		if (iRet == SQLNOTFOUND)
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL,"����ʱδ�ҵ�����[%s][%s]", 
				m_sMsgTp, m_ccms900.OrgnlMsgId.c_str());
			return RTN_FAIL;
		}
		else if (iRet != SQL_SUCCESS)
		{
			sprintf(m_szErrMsg,  "����ԭҵ��ʧ��[%d][%s][%s]", 
				iRet, m_sMsgTp, m_entitybase.GetSqlErr());
				
			Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
		}
	}
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving  CRecvBkCcms900::ExeOriSql");
	return RTN_SUCCESS;
}
//����ԭҵ��״̬
void CRecvBkCcms900::UpdateOriStateSap()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "CRecvBkCcms900::UpdateOriStateSap....");
	CBpbcoutsendlist m_bpbcountsendlist;
	SETCTX(m_bpbcountsendlist);
	SETCTX(m_entitybase);
	int iRet = -1;
	char updateStr[200]={0};
	char updateOriStr[1024]={0};
	char updateOriSrtList[1024]={0};
	char OriMsgid[35+1]={0};
	sprintf(updateStr," MSGID='%s' ",m_ccms900.OrgnlMsgId.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_ccms900.OrgnlMsgId.c_str()=[%s]",m_ccms900.OrgnlMsgId.c_str());
	
	iRet = m_bpbcountsendlist.find(updateStr);
	if(iRet != 0)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "û���ҵ�����������ԭҵ��MSGID =[%s]",m_ccms900.OrgnlMsgId.c_str());
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
	}
	iRet = m_bpbcountsendlist.fetch();
	if(iRet ==SQLNOTFOUND)
	{
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������iRet=[%d]",iRet);
	    //m_bpbcountsendlist.closeCursor();
	    PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "m_bpbcountsendlistû���ҵ�����������ԭҵ��");
	}
	strcpy(OriMsgid,m_bpbcountsendlist.m_orgnlmsgid.c_str());
	
	sprintf(updateOriStr, "UPDATE BP_BDRCVCL t SET"
						  " t.PROCSTATE = '07',t.BUSISTATE='PR05' "
						  " WHERE t.MSGID = '%s' and t.INSTGDRCTPTY ='%s' ",
						   OriMsgid,
						   m_bpbcountsendlist.m_oriinstgdrctpty.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "updateOriStr=[%s",updateOriStr);
	iRet = m_entitybase.execsql(updateOriStr);
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL,"����ʱδ�ҵ�����[%s][%s]", 
		    m_sMsgTp, m_ccms900.OrgnlMsgId.c_str());
	}
	else if (iRet != SQL_SUCCESS)
	{
		sprintf(m_szErrMsg,  "����ԭҵ��ʧ��[%d][%s][%s]", 
		    iRet, m_sMsgTp, m_entitybase.GetSqlErr());
		    
		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}
	sprintf(updateOriSrtList, "UPDATE BP_BDRECVLIST t SET"
						  " t.PROCSTATE = '07',t.BUSISTATE='PR05' "
						  " WHERE t.MSGID = '%s' and t.CDTRBRNCHID='%s' ",
						   OriMsgid,
						   m_bpbcountsendlist.m_oriinstgpty.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "updateOriSrtList=[%s]",updateOriSrtList);
	iRet = m_entitybase.execsql(updateOriSrtList);
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL,"����ʱδ�ҵ�����[%s][%s]", 
		    m_sMsgTp, m_ccms900.OrgnlMsgId.c_str());
	}
	else if (iRet != SQL_SUCCESS)
	{
		sprintf(m_szErrMsg,  "����ԭҵ��ʧ��[%d][%s][%s]", 
		    iRet, m_sMsgTp, m_entitybase.GetSqlErr());
		    
		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}
	m_bpbcountsendlist.closeCursor();
}

void CRecvBkCcms900::Updatebp_bcoutrcvcl_list()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "CRecvBkCcms900::Updatebp_bcoutrcvcl_list....");
	CBpbdsendlist m_CBpbdsendlist;
	SETCTX(m_CBpbdsendlist);
	SETCTX(m_entitybase);
	int iRet = -1;
	char updateStr[200]={0};
	char updateOriStr[1024]={0};
	char updateOriSrtList[1024]={0};
	char OriMsgid[35+1]={0};
	sprintf(updateStr," MSGID='%s' ",m_ccms900.OrgnlMsgId.c_str());
	
	
	iRet = m_CBpbdsendlist.find(updateStr);
	if(iRet != 0)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "û���ҵ�����������ԭҵ��MSGID =[%s]",m_ccms900.OrgnlMsgId.c_str());
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "û���ҵ�����������ԭҵ��");
	}
	iRet = m_CBpbdsendlist.fetch();
	if(iRet ==SQLNOTFOUND)
	{
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������");
	    //m_CBpbdsendlist.closeCursor();
	    PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "m_CBpbdsendlistû���ҵ�����������ԭҵ��");
	}
	
	strcpy(OriMsgid,m_CBpbdsendlist.m_orgnlmsgid.c_str());
	
	sprintf(updateOriStr, "UPDATE BP_BCOUTRCVCL t SET"
						  " t.PROCSTATE = '07',t.BUSISTATE='PR05' "
						  " WHERE t.MSGID = '%s' and t.INSTGDRCTPTY='%s' " ,
						   OriMsgid,
						   m_CBpbdsendlist.m_oriinstgpty.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "updateOriStr=[%s]",updateOriStr);
	iRet = m_entitybase.execsql(updateOriStr);
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL,"����ʱδ�ҵ�����[%s][%s]", 
		    m_sMsgTp, m_ccms900.OrgnlMsgId.c_str());
	}
	else if (iRet != SQL_SUCCESS)
	{
		sprintf(m_szErrMsg,  "����ԭҵ��ʧ��[%d][%s][%s]", 
		    iRet, m_sMsgTp, m_entitybase.GetSqlErr());
		    
		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}
	sprintf(updateOriSrtList, "UPDATE BP_BCOUTRECVLIST t SET"
						  " t.PROCSTATE = '07',t.BUSISTATE='PR05' "
						  " WHERE t.MSGID = '%s' and t.DBTRBRNCHID='%s' and t.TXID='%s' ",
						   OriMsgid,
						   m_CBpbdsendlist.m_oriinstgpty.c_str(),
						   m_CBpbdsendlist.m_oritxid.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "updateOriSrtList=[%s]",updateOriSrtList);
	iRet = m_entitybase.execsql(updateOriSrtList);
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL,"����ʱδ�ҵ�����[%s][%s]", 
		    m_sMsgTp, m_ccms900.OrgnlMsgId.c_str());
	}
	else if (iRet != SQL_SUCCESS)
	{
		sprintf(m_szErrMsg,  "����ԭҵ��ʧ��[%d][%s][%s]", 
		    iRet, m_sMsgTp, m_entitybase.GetSqlErr());
		    
		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}
	m_CBpbdsendlist.closeCursor();
}
