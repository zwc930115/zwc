/******************************************************************** 
�ļ����� recvccms991.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-04-28
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkccms991.h"

using namespace ZFPT;

CRecvBkccms991::CRecvBkccms991()
{
    m_strMsgTp	  = "ccms991";
}


CRecvBkccms991::~CRecvBkccms991()
{
	
}

INT32 CRecvBkccms991::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkccms991::Work()");	

	// do nothing
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkccms991::work()");

	return RTN_SUCCESS;
}

