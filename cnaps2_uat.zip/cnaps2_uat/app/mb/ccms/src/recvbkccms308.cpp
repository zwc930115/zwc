/******************************************************************** 
�ļ����� recvccms308.cpp
�����ˣ� hq
��  �ڣ� 2011-03-29
�޸��ˣ� 
��  �ڣ� 
��  ���� ҵ����Ӧ����<ccms.308.001.02>
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkccms308.h"

using namespace ZFPT;
CRecvBkCcms308::CRecvBkCcms308()
{
    m_strMsgTp	  = "ccms.308.001.02";
    m_strSysCd    = "";
    m_strProcCode = "";
    m_strRjctInf  = "";
    memset(m_szOldMsgNo,0,sizeof(m_szOldMsgNo));
    memset(m_szSapbankinfo,0,sizeof(m_szSapbankinfo));
}


CRecvBkCcms308::~CRecvBkCcms308()
{
	
}

INT32 CRecvBkCcms308::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms308::Work()");	
	
	// ��������
	unPack(sMsg);
	
	//��ǩ
	CheckSign308();
	
	// ����ҵ������Ϣ��CM_TRANSREPEAL
	InsertDb(sMsg);
	
	//��ѯԭҵ��
	QryOldTrade();
	
	// �޸�ԭ��������ҵ��״̬
	UpdateData();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms308::work()");
	
	return RTN_SUCCESS;
}

INT32 CRecvBkCcms308::unPack(LPCSTR sMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms308::unPack");	

    int iRet = RTN_FAIL;

    // �����Ƿ�Ϊ��
    if (NULL == sMsg || '\0' == sMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }

    // ��������
    iRet = m_ccms308.ParseXml(sMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������,iRet[%d]", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
    }

    ZFPTLOG.SetLogInfo("308", m_ccms308.MsgId.c_str());
    
    // ���ı�ʶ�š�ϵͳ���
    m_strMsgID	  = m_ccms308.MsgId;
    m_strSysCd    = m_ccms308.m_PMTSHeader.getOrigSenderSID();
    m_strProcCode = m_ccms308.GetAddtlInf(0,"/G01/"); //ҵ������
    m_strRjctInf  = m_ccms308.GetAddtlInf(1,"/H08/"); //NPCҵ������Ϣ 
    

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strProcCode=[%s]", m_strProcCode.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strRjctInf=[%s]", m_strRjctInf.c_str());

	/*
    // ��ȡ��������

	GetSapBank(m_dbproc, m_ccms308.InstdAgtId.c_str(), m_szSapbankinfo);

	int iSysID = (strstr(m_strSysCd.c_str(), "BEPS") != NULL) ? SYS_BEPS : SYS_HVPS;
	iRet = GetWorkDate(m_dbproc, m_sWorkDate, iSysID, m_szSapbankinfo);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    */
    m_strWorkDate = m_sWorkDate;      

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms308::unPack");	

    return RTN_SUCCESS;
}

void CRecvBkCcms308::CheckSign308()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms308::CheckSign308");
	
	m_ccms308.getOriSignStr();
	
	CheckSign(m_ccms308.m_sSignBuff.c_str(),
						m_ccms308.m_szDigitSign.c_str(),
						m_ccms308.InstgAgtId.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms308::CheckSign308");
}

INT32 CRecvBkCcms308::InsertDb(LPCSTR pchMsg)
{    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms308::InsertDb");	
	
	// ��ֵ
	m_CmTrRepeal.m_sysid			= m_strSysCd;                            //ϵͳ��ʶ��
	m_CmTrRepeal.m_msgid			= m_ccms308.MsgId;                       //���ı�ʶ��
	m_CmTrRepeal.m_instgindrctpty	= m_ccms308.InstgAgtId;	                 //�����������к�
	m_CmTrRepeal.m_instgdrctpty	    = m_ccms308.InstgAgtId;	                 //����ֱ�Ӳ�������к�
	m_CmTrRepeal.m_wrkdate          = m_strWorkDate;                         //��������
	m_CmTrRepeal.m_consigndate	    = m_ccms308.MsgId.substr(0, 8);                         //ί������
	m_CmTrRepeal.m_mesgid		    = m_ccms308.m_PMTSHeader.getMesgID();	 //ͨ�ż���ʶ��
	m_CmTrRepeal.m_mesgrefid	    = m_ccms308.m_PMTSHeader.getMesgRefID(); //ͨ�ż��ο���
	m_CmTrRepeal.m_msgtp			= m_strMsgTp;                            //��������
	m_CmTrRepeal.m_instdindrctpty   = m_ccms308.InstdAgtId;                  //���ղ�������к�
	m_CmTrRepeal.m_instddrctpty     = m_szSapbankinfo;                       //����ֱ�Ӳ�������к�
	m_CmTrRepeal.m_orgnlmsgid       = m_ccms308.OrgnlMsgId;                  //ԭ���ı�ʶ��
	m_CmTrRepeal.m_orgnlmsgtp       = m_ccms308.OrgnlMsgNmId;                //ԭ��������
	m_CmTrRepeal.m_orgnltxtpcd      = "";			                         //ԭҵ�����ͱ���
	m_CmTrRepeal.m_rmkinf           = m_strRjctInf;                          //��ע
	m_CmTrRepeal.m_rspflag			= "1";                                   //Ӧ���־:0-δ��Ӧ,1-�ѻ�Ӧ
	m_CmTrRepeal.m_npcmsg			= "";                                //NPC����
	m_CmTrRepeal.m_mbmsg			= "";                                    //MB����
	m_CmTrRepeal.m_stsid            = m_ccms308.StsId;                       //��������״̬
	m_CmTrRepeal.m_orgnlcanclemsgid = m_ccms308.OrgnlMsgId;                  //ԭ�������ı�ʶ��
	m_CmTrRepeal.m_clrsysref        = m_ccms308.ClrSysRef;                   //��������
	m_CmTrRepeal.m_procstate		= "01";                                  //����״̬:01:������
	m_CmTrRepeal.m_busistate		= m_ccms308.StsId;	                     //ҵ��״̬
	m_CmTrRepeal.m_processcode		= m_strProcCode;                         //ҵ������
	m_CmTrRepeal.m_rjctinf			= m_strRjctInf;	                         //ҵ��ܾ���Ϣ
	m_CmTrRepeal.m_orgnlinstrid     = m_ccms308.OrgnlInstrId;	             //������ҵ���ı�ʶ��
	
	// ��������
	SETCTX(m_CmTrRepeal);

	// �������ݿ�
	int iRet = m_CmTrRepeal.insert();
	if (0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����CM_TRANSREPEAL��ʧ��[%d][%s]",
		    iRet, m_CmTrRepeal.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "����CM_TRANSREPEAL��ʧ��");
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms308::InsertDb");	

    return RTN_SUCCESS;
}
	
void CRecvBkCcms308::QryOldTrade()//��ѯԭҵ��
{
	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "entering CRecvBkCcms308::QryOldTrade()");
	
	m_OldCmTrRepeal.m_msgid          = m_ccms308.OrgnlMsgId;
	m_OldCmTrRepeal.m_instgindrctpty = m_ccms308.InstdAgtId;
	m_OldCmTrRepeal.m_sysid          = m_ccms308.m_PMTSHeader.getOrigSenderSID();
	
	SETCTX(m_OldCmTrRepeal);
	int iRet = m_OldCmTrRepeal.findByPK();   
	if (OPERACT_SUCCESS != iRet){
		sprintf(m_szErrMsg,"findByPK error ,error code = [%d],error cause = [%s]",
				iRet,m_OldCmTrRepeal.GetSqlErr());

		Trace(L_INFO,  __FILE__,  __LINE__,NULL, m_szErrMsg);       
		PMTS_ThrowException(__FILE__, __LINE__, DB_FIND_BY_PK_FAIL, m_szErrMsg);
	} 

	if(NULL != strstr(m_OldCmTrRepeal.m_orgnlmsgtp.c_str(),"CMT")
			|| NULL != strstr(m_OldCmTrRepeal.m_orgnlmsgtp.c_str(),"PKG") ){
	    memcpy(m_szOldMsgNo, m_OldCmTrRepeal.m_orgnlmsgtp.c_str(), 6);
	}
	else{
	    memcpy(m_szOldMsgNo, m_OldCmTrRepeal.m_orgnlmsgtp.c_str() + 5, 3);
    }

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "ԭ��������������[%s]", m_szOldMsgNo);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leave CRecvBkCcms308::QryOldTrade()");

}

void CRecvBkCcms308::UpdateData(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms308::UpdateData()");


    int iRet = RTN_FAIL;
    char szProcsts[2+1] = {0};
    if(NULL != strstr(m_ccms308.StsId.c_str(),PROCESS_PR07))//�����ɹ�
    { 
      strncpy(szProcsts,PR_HVBP_18,sizeof(szProcsts)-1);
    }
    /*    //����ʧ�ܲ����޸�ԭҵ��״̬
    else if(NULL != strstr(m_ccms308.StsId.c_str(),PROCESS_PR09))//����ʧ��
    {
      strncpy(szProcsts,PR_HVBP_24,sizeof(szProcsts)-1);
    } 
    else if(NULL != strstr(m_ccms308.StsId.c_str(),PROCESS_PR24))//npcδ����
    {
      strncpy(szProcsts,PR_HVBP_14,sizeof(szProcsts)-1);
    }
    else
    {
      Trace(L_ERROR, __FILE__, __LINE__, NULL,"δ֪�ĳ�������״̬��%s��",m_ccms308.StsId.c_str());
      strncpy(szProcsts,m_ccms308.StsId.c_str(),sizeof(szProcsts)-1);
    }
    */
    string strSql = "";

    //����ԭ������ҵ���
    strSql = "MSGID = '";
    strSql += m_OldCmTrRepeal.m_msgid+ "' and ";
    strSql += "INSTGINDRCTPTY = '";
    strSql += m_OldCmTrRepeal.m_instgindrctpty + "' and SYSID = '";
    strSql += m_OldCmTrRepeal.m_sysid + "'";
    
    UpdateOriTrade("CM_TRANSREPEAL","1","rspflag",strSql.c_str());
    
    string pSet = ", BUSISTATE = 'PR08', finalstatedate='";
    pSet += m_ccms308.ClrSysRef;
    pSet += "' ";
	string addhvwhere = " AND PROCSTATE = '16'";//�����Ҫ��������ԭҵ��״̬Ϊ�����Ŷ�
	string addbpwhere = " AND PROCSTATE = '16'";//С����Ҫ��������ԭҵ��״̬Ϊ�����Ŷ�

    //�������ɹ����޸�ԭҵ��״̬
    if(0==strcmp(szProcsts,PR_HVBP_18))
    {
        if(  0 == strcmp("111" ,m_szOldMsgNo) || 0 == strcmp("112" ,m_szOldMsgNo) 
             || 0 == strcmp("CMT100", m_szOldMsgNo) || 0 == strcmp("CMT101", m_szOldMsgNo)
             || 0 == strcmp("CMT102", m_szOldMsgNo) || 0 == strcmp("CMT103", m_szOldMsgNo)
             || 0 == strcmp("CMT105", m_szOldMsgNo) || 0 == strcmp("CMT108", m_szOldMsgNo)
             || 0 == strcmp("CMT121", m_szOldMsgNo) || 0 == strcmp("CMT122", m_szOldMsgNo)
             || 0 == strcmp("CMT123", m_szOldMsgNo) || 0 == strcmp("CMT124", m_szOldMsgNo) )
            //���´��ҵ��
        {
            
            //���´�����˻����ϸ��        
            strSql = "MSGID = '";
            strSql += m_OldCmTrRepeal.m_orgnlmsgid + "' and ";
            strSql += "INSTGINDRCTPTY = '";
            strSql += m_OldCmTrRepeal.m_instgindrctpty + "'";
            strSql += addhvwhere;
            
            UpdateOriTrade("HV_SNDEXCHGLIST",szProcsts,"PROCSTATE",strSql.c_str(), pSet.c_str());
            
        }
        else if( 0 == strcmp("141" ,m_szOldMsgNo) && (0==strcmp(szProcsts,PR_HVBP_18)) )
        {
            //���´�����˼�ʱת�˱�       
            strSql = "MSGID = '";
            strSql += m_OldCmTrRepeal.m_orgnlmsgid + "' and ";
            strSql += "INSTGINDRCTPTY = '";
            strSql += m_OldCmTrRepeal.m_instgindrctpty + "'";
            strSql += addhvwhere;
            
            UpdateOriTrade("HV_TROFACSNDLIST",szProcsts,"PROCSTATE",strSql.c_str(), pSet.c_str());
        }
        else if( (0 == strcmp("121" ,m_szOldMsgNo) || 0 == strcmp("122" ,m_szOldMsgNo)||
                  0 == strcmp("123" ,m_szOldMsgNo) || 0 == strcmp("125" ,m_szOldMsgNo))
                   || 0 == strcmp("132",    m_szOldMsgNo) || 0 == strcmp("134",    m_szOldMsgNo)
                   || 0 == strcmp("PKG001", m_szOldMsgNo) || 0 == strcmp("PKG003", m_szOldMsgNo) 
                   || 0 == strcmp("PKG005", m_szOldMsgNo) || 0 == strcmp("PKG007", m_szOldMsgNo) 
                   || 0 == strcmp("PKG008", m_szOldMsgNo) || 0 == strcmp("PKG010", m_szOldMsgNo) 
                   || 0 == strcmp("PKG011", m_szOldMsgNo) )
        {
            
            //����С����ǻ��ܱ�    
            strSql = "MSGID = '";
            strSql += m_OldCmTrRepeal.m_orgnlmsgid + "' and ";
            strSql += "INSTGDRCTPTY = '";
            strSql += m_OldCmTrRepeal.m_instgdrctpty + "'";
            strSql += addbpwhere;
            
            UpdateOriTrade("BP_BCOUTSNDCL",szProcsts,"PROCSTATE",strSql.c_str(), pSet.c_str());
             
         
            //����С�������ϸ��    
            strSql = "MSGID = '";
            strSql += m_OldCmTrRepeal.m_orgnlmsgid + "' and ";
            strSql += "INSTGDRCTPTY = '";
            strSql += m_OldCmTrRepeal.m_instgdrctpty + "'";
            strSql += addbpwhere;
    
            UpdateOriTrade("BP_BCOUTSENDLIST",szProcsts,"PROCSTATE",strSql.c_str(), pSet.c_str());
           
        }
        else
        {
            Trace(L_ERROR, __FILE__, __LINE__, NULL, "��֧�ֵı�������[%s],�޷�����ԭҵ��!", m_szOldMsgNo);
            PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "��֧�ֵı�������,�޷�����ԭҵ��!");            
        }       
    }
          
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms308::UpdateData()");

}
    
void CRecvBkCcms308::UpdateOriTrade(LPCSTR pTableNm , LPCSTR  pProcState ,LPCSTR pField,LPCSTR pWhere,LPCSTR pSet)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms308::UpdateOriTrade()");

    int iRet = RTN_FAIL;
    
    string strSql = "";

    strSql = "update ";
    strSql += pTableNm ;
    strSql += " set ";
    strSql += pField;
    strSql += " = '";
    strSql += pProcState;
    strSql += "' ";
    strSql += pSet;
    strSql += " where ";
    strSql += pWhere;

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSql = [%s]",strSql.c_str());
    
    SETCTX(m_CmTrRepeal);    
    iRet = m_CmTrRepeal.execsql(strSql);
    if (iRet == SQLNOTFOUND)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL,"����ʱδ�ҵ�����[%s]", strSql.c_str());
    }
    else if (iRet != SQL_SUCCESS)
    {
        sprintf(m_szErrMsg,  "����ԭҵ��ʧ��[%d][%s]", 
            iRet,  m_CmTrRepeal.GetSqlErr());          
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
    }
   
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms308::UpdateOriTrade()");

}
