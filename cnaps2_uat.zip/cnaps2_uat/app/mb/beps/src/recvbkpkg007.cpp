/******************************************************************** 
�ļ����� recvpkg007.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-04-15
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkpkg007.h"

using namespace ZFPT;

CRecvBkPkg007::CRecvBkPkg007()
{
    m_strMsgTp = "PKG007";
}

CRecvBkPkg007::~CRecvBkPkg007()
{

}

INT32 CRecvBkPkg007::Work(LPCSTR szMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkPkg007::Work()");

	// ��������
	unPack(szMsg);
    
    AddMac();
    
    //���ʻ�ִ���Ǳ���
    //�����ʴ�����ϸ��
    InsertBCsendList(szMsg);

    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkPkg007::Work()");
	return OPERACT_SUCCESS;
}

void CRecvBkPkg007::InsertBCsendList(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkPkg007::InsertBCsendList()");

    //��ϸ����������
    SETCTX(m_Bpbcoutrecvlist);
    
    //__wsh 2013-01-14 ���Ϊ�������������ı���Ϊ�������ģ���ҵ��״̬Ϊ05������, ����Ϊ03�����
	string strBusistate = "";
	char szSapsdate[32] = {0};
	if (strlen(m_pkg007.stHead001.szSapsDate)>=8){
		chgToISODate(m_pkg007.stHead001.szSapsDate, szSapsdate);
	}

	char szProcSts[8] = {0};
	strcpy(szProcSts,"08");

    char szCcy[3+1]={0};
    strncpy(szCcy, m_pkg007.stHead001.szDetailAmt, sizeof(szCcy)-1);
    
    CBpbcoutrecvlist orgnbcoutlist;
    SETCTX(orgnbcoutlist);
    	
    string strTmp;
    int iNum = atoi(m_pkg007.stHead001.szDetailCnt);
    for(int i = 0; i < iNum; i++)
    {
    	m_pkg007.ParseBusinessData(i);
    	
    	
        //��������
        m_Bpbcoutrecvlist.m_workdate   = m_strWorkDate;
        //ί������
        m_Bpbcoutrecvlist.m_consigdate = m_pkg007.stBody002.szConsignDate; 
        //��Ϣ����
        m_Bpbcoutrecvlist.m_msgtp = m_strMsgTp; 
        //���ı�ʶ
        m_Bpbcoutrecvlist.m_msgid = m_strMsgID;
        //���������� 
        m_Bpbcoutrecvlist.m_instgdrctpty = m_pkg007.stHead001.szOdfiCode  ; 
        //���ղ������
        m_Bpbcoutrecvlist.m_instddrctpty = m_pkg007.stHead001.szRdfiCode  ;

        //��ϸ��ʶ
        strTmp = "";
        strTmp = strTmp + m_pkg007.stBody002.szConsignDate + m_pkg007.stBody002.szTxssNo;        
        m_Bpbcoutrecvlist.m_txid = strTmp ; 

        
                   
        //�����Ϣ
        m_Bpbcoutrecvlist.m_dbtracctid  = m_pkg007.stBody002.szOriRecipientAcc  ; 
        m_Bpbcoutrecvlist.m_dbtrissr    = m_pkg007.stBody002.szOriRecOpenAccBkCode  ; 
        m_Bpbcoutrecvlist.m_dbtrbrnchid = m_pkg007.stBody002.szOdfiCode;
        //m_Bpbcoutrecvlist.m_dbtnm       = m_pkg007.stBody002.szOriRecipientName  ; 
        //m_Bpbcoutrecvlist.m_dbtaddr     = m_pkg007.stBody002.szOriRecipientAddr;
        SetFieldAsUtf8(m_pkg007.stBody002.szOriRecipientName, m_Bpbcoutrecvlist.m_dbtnm);
        SetFieldAsUtf8(m_pkg007.stBody002.szOriRecipientAddr, m_Bpbcoutrecvlist.m_dbtaddr);
        
        //�տ��Ϣ
         
        m_Bpbcoutrecvlist.m_cdtracctid  = m_pkg007.stBody002.szOriPayerAcc  ; 
        m_Bpbcoutrecvlist.m_cdtrissr    = m_pkg007.stBody002.szOriPayOpenAccBkCode  ; 
        m_Bpbcoutrecvlist.m_cdtrbrnchid = m_pkg007.stBody002.szRdfiCode; 
        //m_Bpbcoutrecvlist.m_cdtrnm      = m_pkg007.stBody002.szOriPayerName  ;
        //m_Bpbcoutrecvlist.m_cdtaddr     = m_pkg007.stBody002.szOriPayerAddr  ;
        SetFieldAsUtf8(m_pkg007.stBody002.szOriPayerName, m_Bpbcoutrecvlist.m_cdtrnm);
        SetFieldAsUtf8(m_pkg007.stBody002.szOriPayerAddr, m_Bpbcoutrecvlist.m_cdtaddr);
        
        m_Bpbcoutrecvlist.m_currency   = szCcy ; 
        m_Bpbcoutrecvlist.m_amount     = atof(m_pkg007.stBody002.szOriAmount)/100.0; 
        m_Bpbcoutrecvlist.m_pmttpprtry = m_pkg007.stBody002.szTrxsType  ; 
        m_Bpbcoutrecvlist.m_purpprtry  = m_pkg007.stBody002.szTrxsType  ; //??
         
        m_Bpbcoutrecvlist.m_orgnlmsgid = ""  ; 
        m_Bpbcoutrecvlist.m_orgnlmsgtp = ""  ; 
        m_Bpbcoutrecvlist.m_oriinstgdrctpty = m_pkg007.stBody002.szOriOdfiCode  ; 

        strTmp = "";
        strTmp = strTmp + m_pkg007.stBody002.szOriConsignDate + m_pkg007.stBody002.szOriTxssNo;        
        m_Bpbcoutrecvlist.m_oritxid = strTmp ; 
        
        //ԭҵ�����ͺ�
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += "0BH:";
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += m_pkg007.stBody002.szOriTrxsType;
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += ":";
        //ԭ�������к�
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += "CC1:";
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += m_pkg007.stBody002.szOriOdfiCode;
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += ":";
        //ԭ�������к�
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += "CC2:";
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += m_pkg007.stBody002.szOriRdfiCode;
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += ":";
        //ԭί������
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += "051:";
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += m_pkg007.stBody002.szOriConsignDate;
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += ":";
        //ԭ�������
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += "005:";
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += strTmp;
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += ":";
        //ԭ���
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += "33S:RMB";
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += m_pkg007.stBody002.szOriAmount;
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += ":";
        //ԭ�տ��˿������к�
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += "CCK:";
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += m_pkg007.stBody002.szOriRecOpenAccBkCode;
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += ":";
        //ԭ�տ����˺�
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += "CQ2:";
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += m_pkg007.stBody002.szOriRecipientAcc;
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += ":";
        //ԭ�տ�������
        strTmp = "";
        SetFieldAsUtf8(m_pkg007.stBody002.szOriRecipientName, strTmp);
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += "CR2:";
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += strTmp;
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += ":";
        //ԭ�տ��˵�ַ
        strTmp = "";
        SetFieldAsUtf8(m_pkg007.stBody002.szOriRecipientAddr, strTmp);
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += "59F:";
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += strTmp;
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += ":";
        //ԭ�����˿������к�
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += "CCL:";
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += m_pkg007.stBody002.szOriPayOpenAccBkCode;
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += ":";
        //ԭ�������˺�
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += "CQ1:";
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += m_pkg007.stBody002.szOriPayerAcc;
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += ":";
        //ԭ����������
        strTmp = "";
        SetFieldAsUtf8(m_pkg007.stBody002.szOriPayerName, strTmp);
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += "CR1:";
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += strTmp;
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += ":";
        //ԭ�����˵�ַ
        strTmp = "";
        SetFieldAsUtf8(m_pkg007.stBody002.szOriPayerAddr, strTmp);
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += "50F:";
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += strTmp;
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += ":";
        //�˻�ԭ��
        strTmp = "";
        SetFieldAsUtf8(m_pkg007.stBody002.szBackReason, strTmp);
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += "CIA:";
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += strTmp;
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += ":";
        //�˻㸽��
        strTmp = "";
        SetFieldAsUtf8(m_pkg007.stBody002.szPost, strTmp);
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += "72A:";
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += strTmp;
        m_Bpbcoutrecvlist.m_cstmrcdttrfaddtlinf += ":";
        
        //��ע
        m_Bpbcoutrecvlist.m_remark = strTmp;

        //����
        m_Bpbcoutrecvlist.m_addtlinf    = strTmp;

        m_Bpbcoutrecvlist.m_oriamount   = atof(m_pkg007.stBody002.szOriAmount)/100  ; 
     
        m_Bpbcoutrecvlist.m_srcflag     = m_pkg007.stHead001.szSrcFlag  ; 
        m_Bpbcoutrecvlist.m_checkstate  = PR_CNCH_00; 
        m_Bpbcoutrecvlist.m_busistate   = strBusistate;
        m_Bpbcoutrecvlist.m_processcode = ""  ; 
        m_Bpbcoutrecvlist.m_rjctinf     = ""  ; 
        m_Bpbcoutrecvlist.m_procstate   = szProcSts;
        //m_Bpbcoutrecvlist.m_printno     = 0;
        //m_Bpbcoutrecvlist.m_finalstatedate = szSapsdate; //��̬����
        //m_Bpbcoutrecvlist.m_statetime = m_pkg007.stBody002.szConsignDate  ; 
        //__wsh 2012-07-25 ��������ͳһתΪISODATE��ʽ�洢
        char szIsoDt[32] = {0};
        if(strlen(m_pkg007.stHead001.szNtDate)>=8){
            chgToISODate(m_pkg007.stHead001.szNtDate, szIsoDt);
        }
        Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
            "__netdata[%s], netno[%s]", szIsoDt, m_pkg007.stHead001.szNtNo);
        m_Bpbcoutrecvlist.m_netgdt  = szIsoDt; 
        m_Bpbcoutrecvlist.m_netgrnd = m_pkg007.stHead001.szNtNo  ; 
        
        int iRet = m_Bpbcoutrecvlist.insert();
        if(OPERACT_SUCCESS != iRet)
        {
            sprintf(m_szErrMsg,"m_Bpbcoutrecvlist.insert failed:[%d][%s]", iRet, m_Bpbcoutrecvlist.GetSqlErr());
            PMTS_ThrowException(DB_INSERT_FAIL);  
        }
        
        //__wsh 2012-06-07 ҵ��Ϊ�˻�ʱ��ԭҵ��Ϊ���ڷ����Ž��м�ֱ���ж�
        string strSrcflag = "";
    	orgnbcoutlist.m_txid = m_Bpbcoutrecvlist.m_oritxid;
		orgnbcoutlist.m_dbtrbrnchid = m_pkg007.stBody002.szOriOdfiCode;
    	iRet = orgnbcoutlist.findByPK();
    	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__[%s][%s]",
    	    orgnbcoutlist.m_txid.c_str(), orgnbcoutlist.m_dbtrbrnchid.c_str());
    	if(iRet != SQL_SUCCESS)
    	{
    		if (iRet == SQLNOTFOUND){
				CBpbcoutrecvlisthis his;
				SETCTX(his);
				his.m_txid = orgnbcoutlist.m_txid;
				his.m_dbtrbrnchid = orgnbcoutlist.m_dbtrbrnchid;
				iRet = his.findByPK();
				if (iRet != SQL_SUCCESS){
					if (iRet != SQLNOTFOUND){
						Trace(L_ERROR, __FILE__, __LINE__, NULL,
								"FIND falied,iRet=%d cause=%s", iRet, his.GetSqlErr());
						PMTS_ThrowException(DB_FIND_BY_PK_FAIL);
					}
					else{
						Trace(L_INFO, __FILE__, __LINE__, NULL, "�Ҳ���ԭҵ��!");
					}
				}
				else{
					strSrcflag = his.m_srcflag.c_str();
					m_strOrgnlTable = "bp_bcoutrecvlisthis";
					m_strOrgnlTxid  = his.m_txid.c_str();
					m_strOrgnlDbtrbrnchid = his.m_dbtrbrnchid.c_str();
				}
    		}
    		else{
				Trace(L_ERROR, __FILE__, __LINE__, NULL,
						"Find orgn failed,iRet=%d cause=%s", iRet, orgnbcoutlist.GetSqlErr());
				PMTS_ThrowException(DB_FIND_BY_PK_FAIL);
    		}
    	}
    	else
    	{
    		strSrcflag = orgnbcoutlist.m_srcflag.c_str();
    		m_strOrgnlTable = "bp_bcoutrecvlist";
    		m_strOrgnlTxid  = orgnbcoutlist.m_txid.c_str();
    		m_strOrgnlDbtrbrnchid = orgnbcoutlist.m_dbtrbrnchid.c_str();
    	}

    	//����ԭҵ���˻��־
    	if (strSrcflag != ""){
    		UpdateOrgnlBiz(m_strOrgnlDbtrbrnchid, m_strOrgnlTxid);
    	}

    }

    m_Bpbcoutrcvcl.m_workdate     = m_strWorkDate ;
    m_Bpbcoutrcvcl.m_consigdate   = m_pkg007.stHead001.szPkgCDate ; 
    m_Bpbcoutrcvcl.m_msgtp        = m_strMsgTp ; 
    m_Bpbcoutrcvcl.m_msgid        = m_strMsgID ; 
    m_Bpbcoutrcvcl.m_instgdrctpty = m_pkg007.stHead001.szOdfiCode ; 
    m_Bpbcoutrcvcl.m_instddrctpty = m_pkg007.stHead001.szRdfiCode ; 
    m_Bpbcoutrcvcl.m_ccy          = szCcy ; 
    m_Bpbcoutrcvcl.m_rmk          = m_pkg007.stHead001.szAppData ; 
    m_Bpbcoutrcvcl.m_srcflag      = m_pkg007.stHead001.szSrcFlag ; 
    m_Bpbcoutrcvcl.m_checkstate   = PR_CNCH_00; 
    m_Bpbcoutrcvcl.m_busistate    = strBusistate ;
    m_Bpbcoutrcvcl.m_processcode  = ""; 
    m_Bpbcoutrcvcl.m_rjctinf      = "" ; 
    m_Bpbcoutrcvcl.m_procstate    = szProcSts;
 
    m_Bpbcoutrcvcl.m_netgdt       = m_Bpbcoutrecvlist.m_netgdt ; 
    m_Bpbcoutrcvcl.m_netgrnd      = m_pkg007.stHead001.szNtNo ; 

    m_Bpbcoutrcvcl.m_nboftxs      = atoi(m_pkg007.stHead001.szDetailCnt) ; 
    m_Bpbcoutrcvcl.m_ctrlsum      = atof(m_pkg007.stHead001.szDetailAmt+3)/100 ;

    m_Bpbcoutrcvcl.m_succnboftxs      = atoi(m_pkg007.stHead001.szDetailCnt) ; 
    m_Bpbcoutrcvcl.m_ctrlsuccsum      = atof(m_pkg007.stHead001.szDetailAmt+3)/100 ;
 
    m_Bpbcoutrcvcl.m_realtimeflag = "0"; 
    m_Bpbcoutrcvcl.m_dgtsign      = "MAC" ; 
    m_Bpbcoutrcvcl.m_isrbflg      = "0" ; 
	m_Bpbcoutrcvcl.m_mesgid       = m_pkg007.GetHeadMesgID();
	m_Bpbcoutrcvcl.m_mesgrefid    = m_pkg007.GetHeadMesgReqNo();
    m_Bpbcoutrcvcl.m_srcflag = "0";
    SETCTX(m_Bpbcoutrcvcl);
    iRet = m_Bpbcoutrcvcl.insert();
    if (OPERACT_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg,"m_Bpbcoutrcvcl.insert failed:[%d][%s]", iRet, m_Bpbcoutrcvcl.GetSqlErr());
        Trace(L_ERROR, __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(DB_INSERT_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkPkg007::InsertBCsendList()");
}

INT32 CRecvBkPkg007::unPack(LPCSTR szMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkPkg007::unPack()");

	int iRet = -1;

	// �����Ƿ�Ϊ��
	if (NULL == szMsg || '\0' == szMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
	}

	// ��������
	iRet = m_pkg007.ParseMsg(szMsg);
	if (OPERACT_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= %d", iRet);	
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");
	}

	m_strWorkDate = m_sWorkDate;
    
    ZFPTLOG.SetLogInfo("007", m_strMsgID.c_str());

	// ���ı�ʶ��
	char sMsgId[35 + 1];
	memset(sMsgId, 0x00, sizeof(sMsgId));
	sprintf(sMsgId, "%s%s", m_pkg007.stHead001.szPkgCDate, m_pkg007.stHead001.szPkgserNo);
	m_strMsgID = sMsgId;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkPkg007::unPack()");
	return OPERACT_SUCCESS;
}

int CRecvBkPkg007::CheckMac007()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkPkg007::CheckMac007()");

    int iRet = -1;
    iRet = CheckPkgMac(m_pkg007,m_pkg007.stHead001.szPkgDest,m_pkg007.stHead001.szRdfiCode);
	if(0 != iRet)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CheckMac007 failed");
    	PMTS_ThrowException(__FILE__, __LINE__, OPT_CHECKMAC_FAIL, "CheckMac007 failed");
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkPkg007::CheckMac007()");
    
    return OPERACT_SUCCESS;
}

INT32 CRecvBkPkg007::CheckAcct()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvBkPkg007::CheckAcct");
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CRecvBkPkg007::CheckAcct"); 
    return 0;
}

int CRecvBkPkg007::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkPkg007::FundSettle...");
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û�[%s]", m_szOprUser);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_pkg007.GetHeadDestAddr());

	m_charge.m_amount = m_Bpbcoutrcvcl.m_ctrlsum*100;	//ҵ����
	m_charge.m_iDCFlag = iCREDITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, MBVIRSUALNETID);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_pkg007.GetHeadDestAddr());	//������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(RTN_SUCCESS != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FundSettle iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkPkg007::FundSettle..."); 
    
    return RTN_SUCCESS;
}


//__wsh 2013-02-27 ����ԭҵ����ϸ�˻��־
void CRecvBkPkg007::UpdateOrgnlBiz(const string& dbtrbrnchid, const string& txid)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CRecvBkPkg007::UpdateOrgnlBiz");

	string strSql = "update ";
	strSql += m_strOrgnlTable;
	strSql += " set isrbflg='1' where dbtrbrnchid='";
	strSql += dbtrbrnchid;
	strSql += "' and txid='";
	strSql += txid;
	strSql += "' ";

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strSql=[%s]", strSql.c_str());
	int iRet = m_Bpbcoutrecvlist.execsql(strSql);
	
	if (iRet == SQLNOTFOUND)
	{
    	Trace(L_ERROR, __FILE__, __LINE__, NULL, "Not find Orgn bussiness");	        
	}	
	else if(iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"����ʧ�ܣ�[%s]", m_Bpbcoutrecvlist.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CRecvBkPkg007::UpdateOrgnlBiz");
}

void CRecvBkPkg007::AddMac()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LENTER CRecvbkPkg007::AddMac()");

    char szMac[40+1] = {0};//编押后的串
    GetCodeMac(m_pkg007,szMac);
        
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Mac is [%s] ",szMac);

    m_pkg007.EncodePkgMsg(m_strPkgmsg,szMac);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "pkgmsg is [%s] ",m_strPkgmsg.c_str());
    

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbkPkg007::AddMac()");
    
    return;
}

