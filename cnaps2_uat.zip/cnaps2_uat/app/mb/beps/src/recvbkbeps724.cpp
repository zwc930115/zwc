#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkbeps724.h"

using namespace ZFPT;

CRecvBkbeps724::CRecvBkbeps724()
{
}

CRecvBkbeps724::~CRecvBkbeps724()
{

}

INT32 CRecvBkbeps724::Work(LPCSTR szMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps724::Work()");

	//do nothing	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps724::Work()");
	return 0;
}
