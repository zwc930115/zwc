/******************************************************************** 
�ļ����� recvbeps122.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif
#include "recvbeps122.h"

CRecvbeps122::CRecvbeps122()
{
    m_Bpcl.m_msgtp   = "beps.122.001.01";
    m_BpList.m_msgtp = "beps.122.001.01";
	m_strMsgTp = "beps.122.001.01";
}

CRecvbeps122::~CRecvbeps122()
{

}

void CRecvbeps122::CheckSign122()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms122::CheckSign122");
	
	m_cBeps122.getOriSignStr();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSignBuff = [%s]", m_cBeps122.m_sSignBuff.c_str());	
	
	CheckSign(m_cBeps122.m_sSignBuff.c_str(),
			m_cBeps122.m_szDigitSign.c_str(),
			m_cBeps122.InstgDrctPty.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms122::CheckSign122");
}

int CRecvbeps122::Work(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps122::CRecvbeps122()");

    // ��������
    unPack(szMsg);

    SetData(szMsg);
    
    // ��������
    InsertData();
	
    //��ǩ
    CheckSign122();
	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps122::CRecvbeps122()");
    return OPERACT_SUCCESS;
}

INT32 CRecvbeps122::unPack(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps122::unPack()");
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "receive msg len = [%d]", strlen(szMsg));
    
    int iRet = -1;

    if (NULL == szMsg || '\0' == szMsg)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "���ĳ���Ϊ��!");
        PMTS_ThrowException(PRM_FAIL);
    }

    // ��������
    if (OPERACT_SUCCESS != m_cBeps122.ParseXml(szMsg))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= %d", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");
    }
    
    //���ı�ʶ��
	m_strMsgID = m_cBeps122.MsgId;

	//��ȡ��������
	iRet = GetWorkDate(m_dbproc, m_sWorkDate,
			SYS_BEPS, m_cBeps122.InstdDrctPty.c_str());
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");
		PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
	}
	m_strWorkDate = m_sWorkDate;

	//ZFPTLOG.SetLogInfo("122", m_strMsgID.c_str());    
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps122::unPack()");
    return OPERACT_SUCCESS;
}

INT32 CRecvbeps122::InsertData()
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps122::InsertData()");
    
    SETCTX(m_Bpcl);
    int iRet = m_Bpcl.insert();
	if(OPERACT_SUCCESS != iRet)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "������ϸ��ʧ��,�ع����ܱ�, ERROR = %s", m_Bpcl.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}		 
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps122::InsertData()");
    return iRet;
}

INT32 CRecvbeps122::SetData(LPCSTR pchMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps122::SetData()");
    
    SETCTX(m_BpList);
    
    char szParentName[128 + 1] = {0};
    char szChildName[128 + 1] = {0};
    char sProcstate[2+1]={0};
    string strTemp  = "";
    string strTemp1 = "";
    
    //���ݰ�����״̬���±�״̬
    TransProcStates(m_cBeps122.PrcSts.c_str(),sProcstate);
    
    m_Bpcl.m_msgid        = m_cBeps122.MsgId;
    m_Bpcl.m_workdate     = m_sWorkDate;
    m_Bpcl.m_consigdate   = m_cBeps122.MsgId.substr(0, 8);
    m_Bpcl.m_instgdrctpty = m_cBeps122.InstgDrctPty; 
	m_Bpcl.m_instddrctpty = m_cBeps122.InstdDrctPty; 
	m_Bpcl.m_ccy          = m_cBeps122.CtrlSumCcy; 
	m_Bpcl.m_rmk          = m_cBeps122.Rmk; 
	m_Bpcl.m_srcflag      = "0";//m_cBeps122.SrcFlag; //0:������1������
	m_Bpcl.m_checkstate   = "00"; 
	m_Bpcl.m_busistate    = m_cBeps122.PrcSts; 
	m_Bpcl.m_processcode  = m_cBeps122.PrcCd;
	m_Bpcl.m_rjctinf      = m_cBeps122.RjctInf;
	m_Bpcl.m_procstate    = sProcstate;

	m_Bpcl.m_netgdt       = m_cBeps122.NetgDt;
	m_Bpcl.m_netgrnd      = m_cBeps122.NetgRnd;
	m_Bpcl.m_finalstatedate = m_cBeps122.SttlmDt;
	m_Bpcl.m_nboftxs      = 1;
	m_Bpcl.m_ctrlsum      = atof(m_cBeps122.CtrlSum.c_str()); 
	m_Bpcl.m_sapsnboftxs  = 0; 
	m_Bpcl.m_ctrlsapssum  = 0.00; 
	m_Bpcl.m_realtimeflag = "0";
	m_Bpcl.m_dgtsign      = "DIGTAL SIGN"; 

    m_Bpcl.m_isrbflg      = "0";//��Ҫ�ж�if A105 
    m_Bpcl.m_recvdest     = "1";

    m_BpList.m_finalstatedate = m_cBeps122.SttlmDt;

    strncpy(szParentName,"FinCdtTrfInf",sizeof(szParentName)-1);
    int iNumParent = m_cBeps122.GetDetailCnt();
    for(int i = 0; i < iNumParent; i++)
    {   
        m_cBeps122.ParseDetail(i);
            	    	
        m_BpList.m_workdate      = m_sWorkDate;
        m_BpList.m_consigdate    = m_cBeps122.TxId.substr(0, 8);
        m_BpList.m_instgdrctpty  = m_cBeps122.InstgDrctPty;
        m_BpList.m_instddrctpty  = m_cBeps122.InstdDrctPty;
        m_BpList.m_txid          = m_cBeps122.TxId;
        m_BpList.m_msgid         = m_cBeps122.MsgId;
        m_BpList.m_dbtnm         = m_cBeps122.DbtrNm;
        m_BpList.m_dbtracctid    = m_cBeps122.DbtrAcctId;
        m_BpList.m_dbtrissr      = m_cBeps122.DbtrAcctIssr;
        m_BpList.m_dbtrbrnchid   = m_cBeps122.DbtrAgtId;
        m_BpList.m_cdtrnm        = m_cBeps122.CdtrNm;
        m_BpList.m_cdtracctid    = m_cBeps122.CdtrAcctId;
        m_BpList.m_cdtrissr      = m_cBeps122.CdtrAcctIssr;
        m_BpList.m_cdtrbrnchid   = m_cBeps122.CdtrAgtId;
        m_BpList.m_currency      = m_cBeps122.CtrlSumCcy;
        m_BpList.m_pmttpprtry    = m_cBeps122.CtgyPurpPrtry;
        m_BpList.m_purpprtry     = m_cBeps122.PurpPrtry;
        m_BpList.m_addtlinf      = m_cBeps122.AddtlInf;
        m_BpList.m_amount        = atof(m_cBeps122.CtrlSum.c_str());
        //m_BpList.m_printno       = 0;
        m_BpList.m_srcflag       = "0";
        m_BpList.m_checkstate    = "00";
        m_BpList.m_busistate     = m_cBeps122.PrcSts;
        m_BpList.m_processcode   = m_cBeps122.PrcCd;
        m_BpList.m_rjctinf       = m_cBeps122.RjctInf;
        m_BpList.m_procstate     = sProcstate;
        m_BpList.m_netgdt        = m_cBeps122.NetgDt;
        m_BpList.m_netgrnd       = m_cBeps122.NetgRnd;
        m_BpList.m_dbtaddr       = m_cBeps122.DbtrAdrLine;
        m_BpList.m_cdtaddr       = m_cBeps122.CdtrAdrLine;
        m_BpList.m_acctstate     = "01";
        
        //ҵ������Ϊ�����ʽ���ǻ���
        if("A104" == m_cBeps122.CtgyPurpPrtry)
        {
            strncpy(szChildName,"NtlTrsrCdtInfDtls",sizeof(szChildName)-1);
            //�����ֶ�
            m_BpList.m_cstmrcdttrfaddtlinf = "/FlowNb/" + m_cBeps122.NtlTrsrCdtInfFlowNb + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/Amt/" + m_cBeps122.NtlTrsrCdtInfCcy + m_cBeps122.NtlTrsrCdtInfAmt + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/RptCd/" + m_cBeps122.NtlTrsrCdtInfRptCd + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/RcvCd/" + m_cBeps122.NtlTrsrCdtInfRcvCd + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/RptFrms/" + m_cBeps122.NtlTrsrCdtInfRptFrms + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/RptNb/" + m_cBeps122.NtlTrsrCdtInfRptNb + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/BugtLvl/" + m_cBeps122.BugtLvl + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/Ind/" + m_cBeps122.Ind + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/BugtTp/" + m_cBeps122.BugtTp + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/NbOfTxs/" + m_cBeps122.NtlTrsrCdtInfNbOfTxs + ":";
                        
            //��ϸ������
            int iNumChild = atoi(m_cBeps122.NtlTrsrCdtInfNbOfTxs.c_str());
            Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iNumChild[%d]", iNumChild);
        	for(int j = 0 ; j < iNumChild ; j++)
            {
                strTemp = m_cBeps122.GetValueFromLiLCycle(szParentName,i,szChildName,j,"NtlTrsrCdtInfDtlsTpCd");
                m_BpList.m_cstmrcdttrfaddtlinf += "/TpCd/" + strTemp + ":";
				m_cBeps122.m_strTx2 += Trim(strTemp) + "|";
				
                strTemp = m_cBeps122.GetValueFromLiLCycle(szParentName,i,szChildName,j,"SbjtCd");
                m_BpList.m_cstmrcdttrfaddtlinf += "/SbjtCd/" + strTemp + ":";
				m_cBeps122.m_strTx2 += Trim(strTemp) + "|";
				
                strTemp1 = m_cBeps122.GetValueFromLiLCycle(szParentName,i,szChildName,j,"NtlTrsrCdtInfDtlsCcy");
                strTemp = strTemp1 + m_cBeps122.GetValueFromLiLCycle(szParentName,i,szChildName,j,"NtlTrsrCdtInfDtlsAmt");
                m_BpList.m_cstmrcdttrfaddtlinf += "/Amt/" + strTemp + ":";
            	m_cBeps122.m_strTx2 += Trim(strTemp) + "|";
				
            	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps122.m_strTx2[%s]", m_cBeps122.m_strTx2.c_str());
            	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_BpList.m_cstmrcdttrfaddtlinf[%s]", m_BpList.m_cstmrcdttrfaddtlinf.c_str());
            }
        }
        //ҵ������Ϊ�����ʽ��ծ�Ҹ����ǻ���
        else if("A307" == m_cBeps122.CtgyPurpPrtry)
        {
            //�����ֶ�
            strncpy(szChildName,"NtlTrsrInfDtls",sizeof(szChildName)-1);
            m_BpList.m_cstmrcdttrfaddtlinf = "/FlowNb/" + m_cBeps122.NtlTrsrInfFlowNb + ":";
            m_BpList.m_cstmrcdttrfaddtlinf +=  "/Amt/"+ m_cBeps122.NtlTrsrInfCcy + m_cBeps122.NtlTrsrInfAmt + ":";
            m_BpList.m_cstmrcdttrfaddtlinf +=  "/RptCd/" + m_cBeps122.NtlTrsrInfRptCd + ":";
            m_BpList.m_cstmrcdttrfaddtlinf +=  "/RcvCd/" + m_cBeps122.NtlTrsrInfRcvCd + ":";
            m_BpList.m_cstmrcdttrfaddtlinf +=  "/RptFrms/" + m_cBeps122.NtlTrsrInfRptFrms + ":";
            m_BpList.m_cstmrcdttrfaddtlinf +=  "/RptNb/" + m_cBeps122.NtlTrsrInfRptNb + ":";
            m_BpList.m_cstmrcdttrfaddtlinf +=  "/NbOfTxs/" + m_cBeps122.NtlTrsrInfNbOfTxs + ":";
            
                          
            int iCountChild = atoi(m_cBeps122.NtlTrsrInfNbOfTxs.c_str());
            for(int j=0; j < iCountChild ; j++)
            {
                strTemp = m_cBeps122.GetValueFromLiLCycle(szParentName,i,szChildName,j,"NtlTrsrInfDtlsTpCd");
                m_BpList.m_cstmrcdttrfaddtlinf += "/TpCd/" + strTemp + ":";
				m_cBeps122.m_strTx2 += Trim(strTemp) + "|";
				
                strTemp = m_cBeps122.GetValueFromLiLCycle(szParentName,i,szChildName,j,"CptlCd");
                m_BpList.m_cstmrcdttrfaddtlinf += "/CptlCd/" + strTemp + ":";
                m_cBeps122.m_strTx2 += Trim(strTemp) + "|";
				
                strTemp1 = m_cBeps122.GetValueFromLiLCycle(szParentName,i,szChildName,j,"CptlAmtCcy");
                strTemp = strTemp1 + m_cBeps122.GetValueFromLiLCycle(szParentName,i,szChildName,j,"CptlAmt");
                m_BpList.m_cstmrcdttrfaddtlinf += "/CptlAmt/" + strTemp + ":";
				m_cBeps122.m_strTx2 += Trim(strTemp) + "|";
				
                strTemp = m_cBeps122.GetValueFromLiLCycle(szParentName,i,szChildName,j,"AcrlCd");
                m_BpList.m_cstmrcdttrfaddtlinf += "/AcrlCd/" + strTemp + ":";
				m_cBeps122.m_strTx2 += Trim(strTemp) + "|";
				
                strTemp1 = m_cBeps122.GetValueFromLiLCycle(szParentName,i,szChildName,j,"AcrlAmtCcy");
                strTemp = strTemp1 + m_cBeps122.GetValueFromLiLCycle(szParentName,i,szChildName,j,"AcrlAmt");
                m_BpList.m_cstmrcdttrfaddtlinf += "/AcrlAmt/" + strTemp + ":";
                m_cBeps122.m_strTx2 += Trim(strTemp) + "|";
				
				Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps122.m_strTx2[%s]", m_cBeps122.m_strTx2.c_str());
            	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_BpList.m_cstmrcdttrfaddtlinf[%s]", m_BpList.m_cstmrcdttrfaddtlinf.c_str());
            }
        }
        //ҵ������Ϊ�˻�ҵ��
        else if("A105" == m_cBeps122.CtgyPurpPrtry)
        {
            m_BpList.m_cstmrcdttrfaddtlinf = "/OrgnlMsgId/" + m_cBeps122.OrgnlMsgId + ":";
            m_BpList.m_cstmrcdttrfaddtlinf +=  "/OrgnlInstgPty/"+ m_cBeps122.OrgnlInstgPty + ":";
            m_BpList.m_cstmrcdttrfaddtlinf +=  "/OrgnlMT/" + m_cBeps122.OrgnlMT + ":";
            m_BpList.m_cstmrcdttrfaddtlinf +=  "/InstgIndrctPty/" + m_cBeps122.InstgIndrctPty + ":";
            m_BpList.m_cstmrcdttrfaddtlinf +=  "/InstdIndrctPty/" + m_cBeps122.InstdIndrctPty + ":";
            m_BpList.m_cstmrcdttrfaddtlinf +=  "/OrgnlTxId/" + m_cBeps122.OrgnlTxId + ":";
            m_BpList.m_cstmrcdttrfaddtlinf +=  "/OrgnlTxTpCd/" + m_cBeps122.OrgnlTxTpCd + ":";
            m_BpList.m_cstmrcdttrfaddtlinf +=  "/Cntt/" + m_cBeps122.Cntt + ":";
            
        }
        
        // ���ڼ�ǩ��ѭ��������ѭ����������Ҫ����ѭ������֮�󣬲�����ѭ���ļ�ǩ
		m_cBeps122.AddTxStr();

        //��ϸ����������
        if(OPERACT_SUCCESS != m_BpList.insert())
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "������ϸ��ʧ��,�ع����ܱ�iRet=%d, %s", iRet, m_BpList.GetSqlErr());
            PMTS_ThrowException(DB_INSERT_FAIL);
        }
        
        //__wsh 2012-06-07 ҵ��Ϊ�˻�ʱ��ԭҵ��Ϊ���ڷ����Ž��м�ֱ���ж�
        if("A105" == m_cBeps122.CtgyPurpPrtry)
        {
        	string strSrcflag = "";
        	CBpbcoutsendlist orgnbcoutlist;
        	SETCTX(orgnbcoutlist);
        	orgnbcoutlist.m_txid = m_cBeps122.OrgnlTxId;
        	orgnbcoutlist.m_dbtrbrnchid = m_cBeps122.InstgIndrctPty;
        	iRet = orgnbcoutlist.findByPK();
        	if(iRet != SQL_SUCCESS)
        	{
        		if (iRet == SQLNOTFOUND){
					CBpbcoutsendlisthis his;
					SETCTX(his);
					his.m_txid = orgnbcoutlist.m_txid;
					his.m_dbtrbrnchid = orgnbcoutlist.m_dbtrbrnchid;
					iRet = his.findByPK();
					if (iRet != SQL_SUCCESS){
						if (iRet != SQLNOTFOUND){
							Trace(L_ERROR, __FILE__, __LINE__, NULL,
									"��ѯԭҵ��ʧ��,iRet=%d cause=%s", iRet, his.GetSqlErr());
							PMTS_ThrowException(DB_FIND_BY_PK_FAIL);
						}
						else{
							Trace(L_INFO, __FILE__, __LINE__, NULL, "�Ҳ���ԭҵ��!");
						}
					}
					else{
						strSrcflag = his.m_srcflag.c_str();
						m_strOrgnlTable = "bp_bcoutsendlisthis";
					}
				}
				else{
					Trace(L_ERROR, __FILE__, __LINE__, NULL,
							"��ѯԭҵ��ʧ��,iRet=%d cause=%s", iRet, orgnbcoutlist.GetSqlErr());
					PMTS_ThrowException(DB_FIND_BY_PK_FAIL);
				}
        	}
        	else{
				strSrcflag = orgnbcoutlist.m_srcflag.c_str();
				m_strOrgnlTable = "bp_bcoutsendlist";
			}
        	//����ԭҵ���˻��־
        	if (strSrcflag != ""){
        		UpdateOrgnlBiz(m_cBeps122.InstgIndrctPty, m_cBeps122.OrgnlTxId);
        	}

        } 
    }
   
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps122::SetData()");
    return OPERACT_SUCCESS;
}

//__wsh 2013-02-27 ����ԭҵ����ϸ�˻��־
void CRecvbeps122::UpdateOrgnlBiz(const string& dbtrbrnchid, const string& txid)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CRecvbeps122::UpdateOrgnlBiz");

	string strSql = "update ";
	strSql += m_strOrgnlTable;
	strSql += " set isrbflg='1' where dbtrbrnchid='";
	strSql += dbtrbrnchid;
	strSql += "' and txid='";
	strSql += txid;
	strSql += "' ";

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strSql=[%s]", strSql.c_str());
	int iRet = m_BpList.execsql(strSql);
	if(iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"����ʧ�ܣ�[%s]", m_BpList.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CRecvbeps122::UpdateOrgnlBiz");
}

