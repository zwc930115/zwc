/******************************************************************** 
�ļ����� recvcmt325.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-04-28
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkcmt325.h"

using namespace ZFPT;

CRecvBkCmt325::CRecvBkCmt325()
{
    m_strMsgTp	  = "CMT325";
    memset(m_sOldMsgId, 0x00, sizeof(m_sOldMsgId));
}

CRecvBkCmt325::~CRecvBkCmt325()
{
	
}

void CRecvBkCmt325::GetOrgnBuss()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CRecvBkCmt325::GetOrgnBuss");

    SETCTX(m_cOrgnBpcstpmtcxl);
    char m_sOrgnMsgId[35 + 1] = {0};
    sprintf(m_sOrgnMsgId, "%8s%08s", m_cmt325.sOldconsigndate, m_cmt325.sRevctmssno);        
    
    m_cBpcstpmtcxl.m_msgid = m_sOrgnMsgId ; 
    m_cBpcstpmtcxl.m_instgdrctpty = m_cmt325.sOldsendsapbk ; 
    
    int iRet = m_cOrgnBpcstpmtcxl.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��, iRet = %d", iRet, m_cOrgnBpcstpmtcxl.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CRecvBkCmt325::GetOrgnBuss"); 
}

INT32 CRecvBkCmt325::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CRecvBkCmt325::CheckValues");
    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CRecvBkCmt325::CheckValues"); 
    return OPERACT_SUCCESS;
}

void CRecvBkCmt325::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CRecvBkCmt325::SetData");    
    char m_szchMsgId[35 + 1] = {0};
    int bRet = GetMsgIdValue(m_dbproc, m_szchMsgId, eMsgId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡmsgidʧ��");
        PMTS_ThrowException(PRM_FAIL);    
    }    
    m_cBpcstpmtcxl.m_msgid = m_szchMsgId; 
    
    m_cBpcstpmtcxl.m_instgdrctpty = m_cmt325.m_CMTHeaderMap.startAddr  ; 
    m_cBpcstpmtcxl.m_instddrctpty = m_cmt325.m_CMTHeaderMap.destAddr  ; 
    m_cBpcstpmtcxl.m_oricxlinstgdrctpty = m_cmt325.sOldsendsapbk ; 
    m_cBpcstpmtcxl.m_oricxlmsgid = m_cOrgnBpcstpmtcxl.m_msgid; 
    m_cBpcstpmtcxl.m_oricxlmsgtp = m_cOrgnBpcstpmtcxl.m_msgtp; 
    //m_cBpcstpmtcxl.m_addtlinf = m_cmt325.sRemark  ; 
	SetGbkToUtf8(m_cmt325.sRemark , m_cBpcstpmtcxl.m_addtlinf);
    m_cBpcstpmtcxl.m_procstate = "04"  ; 
    //m_cBpcstpmtcxl.m_proctime = m_cmt325.  ; 
    m_cBpcstpmtcxl.m_oriinstgdrctpty = m_cmt325.sOldsendsapbk  ; 

    char m_sOrgnMsgId[35 + 1] = {0};
    sprintf(m_sOrgnMsgId, "%8s%08s", m_cmt325.sOldpackdate, m_cmt325.sOldpackno);        
    m_cBpcstpmtcxl.m_orimsgid = m_sOrgnMsgId ; 
    
    m_cBpcstpmtcxl.m_orimsgtp = m_cOrgnBpcstpmtcxl.m_orimsgtp; 
    //m_cBpcstpmtcxl.m_prcsts = m_cmt325.  ; 
    //m_cBpcstpmtcxl.m_prccd = m_cmt325.  ; 
    //m_cBpcstpmtcxl.m_rjctinf = m_cmt325.  ; 
    //m_cBpcstpmtcxl.m_netgdt = m_cmt325.sNetdate  ; 
    //m_cBpcstpmtcxl.m_netgrnd = m_cmt325.sNetno  ; 
    //m_cBpcstpmtcxl.m_sttlmdt = m_cmt325.sSapdate  ; 

	//��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS,m_cBpcstpmtcxl.m_instddrctpty.c_str());
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");	
		PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
	}    
    m_cBpcstpmtcxl.m_workdate = m_sWorkDate  ; 
    
    m_cBpcstpmtcxl.m_msgtp = "CMT325"; 
    //m_cBpcstpmtcxl.m_mesgid = m_sMsgRefId  ; 
    //m_cBpcstpmtcxl.m_mesgrefid = m_sMsgRefId  ; 

    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CRecvBkCmt325::SetData"); 
}

void CRecvBkCmt325::UpdateDB()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt325::UpdateDb()");	

	string strSQL;
	strSQL += "UPDATE BP_CSTPMTCXL t SET t.Procstate = '04'";
	strSQL += " WHERE t.msgid = '";
	strSQL += m_cBpcstpmtcxl.m_msgid;
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_cBpcstpmtcxl.m_instgdrctpty; 
	strSQL += "'";
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, strSQL.c_str());
	
    SETCTX(m_cBpcstpmtcxl);
	int iRet = m_cBpcstpmtcxl.execsql(strSQL.c_str());
    if (iRet != SQL_SUCCESS)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]",
		    iRet, m_cBpcstpmtcxl.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
	}
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt325::UpdateDb()");	
}

INT32 CRecvBkCmt325::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt325::Work()");	

	// ��������
	unPack(sMsg);

    // ҵ����
    CheckValues();

    GetOrgnBuss();
    
    SetData();
    
	InsertDb(sMsg);
	
	UpdateDB();

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt325::work()");

	return RTN_SUCCESS;
}

INT32 CRecvBkCmt325::unPack(LPCSTR sMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt325::unPack");	

    int iRet = RTN_FAIL;
    char sMsgId[35 + 1] = { 0 };

    // �����Ƿ�Ϊ��
    if (NULL == sMsg || '\0' == sMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }

    // ��������
    iRet = m_cmt325.ParseCmt(sMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������,iRet[%d]", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
    }

    // ���ı�ʶ�š�ϵͳ���
    sprintf(sMsgId, "%8s%08s", m_cmt325.sOldconsigndate, m_cmt325.sRevctmssno);
    m_strMsgID = sMsgId;
    ZFPTLOG.SetLogInfo("325", m_strMsgID.c_str());
            
    // ��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;      

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt325::unPack");	

    return RTN_SUCCESS;
}

INT32 CRecvBkCmt325::InsertDb(LPCSTR pchMsg)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt325::InsertDb");	

    // ��������
	SETCTX(m_cBpcstpmtcxl);

	// �������ݿ�
	int iRet = m_cBpcstpmtcxl.insert();
	if (0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "������ʧ��[%d][%s]",
		    iRet, m_cBpcstpmtcxl.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "������ʧ��");
	}

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt325::InsertDb");	

    return RTN_SUCCESS;
}


