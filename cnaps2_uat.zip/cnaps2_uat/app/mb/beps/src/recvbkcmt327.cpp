/******************************************************************** 
�ļ����� recvcmt327.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-04-28
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkcmt327.h"

using namespace ZFPT;

CRecvBkCmt327::CRecvBkCmt327()
{
    m_strMsgTp	  = "CMT327";
    memset(m_sOldMsgId, 0x00, sizeof(m_sOldMsgId));
}

CRecvBkCmt327::~CRecvBkCmt327()
{
	
}

INT32 CRecvBkCmt327::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt327::Work()");	

	// ��������
	unPack(sMsg);
    
	InsertDb(sMsg);

	// �޸�ԭ��������ҵ��״̬
	//UpdateDb();

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt327::work()");

	return RTN_SUCCESS;
}

INT32 CRecvBkCmt327::unPack(LPCSTR sMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt327::unPack");	

    int iRet = RTN_FAIL;
    char sMsgId[35 + 1] = { 0 };

    // �����Ƿ�Ϊ��
    if (NULL == sMsg || '\0' == sMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }

    // ��������
    iRet = m_cmt327.ParseCmt(sMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������,iRet[%d]", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
    }

    sprintf(m_sOldMsgId, "%8s%08d", m_cmt327.sOldconsigndate, m_cmt327.iOldtxssno);

    // ���ı�ʶ�š�ϵͳ���
    sprintf(sMsgId, "%8s%08s", m_cmt327.sConsigndate, m_cmt327.sRevctmssno);
    m_strMsgID = sMsgId;
    ZFPTLOG.SetLogInfo("327", m_strMsgID.c_str());
            
    // ��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;      

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt327::unPack");	

    return RTN_SUCCESS;
}

INT32 CRecvBkCmt327::InsertDb(LPCSTR pchMsg)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt327::InsertDb");	

    m_cBpcstbdpcxlcl.m_workdate = m_cmt327.sConsigndate ; 
    m_cBpcstbdpcxlcl.m_consigdate = m_cmt327.sConsigndate ; 
    m_cBpcstbdpcxlcl.m_msgtp = "CMT327" ; 
    m_cBpcstbdpcxlcl.m_mesgid = m_cmt327.m_CMTHeaderMap.mesgID ; 
    m_cBpcstbdpcxlcl.m_mesgid = m_cmt327.GetHeadMesgID();	             //ͨ�ż���ʶ��
	m_cBpcstbdpcxlcl.m_mesgrefid = m_cmt327.GetHeadMesgReqNo();           //ͨ�ż��ο���
    m_cBpcstbdpcxlcl.m_msgid = m_strMsgID ; 
    m_cBpcstbdpcxlcl.m_instgdrctpty = m_cmt327.sOldsendsapbk ; 
    m_cBpcstbdpcxlcl.m_instgpty = m_cmt327.sOldsendbank; 
    m_cBpcstbdpcxlcl.m_instddrctpty = m_cmt327.sOldrecvsapbk ; 
    m_cBpcstbdpcxlcl.m_instdpty = m_cmt327.sOldrecvbank ; 
    m_cBpcstbdpcxlcl.m_grpcxlid = m_cmt327.sFlag; 

    char m_sOrgnMsgId[35 + 1];
    sprintf(m_sOrgnMsgId, "%8s%08s", m_cmt327.sOldpackdate, m_cmt327.sOldpackno);
    m_cBpcstbdpcxlcl.m_orgnlmsgid = m_sOrgnMsgId ; 
    m_cBpcstbdpcxlcl.m_orgnlinstgpty = m_cmt327.sOldsendbank ; 

    string sOldpacktype = m_cmt327.sOldpacktype;
    if( ("001"==sOldpacktype) || ("002"==sOldpacktype) || ("003"==sOldpacktype) || 
        ("004"==sOldpacktype) || ("005"==sOldpacktype) || ("006"==sOldpacktype) || 
        ("007"==sOldpacktype) || ("008"==sOldpacktype) || ("009"==sOldpacktype) || 
        ("010"==sOldpacktype) || ("011"==sOldpacktype) || ("012"==sOldpacktype) || 
        ("013"==sOldpacktype) )
    {
        m_cBpcstbdpcxlcl.m_orgnmsgtp = m_cBpcstbdpcxlcl.m_orgnmsgtp + "PKG" + m_cmt327.sOldpacktype ; 
    }
    else
    {
        m_cBpcstbdpcxlcl.m_orgnmsgtp = m_cBpcstbdpcxlcl.m_orgnmsgtp + "CMT" + m_cmt327.sOldpacktype ; 
    }
    
    m_cBpcstbdpcxlcl.m_procstate = "03" ; 
    //m_cBpcstbdpcxlcl.m_stoppmtsts = m_cmt327.sFlag; 
    //m_cBpcstbdpcxlcl.m_osqlmsgid = m_cmt327. ; 
    //m_cBpcstbdpcxlcl.m_osqinstgpty = m_cmt327. ; 
    //m_cBpcstbdpcxlcl.m_osqmsgtp = m_cmt327. ; 
    m_cBpcstbdpcxlcl.m_rsflag = SRC_FRCNAPS; 

    SETCTX(m_cBpcstbdpcxlcl);
	int iRet = m_cBpcstbdpcxlcl.insert();
	if (0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "������ʧ��[%d][%s]",
		    iRet, m_cBpcstbdpcxlcl.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "������ʧ��");
	}    
	
    if(RTN_SUCCESS == strcmp("0", m_cmt327.sFlag))
    {
        m_cBpcstbdpcxllist.m_instgpty = m_cmt327.sOldsendsapbk ; 
        m_cBpcstbdpcxllist.m_msgid = m_strMsgID ; 
        m_cBpcstbdpcxllist.m_orgnlmsgid = m_sOrgnMsgId; 
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sOldMsgId=%s,m_cmt327.sOldconsigndate=%s, m_cmt327.iOldtxssno=%d",m_sOldMsgId, m_cmt327.sOldconsigndate, m_cmt327.iOldtxssno);	
        m_cBpcstbdpcxllist.m_orgnlpmtinfid = m_sOldMsgId; 
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cmt327.sOldtradetpno=%s",m_cmt327.sOldtradetpno);	
        m_cBpcstbdpcxllist.m_orgnlprtry = m_cmt327.sOldtradetpno ; 
        m_cBpcstbdpcxllist.m_orgdbtrbrnchid = m_cmt327.sOldrecvbank ; 
        m_cBpcstbdpcxllist.m_orgcdtrbrnchid = m_cmt327.sOldsendbank ; 
        //m_cBpcstbdpcxllist.m_rmtinf = m_cmt327.sRemark ; 
		SetGbkToUtf8(m_cmt327.sRemark, m_cBpcstbdpcxllist.m_rmtinf);
        //m_cBpcstbdpcxllist.m_mbmsgid = m_cmt327.sOldconsigndate ; 

        // ��������
    	SETCTX(m_cBpcstbdpcxllist);

    	// �������ݿ�
    	int iRet = m_cBpcstbdpcxllist.insert();
    	if (0 != iRet)
    	{
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "������ʧ��[%d][%s]",
    		    iRet, m_cBpcstbdpcxllist.GetSqlErr());
    		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "������ʧ��");
    	}
	}
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt327::InsertDb");	

    return RTN_SUCCESS;
}


