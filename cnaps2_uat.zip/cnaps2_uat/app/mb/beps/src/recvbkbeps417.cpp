/******************************************************************** 
�ļ����� recvbeps417.cpp
�����ˣ� zys
��  �ڣ� 2011-04-27
�޸��ˣ� 
��  �ڣ� 
��  ���� ʵʱ��Ϣ����Ӧ����< beps.417.001.01>���˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkbeps417.h"

using namespace ZFPT;

CRecvBkBeps417::CRecvBkBeps417()
{
    m_szOriSign = "";
    m_strMsgTp  = "beps.417.001.01";
}

CRecvBkBeps417::~CRecvBkBeps417()
{

}

INT32 CRecvBkBeps417::Work(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkBeps417::Work()");
    
     // ��������
    unPack(szMsg);
    
    // ҵ����
    CheckValues();
    
    // ���
    InsertDb(szMsg);
                
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkBeps417::Work()");
    return 0;
}

INT32 CRecvBkBeps417::unPack(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvBkBeps417::unPack()");
    
    int iRet = OPERACT_FAILED;
    
     // �����Ƿ�Ϊ��
    if (NULL == szMsg || '\0' == szMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��"); 
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }

	/*
    //��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    */
    m_strWorkDate = m_sWorkDate;      
    
    // ��������
    iRet = m_cBeps417.ParseXml(szMsg);
    if (OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= %d", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");
    }
    
    // ���ı�ʶ��
    m_strMsgID = m_cBeps417.MsgId;
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CRecvBkBeps417::unPack()");
    return OPERACT_SUCCESS;
}


/******************************************************************************
*  Function:   CheckValues
*  Description:ҵ����
*  Input:	   ��
*  Output:	   
*  Return:	   0   : �����ɹ�,
			   ����: ����ʧ��
*  Others:	   ��
*  Author:	   zys
*  Date:	   2011-04-20
*******************************************************************************/
INT32 CRecvBkBeps417::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CSendBeps417::CheckValues");

    /*int iRet = OPERACT_FAILED;

    //������޼��
    iRet = isOutOfLimit(m_dbproc, 
                        m_cbpbdsendlist.m_msgtp.c_str(), 
                        m_cbpbdsendlist.m_purpprtry.c_str(),
                        m_cbpbdsendlist.m_amount, 
                        m_sErrMsg);
    if ( OPERACT_SUCCESS != iRet)
    {
        return iRet;
    }
    
    //�����кż��
    iRet = isBankRight(m_dbproc, m_cbpbdsendlist.m_instddrctpty.c_str(), m_sErrMsg);
    if ( 0 != iRet)
    {
        return OPERACT_FAILED;
    }*/
    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CSendBeps417::CheckValues"); 
    return OPERACT_SUCCESS;
}


/******************************************************************************
*  Function:   InsertDb
*  Description:�������
*  Input:	   ��
*  Output:	   
*  Return:	   0   : �����ɹ�,
			   ����: ����ʧ��
*  Others:	   ��
*  Author:	   zys
*  Date:	   2011-04-26
*******************************************************************************/
INT32 CRecvBkBeps417::InsertDb(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkBeps417::InsertDb()");
    
    string strTemp = "";
    char   sTemp[128 + 1] = {0};
    string strTagVal = "";
    int    iRet;
    
    //��������
    SETCTX(m_cBpcstinfcxl);
    
    m_cBpcstinfcxl.m_msgid              =   m_cBeps417.MsgId                         ;    //���ı�ʶ��
    m_cBpcstinfcxl.m_workdate           =   m_cBeps417.CreDtTm                       ;    //���ķ���ʱ��
    m_cBpcstinfcxl.m_instgdrctpty       =   m_cBeps417.InstgDrctPty                  ;    //����ֱ�Ӳ������
    //m_cBpcstinfcxl.m_mesgid             =   m_cBeps417.GrpHdrInstgPty              ;    //����������
    m_cBpcstinfcxl.m_instddrctpty       =   m_cBeps417.InstdDrctPty                  ;    //����ֱ�Ӳ������
    //m_cBpcstinfcxl.m_mesgid             =   m_cBeps417.GrpHdrInstdPty              ;    //���ղ������
    //"BEPS"                              =   m_cBeps417.SysCd                         ;    //ϵͳ���
    //m_cBpcstinfcxl.m_mesgid             =   m_cBeps417.Rmk                         ;    //
    m_cBpcstinfcxl.m_oricxlmsgid        =   m_cBeps417.RealTmInfRvslRspnOrgnlMsgId   ;    //ԭ�������ı�ʶ��
    m_cBpcstinfcxl.m_oricxlinstgdrctpty =   m_cBeps417.RealTmInfRvslRspnOrgnlInstgPty;    //ԭ��������������
    m_cBpcstinfcxl.m_oricxlmsgtp        =   m_cBeps417.RealTmInfRvslRspnOrgnlMT;    //ԭ������������
    m_cBpcstinfcxl.m_status             =   m_cBeps417.Sts                           ;    //ҵ��״̬
    m_cBpcstinfcxl.m_rjctcd              =   m_cBeps417.RjctCd                       ;    //ҵ��ܾ�������
    m_cBpcstinfcxl.m_rjctinf            =   m_cBeps417.RjctInf                       ;    //ҵ�����������
    m_cBpcstinfcxl.m_rjcprcpty             =   m_cBeps417.PrcPty                      ;    //NPC��������
    m_cBpcstinfcxl.m_orimsgid           =   m_cBeps417.OrgnlTxOrgnlMsgId             ;    //ԭҵ���ı�ʶ��
    m_cBpcstinfcxl.m_oriinstgdrctpty    =   m_cBeps417.OrgnlTxOrgnlInstgPty          ;    //ԭҵ����������
    m_cBpcstinfcxl.m_orimsgtp           =   m_cBeps417.OrgnlTxOrgnlMT;    //ԭҵ��������

    //��������
    iRet = m_cBpcstinfcxl.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg,"����ʵʱ��Ϣ������ʧ��[%d][%s]", iRet, m_cBpcstinfcxl.GetSqlErr());
        Trace(L_ERROR, __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkBeps417::InsertDb()");
    return OPERACT_SUCCESS;
}

/******************************************************************************
*  Function:   CheckSign417
*  Description:��ǩ
*  Input:	   ��
*  Output:	   
*  Return:	   0   : �����ɹ�,
			   ����: ����ʧ��
*  Others:	   ��
*  Author:	   zys
*  Date:	   2011-04-26
*******************************************************************************/
INT32 CRecvBkBeps417::CheckSign417()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkBeps417::CheckSign417");
    
    int    iRet      = 0;
    string strTemp   = "";
    string strTagVal = "";

    m_szOriSign = m_szOriSign + Trim(m_cBeps417.MsgId)                           + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps417.CreDtTm)                         + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps417.InstgDrctPty)                    + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps417.GrpHdrInstgPty)                  + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps417.InstdDrctPty)                    + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps417.GrpHdrInstdPty)                  + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps417.SysCd)                           + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps417.Rmk)                             + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps417.RealTmInfRvslRspnOrgnlMsgId)     + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps417.RealTmInfRvslRspnOrgnlInstgPty)  + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps417.RealTmInfRvslRspnOrgnlMT)     + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps417.Sts)                             + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps417.RjctCd)                          + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps417.RjctInf)                         + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps417.PrcPty)                          + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps417.OrgnlTxOrgnlMsgId)               + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps417.OrgnlTxOrgnlInstgPty)            + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps417.OrgnlTxOrgnlMT)               + "|";
    
    char *sOrigenStr = new char[4096];
    
    memset(sOrigenStr, 0x00, 4096 * sizeof(char));
    strcpy(sOrigenStr, m_szOriSign.c_str());

    iRet = checkSign(m_dbproc,signTrim(sOrigenStr),
                            (char *)m_cBeps417.m_szDigitSign.c_str(),
                            Trim(m_cBpcstinfcxl.m_instgdrctpty).c_str());
    if( RTN_SUCCESS != iRet)
    {
        delete [] sOrigenStr;
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "����ǩ����֤δͨ��:[%d]!", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_CHECKSIGN_FAIL, "����ǩ����֤δͨ��");
    }
    
    delete [] sOrigenStr;
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkBeps417::CheckSign417");
    return OPERACT_SUCCESS;
}


