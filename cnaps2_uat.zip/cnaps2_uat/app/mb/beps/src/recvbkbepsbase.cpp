/******************************************************************** 
文件名： recvbkbepsbase.cpp
创建人： zhj
日  期： 2011-03-03
修改人： 
日  期： 
描  述： beps往账处理基类 
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "ccms990.h"
#include "recvbkbepsbase.h"
#include "cmtfileoperator.hpp"
#include "sysmsgonlinectrl.h"
#include "syscomsendmb.h"
using namespace ZFPT;

extern int          g_xmlpack;
extern char		g_MQmgr[256];
extern char		g_MqTxtPath[256];
extern char		g_SendQueue[128];
extern char		g_SendCCMSQueue[128];
extern char     g_bkSendBeps[128];
extern char     g_SapBank[17];
extern int      g_iCfcaSign;
extern char        g_msgpath[128];
extern char        g_SendBkRtnQueue[128];

CRecvbkBepsBase::CRecvbkBepsBase()
{
    m_strBizCode	= "";
    m_strRcvMsgID	= "";
    m_strMsgID		= "";
    m_bIfOptBigData = true;
    memset(m_szErrMsg, 0, sizeof(m_szErrMsg));
	memset(m_szOprUser, 0x00, sizeof(m_szOprUser));
	memset(m_szOprUserNetId,0x00, sizeof(m_szOprUserNetId));
    memset(m_sWorkDate, 0x00, sizeof(m_sWorkDate));
    m_strWorkDate	= "";
    m_iMsgVer		= 0;
    m_strMsgTp		= "";
	m_szOriSign		= "";
	iRet            = -1;
	m_strSendMsg    = "";
	memset(m_sCommHead, 0x00, sizeof(m_sCommHead));

    m_bToSendto = false;
}

CRecvbkBepsBase::~CRecvbkBepsBase()
{

}

/******************************************************************
当有不定长字段时,不要使用此函数,但可以使用表示长度的字段放在iArrary相应下标位置仍可使用.见recvpkg002,"30102"时的用法
iArray 业务附加字段中除循环以上的所有字段长度值,不要加循环长度
iArraySize 数组下标值
iNum   有循环的附加域时,填明细数目
iLen   有循环的附加域时,填单笔明细长度
hdf/20110711
******************************************************************/
void CRecvbkBepsBase::AddAppData(int iArray[], const char* strAppData, string& szDstData, int iArraySize, int iNum, int iLen)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbkBepsBase::AddAppData...");
    
    int offset = 0;
    int j = 0;

    for (int i=1; i<=iArraySize; i++)
    {
        char cDst[512] = {0};
        memcpy(cDst, strAppData + offset, iArray[i-1]);
        offset+=iArray[i-1];
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cDst[%s][%d]", cDst, iArray[i-1]);
        if(0 != strcmp(cDst, ""))
        {
            szDstData+=":72C:";
            szDstData.append(cDst);        
        }
    }

    if (iNum > 0)
    {
        for (int i = 1; i<=iNum; i++)
        {
            char cDst[512] = {0};
            memcpy(cDst, strAppData + offset, iLen);
            offset+=iLen;
            szDstData+=":72C:";
            szDstData.append(cDst);
        }
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbkBepsBase::AddAppData...");
}

void CRecvbkBepsBase::AddSign(const char *srcSign, char *dstSign, int iFlag)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbkBepsBase::AddSign...");
    
    char *Str = new char[strlen(srcSign) + 1];
    ISNULL(Str);
    strcpy(Str, srcSign);
    int iRet = digitSign(m_dbproc, signTrim(Str), dstSign, SYS_BEPS, iFlag);
    DELPOINT(Str);
	if( RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "数字签名加签失败!");
		PMTS_ThrowException(OPT_DIGITSIGN_FAIL);
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbkBepsBase::AddSign...");

}

void CRecvbkBepsBase::CheckSign(const char *srcSign, const char *dstSign, const char * sSendBankCode, int iFlag)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbkBepsBase::CheckSign...");
    
	if(1 == g_iCfcaSign)//验签名
	{
	    string strSendBankCode = sSendBankCode;
		
	    char *Str = new char[strlen(srcSign) + 1];
	    ISNULL(Str);
	    strcpy(Str, srcSign);
	    int iRet = checkSign(m_dbproc,signTrim(Str),
	                            (char *)dstSign,
	                            Trim(strSendBankCode).c_str(),
	                            iFlag);
	    DELPOINT(Str);
		if( RTN_SUCCESS != iRet)
		{
			Trace(L_ERROR, __FILE__, __LINE__,NULL, "数字签名验证未通过!");
			PMTS_ThrowException(__FILE__, __LINE__, OPT_CHECKSIGN_FAIL, "数字签名验证未通过");
		}
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbkBepsBase::CheckSign...");

}

int CRecvbkBepsBase::AddQueue(string msgtx, int length)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbkBepsBase::AddQueue...");
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "消息内容:m_strSendMsg = %s ", msgtx.c_str());
    
    int iRet = m_cMQAgent.PutMsg(g_SendQueue, msgtx.c_str(), length);
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "往MQ发送消息失败！");
		PMTS_ThrowException(OPT_MQ_ADD_FAIL);
	}
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbkBepsBase::AddQueue...");
    return iRet;
}

int CRecvbkBepsBase::AddBkRtnQueue(string msgtx, int length)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbkBepsBase::AddQueue...");
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "消息内容:m_strSendMsg = %s ", msgtx.c_str());    

    int iRet = m_cMQAgent.PutMsg(g_SendBkRtnQueue, msgtx.c_str(), length);
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "往MQ发送消息失败！");
		PMTS_ThrowException(OPT_MQ_ADD_FAIL);
	}
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbkBepsBase::AddQueue...");
    return iRet;
}

int CRecvbkBepsBase::AddSendtoQueue(string msgtx, int length)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbkBepsBase::AddQueue...");
    m_strSendMsg = "";
    m_strSendMsg = m_sCommHead +  msgtx;    //如果没有接入支付平台，m_sCommHead为空，长度为0
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "消息内容:m_strSendMsg = %s  length=%d", m_strSendMsg.c_str(), length+strlen(m_sCommHead));
    
    int iRet = m_cMQAgent.PutMsg(g_bkSendBeps, m_strSendMsg.c_str(), length+strlen(m_sCommHead));
    if(iRet != RTN_SUCCESS)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "往MQ发送消息失败！");
		PMTS_ThrowException(OPT_MQ_ADD_FAIL);
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbkHvpsBase::AddQueue...");
    return iRet;
}

void CRecvbkBepsBase::Init()
{
    int iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS, g_SapBank);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");	
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
}

INT32 CRecvbkBepsBase::doWork(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbkBepsBase::doWork()");	

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "i get a msg[%s]", pchMsg);		

    int iRet = RTN_FAIL;
    char sRet[15 + 1] = { 0 };
    try
    {	
    	//1、获取连接
    	//GetMqConn();
		
        //2、获取连接
        //GetDBConnect();
		
        Init();

        //4、子业务入口
        iRet = Work(pchMsg);
        if (SUCCESSED == iRet) /*成功:*/
        {


            SETCTX(m_cBprecvmsg);
            m_bIfOptBigData = true;    // 操作大文本表

            m_cBprecvmsg.commit(); 

            int ilen = strlen (pchMsg) ;

          
            //判断报文是发送到sendto或直接发到人行
            if(m_bToSendto)
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "jejtest");
                //ab jienjun
                if(!SendNotifyMsg(m_szOrgnlMbMsgId,
                           m_sendbank.c_str(),
                           m_sSysFlg.c_str(),
                           m_sMegType.c_str(),
                           m_sBusiType.c_str()))
                {
                 Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "SendNotifyMsg error");
                 return RTN_FAIL;
                }    
                DelBpRecvMsg();
            }    
            else
            {   
                string strsendmsg;
                //将报文发送到人行MQ队列
                if("" != m_strPkgmsg)
                {
                    strsendmsg = m_strPkgmsg;
                }
                else
                {
                    strsendmsg = pchMsg;
                }
                if(0 == m_cMQAgent.PutMsg ( g_SendQueue, strsendmsg.c_str(), strsendmsg.length() ) ) 
                {
                    //3、回应990
                    Send990(pchMsg, 0);         
                    DelBpRecvMsg();
                    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Send CCPC SUCCESS");
                }    
                else
                {
                    //3、回应990
                    Send990(pchMsg, -1);                 
                    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "SEND CCPC FAILED");
                }
               
            }                     
           
        }
        else
        {
            //3、回应990
            Send990(pchMsg, iRet);
        
            Trace(L_ERROR, __FILE__, __LINE__, NULL, "子业务处理失败!iRet = [%d]",iRet);
        }
		 m_cMQAgent.Commit();

    }
    catch(CException &e)
    {        
        sprintf(m_szErrMsg, "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);

		m_cMQAgent.Commit();
        //异常处理
       iRet = DoException(pchMsg, e.code(), e.what());

    }
    catch(CT_CommException &e)
    {
        sprintf(m_szErrMsg, "parser msg error,error info:[%s] file:[%s] line:[%d]" ,e.GetErrInfo(),e.GetFileNameEx(),e.GetLine());
    
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_szErrMsg);
        m_cMQAgent.Commit();

        iRet = DoException(pchMsg, OPT_PRS_MSG_FAIL, e.GetErrInfo());
    }
/*    
    catch(...)
    {
         Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "未知异常截获！ " );
         m_cMQAgent.Commit();
         iRet = DoException(pchMsg, OTH_ERR, "未知异常！");
    }
*/    
	//5、释放连接
	//g_DBConnPool->PutConnect(m_dbproc); 

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbkBepsBase::doWork()");	

    return iRet;
}


/******************************************************************************
*  Function:   GetDBConnect
*  Description:获取数据库连接
*  Input:      无
*  Output:     无
*  Return:     无
*  Others:     无
*  Author:     zys
*  Date:       2011-03-01
*******************************************************************************/
void CRecvbkBepsBase::GetDBConnect(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbkBepsBase::GetDBConnect()");	
    char	sSapBank[14 + 1]	= { 0 };
    int bRet = 0;
    if(0 == g_DBConnPool->GetConnect(m_dbproc))
    {

        bRet = GetSysParam(m_dbproc,"01", sSapBank);
        if(bRet !=0)
        {
            if(0 == g_DBConnPool->DBReconnect(m_dbproc))
            {
                bRet = GetSysParam(m_dbproc,"01", sSapBank);
                if(!bRet)
                {
                    snprintf(m_szErrMsg, sizeof(m_szErrMsg), "CRecvBepsBase::GetDBConnect():获取数据库连接失败");
                    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
                    PMTS_ThrowException(DB_CNNCT_FAIL);
                }
            }
            else
            {
                snprintf(m_szErrMsg, sizeof(m_szErrMsg), "CRecvBepsBase::GetDBConnect():获取数据库连接失败");
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
                PMTS_ThrowException(DB_CNNCT_FAIL);
            }		
        }
    }
    else
    {
        if(0 == g_DBConnPool->DBReconnect(m_dbproc))
        {
            bRet = GetSysParam(m_dbproc,"01", sSapBank);
            if(bRet !=0)
            {
                snprintf(m_szErrMsg, sizeof(m_szErrMsg), "CRecvBepsBase::GetDBConnect():获取数据库连接失败");
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
                PMTS_ThrowException(DB_CNNCT_FAIL);
            }
        }
        else
        {
            snprintf(m_szErrMsg, sizeof(m_szErrMsg), "CRecvBepsBase::GetDBConnect():获取数据库连接失败");
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
            PMTS_ThrowException(DB_CNNCT_FAIL);
        }		
    }

	m_charge.m_dbproc = m_dbproc;	//初始化记账类
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbkBepsBase::GetDBConnect()");		
}

/******************************************************************************
*  Function:   GetMqConn
*  Description:获取MQ连接
*  Input:      无
*  Output:     无
*  Return:     无
*  Others:     无
*  Author:     zys
*  Date:       2011-03-01
*******************************************************************************/
void CRecvbkBepsBase::GetMqConn(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbkBepsBase::GetMqConn()");	
	
	 //初始化MQ
    if(0 != m_cMQAgent.Init(g_MQmgr, g_MqTxtPath))
    {
    	snprintf(m_szErrMsg, sizeof(m_szErrMsg), 
			"CRecvbkBepsBase::GetMqConn(),Init Thread MQ manager failed.");
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		
        PMTS_ThrowException(OPT_GET_MQ_CNNCT_FAIL);
    }
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbkBepsBase::GetMqConn()");		
}


/******************************************************************************
*  Function:   DelBpRecvMsg
*  Description:从大额来帐通讯表hv_recvmsg里删除对应m_sMsgID的信息
*  Input:      无
*  Output:     无
*  Return:     0   : 操作成功,
               其他: 操作失败
*  Others:     无
*  Author:     zys
*  Date:       2011-02-17
*******************************************************************************/
INT32 CRecvbkBepsBase::DelBpRecvMsg(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbkBepsBase::DelBpRecvMsg");	

    // 若m_strRcvMsgID为空，则无法对应到bp_recvmsg中的记录
    if ("" == m_strRcvMsgID)
    {
        return RTN_FAIL;
    }

    if(m_iErrMsgFlag)
    {
        if( 0 != DelMsgFile(m_strRcvMsgID.c_str()))
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "del file [%s] failed",m_strRcvMsgID.c_str());
            PMTS_ThrowException(DB_DEL_FAIL);
        } 
        
        if(RTN_SUCCESS != DelRecvErrmsg(m_dbproc, m_iErrMsgFlag))
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "del row [%d] failed",m_iErrMsgFlag);
            PMTS_ThrowException(OTH_ERR);
        }

    }
    else
    {
        string strMsgFile = g_msgpath;
        strMsgFile += "/";
        strMsgFile += m_strRcvMsgID;
        
        if( 0 != DelMsgFile(strMsgFile.c_str()))
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "del file [%s] failed",strMsgFile.c_str());
            PMTS_ThrowException(OTH_ERR);
        } 

    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbkBepsBase::DelBpRecvMsg");	

    return RTN_SUCCESS;
}

INT32 CRecvbkBepsBase::DoException(LPCSTR pchMsg, int nErrCode, LPCSTR pchErrDesc)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbkBepsBase::DoException");	

    if(nErrCode == DB_CNNCT_FAIL)
    {
        //连接数据库失败，暂时不做任务操作
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "error:MB_PFR0020:[%s]", m_strRcvMsgID.c_str());
        return RTN_SUCCESS;
    }

    //3、回应990
    Send990(pchMsg, -1);

    // 回滚数据库
    int iRet = m_cBprecvmsg.setctx(m_dbproc);	
    if (0 != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error:%d", iRet);	
        return iRet;
    }
    m_cBprecvmsg.rollback();

    if(m_iErrMsgFlag != 0)
    {
        iRet = UpdateRecvErrmsg(m_dbproc, m_iErrMsgFlag);
        if(RTN_SUCCESS != iRet)
        {
            Trace(L_FATAL,  __FILE__,  __LINE__, NULL, "更改状态失败,写错误文件,客户端上看不到这条记录!!");
            WriteErrFile(pchMsg);
            return iRet;
        }
        
        m_cBprecvmsg.commit();
        return RTN_SUCCESS;
    }
    
    // 写小额来帐异常表
    if (0 == WriteErrTable(pchMsg, nErrCode, pchErrDesc))
    {
        m_bIfOptBigData = false;  // 不操作大文本表
//       DelBpRecvMsg();           // 删除小额来帐通讯表数据:这里失败，暂不处理
        m_cBprecvmsg.commit();
    }
    // 写小额来帐异常表失败，写入文件
    else
    {
        m_cBprecvmsg.rollback();
        WriteErrFile(pchMsg);  // 写文件
    }

    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbkBepsBase::DoException");
    return RTN_SUCCESS;
}

/******************************************************************************
*  Function:   WriteErrTable
*  Description:小额异常来帐表hv_recverrmsg插入记录
*  Input:      iInputErrCode 错误码
*  Output:	   
*  Return:	   0   : 操作成功,
			   其他: 操作失败
*  Others:	   无
*  Author:	   zys
*  Date:	   2011-02-21
*******************************************************************************/
INT32 CRecvbkBepsBase::WriteErrTable(LPCSTR pchMsg, int nErrCode, LPCSTR pchErrDesc)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbkBepsBase::WriteErrTable");

	int iRet = -1;

    // 错误码为空
    if (NULL == pchErrDesc || "" == m_strRcvMsgID)
    {
        return RTN_FAIL;
    }
    
	// 设置连接
	iRet = m_cCmrecverrmsg.setctx(m_dbproc);	
	if (0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error:%d", iRet);	
		return iRet;
	}

    // 获取工作日期
    char sWorkDate[8 + 1];
    char sCode[10]= {0};
    memset(sWorkDate, 0x00, sizeof(sWorkDate));
    GetWorkDate(m_dbproc, sWorkDate, SYS_BEPS);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "sWorkDate = %s", sWorkDate);

    // 给小额来帐异常表字段赋值
    m_cCmrecverrmsg.m_syscode    = "BKBP";
    //m_cCmrecverrmsg.m_msgtext    = pchMsg;

    m_cCmrecverrmsg.m_msgtext    = g_msgpath;
    m_cCmrecverrmsg.m_msgtext    += "/";
    m_cCmrecverrmsg.m_msgtext    += m_strRcvMsgID;
    
    m_cCmrecverrmsg.m_wrkdate    = sWorkDate;
    m_cCmrecverrmsg.m_msgtp      = m_ErrMsgTp; 
    m_cCmrecverrmsg.m_procstate  = "01"; 
    m_cCmrecverrmsg.m_proctimes  = 1; 
    m_cCmrecverrmsg.m_errcode    = itoa(sCode,nErrCode); 
    m_cCmrecverrmsg.m_errdesc    = pchErrDesc;

	// 往小额来帐异常表插入记录
	iRet = m_cCmrecverrmsg.insert();
	if (0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
            "m_cCmrecverrmsg.insert error:error code =[%d],error info = [%s]", iRet,m_cCmrecverrmsg.GetSqlErr());
		return iRet;
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbkBepsBase::WriteErrTable");

	return RTN_SUCCESS;
}

INT32 CRecvbkBepsBase::WriteErrFile(const char * pchErrText)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbkBepsBase::WriteErrFile()");

    time_t timep;
    struct tm *p;
    time(&timep);
    p = gmtime(&timep);

    char szchPathName[gc_nMaxPathLen] = {0};

    sprintf(szchPathName, "../errmsg/%d/%d/%d/beps/", p->tm_year + 1900, p->tm_mon + 1, p->tm_mday);

	bool bRet = createDeepDir(szchPathName);
    if(!bRet)
    {
        printf("异常文件目录创建失败!\n");
        return RTN_FAIL;
    }

    FILE* msgFile = NULL;

    char szchTime[8 + 1] = {0};
    sprintf(szchTime, "%02d%02d%02d", p->tm_hour, p->tm_min, p->tm_sec);
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "szchTime:%s", szchTime);
	
    string strFileName = szchPathName;
    strFileName += "beps";
    strFileName += "-";
    strFileName += m_strBizCode;
    strFileName += "-";
    strFileName += m_strMsgID;
    strFileName += "-";
    strFileName += szchTime;
    strFileName += ".txt";

    if (NULL != (msgFile = fopen(strFileName.c_str(), "w+")))
    {
        fprintf(msgFile, "%s", pchErrText);
        fclose(msgFile);
    }
    else
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "写异常文件失败");
        return RTN_FAIL;
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbkBepsBase::WriteErrFile()");

    return RTN_SUCCESS;
}


void CRecvbkBepsBase::Send990(LPCSTR pchMsg, int iRst)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbkBepsBase::Send990()");

	ccms990	oCcms990;
	char	sMsgRefId[20 + 1]	= { 0 };

	char	sOrignSender[14 + 1]= { 0 };
	char    sOrignReceiver[14 + 1]={ 0};
	char	sOrignSendDate[8 + 1]={ 0 };
	char	sOrignMsgType[20 + 1]={ 0 };
	char	sOrignMesgID[35 + 1]= { 0 };
	char	sOrignRefId[35 + 1] = { 0 };
	
	GetMsgIdValue(m_dbproc, sMsgRefId, eRefId, SYS_BEPS, g_SapBank, NULL, m_sWorkDate);

    //判断报文是一代还是二代
	//m_iMsgVer =  JudgeMsgVer(pchMsg);work类里已经判断过
    
	//组报头
	if(MSG_VER_2ND == m_iMsgVer)
	{

		oCcms990.m_PMTSHeader.ParsePMTSMsgHeader(pchMsg);

		strncpy(sOrignSender, oCcms990.m_PMTSHeader.getOrigSender(), sizeof(sOrignSender)-1);
		strcpy(sOrignSendDate, oCcms990.m_PMTSHeader.getOrigSendDate());
		strcpy(sOrignMsgType, oCcms990.m_PMTSHeader.getMesgType());
		strcpy(sOrignMesgID, oCcms990.m_PMTSHeader.getMesgID());
		strcpy(sOrignRefId, oCcms990.m_PMTSHeader.getMesgRefID());

		m_ErrMsgTp = sOrignMsgType;
		
		// 当收到的是<ccms.990.001.02>报文，不需要回复
		if (strncmp(sOrignMsgType, "ccms.990.001.02", 15) == 0)
		{
			return;
		}
                //alter 20180201
		oCcms990.m_PMTSHeader.SetPMTSXMlHeader(oCcms990.m_PMTSHeader.getOrigReceiverSID(),
                                  oCcms990.m_PMTSHeader.getOrigSenderSID(), 
                                  m_sWorkDate,
                                  oCcms990.m_PMTSHeader.getOrigReceiver(),
                                  sOrignSender,
                                  "ccms.990.001.02",
                                  sMsgRefId
                                  );
		//alter end
	}
	else if(MSG_VER_1ST == m_iMsgVer)
	{
	    char szCmtno[3+1]={0};
		strncpy(szCmtno, pchMsg+11, 3);
		strncpy(sOrignSender, pchMsg+18, 12);
		strncpy(sOrignReceiver, pchMsg+30, 12);
		strncpy(sOrignSendDate, pchMsg+84, 8);
		strncpy(sOrignMesgID, pchMsg+44, 20);
		strncpy(sOrignRefId, pchMsg+64, 20);
		
		// 当收到的是910报文，不需要回复
		if (strncmp(sOrignMsgType, "910", 3) == 0)
		{
			return;
		}
		//alter in 20180201
		oCcms990.m_PMTSHeader.SetPMTSXMlHeader(oCcms990.m_PMTSHeader.getOrigReceiverSID(),
                                  oCcms990.m_PMTSHeader.getOrigSenderSID(), 
                                  m_sWorkDate,
                                  sOrignReceiver,
                                  sOrignSender,
                                  "ccms.990.001.02",
                                  sMsgRefId
                                  );
               //alter end
        atoi(szCmtno) > 13?\
        sprintf(sOrignMsgType,"BCMT%s",szCmtno):\
        sprintf(sOrignMsgType,"BPKG%s",szCmtno);

        m_ErrMsgTp = sOrignMsgType + 1;
	}
		
	oCcms990.OrigSndr					= sOrignSender;
	oCcms990.OrigSndDt					= sOrignSendDate;
	oCcms990.MT							= sOrignMsgType;
	oCcms990.MsgId 						= sOrignMesgID;
	oCcms990.MsgRefId					= sOrignRefId;

    if(!iRst)
    {
        oCcms990.MsgPrcCd                   = "MBFI0000";
    }
    else
    {
        oCcms990.MsgPrcCd                   = "MBFE0001";
    }
	
	oCcms990.CreateXml();

	int iRet = AddBkRtnQueue(oCcms990.m_sXMLBuff.c_str(),  oCcms990.m_sXMLBuff.length());
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "往MQ队列发送通讯级确认报文失败！");
		PMTS_ThrowException(OPT_MQ_ADD_FAIL);
	}
	m_cMQAgent.Commit();
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbkBepsBase::Send990()");
}

void CRecvbkBepsBase::DirectInter(LPCSTR cpSendBank,
								LPCSTR cpRecvBank, 
								LPCSTR cpRecvSapBank,  
								LPCSTR cpTxid, 
								LPCSTR cpNpcMsg)
{
    return;
    #if 0
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbkBepsBase::DirectInter()");
    
    int iRet = RTN_FAIL;
    
    CSysmsgonlinectrl oSysmsgonlinectrl;
    
    oSysmsgonlinectrl.m_cmtno = m_strMsgTp.c_str();
    oSysmsgonlinectrl.m_sysid = "BEPS";
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "oSysmsgonlinectrl.m_cmtno[%s]",oSysmsgonlinectrl.m_cmtno.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "oSysmsgonlinectrl.m_sysid[%s]",oSysmsgonlinectrl.m_sysid.c_str());
    
    SETCTX(oSysmsgonlinectrl);

/*	          //    bk进程不需要查表       修改HPCH
    iRet = oSysmsgonlinectrl.findByPK();
    if(OPERACT_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg, "oSysmsgonlinectrl findByPK fail:	[%d][%s]", 
        iRet, oSysmsgonlinectrl.GetSqlErr());
        Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(DB_GET_DATA_FAIL);
    }
    
    if("1" != oSysmsgonlinectrl.m_recvscflag)//不是直连的，直接返回
    {
        return;
    }

*/   

    CSyscomsendmb oSyscomsendmb;
    
    oSyscomsendmb.m_workdate = m_strWorkDate;// 委托日期
    oSyscomsendmb.m_msgid = cpTxid;// 明细标志号
    oSyscomsendmb.m_sendbank = cpSendBank;// 发起行行号
    oSyscomsendmb.m_recvbank = cpRecvBank;// 接收行行号
    oSyscomsendmb.m_recvsapbank = cpRecvSapBank;// 接收清算行行号
    oSyscomsendmb.m_msgtype = m_strMsgTp;// 报文类型
    oSyscomsendmb.m_sysflag = "BEPS";// 系统标识
    oSyscomsendmb.m_procstate = "01";// 处理状态 01:待处理 02：正在处理03：处理失败 04：待手工派发
    oSyscomsendmb.m_proctimes = 0;// 处理次数
    oSyscomsendmb.m_recvtarget = "0";// 业务来源标志 0：正常 1：手工派发
    
    SETCTX(oSyscomsendmb);
    
    iRet = oSyscomsendmb.insert();
    if (OPERACT_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg, "oSyscomsendmb insert fail [%d][%s]", 
            iRet, oSyscomsendmb.GetSqlErr());
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
    }
    
    Trace(L_INFO,	__FILE__,  __LINE__, NULL, "LEAVE CRecvbkBepsBase::DirectInter()");
    #endif
}

/******************************************************************************
*  Function:   CheckPkgMac
*  Description:一代报文核押凼数(南洋专用)
*  Input:      oPkgBase 
*              pRefStr   20位密押参考值
               pSendSapBank 发起清算行号
*  Return:     0：   成功
*              其他：失败
*  Others:     无
*  Author:     aps-lel
*  Date:       2012-02-16
*******************************************************************************/
int CRecvbkBepsBase::CheckPkgMac(pkgbase& oPkgBase,const char *pRefStr,const char* pSendSapBank)
{
	Trace(L_INFO,	__FILE__,  __LINE__, NULL, "LEAVE CRecvbkBepsBase::CheckPkgMac()");
	
	int iRet = -1;
	
	if(1 == g_iCfcaSign)//验核押
	{
				
	    string strCodeMac;//取核押串
	    oPkgBase.GetMacStr(oPkgBase,strCodeMac);
	    
		//iRet = CheckMac(m_dbproc,pRefStr,strCodeMac.c_str(),pSendSapBank);
		iRet = CheckMac(m_dbproc,pRefStr,strCodeMac.c_str());
		if(0 != iRet)
	    {
	    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CheckPkgMac failed[%d]" ,iRet);
	    	PMTS_ThrowException(__FILE__, __LINE__, OPT_CHECKMAC_FAIL, "核押失败");
	    }
	}
	
	Trace(L_INFO,	__FILE__,  __LINE__, NULL, "LEAVE CRecvbkBepsBase::CheckPkgMac()");
	
	return iRet;
}


void CRecvbkBepsBase::GetCodeMac(pkgbase& oPkgBase,char* pMac)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendPkgPack::GetCodeMac()");
    
    string strCodeMac;//取加押串
    oPkgBase.GetMacStr(oPkgBase,strCodeMac);
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strCodeMac = [%s]", strCodeMac.c_str());
    
    //int iRetCode = CodeMac(m_dbproc,strCodeMac.c_str(),m_strSendBank.c_str(),pMac);
    int iRetCode = CodeMac(m_dbproc,strCodeMac.c_str(),pMac);
    if (RTN_SUCCESS != iRetCode) 
	{	
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "编押失败");
		PMTS_ThrowException(__FILE__, __LINE__, OPT_CODEMAC_FAIL, "编押失败");
	}
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendPkgPack::GetCodeMac()");
}

bool CRecvbkBepsBase::SendNotifyMsg(const char* pMsgId,const char* pSendBank,const char* pSysFlg,const char* pMsgType,const char* pBusiType)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvMb111::SendNotifyMsg()");
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER pSysFlg[%]",pSysFlg);
    
    if(!pMsgId || !pSendBank || !pSysFlg || !pMsgType)
    {
    	return false;
    }
    
    int iRet = RTN_FAIL;
    
    char szSendQ[128] = {0};
    char szVerType[3 +1] = {0};//鎶ユ枃绫诲瀷锛歅KG,CMT,XML
    char szMsgNo[3 +1] = {0};//鎶ユ枃缂栧彿:001,111锛?03绛?    
	if(0 == STRNCASECMP("CMT",pMsgType,3) || 0 == STRNCASECMP("PKG",pMsgType,3))
	{
		strncpy(szVerType,pMsgType,3);	
		strncpy(szMsgNo,pMsgType+3,3);
	}
	else
	{
		strcpy(szVerType,"XML");	
		strncpy(szMsgNo,pMsgType+5,3);
	}  	  		
	
    stuMsgHead stuMsg;
    memset(&stuMsg,0x00,sizeof(stuMsg));
    
    sprintf(stuMsg.szMsgLen, "%08d", sizeof(stuMsg));
    sprintf(stuMsg.szSysType, "%s", pSysFlg);
    sprintf(stuMsg.szMsgUse, "%s", "2");
    sprintf(stuMsg.szMsgTypeFlag, "%s", szVerType);
    sprintf(stuMsg.szMsgType, "%s", szMsgNo);
    sprintf(stuMsg.szMsgFlagNO, "%-28s", pMsgId);
    sprintf(stuMsg.szSndNO, "%-14s", pSendBank);
	sprintf(stuMsg.szOprUser, "%-20s", SP_MB_USERID);//SP_MB_USERID:鐗规畩瀛楃涓?鏀跺埌鍙戦€佸線鎶ユ秷鎭椂锛岀敤瀹冩潵鍒ゆ柇涓氬姟鏉ユ簮)
	sprintf(stuMsg.szOprUserNetId, "%-20s", "000000");
	sprintf(stuMsg.szMsgKind, "%-5s", pBusiType);
	
	string sSendMsg;
	
    sSendMsg  = stuMsg.szMsgLen;
	sSendMsg += stuMsg.szSysType;
	sSendMsg += stuMsg.szMsgUse;
	sSendMsg += stuMsg.szMsgTypeFlag;
	sSendMsg += stuMsg.szMsgType;
	sSendMsg += stuMsg.szMsgFlagNO;
	sSendMsg += stuMsg.szSndNO;
	sSendMsg += stuMsg.szOprUser;
	sSendMsg += stuMsg.szOprUserNetId;
	sSendMsg += stuMsg.szMsgKind;
	
    iRet = AddSendtoQueue(sSendMsg, sSendMsg.length());
    if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "寰€MQ鍙戦€佹秷鎭け璐ワ紒");
		PMTS_ThrowException(OPT_MQ_ADD_FAIL);
	}

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvMb111::SendNotifyMsg()");

	return true;
}

void CRecvbkBepsBase::AddAppData(string& strPmttpprtry, int iArray[], const char* strAppData, string& szDstData, int iArraySize, int iNum, int iLen)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBepsBase::AddAppData...");
    
    int offset = 0;
    int j = 0;
    
    if ( "00102" == strPmttpprtry )
    {
	    for (int i=1; i<=iArraySize; i++)
	    {
	        char cDst[512] = {0};
	        memcpy(cDst, strAppData + offset, iArray[i-1]);
	        offset+=iArray[i-1];
	        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cDst[%s][%d]", cDst, iArray[i-1]);
	        if(0 != strcmp(cDst, ""))
	        {
	            szDstData+=":72C:";
	            if (15 == iArray[i-1])
	            {
	            	szDstData+="RMB";
	            }
	            szDstData.append(cDst);        
	        }
	    }
    }
    else if ( "00103" == strPmttpprtry || "00113" == strPmttpprtry )
    {
	    for (int i=1; i<=iArraySize; i++)
	    {
	        char cDst[512] = {0};
	        memcpy(cDst, strAppData + offset, iArray[i-1]);
	        offset+=iArray[i-1];
	        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cDst[%s][%d]", cDst, iArray[i-1]);
	        if(0 != strcmp(cDst, ""))
	        {
	            szDstData+=":72C:";
	            if (18 == iArray[i-1])
	            {
	            	szDstData+="RMB";
	            }
	            szDstData.append(cDst);        
	        }
	    }
	
	    if (iNum > 0)
	    {
	        for (int i = 1; i<=iNum; i++)
	        {
	            char cDst[512] = {0};
	            iLen = 10;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	            iLen = 20;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	            iLen = 18;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData+="RMB";
	            szDstData.append(cDst);
	        }
	    }
    }
    else if ( "20103" == strPmttpprtry || "20104" == strPmttpprtry || 
    		  "20003" == strPmttpprtry || "20004" == strPmttpprtry)
    {
	    for (int i=1; i<=iArraySize; i++)
	    {
	        char cDst[512] = {0};
	        memcpy(cDst, strAppData + offset, iArray[i-1]);
	        offset+=iArray[i-1];
	        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cDst[%s][%d]", cDst, iArray[i-1]);
	        if(0 != strcmp(cDst, ""))
	        {
	            szDstData+=":72C:";
	            if (18 == iArray[i-1])
	            {
	            	szDstData+="RMB";
	            }
	            szDstData.append(cDst);        
	        }
	    }
	
	    if (iNum > 0)
	    {
	        for (int i = 1; i<=iNum; i++)
	        {
	            char cDst[512] = {0};
	            iLen = 15;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	            iLen = 20;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	            iLen = 20;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	            iLen = 1;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	            iLen = 18;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData+="RMB";
	            szDstData.append(cDst);
	        }
	    }
    }
    else if ( "30102" == strPmttpprtry )
    {
	    for (int i=1; i<=iArraySize; i++)
	    {
	        char cDst[512] = {0};
	        memcpy(cDst, strAppData + offset, iArray[i-1]);
	        offset+=iArray[i-1];
	        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cDst[%s][%d]", cDst, iArray[i-1]);
	        if(0 != strcmp(cDst, ""))
	        {
	            szDstData+=":72C:";
	            if (15 == iArray[i-1])
	            {
	            	szDstData+="RMB";
	            }
	            szDstData.append(cDst);        
	        }
	    }
    }
    else if ( "30103" == strPmttpprtry )
    {
	    for (int i=1; i<=iArraySize; i++)
	    {
	        char cDst[512] = {0};
	        memcpy(cDst, strAppData + offset, iArray[i-1]);
	        offset+=iArray[i-1];
	        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cDst[%s][%d]", cDst, iArray[i-1]);
	        if(0 != strcmp(cDst, ""))
	        {
	            szDstData+=":72C:";
	            if (15 == iArray[i-1])
	            {
	            	szDstData+="RMB";
	            }
	            szDstData.append(cDst);        
	        }
	    }
    }
    else if ( "20005" == strPmttpprtry || "20105" == strPmttpprtry )
    {
	    for (int i=1; i<=iArraySize; i++)
	    {
	        char cDst[512] = {0};
	        memcpy(cDst, strAppData + offset, iArray[i-1]);
	        offset+=iArray[i-1];
	        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cDst[%s][%d]", cDst, iArray[i-1]);
	        if(0 != strcmp(cDst, ""))
	        {
	            szDstData+=":72C:";
	            if (18 == iArray[i-1])
	            {
	            	szDstData+="RMB";
	            }
	            szDstData.append(cDst);        
	        }
	    }
	
	    if (iNum > 0)
	    {
	        for (int i = 1; i<=iNum; i++)
	        {
	            char cDst[512] = {0};
	            iLen = 12;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	            iLen = 12;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	            iLen = 18;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData+="RMB";
	            szDstData.append(cDst);
	            iLen = 12;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	            iLen = 18;
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData+="RMB";
	            szDstData.append(cDst);
	        }
	    }
    }
    else
    {
	    for (int i=1; i<=iArraySize; i++)
	    {
	        char cDst[512] = {0};
	        memcpy(cDst, strAppData + offset, iArray[i-1]);
	        offset+=iArray[i-1];
	        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cDst[%s][%d]", cDst, iArray[i-1]);
	        if(0 != strcmp(cDst, ""))
	        {
	            szDstData+=":72C:";
	            szDstData.append(cDst);        
	        }
	    }
	
	    if (iNum > 0)
	    {
	        for (int i = 1; i<=iNum; i++)
	        {
	            char cDst[512] = {0};
	            memcpy(cDst, strAppData + offset, iLen);
	            offset+=iLen;
	            szDstData+=":72C:";
	            szDstData.append(cDst);
	        }
	    }
	}

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBepsBase::AddAppData...");
}

void CRecvbkBepsBase::doMd5(string& strSrc, string& strDst)
{
    MD5 md5;
    md5.Hash_Start();
    md5.Hash_PatchBuffer((unsigned char*)strSrc.c_str(), strSrc.length());
    strDst =  md5.Hash_End().GetBuffer(0);
}

void CRecvbkBepsBase::SetFieldAsUtf8(const char* szField, string& strDst)
{
    int iLen = strlen(szField);
    //if( !IsUTF8(szField, iLen) ){
    if( 1 ){
        char* pBuffer = new char[iLen*3+1];
        memset(pBuffer, 0x00, iLen*3+1);
        if(!changeEncode((char*)szField, pBuffer, "GB18030", "UTF-8")){
            Trace(L_DEBUG, __FILE__, __LINE__,
                NULL, "GB18030->UTF-8 Failed!");
            if(!changeEncode((char*)szField, pBuffer, "GBK", "UTF-8")){
                Trace(L_DEBUG, __FILE__, __LINE__,
                    NULL, "GBK->UTF-8 Failed!");
            }
        }
        strDst = pBuffer;
        delete[] pBuffer;
        pBuffer = NULL;
    }
    else{
        strDst = szField;
    }
}

void CRecvbkBepsBase::SetFieldAsUtf8(char* szField, string& strDst)
{
    int iLen = strlen(szField);
    //if( !IsUTF8(szField, iLen) ){
    if( 1 ){
        char* pBuffer = new char[iLen*3+1];
        memset(pBuffer, 0x00, iLen*3+1);
        if(!changeEncode(szField, pBuffer, "GB18030", "UTF-8")){
        	Trace(L_DEBUG, __FILE__, __LINE__,
        			NULL, "GB18030->UTF-8 Failed!");
            if(!changeEncode(szField, pBuffer, "GBK", "UTF-8")){
            	Trace(L_DEBUG, __FILE__, __LINE__,
            	        	NULL, "GBK->UTF-8 Failed!");
            }
        }
        strDst = pBuffer;
        delete[] pBuffer;
        pBuffer = NULL;
    }
    else{
        strDst = szField;
    }
}


