/******************************************************************** 
文件名： recvbkbeps398.cpp
创建人： handongfeng
日  期   ： 2011-03-07
修改人： 
日  期： 
描  述： 
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkbeps398.h"

CRecvbkbeps398::CRecvbkbeps398()
{

}

CRecvbkbeps398::~CRecvbkbeps398()
{
}

void CRecvbkbeps398::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "ENTER CRecvbkbeps398::SetData");

    m_Bpbktocstdcntfctn.m_traddt = m_beps398.TradDt; 
    m_Bpbktocstdcntfctn.m_processcode = ""; 
    m_Bpbktocstdcntfctn.m_rjcprtry = ""; 
    m_Bpbktocstdcntfctn.m_rjclinf = ""; 
    m_Bpbktocstdcntfctn.m_procstate = PR_HVBP_08; 
    m_Bpbktocstdcntfctn.m_workdate = m_beps398.MsgId.substr(0, 7);  
    m_Bpbktocstdcntfctn.m_msgtp = "beps.398.001.01"; 
    m_Bpbktocstdcntfctn.m_mesgid = m_beps398.m_PMTSHeader.getMesgID();; 
    m_Bpbktocstdcntfctn.m_mesgrefid = m_beps398.m_PMTSHeader.getMesgRefID(); 
    m_Bpbktocstdcntfctn.m_msgid = m_beps398.MsgId; 
    m_Bpbktocstdcntfctn.m_instgdrctpty = m_beps398.MsgRcptIssr; 
    m_Bpbktocstdcntfctn.m_instddrctpty = m_beps398.MsgRcptId; 
    m_Bpbktocstdcntfctn.m_addtlinf = ""; 
    m_Bpbktocstdcntfctn.m_chrgid = m_beps398.NtfctnId; 
    m_Bpbktocstdcntfctn.m_cusflag = m_beps398.DbtrId; 
    m_Bpbktocstdcntfctn.m_corprtnid = m_beps398.CdtrId; 
    m_Bpbktocstdcntfctn.m_purpprtry = m_beps398.NtryRef; 
    m_Bpbktocstdcntfctn.m_currency = m_beps398.Ccy; 
    m_Bpbktocstdcntfctn.m_pmtamt = atof(m_beps398.Amt.c_str()); 
    m_Bpbktocstdcntfctn.m_dbtrnm = m_beps398.DbtrNm; 
    m_Bpbktocstdcntfctn.m_dbtrid = m_beps398.DbtrAcctId; 
    m_Bpbktocstdcntfctn.m_dbtrissr = m_beps398.DbtrAcctIssr; 
    m_Bpbktocstdcntfctn.m_dbtrmmbid = m_beps398.DbtrAgtMmbId; 
    m_Bpbktocstdcntfctn.m_dbtrbrnchid = m_beps398.DbtrAgtId; 
    m_Bpbktocstdcntfctn.m_cdtrnm = m_beps398.CdtrNm; 
    m_Bpbktocstdcntfctn.m_cdtraccid = m_beps398.CdtrAcctId; 
    m_Bpbktocstdcntfctn.m_cdtrissr = m_beps398.CdtrAcctIssr; 
    m_Bpbktocstdcntfctn.m_cdtrmmbid = m_beps398.CdtrAgtMmbId; 
    m_Bpbktocstdcntfctn.m_cdtrbrnchid = m_beps398.CdtrAgtId; 
	m_Bpbktocstdcntfctn.m_rsflag = "1";

    SETCTX(m_Bpbktocstdcntfctn);
    iRet = m_Bpbktocstdcntfctn.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg,"insert error[%d][%s]", iRet,m_Bpbktocstdcntfctn.GetSqlErr());
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);		
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "LEAVE CRecvbkbeps398::SetData");
    return ;
}

int CRecvbkbeps398::Work(LPCSTR szMsg)
{
    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ENTER CRecvbkbeps398::Work()");

    // 解析报文
    unPack(szMsg);

    SetData();

    //核签
    //CheckSign398();

    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbkbeps398::Work()");
    return OPERACT_SUCCESS;
}

INT32 CRecvbkbeps398::unPack(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbkbeps398::unPack()...");
    // 报文是否为空
    if (NULL == szMsg || '\0' == szMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空"); 
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "报文为空");
    }
    //获取工作日期
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;    

    // 解析报文
    if (OPERACT_SUCCESS != m_beps398.ParseXml(szMsg))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错! ");	
        PMTS_ThrowException(OPT_PRS_MSG_FAIL);
        return OPERACT_FAILED;
    }

    m_strMsgID = m_beps398.MsgId;
    ZFPTLOG.SetLogInfo("398", m_strMsgID.c_str());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbkbeps398::unPack()...");
    return OPERACT_SUCCESS;
}

