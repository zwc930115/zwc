/******************************************************************** 
文件名： recvbeps392.cpp
创建人： caozhuojun
日  期： 2012-06-12
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2012  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkbeps392.h"

const char* _AgrmtDtls = "AgrmtDtls"; //协议明细列表

//
CRecvBkbeps392::CRecvBkbeps392()
{
    //m_ccmcl.m_msgtp = "beps.392.001.01";
	m_strMsgTp = "beps.392.001.01";
}

//
CRecvBkbeps392::~CRecvBkbeps392()
{
}

//__wsh 2012-05-25 //业务处理入口
int CRecvBkbeps392::Work(const char* szmsg)
{
	int iRet = -1;

	//解析报文
	UnPack(szmsg);

	//新增汇总来账记录
	InsertData_cl();

	//新增明细来账记录
	InsertData_list();

	//核签
	CheckSign392();
	
	return 0;
}

//__wsh 2012-05-25
INT32 CRecvBkbeps392::UnPack(const char* szMsg)
{
	Trace(L_DEBUG, __FILE__, __LINE__,
			NULL, "Enter CRecvBkbeps392::UnPack");
	int iRet = -1;

	if(NULL == szMsg || '\0' == szMsg[0]){
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "报文长度为空");
		PMTS_ThrowException(PRM_FAIL);
	}

	//解析报文
	if (OPERACT_SUCCESS != m_cBeps392.ParseXml(szMsg)){
		Trace(L_ERROR,  __FILE__,  __LINE__,
				NULL, "报文解析出错! iRet= %d", iRet);

		PMTS_ThrowException(__FILE__, __LINE__,
				OPT_PRS_MSG_FAIL, "报文解析出错");
	}

	//获取工作日期
	iRet = GetWorkDate(m_dbproc, m_sWorkDate,
			SYS_BEPS, m_cBeps392.InstgDrctPty.c_str());
	if(RTN_SUCCESS != iRet){
		Trace(L_ERROR,  __FILE__, __LINE__,
				NULL, "获取工作日期失败！");
		PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
	}
	m_strWorkDate = m_sWorkDate;

    //ZFPTLOG.SetLogInfo("392", m_cBeps392.MsgId.c_str());
    
	Trace(L_DEBUG, __FILE__, __LINE__,
			NULL, "Leave CRecvBkbeps392::UnPack");

	return OPERACT_SUCCESS;
}

//__wsh 2012-05-25 设置汇总表入库数据
INT32 CRecvBkbeps392::SetData_cl(void)
{
	int iRet = -1;

	m_ccmcl.m_workdate 		= m_strWorkDate;	 //工作日期
	m_ccmcl.m_msgtp 		= m_strMsgTp; 		 //报文类型
	m_ccmcl.m_mesgid		= m_cBeps392.m_PMTSHeader.getMesgID();   //通信级标识
	m_ccmcl.m_mesgrefid		= m_cBeps392.m_PMTSHeader.getMesgRefID();//通信参考号
	m_ccmcl.m_msgid			= m_cBeps392.MsgId;	         //报文标识
	m_ccmcl.m_instgdrctpty	= m_cBeps392.InstgDrctPty;   //发送直接参与行
	m_ccmcl.m_instgpty		= m_cBeps392.GrpHdrInstgPty; //发送参与行
	m_ccmcl.m_instddrctpty	= m_cBeps392.InstdDrctPty;   //接收直接参与行
	m_ccmcl.m_instdpty		= m_cBeps392.GrpHdrInstdPty; //接收参与行
	m_ccmcl.m_syscd			= m_cBeps392.SysCd;			 //系统号
	m_ccmcl.m_rmk			= m_cBeps392.Rmk;			 //备注
	m_ccmcl.m_srcflag		= "1";						 //往来报标识1:往报， 2：来报
	m_ccmcl.m_qryoroprtp	= m_cBeps392.QryOrOprTp;	 //查询类型
	m_ccmcl.m_ctrctagrmttp	= m_cBeps392.CtrctAgrmtTp;	 //合同类型
	m_ccmcl.m_procstate		= PR_HVBP_08;				 //处理状态，已收妥

	iRet = 0;
	return iRet;
}

//__wsh 2012-05-25 来账汇总记录入库
INT32 CRecvBkbeps392::InsertData_cl(void)
{
	int iRet = -1;

	SETCTX(m_ccmcl);

	//设置汇总数据
	iRet = SetData_cl();

	//插入数据
	iRet = m_ccmcl.insert();

	if(SQL_SUCCESS != iRet){
		char szErr[512] = {0};
		sprintf(szErr,
			"插入签约汇总表失败  iRet=%d cause=%s",
			iRet, m_ccmcl.GetSqlErr());
		Trace(L_ERROR, __FILE__, __LINE__,
				NULL, "%s", szErr);

		PMTS_ThrowException(__FILE__,
				__LINE__, DB_INSERT_FAIL, szErr);
	}

	return iRet;
}

//__wsh 2012-05-25 设置来账明细数据
INT32 CRecvBkbeps392::SetData_list(int iCount)
{
	int iRet = -1;

    //解析明细
    m_cBeps392.ParseDetail(iCount);
    
	//变更类型
	m_ccmlist.m_chngtpcd    = m_cBeps392.ChngTpCd;

	//协议号
	m_ccmlist.m_agrmtnb     = m_cBeps392.AgrmtNb;

	//付款人名称
	m_ccmlist.m_dbtrnm      = m_cBeps392.DbtrNm;

	//付款人账号
	m_ccmlist.m_dbtrid      = m_cBeps392.OthrId;

	//付款人开户行行号
	m_ccmlist.m_dbtrissr    = m_cBeps392.Issr;

	//付款清算行行号
	m_ccmlist.m_dbtrmmbid   = m_cBeps392.MmbId;

	//付款行行号
	m_ccmlist.m_dbtrbrnchid = m_cBeps392.BrnchIdId;

	//收款人名称
	m_ccmlist.m_cdtrnm      = m_cBeps392.CdtrNm;

    iRet = 0;
	return iRet;
}

//__wsh 2012-05-25
INT32 CRecvBkbeps392::InsertData_list(void)
{
	int iRet = -1;

	SETCTX(m_ccmlist);

	//设置公共部份明细
	m_ccmlist.m_workdate 	  = m_strWorkDate; 		     //工作日期
	m_ccmlist.m_msgid	      = m_cBeps392.MsgId;	     //报文标识
	m_ccmlist.m_instgdrctpty  = m_cBeps392.InstgDrctPty; //发送参与者
	m_ccmlist.m_qryoroprtp 	  = m_cBeps392.QryOrOprTp;   //协议查询或调整标识
	m_ccmlist.m_ctrctagrmttp  = m_cBeps392.CtrctAgrmtTp; //合同协议类型
	m_ccmlist.m_srcflag		  = "1";       //往来账标识， 1：往账，2：来
	m_ccmlist.m_procstate	  = PR_HVBP_08;//处理状态

	//设置循环部份明细
	int iCount = atoi(m_cBeps392.NbOfAgrmt.c_str());
	for(int i = 0; i < iCount; ++i){
		//设置数据
		SetData_list(i);
		//插入数据
		iRet = m_ccmlist.insert();
		if(SQL_SUCCESS != iRet){
			char szErr[512] = {0};
			sprintf(szErr, "插入批量签约明细失败 iRet=%d cause=%s",
					iRet, m_ccmlist.GetSqlErr());
			Trace(L_ERROR, __FILE__, __LINE__,
					    NULL, "%s", szErr);

			PMTS_ThrowException(DB_INSERT_FAIL);
		}// end if
	}// end for

	return iRet;
}

//__wsh 2012-05-25 核签
void CRecvBkbeps392::CheckSign392()
{
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CheckSign392");

	m_cBeps392.getOriSignStr();

	CheckSign(
		m_cBeps392.m_sSignBuff.c_str(),
		m_cBeps392.m_szDigitSign.c_str(),
		m_cBeps392.InstgDrctPty.c_str());

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CheckSign392");
}







