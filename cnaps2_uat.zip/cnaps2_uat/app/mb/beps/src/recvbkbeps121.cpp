/******************************************************************** 
�ļ����� recvbkbeps121.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif
#include "recvbkbeps121.h"

CRecvBkbeps121::CRecvBkbeps121()
{
    m_Bpcl.m_msgtp   = "beps.121.001.01";
    m_BpList.m_msgtp = "beps.121.001.01";
	m_strMsgTp = "beps.121.001.01";
}

CRecvBkbeps121::~CRecvBkbeps121()
{

}

int CRecvBkbeps121::Work(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps121::Work()");

    // ��������
    unPack(szMsg);
	
    iRet = SetData(szMsg);
    
    // ��������
    InsertData();
        
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps121::Work()");
    return 0;
}

void CRecvBkbeps121::CheckSign121()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms121::CheckSign121");
	
	m_cBeps121.getOriSignStr();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSignBuff = [%s]", m_cBeps121.m_sSignBuff.c_str());	
	if( !IsUTF8(m_cBeps121.m_sSignBuff.c_str(), m_cBeps121.m_sSignBuff.length()) ){
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "ǩ����UTF8����");
	}
	CheckSign(m_cBeps121.m_sSignBuff.c_str(),
			m_cBeps121.m_szDigitSign.c_str(),
			m_cBeps121.InstgDrctPty.c_str());
	        
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms121::CheckSign121");
	
}

INT32 CRecvBkbeps121::unPack(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps121::unPack()");
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "receive msg len = [%d]", strlen(szMsg));
    
    int iRet = -1;
    if (NULL == szMsg || '\0' == szMsg)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "���ĳ���Ϊ��!");
        PMTS_ThrowException(PRM_FAIL);
    }

    
    // ��������
    if (OPERACT_SUCCESS != m_cBeps121.ParseXml(szMsg))
    {
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= %d", iRet);	
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
    }
    //���ı�ʶ��
	m_strMsgID = m_cBeps121.MsgId;
	ZFPTLOG.SetLogInfo("121", m_strMsgID.c_str());

	//��ȡ��������
	//iRet = GetWorkDate(m_dbproc, m_sWorkDate,
	//		SYS_BEPS, m_cBeps121.InstdDrctPty.c_str());

	m_strWorkDate = m_sWorkDate;
	/*
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");
		PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
	}
	m_strWorkDate = m_sWorkDate;*/
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps121::unPack()");
    return OPERACT_SUCCESS;
}

INT32 CRecvBkbeps121::InsertData()
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps121::InsertData()");
    
    SETCTX(m_Bpcl);
    int iRet = m_Bpcl.insert();
	if(OPERACT_SUCCESS != iRet)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "������ϸ��ʧ��,�ع����ܱ�, ERROR = %s", m_Bpcl.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}		 

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps121::InsertData()  iRet=%d", iRet);
    return iRet;
}

INT32 CRecvBkbeps121::SetData(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps121::SetData()");
    
    SETCTX(m_BpList);
    char sProcstate[2+1]={0};
    //���ݰ�����״̬���±�״̬
    TransProcStates(m_cBeps121.PrcSts.c_str(),sProcstate);
    m_Bpcl.m_ccy          = m_cBeps121.CtrlSumCcy;
    m_Bpcl.m_rmk          = m_cBeps121.PKGGrpHdrRmk;
    m_Bpcl.m_srcflag      = "0";
    m_Bpcl.m_checkstate   = PR_CNCH_00;
	m_Bpcl.m_nboftxs      = atoi(m_cBeps121.PKGGrpHdrNbOfTxs.c_str()); 
	m_Bpcl.m_ctrlsum      = atof(m_cBeps121.CtrlSum.c_str()); 
	m_Bpcl.m_succnboftxs  = atoi(m_cBeps121.PKGGrpHdrNbOfTxs.c_str()); 
	m_Bpcl.m_ctrlsuccsum  = atof(m_cBeps121.CtrlSum.c_str()); 
	m_Bpcl.m_sapsnboftxs  = 0; 
	m_Bpcl.m_ctrlsapssum  = 0.00; 
	m_Bpcl.m_realtimeflag = "0"; 
	m_Bpcl.m_dgtsign      = "DIGTAL SIGN"; 
	m_Bpcl.m_isrbflg      = "0";//��Ҫ�ж�if A105 
	//m_Bpcl.m_recvdest     ="1"; 
	m_Bpcl.m_workdate     = m_sWorkDate; 
	m_Bpcl.m_consigdate   = m_cBeps121.MsgId.substr(0, 8); 
	m_Bpcl.m_msgid        = m_cBeps121.MsgId;
    m_Bpcl.m_instgdrctpty = m_cBeps121.InstgDrctPty;
    m_Bpcl.m_instddrctpty = m_cBeps121.InstdDrctPty;
    m_Bpcl.m_netgdt       = m_cBeps121.NetgDt;
    m_Bpcl.m_netgrnd      = m_cBeps121.NetgRnd;
    m_Bpcl.m_busistate    = "";
    m_Bpcl.m_processcode  = m_cBeps121.PrcCd;
    m_Bpcl.m_rjctinf      = m_cBeps121.RjctInf;
    m_Bpcl.m_procstate    = PR_HVBP_08;

	m_Bpcl.m_mesgid    = m_cBeps121.m_PMTSHeader.getMesgID();
	m_Bpcl.m_mesgrefid = m_cBeps121.m_PMTSHeader.getMesgRefID();

    //m_Bpcl.m_finalstatedate = m_cBeps121.SttlmDt;
    
    int iNum = m_cBeps121.GetDetailCnt();
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iNum[%d]",iNum);
    for(int i = 0; i < iNum; i++)
    {
        m_cBeps121.ParseDetail(i);

	      m_BpList.m_isrbflg      = "0";
        m_BpList.m_msgid           = m_cBeps121.MsgId;
        m_BpList.m_instgdrctpty    = m_cBeps121.InstgDrctPty;
        m_BpList.m_instddrctpty    = m_cBeps121.InstdDrctPty;
        m_BpList.m_netgdt          = m_cBeps121.NetgDt;
        m_BpList.m_netgrnd         = m_cBeps121.NetgRnd;
        m_BpList.m_processcode     = m_cBeps121.PrcCd;
        m_BpList.m_rjctinf         = m_cBeps121.RjctInf;
        m_BpList.m_procstate       = PR_HVBP_08;
        m_BpList.m_workdate        = m_sWorkDate;
        m_BpList.m_consigdate      = m_cBeps121.TxId.substr(0, 8);
        m_BpList.m_txid            = m_cBeps121.TxId;
        m_BpList.m_dbtnm           = m_cBeps121.DbtrNm;
        m_BpList.m_dbtracctid      = m_cBeps121.DbtrAcctId;
        m_BpList.m_dbtrissr        = m_cBeps121.DbtrAcctIssr;
        m_BpList.m_dbtrbrnchid     = m_cBeps121.DbtrAgtId;
        m_BpList.m_cdtrnm          = m_cBeps121.CdtrNm;
        m_BpList.m_cdtracctid      = m_cBeps121.CdtrAcctId;
        m_BpList.m_cdtrissr        = m_cBeps121.CdtrAcctIssr;
        m_BpList.m_cdtrbrnchid     = m_cBeps121.CdtrAgtId;
        m_BpList.m_currency        = m_cBeps121.CtrlSumCcy;
        m_BpList.m_pmttpprtry      = m_cBeps121.CtgyPurpPrtry;
        m_BpList.m_purpprtry       = m_cBeps121.PurpPrtry;
        m_BpList.m_addtlinf        = m_cBeps121.AddtlInf;
        m_BpList.m_orgnlmsgid      = m_cBeps121.OrgnlMsgId;
        m_BpList.m_orgnlmsgtp      = m_cBeps121.OrgnlTxTpCd;
        m_BpList.m_oriinstgpty     = m_cBeps121.OrgnlInstgPty;
        m_BpList.m_oriinstgdrctpty = m_cBeps121.InstgIndrctPty;
        m_BpList.m_oritxid         = m_cBeps121.OrgnlTxId; 
        m_BpList.m_amount          = atof(m_cBeps121.CstmrCdtTrfInfAmt.c_str());
        m_BpList.m_srcflag         = "0";
        m_BpList.m_checkstate      = PR_CNCH_00;
        m_BpList.m_busistate       =  "";
        m_BpList.m_dbtaddr         = m_cBeps121.DbtrAdrLine;
        m_BpList.m_cdtaddr         = m_cBeps121.CdtrAdrLine;
        m_BpList.m_acctstate       = "01";
        //m_BpList.m_printno = 0;
        //m_BpList.m_finalstatedate  = m_cBeps121.SttlmDt;
       
  
        //ҵ������Ϊ���ҵ��ҵ������Ϊί���տ��
        if( ("A109" == m_cBeps121.CtgyPurpPrtry) && ("02106" == m_cBeps121.PurpPrtry))
        {
            m_BpList.m_cstmrcdttrfaddtlinf = "/Tp/" + m_cBeps121.ColltnInfTp + ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/Dt/" + m_cBeps121.ColltnInfDt + ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/Nb/" + m_cBeps121.ColltnInfNb+ ":";

        }

        //ҵ������Ϊ���ҵ��ҵ������Ϊ���ճи�����
        if(("A110" == m_cBeps121.CtgyPurpPrtry) && ("02107" == m_cBeps121.PurpPrtry))
        {
            m_BpList.m_cstmrcdttrfaddtlinf = "/Dt/" + m_cBeps121.ColltnWthAccptncInfDt+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/Nb/" + m_cBeps121.ColltnWthAccptncInfNb + ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/AmdsAmt/" + m_cBeps121.AmdsAmtCcy + m_cBeps121.AmdsAmt + ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/RctAmt/" + m_cBeps121.RctAmtCcy + m_cBeps121.RctAmt+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/OrgnlAmt/" + m_cBeps121.OrgnlAmtCcy+ m_cBeps121.OrgnlAmt+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/PmtAmt/" + m_cBeps121.PmtAmtCcy + m_cBeps121.PmtAmt+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/OddAmt/" + m_cBeps121.OddAmtCcy + m_cBeps121.OddAmt+ ":";

        }
                
        //ҵ������Ϊ�ɷ�ҵ��
        if("A301" == m_cBeps121.CtgyPurpPrtry)
        {
            m_BpList.m_cstmrcdttrfaddtlinf = "/FlowNb/" + m_cBeps121.PmtInfFlowNb + ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/Term/" + m_cBeps121.Term + ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/Tp/" + m_cBeps121.PmtInfTp + ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/Rmk/" + m_cBeps121.PmtInfRmk+ ":";
            
        }
        
        //�˻�ҵ��
        if("A105" == m_cBeps121.CtgyPurpPrtry)
        {
            m_BpList.m_cstmrcdttrfaddtlinf = "/OrgnlMsgId/" + m_cBeps121.OrgnlMsgId+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/OrgnlInstgPty/" + m_cBeps121.OrgnlInstgPty+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/OrgnlMT/" + m_cBeps121.OrgnlMT+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/InstgIndrctPty/" + m_cBeps121.InstgIndrctPty+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/InstdIndrctPty/" + m_cBeps121.InstdIndrctPty+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/OrgnlTxId/" + m_cBeps121.OrgnlTxId+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/OrgnlTxTpCd/" + m_cBeps121.OrgnlTxTpCd + ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/Cntt/" + m_cBeps121.Cntt+ ":";
               
        }
 
        //֧Ʊҵ�񸽼�����
        if("A201" == m_cBeps121.CtgyPurpPrtry)
        {
            m_BpList.m_cstmrcdttrfaddtlinf = "/IsseDt/" + m_cBeps121.IsseDt+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/DrwrNm/" + m_cBeps121.DrwrNm+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/ChqAmt/CNY" + m_cBeps121.ChqAmt+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/Amt/CNY" + m_cBeps121.ChqInfAmt+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/Nb/" + m_cBeps121.ChqInfNb+ ":";
         }

        //���л�Ʊҵ�񸽼�����
        if("A203" == m_cBeps121.CtgyPurpPrtry)
        {
            m_BpList.m_cstmrcdttrfaddtlinf = "/IsseDt/" + m_cBeps121.BkIsseDt+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/DrftAmt/" + m_cBeps121.BkDrftAmt+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/ApplyAcct/" + m_cBeps121.BkApplyAcct+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/ApplyNm/" + m_cBeps121.BkApplyNm+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/SttlmAmt/" + m_cBeps121.BkSttlmAmt+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/OddAmt/" + m_cBeps121.BkOddAmt+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/DrftTp/" + m_cBeps121.BkDrftTp+ ":";
         }
         
         // ��ҵ��Ʊҵ�񸽼�����
        if("A111" == m_cBeps121.CtgyPurpPrtry)
        {
            m_BpList.m_cstmrcdttrfaddtlinf = "/IsseDt/" + m_cBeps121.ComIsseDt+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/DrftAmt/" + m_cBeps121.ComDrftAmt+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/ApplyAcct/" + m_cBeps121.ComApplyAcct+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/ApplyNm/" + m_cBeps121.ComApplyNm+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/SttlmAmt/" + m_cBeps121.ComSttlmAmt+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/OddAmt/" + m_cBeps121.ComOddAmt+ ":";
         }   
         
         // ���б�Ʊҵ�񸽼�����
        if("A204" == m_cBeps121.CtgyPurpPrtry)
        {
            m_BpList.m_cstmrcdttrfaddtlinf = "/IsseDt/" + m_cBeps121.CshIsseDt+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/DrftAmt/" + m_cBeps121.CshDrftAmt+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/ApplyAcct/" + m_cBeps121.CshApplyAcct+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/ApplyNm/" + m_cBeps121.CshApplyNm+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/SttlmAmt/" + m_cBeps121.CshSttlmAmt+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/OddAmt/" + m_cBeps121.CshOddAmt+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf = m_BpList.m_cstmrcdttrfaddtlinf + "/DrftTp/" + m_cBeps121.CshDrftTp+ ":";
         } 
                     
        //��ϸ����������
        if(OPERACT_SUCCESS != m_BpList.insert())
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "������ϸ��ʧ��,�ع����ܱ�, ERROR = %s", m_BpList.GetSqlErr());
            PMTS_ThrowException(DB_INSERT_FAIL);
        }
        
    	//__wsh 2012-06-07 ҵ��Ϊ�˻�ʱ��ԭҵ��Ϊ���ڷ����Ž��м�ֱ���ж�
        if("A105" == m_cBeps121.CtgyPurpPrtry)
        {
        	string strSrcflag = "";
        	CBpbcoutsendlist orgnbcoutlist;
        	SETCTX(orgnbcoutlist);
        	orgnbcoutlist.m_txid = m_cBeps121.OrgnlTxId;
        	Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
        	        "orgnbcoutlist.m_txid=%s", orgnbcoutlist.m_txid.c_str()); 
        	orgnbcoutlist.m_dbtrbrnchid = m_cBeps121.InstgIndrctPty;
        	Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
        	        "orgnbcoutlist.m_dbtrbrnchid=%s", orgnbcoutlist.m_dbtrbrnchid.c_str()); 
        	iRet = orgnbcoutlist.findByPK();

        	if(iRet != SQL_SUCCESS)
        	{
        		if (iRet == SQLNOTFOUND){
					CBpbcoutsendlisthis his;
					SETCTX(his);
					his.m_txid = orgnbcoutlist.m_txid;
					his.m_dbtrbrnchid = orgnbcoutlist.m_dbtrbrnchid;
					iRet = his.findByPK();
					if (iRet != SQL_SUCCESS){
						if (iRet != SQLNOTFOUND){
							Trace(L_ERROR, __FILE__, __LINE__, NULL,
									"��ѯԭҵ��ʧ��,iRet=%d cause=%s", iRet, his.GetSqlErr());
							PMTS_ThrowException(DB_FIND_BY_PK_FAIL);
						}
						else{
							Trace(L_INFO, __FILE__, __LINE__, NULL, "�Ҳ���ԭҵ��!");
						}
					}
					else{
						strSrcflag = his.m_srcflag.c_str();
						m_strOrgnlTable = "bp_bcoutsendlisthis";
					}
				}
				else{
					Trace(L_ERROR, __FILE__, __LINE__, NULL,
							"��ѯԭҵ��ʧ��,iRet=%d cause=%s", iRet, orgnbcoutlist.GetSqlErr());
					PMTS_ThrowException(DB_FIND_BY_PK_FAIL);
				}
        	}
        	else{
        		strSrcflag = orgnbcoutlist.m_srcflag.c_str();
        		m_strOrgnlTable = "bp_bcoutsendlist";
        	}

        	//����ԭҵ���˻��־
        	if (strSrcflag != ""){
        		UpdateOrgnlBiz(m_cBeps121.InstgIndrctPty, m_cBeps121.OrgnlTxId);
        	}


        }
        else
        {
        }
    }

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps121::SetData()");
    return OPERACT_SUCCESS;
}

//__wsh 2013-02-27 ����ԭҵ����ϸ�˻��־
void CRecvBkbeps121::UpdateOrgnlBiz(const string& dbtrbrnchid, const string& txid)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CRecvBkbeps121::UpdateOrgnlBiz");

	string strSql = "update ";
	strSql += m_strOrgnlTable;
	strSql += " set isrbflg='1' where dbtrbrnchid='";
	strSql += dbtrbrnchid;
	strSql += "' and txid='";
	strSql += txid;
	strSql += "' ";

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strSql=[%s]", strSql.c_str());
	int iRet = m_BpList.execsql(strSql);
	if(iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"����ʧ�ܣ�[%s]", m_BpList.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CRecvBkbeps121::UpdateOrgnlBiz");
}
