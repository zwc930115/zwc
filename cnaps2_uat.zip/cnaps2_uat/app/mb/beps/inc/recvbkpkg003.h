
#ifndef RECVPKG003_HBK
#define RECVPKG003_HBK

#include "recvbkbepsbase.h"
#include "pkg003.h"
#include "pkg008.h"

#include "bpbdrecvlist.h"
#include "bpbdrcvcl.h"
#include "bpbcoutsendlist.h" 
#include "bpbcoutsndcl.h" 


class CRecvBkPkg003 : public CRecvbkBepsBase
{
public:
	CRecvBkPkg003();

	~CRecvBkPkg003();

	INT32 Work(LPCSTR szMsg);
    
private:
	int  UnPack(const char* szmsg);

	int  InsertData(void);

	int  InsertData_bc_cl(void);

	int  InsertData_bc_list(void);

	int  InsertData_bd_cl(void);

	int  InsertData_bd_list(void);

	void FillBizHead(void);

	void FillBizBody(void);

	void SetReply(void);

	int  BuildReplyMsg009(void);

	void ChkMac003(void);

	void AddMac009(void);
	
	void AddMac();

	int  DoReply(void);

	void InsertUserInfoTel(void);


private:
	pkg003           m_cPkg003;

	pkg008           m_cPkg008;

	CBpbcoutsndcl    m_bcrcvcl;

	CBpbcoutsendlist m_bcrcvlist;

	CBpbdrcvcl       m_bdsndcl;

	CBpbdrecvlist    m_bdsndlist;

	string           m_strNpcMsg;

	char             m_szMsgId_r[32+1];

	char             m_szTxId_r[32+1];

	char             m_szMessRefId[32+1];

	char             m_szRefId[32+1];

	char             m_szMsgId[32+1];
	
	char             m_szTxId[32+1];
};

#endif /*RECVPKG003_H*/


