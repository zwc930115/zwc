#ifndef RECVBKBEPS128_H
#define RECVBKBEPS128_H

#include "recvbkbepsbase.h"
#include "beps128.h"

#include "bpbcoutsendlist.h"
#include "bpbcoutsndcl.h"
#include "bpbdrecvlist.h"


class CRecvBkBeps128 : public CRecvbkBepsBase
{
public:
	CRecvBkBeps128();

	~CRecvBkBeps128();

	INT32 Work(LPCSTR szMsg);

private:
	int  UnPack(const char* szmsg);

	int  QryOrgnlBiz(void);

	int  InsertData(void);

	int  InsertData_cl(void);

	int  InsertData_list(void);

	int  UpdateOrgnlBiz(void);
	
	int  UpdateOrgnlBiz_list(void);

	void ChkSign128(void);

	int  CheckValues(void);

	int  FundSettle(void);

	int  ChargeMb(void);


private:
	CBpbcoutsndcl    m_bcrcvcl;

	CBpbcoutsendlist m_bcrcvlist;

	CBpbdrecvlist    m_orgnlbiz;

	beps128          m_cBeps128;

	string           m_strNpcMsg;
	
};

#endif /*RECVBEPS128_H*/


