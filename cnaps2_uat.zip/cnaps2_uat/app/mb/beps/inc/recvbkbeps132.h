#ifndef RECVBKBEPS132_H
#define RECVBKBEPS132_H

#include "recvbkbepsbase.h"
#include "beps132.h"

#include "bpbcoutsendlist.h" 
#include "bpbcoutsndcl.h" 
#include "bpbdrecvlist.h" 


class CRecvBkBeps132 : public CRecvbkBepsBase
{
public:
	CRecvBkBeps132();

	~CRecvBkBeps132();

	INT32 Work(LPCSTR szMsg);

private:
	int  UnPack(const char* szmsg);

	int  QryOrgnlBiz(void);

	int  InsertData(void);

	int  InsertData_cl(void);

	int  InsertData_list(void);

	int  UpdateOrgnlBiz(void);

	void ChkSign132(void);

	int  CheckValues(void);

	int  FundSettle(void);

	int  ChargeMb(void);

private:
	CBpbcoutsndcl    m_bcrcvcl;

	CBpbcoutsendlist m_bcrcvlist;

	CBpbdrecvlist    m_orgnlbiz;

	beps132          m_cBeps132;

	string           m_strNpcMsg;
	
};

#endif /*RECVBEPS132_H*/


