/******************************************************************** 
�ļ����� recvpkg007.h
�����ˣ� handongfeng
��  �ڣ� 2011-04-15
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifndef __RECVPKG007_H__BK
#define __RECVPKG007_H__BK

#include "recvbkbepsbase.h"
#include "pkg007.h"
#include "bpbcoutsendlist.h"
#include "bpbcoutsndcl.h"
#include "bpbcoutrecvlist.h"
#include "bpbcoutsendlisthis.h"
#include "bpbcoutrecvlisthis.h"

class CRecvBkPkg007 : public CRecvbkBepsBase
{
public:
	CRecvBkPkg007();
	~CRecvBkPkg007();
	INT32 Work(LPCSTR szMsg);
    
private:
	INT32 unPack(LPCSTR szMsg);
	INT32 InsertDb(LPCSTR pchMsg);
    void CreatePkg009();
    void CreateMsgBody();
    void InsertBCsendList(LPCSTR pchMsg);
    void UpdateOrgnlBiz(const string& dbtrbrnchid, const string& txid);
    INT32 CheckAcct();
    int  CheckMac007();
	int FundSettle();
	void AddMac();
	pkg007         m_pkg007;
	CBpbcoutsndcl  m_Bpbcoutrcvcl;
    CBpbcoutsendlist m_Bpbcoutrecvlist;
    string  m_strOrgnlTable;
    string  m_strOrgnlTxid;
    string  m_strOrgnlDbtrbrnchid;
    
};

#endif



