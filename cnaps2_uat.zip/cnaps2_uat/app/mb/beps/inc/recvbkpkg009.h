#ifndef RECVPKG009_HBK
#define RECVPKG009_HBK

#include "recvbkbepsbase.h"
#include "pkg008.h"

#include "bpbdsendlist.h" 
#include "bpbdsndcl.h" 

#include "bpbcoutrecvlist.h"


class CRecvBkPkg009 : public CRecvbkBepsBase
{
public:
	CRecvBkPkg009();

	~CRecvBkPkg009();

	INT32 Work(LPCSTR szMsg);

private:
	int  UnPack(const char* szmsg);

	int  QryOrgnlBiz(void);

	int  InsertData(void);

	int  InsertData_cl(void);

	int  InsertData_list(void);

	int  UpdateOrgnlBiz(void);

	void ChkMac009(void);

	int  CheckValues(void);

	int  FundSettle(void);
	void AddMac();

	int  ChargeMb(void);	
private:
	CBpbdsndcl       m_bdrcvcl;

	CBpbdsendlist    m_bdrcvlist;

	CBpbcoutrecvlist m_orgnlbiz;

	pkg008           m_cPkg009;
	
	string           m_strNpcMsg;

	char             m_szMsgId[32+1];

	char             m_szTxId[32+1];
};

#endif /*RECVPKG009_H*/


