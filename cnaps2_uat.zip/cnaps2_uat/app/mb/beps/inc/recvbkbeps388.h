/******************************************************************** 
文件名： recvbeps388.h
创建人： handongfeng
日  期： 2011-02-23
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __RECVBKBEPS388_H__
#define __RECVBKBEPS388_H__

#include "recvbkbepsbase.h"
#include "beps388.h"
#include "bpbizpubntce.h"
#include "bpcolltnchrgscl.h"
#include "bpcolltnchrgslist.h"

class CRecvBkbeps388 : public CRecvbkBepsBase
{
public:
    CRecvBkbeps388();
    ~CRecvBkbeps388();
    int Work(LPCSTR szMsg);
    
private:

    //INT32 InsertData();
    //INT32 SetData(LPCSTR pchMsg);
    void CheckSign388();
    INT32 unPack(LPCSTR szMsg);
	void SetDBKey();
    void InsertData();
	int UpdateState();
	
    beps388			    m_beps388;
    CBpbizpubntce       m_Bpbizpubntce;
    CBpcolltnchrgscl	m_colltnchrgscl;
    CBpcolltnchrgslist	m_colltnchrgslist;
        
};

#endif

