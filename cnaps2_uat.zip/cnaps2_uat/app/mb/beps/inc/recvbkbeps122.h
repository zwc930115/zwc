/******************************************************************** 
�ļ����� recvbeps122.h
�����ˣ� handongfeng
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __RECVBKBEPS122_H__
#define __RECVBKBEPS122_H__

#include "recvbkbepsbase.h"
#include "beps122.h"
#include "bpbcoutsendlist.h"
#include "bpbcoutsndcl.h"

#include "bpbcoutrecvlist.h"
#include "bpbcoutrecvlisthis.h"

class CRecvBkbeps122 : public CRecvbkBepsBase
{
public:
    CRecvBkbeps122();
    ~CRecvBkbeps122();
    int Work(LPCSTR szMsg);
    
private:
    void  CheckSign122();
    INT32 InsertData();
    INT32 SetData(LPCSTR pchMsg);
    INT32 unPack(LPCSTR szMsg);
    void UpdateOrgnlBiz(const string& dbtrbrnchid, const string& txid);
    beps122		    	m_cBeps122;
    CBpbcoutsendlist	m_BpList;
    CBpbcoutsndcl		m_Bpcl;
    string  m_strOrgnlTable;
   	string  m_strOrgnlTxid;
   	string  m_strOrgnlDbtrbrnchid;
};

#endif
