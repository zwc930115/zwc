/******************************************************************** 
文件名： recvbkbeps396.h
创建人： handongfeng
日  期： 2011-02-23
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __RECVBKBEPS396_H__
#define __RECVBKBEPS396_H__

#include "recvbkbepsbase.h"
#include "beps396.h"
#include "bpgettx.h"

class CRecvbkbeps396 : public CRecvbkBepsBase
{
public:
    CRecvbkbeps396();
    ~CRecvbkbeps396();
    int Work(LPCSTR szMsg);

private:

    void GetTag2ND(int& iDepth, string& DbStr, const string& Tag);
    void SetData();
    INT32 unPack(LPCSTR szMsg);
    beps396 m_beps396;
    CBpgettx m_Bpgettx; 
};

#endif

