/*
 *  recvbeps130.h
 *  Description: ����CISƱ��beps.130.001.01���Ĵ�����
 *  Created on: 2012-09-03
 *  Author: __wsh
 */
 
#ifndef RECVBKBEPS130_H
#define RECVBKBEPS130_H

#include "recvbkbepsbase.h"
#include "beps130.h"

#include "bpbcoutsendlist.h"
#include "bpbcoutsndcl.h"


class CRecvBkBeps130 : public CRecvbkBepsBase
{
public:
	CRecvBkBeps130();

	~CRecvBkBeps130();

	INT32 Work(LPCSTR szMsg);

private:
	int  UnPack(const char* szmsg);

	int  InsertData(void);

	void GetRmtInf(int iLoop);

	int  InsertData_cl(void);

	int  InsertData_list(void);

	void ChkSign130(void);

	int  CheckValues(void);

	int  FundSettle(void);

	int  ChargeMb(void);

	void InsertUserInfoTel(void);

private:
	CBpbcoutsndcl    m_bcrcvcl;

	CBpbcoutsendlist m_bcrcvlist;

	beps130          m_cBeps130;

	string           m_strNpcMsg;

	int              m_iTtlCnt; //��ϸ�ܱ���
	int              m_iTtlCntOk; //�ɹ���ϸ����
	double           m_fTtlAmt; //��ϸ�ܽ��
	double           m_fTtlAmtOk; //�ɹ���ϸ�ܽ��

	int              m_iUstCnt;
};

#endif /*RECVBEPS130_H*/


