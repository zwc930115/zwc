/******************************************************************** 
�ļ����� recvbeps412.h
�����ˣ� zys
��  �ڣ� 2011-04-28
�޸��ˣ� 
��  �ڣ� 
��  ���� ���ҵ��ֹ��Ӧ����< beps.412.001.01>���˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifndef __RECVBKBEPS412_H__
#define __RECVBKBEPS412_H__

#include "recvbkbepsbase.h"
#include "beps412.h"
#include "bpcstbdpcxlcl.h" 
#include "bpcstbdpcxllist.h"
#include "bpbdsendlist.h" 


class CRecvBkBeps412 : public CRecvbkBepsBase
{
public:
	CRecvBkBeps412();
	~CRecvBkBeps412();
	INT32 Work(LPCSTR szMsg);
	
private:
	INT32 unPack(LPCSTR szMsg);
	INT32 CheckValues();
	INT32 InsertDb(LPCSTR pchMsg);
	STRING GetValFromCycle(LPCSTR sNodeName, int iDepth);
	void CheckSign412();
	INT32 CheckAcct();
	
	INT32 QryOrgnBiz(void);
	
    INT32 UpdateBizState(void);
    
    INT32 UpdateBizState(string& strOrgnTxId, 
            string& strOrgnSndBkCd, string& strOrgnRcvBkCd);
            	
	beps412             m_cBeps412;
	CBpcstbdpcxlcl		m_cBpcstbdpcxlcl;
	CBpcstbdpcxllist	m_cBpcstbdpcxllist;
	BOOL				bCheck;
	
	CBpbdsendlist  m_cBpbdsendlist;
	
	string m_strOrgnInfMsgId;
	string m_strOrgnInfInstg;
	string m_strOrgnInfMsgTp;
};

#endif


