#ifndef RECVPKG008_HBK
#define RECVPKG008_HBK

#include "recvbkbepsbase.h"
#include "pkg008.h"

#include "bpbcoutsendlist.h"
#include "bpbcoutsndcl.h"

#include "bpbdrecvlist.h"


class CRecvBkPkg008 : public CRecvbkBepsBase
{
public:
	CRecvBkPkg008();

	~CRecvBkPkg008();

	INT32 Work(LPCSTR szMsg);

private:
	int  UnPack(const char* szmsg);

	int  QryOrgnlBiz(void);

	int  InsertData(void);

	int  InsertData_cl(void);

	int  InsertData_list(void);

	void SetData_006(void);

	void SetData_007(void);

	int  UpdateOrgnlBiz(void);

	void ChkMac008(void);
	void AddMac();


private:
	CBpbcoutsndcl    m_bcrcvcl;

	CBpbcoutsendlist m_bcrcvlist;

	CBpbdrecvlist    m_orgnlbiz;

	pkg008           m_cPkg008;

	string           m_strNpcMsg;

	char             m_szMsgId[32+1];

	char             m_szTxId[32+1];

	bool             m_bUpdate;
};

#endif /*RECVPKG008_H*/


