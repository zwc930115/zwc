/******************************************************************** 
文件名： recvbeps397.h
创建人： handongfeng
日  期： 2011-02-23
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __RECVBKBEPS397_H__
#define __RECVBKBEPS397_H__

#include "recvbkbepsbase.h"
#include "beps397.h"
#include "bpcstpmtqryrspn.h"
#include "bpgettx.h"

class CRecvBkbeps397 : public CRecvbkBepsBase
{
public:
	CRecvBkbeps397();
	~CRecvBkbeps397();
	int Work(LPCSTR szMsg);
    
private:
	INT32 GetParserObj(LPCSTR szMsg);
	void  CheckSign397();
	INT32 InsertData();
	INT32 SetData(LPCSTR pchMsg);
	INT32 unPack(LPCSTR szMsg);
	beps397 m_beps397;
	CBpgettx m_Bpgettx;
	CBpcstpmtqryrspn m_Bpcstpmtqryrspn;      
};

#endif

