/******************************************************************** 
�ļ����� recvbeps392.h
�����ˣ� caozhuojun
��  �ڣ� 2012-06-12
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2012  YLINK 
********************************************************************/ 
#ifndef __RECVBKBEPS392_H__
#define __RECVBKBEPS392_H__

#include "recvbkbepsbase.h"
#include "beps392.h"
#include "bpcstctrctmglist.h"
#include "bpcstctrctmgcl.h"
#include "bpcstctrctmg.h"

class CRecvBkbeps392 : public CRecvbkBepsBase
{
public:
    CRecvBkbeps392();
    ~CRecvBkbeps392();
    int Work(LPCSTR szMsg);
private:
		INT32 UnPack(LPCSTR szMsg);
	
		INT32 SetData_cl();
	
		INT32 InsertData_cl();
	
		INT32 SetData_list(int iCount);
	
		INT32 InsertData_list();
	
		void  CheckSign392();
		
	private:
	
		beps392 m_cBeps392;
	
		CBpcstctrctmgcl m_ccmcl;
	
		CBpcstctrctmglist m_ccmlist;

};

#endif


