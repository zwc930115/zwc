/*
 * 	recvbeps414.cpp
 *	Description: ʵʱ����Ӧ����beps.414.001.01������
 *  Created on: 2012-07-09
 *  Author: __wsh
 */

#ifndef RECVBKBEPS414_H
#define RECVBKBEPS414_H

#include "beps414.h"
#include "recvbkbepsbase.h"

#include "bpcstpmtcxl.h" 

class CRecvBkBeps414 : public CRecvbkBepsBase
{
public:
    CRecvBkBeps414();

    ~CRecvBkBeps414();

    INT32 Work(LPCSTR szMsg);
    
private:
    int UnPack(LPCSTR szMsg);

    void SetData(void);

    int InsertData(void);

    void  CheckSign414();
    
    int UpdateOrgnBiz(void);

    int ChargeMb();
    
private:
    beps414           m_cBeps414;
    
    CBpcstpmtcxl      m_cpc;
};

#endif /*RECVBEPS414_H*/


