#ifndef __RECVBKSAPSWORK_H__
#define __RECVBKSAPSWORK_H__

#include "basicapi.h"
#include "string.h"

class CRecvbkSapsWork
{
public:
    CRecvbkSapsWork();
    ~CRecvbkSapsWork();

    void setData(LPTSTR lpMsgID, int iErrMsgFlag = 0, UINT32 len = 0, LPCSTR data = NULL, LPCSTR lpTrsCode = NULL, LPCSTR lpMsgFile = NULL);

	INT32 GetMsg(void);
	
    void clear();
	
    INT32 doWork();

private:
    std::string  m_sMsgFile;
    VCHAR  m_vData;
    std::string m_strMsgID;
    int  m_iErrMsgFlag;
};
#endif


