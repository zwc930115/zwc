#ifndef _RECVBKSAPSBASE_H_
#define _RECVBKSAPSBASE_H_

#include "pubfunc.h"
#include "exception.h"
#include "logger.h"
#include "cmsendmsg.h"
#include "cmrecverrmsg.h" 
#include "mqagent.h"

using namespace ZFPT;
extern MQAgent m_cMQAgent; 
extern DBProc  m_dbproc;
extern char        g_SapBank[17];

class CRecvbkSapsBase
{
public:
    CRecvbkSapsBase();
    virtual ~CRecvbkSapsBase();

	INT32 doWork(LPCSTR pchMsg);
    
    INT32 SetData(LPCSTR pchMsg);
    
    INT32 InsertData(void);
    
    INT32 DelCmRecvMsg(void);
    
    INT32 WriteErrTable(LPCSTR pchMsg, int nErrCode, LPCSTR pchErrDesc);

	
	  INT32 SendToBkmq(LPCSTR sMsg);

	INT32 WriteErrFile(const char * pchErrText = NULL);

    void GetSapBkToCCPC(DBProc &dbproc, string sSapBank, char* sCCPCCode);
    
    int CheckSign(const char *srcSign, const char *dstSign, const char * sSendBankCode, int iFlag = RAWSIGN);

	bool SendNotifyMsg(const char* pMsgId,
								    const char* pSendBank,
								    const char* pSysFlg,
									const char* pMsgType,
									const char* pBusiType
								    );	

	void DirectInter(LPCSTR cpSendBank, 
					 LPCSTR cpRecvBank, 
					 LPCSTR cpRecvSapBank, 
					 LPCSTR cpNpcMsg, 
					 LPCSTR cpSysflg = "HVPS");


public:
	string	m_strBizCode;       //(дļ,recvcmworkֵ)
	string	m_strRcvMsgID;      //4MSGID(ƴʶ,ɾͨѶ,recvcmworkֵ)
	char	m_sCommHead[42 + 1];//ͨѶ㱨ͷ
    string  m_strSendMsg;       //ͱĴ
	int     m_iErrMsgFlag;  //쳣Ϣ־
	string  m_ErrMsgTp;
	int		m_iMsgVer;			//1:һ;2:
	
protected:
	
	virtual INT32  Work(LPCSTR szMsg) = 0; 
	
	int		AddQueue(string msgtx, int length);
	int AddSendtoQueue(string msgtx, int length);
	
	int		AddBkRtnQueue(string msgtx, int length);

	//DBProc	m_dbproc;
	//MQAgent m_cMQAgent;
	string	m_strMsgID;         //MSGID(дļ,ҵֵ)
	bool	m_bIfOptBigData;    //ֶα
	char	m_szErrMsg[1024 + 1];	//
	char    m_sWorkDate[8 + 1];	//
	char    m_szDisSys[3 + 1];       //ԭĿϵͳ
	char    m_szOrgnlMbMsgId[22 + 1];//ԭڱıʶ
	string	m_strWorkDate;		//
	string	m_strMsgTp;			//:HVPSͷ,һCMTͷ

	string	  m_sSysFlg;//ϵͳʾ
	string    m_sMegType;//
	string    m_sBusiType;//ҵ	
private:
	
	
   Ccmsendmsg		m_cCmrecvmsg;       
    CCmrecverrmsg	m_cCmrecverrmsg;

	void GetDBConnect(void);

	void GetMqConn(void);

    INT32 DoException(LPCSTR pchMsg, int nErrCode, LPCSTR pchErrDesc);
    
    void	Send990(LPCSTR pchMsg, int iRst);

    void Init();
};

#endif


