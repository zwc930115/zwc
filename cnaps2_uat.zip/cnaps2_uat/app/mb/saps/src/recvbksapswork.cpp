/********************************************************************
文件名：recvbksapswork.cpp
创建人：zhj
日  期：2011-03-03
修改人：
日  期：
描  述：saps来帐线程工作类
版  本：
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif


#include "pubfunc.h"
#include "logger.h"
//#include "recvbksapswork.h"


#include "cmrecvmsg.h"
#include "recvbksapsbase.h"
#include "recvbksaps368.h"
#include "recvbksapswork.h"
using namespace ZFPT;

extern CConnectPool *g_DBConnPool;
extern int		g_IsConnPlatm;

CRecvbkSapsWork::CRecvbkSapsWork()
{    

    m_sMsgFile = "";
    m_strMsgID = "";		
}

CRecvbkSapsWork::~CRecvbkSapsWork()
{	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "in ~CRecvbkSapsWork()");   
}

void CRecvbkSapsWork::setData(LPTSTR lpMsgID, int iErrMsgFlag, UINT32 len, LPCSTR data, LPCSTR lpTrsCode, LPCSTR lpMsgFile)
{
    
    if(NULL != data && 0 != len)
    {
        m_vData.resize(len + 1, 0);
    
        memset(&m_vData[0], 0, len * sizeof(char));
        memcpy(&m_vData[0], data, len);
    }
    
    
    if(lpMsgFile != NULL)
    {
        m_sMsgFile = lpMsgFile;
    }
    
    if (NULL != lpMsgID)
    {
        m_strMsgID = lpMsgID;
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgID = %s", m_strMsgID.c_str());	
    }

    m_iErrMsgFlag = iErrMsgFlag;
}

void CRecvbkSapsWork::clear()
{
	
}

INT32 CRecvbkSapsWork::doWork()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvSapsWork::doWork()");	

    // 大报文消息没传过来，需要从来帐通讯表取消息

	int iRet = -1;
	int iBizCode	= -1; 
	int iVersion	= -1;
	
// 	if (0 == m_vData.size()) //当报文长度大于2000时,work从表里取;小于2000时,通过setdata设置
//     {
//         Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "0 == m_vData.size()");	
// 		return RTN_FAIL;   
//     }   
//     
//     Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "是否连接统一支付平台 0:未连接;1:已连接 g_IsConnPlatm = [%d]" ,g_IsConnPlatm);	
//     char sCommHead[42+1] = {0};
// 
//     Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "OK");	
//     if( 1 == g_IsConnPlatm)
//     {
// 	    //取通讯报文头  add by xlz 0712	    
// 	    strncpy(sCommHead , &m_vData[0] ,42);
// 	    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "通讯报文头 sCommHead = [%s]" ,sCommHead);	
// 	    
// 	    //取业务码   
// 	    iBizCode = GetBizCode(&m_vData[0] + 42, iVersion);
// 	}
// 	else
// 	{
		//取业务码   
	    iBizCode = GetBizCode(&m_vData[0], iVersion);
//	}
	if (-1 == iBizCode)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iBizCode 未取到");
        return RTN_FAIL;
    }
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iBizCode = %d", iBizCode);
    
    char szchBizCode[4 + 1] = {0};  // 业务码
    sprintf(szchBizCode, "%d", iBizCode);

	CRecvbkSapsBase *PRecvSaps = NULL;
		//307 919 991 316报文未处理 占时直接return 对于宏定义占时用HV开头
    switch( iBizCode )
    {
        case 368:
        {
            PRecvSaps = new CRecvBkSaps368;
            break;
        } 		
        default:
            return RTN_FAIL;
    }

	PRecvSaps->m_strBizCode  = szchBizCode;
	PRecvSaps->m_strRcvMsgID = m_strMsgID;
    PRecvSaps->m_iErrMsgFlag = m_iErrMsgFlag;
    PRecvSaps->m_iMsgVer	 = iVersion;
    
	ZFPTLOG.SetLogInfo(PRecvSaps->m_strBizCode.c_str(), NULL);
	
// 	if( 1 == g_IsConnPlatm)
// 	{
// 		strncpy(PRecvSaps->m_sCommHead , sCommHead , 42 );
// 		PRecvSaps->doWork(&m_vData[0]+42);
// 	}
// 	else
// 	{
		PRecvSaps->doWork(&m_vData[0]);
//	}	
	
				
	if (NULL != PRecvSaps)
	{
		delete PRecvSaps;
		PRecvSaps = NULL;
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvSapsWork::doWork()");

    return RTN_SUCCESS;
}

/******************************************************************************
*  Function:   GetMsg
*  Description:从来帐通讯表取消息
*  Input:	   无
*  Output:	   
*  Return:	   0   : 操作成功,
			   其他: 操作失败
*  Others:	   无
*  Author:	   zys
*  Date:	   2011-02-21
*******************************************************************************/
INT32 CRecvbkSapsWork::GetMsg(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvSapsWork::GetMsg");	

	int    iRet = RTN_FAIL;
	DBProc cDBProc;

	// 获取数据库连接
	iRet = g_DBConnPool->GetConnect(cDBProc);
	if(0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "GetConnect failed");
		return iRet;	
	}

	CCmrecvmsg cCmrecvmsg;
	iRet= cCmrecvmsg.setctx(cDBProc);
	if (0 != iRet)
	{
		g_DBConnPool->PutConnect(cDBProc);//释放连接
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "cCmrecvmsg.setctx error[%d]", iRet);	
		return iRet;
	}

	cCmrecvmsg.m_msgid  = m_strMsgID;
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_strMsgID = %s", m_strMsgID.c_str());	
	
	// 从来帐通讯表取消息
	iRet = cCmrecvmsg.findByPK();
	if (RTN_SUCCESS == iRet)
	{
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "cCmrecvmsg.findByPK success");	
		m_vData.resize(cCmrecvmsg.m_msgtext.length() + 1, 0);	
		memset(&m_vData[0], 0, cCmrecvmsg.m_msgtext.length() * sizeof(char));
		memcpy(&m_vData[0], cCmrecvmsg.m_msgtext.c_str(), cCmrecvmsg.m_msgtext.length());
	}
	else
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "cCmrecvmsg.findByPKfailed[%d]", iRet);
	}

	//释放连接
	g_DBConnPool->PutConnect(cDBProc);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvSapsWork::GetMsg");

	return iRet;
}


