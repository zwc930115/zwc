/******************************************************************** 
�ļ����� recvccms368.cpp
�����ˣ� aps-lel
��  �ڣ� 2011-04-19	
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbksaps368.h"

extern char		g_RecvTel[128];
CRecvBkSaps368::CRecvBkSaps368()
{
	m_iMsgVer	=	2;
	m_strMsgTp	=	"saps.368.001.01";		
}


CRecvBkSaps368::~CRecvBkSaps368()
{
		
}

INT32 CRecvBkSaps368::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkSaps368::Work()...");


	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkSaps368::work()...");

	return RTN_SUCCESS;
}
