/********************************************************************
 文件名： recvhvps716.cpp
 创建人： ln
 日  期： 2012-08-01
 修改人：
 日  期：
 描  述： 大额业务明细核对应答报文<hvps.716.001.01>
 版  本：
 Copyright (c) 2012  YLINK
 ********************************************************************/
 
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvhvps716.h"

#include "hvsndexchglist.h"
#include "hvsndexchglisthis.h"
#include "hvrcvexchglist.h"
#include "hvrcvexchglisthis.h"
#include "hvtrofacrcvlist.h"
#include "hvtrofacrcvlisthis.h"
#include "cmtransinfoqry.h"
#include "hvmnetstlntc.h"

using namespace ZFPT;
extern char		g_SendQueue[128];

CRecvHvps716::CRecvHvps716()
{
    m_bLast716    = false;
}

CRecvHvps716::~CRecvHvps716()
{

}

int CRecvHvps716::Work(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps716::Work()");

    #if 0
    // 解析716报文
    UnPack(szMsg);
    //删除预对账表的数据
    DeleteBeforeCheck();

    // 解析对账清单,并插入预对账表
   GetDetail();

    // 数字签名串核签--此报文核签有问题 暂不核签
   CheckSign716();
    
	 //说明: 根据原报文标识号和原发起直接参与者 在各业务表中查找,若存在此笔业务则则更新"大额
   //预对账表"的状态改为对账相符，否则为对账 不符。
	 UpdateState();
 
	 //查询本地多的已成功清算的贷记往账
	 FindLocalMore();
   #endif
        
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps716::Work()");
	return 0;
}
void CRecvHvps716::DeleteBeforeCheck()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvHvps716::DeleteBeforeCheck()");
    
    SETCTX(m_hvbeforecheck);
    string szDelSql = "";
    int iRet = -1;
    
    szDelSql = "delete from HV_BEFORECHECK t where t.CHKDT = '";
    szDelSql += m_checkdate;
    szDelSql += "' and INSTDDRCTPTY = '";
    szDelSql += m_hvps716.InstdDrctPty;
    szDelSql += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "szDelSql=[%s]",szDelSql.c_str());

    iRet = m_hvbeforecheck.execsql(szDelSql);
    if ( iRet != SQL_SUCCESS && iRet != SQLNOTFOUND )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "删除HV_BEFORECHECK表失败[%d][%s]",
            iRet, m_hvbeforecheck.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "删除HV_BEFORECHECK表失败");
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CRecvHvps716::DeleteBeforeCheck()");
}

void CRecvHvps716::UnPack(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps716::UnPack()");

    //Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "szMsg[%s]", szMsg);

    int iRet = 0;

	// 解析716报文
    iRet = m_hvps716.ParseXml(szMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "解析报文失败[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "解析报文失败!");
    }

    // 获取工作日期
	GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
	m_strWorkDate = m_sWorkDate;
	
	char tmp[256] = {0};
	chgToDate(m_hvps716.ChckDt.c_str(), tmp);
	//m_hvps716.ChckDt = tmp;
	m_checkdate = tmp;
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_hvps716.ChckDt[%s]",m_hvps716.ChckDt.c_str());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps716::UnPack()");
}


void CRecvHvps716::GetDetail()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps716::GetDetail()");

    int iRet = m_hvbeforecheck.setctx(m_dbproc);
    if (SQL_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }

    int nParentNum = 0, nSendNum = 0, nRecvNum = 0;

    // 大额预对账表
    nParentNum = m_hvps716.GetNodeCountByName("Dtls");
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "nParentNum=[%d]", nParentNum);

   	for(int i=0; i<nParentNum; i++)
    {
    	ClearCycleValue();
		m_hvps716.MT            = m_hvps716.GetValueFromCycle("Dtls", "MT", i);
		m_hvps716.TxTpCd        = m_hvps716.GetValueFromCycle("Dtls", "TxTpCd", i);
		m_hvps716.SndgNbOfTxs   = m_hvps716.GetValueFromCycle("Dtls", "SndgNbOfTxs", i);
		m_hvps716.SndgCtrlSum   = m_hvps716.GetValueFromCycle("Dtls", "SndgCtrlSum", i);
		m_hvps716.RcvgNbOfTxs   = m_hvps716.GetValueFromCycle("Dtls", "RcvgNbOfTxs", i);
		m_hvps716.RcvgCtrlSum   = m_hvps716.GetValueFromCycle("Dtls", "RcvgCtrlSum", i);
	
		nSendNum = m_hvps716.GetInLoopNodeCnt("Dtls", i, "ChckngDtlOfSndg");
		for (int j = 1 ; j <= nSendNum ; ++j)
		{
			m_hvps716.ChckngDtlOfSndgOrgnlMsgId     = m_hvps716.GetValueFromLiLCycle("Dtls",i,"ChckngDtlOfSndg",j,"ChckngDtlOfSndgOrgnlMsgId");
			m_hvps716.ChckngDtlOfSndgOrgnlInstgPty  = m_hvps716.GetValueFromLiLCycle("Dtls",i,"ChckngDtlOfSndg",j,"ChckngDtlOfSndgOrgnlInstgPty");
			m_hvps716.ChckngDtlOfSndgOrgnlMT        = m_hvps716.GetValueFromLiLCycle("Dtls",i,"ChckngDtlOfSndg",j,"ChckngDtlOfSndgOrgnlMT");
			m_hvps716.ChckngDtlOfSndgCcy            = m_hvps716.GetValueFromLiLCycle("Dtls",i,"ChckngDtlOfSndg",j,"ChckngDtlOfSndgCcy");
			m_hvps716.ChckngDtlOfSndgAmt            = m_hvps716.GetValueFromLiLCycle("Dtls",i,"ChckngDtlOfSndg",j,"ChckngDtlOfSndgAmt");
			m_hvps716.ChckngDtlOfSndgPrcSts         = m_hvps716.GetValueFromLiLCycle("Dtls",i,"ChckngDtlOfSndg",j,"ChckngDtlOfSndgPrcSts");
            m_hvps716.ChckngDtlOfSndgCcy         = m_hvps716.GetValueFromLiLCycle("Dtls",i,"ChckngDtlOfSndg",j,"ChckngDtlOfSndgCcy");
            
			m_hvps716.getChckngDtlOfSndg();
			
			Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_hvps716.ChckngDtlOfSndgOrgnlMsgId[%s]",m_hvps716.ChckngDtlOfSndgOrgnlMsgId.c_str());
			Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_hvps716.ChckngDtlOfSndgAmt[%s]",m_hvps716.ChckngDtlOfSndgAmt.c_str());
			InsertChecklist("SR00");
		}
	
		nRecvNum = m_hvps716.GetInLoopNodeCnt("Dtls", i, "ChckngDtlOfRcvg");
		for (int k = 1 ; k <= nRecvNum; ++k)
		{ //业务接收明细清单
		    
			m_hvps716.ChckngDtlOfRcvgOrgnlMsgId   = m_hvps716.GetValueFromLiLCycle("Dtls",i,"ChckngDtlOfRcvg",k,"ChckngDtlOfRcvgOrgnlMsgId");

			m_hvps716.ChckngDtlOfRcvgOrgnlInstgPty = m_hvps716.GetValueFromLiLCycle("Dtls",i,"ChckngDtlOfRcvg",k,"ChckngDtlOfRcvgOrgnlInstgPty");
			
			m_hvps716.ChckngDtlOfRcvgOrgnlMT       = m_hvps716.GetValueFromLiLCycle("Dtls",i,"ChckngDtlOfRcvg",k,"ChckngDtlOfRcvgOrgnlMT");
			
			m_hvps716.ChckngDtlOfRcvgDbtCdtId      = m_hvps716.GetValueFromLiLCycle("Dtls",i,"ChckngDtlOfRcvg",k,"ChckngDtlOfRcvgDbtCdtId");
			
			m_hvps716.ChckngDtlOfRcvgAmt           = m_hvps716.GetValueFromLiLCycle("Dtls",i,"ChckngDtlOfRcvg",k,"ChckngDtlOfRcvgAmt");
			
			m_hvps716.ChckngDtlOfRcvgCcy = m_hvps716.GetValueFromLiLCycle("Dtls",i,"ChckngDtlOfRcvg",k,"ChckngDtlOfRcvgCcy");
			m_hvps716.ChckngDtlOfRcvgPrcSts        = m_hvps716.GetValueFromLiLCycle("Dtls",i,"ChckngDtlOfRcvg",k,"ChckngDtlOfRcvgPrcSts");
            m_hvps716.ChckngDtlOfRcvgCcy         = m_hvps716.GetValueFromLiLCycle("Dtls",i,"ChckngDtlOfRcvg",k,"ChckngDtlOfRcvgCcy");
			m_hvps716.getChckngDtlOfRcvg();
			
			Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_hvps716.ChckngDtlOfRcvgOrgnlMsgId[%s]",m_hvps716.ChckngDtlOfRcvgOrgnlMsgId.c_str());
			Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_hvps716.ChckngDtlOfRcvgAmt[%s]",m_hvps716.ChckngDtlOfRcvgAmt.c_str());
      InsertChecklist("SR01");
		}
		m_hvps716.getDtls(); 
      iRet = m_hvbeforecheck.commit();
	    if (SQL_SUCCESS != iRet)
	    {
	        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "db error[%d][%s]",
	        		iRet, m_hvbeforecheck.GetSqlErr());
	        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "db error");
	    }
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps716::GetDetail()");
}

void CRecvHvps716::InsertChecklist(LPCSTR szSRTP)
{
    SETCTX(m_hvbeforecheck);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps716::InsertChecklist()");

    int iRet = -1;

 //   m_hvchklstlist.m_prcsts          = "0000";	//业务处理状态
 //   m_hvchklstlist.m_instgdrctpty    = m_hvps716.InstgDrctPty;	//发起直接参与机构
      m_hvbeforecheck.m_instddrctpty    = m_hvps716.InstdDrctPty;	//接收直接参与机构
 
      m_hvbeforecheck.m_sndrcvtp            = szSRTP;					//发送接收标志
      m_hvbeforecheck.m_chkdt            = m_checkdate;			//对账日期
    
    
    double dAmount = 0.00;
    if (strncasecmp(szSRTP, "SR00", 4) == 0)
    {
	    m_hvbeforecheck.m_msgtype       = m_hvps716.ChckngDtlOfSndgOrgnlMT; //原报文类型
	    m_hvbeforecheck.m_orgmsgid        = m_hvps716.ChckngDtlOfSndgOrgnlMsgId;	//原报文标识号
	    m_hvbeforecheck.m_orgsendbank     = m_hvps716.ChckngDtlOfSndgOrgnlInstgPty;	//原报文发起机构号

	    //sscanf(m_hvps716.ChckngDtlOfSndgAmt.c_str(), "%0.2f", &dAmount);
	    //m_hvbeforecheck.m_amt             = dAmount;	//明细核对金额
	    
	    m_hvbeforecheck.m_amt     = atof(m_hvps716.ChckngDtlOfSndgAmt.c_str());	//明细核对金额
	//  m_hvchklstlist.m_orgnlccy        = "CNY";//m_hvps716.ChckngDtlOfSndgCcy; //明细核对币种
	    m_hvbeforecheck.m_msgprocstat     = m_hvps716.ChckngDtlOfSndgPrcSts;//处理状态
    }
    else
    {
        if(m_hvps716.ChckngDtlOfRcvgOrgnlMT == "CMT232" || m_hvps716.ChckngDtlOfRcvgOrgnlMT == "hpvs.141.001.01")
        {
            m_hvbeforecheck.m_sndrcvtp = m_hvps716.ChckngDtlOfRcvgDbtCdtId; // 如果是141 南商肯定是来报 该字段填写借贷标志
        }
	    m_hvbeforecheck.m_msgtype       = m_hvps716.ChckngDtlOfRcvgOrgnlMT; //业务类型编码
	    m_hvbeforecheck.m_orgmsgid      = m_hvps716.ChckngDtlOfRcvgOrgnlMsgId;	//原报文标识号
	    m_hvbeforecheck.m_orgsendbank   = m_hvps716.ChckngDtlOfRcvgOrgnlInstgPty;	//原报文发起机构号
   	//m_hvchklstlist.m_cdflag		 	 = m_hvps716.ChckngDtlOfRcvgDbtCdtId;

	    //sscanf(m_hvps716.ChckngDtlOfRcvgAmt.c_str(), "%0.2f", &dAmount);
	    
	    //m_hvbeforecheck.m_amt     = dAmount;	//明细核对金额
	    m_hvbeforecheck.m_amt     = atof(m_hvps716.ChckngDtlOfRcvgAmt.c_str());	//明细核对金额
	  //m_hvbeforecheck.m_orgnlccy        = "CNY";//m_hvps716.ChckngDtlOfRcvgCcy; //明细核对币种
	   m_hvbeforecheck.m_msgprocstat     = m_hvps716.ChckngDtlOfRcvgPrcSts;//处理状态
    }
    m_hvbeforecheck.m_chkstat      = "00";						//对账状态:00：初始状态
   Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_hvbeforecheck.m_amt[%f]",m_hvbeforecheck.m_amt);
    iRet = m_hvbeforecheck.insert();
    if (SQL_SUCCESS != iRet && DUPLICATE_KEY != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "新增HV_BEFORECHECK失败[%d][%s]",
            iRet, m_hvbeforecheck.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "新增HV_BEFORECHECK失败");
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps716::InsertChecklist()");
}

void CRecvHvps716::ClearCycleValue()
{ 
	m_hvps716.ChckngDtlOfSndgOrgnlMsgId       ="";
	m_hvps716.ChckngDtlOfSndgOrgnlInstgPty    ="";
	m_hvps716.ChckngDtlOfSndgOrgnlMT          ="";
	m_hvps716.ChckngDtlOfSndgAmt              ="";
	m_hvps716.ChckngDtlOfSndgPrcSts           ="";
  m_hvps716.ChckngDtlOfRcvgOrgnlMsgId         ="";
  m_hvps716.ChckngDtlOfRcvgOrgnlInstgPty      ="";
  m_hvps716.ChckngDtlOfRcvgOrgnlMT            ="";
  m_hvps716.ChckngDtlOfRcvgDbtCdtId           ="";
  m_hvps716.ChckngDtlOfRcvgAmt                ="";
  m_hvps716.ChckngDtlOfRcvgPrcSts             ="";
  m_hvps716.m_sChckngDtlOfSndg                ="";
  m_hvps716.m_sChckngDtlOfRcvg                ="";
}

void CRecvHvps716::CheckSign716()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps716::CheckSign716()");
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_hvps716.ChckDt[%s]",m_hvps716.ChckDt.c_str());
	m_hvps716.getOriSignStr();

	Trace(L_DEBUG, __FILE__, __LINE__, NULL,
			"m_hvps716.InstgDrctPty=[%s]", m_hvps716.InstgDrctPty.c_str());
	CheckSign(m_hvps716.m_sSignBuff.c_str(),
			m_hvps716.m_szDigitSign.c_str(),
			m_hvps716.InstgDrctPty.c_str());

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps716::CheckSign716()");
}



void CRecvHvps716::TransTable(string &msgtp, string &sndrcvtp, string &tablename)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps716::TransTable()");
	
	tablename = "";	
	
	if ( "hvps.111.001.01" == msgtp 
      || "hvps.112.001.01" == msgtp
      || "CMT100" == msgtp
      || "CMT101" == msgtp
      || "CMT102" == msgtp
      || "CMT103" == msgtp
      || "CMT105" == msgtp
      || "CMT108" == msgtp
      || "CMT121" == msgtp
      || "CMT122" == msgtp
      || "CMT123" == msgtp
      || "CMT124" == msgtp )
    {
        if ( "SR00" == sndrcvtp )
        {
            tablename = "HV_SNDEXCHGLIST";
        }
        else
        {
            tablename = "HV_RCVEXCHGLIST";
        }
    }
    else if ( "hvps.141.001.01" == msgtp 
           || "CMT232" == msgtp
           || "CMT407" == msgtp
           || "CMT408" == msgtp )
    {
		tablename = "HV_TROFACRCVLIST";
    }
    else if ( "hvps.633.001.01" == msgtp 
           || "hvps.631.001.01" == msgtp )
    {
		tablename = "HV_MNETSTLNTC";
    }
    else if ( "ccms.314.001.01" == msgtp 
           || "ccms.315.001.01" == msgtp
           || "CMT301"          == msgtp
           || "CMT302"          == msgtp)
    {
        tablename = "CM_TRANSINFOQRY";
    }
    else
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "未知的报文类型[%s]",  msgtp.c_str());
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps716::TransTable()");
}

INT32 CRecvHvps716::FindOriInfo(string &sTablename, string &sProcsts, double &dAmt) 
{
	int iRet = -1;
	if(sTablename == "HV_SNDEXCHGLIST")
	{
	    
		CHvsndexchglist hvsndlist;
		SETCTX(hvsndlist);
		hvsndlist.m_msgid = m_hvbeforecheck.m_orgmsgid;
		hvsndlist.m_instgindrctpty = m_hvbeforecheck.m_orgsendbank;

		iRet = hvsndlist.findByPK();
		if (SQLNOTFOUND == iRet) 
    	{
    	    
    		CHvsndexchglisthis hvsndlisthis;
    		SETCTX(hvsndlisthis);
			hvsndlisthis.m_msgid = m_hvbeforecheck.m_orgmsgid;
			hvsndlisthis.m_instgindrctpty = m_hvbeforecheck.m_orgsendbank;
			iRet = hvsndlisthis.findByPK();
			if (SQLNOTFOUND == iRet) 
			{
				return RTN_FAIL;
			}
			else if(OPERACT_SUCCESS != iRet)
			{
				sprintf(m_szErrMsg, "hvsndlisthis findByPK fail:  [%d][%s]", 
				 iRet, hvsndlisthis.GetSqlErr());
				Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
				PMTS_ThrowException(DB_GET_DATA_FAIL);
			}
			sProcsts = hvsndlisthis.m_busistate;
			dAmt     = hvsndlisthis.m_amount;
			return RTN_SUCCESS;
    	}
		else if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "hvsndlist findByPK fail:  [%d][%s]", 
			 iRet, hvsndlist.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}

		sProcsts = hvsndlist.m_busistate;
		dAmt     = hvsndlist.m_amount;
	}
	else if(sTablename == "HV_RCVEXCHGLIST")
	{
	    
		CHvrcvexchglist hvrcvlist;
		SETCTX(hvrcvlist);
		hvrcvlist.m_msgid = m_hvbeforecheck.m_orgmsgid;
		hvrcvlist.m_instgindrctpty = m_hvbeforecheck.m_orgsendbank;

		iRet = hvrcvlist.findByPK();
		if (SQLNOTFOUND == iRet) 
    	{
    	    
    		CHvrcvexchglisthis hvrcvlisthis;
    		SETCTX(hvrcvlisthis);
			hvrcvlisthis.m_msgid = m_hvbeforecheck.m_orgmsgid;
			hvrcvlisthis.m_instgindrctpty = m_hvbeforecheck.m_orgsendbank;
			iRet = hvrcvlisthis.findByPK();
			if (SQLNOTFOUND == iRet) 
			{
				return RTN_FAIL;
			}
			else if(OPERACT_SUCCESS != iRet)
			{
				sprintf(m_szErrMsg, "hvrcvlisthis findByPK fail:  [%d][%s]", 
				 iRet, hvrcvlisthis.GetSqlErr());
				Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
				PMTS_ThrowException(DB_GET_DATA_FAIL);
			}
			sProcsts = hvrcvlisthis.m_busistate;
			dAmt     = hvrcvlisthis.m_amount;
			return RTN_SUCCESS;
    	}
		else if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "hvrcvlist findByPK fail:  [%d][%s]", 
			 iRet, hvrcvlist.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}

		sProcsts = hvrcvlist.m_busistate;
		dAmt     = hvrcvlist.m_amount;
	}
	else if(sTablename == "HV_TROFACRCVLIST")
	{
	    
		CHvtrofacrcvlist hvtrolist;
		SETCTX(hvtrolist);
		hvtrolist.m_msgid = m_hvbeforecheck.m_orgmsgid;
		hvtrolist.m_instgindrctpty = m_hvbeforecheck.m_orgsendbank;
		hvtrolist.m_cdcode = m_hvbeforecheck.m_sndrcvtp;

		iRet = hvtrolist.findByPK();
		if (SQLNOTFOUND == iRet) 
    	{
    	    
    		CHvtrofacrcvlisthis hvtrolisthis;
    		SETCTX(hvtrolisthis);
			hvtrolisthis.m_msgid = m_hvbeforecheck.m_orgmsgid;
			hvtrolisthis.m_instgindrctpty = m_hvbeforecheck.m_orgsendbank;
			hvtrolisthis.m_cdcode = m_hvbeforecheck.m_sndrcvtp;
			iRet = hvtrolisthis.findByPK();
			if (SQLNOTFOUND == iRet) 
			{
				return RTN_FAIL;
			}
			else if(OPERACT_SUCCESS != iRet)
			{
				sprintf(m_szErrMsg, "hvtrolisthis findByPK fail:  [%d][%s]", 
				 iRet, hvtrolisthis.GetSqlErr());
				Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
				PMTS_ThrowException(DB_GET_DATA_FAIL);
			}
			sProcsts = hvtrolisthis.m_busistate;
			dAmt     = hvtrolisthis.m_amount;
			return RTN_SUCCESS;
		}
		else if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "hvtrolist findByPK fail:  [%d][%s]", 
			 iRet, hvtrolist.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}

		sProcsts = hvtrolist.m_busistate;
		dAmt     = hvtrolist.m_amount;
	}
	else if(sTablename == "HV_MNETSTLNTC")
	{
				CHvmnetstlntc hvmnetstlntc;
		SETCTX(hvmnetstlntc);
		string strSql = "MSGID = '";
		strSql += m_hvbeforecheck.m_orgmsgid;

		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "HV_MNETSTLNTC find(strSql)[%s]",  strSql.c_str());

		iRet = hvmnetstlntc.find(strSql);
		if(SQL_SUCCESS == iRet) 
		{
			int iCount = 0;
			while(SQL_SUCCESS == hvmnetstlntc.fetch())
			{
				iCount++;
				sProcsts = hvmnetstlntc.m_npcprcsts;
				dAmt     = hvmnetstlntc.m_amt;
				Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "HV_MNETSTLNTC find(iCount)[%d]",  iCount);
			}
			hvmnetstlntc.closeCursor();
		}
		else if(SQLNOTFOUND == iRet)
		{
			return RTN_FAIL;
		}
		else
		{
			sprintf(m_szErrMsg, "hvmnetstlntc find fail(strSql):  [%d][%s]", 
			 iRet, hvmnetstlntc.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	}
	else if(sTablename == "CM_TRANSINFOQRY")
	{
	    
		CCmtransinfoqry cmtransinfoqry;
		SETCTX(cmtransinfoqry);
		cmtransinfoqry.m_sysid = "HVPS";
		cmtransinfoqry.m_msgid = m_hvbeforecheck.m_orgmsgid;
		cmtransinfoqry.m_instgindrctpty = m_hvbeforecheck.m_orgsendbank;
		if(m_hvbeforecheck.m_sndrcvtp == "SR00") // 如果是往报
		{
			cmtransinfoqry.m_rsflag = "1";
		}
		else 
		{
			cmtransinfoqry.m_rsflag = "2";
		}
		
		iRet = cmtransinfoqry.findByPK();
		
		if (SQLNOTFOUND == iRet && cmtransinfoqry.m_rsflag == "1") 
    	{
    		cmtransinfoqry.m_rsflag = "0";
    		iRet = cmtransinfoqry.findByPK();
			if (SQLNOTFOUND == iRet) 
			{
				return RTN_FAIL;
			}
			else if(OPERACT_SUCCESS != iRet)
			{
				sprintf(m_szErrMsg, "cmtransinfoqry findByPK fail:  [%d][%s]", 
				 iRet, cmtransinfoqry.GetSqlErr());
				Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
				PMTS_ThrowException(DB_GET_DATA_FAIL);
			}
    	}
		else if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "cmtransinfoqry findByPK fail:  [%d][%s]", 
			 iRet, cmtransinfoqry.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
		sProcsts = cmtransinfoqry.m_busistate;
	}
	else
	{
		return RTN_FAIL;
	}
	return RTN_SUCCESS;
}

void CRecvHvps716::UpdateState()
{  Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps716::UpdateState()"); 

    int iRet = -1;
    STRING strSQL = "";
	string strSql = "CHKDT ='";
	strSql += m_checkdate;
	strSql += "' AND INSTDDRCTPTY = '";
	strSql += m_hvps716.InstdDrctPty;
	strSql += "'";

	int iCount = 0;
	
	SETCTX(m_hvbeforecheck);

	if(SQL_SUCCESS == m_hvbeforecheck.find(strSql))
	{
		while(SQL_SUCCESS ==m_hvbeforecheck.fetch())
		{
		/*状态 : 00 初始状态 01对账相符 02 金额不符 03状态不符 04本地少 05本地多 06金额状态不符 */
		
			string state = ""; //对账状态
			string procsts = "";//本地状态
			double amt = 0.00;//本地金额
			string tablename = "";

			//通过报文类型得到对应的表名
			TransTable(m_hvbeforecheck.m_msgtype, m_hvbeforecheck.m_sndrcvtp, tablename);		
			Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "tablename[%s]",  tablename.c_str());

			//找到原业务状态和金额
			if(!FindOriInfo(tablename, procsts, amt))
			{
				Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "本地[%s][%f] 来报[%s][%f]",procsts.c_str(),amt,m_hvbeforecheck.m_msgprocstat.c_str(),m_hvbeforecheck.m_amt);
				
				//浮点型精度不准确 将本地的金额与来报金额相减 如果误差小于千分位则认为相等
				double amtsub = amt - m_hvbeforecheck.m_amt;
				Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "amtsub[%.5f]", amtsub);
				
				//if( procsts!=m_hvbeforecheck.m_msgprocstat && fabs(amtsub) >= 0.001 )
				if( procsts!=m_hvbeforecheck.m_msgprocstat )
				{
					state = PR_BFCH_06;//金额状态不符
					Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "金额状态不符不符 msgid[%s]",m_hvbeforecheck.m_orgmsgid.c_str());
				}
				else if( procsts!=m_hvbeforecheck.m_msgprocstat )
				{
					state = PR_BFCH_03;//状态不符
					Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "状态不符 msgid[%s]",m_hvbeforecheck.m_orgmsgid.c_str());
				}
				/*else if( fabs(amtsub) >= 0.001 )
				{
					state = PR_BFCH_02;//金额不符
					Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "金额不符 msgid[%s]",m_hvbeforecheck.m_orgmsgid.c_str());
				}*/
				else
				{
					Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "对账相符 msgid[%s]",m_hvbeforecheck.m_orgmsgid.c_str());
					state = PR_BFCH_01;//对账相符
				}
				
				
			}
			else
			{
				Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "找不到原业务 本地少msgid[%s]",m_hvbeforecheck.m_orgmsgid.c_str());
				state = PR_BFCH_04;
			}
			Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "该条记录对账完毕 msgid[%s],state[%s]",m_hvbeforecheck.m_orgmsgid.c_str(), state.c_str());
			m_hvbeforecheck.m_chkstat = state;
			
			string strSQL;
        	strSQL += "UPDATE hv_beforecheck t SET t.chkstat = '";
        	strSQL += state;
        	strSQL += "'";
        	strSQL += " WHERE t.chkdt = '";
        	strSQL += m_hvbeforecheck.m_chkdt.c_str();
        	strSQL += "' AND t.orgmsgid = '";
        	strSQL += m_hvbeforecheck.m_orgmsgid.c_str();
        	strSQL += "' AND t.orgsendbank = '";
        	strSQL += m_hvbeforecheck.m_orgsendbank.c_str(); 	
        	strSQL += "' AND t.sndrcvtp = '";
        	strSQL += m_hvbeforecheck.m_sndrcvtp.c_str(); 									
        	strSQL += "'";
        	
        	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());
        	
        	SETCTX(m_hvbeforecheck);
        	int iRet = m_hvbeforecheck.execsql(strSQL.c_str());
        	if(iRet != RTN_SUCCESS)
        	{
        		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "修改发送状态失败iRet=%d, %s", iRet, m_hvbeforecheck.GetSqlErr());
        		PMTS_ThrowException(DB_UPDATE_FAIL);
        	}   
			if(++iCount%1000 == 0)
			{
			    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, " 到达1000笔, m_hvbeforecheck.commit()");
			    m_hvbeforecheck.commit();
		    }
				
		}
		m_hvbeforecheck.commit();
		m_hvbeforecheck.closeCursor();
	}
			
}

int CRecvHvps716::FindLocalMore(void)
{
	CHvsndexchglist sndlist;
	SETCTX(sndlist);

	char szSql[1024] = {0};
	snprintf(szSql, sizeof(szSql),
			" procstate='19' and instgdrctpty='%s' and finalstatedate='%s' and "
			"(instgindrctpty || msgid) not in (select orgsendbank || orgmsgid from hv_beforecheck "
			"where sndrcvtp='SR00' and chkdt='%s' and instddrctpty='%s' and msgtype not in ('CMT301', 'CMT302', 'ccms.314..001.01', 'ccms.315.001.01')) ",
			m_hvps716.InstdDrctPty.c_str(), m_hvps716.ChckDt.c_str(), m_checkdate.c_str(), m_hvps716.InstdDrctPty.c_str());

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "szSql=[%s]", szSql);

	int iRet = sndlist.find(szSql);
	if(iRet == SQL_SUCCESS){
		while(true){
			iRet = sndlist.fetch();
			if(iRet != SQL_SUCCESS){
				Trace(L_ERROR, __FILE__, __LINE__, NULL, "fetch ret=%d", iRet);
				break;
			}
			m_hvbeforecheck.m_chkdt       = m_checkdate;
			m_hvbeforecheck.m_msgtype     = sndlist.m_msgtp;
			m_hvbeforecheck.m_orgmsgid    = sndlist.m_msgid;
			m_hvbeforecheck.m_orgsendbank = sndlist.m_instgindrctpty;
			m_hvbeforecheck.m_amt         = sndlist.m_amount;
			m_hvbeforecheck.m_msgprocstat = sndlist.m_busistate;
			m_hvbeforecheck.m_chkstat     = PR_BFCH_05;
			m_hvbeforecheck.m_instddrctpty= m_hvps716.InstdDrctPty;
			m_hvbeforecheck.m_sndrcvtp    = "SR00";
			iRet = m_hvbeforecheck.insert();
			if(iRet != SQL_SUCCESS){
				m_hvbeforecheck.closeCursor();
				Trace(L_ERROR, __FILE__, __LINE__, NULL,
						"[hv_beforecheck]插入失败:%s", m_hvbeforecheck.GetSqlErr());
				PMTS_ThrowException(DB_INSERT_FAIL);
			}
		}
	}
	else{
		Trace(L_INFO, __FILE__, __LINE__, NULL, "find ret=%d", iRet);
	}

	if(iRet != SQL_SUCCESS && iRet != SQLNOTFOUND){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
					"[hv_sndexchglist]查找失败:%s", sndlist.GetSqlErr());
		sndlist.closeCursor();
		PMTS_ThrowException(DB_FIND_FAIL);
	}

	sndlist.closeCursor();

	return RTN_SUCCESS;
}

 
			
