/******************************************************************** 
�ļ����� sendhvps631.cpp
�����ˣ� xiaocuiming
��  �ڣ� 2011-05-17
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
    
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendhvps631.h"

CSendHvps631::CSendHvps631(const stuMsgHead & Smsg):CSendHvpsBase(Smsg)
{

}

CSendHvps631::~CSendHvps631()
{

}

void CSendHvps631::AddSign631()
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "entering CSendHvps631::AddSign631...");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_hvps631.getOriSignStr();
	
	AddSign(m_hvps631.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_hvps631.InstgDrctPty.c_str());
	
	m_hvps631.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendHvps631::AddSign631..."); 
}

void CSendHvps631::SetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendHvps631::SetData...");
    SETCTX(m_CHvmnetstllist);

    m_hvps631.MsgId = m_CHvmnetstlcl.m_msgid;
    int iRet = GetIsoDateTime(m_dbproc, SYS_HVPS, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }
    char szBuff[128]                 = {0};
    m_hvps631.CreDtTm = m_ISODateTime;
    m_hvps631.InstgDrctPty = m_CHvmnetstlcl.m_instgdrctpty;
    m_hvps631.GrpHdrInstgPty = m_CHvmnetstlcl.m_instgindrctpty;
    m_hvps631.InstdDrctPty = m_CHvmnetstlcl.m_instddrctpty;
    m_hvps631.GrpHdrInstdPty = m_CHvmnetstlcl.m_instdindrctpty;
    m_hvps631.SysCd = "HVPS";
    m_hvps631.Rmk = m_CHvmnetstlcl.m_remark;
    m_hvps631.TxTp = m_CHvmnetstlcl.m_txtp;
    m_hvps631.CtgyPurpCd = m_CHvmnetstlcl.m_ctgypurpcd;

    m_hvps631.MulNetSttlmInfNetgRnd = m_CHvmnetstlcl.m_netgrnd;

    memset(szBuff, 0, sizeof(szBuff));
    m_hvps631.DbtrAmt = ftoa(szBuff, m_CHvmnetstlcl.m_dbtramt, 2);
    memset(szBuff, 0, sizeof(szBuff));
    m_hvps631.CdtrAmt = ftoa(szBuff, m_CHvmnetstlcl.m_cdtramt, 2);
    
    m_hvps631.NbOfMmb = "1";//�������������Ҹ�ֵΪ1
    
    m_hvps631.PrcSts = m_CHvmnetstlcl.m_npcprcsts;
    m_hvps631.PrcCd = m_CHvmnetstlcl.m_npcprccd;
    m_hvps631.RjctInf = m_CHvmnetstlcl.m_rjctinf;
    m_hvps631.NPCPrcInfNetgRnd = m_CHvmnetstlcl.m_netgrnd;
    m_hvps631.SttlmDt = m_CHvmnetstlcl.m_sttlmdt;

    //���Ҹ�ֵ
    m_hvps631.NetgDt = m_CHvmnetstlcl.m_workdate;//��������
    m_hvps631.RcvTm = m_CHvmnetstlcl.m_stattime;//���ʱ��
    m_hvps631.TrnsmtTm = m_ISODateTime;//ϵͳʱ��
   

    string whereClause;
    whereClause += "MSGID = '" + m_CHvmnetstlcl.m_msgid +"'";
    whereClause += "and INSTGDRCTPTY = '" + m_CHvmnetstlcl.m_instgdrctpty;

    m_CHvmnetstllist.find(whereClause);
    while(0 == m_CHvmnetstllist.fetch())
    {
        m_hvps631.BookgId = m_CHvmnetstllist.m_bookgid;
        m_hvps631.DbtCdtId = m_CHvmnetstllist.m_dbtcdtid;
        memset(szBuff, 0, sizeof(szBuff));
        m_hvps631.Amt = ftoa(szBuff, m_CHvmnetstllist.m_amt, 2);
        m_hvps631.AmtCcy = m_CHvmnetstllist.m_currency;
        //m_hvps631.AddtlInf = ;
    }
    
    SETCTX(m_CHvmnetstlcumlist);
    whereClause.erase();
    whereClause += "MSGID = '" + m_CHvmnetstllist.m_msgid;
    whereClause += "' and INSTGDRCTPTY = '" + m_CHvmnetstllist.m_instgdrctpty;
    whereClause += "' and BOOKGID = '" + m_CHvmnetstllist.m_bookgid + "'";
    m_CHvmnetstlcumlist.find(whereClause);
    while(0 == m_CHvmnetstlcumlist.fetch())
    {
        m_hvps631.Issr = m_CHvmnetstlcumlist.m_cstmrissr;
        m_hvps631.Id = m_CHvmnetstlcumlist.m_cstrmrid;
        m_hvps631.Nm = m_CHvmnetstlcumlist.m_cstmrnm;
        memset(szBuff, 0, sizeof(szBuff));
        m_hvps631.CstmrAmt = ftoa(szBuff, m_CHvmnetstlcumlist.m_cstmramt, 2);
        m_hvps631.CstmrAmtCcy = m_CHvmnetstlcumlist.m_cstmramtccy;
        m_hvps631.BookgId = m_CHvmnetstlcumlist.m_bookgid;
    }
    /*
    if(2 == m_iVersion)
    {
    
		char MsgCode[16] = {0};
		sprintf(MsgCode, "%s.631.001.01", m_szSysFlagNO);
		Trace(L_DEBUG,	__FILE__,  __LINE__, NULL, "MsgCode = %s", MsgCode);
        //1�����ļ�ͷ 
        m_hvps631.CreateXMlHeader("HVPS",                        \
                                    m_CHvmnetstlcl.m_workdate.c_str(), \
                                    m_CHvmnetstlcl.m_instgdrctpty.c_str(),\
                                    m_CHvmnetstlcl.m_instddrctpty.c_str(),\
                                    MsgCode,\
                                    m_sMesgId.c_str()); 

    }
    */

    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendHvps631::SetData...");

}

void CSendHvps631::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps631::SetDBKey...");

    m_CHvmnetstlcl.m_msgid = m_szMsgFlagNO;
    m_CHvmnetstlcl.m_instgindrctpty = m_szSndNO;

    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "m_CHvmnetstlcl.m_msgid = [%s]", m_CHvmnetstlcl.m_msgid.c_str());
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "m_CHvmnetstlcl.m_instgindrctpty = [%s]", m_CHvmnetstlcl.m_instgindrctpty.c_str());

    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendHvps631::SetDBKey...");
    return;
}

int CSendHvps631::GetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendHvps631::GetData...");

    SETCTX(m_CHvmnetstlcl);
    SetDBKey();
    int iRet = m_CHvmnetstlcl.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ȡ����ʧ�� iRet = [%d], [%s]", iRet, m_CHvmnetstlcl.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendHvps631::GetData...");
    return iRet;

}

int CSendHvps631::UpdateState()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendHvps631::UpdateState...");

    
    SETCTX(m_CHvmnetstlcl);

    STRING strSql;

    strSql += "UPDATE hv_mnetstlcl t SET t.PROCSTATE = '01'";
    strSql += "WHERE t.MSGID = '";
    strSql += m_CHvmnetstlcl.m_msgid.c_str();
    strSql += "' and t.INSTGINDRCTPTY = '";
    strSql += m_CHvmnetstlcl.m_instgindrctpty;
    strSql += "'";

    Trace(L_INFO, __FILE__, __LINE__, NULL, "hv_mnetstlcl::strSql = [%s]", strSql.c_str());

    int iRet = m_CHvmnetstlcl.execsql(strSql.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸�hv_mnetstlcl״̬ʧ��iRet = %d, %s", iRet, m_CHvmnetstlcl.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }
    
    SETCTX(m_CHvmnetstllist);
    strSql.erase();

    strSql += "UPDATE hv_mnetstllist t SET t.PROCSTATE = '01'";
    strSql += "WHERE t.MSGID = '";
    strSql += m_CHvmnetstllist.m_msgid.c_str();
    strSql += "'AND t.INSTGDRCTPTY = '";
    strSql += m_CHvmnetstllist.m_instgdrctpty.c_str();
    strSql += "' AND t.BOOKGID = '";
    strSql += m_CHvmnetstllist.m_bookgid.c_str();
    strSql += "'";
    Trace(L_INFO, __FILE__, __LINE__, NULL, "hv_mnetstllist::strSql = [%s]", strSql.c_str());
    
    iRet = m_CHvmnetstllist.execsql(strSql);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸�hv_mnetstllist״̬ʧ��iRet = %d, %s", iRet, m_CHvmnetstllist.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendHvps631::UpdateState...");
    
    return iRet;
}

int CSendHvps631::doWorkSelf()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendHvps631::doWork...");
    int iRet = 0;
    
    GetData();


    SetData();

    //��ǩ
    /*if(2 == m_iVersion)
    {
        AddSign631();
    }*/

    
    iRet = m_hvps631.CreateXml();
    if(RTN_SUCCESS != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
     //3)	ҵ���飨�ͻ������룩
    //.......
    //4)	���������ͻ������룩
    //.....    

    UpdateState();
    
    AddQueue(m_hvps631.m_sXMLBuff.c_str(), m_hvps631.m_sXMLBuff.length());

    

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendHvps631::doWork...");
    return RTN_SUCCESS;

}
