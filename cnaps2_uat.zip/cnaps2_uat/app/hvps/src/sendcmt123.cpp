/******************************************************************** 
�ļ����� sendcmt123.cpp
�����ˣ� aps-xcm
��  �ڣ� 2011-06-22
�޸��ˣ� 
��  �ڣ� 
��  ���� һ������������л�Ʊ�����ʽ𻮻ر���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt123.h"

CSendCmt123::CSendCmt123(const stuMsgHead& Smsg):CSendHvpsBase(Smsg)
{
   
}

CSendCmt123::~CSendCmt123()
{
    
}

void CSendCmt123::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt123::SetDBKey...");

    m_Hvsndlist.m_msgtp = "CMT";
    m_Hvsndlist.m_msgtp = m_Hvsndlist.m_msgtp + m_szMsgType;
    
	m_Hvsndlist.m_msgid = m_szMsgFlagNO; 
	m_Hvsndlist.m_instgindrctpty = m_szSndNO; 

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_msgtp = %s", m_Hvsndlist.m_msgtp.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_msgid = %s", m_Hvsndlist.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_instgindrctpty = %s", m_Hvsndlist.m_instgindrctpty.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt123::SetDBKey...");
}

int CSendCmt123::GetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt123::GetData...");

    SETCTX(m_Hvsndlist);
    SetDBKey();
    int iRet = m_Hvsndlist.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ȡ����ʧ�ܣ� iRet = [%d]", iRet);
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    if(!m_Hvsndlist.m_endtoendid.empty())
    {
        m_sEndtoEnd = m_Hvsndlist.m_endtoendid;
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sEndtoEnd = %s", m_sEndtoEnd.c_str());
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt123::GetData...");
    return iRet;
    
}


void CSendCmt123::SetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt123::SetData...");
    
    strncpy(m_cCmt123.sConsigndate, m_Hvsndlist.m_workdate.c_str(), sizeof(m_cCmt123.sConsigndate) - 1);
    m_cCmt123.iTxssno = atoi(m_szMsgSerial);
    
    strncpy(m_cCmt123.sCur, m_Hvsndlist.m_currency.c_str(), sizeof(m_cCmt123.sCur) - 1);
    m_cCmt123.dAmount = m_Hvsndlist.m_amount;
    strncpy(m_cCmt123.sSendsapbk, m_Hvsndlist.m_dbtmmbid.c_str(), sizeof(m_cCmt123.sSendsapbk) - 1);
    strncpy(m_cCmt123.sSendbank, m_Hvsndlist.m_dbtid.c_str(), sizeof(m_cCmt123.sSendbank) - 1);
    strncpy(m_cCmt123.sRecvsapbk, m_Hvsndlist.m_cdtmmbid.c_str(), sizeof(m_cCmt123.sRecvsapbk) - 1);
    strncpy(m_cCmt123.sRecvbank, m_Hvsndlist.m_cdtid.c_str(), sizeof(m_cCmt123.sRecvbank) - 1);
    strncpy(m_cCmt123.sPayopenbk, m_Hvsndlist.m_dbtrissr.c_str(), sizeof(m_cCmt123.sPayopenbk) - 1);
    strncpy(m_cCmt123.sPayeracc, m_Hvsndlist.m_dbtracctid.c_str(), sizeof(m_cCmt123.sPayeracc) - 1);
    strncpy(m_cCmt123.sPayername, m_Hvsndlist.m_dbtnm.c_str(), sizeof(m_cCmt123.sPayername) - 1);
    strncpy(m_cCmt123.sPayeraddr, m_Hvsndlist.m_dbtaddr.c_str(), sizeof(m_cCmt123.sPayeraddr) - 1);

    string strTemp;
    GetTag1ST("30B:", strTemp, m_Hvsndlist.m_ustrdstr);
    strncpy(m_cCmt123.sBilldate, strTemp.c_str(), sizeof(m_cCmt123.sBilldate) -1);
    strTemp.erase();
    GetTag1ST("21A:", strTemp, m_Hvsndlist.m_ustrdstr);
    strncpy(m_cCmt123.sBillno, strTemp.c_str(), sizeof(m_cCmt123.sBillno) -1);
    strTemp.erase();
    GetTag1ST("C10:", strTemp, m_Hvsndlist.m_ustrdstr);
    strncpy(m_cCmt123.sDraftmac, strTemp.c_str(), sizeof(m_cCmt123.sDraftmac) -1);
    strTemp.erase();
    GetTag1ST("33C:", strTemp, m_Hvsndlist.m_ustrdstr);
    m_cCmt123.dTicketamount = atof(strTemp.c_str());
    strTemp.erase();
    GetTag1ST("CNV:", strTemp, m_Hvsndlist.m_ustrdstr);
    m_cCmt123.dSapamount = atof(strTemp.c_str());

    strncpy(m_cCmt123.sPayeeopenbk, m_Hvsndlist.m_cdtrissr.c_str(), sizeof(m_cCmt123.sPayeeopenbk) - 1);

    strTemp.erase();
    GetTag1ST("59E:", strTemp, m_Hvsndlist.m_ustrdstr);
    strncpy(m_cCmt123.sLastholdno, strTemp.c_str(), sizeof(m_cCmt123.sLastholdno) -1);
    strTemp.erase();
    GetTag1ST("59D:", strTemp, m_Hvsndlist.m_ustrdstr);
    strncpy(m_cCmt123.sLastholdname, strTemp.c_str(), sizeof(m_cCmt123.sLastholdname) -1);

    //strncpy(m_cCmt123.sPayeeacc, m_Hvsndlist.m_cdtracctid.c_str(), sizeof(m_cCmt123.sPayeeacc) - 1);

    strTemp.erase();
    GetTag1ST("30C:", strTemp, m_Hvsndlist.m_ustrdstr);
    strncpy(m_cCmt123.sTippaydate, strTemp.c_str(), sizeof(m_cCmt123.sTippaydate) -1);

    char SndCCPCNode[4 + 1] 	= {0};	
	char RcvCCPCNode[4 + 1] 	= {0};
    GetSapBkToCCPC(m_dbproc, m_Hvsndlist.m_instgindrctpty, SndCCPCNode);
	GetSapBkToCCPC(m_dbproc, m_Hvsndlist.m_instdindrctpty, RcvCCPCNode);
	strncpy(m_cCmt123.sSendsenter, SndCCPCNode, sizeof(m_cCmt123.sSendsenter) - 1);
	strncpy(m_cCmt123.sRecvsenter, RcvCCPCNode, sizeof(m_cCmt123.sRecvsenter) - 1);

	strncpy(m_cCmt123.sRemark, m_Hvsndlist.m_addinfo.c_str(), sizeof(m_cCmt123.sRemark) - 1);


    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt123::SetData...");
    

}

int CSendCmt123::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt123::buildCmtMsg...");

    int iRet = m_cCmt123.CreateCmt("123", m_Hvsndlist.m_instgdrctpty.c_str(), m_Hvsndlist.m_instddrctpty.c_str(), m_sMesgId.c_str(), m_sMesgId.c_str(), m_Hvsndlist.m_workdate.c_str(), m_Hvsndlist.m_sttlmprty.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt123::buildCmtMsg...");
    return iRet;
}



int CSendCmt123::UpdateState()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt123::UpdateState...");

    SETCTX(m_Hvsndlist);

    string strSQL;

    strSQL += "UPDATE hv_sndexchglist t SET t.STATETIME = sysdate, t.PROCSTATE = '08'";
	strSQL += ", t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
	strSQL += "', t.endtoendid = '";
	strSQL += m_sEndtoEnd;
    strSQL += "' ";
    
	strSQL += " WHERE t.MSGTP = '";
	strSQL += m_Hvsndlist.m_msgtp.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_Hvsndlist.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Hvsndlist.m_instgindrctpty.c_str(); 									
	strSQL += "'";
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "strSQL=[%s]", strSQL.c_str());
    int iRet = m_Hvsndlist.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��iRet=[%d], [%s]", iRet, m_Hvsndlist.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
        
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt123::UpdateState...");
    return iRet;
}

int CSendCmt123::doWorkSelf()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt123::doworkSelf...");
    //1)�������
    GetData();

    //2)��ֵ
    SetData();

	AddMac();
    
    buildCmtMsg();

    
    //3)	ҵ���飨�ͻ������룩
    //.......
    //4)	���������ͻ������룩


    UpdateState();

    AddQueue(m_cCmt123.m_strCmtmsg, m_cCmt123.m_strCmtmsg.length());
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt123::doworkSelf...");
    return RTN_SUCCESS;
    
}


int CSendCmt123::AddMac()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt123::AddMac...");
	int iRet = -1;
	
	m_cCmt123.SetSeal();//��ȡ��Ѻ��

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt123.sSendsapbk[%s]",m_cCmt123.sSendsapbk);
	
    iRet = CodeMac(m_dbproc,m_cCmt123.m_Seal.c_str(),m_cCmt123.sSendsapbk,m_cCmt123.m_szMacStr);
    if(0 != iRet)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "AddMac failed");
    	PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]",m_cCmt123.m_szMacStr);
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt123::AddMac..."); 
    
    return RTN_SUCCESS;
}
