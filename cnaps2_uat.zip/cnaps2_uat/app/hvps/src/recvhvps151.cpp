/******************************************************************** 
文件名： recvhv151.cpp
创建人： hq
日  期： 2011-03-14
修改人： 
日  期： 
描  述： 申请清算银行汇票资金报文<hvps.151.001.01>来账处理
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/
    
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvhvps151.h"

using namespace ZFPT;

CRecvHvps151::CRecvHvps151()
{
	m_iMsgVer	=	2;
	m_strMsgTp	=	"hvps.151.001.01";
}


CRecvHvps151::~CRecvHvps151()
{
	
}

INT32 CRecvHvps151::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps151::Work()");
	
	// 解析报文
	unPack(sMsg);
	
	// 新增数据库
	InsertDb(sMsg);		
	
	// 更新发送状态	
	UpdateState();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps151::work()");
	
	return RTN_SUCCESS;
}



INT32 CRecvHvps151::unPack(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps151::unPack");	

	int iRet = RTN_FAIL;

	//1、报文是否为空
	if (NULL == sMsg || '\0' == sMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "报文为空");
	}

	//2、获取工作日期
	iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");	
		PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
	}
	m_strWorkDate	=	m_sWorkDate;

	//4、解析报文
	iRet = m_cParser151.ParseXml(sMsg);
	if (RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错! iRet= %d", iRet);	
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文解析出错");	
	}

    //ZFPTLOG.SetLogInfo("151", m_cParser151.MsgId.c_str());
    
	m_strMsgID	=	m_cParser151.MsgId;

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps151::unPack");	

	return RTN_SUCCESS;
}

INT32 CRecvHvps151::InsertDb(LPCSTR pchMsg)
{    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps151::InsertDb");	

	//1、设置连接
	if (0 != m_cHvdraft.setctx(m_dbproc))
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
		PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
	}

	//2、赋值
	m_cHvdraft.m_msgtp          = m_strMsgTp;			                                //报文类型
	m_cHvdraft.m_msgid          = m_cParser151.MsgId;		                          //报文标识号
	m_cHvdraft.m_instgdrctpty   = m_cParser151.InstgDrctPty;                      //发起直接参与机构
	m_cHvdraft.m_wrkdate       	= m_strWorkDate;	                                //工作日期
	m_cHvdraft.m_consigndate    = m_strWorkDate;                                  //委托日期:二代报文等于工作日期
	m_cHvdraft.m_mesgid		      = m_cParser151.m_PMTSHeader.getMesgID();          //通信级标识号
	m_cHvdraft.m_mesgrefid	    = m_cParser151.m_PMTSHeader.getMesgRefID();      	//通信级参考号
	m_cHvdraft.m_msgdirect		  = SRC_FRCNAPS;	                                          //业务来源:1:PMTS 0:MB
	m_cHvdraft.m_instgindrctpty = m_cParser151.GrpHdrInstgPty;                    //发起参与机构
	m_cHvdraft.m_instddrctpty   = m_cParser151.InstdDrctPty;	                    //接收直接参与机构
	m_cHvdraft.m_instdindrctpty = m_cParser151.GrpHdrInstdPty;	                  //接收参与机构
	m_cHvdraft.m_drftdt			    = m_cParser151.Dt;	                              //出票日期
	m_cHvdraft.m_drftnb			    = m_cParser151.Nb;	                              //汇票号码
	m_cHvdraft.m_drfttstcd		  = atoi(m_cParser151.TstCd.c_str());	              //汇票密押
	m_cHvdraft.m_drfttp			    = m_cParser151.Tp;	                              //汇票种类
	m_cHvdraft.m_amount			    = atof(m_cParser151.Amt.c_str());	                //出票金额
	m_cHvdraft.m_ccy			      = m_cParser151.AmtCcy;	                          //出票币种
	m_cHvdraft.m_drftissrbk		  = m_cParser151.IssrBk;			                      //汇票签发行行号
	m_cHvdraft.m_drftrcvrnm		  = m_cParser151.RcvrNm;			                      //汇票收款人名称
	m_cHvdraft.m_drfthldrbk		  = m_cParser151.HldrBk;		      	                //最后持票人开户行
	m_cHvdraft.m_drfthldracct	  = m_cParser151.HldrAcct;		  	                  //最后持票人账号
	m_cHvdraft.m_drfthldrnm		  = m_cParser151.HldrNm;			  	                  //最后持票人名称
	m_cHvdraft.m_rmngamt		    = atof(m_cParser151.RmngAmt.c_str());             //多余金额
	m_cHvdraft.m_actlsttlmamt	  = atof(m_cParser151.ActlSttlmAmt.c_str());        //实际结算金额
	m_cHvdraft.m_rmnddtpmt		  = m_cParser151.RmndDtPmt;                         //提示付款日期
	m_cHvdraft.m_procstate		  = PR_HVBP_95;                                     //处理状态:95待发送
	m_cHvdraft.m_busistate		  = PROCESS_PR06;                                   //业务状态:PR06：待处理
	m_cHvdraft.m_npcmsg			    = "";		  	        		  	                      //NPC报文
	m_cHvdraft.m_mbmsg          = pchMsg;                                         //MB报文
	m_cHvdraft.m_reserve		    = m_cParser151.Rmk;		  	                    		//保留域=附言
	
	//打印
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_msgid=%s",m_cHvdraft.m_msgid.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_msgtp=%s",m_cHvdraft.m_msgtp.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_instgindrctpty=%s",m_cHvdraft.m_instgindrctpty.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_wrkdate=%s",m_cHvdraft.m_wrkdate.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_consigndate=%s",m_cHvdraft.m_consigndate.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_mesgid=%s",m_cHvdraft.m_mesgid.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_mesgrefid=%s",m_cHvdraft.m_mesgrefid.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_msgdirect=%s",m_cHvdraft.m_msgdirect.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_instgdrctpty=%s",m_cHvdraft.m_instgdrctpty.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_instddrctpty=%s",m_cHvdraft.m_instddrctpty.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_instdindrctpty=%s",m_cHvdraft.m_instdindrctpty.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_drftdt=%s",m_cHvdraft.m_drftdt.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_drftnb=%s",m_cHvdraft.m_drftnb.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_drfttstcd=%d",m_cHvdraft.m_drfttstcd);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_drfttp=%s",m_cHvdraft.m_drfttp.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_amount=%f",m_cHvdraft.m_amount);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_ccy=%s",m_cHvdraft.m_ccy.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_drftissrbk=%s",m_cHvdraft.m_drftissrbk.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_drftrcvrnm=%s",m_cHvdraft.m_drftrcvrnm.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_drfthldrbk=%s",m_cHvdraft.m_drfthldrbk.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_drfthldracct=%s",m_cHvdraft.m_drfthldracct.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_drfthldrnm=%s",m_cHvdraft.m_drfthldrnm.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_rmngamt=%f",m_cHvdraft.m_rmngamt);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_actlsttlmamt=%f",m_cHvdraft.m_actlsttlmamt);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_rmnddtpmt=%s",m_cHvdraft.m_rmnddtpmt.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_procstate=%s",m_cHvdraft.m_procstate.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_busistate=%s",m_cHvdraft.m_busistate.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvdraft.m_reserve=%s",m_cHvdraft.m_reserve.c_str());

	//入表
	int iRet = m_cHvdraft.insert();
	if (0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "insert失败[%d]", iRet);
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "新增Hvdraft表失败");
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps151::InsertDb");	

	return RTN_SUCCESS;
}


//更新发送状态
INT32 CRecvHvps151::UpdateState()
{
  Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps151::UpdateState...");
  
     string strSQL;
  
     strSQL += "UPDATE hv_draft t SET t.PROCSTATE = '";
     strSQL += PR_HVBP_08;
     strSQL += "'";
  
     strSQL += " WHERE t.MSGID = '";
     strSQL += m_cParser151.MsgId;
     strSQL += "' AND t.INSTGDRCTPTY = '";
     strSQL += m_cParser151.InstgDrctPty;                  
     strSQL += "'";
     Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
  
     int iRet = m_cHvdraft.execsql(strSQL.c_str());
     if(RTN_SUCCESS != iRet)
     {
         Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "UpdateState error:[%d]", iRet);
         PMTS_ThrowException(DB_UPDATE_FAIL);
     }
  
     Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps151::UpdateState...");
     return RTN_SUCCESS;
  
 }

	

