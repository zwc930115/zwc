/********************************************************************
文件名：sendthvps.cpp
创建人：hdf
日  期：2011.01.14
修改人：hdf
日  期：
描  述：客户端业务往账处理主控
版  本：
Copyright (c) 2009  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
//#include "sqlca.h"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <signal.h>
//#include "exception.h"
//#include "pubfunc.h"
//#include "configparser.h"
//#include "thread.h"
//#include "sendhvpswork.h"
//#include "tsocket.h"
//#include "connectpool.h"
//#include "cfg_obj.h"
//#include "logger.h"
//#include "CNAPS2hsm.h"
//#include "assist.h"
//#include "libconntest.h"

//using namespace ZFPT;

#define MQ_ERR_MAX_TIMES 3

//CThreadPool<CSendHvpsWork> cPool;
//CConnectPool	*g_DBConnPool;
//CCfgObj 		 pCfgFile;

char			g_MQmgr[256];
char			g_MqTxtPath[256];
char			g_SendQueue[128];
char			g_ReturnQueue[128];
char            g_SendCBSP[128];
int             g_IsConnCBSP;
char            g_IP[16];
int         	g_IsConnPlatm;
char			g_CfcaPfxPath[256];//pfx证书文件名
char			g_CfcaCrlPath[256];//crl证书文件名
char			g_CfcaP7bPath[256];//p7b证书文件名
char			g_CfcaKey[128];   //证书文件名key


typedef struct
{
	unsigned char alg;
	int len;
}TSPARM;

//int test_mac()
//{
//	unsigned char rc;
//	unsigned char key[16];
//	unsigned char mac[20];
//	unsigned char result;
//	FILE *fp;
//	char pszKey[]="6ed9eba18f1bbcdca953fd4e50a28be6";
//	unsigned char text[16384];
//	int i, x;
//	TSPARM tparm[] = 
//	{
//
//		'1', 128,
//		'2', 128,
//	};
//	unsigned char alg;
//	int len = 32;
//	int index  = 510;
//
//	str2hex(32, pszKey, key);
//	fp = fopen("TestMac.txt", "rb");
//	if(fp == NULL)
//	{
//		printf("err open TestMac.txt\n");
//		exit(1);
//	}
//	fread(text, 1, 16384, fp);
//	fclose(fp);
//
//#if 1
//	for(i = 0; i < sizeof(tparm)/sizeof(TSPARM); i++)
//	{
//		alg = tparm[i].alg;
//		len = tparm[i].len;
//
//		CNAPS2_GenerateMac_ByKeyIndex(&rc, alg, index, len, text, mac);
//		if(rc)
//		{
//			printf("test_mac CNAPS2_GenerateMac_ByKeyIndex err 0x%x\n", rc);
//			exit(1);
//		}
//		else
//		{
//			printf("密押算法%c，内部密钥编押函数：CNAPS2_GenerateMac_ByKeyIndex 成功!\n\n", alg);
//		}
//
//		CNAPS2_VerifyMac_ByKeyIndex(&rc, alg, index, len, text, mac, &result);
//		if(rc)
//		{
//			printf("test_mac CNAPS2_VerifyMac_ByKeyIndex err 0x%x\n", rc);
//			exit(1);
//		}
//		else
//		{
//			printf("密押算法%c，内部密钥核押函数：CNAPS2_VerifyMac_ByKeyIndex 成功!\n\n", alg);
//		}
//		//printf("\n");
//	}
//#endif
//
//#if 1
//	for(i = 0; i < sizeof(tparm)/sizeof(TSPARM); i++)
//	{
//		alg = tparm[i].alg;
//		len = tparm[i].len;
//
//		CNAPS2_GenerateMac_ByPlainkey(&rc, alg, key, len, text, mac);
//		if(rc)
//		{
//			printf("test_mac CNAPS2_GenerateMac_ByPlainkey err 0x%x\n", rc);
//			exit(1);
//		}
//		else
//		{
//			printf("密押算法%c，外部密钥编押函数：CNAPS2_GenerateMac_ByPlainkey 成功!\n\n", alg);
//		}
//		
//		CNAPS2_VerifyMac_ByPlainkey(&rc, alg, key, len, text, mac, &result);
//		if(rc)
//		{
//			printf("test_mac CNAPS2_VerifyMac_ByPlainkey err 0x%x\n", rc);
//			exit(1);
//		}
//		else
//		{
//			printf("密押算法%c，外部密钥核押函数：CNAPS2_VerifyMac_ByPlainkey 成功!\n\n", alg);
//		}
//		//printf("\n");
//	}
//#endif
//	return 0;
//}


int main(int argc, char * argv[])
{
    char sErrDesc[1024 + 1] = {0};
    int iRet                =  0 ;
//    stuCfgInfo           CfgInfo ;
//    string strErr;
//    MQAgent              cAgent;
    
    memset(g_IP, 0x00, sizeof(g_IP));
    
	//初始化全局参数
	signal(SIGINT , SIG_IGN);							//屏蔽中断信号
	signal(SIGQUIT, SIG_IGN);							//屏蔽终端退出信号
	signal(SIGALRM, SIG_IGN);							//屏蔽超时信号
	signal(SIGHUP , SIG_IGN);							//屏蔽连接断开信号
	signal(SIGSTOP, SIG_IGN); 							//这些信号被忽略
	//signal(SIGCHLD, SIG_IGN);
    
    short int iLeng1 = 72;
    short int iLeng = 0;
    
    printf("%.0f\n", 1.0011 * 10000);
    
    iLeng = htons(iLeng1);
    
    memcpy(sErrDesc, &iLeng1, sizeof(iLeng1));
    for(int i =0; i<sizeof(iLeng1); i++)
    {
    	printf("%02x\n", sErrDesc[i] ^ 0);
    }
    
    printf("*****************************\n");
    memset(sErrDesc, 0x00, sizeof(sErrDesc));
    memcpy(sErrDesc, &iLeng, sizeof(iLeng));
    for(int i =0; i<sizeof(iLeng); i++)
    {
    	printf("%02x\n", sErrDesc[i] ^ 0);
    }
    
//    try
//    {
    	unsigned char pReturnCode;
    	unsigned char ucMacAlgFlag='1';
    	unsigned int uiIndex = 510;
    	unsigned int uiTextLen = 128;
//    	unsigned char pucText[MAX_MAC_LEN + 1] = {0};
    	unsigned char pucMax[20] = {0};
    	
//    	while(1)
//    	{
//	    	strcpy((char *)pucText, "KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK");
//	    	//uiTextLen = strlen((char *)pucText);    	
//	    	
//	    	CNAPS2_GenerateMac_ByKeyIndex(&pReturnCode, ucMacAlgFlag, uiIndex, uiTextLen, pucText, pucMax);
//	    	
//	    	if(pReturnCode == 0x00)
//				{
//		//			Trace(L_INFO, __FILE__, __LINE__, NULL, "加押成功。");
//		//			strcpy(pMacStr, MbBinToHex(pucMax, strlen((char *)pucMax)).c_str());
//		//			iRet = 0;
//					
//					printf("加押失败，错误代码[%02x]", pReturnCode);
//				}
//				else
//				{
//		//			Trace(L_ERROR, __FILE__, __LINE__, NULL, "加押失败，错误代码[%02x]", ucReturnCode);
//		//			sprintf((char *)pucMax, "加押失败, 错误代码=[%02x]", ucReturnCode);
//		//			strcpy(pMacStr, (char *)pucMax);
//		//			iRet = -1;
//					printf("加押失败，错误代码[%02x]\n", pReturnCode);
//					printf("pucMax=[%s]\n", pucMax);
//				}
//		}
		
//		CTestConnect OtestConnect;
//		DBProc dbproc;
//		int nRet = OtestConnect.TestDBConnect(1,"mbis","mbis","orcl",dbproc);
    	
//    	int g_socketfd;
//    	iRet=0;
//    	unsigned char buf[256] = {0};
//    	unsigned char pSignData[9100] = {0};
//    	char sCertDN[256] = {0};
//    	char sTemp[256] = {0};
//    	int msglen = 0;
//    	int iOutLen = 0;
//    	
//    	iRet = Connect("192.168.100.2", 878, "111111", &g_socketfd);
//    	
//    	printf("**********************connect to cfca iRet=[%d]**************************\n", iRet);
//    	
//    	strcpy(sTemp, "*****************************cfca for test*****************************");
//    	strcpy(buf, (unsigned char *)sTemp);
//    	msglen = strlen((char *)buf);
//    	
//    	strcpy(sCertDN,"CN=041@7533290000019@JPMC@00000002,OU=Enterprises,OU=CNAPS,O=CFCA TEST CA,C=CN");
//    	
//    	iRet = RawSign(g_socketfd, buf, msglen, sCertDN, pSignData, &iOutLen);
//    	printf("********************** after RawSign iRet=[%d]**************************\n", iRet);
//    	printf("********************** pSignData [%s]**************************\n", pSignData);
//    	printf("********************** iOutLen [%d]**************************\n", iOutLen);
//    	
//    	printf("test_mac() --------- begin --------------\n");
//    	test_mac();
//    	printf("test_mac() --------- end   --------------\n");
//
	
    return 0;
}

