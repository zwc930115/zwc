/******************************************************************** 
�ļ����� recvhvps633.cpp
�����ˣ� xiaocuiming
��  �ڣ� 2011-5-26
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvhvps633.h"

using namespace ZFPT;

CRecvHvps633::CRecvHvps633()
{

}


CRecvHvps633::~CRecvHvps633()
{

}

INT32 CRecvHvps633::unPack(LPCSTR sMsg)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvHvps633::unPack...");
    int iRet = RTN_FAIL;
    
    //1.�жϱ����Ƿ�Ϊ��
    if(NULL == sMsg || '\0' ==sMsg)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "����Ϊ��");
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }

    //2.��ù�����ǰ
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS, NULL);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ȡ������ǰʧ��");
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;

    //4.��������
    iRet = m_hvps633.ParseXml(sMsg);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "���Ľ���ʧ�� ! iRet = [%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ���ʧ��");
        
    }

    ZFPTLOG.SetLogInfo("633", m_hvps633.MsgId.c_str());
    m_strMsgID = m_hvps633.MsgId;

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvHvps633::unPack...");

    return RTN_SUCCESS;
}

INT32 CRecvHvps633::CheckValues()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvHvps633::CheckValues...");


    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvHvps633::CheckValues...");
    
    return RTN_SUCCESS;
}

void CRecvHvps633::CheckSign633()
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvHvps633::CheckSign633...");
	
	m_hvps633.getOriSignStr();
	
	CheckSign(m_hvps633.m_sSignBuff.c_str(),
						m_hvps633.m_szDigitSign.c_str(),
						m_hvps633.InstgDrctPty.c_str());
	
	Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvHvps633::CheckSign633...");
}

INT32 CRecvHvps633::InsertDb(LPCSTR pchMsg)
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvHvps633::InsertDb...");
    
    char szBalTemp[21+1];
    memset(szBalTemp, 0x00,sizeof(szBalTemp));

    //��������
    if(0 != m_CHvmnetstlntc.setctx(m_dbproc))
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��hv_mnetstlntc����ʧ�� setctx erro");
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "��hv_mnetstlntc����ʧ�� setctx erro");
    }

    //��ֵ
    m_CHvmnetstlntc.m_rjctinf = m_hvps633.RjctInf;
    m_CHvmnetstlntc.m_sttlmdt = m_hvps633.SttlmDt;
    m_CHvmnetstlntc.m_procstate = PR_HVBP_19;
    m_CHvmnetstlntc.m_txtp = m_hvps633.TxTp;
    m_CHvmnetstlntc.m_ctgypurpcd = m_hvps633.CtgyPurpCd;
    m_CHvmnetstlntc.m_orgnlmsgid = m_hvps633.OrgnlMsgId;
    m_CHvmnetstlntc.m_orgnlinstgpty = m_hvps633.OrgnlInstgPty;
    m_CHvmnetstlntc.m_orgnlmt = m_hvps633.OrgnlMT;
    m_CHvmnetstlntc.m_workdate = m_strWorkDate;
    m_CHvmnetstlntc.m_msgtp = m_hvps633.m_PMTSHeader.getMesgType();
    m_CHvmnetstlntc.m_msgid = m_hvps633.MsgId;
    m_CHvmnetstlntc.m_instgdrctpty = m_hvps633.InstgDrctPty;
    m_CHvmnetstlntc.m_instgindrctpty = m_hvps633.GrpHdrInstgPty;
    m_CHvmnetstlntc.m_instddrctpty = m_hvps633.InstdDrctPty;
    m_CHvmnetstlntc.m_instdindrctpty = m_hvps633.GrpHdrInstdPty;
    m_CHvmnetstlntc.m_remark = m_hvps633.Rmk;
    m_CHvmnetstlntc.m_dbtcdtid = m_hvps633.DbtCdtId;
    
    if(m_hvps633.NPCPrcInfNetgRnd == "")
    {
    	m_CHvmnetstlntc.m_netgrnd = "0";
    }
    else
    {
	    m_CHvmnetstlntc.m_netgrnd = m_hvps633.NPCPrcInfNetgRnd;
  	}
    m_CHvmnetstlntc.m_amt = atof(m_hvps633.Amt.c_str());
    m_CHvmnetstlntc.m_currency = m_hvps633.AmtCcy;
    m_CHvmnetstlntc.m_addinfo = m_hvps633.AddtlInf;
    
    memcpy(szBalTemp,m_hvps633.Bal.c_str()+4,(m_hvps633.Bal.length()-4));
    m_CHvmnetstlntc.m_bal = atof(szBalTemp);
    m_CHvmnetstlntc.m_balccy = m_hvps633.Bal.substr(0,3);//��ǰ������

    m_CHvmnetstlntc.m_npcprccd = m_hvps633.PrcCd;//NPC������
    m_CHvmnetstlntc.m_npcprcsts = m_hvps633.PrcSts;//NPC����״̬
    
    

	int iCycle = 0;

	int iRet = -1;
	
	char *pCycleNode = "CstmrInf";
	
	iCycle = m_hvps633.GetNodeCountByName("CstmrInf");
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, " iCycle = %d",iCycle);
    
    m_CHvmnetstlntc.m_cstmrinf = "";
    
	for(int i = 0;i < iCycle;i++)
	{
	    m_hvps633.Issr= m_hvps633.GetValueFromCycle(pCycleNode,"Issr",i);//   �ͻ��������к�
		m_CHvmnetstlntc.m_cstmrinf +="/Issr/" + m_hvps633.Issr + ":";
	    
	    m_hvps633.Id= m_hvps633.GetValueFromCycle(pCycleNode,"Id",i);//  �ͻ��˺�
		m_CHvmnetstlntc.m_cstmrinf +="/Id/" + m_hvps633.Id + ":";
		
		m_hvps633.Nm= m_hvps633.GetValueFromCycle(pCycleNode,"Nm",i);//  �ͻ�����
		m_CHvmnetstlntc.m_cstmrinf +="/Nm/" + m_hvps633.Nm + ":";
		
		m_hvps633.CstmrAmt= m_hvps633.GetValueFromCycle(pCycleNode,"CstmrAmt",i);//  �ͻ�ҵ����
		m_CHvmnetstlntc.m_cstmrinf +="/CstmrAmt/" + m_hvps633.CstmrAmt + ":";
		
		m_hvps633.CstmrAmtCcy= m_hvps633.GetValueFromCycle(pCycleNode,"CstmrAmtCcy",i);//  �ͻ�ҵ����
		m_CHvmnetstlntc.m_cstmrinf +="/CstmrAmtCcy/" + m_hvps633.CstmrAmtCcy + ":";	  

		m_hvps633.CstmrDbtCdtId = m_hvps633.GetValueFromCycle(pCycleNode, "CstmrDbtCdtId", i);
		m_CHvmnetstlntc.m_cstmrinf +="/CstmrDbtCdtId/" + m_hvps633.CstmrDbtCdtId + ":";

        m_hvps633.getCstmrInf();
    }
  
    char time[19 + 1];
    iRet = GetIsoDateTime(m_dbproc, SYS_HVPS, time);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }
    m_CHvmnetstlntc.m_statetime = time;//���ʱ��

    
    //�������ݱ�
    iRet = 0;
    iRet = m_CHvmnetstlntc.insert();
    if(0 != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,
            "m_CHvmnetstlntc.insert failed:error code = [%d],error cause = [%s]", iRet,m_CHvmnetstlntc.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "����Hvrcvexchglist��ʧ��");
    }
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvHvps633::InsertDb...");
    return RTN_SUCCESS;
    
    
}

INT32 CRecvHvps633::Work(LPCSTR sMsg)
{

	Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CRecvHvps633::Work...");

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "recvMsg=[%s]",sMsg);

	//��������
	unPack(sMsg);
	
	//ҵ����
	CheckValues();
	
	//�������ݱ�
	InsertDb(sMsg);
	
	//��ǩǩ��
	CheckSign633();	
	
	Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CRecvHvps633::Work...");
	
	return RTN_SUCCESS;

}
