/******************************************************************** 
 �ļ����� recvhvps713.cpp
 �����ˣ� hq
 ��  �ڣ� 2011-05-13
 �޸��ˣ� 
 ��  �ڣ� 
 ��  ���� ���ҵ����ϸ�˶�Ӧ����<hvps.713.001.01>
 ��  ���� 
 Copyright (c) 2011  YLINK 
 ********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif
#include "recvhvps713.h"

using namespace ZFPT;

extern char		g_SendQueue[128];
//extern char        g_szCLISENDHVPS[128];

CRecvHvps713::CRecvHvps713()
{
    m_bLast713 = false;
}

CRecvHvps713::~CRecvHvps713()
{
    
}

void CRecvHvps713::updateBkChkSt(LPCSTR _sChkSt)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvHvps713::updateBkChkSt()");

    int iRet = -1;
    
    CCheckAccount   m_checkaccount;
    SETCTX(m_checkaccount);
    iRet = m_checkaccount.upHvBkChkSt(m_hvps713.InstdDrctPty.c_str(), m_hvps713.ChckDt.c_str(), _sChkSt);
    if ( iRet != SQL_SUCCESS )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "����HV_BKCHKST��ʧ��[%d][%s]", 
            iRet, m_checkaccount.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "����HV_BKCHKST��ʧ��");
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CRecvHvps713::updateBkChkSt()");
}

bool CRecvHvps713::ChickIfContuine()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps713::ChickIfContuine()");

    int  iRet = -1;

	m_checkqry.m_msgid = m_hvps713.DtlRspnOrgnlMsgId;
	m_checkqry.m_msgtype = m_hvps713.DtlRspnOrgnlMT;
	m_checkqry.m_sapbank = m_hvps713.DtlRspnOrgnlInstgPty;
	SETCTX(m_checkqry);
	iRet = m_checkqry.findByPK();
	if(1403 != iRet && 0 != iRet)
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FIND CM_CHECKQRY FILED[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "FIND CM_CHECKQRY FILED!");
	}
	else if(1403 == iRet)
	{	
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "MSGID=[%s] MSGTP=[%s] SAPBANK=[%s] NOT PMTS QRY",
			                        m_checkqry.m_msgid.c_str(),m_checkqry.m_msgtype.c_str(),m_checkqry.m_sapbank.c_str());		
		return false;
	}
	else{
		
		string strSql = "SAPBANK = '"+ m_checkqry.m_sapbank + "' AND CHECKDATE = '" + m_hvps713.ChckDt +"' AND MSGTYPE = 'hvps.712.001.01'";
		
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=[%s]",strSql.c_str());
		
		iRet = m_checkqry.findcount(strSql);
		
		if(1403 != iRet && 0 != iRet)
		{
	        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FIND CM_CHECKQRY FILED[%d]", iRet);
	        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "FIND CM_CHECKQRY FILED!");
		}
		if(m_checkqry.m_iCount > 2)
		{
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql[%s] times[%d] > 2",strSql.c_str(),m_checkqry.m_iCount);
			return false;
		}
		else
		{
			return true;
		}
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "CRecvHvps713::ChickIfContuine()");
	return true;
}


int CRecvHvps713::Work(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps713::Work()");

    // ����713����
    UnPack(szMsg);

    // ���оܾ���������
    if ( PROCESS_PR09 == m_hvps713.NPCPrcInfPrcSts)
    {
        sprintf(m_szErrMsg, "NPC�ܾ�713[%s][%s]", m_hvps713.NPCPrcInfPrcSts.c_str(), m_hvps713.RjctInf.c_str());
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        //NotifyOprUser(m_dbproc, "2", "01", m_szErrMsg, m_hvps713.InstdDrctPty.c_str());
        return 0;
    }

	if(!ChickIfContuine())
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Do nothing return");
		return 0;
	}

	
    //ɾ������������ϸ��������
    DeleteChecklist();

    // ������ϸ�˶Ը�����
    InsertChkLstCl();
    
    // ���������嵥
    GetDetail();
    
    // ����ǩ������ǩ
    CheckSign713();

	// �ж��Ƿ��ѽ������713
    isContinue();
    
	// ���������713��������ϸ������
    if (m_bLast713)
    {
		m_hvchecklist.doCheckListWork(m_dbproc, 
	                            0, 
	                            m_hvps713.ChckDt.c_str(),
	                            m_hvps713.InstdDrctPty.c_str(),
	                            m_cMQAgent,
	                            g_SendQueue);

		m_hvchklstlist.commit();
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_hvchecklist.m_iTtlCnt=[%d]",m_hvchecklist.m_iTtlCnt);
		
		if(m_hvchecklist.m_iTtlCnt == 0)//�������Ҫ������ϸ������������ܶ���
		{
			Send710();
		}
		else
		{
			m_hvbkchkst.m_sapbank = m_hvps713.InstdDrctPty;
			m_hvbkchkst.m_checkdate = m_hvps713.ChckDt;
			SETCTX(m_hvbkchkst);
			int iRet = m_hvbkchkst.findByPK();
			if( 0 != iRet)
			{
		        Trace(L_ERROR, __FILE__, __LINE__, NULL, "m_hvbkchkst.findByPK() ERROR [%d][%s]", 
		            iRet, m_hvbkchkst.GetSqlErr());
		        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "m_hvbkchkst.findByPK() ERROR");			
			}

			m_hvbkchkst.m_detailnm = m_hvchecklist.m_iTtlCnt;
			m_hvbkchkst.m_rcvnm = 0;
			iRet = m_hvbkchkst.updatestate();
			if( 0 != iRet)
			{
		        Trace(L_ERROR, __FILE__, __LINE__, NULL, "m_hvbkchkst.updatestate() ERROR [%d][%s]", 
		            iRet, m_hvbkchkst.GetSqlErr());
		        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "m_hvbkchkst.updatestate() ERROR");			
			}		
		}
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps713::Work()");
	return 0;
}

void CRecvHvps713::DeleteChecklist()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvHvps713::DeleteChecklist()");
    
    if(atoi(m_hvps713.TtlNb.c_str()) != atoi(m_hvps713.EndNb.c_str()) ||
        atoi(m_hvps713.StartNb.c_str()) != 1 )
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "�ñ����Ƿ�Ƭ���ģ�����������ݲ������˳�������");
        return;
    }
    
    SETCTX(m_hvchklstcl);
    string szDelSql = "";
    int iRet = -1;
    
    szDelSql = "delete from HV_CHKLSTCL t where t.CHCKDT = '";
    szDelSql += m_hvps713.ChckDt;
    szDelSql += "' and INSTDDRCTPTY = '";
    szDelSql += m_hvps713.InstdDrctPty;
    szDelSql += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "szDelSql=[%s]",szDelSql.c_str());

    iRet = m_hvchklstcl.execsql(szDelSql);
    if ( iRet != SQL_SUCCESS && iRet != SQLNOTFOUND )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "ɾ��HV_CHKLSTCL��ʧ��[%d][%s]", 
            iRet, m_hvchklstcl.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "ɾ��HV_CHKLSTCL��ʧ��");
    }
    
    szDelSql = "";
    szDelSql = "delete from HV_CHKLSTLIST t where t.CHCKDT = '";
    szDelSql += m_hvps713.ChckDt;
    szDelSql += "' and INSTDDRCTPTY = '";
    szDelSql += m_hvps713.InstdDrctPty;
    szDelSql += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "szDelSql=[%s]",szDelSql.c_str());
	
    SETCTX(m_hvchklstlist);
    iRet = m_hvchklstlist.execsql(szDelSql);
    if ( iRet != SQL_SUCCESS && iRet != SQLNOTFOUND )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "ɾ��HV_CHKLSTLIST��ʧ��[%d][%s]", 
            iRet, m_hvchklstlist.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "ɾ��HV_CHKLSTLIST��ʧ��");
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CRecvHvps713::DeleteChecklist()");
}

void CRecvHvps713::UnPack(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps713::UnPack()");

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "szMsg[%s]", szMsg);
    
    int iRet = 0;

	// ����713����
    iRet = m_hvps713.ParseXml(szMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��������ʧ��[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "��������ʧ��!");
    } 

    // ��ȡ��������
	GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS, m_hvps713.InstdDrctPty.c_str());
	m_strWorkDate = m_sWorkDate;

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps713::UnPack()");
}

void CRecvHvps713::InsertChkLstCl()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps713::InsertChkLstCl()");
	
    int iRet = -1;

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "MsgId[%s]",                m_hvps713.MsgId.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "InstgDrctPty[%s]",         m_hvps713.InstgDrctPty.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ChckDt[%s]",               m_hvps713.ChckDt.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "InstdDrctPty[%s]",         m_hvps713.InstdDrctPty.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "Rmk[%s]",                  m_hvps713.Rmk.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "DtlRspnOrgnlMsgId[%s]",    m_hvps713.DtlRspnOrgnlMsgId.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "DtlRspnOrgnlInstgPty[%s]", m_hvps713.DtlRspnOrgnlInstgPty.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "DtlRspnOrgnlMT[%s]",       m_hvps713.DtlRspnOrgnlMT.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "NPCPrcInfPrcSts[%s]",      m_hvps713.NPCPrcInfPrcSts.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "PrcCd[%s]",                m_hvps713.PrcCd.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "RjctInf[%s]",              m_hvps713.RjctInf.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "SttlmDt[%s]",              m_hvps713.SttlmDt.c_str());
    
    m_hvchklstcl.m_msgid             = m_hvps713.MsgId;                //���ı�ʶ��
    m_hvchklstcl.m_instgdrctpty      = m_hvps713.InstgDrctPty;         //����ֱ�Ӳ������
    m_hvchklstcl.m_chckdt            = m_hvps713.ChckDt;               //��������
    m_hvchklstcl.m_workdate          = m_strWorkDate;                  //��������
    m_hvchklstcl.m_msgtp             = "hvps.713.001.01";              //��������
    m_hvchklstcl.m_instddrctpty      = m_hvps713.InstdDrctPty;         //����ֱ�Ӳ������
    m_hvchklstcl.m_remark            = m_hvps713.Rmk;                  //��ע
    m_hvchklstcl.m_orgnlmsgid        = m_hvps713.DtlRspnOrgnlMsgId;    //ԭ���뱨�ı�ʶ��
    m_hvchklstcl.m_orgnlinstgdrctpty = m_hvps713.DtlRspnOrgnlInstgPty; //ԭ���뷢�������
    m_hvchklstcl.m_orgnlmsgtp        = m_hvps713.DtlRspnOrgnlMT;       //ԭ���뱨������ 
    m_hvchklstcl.m_npcprcsts         = m_hvps713.NPCPrcInfPrcSts;      //NPC����״̬
    m_hvchklstcl.m_npcprccd          = m_hvps713.PrcCd;                //NPC������
    m_hvchklstcl.m_npcrjctinf        = m_hvps713.RjctInf;              //NPC�ܾ���Ϣ
    m_hvchklstcl.m_npcsttlmdt        = m_hvps713.SttlmDt;              //NPC��������/��̬����
    m_hvchklstcl.m_procstate         = PR_HVBP_00;                     //����״̬:��ʼ
    m_hvchklstcl.m_printno           = 0;                              //��ӡ����

    iRet = m_hvchklstcl.setctx(m_dbproc);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }
    
    iRet = m_hvchklstcl.insert();
    if (SQL_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����HV_CHKLSTCLʧ��[%d][%s]",
            iRet, m_hvchklstcl.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "����HV_CHKLSTCLʧ��");        
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps713::InsertChkLstCl()");
}

void CRecvHvps713::GetDetail()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps713::GetDetail()");
	
    int iParentNum = 0;
    int iChildNum = 0;
    int iCommitNum = 0;
    
    // �����ϸ�˶Ա�
    iParentNum = m_hvps713.GetNodeCountByName("Dtls");
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iParentNum[%d]", iParentNum);

    int iRet = m_hvchklstlist.setctx(m_dbproc);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }
    
   	for(int i=0; i<iParentNum; i++)
    {
   	    //ClearCycleValue("SUM");

   	    m_hvps713.MT       		= m_hvps713.GetValueFromCycle("Dtls", "MT", i);
        m_hvps713.TxTpCd   		= m_hvps713.GetValueFromCycle("Dtls", "TxTpCd", i);
        m_hvps713.SndRcvTp 		= m_hvps713.GetValueFromCycle("Dtls", "SndRcvTp", i);
        m_hvps713.DtlsPrcSts	= m_hvps713.GetValueFromCycle("Dtls", "DtlsPrcSts", i);
        m_hvps713.NbOfTxs  		= m_hvps713.GetValueFromCycle("Dtls", "NbOfTxs", i);

        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_hvps713.MT       	 =[%s]", m_hvps713.MT.c_str());  
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_hvps713.TxTpCd   	 =[%s]", m_hvps713.TxTpCd.c_str()); 
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_hvps713.SndRcvTp 	 =[%s]", m_hvps713.SndRcvTp.c_str()); 
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_hvps713.DtlsPrcSts =[%s]", m_hvps713.DtlsPrcSts.c_str()); 
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_hvps713.NbOfTxs  	 =[%s]", m_hvps713.NbOfTxs.c_str()); 

        if ( "hvps.111.001.01" == m_hvps713.MT 
          || "hvps.112.001.01" == m_hvps713.MT
          || "CMT100" == m_hvps713.MT
          || "CMT101" == m_hvps713.MT
          || "CMT102" == m_hvps713.MT
          || "CMT103" == m_hvps713.MT
          || "CMT105" == m_hvps713.MT
          || "CMT108" == m_hvps713.MT
          || "CMT121" == m_hvps713.MT
          || "CMT122" == m_hvps713.MT
          || "CMT123" == m_hvps713.MT
          || "CMT124" == m_hvps713.MT )
        {
            if ( "SR00" == m_hvps713.SndRcvTp )
            {
                if ( 0 < atoi(m_hvps713.NbOfTxs.c_str()) )
                    m_hvchecklist.m_bSndExChgList = true;
            }
            else
            {
                if ( 0 < atoi(m_hvps713.NbOfTxs.c_str()) )
                    m_hvchecklist.m_bRcvExChgList = true;
            }
        }
        else if ( "hvps.141.001.01" == m_hvps713.MT 
               || "CMT232" == m_hvps713.MT
               || "CMT407" == m_hvps713.MT
               || "CMT408" == m_hvps713.MT )
        {
            if ( "SR00" == m_hvps713.SndRcvTp )
            {
                if ( 0 < atoi(m_hvps713.NbOfTxs.c_str()) )
                    m_hvchecklist.m_bSndTroFacList = true;
            }
            else
            {
                if ( 0 < atoi(m_hvps713.NbOfTxs.c_str()) )
                    m_hvchecklist.m_bRcvTroFacList = true;
            }
        }
        else if ( "hvps.633.001.01" == m_hvps713.MT )
        {
            if ( 0 < atoi(m_hvps713.NbOfTxs.c_str()) )
                m_hvchecklist.m_bMnetstlNtc = true;   
        }
        else if ( "ccms.314.001.01" == m_hvps713.MT 
          || "ccms.315.001.01" == m_hvps713.MT 
          || "CMT301" == m_hvps713.MT
          || "CMT302" == m_hvps713.MT)
        {
            if ( 0 < atoi(m_hvps713.NbOfTxs.c_str()) )
                m_hvchecklist.m_bTransInfoQry = true;   
        }
        else
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�������ʹ���[%s]", m_hvps713.MT.c_str());
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "�������ʹ���");
        }
                       
        iChildNum = atoi(m_hvps713.NbOfTxs.c_str());
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iChildNum[%d]", iChildNum);
        
        for(int j = 1; j <= iChildNum; j++)
        {   		
            //ClearCycleValue("DETAIL");

            m_hvps713.ChckngDtlOrgnlMsgId    	= m_hvps713.GetValueFromLiLCycle("Dtls",i,"ChckngDtl",j,"ChckngDtlOrgnlMsgId");
            m_hvps713.ChckngDtlOrgnlInstgPty 	= m_hvps713.GetValueFromLiLCycle("Dtls",i,"ChckngDtl",j,"ChckngDtlOrgnlInstgPty");
            m_hvps713.ChckngDtlOrgnlMT       	= m_hvps713.GetValueFromLiLCycle("Dtls",i,"ChckngDtl",j,"ChckngDtlOrgnlMT");
            m_hvps713.DbtCdtId        			= m_hvps713.GetValueFromLiLCycle("Dtls",i,"ChckngDtl",j,"DbtCdtId");
            m_hvps713.Amt        				= m_hvps713.GetValueFromLiLCycle("Dtls",i,"ChckngDtl",j,"Amt");
            m_hvps713.Ccy     					= m_hvps713.GetValueFromLiLCycle("Dtls",i,"ChckngDtl",j,"Ccy");
            
            Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_hvps713.ChckngDtlOrgnlMsgId	 =[%s]", m_hvps713.ChckngDtlOrgnlMsgId.c_str());  
	        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_hvps713.ChckngDtlOrgnlInstgPty =[%s]", m_hvps713.ChckngDtlOrgnlInstgPty.c_str()); 
	        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_hvps713.ChckngDtlOrgnlMT 	 	 =[%s]", m_hvps713.ChckngDtlOrgnlMT.c_str()); 
	        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_hvps713.DbtCdtId 				 =[%s]", m_hvps713.DbtCdtId.c_str()); 
	        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_hvps713.Amt 					 =[%s]", m_hvps713.Amt.c_str()); 
	        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_hvps713.Ccy  	 				 =[%s]", m_hvps713.Ccy.c_str()); 

        	/*ȡѭ��<Dtls>��ѭ��<ChckngDtl>������*/
            m_hvps713.getChckngDtl();

            //д�������ϸ��
            iCommitNum++;
            InsertChecklist();

            //�����ύ�����������
    		if(0 == iCommitNum%100)
            {
            	m_hvchklstlist.commit();
            }
        }
        
		/*ȡѭ��<Dtls>�е�����*/
        m_hvps713.getDtls();
    }  
	
    m_hvchklstlist.commit();

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps713::GetDetail()");
}

void CRecvHvps713::InsertChecklist()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps713::InsertChecklist()");
	
    int iRet = -1;
    
    m_hvchklstlist.m_msgtype         = m_hvps713.MT;						//�������ʹ���
    m_hvchklstlist.m_dtltxtpcd       = m_hvps713.TxTpCd;					//ҵ�����ͱ���
    m_hvchklstlist.m_orgnlmsgid      = m_hvps713.ChckngDtlOrgnlMsgId;		//ԭ���ı�ʶ��
    m_hvchklstlist.m_orgnlinstgdrpty = m_hvps713.ChckngDtlOrgnlInstgPty;	//ԭ���ķ��������
    m_hvchklstlist.m_prcsts          = m_hvps713.DtlsPrcSts;				//ҵ����״̬
    m_hvchklstlist.m_sndrcvtp        = m_hvps713.SndRcvTp;					//���ͽ��ձ�־
    m_hvchklstlist.m_workdate        = m_strWorkDate;						//��������
    m_hvchklstlist.m_msgid           = m_hvps713.MsgId;						//���ı�ʶ��
    m_hvchklstlist.m_instgdrctpty    = m_hvps713.InstgDrctPty;				//����ֱ�Ӳ������
    m_hvchklstlist.m_instddrctpty    = m_hvps713.InstdDrctPty;				//����ֱ�Ӳ������
    m_hvchklstlist.m_chckdt    	      = m_hvps713.ChckDt;					//��������
    m_hvchklstlist.m_orgnlmsgtp      = m_hvps713.ChckngDtlOrgnlMT;			//ԭ��������
    m_hvchklstlist.m_orgnlamount     = atof(m_hvps713.Amt.c_str());			//��ϸ�˶Խ��
    m_hvchklstlist.m_orgnlccy        = m_hvps713.Ccy;						//��ϸ�˶Ա���
    m_hvchklstlist.m_checkstate      = "00";								//����״̬:00����ʼ״̬
    m_hvchklstlist.m_isdownload      = "0";									//�Ƿ���������ϸ
    
    if( NULL != strstr(m_hvps713.MT.c_str(),"hvps.141") ||
        NULL != strstr(m_hvps713.MT.c_str(),"CMT232") )
    {
    	m_hvchklstlist.m_sndrcvtp = m_hvps713.DbtCdtId;
    }

    iRet = m_hvchklstlist.insert();
    if (SQL_SUCCESS != iRet && DUPLICATE_KEY != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����HV_CHKLSTLISTʧ��[%d][%s]",
            iRet, m_hvchklstlist.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "����HV_CHKLSTLISTʧ��");        
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps713::InsertChecklist()");
}
/*
void CRecvHvps713::ClearCycleValue(STRING szType)
{
    if ( "SUM" == szType )
    {
        m_szMT         = ""; //���ı��
        m_szTxTpCd     = ""; //ҵ�����ͱ���
        m_szSndRcvTp   = ""; //���͡����ձ�־(SR00:����/���� SR01:����/����)
        m_szPrcSts     = ""; //����״̬
        m_szNbOfTxs    = ""; //��ϸ�ܱ���
    }
    else if ( "DETAIL" == szType )
    {
        m_szOrMsgId    = ""; //ԭ���ı�ʶ��
        m_szOrInstgPty = ""; //ԭ����������
        m_szOrMT       = ""; //ԭ��������
        m_szAmt        = ""; //���:��ҵ������ΪK100��K101ʱ���̶���дΪ0
        m_szAmtCcy     = ""; //����
    }
}
*/
void CRecvHvps713::CheckSign713()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps713::CheckSign713()");
	
	m_hvps713.getOriSignStr();
	
	CheckSign(m_hvps713.m_sSignBuff.c_str(),
			m_hvps713.m_szDigitSign.c_str(),
			m_hvps713.InstgDrctPty.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps713::CheckSign713()");
}

void CRecvHvps713::isContinue()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps713::isContinue()"); 

	string szFindSql = "";
    int iRet = -1;

    //����������+�к�ͳ��
    szFindSql = " CHCKDT = '";
    szFindSql += m_hvps713.ChckDt;
    szFindSql += "' and INSTDDRCTPTY = '";
    szFindSql += m_hvps713.InstdDrctPty;
    szFindSql += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "szFindSql=[%s]",szFindSql.c_str());

    iRet = m_hvchklstlist.findcount(szFindSql);
    if ( iRet != SQL_SUCCESS )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "ͳ��HV_CHKLSTLIST��ʧ��[%d][%s]", 
            iRet, m_hvchklstlist.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "ͳ��HV_CHKLSTLIST��ʧ��");
    }

    //�����ķ�Ƭ������е�"�ܼ�¼��"ָ���Ǹ�ҵ������"�����ܱ���"��"�����ܱ���"�ĺͣ�
    // ��ĳһҵ������"�����ܱ���"��"�����ܱ���"��Ϊ0ʱ����ҵ�����͵ļ�¼����Ϊ1 ��
    // ����:�����ǰ������µ�711�����ص�,711�м�¼,713�Ͳ�Ӧ�ó��������˶�û�м�¼��

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_iCount[%d]TtlNb[%d]", 
        m_hvchklstlist.m_iCount, atoi(m_hvps713.TtlNb.c_str()));
    if ( m_hvchklstlist.m_iCount == atoi(m_hvps713.TtlNb.c_str()) )
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "713���Ľ������,���Խ��ж���"); 
        m_bLast713 = true;
    }

    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps713::isContinue()");
}


/**
 * ����710��������ܶ���
 */
void CRecvHvps713::Send710(void)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CRecvHvps713::Send710");

    // ��ȡ��������
    char	m_sWorkDate[8 + 1] = {0};
    char m_ISODateTime[19+1];
	
    int iRet = FAILED;

    char   m_sMesgID[20+1] = {0};
    
    if( !GetMsgIdValue(m_dbproc, m_sMesgID, eRefId, SYS_HVPS, m_hvps713.InstdDrctPty.c_str()) )
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "error");
        PMTS_ThrowException(PRM_FAIL);
    }
	
    iRet  = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS, m_hvps713.InstdDrctPty.c_str());
  
    if(RTN_SUCCESS != iRet)
    {
      Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");
      PMTS_ThrowException(OPT_GET_DATE_FAIL);
    }

    iRet = GetIsoDateTime(m_dbproc, SYS_HVPS, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get ISODateTime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }

    char MsgID[40] = {0};
    bool bRet = GetMsgIdValue(m_dbproc, MsgID, eMsgId,  SYS_HVPS, m_hvps713.InstdDrctPty.c_str());
    if(true != bRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get Msgid fail");
	    PMTS_ThrowException(OPT_GET_MSGID_FAIL);
    }
    m_hvps710.MsgId = MsgID;
    m_hvps710.CreDtTm = m_ISODateTime;
    m_hvps710.InstgDrctPty = m_hvps713.InstdDrctPty;
    m_hvps710.GrpHdrInstgPty = m_hvps713.InstdDrctPty;
    m_hvps710.InstdDrctPty = "0000";
    m_hvps710.GrpHdrInstdPty = "0000";
    m_hvps710.SysCd = "HVPS";
    m_hvps710.ChckngDt = m_hvps713.ChckDt;
	
    // ���ļ�ͷ
    m_hvps710.CreateXMlHeader("HVPS",                        \
                                m_sWorkDate, \
                                m_hvps713.InstdDrctPty.c_str(),\
                                "0000",\
                                "hvps.710.001.01",              \
                                m_sMesgID);


	char   sSignedStr[4096 + 1] = {0};
	
	m_hvps710.getOriSignStr();
	
	AddSign(m_hvps710.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_hvps710.InstgDrctPty.c_str());
	
	m_hvps710.m_szDigitSign = sSignedStr;

	m_checkqry.m_msgid = m_hvps710.MsgId;
	m_checkqry.m_msgtype = "hvps.710.001.01";
	m_checkqry.m_sapbank = m_hvps710.InstgDrctPty;
	m_checkqry.m_checkdate = m_hvps710.ChckngDt;
	
	SETCTX(m_checkqry);
	iRet = m_checkqry.insert();
	if( 0 != iRet)
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "INSERT CM_CHECKQRY FILED[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "INSERT CM_CHECKQRY FILED!");
	}

	m_hvps710.CreateXml();
    AddQueue(m_hvps710.m_sXMLBuff.c_str(), m_hvps710.m_sXMLBuff.length());

	Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CRecvHvps713::Send710");
}

/**
 * �Ƿ���˳ɹ�
 */
bool CRecvHvps713::IsAllOk(void)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CRecvHvps713::IsAllOk");

	char szSql[256] = {0};

	snprintf(szSql, sizeof(szSql),
			" chckdt='%s' and instddrctpty='%s' and checkstate='01'",
			m_hvps713.ChckDt.c_str(), m_hvps713.InstdDrctPty.c_str());

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "_szSql[%s]", szSql);

	if (m_hvchklstlist.findcount(szSql) != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[hv_chklstlist]��ѯʧ��[%s]", m_hvchklstlist.GetSqlErr());
		PMTS_ThrowException(DB_OPT_FAIL);
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_iCount[%d]TtlNb[%d]",
	        m_hvchklstlist.m_iCount, atoi(m_hvps713.TtlNb.c_str()));

	Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CRecvHvps713::IsAllOk");

	return m_hvchklstlist.m_iCount == atoi(m_hvps713.TtlNb.c_str());
}

/**
 * �жϵ�ǰ���������Ƿ��Ѵﵽ����Զ�����710���Ĵ����� ��ֹ�����쳣
 * �������޴��Զ�����710, Ĭ�����3��
 */
bool CRecvHvps713::IsCriticalTimes(int max_times)
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "Enter CRecvHvps713::IsCriticalTimes");

	bool bRet = false;

	/*
	 * �����ѷ��ʹ�������ǰ��������
	 */
	static int  _times = 0;      /*�ѷ���710����*/
	static char _chkdt[12] = {0};/*��ǰ��������*/

	if(m_hvps713.ChckDt != _chkdt){
		/*������������Ѿ���������ִ�У�  ������0����*/
		_times = 0;
		snprintf(_chkdt, sizeof(_chkdt), m_hvps713.ChckDt.c_str());
	}

	Trace(L_INFO, __FILE__, __LINE__, NULL,
			"��������:[%s]�ѷ���710����:[%d]", _chkdt, _times);

	++_times;

	Trace(L_INFO, __FILE__, __LINE__, NULL, "Leave CRecvHvps713::IsCriticalTimes");

	return (_times > max_times);
}
