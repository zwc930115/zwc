/******************************************************************** 
�ļ����� recvhv154.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-03-14
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/
    
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvhvps154.h"

using namespace ZFPT;

CRecvHvps154::CRecvHvps154()
{
	m_iMsgVer	=	2;
	m_strMsgTp	=	"hvps.154.001.01";
}


CRecvHvps154::~CRecvHvps154()
{
	
}

INT32 CRecvHvps154::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps154::Work()");
	
	// ��������
	unPack(sMsg);
		
	// �������ݿ�
	InsertDb(sMsg);
	
	// ��ǩ
	CheckSign154();	
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps154::work()");
	
	return RTN_SUCCESS;
}



INT32 CRecvHvps154::unPack(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps154::unPack");	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "receive msg = [%s]",sMsg); 

	int iRet = RTN_FAIL;

	//1�������Ƿ�Ϊ��
	if (NULL == sMsg || '\0' == sMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
	}

	//2����ȡ��������
	iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");	
		PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
	}
	m_strWorkDate	=	m_sWorkDate;

	//4����������
	iRet = m_cParser154.ParseXml(sMsg);
	if (RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= %d", iRet);	
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
	}

    //ZFPTLOG.SetLogInfo("154", m_cParser154.MsgId.c_str());
    
	m_strMsgID	=	m_cParser154.MsgId;

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps154::unPack");	

	return RTN_SUCCESS;
}

INT32 CRecvHvps154::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvHvps154::CheckValues");

    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CRecvHvps154::CheckValues");
    return 0;
}

void  CRecvHvps154::CheckSign154()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps154::CheckSign154");
	
	m_cParser154.getOriSignStr();
	
	CheckSign(m_cParser154.m_sSignBuff.c_str(),
						m_cParser154.m_szDigitSign.c_str(),
						m_cParser154.GrpHdrInstgPty.c_str());

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps154::CheckSign154");
}

INT32 CRecvHvps154::InsertDb(LPCSTR pchMsg)
{    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps154::InsertDb");	

    m_Hvwdrwlrspn.m_workdate=  m_strWorkDate; 
    m_Hvwdrwlrspn.m_msgtp=  m_strMsgTp; 
    m_Hvwdrwlrspn.m_mesgid= m_cParser154.m_PMTSHeader.getMesgID() ; 
    m_Hvwdrwlrspn.m_mesgrefid= m_cParser154.m_PMTSHeader.getMesgRefID() ; 
    m_Hvwdrwlrspn.m_msgid= m_cParser154.MsgId; 
    m_Hvwdrwlrspn.m_instgdrctpty= m_cParser154.InstgDrctPty; 
    m_Hvwdrwlrspn.m_instgindrctpty= m_cParser154.GrpHdrInstgPty; 
    m_Hvwdrwlrspn.m_instddrctpty= m_cParser154.InstdDrctPty; 
    m_Hvwdrwlrspn.m_instdindrctpty= m_cParser154.GrpHdrInstdPty; 
    m_Hvwdrwlrspn.m_remark= m_cParser154.Rmk; 
    m_Hvwdrwlrspn.m_acctgsbjtcd= m_cParser154.AcctgSbjtCd; 
    m_Hvwdrwlrspn.m_acctgsbjtnm= m_cParser154.AcctgSbjtNm; 
    m_Hvwdrwlrspn.m_brnchcd= m_cParser154.BrnchCd; 
    m_Hvwdrwlrspn.m_brnchnm= m_cParser154.BrnchNm; 
    m_Hvwdrwlrspn.m_txid= m_cParser154.TxId; 
    m_Hvwdrwlrspn.m_orgnltxid= m_cParser154.OrgnlTxId; 
    m_Hvwdrwlrspn.m_mmbid= m_cParser154.MmbId; 
    m_Hvwdrwlrspn.m_brnchid= m_cParser154.BrnchId; 
    m_Hvwdrwlrspn.m_pstngacct= m_cParser154.PstngAcct; 
    m_Hvwdrwlrspn.m_pstngnm= m_cParser154.PstngNm; 
    m_Hvwdrwlrspn.m_instnid= m_cParser154.InstnId; 
    m_Hvwdrwlrspn.m_instnnm= m_cParser154.InstnNm; 
    m_Hvwdrwlrspn.m_sttlmprty= m_cParser154.SttlmPrty; 
    m_Hvwdrwlrspn.m_currency= m_cParser154.Ccy; 
    double m_amt= atof(m_cParser154.Amt.c_str()); 
    m_Hvwdrwlrspn.m_pmttp= m_cParser154.PmtTp; 
    m_Hvwdrwlrspn.m_tp= m_cParser154.Tp; 
    m_Hvwdrwlrspn.m_procstate= "01" ; 
    //m_Hvwdrwlrspn.m_stattime= m_cParser154. ; 
    int m_printno= 0 ; 

	//1����������
	SETCTX(m_Hvwdrwlrspn);
	int iRet = m_Hvwdrwlrspn.insert();
	if (0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL,
            "m_Hvwdrwlrspn.insert failed:error code = [%d],error cause = [%s]", iRet,m_Hvwdrwlrspn.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "����Hvrcvexchglist��ʧ��");
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps154::InsertDb");	

	return RTN_SUCCESS;
}
	


