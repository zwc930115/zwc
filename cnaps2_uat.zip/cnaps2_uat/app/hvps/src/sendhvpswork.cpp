/********************************************************************
文件名：sendhvpswork.cpp
创建人：handongfeng
日  期：2011.01.14
描  述：
版  本：
Copyright (c) 2009  YLINK
********************************************************************/
    
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendhvpswork.h"
#include "tsocket.h"
#include "exception.h"
#include "sendhvps111.h"
#include "sendhvps112.h"
#include "sendhvps132.h"
#include "sendhvps141.h"
#include "sendhvps143.h"
#include "sendhvps151.h"
#include "sendhvps153.h"
#include "sendhvps631.h"
#include "sendhvps634.h"
#include "sendhvps710.h"
#include "sendcmt100.h"
#include "sendcmt101.h"
#include "sendcmt102.h"
#include "sendcmt103.h"
#include "sendcmt105.h"
#include "sendcmt108.h"
#include "sendcmt110.h"
#include "sendcmt121.h"
#include "sendcmt122.h"
#include "sendcmt123.h"
#include "sendcmt124.h"
#include "sendcmt231.h"
#include "sendcmt721.h"
#include "sendcmt724.h"
#include "sendcmt223.h"

#include "logger.h"

using namespace ZFPT;

CSendHvpsWork::CSendHvpsWork()
{
    memset(&m_MsgHead, 0x00, sizeof(m_MsgHead));
}

CSendHvpsWork::CSendHvpsWork(const CSendHvpsWork &e)
{
    if(this != &e)
    {
        m_sTrsCode = e.m_sTrsCode;
        memcpy(m_MQMsgId , e.m_MQMsgId, sizeof(e.m_MQMsgId));        
        memcpy(&m_MsgHead, &e.m_MsgHead, sizeof(e.m_MsgHead));
    }
}

CSendHvpsWork::~CSendHvpsWork()
{
}

void CSendHvpsWork::clear()
{
	
}

void CSendHvpsWork::UnpackMsgHead(const char* strMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Enter CSendHvpsWork::UnpackMsgHead...");
    memset(m_MsgHead.szMsgFlagNO, ' ', 28);
    memset(m_MsgHead.szSndNO, ' ', 14);
	int offset = 0;
	OffsetCpy(m_MsgHead.szSysType, strMsg, offset, 4);
	OffsetCpy(m_MsgHead.szMsgUse, strMsg, offset, 1);
	OffsetCpy(m_MsgHead.szMsgTypeFlag, strMsg, offset, 3);
	OffsetCpy(m_MsgHead.szMsgType, strMsg, offset, 3);
	OffsetCpy(m_MsgHead.szMsgFlagNO, strMsg, offset, 28);
	OffsetCpy(m_MsgHead.szSndNO, strMsg, offset, 14);
	OffsetCpy(m_MsgHead.szOprUser,strMsg, offset, 20);
	OffsetCpy(m_MsgHead.szOprUserNetId,strMsg, offset, 20);	
	OffsetCpy(m_MsgHead.szMsgKind,strMsg, offset, 5);
	OffsetCpy(m_MsgHead.szReserve,strMsg, offset, 43);

	Trim(m_MsgHead.szMsgFlagNO);
	Trim(m_MsgHead.szSndNO);
	Trim(m_MsgHead.szOprUser);
	Trim(m_MsgHead.szOprUserNetId);
	Trim(m_MsgHead.szMsgKind);
	
	m_sTrsCode = m_MsgHead.szMsgFlagNO;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_sTrsCode= [%s]",     m_sTrsCode.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_MsgHead.szSysType= [%s]",     m_MsgHead.szSysType);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_MsgHead.szMsgUse= [%s]",     m_MsgHead.szMsgUse); 
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_MsgHead.szMsgType= [%s]",     m_MsgHead.szMsgType);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_MsgHead.szMsgTypeFlag =[%s]",  m_MsgHead.szMsgTypeFlag);  
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_MsgHead.szMsgFlagNO= [%s]",   m_MsgHead.szMsgFlagNO);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_MsgHead.szSndNO =[%s]",  m_MsgHead.szSndNO);  
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leave CSendHvpsWork::UnpackMsgHead...");
	return;
}


INT32 CSendHvpsWork::doWork()
{
    ZFPTLOG.SetLogInfo(m_MsgHead.szMsgType, m_MsgHead.szMsgFlagNO);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvpsWork::doWork..."); 
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "收到交易:[%s]", m_sTrsCode.c_str());

    int iMsgNO = atoi(m_MsgHead.szMsgType);
    if(0 == iMsgNO)
    {
        Trace(L_INFO, __FILE__,  __LINE__, NULL, "转换报文号失败,m_MsgHead.szMsgType = %s", m_MsgHead.szMsgType);
    }
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "收到报文类型:iMsgNO[%d]", iMsgNO);
    
    int iRet = 0;
    CSendHvpsBase *pSendBase = NULL;
    stuSndMsg SndMsg;
    memset(&SndMsg, 0x00, sizeof(SndMsg));

    switch(iMsgNO)
    {

        case 100:
        {
        	pSendBase = new CSendCmt100(m_MsgHead);
            break;
        }
        case 110:
        {
        	pSendBase = new CSendCmt110(m_MsgHead);
            break;
        }
        case 121:
        {
        	pSendBase = new CSendCmt121(m_MsgHead);
            break;
        }
        case 122:
        {
            pSendBase = new CSendCmt122(m_MsgHead);
            break;
        }
        case 123:
        {
            pSendBase = new CSendCmt123(m_MsgHead);
            break;
        }
        case 124:
        {
            pSendBase = new CSendCmt124(m_MsgHead);
            break;
        }
        case 231:
        {
            pSendBase = new CSendCmt231(m_MsgHead);
            break;
        }
        case 223:
        {
            pSendBase = new CSendCmt223(m_MsgHead);
            break;
        }		
        case 111:
        {
            pSendBase = new CSendHvps111(m_MsgHead);
            break;
        }		
        case 141:
        {
            pSendBase = new CSendHvps141(m_MsgHead);
            break;
        }

        case 143:
        {
            pSendBase = new CSendHvps143(m_MsgHead);
            break;
        }
        
        case 151:
        {
            pSendBase = new CSendHvps151(m_MsgHead);
            break;
        }

        case 724:
        {
            pSendBase = new CSendCmt724(m_MsgHead);
            break;
        }
        case 153:
        {
            pSendBase = new CSendHvps153(m_MsgHead);
            break;
        }
        case 631:
        {
            pSendBase = new CSendHvps631(m_MsgHead);
            break;
        }
        case 634:
        {
            pSendBase = new CSendHvps634(m_MsgHead);
            break;
        }
        case 710:
        {
            pSendBase = new CSendHvps710(m_MsgHead);
            break;
        }
        case 721:
        {
            pSendBase = new CSendCmt721(m_MsgHead);
            break;
        }
        case 132:
        {
            pSendBase = new CSendHvps132(m_MsgHead);
            break;
        }

        default:
        {
            Trace(L_INFO, __FILE__,  __LINE__, NULL, "没有找到相应的报文号!");
            
            return RTN_FAIL;
        }
    }
    
    //将MQM消息ID赋值给pSendBase成员，便于SendBase基类中统一给客户端同步回应    
    memcpy(pSendBase->m_MQMsgId , m_MQMsgId, sizeof(m_MQMsgId));
    
    iRet = pSendBase->doWork();
    DELPOINT_VOID(pSendBase);  
    
    Trace(L_INFO, __FILE__,  __LINE__, NULL, "报文处理结束,iMsgNO = %d!", iMsgNO);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Leave CSendHvpsWork::doWork..."); 
    
    return RTN_SUCCESS;
}


