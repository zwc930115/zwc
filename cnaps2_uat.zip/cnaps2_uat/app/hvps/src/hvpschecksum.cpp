/******************************************************************** 
文件名： hvpsckecksum.cpp
创建人： hq
日  期： 2011-05-11
修改人： 
日  期： 
描  述： 大额汇总对账类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "hvpschecksum.h"
#include "exception.h"
#include "logger.h"
#include "cmcheckqry.h"

using namespace ZFPT;

CHvpsCheckSum::CHvpsCheckSum()
{
    m_iTtlCnt    = 0;
    m_iLocalMore = 0;
    m_szChkDt    = "";
    m_szBkCode   = "";
    m_szMT       = "";
    m_szTxTpCd   = "";
    m_szPrcSts   = "";
    m_szCcy      = "";

    memset(&VCheckArray, 0x00, sizeof(VCheckArray));
}

CHvpsCheckSum::~CHvpsCheckSum()
{
    
}

void CHvpsCheckSum::doCheckSumWork(DBProc &dbProc,
                                 int iChkTp, 
                                 LPCSTR sChkDt, 
                                 LPCSTR sBankCode, 
                                 MQAgent &cMQAgent, 
                                 LPCSTR sSendQueue)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsCheckSum::doCheckSumWork()");

    // 说明；汇总对账类型:0收711调用，1其他调用
    m_szChkDt     = sChkDt;
    m_szBkCode    = sBankCode;
    m_dbproc.pCtx = dbProc.pCtx;

    // 设置连接
    SetAllCtx();

    // 统计本地数据
    if (1 == iChkTp)
    {
    	CountLocalInfo();
	}

	// 对账相符的，更新业务表的对账状态
	UpdateSts();
	
    // 更新大额对帐状态信息表
	updateBkChkSt();
	
	// 对账不平，则发起业务明细核对申请报文
	if ( 0 < m_iTtlCnt )
	{
	    //删除"大额明细核对表"
	    //DeleteCheckList();
	    
	    //发送712报文
	    SndToNpcFor712(cMQAgent, sSendQueue);
	}
	else
	{
	    char sTelMsg[1024 + 1] = {0};
	    sprintf(sTelMsg, "工作日期[%s]对账相符", sChkDt);
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sTelMsg); 
        //NotifyOprUser(m_dbproc, "2", "01", sTelMsg, sBankCode);
    }
	

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsCheckSum::doCheckSumWork()");
}

void CHvpsCheckSum::CountLocalInfo()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsCheckSum::CountLocalInfo()");

    int iRet = -1;
    int iCountNum = 0;
    STRING strSqlStr = "";
    
	//查询条件:对账日期和行号相等，且对账状态不相符
    strSqlStr = (STRING)" CHCKDT = '" + m_szChkDt;
    strSqlStr += "' and INSTDDRCTPTY = '" + m_szBkCode;
    strSqlStr += "' and CHECKSTATE <> '";
    strSqlStr += PR_CNCH_01;
    strSqlStr += "' order by MSGTP,TXTPCD,PRCSTS";

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSqlStr[%s]", strSqlStr.c_str());        

    iRet = m_hvcheckcl.find(strSqlStr);
    if (SQL_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "查询大额汇总核对表失败[%d][%s]",
            iRet, m_hvcheckcl.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "查询大额汇总核对表失败");
    }

    while(SQL_SUCCESS == iRet)
    {
    	iRet = m_hvcheckcl.fetch();
      	if (SQLNOTFOUND == iRet) 
    	{
    	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "*****CountLocalInfo is over*****");
            break;
    	}
    	else if (SQL_SUCCESS != iRet) 
    	{
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "查询大额汇总核对表失败[%d][%s]",
                iRet, m_hvcheckcl.GetSqlErr());
                
            m_hvcheckcl.closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "查询大额汇总核对表失败");
    	}

        iCountNum++;
        
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "msgtp[%s], prcsts[%s], txtpcd[%s], ccy[%s]", 
              m_hvcheckcl.m_msgtp.c_str(),  m_hvcheckcl.m_prcsts.c_str(), 
              m_hvcheckcl.m_txtpcd.c_str(),    m_hvcheckcl.m_rcvgctrlsumccy.c_str());

        m_szMT     = m_hvcheckcl.m_msgtp;
        
		if ( "hvps.111.001.01" == m_szMT 
          || "hvps.112.001.01" == m_szMT
          || "CMT100" == m_szMT
          || "CMT101" == m_szMT
          || "CMT102" == m_szMT
          || "CMT103" == m_szMT
          || "CMT105" == m_szMT
          || "CMT108" == m_szMT
          || "CMT121" == m_szMT
          || "CMT122" == m_szMT
          || "CMT123" == m_szMT
          || "CMT124" == m_szMT )
        {
            UpdateCheckCl("EXCHGLIST");
        }
        else if ( "hvps.141.001.01" == m_szMT 
			   || "hvps.141.002.01" == m_szMT 
               || "CMT232" == m_szMT
               || "CMT407" == m_szMT
               || "CMT408" == m_szMT )
        {
            UpdateCheckCl("TROFACSNDLIST");
        }
        else if ( "hvps.633.001.01" == m_szMT )
        {
            UpdateCheckCl("MNETSTLNTC");
        }
        else if ( "ccms.314.001.01" == m_szMT 
               || "ccms.315.001.01" == m_szMT
               || "CMT301" == m_szMT
               || "CMT302" == m_szMT )
        {
            UpdateCheckCl("TRANSINFOQRY");
        }
        else
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文类型错误[%s]", 
                m_hvcheckcl.m_msgtp.c_str());
                
            m_hvcheckcl.closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "报文类型错误");
        }
    }
    
    m_hvcheckcl.closeCursor();

    if ( 0 == iCountNum )
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "汇总表HV_CHECKCL无数据");
        PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "汇总表HV_CHECKCL无数据");
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsCheckSum::CountLocalInfo()");    
}

void CHvpsCheckSum::UpdateCheckCl(LPCSTR sTableNm)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsCheckSum::UpdateCheckCl()");

    int  iRet = -1;
    int  iLSndCount = 0;
    int  iLRcvCount = 0;
    double dLSndSum = 0.00;
    double dLRcvSum = 0.00;
    char sUpdateSql[1024 + 1];
    string szUpdateSql= "";
    string szSndTableNm = "";
    string szRcvTableNm = "";
    char sCheckState[2 + 1] = { 0 };
    stCheckSum stTemp;
    
    // 统计本地往账
    if ( 0 == strcmp("MNETSTLNTC", sTableNm) )
    {
        iLSndCount = 0;
        dLSndSum   = 0.00;
    }
    else
    {
        szSndTableNm = szSndTableNm + "SND" + sTableNm;
        iRet = m_checkaccount.getHvLocalSumData(szSndTableNm.c_str(), 
                                m_hvcheckcl.m_msgtp.c_str(),
                                m_hvcheckcl.m_instddrctpty.c_str(),
                                m_hvcheckcl.m_prcsts.c_str(),
                                m_hvcheckcl.m_chckdt.c_str(),
                                m_hvcheckcl.m_txtpcd.c_str(),
                                m_hvcheckcl.m_sndgctrlsumccy.c_str());
        if ( iRet != SQL_SUCCESS )
        {
            Trace(L_ERROR, __FILE__, __LINE__, NULL, "汇总本地数据失败[%d][%s]", 
                iRet, m_checkaccount.GetSqlErr());

            m_hvcheckcl.closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "汇总本地数据失败");
        }
        iLSndCount = m_checkaccount.m_iCount;
        dLSndSum   = m_checkaccount.m_amount;
    }
    
    // 统计本地来账
    szRcvTableNm = szRcvTableNm + "RCV" + sTableNm;
    iRet = m_checkaccount.getHvLocalSumData(szRcvTableNm.c_str(), 
                            m_hvcheckcl.m_msgtp.c_str(),
                            m_hvcheckcl.m_instddrctpty.c_str(),
                            m_hvcheckcl.m_prcsts.c_str(),
                            m_hvcheckcl.m_chckdt.c_str(),
                            m_hvcheckcl.m_txtpcd.c_str(),
                            m_hvcheckcl.m_rcvgctrlsumccy.c_str());
    if ( iRet != SQL_SUCCESS )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "汇总本地数据失败[%d][%s]", 
            iRet, m_checkaccount.GetSqlErr());

        m_hvcheckcl.closeCursor();
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "汇总本地数据失败");
    }
    iLRcvCount = m_checkaccount.m_iCount;
    dLRcvSum   = m_checkaccount.m_amount;

    m_szTxTpCd = m_hvcheckcl.m_txtpcd;
    m_szPrcSts = m_hvcheckcl.m_prcsts;
        
    // 比较数据
    if (   m_hvcheckcl.m_sndgnboftxs == iLSndCount
        && m_hvcheckcl.m_sndgctrlsum == dLSndSum
        && m_hvcheckcl.m_rcvgnboftxs == iLRcvCount
        && m_hvcheckcl.m_rcvgctrlsum == dLRcvSum )
    {
        strcpy(sCheckState, PR_CNCH_01); //对账相符
    }
    else 
    {
        strcpy(sCheckState, PR_CNCH_02); //对账不符

        //
        if ( m_hvcheckcl.m_sndgnboftxs != iLSndCount
          || m_hvcheckcl.m_sndgctrlsum != dLSndSum )
        {
            //往账不符,且人行笔数大于零时，才下载明细
            if ( 0 < m_hvcheckcl.m_sndgnboftxs )
            {
                m_iTtlCnt++;
                AddDetail("SR00"); 
            }
            /*
            //往账不符,且人行笔数为零时,直接更新本地状态为本地多
            else
            {
                m_iLocalMore++;
                memset(&stTemp, 0x00, sizeof(stTemp));
                strncpy(stTemp.sTableNm, szSndTableNm.c_str(),                 sizeof(stTemp.sTableNm) - 1);
                strncpy(stTemp.sCheckSt, PR_CNCH_05,                     sizeof(stTemp.sTableNm) - 1);
                strncpy(stTemp.sMt,      m_szMT.c_str(),                       sizeof(stTemp.sMt)      - 1);
                strncpy(stTemp.sBkCode,  m_szBkCode.c_str(),                   sizeof(stTemp.sBkCode)  - 1);
                strncpy(stTemp.sPrcSts,  m_szPrcSts.c_str(),                   sizeof(stTemp.sPrcSts)  - 1);
                strncpy(stTemp.sChkDt,   m_szChkDt.c_str(),                    sizeof(stTemp.sChkDt)   - 1);
                strncpy(stTemp.sTxTpCd,  m_szTxTpCd.c_str(),                   sizeof(stTemp.sTxTpCd)  - 1);
                strncpy(stTemp.sCcy,     m_hvcheckcl.m_sndgctrlsumccy.c_str(), sizeof(stTemp.sCcy)     - 1);
               
                VCheckArray.push_back(stTemp);
            }*/
        }
        if ( m_hvcheckcl.m_rcvgnboftxs != iLRcvCount
          || m_hvcheckcl.m_rcvgctrlsum != dLRcvSum )
        {
            //来账不符,且人行笔数大于零时，才下载明细
            if ( 0 < m_hvcheckcl.m_rcvgnboftxs )
            {
                m_iTtlCnt++;
                AddDetail("SR01"); 
            }
            /*
            //来账不符,且人行笔数为零时,直接更新本地状态为本地多
            else
            {
                m_iLocalMore++;
                memset(&stTemp, 0x00, sizeof(stTemp));
                strncpy(stTemp.sTableNm, szRcvTableNm.c_str(),                 sizeof(stTemp.sTableNm) - 1);
                strncpy(stTemp.sCheckSt, PR_CNCH_05,                     sizeof(stTemp.sTableNm) - 1);
                strncpy(stTemp.sMt,      m_szMT.c_str(),                       sizeof(stTemp.sMt)      - 1);
                strncpy(stTemp.sBkCode,  m_szBkCode.c_str(),                   sizeof(stTemp.sBkCode)  - 1);
                strncpy(stTemp.sPrcSts,  m_szPrcSts.c_str(),                   sizeof(stTemp.sPrcSts)  - 1);
                strncpy(stTemp.sChkDt,   m_szChkDt.c_str(),                    sizeof(stTemp.sChkDt)   - 1);
                strncpy(stTemp.sTxTpCd,  m_szTxTpCd.c_str(),                   sizeof(stTemp.sTxTpCd)  - 1);
                strncpy(stTemp.sCcy,     m_hvcheckcl.m_rcvgctrlsumccy.c_str(), sizeof(stTemp.sCcy)     - 1);
               
                VCheckArray.push_back(stTemp);
            }
            */
        }
    }
    
    // 如果对账相符且笔数大于零:将需要更新的表名存到vector容器
    if (   m_hvcheckcl.m_sndgnboftxs == iLSndCount
        && m_hvcheckcl.m_sndgctrlsum == dLSndSum
        && 0 < iLSndCount )
    {
        memset(&stTemp, 0x00, sizeof(stTemp));
        strncpy(stTemp.sTableNm, szSndTableNm.c_str(),                 sizeof(stTemp.sTableNm) - 1);
        strncpy(stTemp.sCheckSt, PR_CNCH_01,                      sizeof(stTemp.sTableNm) - 1);
        strncpy(stTemp.sMt,      m_szMT.c_str(),                       sizeof(stTemp.sMt)      - 1);
        strncpy(stTemp.sBkCode,  m_szBkCode.c_str(),                   sizeof(stTemp.sBkCode)  - 1);
        strncpy(stTemp.sPrcSts,  m_szPrcSts.c_str(),                   sizeof(stTemp.sPrcSts)  - 1);
        strncpy(stTemp.sChkDt,   m_szChkDt.c_str(),                    sizeof(stTemp.sChkDt)   - 1);
        strncpy(stTemp.sTxTpCd,  m_szTxTpCd.c_str(),                   sizeof(stTemp.sTxTpCd)  - 1);
        strncpy(stTemp.sCcy,     m_hvcheckcl.m_sndgctrlsumccy.c_str(), sizeof(stTemp.sCcy)     - 1);
       
        VCheckArray.push_back(stTemp);
    }
    if ( m_hvcheckcl.m_rcvgnboftxs == iLRcvCount
      && m_hvcheckcl.m_rcvgctrlsum == dLRcvSum 
      && 0 < iLRcvCount )
    {
        memset(&stTemp, 0x00, sizeof(stTemp));
        strncpy(stTemp.sTableNm, szRcvTableNm.c_str(),                 sizeof(stTemp.sTableNm) - 1);
        strncpy(stTemp.sCheckSt, PR_CNCH_01,                      sizeof(stTemp.sTableNm) - 1);
        strncpy(stTemp.sMt,      m_szMT.c_str(),                       sizeof(stTemp.sMt)      - 1);
        strncpy(stTemp.sBkCode,  m_szBkCode.c_str(),                   sizeof(stTemp.sBkCode)  - 1);
        strncpy(stTemp.sPrcSts,  m_szPrcSts.c_str(),                   sizeof(stTemp.sPrcSts)  - 1);
        strncpy(stTemp.sChkDt,   m_szChkDt.c_str(),                    sizeof(stTemp.sChkDt)   - 1);
        strncpy(stTemp.sTxTpCd,  m_szTxTpCd.c_str(),                   sizeof(stTemp.sTxTpCd)  - 1);
        strncpy(stTemp.sCcy,     m_hvcheckcl.m_rcvgctrlsumccy.c_str(), sizeof(stTemp.sCcy)     - 1);
        
        VCheckArray.push_back(stTemp);
    }
    
    // 更新HV_CHECKCL
    sprintf(sUpdateSql, "update HV_CHECKCL set "
                " LSNDGCTRLSUMCCY = SNDGCTRLSUMCCY, LRCVGCTRLSUMCCY = RCVGCTRLSUMCCY,"
                " LSNDGNBOFTXS = %d,"
                " LSNDGCTRLSUM = %f," 
                " LRCVGNBOFTXS = %d,"
                " LRCVGCTRLSUM = %f,"
                " CHECKSTATE = '%s'"
                " where CHCKDT = '%s'"
                " and MSGTP = '%s'"
                " and TXTPCD = '%s'"
                " and PRCSTS = '%s'"
                " and INSTDDRCTPTY = '%s'",
                iLSndCount,
                dLSndSum,
                iLRcvCount,
                dLRcvSum,
                sCheckState,
                m_hvcheckcl.m_chckdt.c_str(),
                m_hvcheckcl.m_msgtp.c_str(),
                m_hvcheckcl.m_txtpcd.c_str(),
                m_hvcheckcl.m_prcsts.c_str(),
                m_hvcheckcl.m_instddrctpty.c_str()); 
    Trace(L_INFO, __FILE__, __LINE__, NULL, "sUpdateSql[%s]", sUpdateSql);

    szUpdateSql = sUpdateSql;
    iRet = m_hvcheckcl.execsql(szUpdateSql);
    if (iRet != SQL_SUCCESS )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "更新HV_CHECKCL失败[%d][%s]",
            iRet, m_hvcheckcl.GetSqlErr());
        m_hvcheckcl.closeCursor();
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新HV_CHECKCL失败");
    }
        
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsCheckSum::UpdateCheckCl()");    
}

void CHvpsCheckSum::UpdateSts()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsCheckSum::UpdateSts()");

    int  iRet = -1;
    char sSqlStr[1024 + 1];
    char sErrMsg[1024 + 1];
    char sShortDt[8 + 1];
    
    memset(sSqlStr, 0x00, sizeof(sSqlStr));
    memset(sErrMsg, 0x00, sizeof(sErrMsg));
    memset(sShortDt, 0x00, sizeof(sShortDt));

    //暂时不按币种更新，以后有需要再加上
    for ( vector<stCheckSum>::size_type ix = 0; ix != VCheckArray.size(); ++ix )
    {
        chgToDate(VCheckArray[ix].sChkDt, sShortDt); //8位对账日期
        
        //大额往账汇兑明细表
        if ( 0 == strcmp("SNDEXCHGLIST", VCheckArray[ix].sTableNm) )
        { 
        	 if(0 == strncmp("CMT",VCheckArray[ix].sMt,3))
        	 	{
             sprintf(sSqlStr, "UPDATE HV_SNDEXCHGLIST t SET "
                             "t.CHECKSTATE = '%s'  "
                             " WHERE MSGTP = '%s'"
                             " AND INSTGDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s'",     
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt);
                        
            }
           else
           	{
           	 sprintf(sSqlStr, "UPDATE HV_SNDEXCHGLIST t SET "
                             "t.CHECKSTATE = '%s'  "
                             " WHERE MSGTP = '%s'"
                             " AND INSTGDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s'"
                             " AND CTGYPURPPRTRY = '%s'"
                             /*" AND CURRENCY = '%s'"*/,
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt,
                             VCheckArray[ix].sTxTpCd/*,
                             VCheckArray[ix].sCcy*/);	
            }	
            	                 
        }
        //大额来账汇兑明细表
        else if ( 0 == strcmp("RCVEXCHGLIST", VCheckArray[ix].sTableNm) )
        { 
        	if(0 == strncmp("CMT",VCheckArray[ix].sMt,3))
        		{
            sprintf(sSqlStr, "UPDATE HV_RCVEXCHGLIST t SET "
                             "t.CHECKSTATE = '%s'  "
                             " WHERE MSGTP = '%s'"
                             " AND INSTDDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s'",
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt);
            }
            else
            {sprintf(sSqlStr, "UPDATE HV_RCVEXCHGLIST t SET "
                             "t.CHECKSTATE = '%s'  "
                             " WHERE MSGTP = '%s'"
                             " AND INSTDDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s'"
                             " AND CTGYPURPPRTRY = '%s'"
                             /*" AND CURRENCY = '%s'"*/,
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt,
                             VCheckArray[ix].sTxTpCd/*,
                             VCheckArray[ix].sCcy*/);
            }		                 
        }
        //大额即时转账业务表-往账
        else if ( 0 == strcmp("SNDTROFACSNDLIST", VCheckArray[ix].sTableNm) )
        {
            sprintf(sSqlStr, "UPDATE HV_TROFACSNDLIST t SET "
                             "t.CHECKSTATE = '%s'  "
                             " WHERE MSGTP = '%s'"
                             " AND INSTGDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s'"
                             " AND CTGYPURPPRTRY = '%s'"
                             /*" AND CURRENCY = '%s'"*/,
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt,
                             VCheckArray[ix].sTxTpCd/*,
                             VCheckArray[ix].sCcy*/);    
        }
        //大额即时转账业务表-来账
        else if ( 0 == strcmp("RCVTROFACSNDLIST", VCheckArray[ix].sTableNm) )
        {
        	if(0 == strncmp("CMT",VCheckArray[ix].sMt,3))
        		{
            sprintf(sSqlStr, "UPDATE HV_TROFACRCVLIST t SET "
                             "t.CHECKSTATE = '%s'  "
                             " WHERE MSGTP = '%s'"
                             " AND INSTDDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s'",
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt);
            }
          else
          	{
          	sprintf(sSqlStr, "UPDATE HV_TROFACRCVLIST t SET "
                             "t.CHECKSTATE = '%s'  "
                             " WHERE MSGTP = '%s'"
                             " AND INSTDDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s'"
                             " AND CTGYPURPPRTRY = '%s'"
                             /*" AND CURRENCY = '%s'"*/,
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt,
                             VCheckArray[ix].sTxTpCd/*,
                             VCheckArray[ix].sCcy*/);	
          }	
            	                  
        }
        //多边轧差净额结算借贷通知表-来账
        else if ( 0 == strcmp("RCVMNETSTLNTC", VCheckArray[ix].sTableNm) )
        {
            sprintf(sSqlStr, "UPDATE HV_MNETSTLNTC t SET "
                             "t.CHECKSTATE = '%s'  "
                             " WHERE MSGTP = '%s'"
                             " AND INSTDDRCTPTY = '%s'"
                             " AND NPCPRCSTS = '%s'"
                             " AND STTLMDT = '%s'"
                             " AND TXTP = '%s'"
                             /*" AND CURRENCY = '%s'"*/,
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt,
                             VCheckArray[ix].sTxTpCd/*,
                             VCheckArray[ix].sCcy*/);
        }
        //业务状态查询表-往账
        else if ( 0 == strcmp("SNDTRANSINFOQRY", VCheckArray[ix].sTableNm) )
        {
            sprintf(sSqlStr, "UPDATE CM_TRANSINFOQRY t SET "
                             "t.CHECKSTATE = '%s'  "
                             " WHERE MSGTP = '%s'"
                             " AND INSTGDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s' AND RSFLAG <> '2' AND SYSID = 'HVPS'",
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt); 
        }
        //业务状态查询表-来账
        else if ( 0 == strcmp("RCVTRANSINFOQRY", VCheckArray[ix].sTableNm) )
        {
            sprintf(sSqlStr, "UPDATE CM_TRANSINFOQRY t SET "
                             "t.CHECKSTATE = '%s'  "
                             " WHERE MSGTP = '%s'"
                             " AND INSTDDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s' AND RSFLAG = '2' AND SYSID = 'HVPS'",
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt);
        }       
        else
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "do not support the table[%s]", VCheckArray[ix].sTableNm);
            m_hvcheckcl.closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "TableNm error");
        }        

    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sSqlStr[%s]", sSqlStr);
    	
        iRet = m_hvcheckcl.execsql(sSqlStr);
        if ( iRet != SQL_SUCCESS )
        {
            sprintf(sErrMsg, "更新[%s]表失败[%d][%s]", VCheckArray[ix].sTableNm, iRet, m_hvcheckcl.GetSqlErr());
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrMsg);
            m_hvcheckcl.closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, sErrMsg);
        }

        // 为避免大事务，每次都提交
        m_hvcheckcl.commit();
    }
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsCheckSum::UpdateSts()");  
}

void CHvpsCheckSum::updateBkChkSt()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CHvpsCheckSum::updateBkChkSt()");

    int iRet = -1;
    char sCheckState[2 + 1];

    if ( 0 < m_iTtlCnt || 0 < m_iLocalMore )
    {
        strcpy(sCheckState, PR_CNCH_22); //对账不符
    }
    else
    {
        strcpy(sCheckState, PR_CNCH_21); //对账相符
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_iTtlCnt[%d]m_iLocalMore[%d]sCheckState[%s]", 
        m_iTtlCnt, m_iLocalMore, sCheckState);
    
    iRet = m_checkaccount.upHvBkChkSt(m_szBkCode.c_str(), m_szChkDt.c_str(), sCheckState);
    if ( iRet != SQL_SUCCESS )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "更新HV_BKCHKST表失败[%d][%s]", 
            iRet, m_checkaccount.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新HV_BKCHKST表失败");
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CHvpsCheckSum::updateBkChkSt()");
}

void CHvpsCheckSum::DeleteCheckList()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsCheckSum::DeleteCheckList()");

    int  iRet = -1;
    char sDeleteSql[1024 + 1];
    
    //大额明细核对辅助表
    sprintf(sDeleteSql, "delete from HV_CHKLSTCL "
                " where INSTDDRCTPTY = '%s'",
                m_szBkCode.c_str()); 
    Trace(L_INFO, __FILE__, __LINE__, NULL, "sDeleteSql[%s]", sDeleteSql);

    iRet = m_hvcheckcl.execsql(sDeleteSql);
    if ( iRet != SQL_SUCCESS && iRet != SQLNOTFOUND )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "删除HV_CHKLSTCL失败[%d][%s]",
            iRet, m_hvcheckcl.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "删除HV_CHKLSTCL失败");
    }

    //大额明细核对表
    sprintf(sDeleteSql, "delete from HV_CHKLSTLIST "
                " where INSTDDRCTPTY = '%s'",
                m_szBkCode.c_str()); 
    Trace(L_INFO, __FILE__, __LINE__, NULL, "sDeleteSql[%s]", sDeleteSql);

    iRet = m_hvcheckcl.execsql(sDeleteSql);
    if ( iRet != SQL_SUCCESS && iRet != SQLNOTFOUND )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "删除HV_CHKLSTLIST失败[%d][%s]",
            iRet, m_hvcheckcl.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "删除HV_CHKLSTLIST失败");
    }
        
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsCheckSum::DeleteCheckList()");    
}

void CHvpsCheckSum::SndToNpcFor712(MQAgent &cMQAgent, LPCSTR sSendQueue)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsCheckSum::SndToNpcFor712()");

    char sBankNo[14 + 1] = {0};
    char sMesgId[20 + 1] = {0};
    char sMsgId[35 + 1] = {0};
    char sISODateTime[19 + 1] = {0};
    char sTemp[128 + 1] = {0};
    char sChkDt[8 + 1] = {0};
    int  iRet = -1;

    strncpy(sBankNo, m_szBkCode.c_str(), sizeof(sBankNo) - 1);
    
    //报文头赋值
    if ( !GetMsgIdValue(m_dbproc, sMesgId, eRefId,  SYS_HVPS, sBankNo) )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "取报文参考号失败");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_SYS_PARA_FAIL, "取报文参考号失败");
    }

    chgToDate(m_szChkDt.c_str(), sChkDt);
    m_hvps712.CreateXMlHeader("HVPS",
                              sChkDt,
                              m_szBkCode.c_str(),
                              "0000",
                              "hvps.712.001.01",
                              sMesgId);
                              
    //报文体赋值
    if ( !GetMsgIdValue(m_dbproc, sMsgId, eMsgId,  SYS_HVPS, sBankNo) )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "取报文标识号失败");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_SYS_PARA_FAIL, "取报文标识号失败");
    }
    GetIsoDateTime(m_dbproc, SYS_HVPS, sISODateTime);
    
    m_hvps712.MsgId           = sMsgId;         //报文标识号
    m_hvps712.CreDtTm         = sISODateTime;   //报文发送时间
    m_hvps712.InstgDrctPty    = m_szBkCode;     //发起直接参与机构
    m_hvps712.GrpHdrInstgPty  = m_szBkCode;     //发起参与机构
    m_hvps712.InstdDrctPty    = "0000"; //接收直接参与机构
    m_hvps712.GrpHdrInstdPty  = "0000"; //接收参与机构
    m_hvps712.SysCd           = "HVPS";         //系统编号
    m_hvps712.ChckngDt        = m_szChkDt;      //对账日期

    sprintf(sTemp, "%d", m_iTtlCnt);
    m_hvps712.TtlCnt          = sTemp;          //对账记录数目


    //组报文
    iRet = m_hvps712.CreateXml();
    if (0 != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "组712报文失败[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, "组712报文失败");    
    }

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sXMLBuff[%s]", m_hvps712.m_sXMLBuff.c_str());

	CMcheckqry m_checkqry;
	m_checkqry.m_msgid = m_hvps712.MsgId;
	m_checkqry.m_msgtype = "hvps.712.001.01";
	m_checkqry.m_sapbank = m_hvps712.InstgDrctPty;
	m_checkqry.m_checkdate = m_hvps712.ChckngDt;

	SETCTX(m_checkqry);
	iRet = m_checkqry.insert();
	if( 0 != iRet)
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FIND CM_CHECKQRY FILED[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "FIND CM_CHECKQRY FILED!");
	}
	
    //发送报文
    int i = m_hvps712.m_sXMLBuff.length();
	iRet = cMQAgent.PutMsg(sSendQueue, m_hvps712.m_sXMLBuff.c_str(), i);
	if (0 != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "将712报文PUTMQ失败[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_MQ_ADD_FAIL, "将712报文PUTMQ失败");    
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsCheckSum::SndToNpcFor712()");
}

void CHvpsCheckSum::AddDetail(LPCSTR sSndRcvTp)
{
    m_hvps712.AddNodeToSubcycle("MT"       , m_szMT.c_str());
    m_hvps712.AddNodeToSubcycle("TxTpCd"   , m_szTxTpCd.c_str());
    m_hvps712.AddNodeToSubcycle("SndRcvTp" , sSndRcvTp);
    m_hvps712.AddNodeToSubcycle("PrcSts"   , m_szPrcSts.c_str());

    m_hvps712.AddSubcycleToNode("Dtls");

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMT[%s]",     m_szMT.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "sSndRcvTp[%s]",  sSndRcvTp);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szTxTpCd[%s]", m_szTxTpCd.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szPrcSts[%s]", m_szPrcSts.c_str());
}

void CHvpsCheckSum::SetAllCtx()
{
    int iRet = -1;
    
    iRet = m_hvcheckcl.setctx(m_dbproc);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }
    
    iRet = m_checkaccount.setctx(m_dbproc);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }
}

