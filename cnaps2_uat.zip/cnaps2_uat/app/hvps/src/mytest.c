/********************************************************************
文件名：sendthvps.cpp
创建人：hdf
日  期：2011.01.14
修改人：hdf
日  期：
描  述：客户端业务往账处理主控
版  本：
Copyright (c) 2009  YLINK
********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>
#include "connectpool.h"
#include "CNAPS2hsm.h"
#include "assist.h"

CConnectPool	*g_DBConnPool;

int main(int argc, char * argv[])
{
	while(1)
	{
    	unsigned char pReturnCode;
    	unsigned char ucMacAlgFlag='1';
    	unsigned int uiIndex = 511;
    	unsigned int uiTextLen = 128;
    	unsigned char pucText[512 + 1] = {0};
    	unsigned char pucMax[20] = {0};
    	
    	strcpy((char *)pucText, "KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK");
    	//uiTextLen = strlen((char *)pucText);    	
    	
    	CNAPS2_GenerateMac_ByKeyIndex(&pReturnCode, ucMacAlgFlag, uiIndex, uiTextLen, pucText, pucMax);
    	
    	if(pReturnCode == 0x00)
		{
//			Trace(L_INFO, __FILE__, __LINE__, NULL, "加押成功。");
//			strcpy(pMacStr, MbBinToHex(pucMax, strlen((char *)pucMax)).c_str());
//			iRet = 0;
			
			printf("加押成功\n");
		}
		else
		{
//			Trace(L_ERROR, __FILE__, __LINE__, NULL, "加押失败，错误代码[%02x]", ucReturnCode);
//			sprintf((char *)pucMax, "加押失败, 错误代码=[%02x]", ucReturnCode);
//			strcpy(pMacStr, (char *)pucMax);
//			iRet = -1;
			printf("加押失败，错误代码[%02x]\n", pReturnCode);
			printf("pucMax=[%s]\n", pucMax);
		}
    	
   sleep(1);
 }
    return 0;
}

