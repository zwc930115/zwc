/******************************************************************** 
�ļ����� send152.cpp
�����ˣ� ������
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
/*

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendhvps152.h"
#include "category.h"


extern CConnectPool *g_DBConnPool;
extern CCategory g_LogObj;

using namespace ZFPT;

CSendHvps152::CSendHvps152(const stuMsgHead& Smsg):CSendHvpsBase(Smsg)
{


}

CSendHvps152::~CSendHvps152()
{
 
}

void CSendHvps152::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps152::SetData...");
    char sTm[7] = {0}; 
    getSysTime(sTm);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "sTm = %s", sTm);
        char temp[21] = {0};
    sprintf(temp, "%s.%s.%s.%s",  "hvps", m_szMsgType, "001", "01");
    sprintf(m_MsgTypeCode, "%-20s", temp);
    
    m_cParser152.m_PMTSHeader.setVerID("02");
    m_cParser152.m_PMTSHeader.setOrigSender(m_Hvsndlist.m_instgdrctpty.c_str());
    m_cParser152.m_PMTSHeader.setOrigSenderSID("HVPS");
    m_cParser152.m_PMTSHeader.setOrigReceiver(m_Hvsndlist.m_instddrctpty.c_str());
    m_cParser152.m_PMTSHeader.setOrigReceiverSID("HVPS");
    m_cParser152.m_PMTSHeader.setOrigSendDate(m_Hvsndlist.m_workdate.c_str());
    m_cParser152.m_PMTSHeader.setOrigSendTime(sTm);
    m_cParser152.m_PMTSHeader.setStructType(m_szMsgTypeFlag);
    m_cParser152.m_PMTSHeader.setMesgRefID(m_Hvsndlist.m_mesgrefid.c_str());
    m_cParser152.m_PMTSHeader.setMesgID(m_Hvsndlist.m_mesgid.c_str());
    m_cParser152.m_PMTSHeader.setMesgPriority(m_Hvsndlist.m_mesgrefid.c_str());
    m_cParser152.m_PMTSHeader.setMesgDirection("U");
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps152::SetData...");
    return;
}

int CSendHvps152::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps152::GetData...");
    
    m_Hvsndlist.setctx(m_dbproc);

    m_Hvsndlist.m_msgtp = m_szMsgType; 
	m_Hvsndlist.m_msgid = m_szMsgFlagNO; 
	m_Hvsndlist.m_instgdrctpty = m_szSndNO; 

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgType = %s", m_szMsgType);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgFlagNO = %s", m_szMsgFlagNO);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndNO = %s", m_szSndNO);

    int iRet = m_Hvsndlist.findByPK();
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps152::GetData...");
    return iRet;
}

int CSendHvps152::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps152::UpdateState...");
    
    m_Hvsndlist.setctx(m_dbproc);
    m_Hvsndlist.m_msgtp = m_szMsgType; 
	m_Hvsndlist.m_msgid = m_szMsgFlagNO; 
	m_Hvsndlist.m_instgdrctpty = m_szSndNO; 
    if(OPERACT_SUCCESS != m_Hvsndlist.setstate("02", m_sMesgId, m_sEndtoEnd))
    {
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��");
        return OPERACT_FAILED;
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps152::UpdateState...");
    return OPERACT_SUCCESS;
}

int CSendHvps152::doWorkSelf()
{
   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps152::doWork...");

    //��ȡ���ݿ�����
    int iRet = g_DBConnPool->GetConnect(m_dbproc);
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ���ݿ�����ʧ��");
        return ERR_DB_CONNT_FAILE;	
    }

    iRet = GetData();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ�� iRet = %d", iRet);
        return ERR_DB_GETDATA_FAILE;	
    }

    //3)	ҵ���飨�ͻ������룩
    //.......
    //4)	���������ͻ������룩
    //.....
    
    
    
    m_cParser152.Init(m_iVersion, atoi(m_szMsgType));
    SetData();
    iRet = m_cParser152.CreateMsg();
    if(OPERACT_SUCCESS != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        return ERR_CREATE_MSG_FAILE;
    }
    
    iRet = AddQueue( m_cParser152.m_MsgTxt.c_str(), m_cParser152.m_MsgTxt.length());
    if(iRet != OPERACT_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��MQ��������ʧ��");
        return ERR_MQ_ADD_FAILE;
    }
    
    iRet = UpdateState();
    if(iRet != OPERACT_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��");
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps152::doWork..."); 
    return OPERACT_SUCCESS;
}

*/
