                        
#include <sys/types.h>                            
#include <sys/wait.h>                            
#include <signal.h>  
//#include "connectpool.h"                            
#include "exception.h" 


//#include "configparser.h"                                     
                         
                               
                           
#include "cfg_obj.h"   
                         
#include "hvps111.h"                                                    
CCfgObj		pCfgFile;                       
                     

char		g_MQmgr[256];
char		g_MqTxtPath[256];
char		g_DbName[128];
char		g_DbUser[32];
char		g_DbKey[32];
char		g_SendQueue[128];
char		g_SendCCMSQueue[128];
char        g_SendCBSP[128];
int         g_IsConnCBSP;
char        g_IP[16];
int         g_IsConnPlatm;

static int getFileText(char *sFileName, char *sMsg, int maxlen)
{
	char sBuff[1024] ;

	//ѭ����ȡ���ݲ�����
	FILE *fp = NULL; 
	
	fp = fopen(sFileName, "r");
	
	if (fp == NULL)
	{
		printf("���ļ�����\n");
		return -1;	
	}
	
	int rendlen = 0;
	int iTotalLen = 0;

	while (1)
	{
		memset(sBuff, 0, sizeof(sBuff));
		fgets(sBuff, sizeof(sBuff), fp)	;
		
        rendlen = strlen(sBuff);
		if (rendlen == 0)
			break;

        if (iTotalLen+rendlen >= maxlen)
            break;
 
		strcpy(sMsg+iTotalLen ,sBuff);
		iTotalLen += rendlen;
	}

	return 0;
} 

int main(int argc, char **argv)
{
	

	int aaa=5.0329E+11;
	int iRet =  0;
	//CConfigParser& cCfg = CConfigParser::getInstance();
		
	if (argc < 2)
    {
        printf("Useage: %s filename\n", argv[0]);
        return -1;
    }
     try
    {
        int iRet = pCfgFile.Init("../cfg/pmtsxml.cfg");  //�����ļ�·��
        if(iRet != 0)
        {
            printf("Failed to Init the node Config Object: ErrCode = %d, ErrInfo = %s\n",
                pCfgFile.GetLastErrCode(), pCfgFile.GetLastErrInfo());

            return -1;
        }

        char pchMsg[10240] = {0};

        if (0 != getFileText(argv[1], pchMsg, sizeof(pchMsg)))
        {
            printf("��ȡ�ļ�%sʧ��", argv[1]);
            return -2;
        }

        printf("��ȡ�ı���Ϊ[%s]\n", pchMsg);



       printf("test singo 1111\n");
       hvps111 m_cHvps111;
       iRet = m_cHvps111.ParseXml(pchMsg);
        if (0 != iRet)
        {
            printf("��������ʧ��[%d]\n", iRet);
            return -3;
        }

    }
	catch(CException &e)
    {
        printf("Catch a exception from [%s]\n",  e.what());

        return -3;
    }
	printf("test end\n"); 

    return 0;
}
