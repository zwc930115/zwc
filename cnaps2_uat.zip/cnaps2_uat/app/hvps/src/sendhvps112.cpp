/******************************************************************** 
�ļ����� send112.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
    
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendhvps112.h"

CSendHvps112::CSendHvps112(const stuMsgHead& Smsg):CSendHvpsBase(Smsg)
{
    
}

CSendHvps112::~CSendHvps112()
{
    
}

void CSendHvps112::AddSign112()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendHvps112::AddSign112");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_cParser112.getOriSignStr();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSignBuff = [%s]", m_cParser112.m_sSignBuff.c_str());
	
	AddSign(m_cParser112.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_Hvsndlist.m_instgdrctpty.c_str());
	
	m_cParser112.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendHvps112::AddSign112");
}

void CSendHvps112::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps112::SetDBKey...");

	m_Hvsndlist.m_msgid = m_szMsgFlagNO; 
	m_Hvsndlist.m_instgindrctpty = m_szSndNO; 

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_msgid = %s", m_Hvsndlist.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_instgindrctpty = %s", m_Hvsndlist.m_instgindrctpty.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps112::SetDBKey...");
    return;
}

string CSendHvps112::GetTag2ND(const string& QryVal, const string& QryStr, int& iDepth)
{
    string strTemp;
    if(RTN_SUCCESS == GetTagVal(strTemp, QryStr, QryVal))
    { 
       /* //���ȡ��������ر���
        if(QryVal == "/D27/")
        {
            int rate = (int)atof(strTemp.c_str())*10000;
            char szRate[10] = {0};
            sprintf(szRate, "%7d", rate);
            strTemp = szRate;
        }*/
        strTemp = QryVal + strTemp;
        m_cParser112.SetUstrd(iDepth, strTemp.c_str());
        iDepth++;
    }

    return strTemp;
}

void CSendHvps112::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps112::SetData...");
    
    char sUstrdStr[100]               = {0};//�����ֶ�
    char szBuff[128]                 = {0};

    int iRet = GetIsoDateTime(m_dbproc,SYS_HVPS,m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
        PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }
    
    m_cParser112.m_szDigitSign       = "";
    m_cParser112.MsgId               = m_szMsgFlagNO;
    m_cParser112.CreDtTm             = m_ISODateTime;
    m_cParser112.SttlmPrty           = m_Hvsndlist.m_sttlmprty;
    m_cParser112.CdtrId              = m_Hvsndlist.m_cdtid;
    m_cParser112.EndToEndId          = m_sEndtoEnd;
    m_cParser112.Prtry               = m_Hvsndlist.m_ctgypurpprtry;
    m_cParser112.IntrBkSttlmAmt      = ftoa(szBuff, m_Hvsndlist.m_amount, 2);
    m_cParser112.DbtrId              = m_Hvsndlist.m_dbtid;
    m_cParser112.CdtrAdrLine         = m_Hvsndlist.m_cdtaddr;
    m_cParser112.DbtrAcctIssr        = m_Hvsndlist.m_dbtrissr;
    m_cParser112.SttlmMtd            = "CLRG";    
    m_cParser112.DbtrMmbId           = m_Hvsndlist.m_dbtmmbid;
    m_cParser112.CdtrNm              = m_Hvsndlist.m_cdtrnm;
    m_cParser112.DbtrAdrLine         = m_Hvsndlist.m_dbtaddr;
    
    int iDepth = 0; 

    string strTemp = "/F25/" + m_Hvsndlist.m_purpprtry;
    m_cParser112.SetUstrd(iDepth++, strTemp.c_str());

    strTemp = "/H01/" + m_Hvsndlist.m_addinfo;
    m_cParser112.SetUstrd(iDepth++, strTemp.c_str());

    strTemp = "/H02/" + m_Hvsndlist.m_addinfo2;
    m_cParser112.SetUstrd(iDepth, strTemp.c_str());
    
    m_cParser112.Ustrd               = m_Hvsndlist.m_ustrdstr;
    m_cParser112.CdtrMmbId            = m_Hvsndlist.m_cdtmmbid;
    m_cParser112.Ccy                 = m_Hvsndlist.m_currency; 
    m_cParser112.TxId                = m_Hvsndlist.m_msgid;
    m_cParser112.DbtrAcctId          = m_Hvsndlist.m_dbtracctid;
    m_cParser112.DbtrNm              = m_Hvsndlist.m_dbtnm;
    m_cParser112.CdtrAcctId          = m_Hvsndlist.m_cdtracctid;
    m_cParser112.CdtrAcctIssr        = m_Hvsndlist.m_cdtrissr;
    m_cParser112.NbOfTxs             = "1";

    
    m_cParser112.ClrMbId1             =   m_Hvsndlist.m_clrmbid1                ;//�н����1         
    m_cParser112.ClrMbId1Nm           =   m_Hvsndlist.m_clrmbid1name            ;// �н����1����    
    m_cParser112.ClrMbId2             =   m_Hvsndlist.m_clrmbid2                ;//�н����2         
    m_cParser112.ClrMbId2Nm           =   m_Hvsndlist.m_clrmbid2name            ;//�н����2����     
    m_cParser112.DbtrAcctIssrNm       =  m_Hvsndlist.m_dbtrlssrnm              ;// �����˿��������� 
    m_cParser112.CbtrAcctIssrNm       =  m_Hvsndlist.m_cdtrlssrnm              ;//�տ��˿���������  
    
    
    
    // ���ļ�ͷ
    m_cParser112.CreateXMlHeader("HVPS",                        \
                                m_Hvsndlist.m_workdate.c_str(), \
                                m_Hvsndlist.m_instgdrctpty.c_str(),\
                                m_Hvsndlist.m_instddrctpty.c_str(),\
                                "hvps.112.001.01",\
                                m_sMesgId.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sMesgId=%s", m_sMesgId.c_str());             
    
    if("A200" == m_Hvsndlist.m_ctgypurpprtry)//�м��ʽ�㻮
    {
        //++iDepth;
        GetTag2ND("/D27/", m_Hvsndlist.m_ustrdstr, iDepth);//���ݿ���û��
        GetTag2ND("/C18/", m_Hvsndlist.m_ustrdstr, iDepth);
    }

    if("A105" == m_Hvsndlist.m_ctgypurpprtry)//�˻�
    {
        //++iDepth;
        GetTag2ND("/E51/", m_Hvsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/A70/", m_Hvsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/F40/", m_Hvsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/H20/", m_Hvsndlist.m_ustrdstr, iDepth);            
    }
    
    if("A113" == m_Hvsndlist.m_ctgypurpprtry)//�羳

    {
        //++iDepth;
        GetTag2ND("/C14/", m_Hvsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/F56/", m_Hvsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/D63/", m_Hvsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/D64/", m_Hvsndlist.m_ustrdstr, iDepth);
        GetTag2ND("/H19/", m_Hvsndlist.m_ustrdstr, iDepth);
        //__ wsh 2012-11-19 ����1.4��׼������
		GetTag2ND("/H33/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/H34/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/H35/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/H36/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/H37/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/B29/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/H38/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/H39/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/H40/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/H41/", m_Hvsndlist.m_ustrdstr, iDepth);  
		GetTag2ND("/H42/", m_Hvsndlist.m_ustrdstr, iDepth); 
		GetTag2ND("/H43/", m_Hvsndlist.m_ustrdstr, iDepth); 
		GetTag2ND("/B30/", m_Hvsndlist.m_ustrdstr, iDepth);             
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps112::SetData...");
    return;
}

int CSendHvps112::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps112::GetData...");
    
    SetDBKey();
    
    SETCTX(m_Hvsndlist);
    int iRet = m_Hvsndlist.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ�� iRet = %d, %s", iRet, m_Hvsndlist.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    if(!m_Hvsndlist.m_endtoendid.empty())
    {
        m_sEndtoEnd = m_Hvsndlist.m_endtoendid;
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sEndtoEnd = %s", m_sEndtoEnd.c_str());
    }    
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps112::GetData...");
    return iRet;
}

int CSendHvps112::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps112::UpdateState...");
    
    SetDBKey();

    string strNpcMsg = "";
	if(!m_Hvsndlist.write_blob(m_cParser112.m_sXMLBuff.c_str(), strNpcMsg, SYS_HVPS)){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"д���ֶα�����:[%s]", m_Hvsndlist.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}

    string strSQL;
	strSQL += "UPDATE hv_sndexchglist t SET t.STATETIME = sysdate, t.PROCSTATE = '";
	strSQL += m_szProState;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
	strSQL += "', t.endtoendid = '";
	strSQL += m_sEndtoEnd;
	strSQL += "', t.npcmsg='";
	strSQL += strNpcMsg;
	strSQL += "' WHERE t.MSGTP = '";
	strSQL += m_Hvsndlist.m_msgtp.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_Hvsndlist.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Hvsndlist.m_instgindrctpty.c_str(); 									
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());

	SETCTX(m_Hvsndlist);
    int iRet = m_Hvsndlist.execsql(strSQL.c_str());
    
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��iRet=%d, %s", iRet, m_Hvsndlist.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }
    
    m_Hvsndlist.commit();

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps112::UpdateState...");
    return RTN_SUCCESS;
}

int CSendHvps112::doWorkSelf()
{
   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps112::doWork...");

    GetData();
    
    SetData();

    AddSign112();
    
    int iRet = m_cParser112.CreateXml();
    if(RTN_SUCCESS != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    //3)	ҵ���飨�ͻ������룩
    //.......
    //4)	���������ͻ������룩
    iRet = 0;
	if(RTN_SUCCESS != iRet)        
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ChargeMB iRet=%d", iRet);
		PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
	}
	
	strcpy(m_szProState,PR_HVBP_08); //���ҵ��û���Ŷӣ�����״̬����08�ѷ���

	//5) ����ͷ�繦��
	FundSettle();
    
    //Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_sXMLBuff=[%s]", m_cParser112.m_sXMLBuff.c_str());
    
    UpdateState();
    
    if(strcmp(m_szProState,PR_HVBP_08) == 0)//�������״̬Ϊ�ѷ��ͣ�����Խ�����дMQ
    {    
        AddQueue(m_cParser112.m_sXMLBuff.c_str(), m_cParser112.m_sXMLBuff.length());
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps112::doWork..."); 
    return RTN_SUCCESS;
}

int CSendHvps112::ChargeMB()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps112::ChargeMB...");

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps112::ChargeMB..."); 
    
    return RTN_SUCCESS;
}

int CSendHvps112::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps112::FundSettle...");
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û�[%s]", m_szOprUser);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_szSndNO);

	m_charge.m_amount = m_Hvsndlist.m_amount;	//ҵ����
	m_charge.m_iDCFlag = iDEBITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, m_szOprUserNetId);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_szSndNO);	//������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(iRet == 1)//���ö�Ȳ��㣬ҵ���Ŷ�
	{
		strcpy(m_szProState,PR_HVBP_55); //ҵ���Ŷ�
		iRet = m_charge.IntoPurpList(m_szOprUserNetId,m_Hvsndlist.m_workdate.c_str(),m_Hvsndlist.m_amount,m_Hvsndlist.m_msgid.c_str(),m_Hvsndlist.m_instgindrctpty.c_str(),m_Hvsndlist.m_msgtp.c_str(),"HVPS");
		if(iRet != RTN_SUCCESS)
		{
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�۳������ʽ�ʧ�ܣ�iRet=%d", iRet);
			PMTS_ThrowException(DB_INSERT_FAIL);
		}

		//�ͻ���Ϣ֪ͨ��ҵ���Ŷ�
		InsertUserInfoTel(m_Hvsndlist.m_msgid.c_str(),
			      m_Hvsndlist.m_instgindrctpty.c_str(),
			      m_Hvsndlist.m_instgdrctpty.c_str(),
			      m_Hvsndlist.m_instdindrctpty.c_str(),       
			      m_Hvsndlist.m_instddrctpty.c_str(),       						      
			      "HVPS",
			      m_Hvsndlist.m_msgtp.c_str(),
				  NT_CMIPUR,
				  " ");
	}
	else if(iRet == 2)//���ö�Ȳ��㣬ҵ����Ҫ�Ŷӣ�Ԥ��֪ͨ�ͻ�
	{
		InsertUserInfoTel(m_Hvsndlist.m_msgid.c_str(),
			      m_Hvsndlist.m_instgindrctpty.c_str(),
			      m_Hvsndlist.m_instgdrctpty.c_str(),
			      m_Hvsndlist.m_instdindrctpty.c_str(),       
			      m_Hvsndlist.m_instddrctpty.c_str(),       						      
			      "HVPS",
			      m_Hvsndlist.m_msgtp.c_str(),
				  NT_CMIQUE,
				  " ");
	}
	else if(iRet == -1)        
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�۳������ʽ�ʧ�ܣ�iRet=%d", iRet);
		PMTS_ThrowException(DATA_FAIL);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps112::FundSettle..."); 
    
    return RTN_SUCCESS;
}


