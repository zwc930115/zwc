/******************************************************************** 
�ļ����� recvcmt253.cpp
�����ˣ� aps-lel
��  �ڣ� 2011-05-18
�޸��ˣ� 
��  �ڣ� 
��  ���� ������˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvcmt253.h"

using namespace ZFPT;

CRecvCmt253::CRecvCmt253()
{
    m_strMsgTp = "CMT253";
    memset(m_sProcState, 0x00, sizeof(m_sProcState));
    memset(m_szBusiState, 0x00, sizeof(m_szBusiState));
    memset(m_szdate, 0x00, sizeof(m_szdate));
}


CRecvCmt253::~CRecvCmt253()
{

}

INT32 CRecvCmt253::Work(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt253::doWork()");

    // 1.��������
    unPack(pchMsg);
        
    // 2.����ԭҵ��
    UpdateOriTrade();
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt253::doWork()");

    return RTN_SUCCESS;
}

INT32 CRecvCmt253::unPack(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt253::unPack()");
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "receive msg = [%s]",pchMsg);
    // 1�������Ƿ�Ϊ��
    if (NULL == pchMsg || '\0' == pchMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_strBizCode.c_str(), "����Ϊ��");
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }
    
    int iRet = RTN_FAIL;
    
    // 3����������
    iRet = m_cCmt253.ParseCmt(pchMsg);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ParseCmt[%d]",iRet);

    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CRecvCmt253::Work(): ��������ʧ��");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������!");
    }

    char szTxssno[9] = {0};
    sprintf(szTxssno,"%08d",m_cCmt253.iTxssno);    
    // ���ı�ʶ��,����д�����ļ�����
    m_strMsgID = m_cCmt253.sConsigndate;
    m_strMsgID += szTxssno;
    //ZFPTLOG.SetLogInfo("253",m_strMsgID.c_str()); 
    

    // ��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "GetWorkDate[%s][%d]", m_sWorkDate, iRet);

    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");
        PMTS_ThrowException(OPT_GET_DATE_FAIL);
    }
    m_strWorkDate   =   m_sWorkDate;
     
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt253::unPack()");	
    
    return RTN_SUCCESS;
}


void CRecvCmt253::UpdateOriTrade()
{    
  	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt253::UpdateOriTrade()");

	int iRet = RTN_FAIL;
    char sSapbank[15] = {0};
	char sz_TempBal[30];
	STRING strSql;
    //iRet = GetSapBank(m_dbproc,m_cCmt253.sBankno,sSapbank);
    strcpy(sSapbank, "501290000012");
    //��8λ����ת��Ϊ10λ����
    chgToISODate(m_cCmt253.GetHeadWorkDate(),m_szdate);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szdate = [%s]",m_szdate);            
    //if(SUCCESSED !=iRet)
    //{
    //    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "��ȡ������ʧ�ܣ�");	
    //    PMTS_ThrowException(OTH_ERR);
    //}
	
	if (0 == memcmp(m_cCmt253.sDelcode+4, "0000", 4))
	{
	    memcpy(m_sProcState, PR_HVBP_19, sizeof(m_sProcState) - 1);
        memcpy(m_szBusiState, PROCESS_PR04, sizeof(m_szBusiState) - 1);
		UpdateSndexchglist("0",sSapbank);
	}
	else if (0 == memcmp(m_cCmt253.sDelcode, "CS2O9010", 8))
	{
	    memcpy(m_sProcState,  PR_HVBP_16, sizeof(m_sProcState) - 1);
        memcpy(m_szBusiState, PROCESS_PR12, sizeof(m_szBusiState) - 1);
		UpdateSndexchglist("1",sSapbank);

	}
	else
	{
        memcpy(m_sProcState, PR_HVBP_24, sizeof(m_sProcState) - 1);
        memcpy(m_szBusiState, PROCESS_PR09, sizeof(m_szBusiState) - 1);
		UpdateSndexchglist("",sSapbank);

	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt253::UpdateOriTrade()");
}

void CRecvCmt253::UpdateSndexchglist(const char * pFlag,const char * pSapbank)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt253::UpdateSndexchglist()");

    int iRet = RTN_FAIL;
    if(NULL == pFlag||NULL == pSapbank)
    {       
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "��������");	
        PMTS_ThrowException(PRM_FAIL);
    }

	//1����������
	SETCTX(m_cHvsndexchglist);
    
    string strSql;
    strSql = "update hv_sndexchglist t set t.iswait = '";
    strSql += pFlag;
    strSql += "', t.FINALSTATEDATE = '";
    strSql += m_szdate;
    strSql += "', t.PROCESSCODE = '";
    strSql += m_cCmt253.sDelcode;
    strSql += "', t.procstate = '";
    strSql += m_sProcState;
    strSql += "', t.busistate = '";
    strSql += m_szBusiState;
    strSql += "' , t.WAITSTART = sysdate, t.WAITEND = sysdate  where t.msgid = '";
    strSql += m_strMsgID + "' and t.INSTGINDRCTPTY = '";
    strSql += m_cCmt253.sBankno; 
    strSql += "'";
    iRet = m_cHvsndexchglist.execsql(strSql);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSql = [%s]",strSql.c_str());
    if(SQLNOTFOUND == iRet )//�ڴ������û���ҵ����¼�¼����ȥ��ʱת�˱��и���
    {
        UpdateTrofacSndlist(pFlag,pSapbank);
    }
    else if(SUCCESSED !=iRet && SQLNOTFOUND != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
            "m_cHvsndexchglist.execsql fail: error code = [%d],error cause = [%s]",iRet,m_cHvsndexchglist.GetSqlErr()); 
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "pFlag = [%s],  m_cHvsndexchglist.m_msgtp =[%s]",pFlag, m_cHvsndexchglist.m_msgtp.c_str() );
    if( 0 == strncmp(pFlag, "0", 1) && m_cHvsndexchglist.m_msgtp == "CMT108" )
    {
        string strTemp="";
        string orgnlmsgid = "";
        string orgnlmsgtp = "";
	    //GetTagVal(orgnlmsgid,  m_cHvsndexchglist.m_ustrdstr, "051:");
	    GetTagVal(orgnlmsgid,  m_cHvsndexchglist.m_ustrdstr, "005:");
	    //char msgno[8 + 1] ={0};
	    //sprintf(msgno, "%08d", atoi(strTemp.c_str()));
	    //m_OriHvsnddexlist.m_msgid += msgno;
	    
	    strTemp="";
	    GetTagVal(strTemp,  m_cHvsndexchglist.m_ustrdstr, "02B:");
	    orgnlmsgtp = "CMT" + strTemp; 
	    
	    char *sTableNm = "hv_rcvexchglist";
	    char strSQL[1024] = {0};
	    sprintf(strSQL,  " UPDATE %s t SET"
					" t.isrbflg = '1'"
 					" WHERE t.MSGID = '%s'"
					" AND t.MSGTP = '%s' ",
					sTableNm,
					orgnlmsgid.c_str(),
					orgnlmsgtp.c_str());
	
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSQL = [%s]",strSQL);
		SETCTX(m_cHvsndexchglist);
        int iRet = m_cHvsndexchglist.execsql(strSQL);
        if(iRet != RTN_SUCCESS)
        {
            sTableNm = "hv_rcvexchglisthis";
            memset(strSQL, 0, sizeof(strSQL));
            
            sprintf(strSQL,  " UPDATE %s t SET"
					" t.isrbflg = '1'"
 					" WHERE t.MSGID = '%s'"
					" AND t.MSGTP = '%s' ",
					sTableNm,
					orgnlmsgid.c_str(),
					orgnlmsgtp.c_str());
					
			iRet = m_cHvsndexchglist.execsql(strSQL);
            if(iRet != RTN_SUCCESS)
			{		
        		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸�ԭ֧��ҵ���˻ر�־ʧ��iRet=%d, %s", iRet, m_cHvsndexchglist.GetSqlErr());
        		PMTS_ThrowException(DB_UPDATE_FAIL);
            }
        }   
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt253::UpdateSndexchglist()");
}

void CRecvCmt253::UpdateTrofacSndlist(const char * pFlag,const char * pSapbank)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt253::UpdateTrofacSndlist()");

    int iRet = RTN_FAIL;
    if(NULL == pFlag||NULL == pSapbank)
    {       
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "��������");	
        PMTS_ThrowException(PRM_FAIL);
    }

	//1����������
	SETCTX(m_cHvtrofacsndlist);
    
    string strSql;
    strSql = "update hv_trofacsndlist t set t.iswait = '";
    strSql += pFlag;
    strSql += "', t.FINALSTATEDATE = '";
    strSql += m_szdate;
    strSql += "', t.PROCESSCODE = '";
    strSql += m_cCmt253.sDelcode;
    strSql += "', t.procstate = '";
    strSql += m_sProcState;
    strSql += "', t.busistate = '";
    strSql += m_szBusiState;
    strSql += "' , t.WAITSTART = sysdate, t.WAITEND = sysdate where t.msgid = '";
    strSql += m_strMsgID + "' and t.INSTGINDRCTPTY = '";
    strSql += pSapbank;
    strSql += "'";
    iRet = m_cHvsndexchglist.execsql(strSql);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSql = [%s]",strSql.c_str());
    if(SQLNOTFOUND == iRet )//�ڼ�ʱת�˱���û���ҵ����¼�¼
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "NOT FIND UPDATA DATA");
    }
    else if(SUCCESSED !=iRet && SQLNOTFOUND != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
            "m_cHvtrofacsndlist.execsql fail: error code = [%d],error cause = [%s]",iRet,m_cHvtrofacsndlist.GetSqlErr()); 
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt253::UpdateTrofacSndlist()");

}

/******************************************************************************
*  Function:   InsertComsendmb
*  Description:������ͨѶ��
*  Input:      LPCSTR sMsg
*  Output:     
*  Return:     0   : �����ɹ�,
               ����: ����ʧ��
*  Others:     ��
*  Author:     hhc
*  Date:       2012-04-18
*******************************************************************************/
INT32 CRecvCmt253::InsertComsendmb(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt253::InsertComsendmb()");
	
	int    iRet = RTN_FAIL;
	string strRval = "";
	
	//������ֵ
	m_cHvsndexchglist.m_msgid = m_strMsgID;
	m_cHvsndexchglist.m_instgindrctpty = m_cCmt253.sBankno;

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_msgtp=[%s]" ,m_cHvsndexchglist.m_msgtp.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_msgid=[%s]" ,m_cHvsndexchglist.m_msgid.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_instgindrctpty=[%s]" ,m_cHvsndexchglist.m_instgindrctpty.c_str());

	//��������
	if (0 != m_cHvsndexchglist.setctx(m_dbproc))
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
		PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
	}

	//��ѯԭҵ��
	iRet = m_cHvsndexchglist.findByPK();
	if (RTN_SUCCESS != iRet)
	{
		snprintf(m_szErrMsg, sizeof(m_szErrMsg) - 1, 
			"�յ�����253���ģ�����ԭ������ʴ�������ҵ����Ϣʧ��;[%d]", iRet);
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);       
		PMTS_ThrowException(__FILE__, __LINE__, DB_FIND_BY_PK_FAIL, m_szErrMsg);        
	}
	
	iRet = GetTagVal(strRval, m_cHvsndexchglist.m_reserve, ":orimsgsys:");
	if(0 == iRet)
	{
		strcpy(m_szDisSys, strRval.c_str());
		strncpy(m_szOrgnlMbMsgId, m_cHvsndexchglist.m_mbmsgid.c_str(), 22);
    
		//�жϼ�ֱ���������ֱ����������ͨѶ�� BY ADD ZQL 
		if(m_cHvsndexchglist.m_msgdirect =="0")
		{
		    DirectInter(m_cHvsndexchglist.m_instgindrctpty.c_str(), 
		    			m_cHvsndexchglist.m_instdindrctpty.c_str(),
		    			m_cHvsndexchglist.m_instddrctpty.c_str(), 
		    			sMsg);
	    }
	}
	else//����������ͨѶ��
	{
        Trace(L_INFO, __FILE__, __LINE__, NULL, "������������");
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt253::InsertComsendmb()");

	return RTN_SUCCESS;
}


