/******************************************************************** 
�ļ����� sendhvps143.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
    
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendhvps143.h"

CSendHvps143::CSendHvps143(const stuMsgHead& Smsg):CSendHvpsBase(Smsg)
{

}

CSendHvps143::~CSendHvps143()
{
}

void CSendHvps143::AddSign143()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendHvps143::AddSign143");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_cParser143.getOriSignStr();
	
	AddSign(m_cParser143.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_cParser143.InstgDrctPty.c_str());
	
	m_cParser143.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendHvps143::AddSign143");
}

int CSendHvps143::doWorkSelf()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps143::doWork...");
	int iRet = 0;
	
	GetData();
	
	SetData();
	
	//��ǩ
	AddSign143();
	
	
	iRet = m_cParser143.CreateXml();
	if(RTN_SUCCESS != iRet)        
	{            
		  Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
		  PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
	}
	
	//3)	ҵ���飨�ͻ������룩
	//.......
	//4)	���������ͻ������룩
	//.....    
	UpdateState();
	
	AddQueue(m_cParser143.m_sXMLBuff.c_str(), m_cParser143.m_sXMLBuff.length());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps143::doWork..."); 
	return RTN_SUCCESS;
}


void CSendHvps143::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps143::SetData...");
	
	char szBuff[128]                 = {0};
	int iRet = GetIsoDateTime(m_dbproc, SYS_HVPS, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }
    
    m_cParser143.MsgId = m_Hvpvpsetofac.m_msgid;
    m_cParser143.CreDtTm = m_ISODateTime ;
    m_cParser143.InstgDrctPty = m_Hvpvpsetofac.m_instgdrctpty ;
    m_cParser143.GrpHdrInstgPty = m_Hvpvpsetofac.m_instgindrctpty;
    m_cParser143.InstdDrctPty = m_Hvpvpsetofac.m_instddrctpty ;
    m_cParser143.GrpHdrInstdPty = m_Hvpvpsetofac.m_instdindrctpty;
    m_cParser143.SysCd = "HVPS" ;
    if( m_Hvpvpsetofac.m_msgdirect == "0")
    {
        m_cParser143.Rmk = "";
    }
    else
    {
        m_cParser143.Rmk = m_Hvpvpsetofac.m_reserve;
    }
    m_cParser143.Nm = m_Hvpvpsetofac.m_dbtnm;
	m_cParser143.OthrId = m_Hvpvpsetofac.m_dbtracctid;
	m_cParser143.Issr = m_Hvpvpsetofac.m_dbtrissr;
	memset(szBuff, 0x00, sizeof(szBuff));
	m_cParser143.PurchsPric = m_Hvpvpsetofac.m_purchspricccy;
	m_cParser143.PurchsPric += ftoa(szBuff, m_Hvpvpsetofac.m_purchspric,2);
	memset(szBuff, 0x00, sizeof(szBuff));
	m_cParser143.BuyAmt = ftoa(szBuff, m_Hvpvpsetofac.m_buyamt, 2);
	m_cParser143.Tp = m_Hvpvpsetofac.m_currency;
    m_cParser143.TxlCtrctNb = m_Hvpvpsetofac.m_txlctrctnb;

    //1�����ļ�ͷ 
    m_cParser143.CreateXMlHeader("HVPS",                        \
                                m_Hvpvpsetofac.m_workdate.c_str(), \
                                m_Hvpvpsetofac.m_instgdrctpty.c_str(),\
                                m_Hvpvpsetofac.m_instddrctpty.c_str(),\
                                "hvps.143.001.01",\
                                m_sMesgId.c_str()); 
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps143::SetData...");
    return;
}

void CSendHvps143::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps143::SetDBKey...");

	m_Hvpvpsetofac.m_msgid = m_szMsgFlagNO; 
	m_Hvpvpsetofac.m_instgindrctpty = m_szSndNO; 
    m_Hvpvpsetofac.m_msgtp= "hvps.143.001.01";
	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvpvpsetofac.m_msgid = %s", m_Hvpvpsetofac.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvpvpsetofac.m_instgdrctpty = %s", m_Hvpvpsetofac.m_instgindrctpty.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps143::SetDBKey...");
    return;
}

int CSendHvps143::GetData()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps143::GetData...");

	SETCTX(m_Hvpvpsetofac);
	SetDBKey();
	int iRet = m_Hvpvpsetofac.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ�� iRet = %d, %s", iRet, m_Hvpvpsetofac.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps143::GetData...");
	return iRet;
}

int CSendHvps143::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps143::UpdateState...");
    
    SetDBKey();
    string strSQL;
	strSQL += "UPDATE hv_pvpsetofac t SET t.STATETIME = sysdate, t.PROCSTATE = '08'";
	strSQL += ", t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
    strSQL += "' ";
    
	strSQL += " WHERE t.MSGTP = '";
	strSQL += m_Hvpvpsetofac.m_msgtp.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_Hvpvpsetofac.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Hvpvpsetofac.m_instgindrctpty.c_str(); 									
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	
    SETCTX(m_Hvpvpsetofac);	
    int iRet = m_Hvpvpsetofac.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ�� iRet = %d, %s", iRet, m_Hvpvpsetofac.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps143::UpdateState...");
    return iRet;
}


