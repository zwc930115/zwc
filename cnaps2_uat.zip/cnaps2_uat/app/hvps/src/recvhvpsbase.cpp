/******************************************************************** 
文件名： recvhvpsbase.cpp 
创建人： yszhong
日  期： 2011-03-01
修改人： 
日  期： 
描  述： 大额接收基类 
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 
    
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include <sqlca.h>
#endif

#include "ccms990.h"
#include "recvhvpsbase.h"
#include "cmtfileoperator.hpp"
#include "sysmsgonlinectrl.h"
#include "syscomsendmb.h"
#include "rout.h"
using namespace ZFPT;

extern char		g_MQmgr[256];
extern char		g_MqTxtPath[256];
extern char		g_SendQueue[128];
extern char		g_SendCCMSQueue[128];
extern int      g_iCfcaSign;//是否验签名或核押
extern char     g_SapBank[17];
extern char		g_msgpath[128];
extern Rout    *g_rout;

CRecvHvpsBase::CRecvHvpsBase()
{
    memset(m_szErrMsg, 0x00, sizeof(m_szErrMsg));	
    m_strBizCode       = "";
    m_strRcvMsgID      = "";
    m_strMsgID         = "";
    m_bIfOptBigData    = true;
    
	memset(m_szOprUser, 0x00, sizeof(m_szOprUser));
	memset(m_szOprUserNetId,0x00, sizeof(m_szOprUserNetId));
	
    memset(m_sWorkDate, 0x00, sizeof(m_sWorkDate));
    m_strWorkDate      = "";
    m_iMsgVer          = 2;
    m_strMsgTp         = "";
    m_strSendMsg    = "";
	memset(m_sCommHead, 0x00, sizeof(m_sCommHead));
	memset(m_szDisSys, 0x00, sizeof(m_szDisSys));
	memset(m_szOrgnlMbMsgId, 0x00, sizeof(m_szOrgnlMbMsgId));
	memset(m_szIngoingDetailTable, 0x00, sizeof(m_szIngoingDetailTable));
	memset(m_szPmtTpPrtry, 0x00, sizeof(m_szPmtTpPrtry));
	iBaseCertSign = 1;
}

CRecvHvpsBase::~CRecvHvpsBase()
{
}

int CRecvHvpsBase::CheckSign(const char *srcSign, const char *dstSign, const char * sSendBankCode, int iFlag)
{
	int iRet = 0;
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvHvpsBase::CheckSign...");
    
	return 0;//test
	
    string strSendBankCode = sSendBankCode;
	
    char *Str = new char[strlen(srcSign) + 1];
    ISNULL(Str);
    strcpy(Str, srcSign);
    iRet = checkSign(m_dbproc,signTrim(Str),
                            (char *)dstSign,
                            Trim(strSendBankCode).c_str(),
                            iFlag);
    DELPOINT(Str);
	if( RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR, __FILE__, __LINE__,NULL, "数字签名验证未通过!");
		PMTS_ThrowException(__FILE__, __LINE__, OPT_CHECKSIGN_FAIL, "数字签名验证未通过");
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvHvpsBase::CheckSign...");

    return iRet;

}

void CRecvHvpsBase::Init()
{
    int iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS, g_SapBank);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");	
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
}

INT32 CRecvHvpsBase::doWork(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvpsBase::doWork()");
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "i get a msg[%s]", pchMsg);		

    int iRet = RTN_FAIL;
    char sRet[15 + 1] = { 0 };
    try
    {
    	//获取MQ连接
    	//GetMqConn();
		
        // 获取数据库连接
        //GetDBConnect();
		
        Init();

		//回应990
    	Send990(pchMsg);

		//delete begin by jienjun 20161111	question  332  the msg 711,713,715 send to TOPS from progress routrecv
		#if 0
		//ɧ¹�֋`Ј½«±¨τЈ·¢¸�£¬ҵϱ´¦mº󲼔ٷ¢̍
	    if( "710" == m_strBizCode ||
			"713" == m_strBizCode ||
			"715" == m_strBizCode)
	    {
			if (SUCCESSED != g_rout->PutMsg(pchMsg))
			{
				   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "往MQ发送消息失败！");
				   PMTS_ThrowException(OPT_MQ_ADD_FAIL);			
			}
		}
		#endif
		//delete end by jienjun 20161111	  question  332  the msg 711,713,715 send to TOPS from progress routrecv
		
		
		// 子业务入口
		iRet = Work(pchMsg);
		if (SUCCESSED != iRet)
		{
		    Trace(L_ERROR, __FILE__, __LINE__, NULL, "子业务处理失败!iRet = [%d]",iRet);
		}	

		 //modify begin by jienjun 20161111  question  332	the msg 711,713,715 send to TOPS from progress routrecv
		 //if( "710" != m_strBizCode &&
		 if( "711" != m_strBizCode &&		 	
			 "713" != m_strBizCode &&
			 "715" != m_strBizCode)
		 {
			 if (SUCCESSED != g_rout->PutMsg(pchMsg))
			 {
					Trace(L_INFO,  __FILE__,  __LINE__, NULL, "往MQ发送消息失败！");
					PMTS_ThrowException(OPT_MQ_ADD_FAIL);			 
			 }
		 }
		 //modify end by jienjun 20161111  question  332	the msg 711,713,715 send to TOPS from progress routrecv
		    
		 SETCTX(m_cHvrecvmsg);
		 m_bIfOptBigData = true;    // 操作大文本表

		DelHvRecvMsg();            // 删除大额来帐通讯表数据:这里失败，暂不处理

		m_cHvrecvmsg.commit();            
		m_cMQAgent.Commit();
    }
    catch(CException &e)
    {   
        sprintf(m_szErrMsg, "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());
        Trace(L_ERROR, __FILE__, __LINE__, NULL,m_szErrMsg );	
		m_cMQAgent.Commit();
        //异常处理
       iRet = DoException(pchMsg, e.code(), e.what());
            
    }   
    catch(CT_CommException &e)
    {
        sprintf(m_szErrMsg, "parser msg error,error info:[%s] " ,e.GetErrInfo() );
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_szErrMsg);
        m_cMQAgent.Commit();
        iRet = DoException(pchMsg, OPT_PRS_MSG_FAIL, e.GetErrInfo());
    }
    catch(...)
    {
         Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "未知异常截获！ " );
         m_cMQAgent.Commit();
         iRet = DoException(pchMsg, OTH_ERR, "未知异常！");
    }
	//释放连接
	  g_DBConnPool->PutConnect(m_dbproc);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvpsBase::doWork()");

    return iRet;
}

INT32 CRecvHvpsBase::doChildWork(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvpsBase::doChildWork()");
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "i get a msg[%s]", pchMsg);		

    int iRet = RTN_FAIL;
    char sRet[15 + 1] = { 0 };

		iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS, g_SapBank);
		if(iRet != RTN_SUCCESS)
		{
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "获取工作日期失败！");	
			PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
		}

		// 子业务入口
		iRet = Work(pchMsg);
		if (SUCCESSED != iRet)
		{
		    Trace(L_ERROR, __FILE__, __LINE__, NULL, "子业务处理失败!iRet = [%d]",iRet);
		}	

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvpsBase::doChildWork()");

    return iRet;
}

int CRecvHvpsBase::AddQueue(string msgtx, int length)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvHvpsBase::AddQueue...");
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "消息内容:msgtx = %s", msgtx.c_str());

    int iRet = m_cMQAgent.PutMsg(g_SendQueue, msgtx.c_str(), length);
    if(iRet != RTN_SUCCESS)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "往MQ发送消息失败！");
		PMTS_ThrowException(OPT_MQ_ADD_FAIL);
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvHvpsBase::AddQueue...");
    return iRet;
}


/******************************************************************************
*  Function:   GetDBConnect
*  Description:获取数据库连接
*  Input:      无
*  Output:     无
*  Return:     无
*  Others:     无
*  Author:     zys
*  Date:       2011-03-01
*******************************************************************************/
void CRecvHvpsBase::GetDBConnect(void)
{
    char	sSapBank[14 + 1]	= { 0 };
    int bRet = 0;
    if(0 == g_DBConnPool->GetConnect(m_dbproc))
    {
        bRet = GetSysParam(m_dbproc,"01", sSapBank);
        if(bRet !=0)
        {
            if(0 == g_DBConnPool->DBReconnect(m_dbproc))
            {
                bRet = GetSysParam(m_dbproc,"01", sSapBank);
                if(!bRet)
                {
                    snprintf(m_szErrMsg, sizeof(m_szErrMsg), "CRecvBepsBase::GetDBConnect():获取数据库连接失败");
                    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
                    PMTS_ThrowException(DB_CNNCT_FAIL);
                }
            }
            else
            {
                snprintf(m_szErrMsg, sizeof(m_szErrMsg), "CRecvBepsBase::GetDBConnect():获取数据库连接失败");
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
                PMTS_ThrowException(DB_CNNCT_FAIL);
            }		
        }
    }
    else
    {
        if(0 == g_DBConnPool->DBReconnect(m_dbproc))
        {
            bRet = GetSysParam(m_dbproc,"01", sSapBank);
            if(bRet !=0)
            {
                snprintf(m_szErrMsg, sizeof(m_szErrMsg), "CRecvBepsBase::GetDBConnect():获取数据库连接失败");
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
                PMTS_ThrowException(DB_CNNCT_FAIL);
            }
        }
        else
        {
            snprintf(m_szErrMsg, sizeof(m_szErrMsg), "CRecvBepsBase::GetDBConnect():获取数据库连接失败");
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
            PMTS_ThrowException(DB_CNNCT_FAIL);
        }		
    }

    m_charge.m_dbproc = m_dbproc;	//初始化记账类
    
}

/******************************************************************************
*  Function:   GetMqConn
*  Description:获取MQ连接
*  Input:      无
*  Output:     无
*  Return:     无
*  Others:     无
*  Author:     zys
*  Date:       2011-03-01
*******************************************************************************/
void CRecvHvpsBase::GetMqConn(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvpsBase::GetMqConn()");	
	
	 //初始化MQ
    if(0 != m_cMQAgent.Init(g_MQmgr, g_MqTxtPath))
    {
    	snprintf(m_szErrMsg, sizeof(m_szErrMsg), 
			"CRecvHvpsBase::GetMqConn(),Init Thread MQ manager failed.");
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		
        PMTS_ThrowException(OPT_GET_MQ_CNNCT_FAIL);
    }
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvpsBase::GetMqConn()");		
}


/******************************************************************************
*  Function:   DelHvRecvMsg
*  Description:从大额来帐通讯表hv_recvmsg里删除对应m_sMsgID的信息
*  Input:      无
*  Output:     无
*  Return:     0   : 操作成功,
               其他: 操作失败
*  Others:     无
*  Author:     zys
*  Date:       2011-02-17
*******************************************************************************/
INT32 CRecvHvpsBase::DelHvRecvMsg(void)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "entering CRecvHvpsBase::DelHvRecvMsg()");

    // 若m_strRcvMsgID为空，则无法对应到hv_recvmsg中的记录
    if ("" == m_strRcvMsgID)
    {
        return RTN_FAIL;
    }

    if(m_iErrMsgFlag)
    {
        if( 0 != DelMsgFile(m_strRcvMsgID.c_str()))
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "del file [%s] failed",m_strRcvMsgID.c_str());
            PMTS_ThrowException(DB_DEL_FAIL);
        } 
        
        if(RTN_SUCCESS != DelRecvErrmsg(m_dbproc, m_iErrMsgFlag))
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "del row [%d] failed",m_iErrMsgFlag);
            PMTS_ThrowException(DB_DEL_FAIL);
        }

    }
    else
    {
        string strMsgFile = g_msgpath;
        strMsgFile += "/";
        strMsgFile += m_strRcvMsgID;
        
        if( 0 != DelMsgFile(strMsgFile.c_str()))
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "del file [%s] failed",strMsgFile.c_str());
            PMTS_ThrowException(DB_DEL_FAIL);
        } 

    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvpsBase::DelHvRecvMsg()");

    return RTN_SUCCESS;
}

INT32 CRecvHvpsBase::DoException(LPCSTR pchMsg, int nErrCode, LPCSTR pchErrDesc)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvpsBase::DoException");	

     if(nErrCode == DB_CNNCT_FAIL)
    {
        //连接数据库失败，暂时不做任务操作
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "error:MB_PFR0020:[%s]", m_strRcvMsgID.c_str());
        return RTN_SUCCESS;
    }

    // 回滚数据库	
	int iRet = m_cHvrecvmsg.setctx(m_dbproc);
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_cHvrecvmsg setctx failed!");
		return iRet;
	}
    m_cHvrecvmsg.rollback();

    if(m_iErrMsgFlag != 0)
    {
        iRet = UpdateRecvErrmsg(m_dbproc, m_iErrMsgFlag);
        if(RTN_SUCCESS != iRet)
        {
            Trace(L_FATAL,  __FILE__,  __LINE__, NULL, "更改状态失败,写错误文件,客户端上看不到这条记录!!");
            WriteErrFile(pchMsg);
            return iRet;
        }
        
        return RTN_SUCCESS;
    }
    
    // 写大额来帐异常表
    if (0 == WriteErrTable(pchMsg, nErrCode, pchErrDesc))
    {
        m_bIfOptBigData = false;  // 不操作大文本表
        m_cHvrecvmsg.commit();
    }
    else // 写大额来帐异常表失败，写入文件
    {
        m_cHvrecvmsg.rollback();
        WriteErrFile(pchMsg);  // 写文件
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvpsBase::DoException");
    return RTN_SUCCESS;
}

/******************************************************************************
*  Function:   WriteErrTable
*  Description:大额异常来帐表hv_recverrmsg插入记录
*  Input:	   pchErrCode:错误码
			   pchErrDesc:错误信息描述
*  Output:	   
*  Return:	   0   : 操作成功,
			   其他: 操作失败
*  Others:	   无
*  Author:	   zys
*  Date:	   2011-02-21
*******************************************************************************/

INT32 CRecvHvpsBase::WriteErrTable(const char * pchMsg, int nErrCode, const char * pchErrDesc)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvpsBase::WriteErrTable()");

    int iRet = RTN_FAIL;

    // 错误码为空
    if (NULL == pchErrDesc || "" == m_strRcvMsgID)
    {
        return RTN_FAIL;
    }

    // 获取工作日期
    char sWorkDate[8 + 1];
    char sCode[10] = {0};
    memset(sWorkDate, 0x00, sizeof(sWorkDate));
    iRet = GetWorkDate(m_dbproc, sWorkDate, SYS_BEPS);
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");
		return iRet;
	}
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "sWorkDate = %s", sWorkDate);

    // 给大额来帐异常表字段赋值
    m_cCmrecverrmsg.m_syscode    = "HVPS";
    //m_cCmrecverrmsg.m_msgtext    = pchMsg;

    m_cCmrecverrmsg.m_msgtext    = g_msgpath;
    m_cCmrecverrmsg.m_msgtext    += "/";
    m_cCmrecverrmsg.m_msgtext    += m_strRcvMsgID;
    
    m_cCmrecverrmsg.m_wrkdate    = sWorkDate; 
    m_cCmrecverrmsg.m_msgtp      = m_ErrMsgTp; 
    m_cCmrecverrmsg.m_procstate  = "00"; 
    m_cCmrecverrmsg.m_proctimes  = 1; 
    m_cCmrecverrmsg.m_errcode    = itoa(sCode,nErrCode); 
    m_cCmrecverrmsg.m_errdesc    = pchErrDesc; 


    // 设置连接
	iRet = m_cCmrecverrmsg.setctx(m_dbproc);
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_cCmrecverrmsg setctx failed!");
		return iRet;
	}
		
	// 往大额来帐异常表插入记录
    iRet = m_cCmrecverrmsg.insert();
    if (0 != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
			"m_cCmrecverrmsg.insert()fail: error_code = [%d],error_cause = [%s]",iRet,m_cCmrecverrmsg.GetSqlErr());
		return iRet;
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvpsBase::WriteErrTable()");

    return iRet;
}
    
/******************************************************************************
*  Function:   WriteErrFile
*  Description:写异常文件
*  Input:	   pchMsgID:报文标识
*  Output:	   
*  Return:	   0   : 操作成功,
			   其他: 操作失败
*  Others:	   无
*  Author:	   zys
*  Date:	   2011-03-02
*******************************************************************************/
INT32 CRecvHvpsBase::WriteErrFile(const char * pchErrText)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvpsBase::WriteErrFile()");

    time_t timep;
    struct tm *p;
    time(&timep);
    p = gmtime(&timep);

    char szchPathName[gc_nMaxPathLen] = {0};

    sprintf(szchPathName, "../errmsg/%d/%d/%d/hvps/", p->tm_year + 1900, p->tm_mon + 1, p->tm_mday);
    //printf("开始创建日志目录!_newName=%s\n", _newName);
    bool bRet = createDeepDir(szchPathName);
    if(!bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "异常文件目录创建失败");
        return RTN_FAIL;
    }

    FILE* msgFile = NULL;

    char szchTime[8 + 1] = {0};
    sprintf(szchTime, "%02d%02d%02d", p->tm_hour, p->tm_min, p->tm_sec);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "szchTime:%s", szchTime);

    string strFileName = szchPathName;
    strFileName += "hvps";
    strFileName += "-";
    strFileName += m_strBizCode;
    strFileName += "-";
    strFileName += m_strMsgID;
    strFileName += "-";
    strFileName += szchTime;
    strFileName += ".txt";

    if (NULL != (msgFile = fopen(strFileName.c_str(), "w+")))
    {
        fprintf(msgFile, "%s", pchErrText);
        fclose(msgFile);
    }
    else
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "写异常文件失败");
        return RTN_FAIL;
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvpsBase::WriteErrFile()");

    return RTN_SUCCESS;
}

int CRecvHvpsBase::AddSign(const char *srcSign, char *dstSign, int iFlag,const char * pSendSapbank)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvpsBase::AddSign...");
    
    int iRet = RTN_FAIL;
    
    char *Str = new char[strlen(srcSign) + 1];  
    // Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strlen(srcSign) = [%d]",strlen(srcSign));  
    
    ISNULL(Str);  
    strcpy(Str,srcSign);
    
    iRet = digitSign(m_dbproc, signTrim(Str), dstSign, SYS_HVPS, iFlag, pSendSapbank);
    
    DELPOINT(Str);
    
    if( RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "数字签名加签失败");
        PMTS_ThrowException(OPT_DIGITSIGN_FAIL);
    }
		
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvpsBase::AddSign...");
    return RTN_SUCCESS;
}

void CRecvHvpsBase::Send990(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvpsBase::Send990()");

	ccms990	oCcms990;
	char	sMsgRefId[20 + 1]	= { 0 };
	char	sOrignSender[14 + 1]= { 0 };
    char	sOrignReceiver[14 + 1]= { 0 };
	char	sOrignSendDate[8 + 1]={ 0 };
	char	sOrignMsgType[20 + 1]={ 0 };
	char	sOrignMesgID[35 + 1]= { 0 };
	char	sOrignRefId[35 + 1] = { 0 };
	
	GetMsgIdValue(m_dbproc, sMsgRefId, eRefId, SYS_HVPS, g_SapBank, NULL, m_sWorkDate);
	//m_iMsgVer =  JudgeMsgVer(pchMsg);work类里已经判断过
    
	//组报头
	if(MSG_VER_2ND == m_iMsgVer)
	{
		oCcms990.m_PMTSHeader.ParsePMTSMsgHeader(pchMsg);

		strncpy(sOrignSender, oCcms990.m_PMTSHeader.getOrigSender(), sizeof(sOrignSender)-1);
		strcpy(sOrignSendDate, oCcms990.m_PMTSHeader.getOrigSendDate());
		strcpy(sOrignMsgType, oCcms990.m_PMTSHeader.getMesgType());
		strcpy(sOrignMesgID, oCcms990.m_PMTSHeader.getMesgID());
		strcpy(sOrignRefId, oCcms990.m_PMTSHeader.getMesgRefID());

        m_ErrMsgTp = sOrignMsgType;
        
        // 当收到的是<ccms.990.001.02>报文，不需要回复
        if (strncmp(sOrignMsgType, "ccms.990.001.02", 15) == 0)
		{
            return;
		}
	        //alter in 20180201	
		oCcms990.m_PMTSHeader.SetPMTSXMlHeader(oCcms990.m_PMTSHeader.getOrigReceiverSID(),
                                  oCcms990.m_PMTSHeader.getOrigSenderSID(), 
                                  m_sWorkDate,
                                  oCcms990.m_PMTSHeader.getOrigReceiver(),
                                  "0000",
                                  "ccms.990.001.02",
                                  sMsgRefId
                                  );
		//alter end
	}
	else if(MSG_VER_1ST == m_iMsgVer)
	{
		char szCmtno[3+1]={0};
		strncpy(szCmtno, pchMsg+11, 3);
		strncpy(sOrignSender, pchMsg+18, 12);
		strncpy(sOrignReceiver, pchMsg+30, 12);
		strncpy(sOrignSendDate, pchMsg+84, 8);
		strncpy(sOrignMesgID, pchMsg+44, 20);
		strncpy(sOrignRefId, pchMsg+64, 20);

		// 当收到的是910报文，不需要回复
		if (strncmp(sOrignMsgType, "910", 3) == 0)
		{
            return;
		}
		//alter in 20180201
		oCcms990.m_PMTSHeader.SetPMTSXMlHeader(oCcms990.m_PMTSHeader.getOrigReceiverSID(),
                                  oCcms990.m_PMTSHeader.getOrigSenderSID(), 
                                  m_sWorkDate,
                                  sOrignReceiver,
                                  "0000",
                                  "ccms.990.001.02",
                                  sMsgRefId
                                  );
               //alter end
        sprintf(sOrignMsgType,"HCMT%s",szCmtno);

        m_ErrMsgTp = "CMT";
        m_ErrMsgTp =+ szCmtno;
	}
		
	oCcms990.OrigSndr					= sOrignSender;
	oCcms990.OrigSndDt					= sOrignSendDate;
	oCcms990.MT							= sOrignMsgType;
	oCcms990.MsgId 						= sOrignMesgID;
	oCcms990.MsgRefId					= sOrignRefId;
	oCcms990.MsgPrcCd					= "CU0I0000";
	
	oCcms990.CreateXml();

	int iRet = AddQueue(oCcms990.m_sXMLBuff.c_str(),  oCcms990.m_sXMLBuff.length());
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "往MQ队列发送通讯级确认报文失败！");
		PMTS_ThrowException(OPT_MQ_ADD_FAIL);
	}
	m_cMQAgent.Commit();
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvpsBase::Send990()");
}

void CRecvHvpsBase::DirectInter(LPCSTR cpSendBank,
								LPCSTR cpRecvBank, 
								LPCSTR cpRecvSapBank,  
								LPCSTR cpNpcMsg,
								LPCSTR cpIngoingDetailTable,
								LPCSTR cpPmtTpPrtry)
{
    /*Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvHvpsBase::DirectInter()");

    int iRet = RTN_FAIL;
    
    CSysmsgonlinectrl oSysmsgonlinectrl;
    
    oSysmsgonlinectrl.m_cmtno = m_strMsgTp.c_str();
    oSysmsgonlinectrl.m_sysid = "HVPS";
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "oSysmsgonlinectrl.m_cmtno[%s]",oSysmsgonlinectrl.m_cmtno.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "oSysmsgonlinectrl.m_sysid[%s]",oSysmsgonlinectrl.m_sysid.c_str());
    
    SETCTX(oSysmsgonlinectrl);
	
    iRet = oSysmsgonlinectrl.findByPK();
    if(OPERACT_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg, "oSysmsgonlinectrl findByPK fail:	[%d][%s]", 
        iRet, oSysmsgonlinectrl.GetSqlErr());
        Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(DB_GET_DATA_FAIL);
    }
    
    if("1" != oSysmsgonlinectrl.m_recvscflag)//不是直连的，直接返回
    {
        return;
    }
    
    CSyscomsendmb oSyscomsendmb;
    
    oSyscomsendmb.m_workdate = m_strWorkDate;						// 委托日期
    oSyscomsendmb.m_msgid = m_strMsgID;								// 报文标识号
    oSyscomsendmb.m_sendbank = cpSendBank;							// 发起行行号
    oSyscomsendmb.m_recvbank = cpRecvBank;							// 接收行行号
    oSyscomsendmb.m_recvsapbank = cpRecvSapBank;					// 接收清算行行号
    oSyscomsendmb.m_msgtype = m_strMsgTp;							// 报文类型
    oSyscomsendmb.m_sysflag = "HVPS";								// 系统标识
    oSyscomsendmb.m_procstate = "01";								// 处理状态 01:待处理 02：正在处理03：处理失败 04：待手工派发
    oSyscomsendmb.m_proctimes = 0;									// 处理次数
    oSyscomsendmb.m_recvtarget = "0";								// 业务来源标志 0：正常 1：手工派发
	oSyscomsendmb.m_ingoingdetailtable = cpIngoingDetailTable;		// 来账明细表名	
	if(cpPmtTpPrtry != NULL)
	{
		oSyscomsendmb.m_pmttpprtry = cpPmtTpPrtry;						// 业务类型编码
	}
	
	
	
    if(NULL != strstr(oSyscomsendmb.m_msgtype.c_str(),"CMT253"))
    {
        oSyscomsendmb.m_refnumber = m_szOrgnlMbMsgId;// 原报文行内标识号
        oSyscomsendmb.m_targetsys = m_szDisSys;// 源系统
        oSyscomsendmb.m_npcmsg = cpNpcMsg;// 人行报文
    }
    if(NULL != strstr(oSyscomsendmb.m_msgtype.c_str(),"hvps.141") 
    || NULL != strstr(oSyscomsendmb.m_msgtype.c_str(),"hvps.142") 
    || NULL != strstr(oSyscomsendmb.m_msgtype.c_str(),"CMT232"))
    {
        oSyscomsendmb.m_reserve1 = m_strCdCode;// 借贷标识
    }
    
    SETCTX(oSyscomsendmb);
    
    iRet = oSyscomsendmb.insert();
    if (OPERACT_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg, "oSyscomsendmb insert fail [%d][%s]", 
            iRet, oSyscomsendmb.GetSqlErr());
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
    }
    
    Trace(L_INFO,	__FILE__,  __LINE__, NULL, "LEAVE CRecvHvpsBase::DirectInter()");*/

}


