/********************************************************************
文件名：sendhvpsbase.cpp
创建人：handongfeng
日  期：2011.01.14
描  述：
版  本：
Copyright (c) 2009  YLINK
********************************************************************/
    
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendhvpsbase.h"
#include "sysrecvfrommb.h"

using namespace ZFPT;

extern char			g_MQmgr[256];
extern char			g_MqTxtPath[256];
extern char			g_SendQueue[128];
extern char			g_ReturnQueue[128];
extern int			g_IsConnPlatm;

CSendHvpsBase::CSendHvpsBase(const stuMsgHead& Smsg)
{
	memset(m_sErrMsg, 0x00, sizeof(m_sErrMsg));
    memset(m_szMsgFlagNO, 0x00, sizeof(m_szMsgFlagNO));
    memset(m_szMsgTypeFlag, 0x00, sizeof(m_szMsgTypeFlag));
    memset(m_szMsgType, 0x00, sizeof(m_szMsgType));
    memset(m_szSndNO, 0x00, sizeof(m_szSndNO));
    memset(m_szSysFlagNO, 0x00, sizeof(m_szSysFlagNO));
    memset(m_szConsignDate, 0x00, sizeof(m_szConsignDate));
    memset(m_szMsgSerial, 0x00, sizeof(m_szMsgSerial));
	memset(m_szOprUser, 0x00, sizeof(m_szOprUser));
	memset(m_szOprUserNetId, 0x00, sizeof(m_szOprUserNetId));
    m_strSendMsg = "";
    
    strcpy(m_szMsgFlagNO, Smsg.szMsgFlagNO);
    strcpy(m_szSysFlagNO, Smsg.szSysType);
    StrUpperCase_ZFPT(m_szSysFlagNO);
    strcpy(m_szMsgTypeFlag, Smsg.szMsgTypeFlag);
    strcpy(m_szMsgType, Smsg.szMsgType);
    strcpy(m_szSndNO, Smsg.szSndNO);
	strcpy(m_szOprUser, Smsg.szOprUser);	//操作用户 
	strcpy(m_szOprUserNetId, Smsg.szOprUserNetId);
	
    //这里要做判断:区分是行内发起还是客户端发起
    if(0 == STRNCASECMP(SP_MB_USERID,m_szOprUser,strlen(SP_MB_USERID)))
	{
		strcpy(m_szSrcflg,SRC_FRMB);
	}
	else
	{
		strcpy(m_szSrcflg,SRC_FRCLIENT);
	}
	
    m_iVersion = (strcmp(m_szMsgTypeFlag, "XML")?MSG_VER_1ST:MSG_VER_2ND);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_szMsgFlagNO= [%s]",     m_szMsgFlagNO);
    if(MSG_VER_1ST == m_iVersion)
    {
        int Offset = 0;
        OffsetCpy(m_szConsignDate, m_szMsgFlagNO, Offset, 8, true);
        OffsetCpy(m_szMsgSerial, m_szMsgFlagNO, Offset, 20, true);
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_szConsignDate[%s], m_szMsgSerial[%s]",m_szConsignDate, m_szMsgSerial);
    }
    iBaseCertSign = 1;
}

CSendHvpsBase::~CSendHvpsBase()
{
}


int CSendHvpsBase::AddSign(const char *srcSign, char *dstSign, int iFlag,const char * pSendSapbank)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvpsBase::AddSign...");
    
    int iRet = RTN_FAIL;
    
    char *Str = new char[strlen(srcSign) + 1];  
    // Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strlen(srcSign) = [%d]",strlen(srcSign));  
    
    ISNULL(Str);  
    strcpy(Str,srcSign);
    
    iRet = digitSign(m_dbproc, signTrim(Str), dstSign, SYS_HVPS, iFlag, pSendSapbank);
    
    DELPOINT(Str);
    
    if( RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "数字签名加签失败");
        PMTS_ThrowException(OPT_DIGITSIGN_FAIL);
    }
		
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvpsBase::AddSign...");
    return RTN_SUCCESS;
}

int CSendHvpsBase::AddQueue(string msgtx, int length)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvpsBase::AddQueue...");
    
	
	if( 1 == g_IsConnPlatm)   
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "已连接平台 g_IsConnPlatm = [%d]",g_IsConnPlatm);
		m_strSendMsg = "11                                        " + msgtx;  //add by xlz  加通讯报文头
		length = length +42;
	}
	else   
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "未连接平台 g_IsConnPlatm = [%d]",g_IsConnPlatm);
		m_strSendMsg =  msgtx;  
  }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "MSG Content: m_strSendMsg=[%s]  length=[%d] ,g_SendQueue = [%s]", m_strSendMsg.c_str(), length, g_SendQueue);
    int iRet = m_cMQAgent.PutMsg(g_SendQueue, m_strSendMsg.c_str(), length);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "向MQ添加数据失败");
        PMTS_ThrowException(OPT_MQ_ADD_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvpsBase::AddQueue...");
    return iRet;
}

void CSendHvpsBase::GetTag1ST(const string& QryVal, string& OutVal, const string& QryStr)
{
    string strTemp;
    GetTagVal(strTemp, QryStr, QryVal);
    OutVal = strTemp;
}

void CSendHvpsBase::GetSapBkToCCPC(DBProc &dbproc, string sSapBank, char* sCCPCCode)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvpsBase::GetSapBkToCCPC...");
    
    if(4 < sSapBank.length())
    {
        TranSapBkToCCPCCode(dbproc, sSapBank.c_str(), sCCPCCode);
    }
    else if(4 == sSapBank.length())
    {
        strcpy(sCCPCCode, sSapBank.c_str());
    }
    else if(4 > sSapBank.length())
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "参数错误");
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "参数错误");
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvpsBase::GetSapBkToCCPC...");
    return;
}

void CSendHvpsBase::InitSysParam()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvpsBase::InitSysParam()");	
    
    //获取通信id
    char sMesgId[20 + 1] = {0};
    //应该根据清算行取
    //bool bRet = GetMsgIdValue(m_dbproc, sMesgId, eRefId,  SYS_HVPS, m_szSndNO);
    bool bRet = GetMsgIdValue(m_dbproc, sMesgId, eRefId,  SYS_HVPS);
    if(false == bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "参数错误");
        PMTS_ThrowException(PRM_FAIL);
    }
    m_sMesgId   = sMesgId;
    m_sEndtoEnd = m_szMsgFlagNO;
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL,"m_sMesgId= [%s] m_sEndtoEnd=[%s]",
        m_sMesgId.c_str(), m_sEndtoEnd.c_str());
        
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvpsBase::InitSysParam()");	
}

void CSendHvpsBase::SetFieldAsGbk(const string& strVal, char* szField, int iLen)
{
    if(szField == NULL || iLen < 1 || strVal.length() < 1){
        return;
    }
    
    int iBufLen = strVal.length()+1;
    char* pBuffer = new char[iBufLen];
    if(pBuffer == NULL){
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "__Alloc Memory Failed!");
        return;
    }
    
    memset(pBuffer, 0x00, iBufLen);
    if(IsUTF8((char*)strVal.c_str(), strVal.length())){
        if(!changeEncode((char*)strVal.c_str(), pBuffer, "UTF-8", "GB18030")){
            Trace(L_ERROR, __FILE__, __LINE__, NULL, "__Encode Failed!");
        }
    }
    else{
        strncpy(pBuffer, strVal.c_str(), iBufLen-1);
    }
    
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__pBuffer=[%s]", pBuffer);
    strncpy(szField, pBuffer, iLen);
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__szField=[%s]", szField);
    delete[] pBuffer;
    pBuffer = NULL;
}


void CSendHvpsBase::SendToMB(stuSndMsg SndMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvpsBase::SendToMB...");
    int iRet;
    
    //后台发来报文处理,更新接收行内通讯表
    if (0 == strcmp(m_szSrcflg,SRC_FRMB))
    {
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "业务来自行内");
		/*string strSQL;
		CSysrecvfrommb Sysrecvfrommb;
		SETCTX(Sysrecvfrommb);
		iRet = -1;
		strSQL += "UPDATE SYS_RECVFROMMB t SET t.PROCSTATE = '";
		strSQL += strcmp(SndMsg.szErrorCode,"0000")==0?"00":"03";
		strSQL += "' WHERE t.MSGID = '";
		strSQL += m_szMsgFlagNO;
		strSQL += "' AND t.SENDBK = '";
		strSQL += m_szSndNO;
		strSQL += "'";
		
		iRet = Sysrecvfrommb.execsql(strSQL.c_str());
		Sysrecvfrommb.commit();
		if (iRet != SQL_SUCCESS)
		{
		Sysrecvfrommb.rollback();
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "Update sys_recvfrommb failed, sqlcode=[%d]", iRet);
		}*/
    }
    else
    {
          //前台发来报文处理
      int iLen = sizeof(SndMsg.szErrorCode) -1     \
                  + sizeof(SndMsg.szErrorDesc) -1;

      char *strMsg = new char[iLen + 8 + 1];
      memset(strMsg, 0x00, iLen + 8 + 1);
      sprintf(strMsg,"%08d%04s%-60s", iLen, SndMsg.szErrorCode, SndMsg.szErrorDesc);

      STRING sMsgid = MbBinToHex((unsigned char*)m_MQMsgId,24);
      
      Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sMsgid=[%s] strMsg=[%s]", sMsgid.c_str(),strMsg);

      iRet = m_cMQAgent.PutMsg(g_ReturnQueue, strMsg, iLen, NULL, m_MQMsgId);
      if(iRet != RTN_SUCCESS)
      {
          Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "向MQ添加数据失败");

          DELPOINT(strMsg);

          PMTS_ThrowException(OPT_MQ_ADD_FAIL);
      }
      DELPOINT(strMsg);
      m_cMQAgent.Commit();
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvpsBase::SendToMB...");  
}

int CSendHvpsBase::doWork()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvpsBase::doWork()");	
    
	int iRet = 0;
    try
    {
    	//获取MQ连接
        GetMqConn();
		
    	//获取数据库连接
        GetDBConnect();
		
		//初始化系统参数
    	InitSysParam();
    	
        //子业务入口
        iRet = doWorkSelf();
        if(RTN_SUCCESS == iRet)
        {
            SETCTX(m_entitybase);
            m_entitybase.commit();
            m_cMQAgent.Commit();
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_entitybase commit success!");	
        }
        else
        {
            SETCTX(m_entitybase);
            m_entitybase.rollback();
    		m_cMQAgent.RollBack();
            Trace(L_ERROR, __FILE__, __LINE__, NULL, "子业务处理失败!iRet = [%d]",iRet);
        }

    }
    catch(CException &e)
    {        
        Trace(L_ERROR, __FILE__, __LINE__, "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());
		m_cMQAgent.RollBack();
		INT_SETCTX(m_entitybase);
		m_entitybase.rollback();

		iRet = e.code();
    }
    catch(...)
    {   
        Trace(L_ERROR, __FILE__, __LINE__, NULL,"Catch an unkown exception ");
		m_cMQAgent.RollBack();
		INT_SETCTX(m_entitybase);
		m_entitybase.rollback();

		iRet = OTH_ERR;
    }
    
	stuSndMsg SndMsg;
    memset(&SndMsg, 0x00, sizeof(SndMsg));
    sprintf(SndMsg.szErrorCode, "%04d", iRet);
    GetErrDsc(iRet, SndMsg.szErrorDesc);
    
    SendToMB(SndMsg);
        
	//释放连接
    g_DBConnPool->PutConnect(m_dbproc);	
        
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvpsBase::doWork()");	
    return iRet;
}


void CSendHvpsBase::GetDBConnect(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendHvpsBase::GetDBConnect()");	

    if(0 != g_DBConnPool->GetConnect(m_dbproc))
    {
        snprintf(m_sErrMsg, sizeof(m_sErrMsg), 
			"CRecvBepsBase::GetDBConnect():获取数据库连接失败");
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, m_sErrMsg);
    }

	m_charge.m_dbproc = m_dbproc;	//初始化记账类
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendHvpsBase::GetDBConnect()");		
}

void CSendHvpsBase::GetMqConn(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendHvpsBase::GetMqConn()");	
	
	 //初始化MQ
    if(0 != m_cMQAgent.Init(g_MQmgr, g_MqTxtPath))
    {
    	snprintf(m_sErrMsg, sizeof(m_sErrMsg), 
			"CSendHvpsBase::GetMqConn(),Init Thread MQ manager failed.");
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
        PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_MQ_CNNCT_FAIL, m_sErrMsg);
    }
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendHvpsBase::GetMqConn()");		
}

