/******************************************************************** 
�ļ����� sendhvps634.cpp
�����ˣ� xiaocuiming
��  �ڣ� 2011-05-25
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
    
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendhvps634.h"

CSendHvps634::CSendHvps634(const stuMsgHead & Smsg):CSendHvpsBase(Smsg)
{

}

CSendHvps634::~CSendHvps634()
{

}

int CSendHvps634::GetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendHvps634::GetData...");

    if(0 != m_CHvmnetstlmcxl.setctx(m_dbproc))
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "���ݱ�HV_MNETSTLMCXL����ʧ��");
        PMTS_ThrowException(DB_CNNCT_FAIL);
    }

    //string whereClause = " ";

    
    //whereClause = "MSGID = '" + m_szMsgFlagNO;
    //whereClause += "' and INSTGDRCTPTY = '" + m_szSndNO;
    //whereClause += "'";

    char whereClause[1024];
    sprintf(whereClause, "MSGID = '%s' and INSTGINDRCTPTY = '%s'", m_szMsgFlagNO, m_szSndNO);
    Trace(L_INFO, __FILE__, __LINE__, NULL, "WhereValue = [%s]", whereClause);

    if(SQL_SUCCESS != m_CHvmnetstlmcxl.find(whereClause))
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "���ݱ�HV_MNETSTLMCXL findδ�ҵ���¼");
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    if(SQL_SUCCESS != m_CHvmnetstlmcxl.fetch())
    {
        Trace(L_INFO, __FILE__, __LINE__, NULL, "���ݱ�HV_MNETSTLMCXL fetch �������ʧ��");
        PMTS_ThrowException(DB_GET_DATA_FAIL);
    }

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendHvps634::GetData...");

    return RTN_SUCCESS;
    
}

void CSendHvps634::SetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendHvps634::SetData...");

    m_hvps634.MsgId = m_CHvmnetstlmcxl.m_msgid;
    int iRet = GetIsoDateTime(m_dbproc, SYS_HVPS, m_ISODateTime);

    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "Get Datatime fail");
        PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }

    m_hvps634.CreDtTm = m_ISODateTime;
    m_hvps634.InstgDrctPty = m_CHvmnetstlmcxl.m_instgdrctpty;
    m_hvps634.GrpHdrInstgPty = m_CHvmnetstlmcxl.m_instgindrctpty;
    m_hvps634.InstdDrctPty = m_CHvmnetstlmcxl.m_instddrctpty;
    m_hvps634.GrpHdrInstdPty = m_CHvmnetstlmcxl.m_instdindrctpty;
    m_hvps634.SysCd = "HVPS";
    m_hvps634.Rmk = m_CHvmnetstlmcxl.m_remark;
    m_hvps634.OrgnlMsgId = m_CHvmnetstlmcxl.m_orgnlmsgid;
    m_hvps634.OrgnlInstgPty = m_CHvmnetstlmcxl.m_orgnlinstgpty;
    m_hvps634.OrgnlMT = m_CHvmnetstlmcxl.m_orgnlmt;

    ////////////////////////////////////
    
    m_hvps634.Nb = "1"; //����������֪����������,���Ҹ�ֵ"1"

    /////////////////////////////////////

    m_hvps634.Id = m_CHvmnetstlmcxl.m_dtlsid;

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendHvps634::SetData...");
    

}

void CSendHvps634::AddSign634()
{
	Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendHvps634::AddSign634...");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_hvps634.getOriSignStr();
	
	AddSign(m_hvps634.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_hvps634.InstgDrctPty.c_str());
	
	m_hvps634.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendHvps634::AddSign634...");
}

int CSendHvps634::UpdateState()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendHvps634::UpdateState...");

    if(SQL_SUCCESS != m_CHvmnetstlmcxl.setctx(m_dbproc))
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "���ݱ�HV_MNETSTLMCXL ����ʧ��");
        PMTS_ThrowException(DB_CNNCT_FAIL);
    }

    STRING strSql;

    strSql += "UPDATE hv_mnetstlmcxl t SET t.PROCSTATE = '09' WHERE t.MSGID = '";
    strSql += m_CHvmnetstlmcxl.m_msgid + "'";
    strSql += "and t.INSTGINDRCTPTY = '";
    strSql += m_CHvmnetstlmcxl.m_instgindrctpty + "'";

    Trace(L_INFO, __FILE__, __LINE__, NULL, "strSql = [%s]", strSql.c_str());

    int iRet = m_CHvmnetstlmcxl.execsql(strSql);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "�޸�hv_mnetstlmcxl״̬ʧ��iRet = %d, %s", iRet, m_CHvmnetstlmcxl.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendHvps634::UpdateState...");
    return iRet;
    

}
int CSendHvps634::doWorkSelf()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendHvps634::doWorkSelf...");
    int iRet = 0;
    
    GetData();

    SetData();

    
    if(2 == m_iVersion)
    {
        AddSign634();
    }

    iRet = m_hvps634.CreateXml();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }

    UpdateState();

    AddQueue(m_hvps634.m_sXMLBuff.c_str(), m_hvps634.m_sXMLBuff.length());

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendHvps634::doWorkSelf...");

    return RTN_SUCCESS;
    
    
}

