/******************************************************************** 
�ļ����� sendcmt101.cpp
�����ˣ� aps-xcm
��  �ڣ� 2011-06-21
�޸��ˣ� 
��  �ڣ� 
��  ���� һ���������ί���տ���أ�֧������
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt101.h"

CSendCmt101::CSendCmt101(const stuMsgHead& Smsg):CSendHvpsBase(Smsg)
{
   
}

CSendCmt101::~CSendCmt101()
{
    
}

void CSendCmt101::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt101::SetDBKey...");

    m_Hvsndlist.m_msgtp = "CMT";
    m_Hvsndlist.m_msgtp = m_Hvsndlist.m_msgtp + m_szMsgType;
    
	m_Hvsndlist.m_msgid = m_szMsgFlagNO; 
	m_Hvsndlist.m_instgindrctpty = m_szSndNO; 

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_msgtp = %s", m_Hvsndlist.m_msgtp.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_msgid = %s", m_Hvsndlist.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_instgindrctpty = %s", m_Hvsndlist.m_instgindrctpty.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt101::SetDBKey...");
    
}

int CSendCmt101::GetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt101::GetData...");

    SETCTX(m_Hvsndlist);
    SetDBKey();
    int iRet = m_Hvsndlist.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ȡ����ʧ�ܣ� iRet = [%d]", iRet);
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    //if(!m_Hvsndlist.m_endtoendid.empty())
    //{
        //m_sEndtoEnd = m_Hvsndlist.m_endtoendid;
        //Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sEndtoEnd = %s", m_sEndtoEnd.c_str());
    //}
    Trace(L_INFO, __FILE__, __LINE__, NULL, " m_Hvsndlist.m_msgid.c_str()=%s", m_Hvsndlist.m_msgid.c_str());
    Trace(L_INFO, __FILE__, __LINE__, NULL, " m_Hvsndlist.m_mesgid.c_str()=%s", m_Hvsndlist.m_mesgid.c_str());
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt101::GetData...");
    return iRet;
}


void CSendCmt101::SetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt101::SetData...");

    strncpy(m_cCmt101.sConsigndate, m_Hvsndlist.m_consigndate.c_str(), sizeof(m_cCmt101.sConsigndate) - 1);
    m_cCmt101.iTxssno = atoi(m_szMsgSerial);
    
    strncpy(m_cCmt101.sCur, m_Hvsndlist.m_currency.c_str(), sizeof(m_cCmt101.sCur) - 1);
    m_cCmt101.dAmount = m_Hvsndlist.m_amount;
    strncpy(m_cCmt101.sSendsapbk, m_Hvsndlist.m_dbtmmbid.c_str(), sizeof(m_cCmt101.sSendsapbk) - 1);
    strncpy(m_cCmt101.sSendbank, m_Hvsndlist.m_dbtid.c_str(), sizeof(m_cCmt101.sSendbank) - 1);
    strncpy(m_cCmt101.sPayopenbk, m_Hvsndlist.m_dbtrissr.c_str(), sizeof(m_cCmt101.sPayopenbk) - 1);
    strncpy(m_cCmt101.sPayeracc, m_Hvsndlist.m_dbtracctid.c_str(), sizeof(m_cCmt101.sPayeracc) - 1);
    
   
    strncpy(m_cCmt101.sRecvsapbk, m_Hvsndlist.m_cdtmmbid.c_str(), sizeof(m_cCmt101.sRecvsapbk) - 1);
    strncpy(m_cCmt101.sRecvbank, m_Hvsndlist.m_cdtid.c_str(), sizeof(m_cCmt101.sRecvbank) - 1);
    strncpy(m_cCmt101.sPayeeopenbk, m_Hvsndlist.m_cdtrissr.c_str(), sizeof(m_cCmt101.sPayeeopenbk) - 1);
    strncpy(m_cCmt101.sPayeeacc, m_Hvsndlist.m_cdtracctid.c_str(), sizeof(m_cCmt101.sPayeeacc) - 1);
    
    
    char SndCCPCNode[4 + 1] 	= {0};	
	char RcvCCPCNode[4 + 1] 	= {0};
    GetSapBkToCCPC(m_dbproc, m_Hvsndlist.m_instgdrctpty, SndCCPCNode);
	GetSapBkToCCPC(m_dbproc, m_Hvsndlist.m_instddrctpty, RcvCCPCNode);
	strncpy(m_cCmt101.sSendsenter, SndCCPCNode, sizeof(m_cCmt101.sSendsenter) - 1);
	strncpy(m_cCmt101.sRecvsenter, RcvCCPCNode, sizeof(m_cCmt101.sRecvsenter) - 1);
	/*
	strncpy(m_cCmt101.sPayeename, m_Hvsndlist.m_cdtrnm.c_str(), sizeof(m_cCmt101.sPayeename) - 1);
    strncpy(m_cCmt101.sPayername, m_Hvsndlist.m_dbtnm.c_str(), sizeof(m_cCmt101.sPayername) - 1);
    strncpy(m_cCmt101.sRemark, m_Hvsndlist.m_addinfo.c_str(), sizeof(m_cCmt101.sRemark) - 1);
    */
    
    SetFieldAsGbk(m_Hvsndlist.m_addinfo, m_cCmt101.sRemark, sizeof(m_cCmt101.sRemark)-1);
    SetFieldAsGbk(m_Hvsndlist.m_dbtnm, m_cCmt101.sPayername, sizeof(m_cCmt101.sPayername)-1);
    SetFieldAsGbk(m_Hvsndlist.m_cdtrnm, m_cCmt101.sPayeename, sizeof(m_cCmt101.sPayeename)-1);
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "m_Hvsndlist.m_ustrdstr[%s]", m_Hvsndlist.m_ustrdstr.c_str());
    string strTemp = "";
    GetTag1ST("30B:", strTemp,  m_Hvsndlist.m_ustrdstr);
    snprintf(m_cCmt101.sBilldate, sizeof(m_cCmt101.sBilldate), strTemp.c_str());

    strTemp = "";
    GetTag1ST("21A:", strTemp,  m_Hvsndlist.m_ustrdstr);
    snprintf(m_cCmt101.sBillno, sizeof(m_cCmt101.sBillno), strTemp.c_str());

    strTemp = "";
    GetTag1ST("CEJ:", strTemp,  m_Hvsndlist.m_ustrdstr);
    snprintf(m_cCmt101.sWarranttype, sizeof(m_cCmt101.sWarranttype), strTemp.c_str());

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt101::SetData...");
}

int CSendCmt101::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt101::buildCmtMsg...");

    int iRet = m_cCmt101.CreateCmt("101", m_Hvsndlist.m_instgdrctpty.c_str(), m_Hvsndlist.m_instddrctpty.c_str(), m_sMesgId.c_str(), m_sMesgId.c_str(), m_Hvsndlist.m_workdate.c_str(), m_Hvsndlist.m_sttlmprty.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt101::buildCmtMsg...");
    return iRet;
}
int CSendCmt101::UpdateState()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt101::UpdateState...");

    SETCTX(m_Hvsndlist);
    string strSQL;

    string strNpcMsg = "";
	if(!m_Hvsndlist.write_blob(m_cCmt101.m_strCmtmsg.c_str(), strNpcMsg, SYS_HVPS)){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"д���ֶα�����:[%s]", m_Hvsndlist.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}

    strSQL += "UPDATE hv_sndexchglist t SET t.STATETIME = sysdate, t.PROCSTATE = '";
    strSQL += m_szProState;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
	strSQL += "', t.endtoendid = '";
	strSQL += m_sEndtoEnd;
	strSQL += "', t.npcmsg='";
	strSQL += strNpcMsg;
	strSQL += "' WHERE t.MSGTP = '";
	strSQL += m_Hvsndlist.m_msgtp.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_Hvsndlist.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Hvsndlist.m_instgindrctpty.c_str(); 									
	strSQL += "'";
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "strSQL=[%s]", strSQL.c_str());
    int iRet = RTN_FAIL;
    Trace(L_DEBUG, __FILE__, __LINE__, NULL,"befor execsql iRet= [%d]", iRet);
    iRet = m_Hvsndlist.execsql(strSQL);
    Trace(L_DEBUG, __FILE__, __LINE__, NULL,"after execsql iRet= [%d]", iRet);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��iRet=[%d], [%s]", iRet, m_Hvsndlist.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
        
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt101::UpdateState...");
    return iRet;
    
    
}


int CSendCmt101::doWorkSelf()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt101::dowork...");
    //1)�������
    GetData();

    //2)��ֵ
    SetData();

    AddMac();
    
    buildCmtMsg();
    
    //3)	ҵ���飨�ͻ������룩
    //.......
    //4)	���������ͻ������룩
    
    strcpy(m_szProState,PR_HVBP_08);//���ҵ��û���Ŷӣ�����״̬����08�ѷ���
    
    FundSettle();

    UpdateState();
    
    if(strcmp(m_szProState, PR_HVBP_08) == 0)//�������״̬Ϊ�ѷ��ͣ�����Խ�����дMQ
    {
    	AddQueue(m_cCmt101.m_strCmtmsg, m_cCmt101.m_strCmtmsg.length());
    }

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt101::dowork...");
    return RTN_SUCCESS;
    
}

int CSendCmt101::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt101::FundSettle...");
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û�[%s]", m_szOprUser);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_cCmt101.sSendbank);

	m_charge.m_amount = m_cCmt101.dAmount;	//ҵ����
	m_charge.m_iDCFlag = iDEBITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, MBVIRSUALNETID);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_cCmt101.sSendbank);	//������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(iRet == 1)//���ö�Ȳ��㣬ҵ���Ŷ�
	{
		strcpy(m_szProState,PR_HVBP_55); //ҵ���Ŷ�
		iRet = m_charge.IntoPurpList(m_szOprUserNetId,m_Hvsndlist.m_workdate.c_str(),m_Hvsndlist.m_amount,m_Hvsndlist.m_msgid.c_str(),m_Hvsndlist.m_instgindrctpty.c_str(),m_Hvsndlist.m_msgtp.c_str(),"HVPS");
		if(iRet != RTN_SUCCESS)
		{
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�۳������ʽ�ʧ�ܣ�iRet=%d", iRet);
			PMTS_ThrowException(DB_INSERT_FAIL);
		}

		//�ͻ���Ϣ֪ͨ��ҵ���Ŷ�
		InsertUserInfoTel(m_Hvsndlist.m_msgid.c_str(),
			      m_Hvsndlist.m_instgindrctpty.c_str(),
			      m_Hvsndlist.m_instgdrctpty.c_str(),
			      m_Hvsndlist.m_instdindrctpty.c_str(),       
			      m_Hvsndlist.m_instddrctpty.c_str(),       						      
			      "HVPS",
			      m_Hvsndlist.m_msgtp.c_str(),
				  NT_CMIPUR,
				  " ");
	}
	else if(iRet == 2)//���ö�Ȳ��㣬ҵ����Ҫ�Ŷӣ�Ԥ��֪ͨ�ͻ�
	{
		InsertUserInfoTel(m_Hvsndlist.m_msgid.c_str(),
			      m_Hvsndlist.m_instgindrctpty.c_str(),
			      m_Hvsndlist.m_instgdrctpty.c_str(),
			      m_Hvsndlist.m_instdindrctpty.c_str(),       
			      m_Hvsndlist.m_instddrctpty.c_str(),       						      
			      "HVPS",
			      m_Hvsndlist.m_msgtp.c_str(),
				  NT_CMIQUE,
				  " ");
	}
	else if(iRet == -1)        
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�۳������ʽ�ʧ�ܣ�iRet=%d", iRet);
		PMTS_ThrowException(DATA_FAIL);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt101::FundSettle..."); 
    
    return RTN_SUCCESS;
}

int CSendCmt101::AddMac()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt101::AddMac...");
	int iRet = -1;
	
	m_cCmt101.SetSeal();//��ȡ��Ѻ��

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt101.sSendsapbk[%s]",m_cCmt101.sSendsapbk);
	
    iRet = CodeMac(m_dbproc,m_cCmt101.m_Seal.c_str(),m_cCmt101.sSendsapbk,m_cCmt101.m_szMacStr);
    if(0 != iRet)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "AddMac failed");
    	PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]",m_cCmt101.m_szMacStr);
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt101::AddMac..."); 
    
    return RTN_SUCCESS;
}
