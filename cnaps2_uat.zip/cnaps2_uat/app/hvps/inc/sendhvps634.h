/******************************************************************** 
�ļ����� sendhvps634.h
�����ˣ� xiaocuiming
��  �ڣ� 2011-05-25
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __SENDHVPS634_H__
#define __SENDHVPS634_H__

#include "sendhvpsbase.h"
#include "hvps634.h"
#include "hvmnetstlmcxl.h"


class CSendHvps634 : public CSendHvpsBase
{
public:
    CSendHvps634(const stuMsgHead& Smsg);
    ~CSendHvps634();
    int doWorkSelf();
private:
    void AddSign634();
    void SetData();
    int GetData();
    int UpdateState();
public:
    
private:
    
    CHvmnetstlmcxl m_CHvmnetstlmcxl;
    hvps634 m_hvps634;
};

#endif



