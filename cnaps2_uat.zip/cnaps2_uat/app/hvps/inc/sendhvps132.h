/******************************************************************** 
文件名： send132.h
创建人： luoyutian
日  期： 2017-03-22
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __SENDHVPS132_H__
#define __SENDHVPS132_H__

#include "sendhvpsbase.h"
#include "hvps132.h"
#include "hvtrofacrcvlist.h"
//#include "hvimmedaacctautorsp.h"

class CSendHvps132 : public CSendHvpsBase
{
public:
	CSendHvps132(const stuMsgHead& Smsg);
	~CSendHvps132();
	int doWorkSelf();
private:
	void AddSign132();
	void SetData();
	int GetData();
	int UpdateState();
	
private:
	std::string m_rspway;
	CHvtrofacrcvlist m_cHvtrofacrcvlist;
	hvps132 m_hvps132;
	char m_szErrMsg[1024];
};

#endif


