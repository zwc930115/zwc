/********************************************************************
文件名：sendhvpswork.h
创建人：handongfeng
日  期：2011.01.14
描  述：
版  本：
Copyright (c) 2009  YLINK
********************************************************************/
#ifndef __SENDHVPSWORK_H__
#define __SENDHVPSWORK_H__

#include "basicapi.h"
#include "pubfunc.h"
#include "logger.h"
using namespace ZFPT;

class CSendHvpsWork
{
public:
    CSendHvpsWork();
    CSendHvpsWork(const CSendHvpsWork &e);

    ~CSendHvpsWork();

    void UnpackMsgHead(const char* strMsg);
	
	void clear();
	
    INT32 doWork();

    CSendHvpsWork& operator=(const CSendHvpsWork & e)
    {
        if(this != &e)
        {
            m_sTrsCode = e.m_sTrsCode;
            memcpy(m_MQMsgId , e.m_MQMsgId, sizeof(e.m_MQMsgId));        
            memcpy(&m_MsgHead, &e.m_MsgHead, sizeof(e.m_MsgHead));
        }
        return *this;
    }

    char m_MQMsgId[64];
private:
    
    //在这里添加成员的时候记得在操作符重载函数和构造函数里也添加!
    
    string m_sTrsCode;
    
    stuMsgHead m_MsgHead;
    
};

#endif

