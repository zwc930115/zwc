/******************************************************************** 
�ļ����� sendhvps153.h
�����ˣ� handongfeng
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __SENDHVPS153_H__
#define __SENDHVPS153_H__

#include "sendhvpsbase.h"
#include "hvps153.h"
#include "hvdraft.h"

class CSendHvps153 : public CSendHvpsBase
{
public:
    CSendHvps153(const stuMsgHead& Smsg);
    ~CSendHvps153();
    int doWorkSelf();
private:
    void AddSign153();
    void SetData();
    int GetData();
    int UpdateState();
    void GetTag2ND(const string& QryVal, const string& QryStr, int& iDepth);
    void SetDBKey();
public:

private:
    CHvdraft	m_cHvdraft;
    hvps153 m_cParser153;
};

#endif




