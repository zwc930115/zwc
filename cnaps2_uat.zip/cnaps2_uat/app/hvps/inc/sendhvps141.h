/******************************************************************** 
�ļ����� send141.h
�����ˣ� handongfeng
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __SENDHVPS141_H__
#define __SENDHVPS141_H__

#include "sendhvpsbase.h"
#include "hvps141.h"
#include "hvtrofacsndlist.h"

class CSendHvps141 : public CSendHvpsBase
{
public:
	CSendHvps141(const stuMsgHead& Smsg);
	~CSendHvps141();
	int doWorkSelf();
private:
	void AddSign141();
	void SetData();
	int GetData();
	int ChargeMB();
	int FundSettle();
	int UpdateState();
	void GetTag2ND(const string& QryVal, const string& QryStr, int& iDepth);
	void SetDBKey();
	
private:
	CHvtrofacsndlist m_Hvtrofacsndlist;
	hvps141 m_cParser141;
	string m_Sign;
	
	
};

#endif



