/******************************************************************** 
�ļ����� send112.h
�����ˣ� handongfeng
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __SENDHVPS112_H__
#define __SENDHVPS112_H__

#include "sendhvpsbase.h"
#include "hvps112.h"
#include "hvsndexchglist.h"

class CSendHvps112 : public CSendHvpsBase
{
public:
	CSendHvps112(const stuMsgHead& Smsg);
	~CSendHvps112();
	int doWorkSelf();
private:
	void AddSign112();
	string GetTag2ND(const string& QryVal, const string& QryStr, int& iDepth);
	void SetData();
	int GetData();
	int ChargeMB();
	int FundSettle();
	int UpdateState();
	void SetDBKey();
	
	
private:
	CHvsndexchglist m_Hvsndlist;
	hvps112 m_cParser112;
	
};

#endif


