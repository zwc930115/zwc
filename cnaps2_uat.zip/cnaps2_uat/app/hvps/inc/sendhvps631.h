/******************************************************************** 
�ļ����� sendhvps631.h
�����ˣ� xiaocuiming
��  �ڣ� 2011-05-17
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __SENDHVPS631_H__
#define __SENDHVPS631_H__

#include "sendhvpsbase.h"
#include "hvps631.h"
#include "hvmnetstlcl.h"
#include "hvmnetstllist.h"
#include "hvmnetstlcumlist.h"

class CSendHvps631 : public CSendHvpsBase
{
public:
    CSendHvps631(const stuMsgHead& Smsg);
    ~CSendHvps631();
    int doWorkSelf();
private:
    void AddSign631();
    void SetData();
    int GetData();
    int UpdateState();
    void SetDBKey();
public:

private:
    
    CHvmnetstlcl m_CHvmnetstlcl;
    CHvmnetstllist m_CHvmnetstllist;
    CHvmnetstlcumlist m_CHvmnetstlcumlist;
    hvps631 m_hvps631 ;
    
};

#endif



