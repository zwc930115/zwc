/******************************************************************** 
文件名： hvpsckecksum.h
创建人： hq
日  期： 2011-05-11
修改人： 
日  期： 
描  述： 大额汇总对账类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef _HVPSCHECKSUM_H_
#define _HVPSCHECKSUM_H_

#include <vector>
#include "basic.h"
#include "connectpool.h"
#include "hvcheckcl.h"
#include "checkaccount.h"
#include "hvps712.h"
#include "mqagent.h"
#include "pubfunc.h"

class CHvpsCheckSum
{
public:
    
    CHvpsCheckSum();
    ~CHvpsCheckSum();

    void doCheckSumWork(DBProc &dbProc,
                        int iChkTp, 
                        LPCSTR sChkDt, 
                        LPCSTR sBankCode, 
                        MQAgent &cMQAgent, 
                        LPCSTR sSendQueue);

public:

    void AddDetail(LPCSTR sSndRcvTp);
    
    int    m_iTtlCnt;      //对账不符的数目
    int    m_iLocalMore;   //本地多的数目(不用下载明细)
    STRING m_szMT;         //报文编号
    STRING m_szTxTpCd;     //业务类型编码
    STRING m_szPrcSts;     //处理状态
    STRING m_szChkDt;      //对账日期
    STRING m_szBkCode;     //清算行号
    STRING m_szCcy;        //币种

    vector<stCheckSum> VCheckArray;
    
private:

    void SetAllCtx();
    void CountLocalInfo();
    void UpdateCheckCl(LPCSTR sTableNm);
    void UpdateSts();
    void updateBkChkSt();
    void DeleteCheckList();
    void SndToNpcFor712(MQAgent &cMQAgent, LPCSTR sSendQueue);

    hvps712       m_hvps712;
    CHvcheckcl    m_hvcheckcl;
    CCheckAccount m_checkaccount;

    DBProc m_dbproc;
};

#endif


