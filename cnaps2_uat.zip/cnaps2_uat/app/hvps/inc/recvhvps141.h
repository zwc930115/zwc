#ifndef _RECVHVPS141_H_
#define _RECVHVPS141_H_

#include "recvhvpsbase.h"
#include "hvps141.h"
#include "hvtrofacrcvlist.h"


class CRecvHvps141 : public CRecvHvpsBase
{
	
public:
	CRecvHvps141();
	~CRecvHvps141();
	
	// ҵ����ں���
	INT32 Work(LPCSTR sMsg);
	
	// �������Ĵ�
	INT32 unPack(LPCSTR sMsg);
	
	// ʵ���ำֵ
	INT32 SetData(LPCSTR pchMsg);
	
	// �������ݿ�
	INT32 InsertData(void);
	
	// ��ǩ
	void  CheckSign141();
	
	int ChargeMB();
private:
	hvps141          m_cParser141;
	string           m_strSignSub;
	CHvtrofacrcvlist m_cHvtrofacrcvlist; 
};

#endif

