#!/bin/sh
# create and modified by 高卓 
cat PreconditionInfo.txt | tr -d '\015' > PreconditionInfo1.txt
cat MediumInfo.txt | tr -d '\015' > MediumInfo1.txt
cat PackageDescription.txt | tr -d '\015' > PackageDescription1.txt
cat ConfigInfo.txt | tr -d '\015' > ConfigInfo1.txt

echo "==============================================================================="
echo "   PAMT安装程序开始调用卸载前运行脚本                                          "
echo "   卸载前运行脚本是确保正确卸载而进行的操作，如停CICS，MQ等                    "
echo "==============================================================================="
echo


#在前置条件PreconditionInfo文档中，提供了卸载前及卸载后脚本的名称
PREUNINSTALLNAMESTR=`grep PreUninstallName ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`
INSTRUCTIONSTR=`grep -w Instruction ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`
PREUNINSTALLNUMBER=`grep PreUninstallNum ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`

if [ -n "$PREUNINSTALLNUMBER" ]
then
  PREUNINSTALLNUM=`echo ${PREUNINSTALLNUMBER}|tr -cs "[0-9]" " "`
  #echo "$PREUNINSTALLNUM"
  VAR1=1
  #echo "$VAR1"
  while [[ ${VAR1} -le ${PREUNINSTALLNUM} ]]
    do
       PREUNINSTALLNAME=`echo ${PREUNINSTALLNAMESTR}|awk -F";" '{print $(VAR1)}' VAR1="$VAR1"`
       echo "执行脚本${PREUNINSTALLNAME}"
       ./${PREUNINSTALLNAME}
        VAR1=`expr ${VAR1} + 1`	
      #  echo "$VAR1"
    done
else
  echo "--本次安装没有集成卸载前运行脚本--"
fi


echo "==============================================================================="
echo "  PAMT安装程序开始进行系统恢复!                                                "
echo "  系统恢复是将产品恢复至此安装包的上一版本的操作                               "
echo "==============================================================================="


#产品短名称
SHORTPRODUCTNAME=`grep ProductName ./ConfigInfo1.txt|awk -F"=" '{print $2}'`

FILEBACKUPNAME=`grep FileName ./PackageDescription1.txt|awk -F"=" '{print $2}'`
PAMTFULLNAME=`grep ProductName ./PackageDescription1.txt | awk -F"=" '{print $2}'`


#备份路径从环境变量中去取
#BACKPATH=`grep BackupPath ./PackageDescription1.txt|awk -F"=" '{print $2}'`


#echo "备份路径是$BACKPATH"
#PRODUCTNAME=`grep BackPath ./PackageDescription1.txt|awk -F"=" '{print $2}'`

#现在不需要了
#PRODUCTNAME=`echo "$BACKPATHWITHSPACE|tr -d " "`
#restorefile=`ls`

PAMTFILEPATHSTR=`grep -w Path ./MediumInfo1.txt|awk -F"=" '{print $2}'`
PAMTFILENAMESTR=`grep MaintanceFileName ./MediumInfo1.txt|awk -F"=" '{print $2}'`
PAMTFILENUMBER=`grep MaintanceFileNum ./MediumInfo1.txt|awk -F"=" '{print $2}'`

#在MediumInfo.txt信息文件中，新增标识位，用来区别文件及文件夹，20110901
#文件夹为1，文件为0

PAMTFILEFLAGSTR=`grep FileFlag ./MediumInfo1.txt|awk -F"=" '{print $2}'`
PAMTFILEPROPERTYSTR=`grep Property ./MediumInfo1.txt|awk -F"=" '{print $2}'`

#PAT1=`echo ${PAMTFILEPATH1}|awk -F";" '{print $2}'`

PAMTFILENUMBER=`echo $PAMTFILENUMBER|tr -cs "[0-9]" " "`
while [[ ${PAMTFILENUMBER} -ne  0 ]]
  do
		PAMTFILENAME=`echo ${PAMTFILENAMESTR}|awk -F";" '{print $(PAMTFILENUMBER)}' PAMTFILENUMBER="$PAMTFILENUMBER" `
		PAMTFILEPATH=`echo ${PAMTFILEPATHSTR}|awk -F" " '{print $(PAMTFILENUMBER)}' PAMTFILENUMBER="$PAMTFILENUMBER" `
		PAMTFILEPROPERTY=`echo ${PAMTFILEPROPERTYSTR}|awk -F" " '{print $(PAMTFILENUMBER)}' PAMTFILENUMBER="$PAMTFILENUMBER" `
    PAMTFILEFLAG=`echo ${PAMTFILEFLAGSTR}|awk -F" " '{print $(PAMTFILENUMBER)}' PAMTFILENUMBER="$PAMTFILENUMBER" `
		PAMTFILENUMBER=`expr ${PAMTFILENUMBER} - 1`	
		if [[ ${PAMTFILEFLAG} == "0" ]]
    then 
#		  echo "PAMTFILEPROPERTY  is ${PAMTFILEPROPERTY}"
				if [[ ${PAMTFILEPROPERTY} == "Replace" ]]
		  then		  
#		    cp -p ${BACKPATH}${PAMTFULLNAME}/${PAMTFILENAME} ${PAMTFILEPATH}
#      echo "cp -p ${PAMTBACKUP}/${PAMTFULLNAME}${PAMTFILEPATH}/${PAMTFILENAME} ${PAMTFILEPATH}/"
        cp -p ${PAMTBACKUP}/${PAMTFULLNAME}${PAMTFILEPATH}/${PAMTFILENAME} ${PAMTFILEPATH}/
        echo "--恢复文件${PAMTFILENAME}成功--"
#		    echo ${PAMTFILENUMBER}
		  else 
		    echo "--文件${PAMTFILENAME}为安装时新增,无需恢复"
		    fi	
		else
		:;
		fi	
done


#恢复版本信息
#echo "************文件恢复完毕，下面开恢复本地配置文件中的版本信息******"
#增加下一行语句是预防在第一次使用install.bin，并卸载时，本地文件信息被创建而无法被删除
if [ -f "../LocalMediumInfo.txt" ]
then
  PRELOCALNAME=`grep $SHORTPRODUCTNAME ../LocalMediumInfo.txt|awk -F"=" '{print $2}'`
  POSTLOCALNAME=`grep $SHORTPRODUCTNAME ${PAMTBACKUP}/LocalMediumInfo.txt|awk -F"=" '{print $2}'`
# 如果备份的本地版本文件中没有包含有此产品的版本信息，则PRELOCALNAME值应该为空
  if [ -n "$PRELOCALNAME" ]
  then
    sed -e "s/"$POSTLOCALNAME"/"$PRELOCALNAME"/"  ${PAMTBACKUP}/LocalMediumInfo.txt >${PAMTBACKUP}/LocalMediumInfo.txt.tmp
    mv ${PAMTBACKUP}/LocalMediumInfo.txt.tmp ${PAMTBACKUP}/LocalMediumInfo.txt
  else
    PRODUCTNUM=`grep -w Product ${PAMTBACKUP}/LocalMediumInfo.txt|awk -F"=" '{print $2}'`
    PROFULLPRODUCT=`grep -w Product ${PAMTBACKUP}/LocalMediumInfo.txt`
    PRODUCTNUM=`echo ${PRODUCTNUM}|tr -cs "[0-9]" " "`
    #产品编号减一
    NEWPRODUCTNUM=`expr ${PRODUCTNUM} - 1`
    NEWFULLPRODUCT="Product=${NEWPRODUCTNUM}"
    sed -e "s/"$PROFULLPRODUCT"/"$NEWFULLPRODUCT"/"  ${PAMTBACKUP}/LocalMediumInfo.txt >${PAMTBACKUP}/LocalMediumInfo.txt.tmp
    mv ${PAMTBACKUP}/LocalMediumInfo.txt.tmp ${PAMTBACKUP}/LocalMediumInfo.txt
    sed "/"${SHORTPRODUCTNAME}"/d" ${PAMTBACKUP}/LocalMediumInfo.txt >${PAMTBACKUP}/LocalMediumInfo.txt.tmp
    mv ${PAMTBACKUP}/LocalMediumInfo.txt.tmp ${PAMTBACKUP}/LocalMediumInfo.txt
  fi
#   cp  ../LocalMediumInfo.txt ${BACKPATH}LocalMediumInfo.txt 2>/dev/null
else
  rm ${PAMTBACKUP}/LocalMediumInfo.txt 2>/dev/null  
fi

#PAMTPRODUCTNAME=`grep ProductName ./ConfigInfo1.txt|awk -F"=" '{print $2}'`
#PAMTVERSION=`grep productname ./ConfigInfo.txt | awk -F"=" '{print $2}'`

echo "--版本信息更新完毕--"
#echo
#echo "------------恢复前的版本信息为$PAMTPRODUCTNAME"
#echo
#echo "------------恢复后的版本信息为${PAMTLOCALNAME}"

#恢复MD5码文件
#增加下一行语句是保证，初次安装后卸载，将md5码信息完全删除，而在下一行的cp也不会将md5文件考回，因为不存在
rm ${PAMTBACKUP}/bin/${SHORTPRODUCTNAME}.md5 2>/dev/null
cp ../${SHORTPRODUCTNAME}.md5 ${PAMTBACKUP}/bin/ 2>/dev/null
rm ../${SHORTPRODUCTNAME}.md5 2>/dev/null

#cp ../configFile/LocalMediumInfo.txt $BACKPATH/

rm MediumInfo1.txt
rm PackageDescription1.txt
rm ConfigInfo1.txt

echo "==============================================================================="
echo "   PAMT安装程序开始调用卸载后运行脚本                                          "
echo "   卸载后运行脚本可对卸载结果进行去确认，或者进行删除用户、卷组等操作          "
echo "==============================================================================="
echo

POSTUNINSTALLNAMESTR=`grep PostUninstallName ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`
INSTRUCTIONSTR=`grep -w Instruction ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`
POSTUNINSTALLNUMBER=`grep PostUninstallNum ./PreconditionInfo1.txt|awk -F"=" '{print $2}'`

if [ -n "$POSTUNINSTALLNUMBER" ]
then
  POSTUNINSTALLNUM=`echo ${POSTUNINSTALLNUMBER}|tr -cs "[0-9]" " "`
#  echo "$POSTUNINSTALLNUM"
  VAR1=1
#  echo "$VAR1"
  while [[ ${VAR1} -le ${POSTUNINSTALLNUM} ]]
    do
       POSTUNINSTALLNAME=`echo ${POSTUNINSTALLNAMESTR}|awk -F";" '{print $(VAR1)}' VAR1="$VAR1"`
       echo "执行脚本${POSTUNINSTALLNAME}"
       ./${POSTUNINSTALLNAME}
       VAR1=`expr ${VAR1} + 1`	
#      echo "$VAR1"
    done
else
   echo "--本次安装没有集成卸载后运行脚本--"
fi

rm PreconditionInfo1.txt

#针对有可能出现Product=0,再安装调取PAMT0004更新LocalMediumInfo文件失败，处理如下
PRODUCTNUM=`grep -w Product ${PAMTBACKUP}/LocalMediumInfo.txt|awk -F"=" '{print $2}'`
if [[ ${PRODUCTNUM} == "0" ]]
then
rm ${PAMTBACKUP}/LocalMediumInfo.txt
fi

#以下是删除备份时生成在备份文件路径下的产品文件夹

#rm -rf ${PAMTBACKUP}/${PAMTFULLNAME}

rm -rf ../LocalMediumInfo.txt




