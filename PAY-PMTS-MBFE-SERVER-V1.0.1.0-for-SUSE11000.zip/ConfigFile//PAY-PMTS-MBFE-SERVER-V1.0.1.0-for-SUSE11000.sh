#!/bin/sh
cp /pmts/publib/libtlq6CNAPS2SLES.so      /pmts/publib/libtlq6CNAPS2SLES.so.ln
cp /pmts/publib/libPmtsPub.so             /pmts/publib/libPmtsPub.so.ln
cp /pmts/publib/libcfcaCNAPS2SLES.so      /pmts/publib/libcfcaCNAPS2SLES.so.ln
cp /pmts/publib/libcmtmsgBEPS.so          /pmts/publib/libcmtmsgBEPS.so.ln
cp /pmts/publib/libcmtmsgCNCC.so          /pmts/publib/libcmtmsgCNCC.so.ln
cp /pmts/publib/libcmtmsgHVPS.so          /pmts/publib/libcmtmsgHVPS.so.ln
cp /pmts/publib/libcnaps2msgCNAPS2SLES.so /pmts/publib/libcnaps2msgCNAPS2SLES.so.ln
cp /pmts/publib/libcnccCNAPS2SLES.so      /pmts/publib/libcnccCNAPS2SLES.so.ln
cp /pmts/publib/libcommCNAPS.so           /pmts/publib/libcommCNAPS.so.ln
cp /pmts/publib/libmqCNAPS2SLES.so        /pmts/publib/libmqCNAPS2SLES.so.ln
cp /pmts/publib/libpkgmsgBEPS.so          /pmts/publib/libpkgmsgBEPS.so.ln
cp /pmts/publib/libsysmsgCNAPS2SLES.so    /pmts/publib/libsysmsgCNAPS2SLES.so.ln
cp /pmts/publib/libtlqCNAPS2SLES.so       /pmts/publib/libtlqCNAPS2SLES.so.ln
cp /pmts/publib/libxerces-c-3.1.so        /pmts/publib/libxerces-c-3.1.so.ln
cp /pmts/publib/libxmlmsgBEPS.so          /pmts/publib/libxmlmsgBEPS.so.ln
cp /pmts/publib/libxmlmsgCCMS.so          /pmts/publib/libxmlmsgCCMS.so.ln
cp /pmts/publib/libxmlmsgHVPS.so          /pmts/publib/libxmlmsgHVPS.so.ln
cp /pmts/publib/libxmlmsgIBPS.so          /pmts/publib/libxmlmsgIBPS.so.ln
cp /pmts/publib/libxmlmsgNETS.so          /pmts/publib/libxmlmsgNETS.so.ln
cp /pmts/publib/libxmlmsgSAPS.so          /pmts/publib/libxmlmsgSAPS.so.ln
rm -rf /usr/lib/libtlq6CNAPS2SLES.so
rm -rf /usr/lib/libPmtsPub.so
rm -rf /usr/lib/libcfcaCNAPS2SLES.so
rm -rf /usr/lib/libcmtmsgBEPS.so
rm -rf /usr/lib/libcmtmsgCNCC.so
rm -rf /usr/lib/libcmtmsgHVPS.so
rm -rf /usr/lib/libcnaps2msgCNAPS2SLES.so
rm -rf /usr/lib/libcnccCNAPS2SLES.so
rm -rf /usr/lib/libcommCNAPS.so
rm -rf /usr/lib/libmqCNAPS2SLES.so
rm -rf /usr/lib/libpkgmsgBEPS.so
rm -rf /usr/lib/libsysmsgCNAPS2SLES.so
rm -rf /usr/lib/libtlqCNAPS2SLES.so
rm -rf /usr/lib/libxerces-c-3.1.so
rm -rf /usr/lib/libxmlmsgBEPS.so
rm -rf /usr/lib/libxmlmsgCCMS.so
rm -rf /usr/lib/libxmlmsgHVPS.so
rm -rf /usr/lib/libxmlmsgIBPS.so
rm -rf /usr/lib/libxmlmsgNETS.so
rm -rf /usr/lib/libxmlmsgSAPS.so
cp /pmts/publib/libtlq6CNAPS2SLES.so.ln      /pmts/publib/libtlq6CNAPS2SLES.so
cp /pmts/publib/libPmtsPub.so.ln             /pmts/publib/libPmtsPub.so
cp /pmts/publib/libcfcaCNAPS2SLES.so.ln      /pmts/publib/libcfcaCNAPS2SLES.so
cp /pmts/publib/libcmtmsgBEPS.so.ln          /pmts/publib/libcmtmsgBEPS.so
cp /pmts/publib/libcmtmsgCNCC.so.ln          /pmts/publib/libcmtmsgCNCC.so
cp /pmts/publib/libcmtmsgHVPS.so.ln          /pmts/publib/libcmtmsgHVPS.so
cp /pmts/publib/libcnaps2msgCNAPS2SLES.so.ln /pmts/publib/libcnaps2msgCNAPS2SLES.so
cp /pmts/publib/libcnccCNAPS2SLES.so.ln      /pmts/publib/libcnccCNAPS2SLES.so
cp /pmts/publib/libcommCNAPS.so.ln           /pmts/publib/libcommCNAPS.so
cp /pmts/publib/libmqCNAPS2SLES.so.ln        /pmts/publib/libmqCNAPS2SLES.so
cp /pmts/publib/libpkgmsgBEPS.so.ln          /pmts/publib/libpkgmsgBEPS.so
cp /pmts/publib/libsysmsgCNAPS2SLES.so.ln    /pmts/publib/libsysmsgCNAPS2SLES.so
cp /pmts/publib/libtlqCNAPS2SLES.so.ln       /pmts/publib/libtlqCNAPS2SLES.so
cp /pmts/publib/libxerces-c-3.1.so.ln        /pmts/publib/libxerces-c-3.1.so
cp /pmts/publib/libxmlmsgBEPS.so.ln          /pmts/publib/libxmlmsgBEPS.so
cp /pmts/publib/libxmlmsgCCMS.so.ln          /pmts/publib/libxmlmsgCCMS.so
cp /pmts/publib/libxmlmsgHVPS.so.ln          /pmts/publib/libxmlmsgHVPS.so
cp /pmts/publib/libxmlmsgIBPS.so.ln          /pmts/publib/libxmlmsgIBPS.so
cp /pmts/publib/libxmlmsgNETS.so.ln          /pmts/publib/libxmlmsgNETS.so
cp /pmts/publib/libxmlmsgSAPS.so.ln          /pmts/publib/libxmlmsgSAPS.so
ln -s  /pmts/publib/libtlq6CNAPS2SLES.so       	 /usr/lib/libtlq6CNAPS2SLES.so
ln -s  /pmts/publib/libPmtsPub.so                /usr/lib/libPmtsPub.so
ln -s  /pmts/publib/libcfcaCNAPS2SLES.so         /usr/lib/libcfcaCNAPS2SLES.so
ln -s  /pmts/publib/libcmtmsgBEPS.so             /usr/lib/libcmtmsgBEPS.so
ln -s  /pmts/publib/libcmtmsgCNCC.so             /usr/lib/libcmtmsgCNCC.so
ln -s  /pmts/publib/libcmtmsgHVPS.so             /usr/lib/libcmtmsgHVPS.so
ln -s  /pmts/publib/libcnaps2msgCNAPS2SLES.so    /usr/lib/libcnaps2msgCNAPS2SLES.so
ln -s  /pmts/publib/libcnccCNAPS2SLES.so         /usr/lib/libcnccCNAPS2SLES.so
ln -s  /pmts/publib/libcommCNAPS.so              /usr/lib/libcommCNAPS.so
ln -s  /pmts/publib/libmqCNAPS2SLES.so           /usr/lib/libmqCNAPS2SLES.so
ln -s  /pmts/publib/libpkgmsgBEPS.so             /usr/lib/libpkgmsgBEPS.so
ln -s  /pmts/publib/libsysmsgCNAPS2SLES.so       /usr/lib/libsysmsgCNAPS2SLES.so
ln -s  /pmts/publib/libtlqCNAPS2SLES.so          /usr/lib/libtlqCNAPS2SLES.so
ln -s  /pmts/publib/libxerces-c-3.1.so           /usr/lib/libxerces-c-3.1.so
ln -s  /pmts/publib/libxmlmsgBEPS.so             /usr/lib/libxmlmsgBEPS.so         
ln -s  /pmts/publib/libxmlmsgCCMS.so             /usr/lib/libxmlmsgCCMS.so
ln -s  /pmts/publib/libxmlmsgHVPS.so             /usr/lib/libxmlmsgHVPS.so
ln -s  /pmts/publib/libxmlmsgIBPS.so             /usr/lib/libxmlmsgIBPS.so
ln -s  /pmts/publib/libxmlmsgNETS.so             /usr/lib/libxmlmsgNETS.so
ln -s  /pmts/publib/libxmlmsgSAPS.so             /usr/lib/libxmlmsgSAPS.so
rm -f /pmts/publib/libtlq6CNAPS2SLES.so.ln      
rm -f /pmts/publib/libPmtsPub.so.ln             
rm -f /pmts/publib/libcfcaCNAPS2SLES.so.ln      
rm -f /pmts/publib/libcmtmsgBEPS.so.ln          
rm -f /pmts/publib/libcmtmsgCNCC.so.ln          
rm -f /pmts/publib/libcmtmsgHVPS.so.ln          
rm -f /pmts/publib/libcnaps2msgCNAPS2SLES.so.ln 
rm -f /pmts/publib/libcnccCNAPS2SLES.so.ln      
rm -f /pmts/publib/libcommCNAPS.so.ln           
rm -f /pmts/publib/libmqCNAPS2SLES.so.ln        
rm -f /pmts/publib/libpkgmsgBEPS.so.ln          
rm -f /pmts/publib/libsysmsgCNAPS2SLES.so.ln    
rm -f /pmts/publib/libtlqCNAPS2SLES.so.ln       
rm -f /pmts/publib/libxerces-c-3.1.so.ln        
rm -f /pmts/publib/libxmlmsgBEPS.so.ln          
rm -f /pmts/publib/libxmlmsgCCMS.so.ln          
rm -f /pmts/publib/libxmlmsgHVPS.so.ln          
rm -f /pmts/publib/libxmlmsgIBPS.so.ln          
rm -f /pmts/publib/libxmlmsgNETS.so.ln          
rm -f /pmts/publib/libxmlmsgSAPS.so.ln          
