#!/bin/sh
# create and modified by 高卓 
choice()
{
  echo
  echo "--输入'Y'或'y'进行确认，或同时按下CTRL+C键退出本次安装--"
  read ch
  if [[ ${ch} == "Y" ]] || [[ ${ch} == "y" ]]
  then
  echo "--继续执行下一步--"  
  echo
  else
  echo "输入字符错误，请重新输入！"
  choice
  fi
}

echo "==============================================================================="
echo "   PAMT安装程序开始进行系统备份                                                "
echo "   系统备份是对系统中已存在的文件进行备份 ，不包括此次更新文件                 "
echo "==============================================================================="
echo
PAMTBACKUPNAME=`date +"%Y-%m-%d%H:%M:%S"`

cat PackageDescription.txt | tr -d '\015' > PackageDescription1.txt
cat ConfigInfo.txt | tr -d '\015' > ConfigInfo1.txt
#echo $BACK
#获取备份路径
SHORTPRODUCTNAME=`grep ProductName ./ConfigInfo1.txt|awk -F"=" '{print $2}'`

#备份路径取消掉，从环境变量中获取
#BACKPATH=`grep BackupPath ./PackageDescription1.txt|awk -F"=" '{print $2}'`
PRODUCTNAME=`grep ProductName ./PackageDescription1.txt|awk -F"=" '{print $2}'`
#echo "----创建完的文件夹名称为："
#echo "$PRODUCTNAME"
#echo
PAMTFULLBACKUP=`echo "${PAMTBACKUP}/${PRODUCTNAME}"`

echo "--系统备份主路径为:${PAMTBACKUP}，安装包备份路径为：${PAMTFULLBACKUP}"
choice

#mkdir -p ${PAMTBACKUP}/${PRODUCTNAME}
mkdir -p ${PAMTFULLBACKUP}
#echo "*********************创建备份文件夹，命令为："
#echo "mkdir -p $PAMTBACKUP"
#echo
#echo "----备份文件夹创建完毕"
#echo
echo "--进入文件备份步骤："
echo
cat MediumInfo.txt | tr -d '\015' > MediumInfo1.txt
PAMTFILENAMESTR=`grep MaintanceFileName ./MediumInfo1.txt|awk -F"=" '{print $2}'`
PAMTFILEPATHSTR=`grep -w Path ./MediumInfo1.txt|awk -F"=" '{print $2}'`
PAMTFILENUMBER=`grep MaintanceFileNum ./MediumInfo1.txt|awk -F"=" '{print $2}'`
#新增标识位，用来区别文件及文件夹，20110901
PAMTFILEFLAGSTR=`grep FileFlag ./MediumInfo1.txt|awk -F"=" '{print $2}'`
PAMTFILEPROPERTYSTR=`grep Property ./MediumInfo1.txt|awk -F"=" '{print $2}'`
PAMTFILENUMBER=`echo $PAMTFILENUMBER|tr -cs "[0-9]" " "`
#echo "数字为$PAMTFILENUMBER"


while [[ ${PAMTFILENUMBER} -ne  0 ]]
do
		PAMTFILENAME=`echo ${PAMTFILENAMESTR}|awk -F";" '{print $(PAMTFILENUMBER)}' PAMTFILENUMBER="$PAMTFILENUMBER" `
		PAMTFILEPATH=`echo ${PAMTFILEPATHSTR}|awk -F" " '{print $(PAMTFILENUMBER)}' PAMTFILENUMBER="$PAMTFILENUMBER" `
    PAMTFILEFLAG=`echo ${PAMTFILEFLAGSTR}|awk -F" " '{print $(PAMTFILENUMBER)}' PAMTFILENUMBER="$PAMTFILENUMBER" `
		PAMTFILEPROPERTY=`echo ${PAMTFILEPROPERTYSTR}|awk -F" " '{print $(PAMTFILENUMBER)}' PAMTFILENUMBER="$PAMTFILENUMBER" `
#		echo PAMTFILENAMESTR$PAMTFILENAMESTR
#		echo PAMTFILENAME$PAMTFILENAME
#		echo PAMTFILEPATHSTR$PAMTFILEPATHSTR
#		echo "PAMTFILEPATH $PAMTFILEPATH$PAMTFILENAME"
    if [[ ${PAMTFILEFLAG} == "0" ]]
    then 
		  if [[ ${PAMTFILEPROPERTY} == "Replace" ]]
		  then
#		  echo "    文件${PAMTFILENAME}是替换文件，需进行备份"
		  #echo "命令为:"
		  #echo "-------------------cp -p $PAMTFILEPATH$PAMTFILENAME $PAMTBACKUP"
		  #echo "----$PAMTFILEPATH"
		  #echo "----$PAMTFILENAME"
		  #echo $PAMTFILEPATH$PAMTFILENAME
		  #echo $PAMTBACKUP
#		  cp -p $PAMTFILEPATH/$PAMTFILENAME $PAMTBACKUP/
#     考虑到同名文件出现的可能，特更改
#变量PAMTFILEPATH前带有/符号
      mkdir -p $PAMTFULLBACKUP$PAMTFILEPATH
      cp -p $PAMTFILEPATH/$PAMTFILENAME $PAMTFULLBACKUP$PAMTFILEPATH/
		  echo "--文件${PAMTFILENAME}为替换文件，备份完成"
		  echo
		  else 
		  echo "--${PAMTFILENAME}为新增文件，无需备份"
		  echo
		  fi
		else
		:;
		fi
	  PAMTFILENUMBER=`expr ${PAMTFILENUMBER} - 1`	
done

echo "--文件备份完毕--"
choice
echo
#echo "下面开始备份本地配置文件"
#cp MediumInfo.txt $PAMTBACKUP/
#echo "cp ${BACKPATH}LocalMediumInfo.txt ./LocalMediumInfo.txt"
cp ${PAMTBACKUP}/LocalMediumInfo.txt ../LocalMediumInfo.txt 2>/dev/null
#echo "*********************本地配置文件备份完毕"
#echo "下面开始备份帮助文件"
#cp ./MediumInfo.txt ./BackupHelp.txt
#echo "FileName=$PRODUCTNAME$PAMTBACKUPNAME" >> ./BackupHelp.txt


#备份MD5码文件
cp ${PAMTBACKUP}/bin/${SHORTPRODUCTNAME}.md5 ../ 2>/dev/null

rm PackageDescription1.txt
rm MediumInfo1.txt
rm ConfigInfo1.txt