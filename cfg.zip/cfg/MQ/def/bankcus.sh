runmqsc QMUMBFEA<bankcus.tst> bankcus.log
