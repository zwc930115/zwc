/********************************************************************
�ļ�����del_recvsmp702.cpp
�����ˣ�aps-wdk
��  �ڣ�2008-08-30
�޸��ˣ�
��  �ڣ�2008-08-30
��  ����ƽ̨�յ����ĵ�SMP702���Ĵ�����

��  ����
Copyright (c) 2008  YLINK
********************************************************************/
#include "del_recvsmp.h"
#include "sSmp702.hpp"

//add by zwc for tranfer account
#include "isuser.hpp"
#include "usergroup.hpp"
#include "funclist.hpp"
#include <time.h>
//add end

#define       SQLCA_STORAGE_CLASS   extern

extern int m_iTagFlag;
extern char m_strUnpackErr[400];

CDelRecvSmp702::CDelRecvSmp702()
{
}


/******************************************************************************
*  Function:   CDelRecvSmp702::DoSelfWork
*  Description:֧��������ҵ����
*  Input:      strMsg �յ��ı���
*  Output:     ��
*  Return:     ��
*  Others:     ��
*  Author:     aps-zxu
*  Date:       2008-08-26
*******************************************************************************/
void CDelRecvSmp702::DoSelfWork(const char *strMsg)
{
    Log(_INFOLOG, "Info: into CDelRecvSmp702::DoSelfWork.");
    bool bRight = true; /* ���ĺϷ��Ա�־ */
    int iRet=0;
    int  iJoin = JOIN_DIRECT; //���ӷ�ʽ
	CString sMBmsg;
	CString strDetail;	
	
    /* ����SMP702���� */
    bRight = UnPackSmp702(strMsg);
   if (true != bRight)
    {
        strcpy(m_sTemp,"SMP702���Ľ�������");
        My_Printf("%s",m_sTemp);
        Log(_IMPORTANTLOG, m_sTemp);
        CTBEPS_ThrowException(m_sTemp, ERR_OTHER);
    }

	//���±�
	updateTable();
	//�����ϵͳ��
	CheckState oCheckState;
	oCheckState.checkdate = pCSMP702->m_strCenterDate;
	oCheckState.checknode = pCSMP702->m_strRecvBnkCode;
	oCheckState.workdate  =  pCSMP702->m_strCenterDate;
	oCheckState.checkstate = "00"; 

	//oCheckState.statetime ;
	//oCheckState.dealcode  ;
	//oCheckState.dealdesc  ;
	//oCheckState.remark    ;
	
    if (oCheckState.findByPK() != 0)
    {
        oCheckState.checkdate = pCSMP702->m_strCenterDate;
        oCheckState.checknode = pCSMP702->m_strRecvBnkCode;
        oCheckState.workdate  =  pCSMP702->m_strCenterDate;
        oCheckState.checkstate = "00"; 
	    iRet = oCheckState.insert();
    }
	if (0 != iRet)
	{
	 	sprintf(m_sTemp,"CDelRecvSmp702, DoSelfWork��CheckState������, iRet=[%d]", iRet);
		printf("CDelRecvSmp702::DoSelfWork, [%s]\n", m_sTemp);    	  	
        Log(_DEBUGLOG, m_sTemp);
    	CTBEPS_ThrowException(m_sTemp, ERR_DB);  
	}
	Log(_INFOLOG, "��CheckState���ɹ�");

    //�����˺��ļ�
    trafAcct();
	
	//����ʷ��
	CrdSendList oCrdSendList;
	oCrdSendList.subdate = pCSMP702->m_strCenterDate;
	iRet = oCrdSendList.MoveHis();
	if ((0 != iRet)&&(SQLNOTFOUND != iRet) && (ORACLE_SQLNOTFOUND != iRet))
	{
	 	sprintf(m_sTemp,"CDelRecvSmp702, CrdSendList.MoveHis������, iRet=[%d]", iRet);
		printf("CDelRecvSmp702::DoSelfWork, [%s]\n", m_sTemp);    	  	
        Log(_DEBUGLOG, m_sTemp);
    	CTBEPS_ThrowException(m_sTemp, ERR_DB);  
	}

	CrdRecvList oCrdRecvList;
	oCrdRecvList.subdate = pCSMP702->m_strCenterDate;
	iRet = oCrdRecvList.MoveHis();
	if ((0 != iRet)&&(SQLNOTFOUND != iRet) && (ORACLE_SQLNOTFOUND != iRet))
	{
	 	sprintf(m_sTemp,"CDelRecvSmp702, oCrdRecvList.MoveHis������, iRet=[%d]", iRet);
		printf("CDelRecvSmp702::DoSelfWork, [%s]\n", m_sTemp);    	  	
        Log(_DEBUGLOG, m_sTemp);
    	CTBEPS_ThrowException(m_sTemp, ERR_DB);  
	}

	DbRecvList oDbRecvList;
	oDbRecvList.subdate = pCSMP702->m_strCenterDate;
	iRet = oDbRecvList.MoveHis();
	if ((0 != iRet)&&(SQLNOTFOUND != iRet) && (ORACLE_SQLNOTFOUND != iRet))
	{
	 	sprintf(m_sTemp,"CDelRecvSmp702, oDbRecvList.MoveHis������, iRet=[%d]", iRet);
		printf("CDelRecvSmp702::DoSelfWork, [%s]\n", m_sTemp);    	  	
        Log(_DEBUGLOG, m_sTemp);
    	CTBEPS_ThrowException(m_sTemp, ERR_DB);  
	}

	DbSendList oDbSendList;
	oDbSendList.subdate = pCSMP702->m_strCenterDate;
	iRet = oDbSendList.MoveHis();
	if ((0 != iRet)&&(SQLNOTFOUND != iRet) && (ORACLE_SQLNOTFOUND != iRet))
	{
	 	sprintf(m_sTemp,"CDelRecvSmp702, oDbSendList.MoveHis������, iRet=[%d]", iRet);
		printf("CDelRecvSmp702::DoSelfWork, [%s]\n", m_sTemp);    	  	
        Log(_DEBUGLOG, m_sTemp);
    	CTBEPS_ThrowException(m_sTemp, ERR_DB);  
	}

	SpepaymentInfo oSpepaymentInfo;
	oSpepaymentInfo.subdate = pCSMP702->m_strCenterDate;
	iRet = oSpepaymentInfo.MoveHis();
	if ((0 != iRet)&&(SQLNOTFOUND != iRet) && (ORACLE_SQLNOTFOUND != iRet))
	{
	 	sprintf(m_sTemp,"CDelRecvSmp702, oSpepaymentInfo.MoveHis������, iRet=[%d]", iRet);
		printf("CDelRecvSmp702::DoSelfWork, [%s]\n", m_sTemp);    	  	
        Log(_DEBUGLOG, m_sTemp);
    	CTBEPS_ThrowException(m_sTemp, ERR_DB);  
	}

	CCandet oCCandet;
	oCCandet.wrkdate = pCSMP702->m_strCenterDate;
	iRet = oCCandet.MoveHis();
	if ((0 != iRet)&&(SQLNOTFOUND != iRet) && (ORACLE_SQLNOTFOUND != iRet))
	{
	 	sprintf(m_sTemp,"CDelRecvSmp702, oCCandet.MoveHis������, iRet=[%d]", iRet);
		printf("CDelRecvSmp702::DoSelfWork, [%s]\n", m_sTemp);    	  	
        Log(_DEBUGLOG, m_sTemp);
    	CTBEPS_ThrowException(m_sTemp, ERR_DB);  
	}
	
   	/*����ֱ����־ת����*/
   	if (0 != getJoinType("SMP702", RECV_FLAG, iJoin))
	{
		Log(_IMPORTANTLOG, "��ȡ��ֱ�����÷�ʽ����!");
		My_Printf("��ȡ��ֱ�����÷�ʽ����!");
		/*��ȡ��ֱ�����ó���ʱ��Ĭ�ϰ�ֱ����ʽת������*/
	}
	
    if(iJoin == JOIN_DIRECT)
   	{
   	    char sMBmsg[2000];
        memset(sMBmsg, 0, sizeof(sMBmsg));
   		/*���ڱ��ģ�SMP702��ת������*/
   		iRet = TranToMBMsg( sMBmsg );
        if (0 != iRet)
        {
            sprintf(m_sTemp, "SMP702����ת��ʧ��.[%s][%s][%s]",
            pCSMP702->m_strCenterDate.GetBuffer(0), pCSMP702->m_strRecvBnkCode.GetBuffer(0), pCSMP702->m_strWorkDateB.GetBuffer(0));
            My_Printf("%s",m_sTemp);
            Log(_DEBUGLOG, m_sTemp);
            return;
        }
        iRet = InsertMBCom( sMBmsg);
        if (0 != iRet)
        {
            sprintf(m_sTemp, "SMP702����������ͨѶ��ʧ��,SQLCA.sqlcode=[%d].[%s][%s][%s]", 
            iRet,pCSMP702->m_strCenterDate.GetBuffer(0),pCSMP702->m_strRecvBnkCode.GetBuffer(0),pCSMP702->m_strWorkDateB.GetBuffer(0));
            My_Printf("%s",m_sTemp);
            Log(_DEBUGLOG, m_sTemp);
            CTBEPS_ThrowException(m_sTemp, ERR_DB);  
        }	
   	}	
   	else
   	{
   		/*����Ҫת������ȥ*/
   		//д�ͻ�֪ͨ��
	    sprintf(m_sTemp, "�յ�[%s]����,��������[%s]", pCSMP702->m_strSMPCode.GetBuffer(0),pCSMP702->m_strWorkDateB.GetBuffer(0));
	    NotifyOprUser(_IMP_NOTIFY, pCSMP702->m_strRecvBnkCode.GetBuffer(0), m_sTemp, _SMPFLAG);
   	}	
   	
    Log(_INFOLOG, "Info: exit CDelRecvSmp702::DoSelfWork.");
    return;
}

/******************************************************************************
*  Function:   CDelRecvSmp702::UnPackSmp702
*  Description:�������ڱ��ı��浽�ṹ��
*  Input:      ��
*  Output:     ��
*  Return:     ��
*  Others:     ��
*  Author:     xqg
*  Date:       2008-08-17
*******************************************************************************/
bool CDelRecvSmp702::UnPackSmp702(const char *strMsg)
{
    Log(_INFOLOG, "Info: into CDelRecvSmp702::UnPackSmp702.");
    //CBaseSMP *pMsgIn=NULL;
    pMsgIn = CBaseSMP::FromString(strMsg, 0);
    if (m_iTagFlag || pMsgIn == NULL)
    {
    	printf("%s \n",m_strUnpackErr);	
    	Log(_DEBUGLOG, m_strUnpackErr);	
        return false;
    }

    if( 0 !=pMsgIn->m_nStatus)
    {
        Log(_DEBUGLOG, pMsgIn->m_strErrMsg.GetBuffer(0));
        Log(_DEBUGLOG, "���Ľ���ʧ�ܣ���");
        return false;
    } 
    pCSMP702 = dynamic_cast < CSMP702 * >(pMsgIn);
    if (NULL == pCSMP702) {
        Log(_DEBUGLOG, pMsgIn->m_strErrMsg.GetBuffer(0));
        Log(_DEBUGLOG, "���Ľ���ʧ�ܣ���");
        return false;
    }
    
    Log(_INFOLOG, "Info: exit CDelRecvSmp702::UnPackSmp702.");    
    return true;
}

int CDelRecvSmp702::updateTable()
{
    Log(_INFOLOG, "Info: into CDelRecvSmp702::updateTable.");    
	int iRet = 0;
	oSysParm.parmcode = "003"; //��һ������
	iRet = oSysParm.findByPK();
	if( iRet < 0 )
    {
        sprintf(m_sTemp, "SMP702���ұ�oSysParmʧ��,SQLCA.sqlcode=[%d],[%s]", iRet,pCSMP702->m_strCenterDate.GetBuffer(0)); 
        Log(_DEBUGLOG, m_sTemp);  
        CTBEPS_ThrowException(m_sTemp, ERR_DB);                         
    }
	oSysParm.parmvalue = pCSMP702->m_strPreWkDate;
	oSysParm.update();
	if( iRet < 0 )
    {
        sprintf(m_sTemp, "SMP702���±�oSysParmʧ��,SQLCA.sqlcode=[%d],[%s]", iRet,pCSMP702->m_strCenterDate.GetBuffer(0)); 
        Log(_DEBUGLOG, m_sTemp);  
        CTBEPS_ThrowException(m_sTemp, ERR_DB);                         
    }
	oSysParm.parmcode = "002"; //��������
	oSysParm.findByPK();	
	if( iRet < 0 )
    {
        sprintf(m_sTemp, "SMP702���ұ�oSysParm��002ʧ��,SQLCA.sqlcode=[%d],[%s]", iRet,pCSMP702->m_strCenterDate.GetBuffer(0)); 
        Log(_DEBUGLOG, m_sTemp);  
        CTBEPS_ThrowException(m_sTemp, ERR_DB);                         
    }
	oSysParm.parmvalue = pCSMP702->m_strWorkDateB;
	oSysParm.update();
	if( iRet < 0 )
    {
        sprintf(m_sTemp, "SMP702���±�oSysParm��002ʧ��,SQLCA.sqlcode=[%d],[%s]", iRet,pCSMP702->m_strCenterDate.GetBuffer(0)); 
        Log(_DEBUGLOG, m_sTemp);  
        CTBEPS_ThrowException(m_sTemp, ERR_DB);                         
    }
    Log(_INFOLOG, "Info: exit CDelRecvSmp702::updateTable.");    
	return 0;
}
	
/****************************************************************************** 
*  Function:   InsertMBCom                      
*  Description:�ѱ���ת�浽������ͨѶ����        
*  Input:      Ҫ���͵ı���            
*  Output:     ��
*  Return:     0 �ɹ� <0 ʧ��
*  Others:     
*  Author:     xqg
*  Date:       2008-08-26
*******************************************************************************/ 
int CDelRecvSmp702::InsertMBCom( const char *strMsg)
{
    Log(_INFOLOG, "Info: into CDelRecvSmp702::InsertMBCom.");    
    int iRet = 0;

    SendToMb oSendToMb;
    oSendToMb.msgtype=pCSMP702->m_strSMPCode;
    oSendToMb.wrkdate = pCSMP702->m_strCenterDate;
    oSendToMb.msgtext=strMsg;
    oSendToMb.procstate="01";
    oSendToMb.proctimes = 0;
    iRet = oSendToMb.insert();
    if( iRet < 0 )
    {
        sprintf(m_sTemp, "SMP702����������ͨѶ��ʧ��,SQLCA.sqlcode=[%d],[%s]", iRet,pCSMP702->m_strCenterDate.GetBuffer(0)); 
        Log(_DEBUGLOG, m_sTemp);  
        CTBEPS_ThrowException(m_sTemp, ERR_DB);                         
    }
    Log(_INFOLOG, "Info: exit CDelRecvSmp702::InsertMBCom.");    
    return 0;
}

/******************************************************************************
*  Function:   CDelRecvSmp702::TranToMBMsg
*  Description:�����ı�׼����ת�������ڱ���
*  Input:      ���ı�׼����
*  Output:     ���ڱ���
*  Return:     = 0 �ɹ�   �� 0  ʧ��
*  Others:     ��
*  Author:     xqg
*  Date:       2008-08-27 
*******************************************************************************/
int CDelRecvSmp702::TranToMBMsg(char *strMsg)
{
    Log(_INFOLOG, "Info: into CDelRecvSmp702::TranToMBMsg.");    
    char szTemp[2000];
    int iRet =0;
    memset(szTemp,0,sizeof(szTemp));
    CSsmp702 psmp702;
    psmp702.Copy(pCSMP702);
    iRet = psmp702.BodyToString(szTemp);
    if(0 != iRet)
    {
        Log(_INFOLOG, "Info: exit CDelRecvSmp702::TranToMBMsg. return -1");    
        return -1;
    }
    memcpy(strMsg,szTemp,strlen(szTemp));
    Log(_INFOLOG, "Info: exit CDelRecvSmp702::TranToMBMsg.");    
    return 0;
    
}

/******************************************************************************
*  Function:   CDelRecvSmp713::isReRecived
*  Description:����Ƿ��ظ����ձ���
*  Input:      strSendBank:�����к�,strWorkDate:��������,sSndeq:֧���������
*  Output:     ��
*  Return:     true �������� .false �ظ�����
*  Others:     ���ʧ��ʱ�Ὣ�������¼
*  Author:     XQG
*  Date:       2008-08-17
*******************************************************************************/
bool CDelRecvSmp702::isReRecived(char* strSendBank, char* strWorkDate, char* sSndeq)
{
	Log(_INFOLOG, "Info: enter CDelRecvSmp713::isReRecived.");
  	int	iRet;
    return true;
}

bool CDelRecvSmp702::checkValues()
{
	return true;
}

//add by zwc 20171207 for transfer account file
void CDelRecvSmp702::trafAcct()
{
	Log(_INFOLOG, "Info: into CDelRecvSmp702::tranAcct.");	
	CString sSftpDir = "../sftp/";
	CString sAcctFile = "";
	CString sEntlFile = "";
	CString sSMODFile = "";
	CString sTarFile  = "";
	char szCmd[512] = {0};
	char szResult[512] = {0};
	time_t timep;
	struct tm *p;
	time(&timep);
	p = gmtime(&timep);
    int iRet = -1;

    // ���� Accounts file
	iRet = createAcctF(sSftpDir, sAcctFile);
	if (0 != iRet)
	{
	    memset(m_sTemp, 0, sizeof(m_sTemp));
        sprintf(m_sTemp, "����Accounts fileʧ�ܣ�FileName=[%s%s]", 
			    sSftpDir.GetBuffer(0),sAcctFile.GetBuffer(0)); 
        Log(_DEBUGLOG, m_sTemp); 
	}

	// ���� Entitlements file
	iRet = createAcctRoleF(sSftpDir, sEntlFile);
	if (0 != iRet)
	{
	    memset(m_sTemp, 0, sizeof(m_sTemp));
        sprintf(m_sTemp, "����Entitlements fileʧ�ܣ�FileName=[%s%s]", 
			    sSftpDir.GetBuffer(0),sEntlFile.GetBuffer(0)); 
        Log(_DEBUGLOG, m_sTemp); 
	}

	// ���� SMOD file
	iRet = createRoleF(sSftpDir, sSMODFile);
	if (0 != iRet)
	{
	    memset(m_sTemp, 0, sizeof(m_sTemp));
        sprintf(m_sTemp, "����SMOD fileʧ�ܣ�FileName=[%s%s]", 
			    sSftpDir.GetBuffer(0),sSMODFile.GetBuffer(0)); 
        Log(_DEBUGLOG, m_sTemp); 
	}

	//��tar�ļ���
	sTarFile.Format("HBAP-CN-A-HTSAHBCNSMPS-01.grmrdata.%d%02d%02d%02u%02u%02u.tar", 
		            p->tm_year + 1900, p->tm_mon + 1, p->tm_mday, 
					p->tm_hour,p->tm_min,p->tm_sec);

    //���acct��entl��smod�����ļ���tar��
    sprintf(szCmd, "cd %s && tar -cvf %s %s %s %s && ../bin/sftp.sh %s", 
           sSftpDir.GetBuffer(0),sTarFile.GetBuffer(0),
           sAcctFile.GetBuffer(0),sEntlFile.GetBuffer(0),
           sSMODFile.GetBuffer(0),sTarFile.GetBuffer(0));	
    //ͨ��sftp����
	//sprintf(sCmd, "./sftp.sh %s", szTarFile);	
	MyCMD(szCmd, szResult);
	memset(m_sTemp, 0, sizeof(m_sTemp));
    sprintf(m_sTemp, "szCmd=[%s]��\nszResult=[\n%s]", szCmd,szResult); 
    Log(_DEBUGLOG, m_sTemp); 

	Log(_INFOLOG, "Info: exit CDelRecvSmp702::tranAcct.");	
}

int CDelRecvSmp702::createAcctF(CString &sDirPath, CString &sFileName)
{
    Log(_INFOLOG, "Info: into CDelRecvSmp702::createAcctF.");
	IsUser oIsUser;
    CString strFindSql;
	CString strBody;
	int iCount = 0;
	CString strHead;
	CString strTail;
	CString strContent;
	CString strPersonID;
	CString strUserState;
	char szPath[200]={0};
	time_t timep;
	struct tm *p;
	time(&timep);
	p = gmtime(&timep);
	FILE* msgFile = NULL;	
	int iRet = -1;
	
    strFindSql.Format(" where 1=1 ");
	memset(m_sTemp, 0, sizeof(m_sTemp));
	sprintf(m_sTemp, "strFindSql=[%s]",	strFindSql.GetBuffer(0)); 
	Log(_DEBUGLOG, m_sTemp); 

    //��ѯ��¼
	iRet = oIsUser.find(strFindSql);
    if (iRet != 0)
    {
        oIsUser.closeCursor();
	    memset(m_sTemp, 0, sizeof(m_sTemp));
        sprintf(m_sTemp, "����smp_isuser��ʧ�ܣ�iRet=[%d]", 	    iRet); 
        Log(_DEBUGLOG, m_sTemp); 
    }
    else
    {
	    iRet = oIsUser.fetch();
	    while(iRet == 0)
	    {
	        strPersonID = oIsUser.cbuserid.Left(8);
	        // ��ȡԱ��ID
	        if (TRUE != strPersonID.IsDigit() ||
				strPersonID.GetLength() < 8)
	        {
			    //strPersonID = "";
			    iRet = oIsUser.fetch();
				continue;
			}
			
	        // ��ȡ�˻�״̬,01/02ת��'Active',����ת��'Disable'
	        if (0 == oIsUser.cbuserstate.CompareN("01",2) ||
				0 == oIsUser.cbuserstate.CompareN("02",2) )
	        {
	            strUserState = "Active";
	        }
			else
			{
			    strUserState = "Disable";
			}

	        // �˻�id,Ա��id,firsrname,middlename,lastname,
	        // ����¼����,��������,�û�����,�˺�״̬,�����˺�״̬,
	        // ϵͳid,ϵͳ����,ϵͳȨ��		
	        strBody = strBody+oIsUser.cbuserid+","+strPersonID+","+ \
	                  oIsUser.cbusername+",,,"+oIsUser.cblogontime+\
	                  ","+oIsUser.cbaffecttime+",User,"+strUserState+ \
	                  ","+oIsUser.cbuserstate+",HBAP-CN-A-HTSAHBCNSMPS-01,HBCN,CN\n";

	        iCount ++;
	        iRet = oIsUser.fetch();
	    }
		oIsUser.closeCursor();
    }

    //���ļ�ͷ
    strHead.Format("%s","account_id,person_id,native_first_name,native_middle_name," \
	                    "native_last_name,last_login_timestamp,creation_timestamp,"  \
	                    "account_type,account_status,native_account_status,system_id," \
	                    "system_region,system_entity\n");

    //���ļ�β
	strTail.Format("TRAILER,%02d%02d%d%02u%02u%02u,%d",
	               p->tm_mon + 1, p->tm_mday, p->tm_year + 1900, 
	               p->tm_hour,p->tm_min,p->tm_sec,iCount);

    //���ļ���
	sFileName.Format("HBAP-CN-A-HTSAHBCNSMPS-01.acct.%d%02d%02d%02u%02u%02u.csv",
	                 p->tm_year + 1900, p->tm_mon + 1, p->tm_mday,  
	                 p->tm_hour,p->tm_min,p->tm_sec);

    //���ļ�����
	strContent = strContent+strHead+strBody+strTail;

    //�����ļ���д����
    sprintf(szPath,"%s%s",sDirPath.GetBuffer(0),sFileName.GetBuffer(0));
	msgFile = fopen(szPath, "w+");
	if (NULL != msgFile)
    {
        fprintf(msgFile, "%s", strContent.GetBuffer(0));
        fclose(msgFile);
    }
    else
    {
		return -1;
    }	
	
	Log(_INFOLOG, "Info: exit CDelRecvSmp702::createAcctF.");
	return 0;
}

int CDelRecvSmp702::createAcctRoleF(CString &sDirPath, CString &sFileName)	
{
    Log(_INFOLOG, "Info: into CDelRecvSmp702::createAcctRoleF.");
	IsUser oIsUser;
    CString strFindSql;
	CString strBody;
	int iCount = 0;
	CString strHead;
	CString strTail;
	CString strContent;
	CString strUserGroupID;
	CString strRoleName;
	CString strPersonID;
	char szPath[200]={0};
	time_t timep;
	struct tm *p;
	time(&timep);
	p = gmtime(&timep);
	FILE* msgFile = NULL;	
	int iRet = -1;
	
    strFindSql.Format(" where 1=1 ");
	memset(m_sTemp, 0, sizeof(m_sTemp));
	sprintf(m_sTemp, "strFindSql=[%s]",	strFindSql.GetBuffer(0)); 
	Log(_DEBUGLOG, m_sTemp); 

    //��ѯ��¼
	iRet = oIsUser.find(strFindSql);
    if (iRet != 0)
    {
        oIsUser.closeCursor();
	    memset(m_sTemp, 0, sizeof(m_sTemp));
        sprintf(m_sTemp, "����smp_isuser��ʧ�ܣ�iRet=[%d]", 	    iRet); 
        Log(_DEBUGLOG, m_sTemp); 
    }
    else
    {
	    iRet = oIsUser.fetch();
	    while(iRet == 0)
	    {
	        strPersonID = oIsUser.cbuserid.Left(8);
	        // ��ȡԱ��ID
	        if (TRUE != strPersonID.IsDigit() ||
				strPersonID.GetLength() < 8)
	        {
			    //strPersonID = "";
			    iRet = oIsUser.fetch();
				continue;
			}
			
	        // �����û���id��ȡ�û�������
	        strUserGroupID = oIsUser.usergroupid;
			GetRoleName(strUserGroupID, strRoleName);
	        // �˻�id,ϵͳid,�˻���Դ,Ȩ������,
	        // ϵͳ����,Ȩ��,����
	        strBody = strBody+oIsUser.cbuserid+",HBAP-CN-A-HTSAHBCNSMPS-01,System,P,"+ \
	                  strRoleName+",,\n";

	        iCount ++;
	        iRet = oIsUser.fetch();
	    }
		oIsUser.closeCursor();
    }

    //���ļ�ͷ
    strHead.Format("%s","account_id,system_id,account_source,entitlement_type," \
	                    "system_profile,entitlement,action\n");

    //���ļ�β
	strTail.Format("TRAILER,%02d%02d%d%02u%02u%02u,%d",
		           p->tm_mon + 1, p->tm_mday, p->tm_year + 1900, 
	               p->tm_hour,p->tm_min,p->tm_sec,iCount);

    //���ļ���
	sFileName.Format("HBAP-CN-A-HTSAHBCNSMPS-01.enti.%d%02d%02d%02u%02u%02u.csv",
		             p->tm_year + 1900, p->tm_mon + 1, p->tm_mday, 
	                 p->tm_hour,p->tm_min,p->tm_sec);

    //���ļ�����
	strContent = strContent+strHead+strBody+strTail;

    //�����ļ���д����
    sprintf(szPath,"%s%s",sDirPath.GetBuffer(0),sFileName.GetBuffer(0));
	msgFile = fopen(szPath, "w+");
	if (NULL != msgFile)
    {
        fprintf(msgFile, "%s", strContent.GetBuffer(0));
        fclose(msgFile);
    }
    else
    {
		return -1;
    }

	Log(_INFOLOG, "Info: exit CDelRecvSmp702::createAcctRoleF.");
	return 0;
}

int CDelRecvSmp702::createRoleF(CString &sDirPath, CString &sFileName)
{
    Log(_INFOLOG, "Info: into CDelRecvSmp702::createRoleF.");
	UserGroup oUserGroup;
	FuncList oFuncList;
    CString strFindSql;
	CString strBody;
	int iCount = 0;
	CString strHead;
	CString strTail;
	CString strContent;
	CString strUserGroupID;
	CString strRoleName;
	CString strUserGroupRight;
	CString strFuncID;
	CString strFuncButton;
	char szPath[200]={0};
	time_t timep;
	struct tm *p;
	time(&timep);
	p = gmtime(&timep);
	FILE* msgFile = NULL;	
	int iRet = -1;
	
    strFindSql.Format(" where 1=1 ");
	memset(m_sTemp, 0, sizeof(m_sTemp));
	sprintf(m_sTemp, "strFindSql=[%s]",	strFindSql.GetBuffer(0)); 
	Log(_DEBUGLOG, m_sTemp); 

    //��ѯ��¼
	iRet = oUserGroup.find(strFindSql);
    if (iRet != 0)
    {
        oUserGroup.closeCursor();
	    memset(m_sTemp, 0, sizeof(m_sTemp));
        sprintf(m_sTemp, "����smp_usergroup��ʧ�ܣ�iRet=[%d]", 	    iRet); 
        Log(_DEBUGLOG, m_sTemp); 
    }
    else
    {
	    iRet = oUserGroup.fetch();
	    while(iRet == 0)
	    {
	        // �����û���id��ȡ�û�������
	        strUserGroupID = oUserGroup.usergroupid;
			GetRoleName(strUserGroupID, strRoleName);
			// �û���Ȩ��
			strUserGroupRight = oUserGroup.usergroupright;
		    // ��ʽ����ɫȨ���ֶΣ������ڲ˵����в�ѯ
			strUserGroupRight.TrimLeftChar('#');
			strUserGroupRight.Replace("#", "','");
			strFindSql = "where cbdisplaycode in ('"+strUserGroupRight+"')";
			memset(m_sTemp, 0, sizeof(m_sTemp));
			sprintf(m_sTemp, "strFindSql=[%s]", strFindSql.GetBuffer(0)); 
			Log(_DEBUGLOG, m_sTemp); 
            #if 1
			iRet = oFuncList.find(strFindSql);
			if (iRet != 0)
			{
				oFuncList.closeCursor();
				memset(m_sTemp, 0, sizeof(m_sTemp));
				sprintf(m_sTemp, "����smp_funclist��ʧ�ܣ�iRet=[%d]",		iRet); 
				Log(_DEBUGLOG, m_sTemp); 
			}
			else
			{
			    iRet = oFuncList.fetch();
			    while(iRet == 0)
				{
					// �����û���id��ȡ�û�������
					strFuncID = oFuncList.cbdisplaycode;
					GetFuncButton(strFuncID, strFuncButton);
			        // ϵͳid,ϵͳ����,��ȫ��������,ϵͳ������,Ȩ��,����
			        strBody = strBody+"HBAP-CN-A-HTSAHBCNSMPS-01,"+strRoleName+",E,,"+ \
			                  oFuncList.cbdesc+","+strFuncButton+"\n";

			        iCount ++;
					iRet = oFuncList.fetch();
				}
			    oFuncList.closeCursor();
            }
			#endif
			
	        iRet = oUserGroup.fetch();
	    }
		oUserGroup.closeCursor();
   	}

    //���ļ�ͷ
    strHead.Format("%s","system_id,system_profile,security_definition_type," \
	                    "system_profile_child,entitlement,action\n");

    //���ļ�β
	strTail.Format("TRAILER,%02d%02d%d%02u%02u%02u,%d",
		           p->tm_mon + 1, p->tm_mday, p->tm_year + 1900, 
	               p->tm_hour,p->tm_min,p->tm_sec,iCount);

    //���ļ���
	sFileName.Format("HBAP-CN-A-HTSAHBCNSMPS-01.smod.%d%02d%02d%02u%02u%02u.csv",
		             p->tm_year + 1900, p->tm_mon + 1, p->tm_mday, 
	                 p->tm_hour,p->tm_min,p->tm_sec);

    //���ļ�����
	strContent = strContent+strHead+strBody+strTail;

    //�����ļ���д����
    sprintf(szPath,"%s%s",sDirPath.GetBuffer(0),sFileName.GetBuffer(0));
	msgFile = fopen(szPath, "w+");
	if (NULL != msgFile)
    {
        fprintf(msgFile, "%s", strContent.GetBuffer(0));
        fclose(msgFile);
    }
    else
    {
		return -1;
    }

	Log(_INFOLOG, "Info: exit CDelRecvSmp702::createRoleF.");
	return 0;
}


void CDelRecvSmp702::GetRoleName(CString &strRoleID,CString &strRoleName)
{
	//Log(_INFOLOG, "Info: into CDelRecvSmp702::GetRoleName.");

	if (0 == strRoleID.CompareN("001",3))
	{
		strRoleName = "Business Manager";
	}
	else if (0 == strRoleID.CompareN("002",3))
	{
		strRoleName = "Business Operator";
	}
	else if (0 == strRoleID.CompareN("101",3))
	{
		strRoleName = "System Operator";
	}
	else if (0 == strRoleID.CompareN("100",3))
	{
		strRoleName = "System Manager";
	}
	else
	{
		strRoleName = "TestUser";
	}
	//Log(_INFOLOG, "Info: exit CDelRecvSmp702::GetRoleName.");
	return;
}

void CDelRecvSmp702::GetFuncButton(CString &strFuncID,CString &strButton)
{
	//Log(_INFOLOG, "Info: into CDelRecvSmp702::GetFuncButton.");

	if (0 == strFuncID.CompareN("101",3) ||
		0 == strFuncID.CompareN("102",3) ||
		0 == strFuncID.CompareN("105",3) ||
		0 == strFuncID.CompareN("107",3) ||
		0 == strFuncID.CompareN("109",3) ||
		0 == strFuncID.CompareN("201",3) ||
		0 == strFuncID.CompareN("203",3) ||
		0 == strFuncID.CompareN("212",3) ||
		0 == strFuncID.CompareN("601",3) ||
		0 == strFuncID.CompareN("602",3) ||
		0 == strFuncID.CompareN("A0" ,2) ||
		0 == strFuncID.CompareN("A10",3) ||
		0 == strFuncID.CompareN("B01",3) ||
		0 == strFuncID.CompareN("B02",3) ||
		0 == strFuncID.CompareN("B03",3) ||
		0 == strFuncID.CompareN("B04",3) ||
		0 == strFuncID.CompareN("B05",3) ||
		0 == strFuncID.CompareN("B06",3) ||
		0 == strFuncID.CompareN("B07",3) )
	{
		strButton = "Input Payment";
	}
	else if (0 == strButton.CompareN("111",3) ||
		     0 == strButton.CompareN("112",3) ||
		     0 == strFuncID.CompareN("A11",3) ||
			 0 == strFuncID.CompareN("A12",3) ||
			 0 == strFuncID.CompareN("A13",3) ||
			 0 == strFuncID.CompareN("A14",3) ||
			 0 == strFuncID.CompareN("A15",3) ||
			 0 == strFuncID.CompareN("A16",3) ||
		     0 == strFuncID.CompareN("A17",3) ||
			 0 == strFuncID.CompareN("A18",3) ||
			 0 == strFuncID.CompareN("A19",3) ||
			 0 == strFuncID.CompareN("A20",3) ||
			 0 == strFuncID.CompareN("B08",3) ||
		     0 == strFuncID.CompareN("B09",3) ||
			 0 == strFuncID.CompareN("B10",3) ||
			 0 == strFuncID.CompareN("B11",3) )
	{
		strButton = "Check Payment";
	}
	else if (0 == strButton.CompareN("5",1) ||
		     0 == strButton.CompareN("D",1))
	{
		strButton = "Daily Report";
	}
	else if (0 == strButton.CompareN("C",1) ||
		     0 == strButton.CompareN("9",1))
	{
		strButton = "System Managment";
	}
	else
	{
		strButton = "Query";
	}
	//Log(_INFOLOG, "Info: exit CDelRecvSmp702::GetFuncButton.");
	return;
}
//add end



