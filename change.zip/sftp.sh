#!/bin/sh
#IP="172.26.188.82"
#USER="abis"
RouteAddress="iamtkofiles-uat.hk.hsbc"
LocalAddress="192.168.1.113"
USER="grmrdata"
PORT="10022"
SRCFILE=$1
TGTFILE=/tmp

TMPFILE=tmpfile

#echo "sftp $USER@$IP" > $TMPFILE
#echo "cd /tmp" >>$TMPFILE
echo "put $SRCFILE $TGTFILE" >> $TMPFILE
echo "bye" >> $TMPFILE

sftp -b $TMPFILE -oBindAddress=$LocalAddress -oPort=$PORT $USER@$RouteAddress
if [ $? = 0 ]
then
	echo "sftp Ok"
	rm -f $TMPFILE
	exit 0 
else
	echo "sftp error"
	#rm -f $TMPFILE
	exit -1
fi

