/******************************************************************** 
文件名： sendcmt328.cpp
创建人： handongfeng
日  期： 2011-04-18
修改人： 
日  期： 
描  述： 小额借记止付往帐328报文处理类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt328.h"

using namespace ZFPT;

CSendCmt328::CSendCmt328(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{
}

CSendCmt328::~CSendCmt328()
{
}

INT32 CSendCmt328::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt328::doWorkSelf");

    /*从业务表中获取数据*/
    GetData();

    buildPmtsMsg();
    
    UpdateDb();

    if(RTN_SUCCESS == strcmp("1", m_cmt328.sFlag))
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "状态为已止付,更新原业务的汇总表");	
        UpdateState();   
    }
    
	AddQueue(m_cmt328.m_strCmtmsg.c_str(), m_cmt328.m_strCmtmsg.length());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt328::doWorkSelf"); 
    return 0;
}

int CSendCmt328::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt328::getData");

	SETCTX(m_cBpcstbdpcxlcl);
    
  	m_cBpcstbdpcxlcl.m_instgdrctpty = m_szSndNO;
  	m_cBpcstbdpcxlcl.m_msgid        = m_szMsgFlagNO;
  	
  	int iRet = m_cBpcstbdpcxlcl.findByPK();

  	if (SQLNOTFOUND == iRet)
	{
		sprintf(m_sErrMsg, "找不到指定业务[%s], [%s], [%d][%s]", 
		    m_szSndNO, m_szMsgFlagNO, iRet, m_cBpcstbdpcxlcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	} 	
	else if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg, "查询汇总表发生错误[%s], [%s], [%d][%s]",
		    m_szSndNO, m_szMsgFlagNO, iRet, m_cBpcstbdpcxlcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}

    SETCTX(m_OrgncBpcstbdpcxlcl);
  	m_OrgncBpcstbdpcxlcl.m_instgdrctpty = m_cBpcstbdpcxlcl.m_osqinstgpty;
  	m_OrgncBpcstbdpcxlcl.m_msgid        = m_cBpcstbdpcxlcl.m_osqlmsgid;
  	
  	iRet = m_OrgncBpcstbdpcxlcl.findByPK();
  	if (SQLNOTFOUND == iRet)
	{
		sprintf(m_sErrMsg, "找不到指定业务[%s], [%s], [%d][%s]", 
		    m_szSndNO, m_szMsgFlagNO, iRet, m_OrgncBpcstbdpcxlcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	} 	
	else if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg, "查询汇总表发生错误[%s], [%s], [%d][%s]",
		    m_szSndNO, m_szMsgFlagNO, iRet, m_OrgncBpcstbdpcxlcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}

  	if("0" == m_OrgncBpcstbdpcxlcl.m_grpcxlid)
    {
        SETCTX(m_cOrgnBpcstbdpcxllist);
        m_cOrgnBpcstbdpcxllist.m_msgid = m_OrgncBpcstbdpcxlcl.m_msgid;
        m_cOrgnBpcstbdpcxllist.m_instgpty = m_OrgncBpcstbdpcxlcl.m_instgdrctpty ;

        string strSQL = "MSGID = '" + m_cOrgnBpcstbdpcxllist.m_msgid + "' and INSTGDRCTPTY = '" + m_cOrgnBpcstbdpcxllist.m_instgpty + "'";
        iRet = m_cOrgnBpcstbdpcxllist.find(strSQL);
        if (SQL_SUCCESS != iRet) 
    	{
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "查询借记业务止付明细表发生错误[%s], [%s], [%d][%s]", 
    		        m_cOrgnBpcstbdpcxllist.m_msgid.c_str(), m_cOrgnBpcstbdpcxllist.m_instgpty.c_str(), iRet, m_cOrgnBpcstbdpcxllist.GetSqlErr());
    		PMTS_ThrowException(DB_NOT_FOUND);
    	}

    	int iRetCode = m_cOrgnBpcstbdpcxllist.fetch();	
    	if (SQLNOTFOUND == iRetCode) 
    	{
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL,  "找不到指定业务[%s], [%s], [%d][%s]", 
    		                                            m_cOrgnBpcstbdpcxllist.m_msgid.c_str(), 
    		                                            m_cOrgnBpcstbdpcxllist.m_instgpty.c_str(), 
    		                                            iRet, 
    		                                            m_cOrgnBpcstbdpcxllist.GetSqlErr());
    		
    		PMTS_ThrowException(DB_NOT_FOUND);		
    	}	    
    }
    
    SETCTX(m_cBpbdrcvcl);
    
    m_cBpbdrcvcl.m_msgid        = m_OrgncBpcstbdpcxlcl.m_orgnlmsgid;
    m_cBpbdrcvcl.m_instgdrctpty = m_OrgncBpcstbdpcxlcl.m_orgnlinstgpty;

    iRet = m_cBpbdrcvcl.findByPK();
    if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg, "查询借记业务汇总表发生错误[%s], [%s], [%d][%s]",
		    m_cBpbdrcvcl.m_msgid.c_str(), m_cBpbdrcvcl.m_instgdrctpty.c_str(), iRet, m_cBpbdrcvcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}
        
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt328::getData"); 
    
	return iRet;
}

int CSendCmt328::buildPmtsMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt328::buildPmtsMsg");

    char sTemp[128]  = {0};
    char szOrgDate[8+1]={0};
    char szOrgTxss[8+1]={0};
    string strTemp = "";

	SETCTX(m_cBpcstbdpcxlcl);
    
    strncpy(szOrgDate, m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(), sizeof(szOrgDate)-1);
    strncpy(szOrgTxss, m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str() + 8, sizeof(szOrgTxss)-1);

    //char SndCCPCNode[30] 	= {0};	
	//TranSapBkToCCPCCode(m_dbproc, m_cBpcstbdpcxlcl.m_instgdrctpty.c_str(), SndCCPCNode);

    strcpy(m_cmt328.sConsigndate, m_cBpcstbdpcxlcl.m_consigdate.c_str());        //委托日期   8n         M
    strcpy(m_cmt328.sOldrecvsapbk, m_cBpbdrcvcl.m_instgdrctpty.c_str());      //止付应答清算行 = 原包接收清算行     12n        M
    strcpy(m_cmt328.sOldrecvbank, m_cBpcstbdpcxlcl.m_instgpty.c_str());       //止付应答行 = 原业务接收行     12n        O
    strcpy(m_cmt328.sRecvmssno, m_szMsgSerial);          //止付应答序号             8n         M
    strcpy(m_cmt328.sOldconsigndate, m_OrgncBpcstbdpcxlcl.m_consigdate.c_str());     //原止付申请委托日期       8n         O	
    strcpy(m_cmt328.sOldsendsapbk, m_cBpbdrcvcl.m_instddrctpty.c_str());      //原止付申请清算行 = 原包发起清算行     12n        M
    strcpy(m_cmt328.sOldsendbank,  m_cBpcstbdpcxlcl.m_instdpty.c_str());       //原止付申请行 = 原业务发起行     12n       O
    strcpy(m_cmt328.sOldsendmssno, szOrgTxss) ;       //原止付申请序号       8n         M
    strcpy(m_cmt328.sOldpacktype, m_OrgncBpcstbdpcxlcl.m_grpcxlid.c_str());
    //m_cmt328.sTextkey= m_cBpcstbdpcxlcl. ;           //密押               40x        O                              

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstbdpcxlcl.m_stoppmtsts=%s", m_cBpcstbdpcxlcl.m_stoppmtsts.c_str());
    strcpy(m_cmt328.sFlag , m_cBpcstbdpcxlcl.m_stoppmtsts.c_str());
    //m_cmt328.sRemark= m_cBpcstbdpcxlcl. ;            //止付申请附言           60g        O   
    
    int iRet = m_cmt328.CreateCmt("328",
                           	  m_cBpcstbdpcxlcl.m_instgdrctpty.c_str(),
                           	  m_cBpcstbdpcxlcl.m_instddrctpty.c_str(),
                           	  m_sMesgId.c_str(),
                           	  m_sMesgId.c_str(), 
                           	  m_cBpcstbdpcxlcl.m_workdate.c_str(),
                           	  "0");
    if (0 != iRet)
    {
		sprintf(m_sErrMsg, "Create msg Error!iRet[%d]", iRet);

		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, m_sErrMsg); 
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt328::buildPmtsMsg");
    return 0;   
}

int CSendCmt328::UpdateState(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendCmt328::UpdateDb");

    int iRet = 0;
    string strSQL;
    if("1" == m_OrgncBpcstbdpcxlcl.m_grpcxlid)
    {
        SETCTX(m_cBpbdrcvcl);
    	strSQL += "UPDATE bp_BDRCVCL t SET t.Procstate = '";
        strSQL += PR_HVBP_23;
        strSQL += "', t.BusiState = '";
        strSQL += PROCESS_PR21;
    	strSQL += "', t.STATETIME = sysdate WHERE t.msgid = '";
    	strSQL += m_cBpbdrcvcl.m_msgid;
    	strSQL += "' AND t.INSTGDRCTPTY = '";
    	strSQL += m_cBpbdrcvcl.m_instgdrctpty;
    	strSQL += "'";
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    	
        iRet = m_cBpbdrcvcl.execsql(strSQL);
        if (iRet != SQL_SUCCESS)
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL, "更新表失败[%d][%s]", iRet, m_cBpbdrcvcl.GetSqlErr());
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "更新表失败");
		}
		
        SETCTX(m_cBpbdrecvlist);
        strSQL = "";
    	strSQL += "UPDATE bp_bdrecvlist t SET t.Procstate = '23', t.BusiState = 'PR21'";
    	strSQL += " WHERE t.msgid = '";
    	strSQL += m_cBpbdrcvcl.m_msgid;
    	strSQL += "' AND t.INSTGDRCTPTY = '";
    	strSQL += m_cBpbdrcvcl.m_instgdrctpty;    	
    	strSQL += "'";
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    	
    	iRet = m_cBpbdrecvlist.execsql(strSQL);
        if (iRet != SQL_SUCCESS)
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL, "更新表失败[%d][%s]", iRet, m_cBpbdrecvlist.GetSqlErr());
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "更新表失败");
		}
		    	
	}
    else
    {
        SETCTX(m_cBpbdrecvlist);
        strSQL = "";
    	strSQL += "UPDATE bp_bdrecvlist t SET t.Procstate = '23', t.BusiState = 'PR21'";
    	strSQL += " WHERE t.TxId = '";
    	strSQL += m_cOrgnBpcstbdpcxllist.m_orgnlpmtinfid;
    	strSQL += "' AND t.INSTGDRCTPTY = '";
    	strSQL += m_cBpbdrcvcl.m_instgdrctpty;
    	strSQL += "' AND t.msgid = '";
    	strSQL += m_cBpbdrcvcl.m_msgid;    	
    	strSQL += "'";
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    	
    	iRet = m_cBpbdrecvlist.execsql(strSQL);
        if (iRet != SQL_SUCCESS)
		{
			Trace(L_ERROR, __FILE__, __LINE__, NULL, "更新表失败[%d][%s]", iRet, m_cBpbdrecvlist.GetSqlErr());
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "更新表失败");
		}
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendCmt328::UpdateDb");
    return RTN_SUCCESS;
}

void CSendCmt328::UpdateDb(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendCmt328::UpdateDb");

	string strSQL;
	int iRet = -1;

	strSQL += "UPDATE bp_CstBdPCxlCl t SET t.Procstate = '04', t.StopPmtSts = '";
	strSQL += m_cmt328.sFlag;
	strSQL += "' ";	
	strSQL += " WHERE t.msgid = '";
	strSQL += m_cBpcstbdpcxlcl.m_msgid;
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_cBpcstbdpcxlcl.m_instgdrctpty; 
	strSQL += "'";
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, strSQL.c_str());
	
    SETCTX(m_cBpcstbdpcxlcl);
	iRet = m_cBpcstbdpcxlcl.execsql(strSQL.c_str());
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL, "Update failed, sqlcode=[%d]", iRet);
	}
	else if (iRet != SQL_SUCCESS)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "更新表失败[%d][%s]",
		    iRet, m_cBpcstbdpcxlcl.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "更新表失败");
	}

    strSQL = "";
	strSQL += "UPDATE bp_CstBdPCxlCl t SET t.Procstate = '04', t.StopPmtSts = '";
	strSQL += m_cmt328.sFlag;
	strSQL += "' ";	
	strSQL += " WHERE t.msgid = '";
	strSQL += m_OrgncBpcstbdpcxlcl.m_msgid;
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_OrgncBpcstbdpcxlcl.m_instgdrctpty; 
	strSQL += "'";
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, strSQL.c_str());
	
    SETCTX(m_OrgncBpcstbdpcxlcl);
	iRet = m_OrgncBpcstbdpcxlcl.execsql(strSQL.c_str());
	if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL, "Update failed, sqlcode=[%d]", iRet);
	}
	else if (iRet != SQL_SUCCESS)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "更新表失败[%d][%s]",
		    iRet, m_OrgncBpcstbdpcxlcl.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "更新表失败");
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendCmt328::UpdateDb");

	return ;
}

