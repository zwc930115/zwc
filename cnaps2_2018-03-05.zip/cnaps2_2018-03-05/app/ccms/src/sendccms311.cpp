/********************************************************************
�ļ�����sendccms311.cpp
�����ˣ�aps-lel
��  �ڣ�2011.04.02
��  ����ͨ�÷�ǩ����Ϣҵ��Ӧ����
��  ����
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendccms311.h"


CSendCcms311::CSendCcms311(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{

}

CSendCcms311::~CSendCcms311()
{

}

int CSendCcms311::doWorkSelf()
{
   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms311::doWork...");

    int iRet = 0;

    GetData();

    SetData();
	
    iRet = m_ccms311.CreateXml();
	
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    UpdateState();
    
    //�����յ�������ҵ��
    //UpdateOriTrade();
    
   AddQueue( m_ccms311.m_sXMLBuff.c_str(), m_ccms311.m_sXMLBuff.length());
   
   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms311::doWork..."); 
	
    return RTN_SUCCESS;
}

void CSendCcms311::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms311::SetDBKey...");
     
	m_Cmcnotsgninfbiz.m_msgid = m_szMsgFlagNO; 
	m_Cmcnotsgninfbiz.m_instgpty = m_szSndNO; 
	m_Cmcnotsgninfbiz.m_srcflag = m_szSrcflg;
	m_Cmcnotsgninfbiz.m_syscd    = m_szSysFlagNO;     //ϵͳID  
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgFlagNO = %s", m_szMsgFlagNO);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndNO = %s", m_szSndNO);
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms311::SetDBKey...");
    return;
}

void CSendCcms311::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms311::SetData...");
    
	int iSysflg = -1;
    int iRet = -1;
    chgSysCd(m_szSysFlagNO,iSysflg); 
    iRet = GetIsoDateTime(m_dbproc, iSysflg, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_ISODateTime = %s", m_ISODateTime);
	 
    char szSyscd[4+1] = {0};
    strcpy(szSyscd,m_Cmcnotsgninfbiz.m_syscd.c_str());
    StrUpperCase_ZFPT(szSyscd);
    
    // ���ļ�ͷ
    m_ccms311.CreateXMlHeader(szSyscd,                        \
                                m_Cmcnotsgninfbiz.m_workdate.c_str(), \
                                m_Cmcnotsgninfbiz.m_instgdrctpty.c_str(),\
                                m_Cmcnotsgninfbiz.m_instddrctpty.c_str(),\
                                "ccms.311.001.01",              \
                                m_sMesgId.c_str()); 
   //����С��ʱ�����������뷢��ֱ�Ӳ������Ҫ�ر��뱣��һ�£���д����ֱ�Ӳ��������
   //����С��ʱ���ղ�����������ֱ�Ӳ������Ҫ�ر��뱣��һ�£���д����ֱ�Ӳ��������
   

	m_ccms311.InstgDrctPty                  = m_Cmcnotsgninfbiz.m_instgdrctpty; //����ֱ�Ӳ������
	m_ccms311.GrpHdrInstgPty                = m_Cmcnotsgninfbiz.m_instgpty;     //����������
	m_ccms311.InstdDrctPty                  = m_Cmcnotsgninfbiz.m_instddrctpty; //����ֱ�Ӳ������
	m_ccms311.GrpHdrInstdPty                = m_Cmcnotsgninfbiz.m_instdpty;     //���ղ������

	m_ccms311.MsgId                         = m_Cmcnotsgninfbiz.m_msgid;        //���ı�ʶ��    
	m_ccms311.CreDtTm                       = m_ISODateTime;                    //���ķ���ʱ��
	
	m_ccms311.SysCd                         = m_Cmcnotsgninfbiz.m_syscd;	  	//ϵͳ���
	m_ccms311.Rmk                           = m_Cmcnotsgninfbiz.m_rmk;		    //��ע
	m_ccms311.OrgnlMsgId                    = m_Cmcnotsgninfbiz.m_orgnlmsgid;	//ԭ���ı�ʶ��
	m_ccms311.OrgnlInstgPty                 = m_Cmcnotsgninfbiz.m_orgnlinstgpty;//ԭ����������
	m_ccms311.OrgnlMT                       = m_Cmcnotsgninfbiz.m_orgnlmt;
	m_ccms311.Sts                           = m_Cmcnotsgninfbiz.m_status;	    //ҵ��״̬
	m_ccms311.RjctCd                        = m_Cmcnotsgninfbiz.m_rjctcd;
	m_ccms311.RjctInf                       = m_Cmcnotsgninfbiz.m_rjctinf;
	m_ccms311.PrcPty                        = m_Cmcnotsgninfbiz.m_rjcprcpty;	
	m_ccms311.OrgnlTxTpCd                   = m_Cmcnotsgninfbiz.m_txtpcd;	    //ԭҵ�����ͱ���
	
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms311::SetData...");
    m_Cmcnotsgninfbiz.closeCursor();
    return;
}

int CSendCcms311::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms311::GetData...");
	
	SETCTX(m_Cmcnotsgninfbiz);
	
    SetDBKey();
	/*
	char strSql[1024]={0};
    sprintf(strSql ,"INSTGPTY='%s' and MSGID='%s' and srcflag='%s' "
                    ,m_Cmcnotsgninfbiz.m_instgpty.c_str()
                    ,m_Cmcnotsgninfbiz.m_msgid.c_str()
                    ,m_Cmcnotsgninfbiz.m_srcflag.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=[%s]",strSql);
	int iRet = m_Cmcnotsgninfbiz.find(strSql);
	if(0 != iRet)
	{
		sprintf( m_sErrMsg,"find error,error code =[%d] error cause = [%s]",iRet,m_Cmcnotsgninfbiz.GetSqlErr());
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_sErrMsg);
		PMTS_ThrowException(__FILE__,__LINE__,DB_NOT_FOUND,m_sErrMsg);
	}
	iRet = m_Cmcnotsgninfbiz.fetch();
	if(iRet ==SQLNOTFOUND)
	{
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������");
        m_Cmcnotsgninfbiz.closeCursor();
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "m_Cmcnotsgninfbizû���ҵ�����������ԭҵ��");
	}
	
    int iRet = m_Cmcnotsgninfbiz.findByPK();
   
	if(RTN_SUCCESS != iRet)
	{
	   sprintf( m_sErrMsg,"findByPK() error,error code =[%d] error cause = [%s]",iRet,m_Cmcnotsgninfbiz.GetSqlErr());
	   Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_sErrMsg);
	   PMTS_ThrowException(__FILE__,__LINE__,DB_NOT_FOUND,m_sErrMsg);
			
	}
	*/
	
	int iRet = m_Cmcnotsgninfbiz.findByPK();
	if(RTN_SUCCESS != iRet)
	{
	    m_Cmcnotsgninfbiz.m_srcflag = "0";
	    iRet = m_Cmcnotsgninfbiz.findByPK();
    	if(0 != iRet)
    	{
    		sprintf( m_sErrMsg,"findByPK() error,error code =[%d] error cause = [%s]",iRet,m_Cmcnotsgninfbiz.GetSqlErr());
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_sErrMsg);
    		PMTS_ThrowException(__FILE__,__LINE__,DB_NOT_FOUND,m_sErrMsg);
        }
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms311::GetData...");
	
    return iRet;
}

int CSendCcms311::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms311::UpdateState...");
	
	SETCTX(m_Cmcnotsgninfbiz);
    SetDBKey();
    string strSQL;
	strSQL += "UPDATE cm_cnotsgninfbiz  t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_08;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
    strSQL += "' , t.PROCTIME = sysdate ";    
	strSQL += " WHERE t.MSGID = '";
	strSQL += m_Cmcnotsgninfbiz.m_msgid.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_Cmcnotsgninfbiz.m_instgpty.c_str(); 									
	strSQL += "' AND t.SRCFLAG = '";
	strSQL += m_szSrcflg;
	strSQL += "' ";
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	
	int iRet = m_Cmcnotsgninfbiz.execsql(strSQL.c_str());
	
    if(RTN_SUCCESS != iRet)
    {	  
	   sprintf( m_sErrMsg,"execsql() error,error code =[%d] error cause = [%s]",iRet,m_Cmcnotsgninfbiz.GetSqlErr());
	   Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_sErrMsg);
	   PMTS_ThrowException(__FILE__,__LINE__,DB_UPDATE_FAIL,m_sErrMsg);

    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms311::UpdateState...");
	
    return RTN_SUCCESS;
}

void CSendCcms311::UpdateOriTrade()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendCcms311::UpdateOriTrade...");

    //�����յ�������ҵ��
    SETCTX(m_Cmcnotsgninfbiz);
    string strSQL;
	strSQL = "UPDATE CM_CNOTSGNINFBIZ t SET ";
	strSQL += "t.PROCSTATE = '";
    strSQL += PR_HVBP_07;	
    strSQL += "' , t.PROCTIME = sysdate ";   
	strSQL += " WHERE t.MSGID = '";
	strSQL += m_ccms311.OrgnlMsgId.c_str();
    strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_ccms311.OrgnlInstgPty.c_str();	
    strSQL += "' AND t.SRCFLAG = '";
	strSQL += SRC_FRCNAPS;
	strSQL += "'";
   
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSQL = [%s]", strSQL.c_str());
    
	int iRet = m_Cmcnotsgninfbiz.execsql(strSQL.c_str());
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
            "UdateState Failed!  iRet=%d, %s", iRet, m_Cmcnotsgninfbiz.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }
        
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendCcms311::UpdateOriTrade...");
}



