/******************************************************************** 
�ļ����� recvcmt910.cpp
�����ˣ� hhc
��  �ڣ� 2012-04-26
�޸��ˣ� 
��  �ڣ� 
��  ���� ������˴���
��  ���� 
Copyright (c) 2012  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvcmt910.h"
#include "hvsndexchglist.h"
#include "hvtrofacsndlist.h"
#include "cmtransinfoqry.h"
#include "cmfreeinfo.h"

using namespace ZFPT;

CRecvCmt910::CRecvCmt910()
{
    m_strMsgTp = "CMT910";
    m_strMesgID = "";
    m_strTableName = "";
}

CRecvCmt910::~CRecvCmt910()
{

}

INT32 CRecvCmt910::Work(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt910::doWork()");

    // ��������
    unPack(pchMsg);
	
    // ֻ����������Ϊʧ�ܵ����
    if ( RTN_SUCCESS == TransProcSts() )
    {
	    if ( RTN_FAIL == UpdateState() )
	    {
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����״̬ʧ��");
        
        	PMTS_ThrowException(DB_UPDATE_FAIL);
	    }
		
		InsertComsendmb(pchMsg);
	}
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt910::doWork()");

    return RTN_SUCCESS;
}

INT32 CRecvCmt910::unPack(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt910::unPack()");
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "receive msg = [%s]",pchMsg);
    // 1�������Ƿ�Ϊ��
    if (NULL == pchMsg || '\0' == pchMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_strBizCode.c_str(), "����Ϊ��");
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }
    
    int iRet = RTN_FAIL;
    
    // 3����������
    iRet = m_cCmt910.ParseCmt(pchMsg);

    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CRecvCmt910::Work(): ��������ʧ��");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������!");
    }

    m_strMesgID = m_cCmt910.GetHeadMesgReqNo();
    
    ZFPTLOG.SetLogInfo("1910", m_cCmt910.GetHeadMesgID());
   
    // ��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
  
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");
        PMTS_ThrowException(OPT_GET_DATE_FAIL);
    }
    m_strWorkDate   =   m_sWorkDate;
     
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt910::unPack()");	
    
    return RTN_SUCCESS;
}

INT32 CRecvCmt910::TransProcSts()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt910::TransProcSts()");

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strProcSts = [%s]", m_cCmt910.sProcCode);	
    
    if ( 0 == strncmp(m_cCmt910.sProcCode+4,"0000",4))
    {       
        return RTN_FAIL;
    }
    else if ( 0 == strncmp(m_cCmt910.sProcCode+4,"0001" ,4))
    {
        m_strProcSts  = PR_HVBP_09;
        m_strBusistate = PROCESS_PR09;
    }
    else if ( 0 == strncmp(m_cCmt910.sProcCode+4,"0002" ,4))
    {
        m_strProcSts  = PR_HVBP_10;
        m_strBusistate = PROCESS_PR09;
    }
    else if ( 0 == strncmp(m_cCmt910.sProcCode+4,"0003",4 ))
    {
        m_strProcSts  = PR_HVBP_11;
        m_strBusistate = PROCESS_PR09;
    }
    else if ( 0 == strncmp(m_cCmt910.sProcCode+4,"0004",4 ))
    {
        m_strProcSts  = PR_HVBP_12;
        m_strBusistate = PROCESS_PR09;
    }
    else
    {
    	m_strProcSts  = PR_HVBP_14;
    	m_strBusistate = PROCESS_PR09;
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt910::TransProcSts()");
    
    return RTN_SUCCESS;
}

INT32 CRecvCmt910::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt910::UpdateState()");
    
    int		iRet  = RTN_FAIL;
    string  strSql = "";
    SETCTX(m_entitybase);
    SETCTX(m_hvsndexchglist);
	SETCTX(m_CHvtrofacsndlist);
	SETCTX(m_CCmcnotsgninfbiz);
	SETCTX(m_CCmfreeinfo); 
	SETCTX(m_CHvsealerr);
	
	//������ͷ���Ĺ���������Ϊ��̬����
    char szIOSdate[10 + 1] = {0};
    chgToISODate(m_cCmt910.GetHeadWorkDate(), szIOSdate);  
	 
   
	strSql  = "";
	strSql += "UPDATE HV_SNDEXCHGLIST t SET t.PROCSTATE = '";
	strSql += m_strProcSts;
    strSql += "', t.PROCESSCODE = '";
    strSql += m_cCmt910.sProcCode;
    strSql += "', t.RJCTINF = '";
    strSql += m_cCmt910.sRemark;
    strSql += "', t.BUSISTATE = '";
    strSql += m_strBusistate;
	strSql += "',FINALSTATEDATE = '";
    strSql += szIOSdate;	
    strSql += "', t.STATETIME = sysdate";
    strSql += " WHERE t.MESGREFID = '";
	strSql += m_strMesgID.c_str();
	strSql += "'";
    

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=%s", strSql.c_str());
    //iRet = m_entitybase.execsql(strSql.c_str());
    iRet = m_hvsndexchglist.execsql(strSql.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iRet=[%d]",iRet);
    if(RTN_SUCCESS == iRet)
    {
        m_strTableName = "HV_SNDEXCHGLIST";
        
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "���±�HV_SNDEXCHGLIST�ɹ�");
    
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCmt910::UpdateState()");
        
        return RTN_SUCCESS;
    }
	
	strSql  = "";
	strSql += "UPDATE HV_TROFACSNDLIST t SET t.PROCSTATE = '";
	strSql += m_strProcSts;
    strSql += "', t.PROCESSCODE = '";
    strSql += m_cCmt910.sProcCode;
    strSql += "', t.RJCTINF = '";
    strSql += m_cCmt910.sRemark;
    strSql += "', t.BUSISTATE = '";
    strSql += m_strBusistate;
    strSql += "', t.STATETIME = sysdate";
    strSql += " WHERE t.MESGREFID = '";
	strSql += m_strMesgID.c_str();
	strSql += "'";
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=%s", strSql.c_str());
    //iRet = m_entitybase.execsql(strSql.c_str());
    iRet = m_CHvtrofacsndlist.execsql(strSql.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iRet=[%d]",iRet);
    if(RTN_SUCCESS == iRet)
    {
        m_strTableName = "HV_TROFACSNDLIST";
        
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "���±�HV_TROFACSNDLIST�ɹ�");
    
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCmt910::UpdateState()");
        
        return RTN_SUCCESS;
    }
	
	strSql  = "";
	strSql += "UPDATE CM_CNOTSGNINFBIZ t SET t.PROCSTATE = '";
	strSql += m_strProcSts;
    //strSql += "', t.PROCESSCODE = '";//�ñ�û������ֶ�
    //strSql += m_cCmt910.sProcCode;
    strSql += "', t.RJCTINF = '";
    strSql += m_cCmt910.sRemark;
    strSql += "', t.STATUS = '";
    strSql += m_strBusistate;
    strSql += "', t.PROCTIME = sysdate";
    strSql += " WHERE t.MESGREFID = '";
	strSql += m_strMesgID.c_str();
	//strSql += m_cCmt910.MsgId.c_str();
	strSql += "'";
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=%s", strSql.c_str());
    
    //iRet = m_entitybase.execsql(strSql.c_str());
    iRet = m_CCmcnotsgninfbiz.execsql(strSql.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iRet=[%d]",iRet);
    if(RTN_SUCCESS == iRet)
    {
        m_strTableName = "CM_CNOTSGNINFBIZ";
        
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "���±�CM_CNOTSGNINFBIZ�ɹ�");
    
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCmt910::UpdateState()");
        
        return RTN_SUCCESS;
    }
	
	strSql  = "";
	strSql += "UPDATE CM_FREEINFO t SET t.PROCSTATE = '";
	strSql += m_strProcSts;
    strSql += "', t.PROCESSCODE = '";
    strSql += m_cCmt910.sProcCode;
    strSql += "', t.RJCTINF = '";
    strSql += m_cCmt910.sRemark;
    strSql += "', t.BUSISTATE = '";
    strSql += m_strBusistate;
    strSql += "', t.STATETIME = sysdate";
    strSql += " WHERE t.MESGREFID = '";
	strSql += m_strMesgID.c_str();
	strSql += "'";
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=%s", strSql.c_str());
    
    //iRet = m_entitybase.execsql(strSql.c_str());
    iRet = m_CCmfreeinfo.execsql(strSql.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iRet=[%d]",iRet);
    if(RTN_SUCCESS == iRet)
    {
        m_strTableName = "CM_FREEINFO";
        
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "���±�CM_FREEINFO�ɹ�");
    
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCmt910::UpdateState()");
        
        return RTN_SUCCESS;
    }
    
    strSql  = "";
	strSql += "UPDATE CM_TRANSINFOQRY t SET t.PROCSTATE = '";
	strSql += m_strProcSts;
    strSql += "', t.PROCESSCODE = '";
    strSql += m_cCmt910.sProcCode;
    strSql += "', t.RJCTINF = '";
    strSql += m_cCmt910.sRemark;
    strSql += "', t.BUSISTATE = '";
    strSql += m_strBusistate;
	strSql += "',FINALSTATEDATE = '";
    strSql += szIOSdate;	
    strSql += "', t.STATETIME = sysdate";
    strSql += " WHERE t.RSFLAG <> '2' AND t.MESGREFID = '";
	strSql += m_strMesgID.c_str();
	strSql += "'";
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=%s", strSql.c_str());
    
    //iRet = m_entitybase.execsql(strSql.c_str());
    iRet = m_entitybase.execsql(strSql.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iRet=[%d]",iRet);
    if(RTN_SUCCESS == iRet)
    {
        m_strTableName = "CM_TRANSINFOQRY";
        
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "���±�CM_TRANSINFOQRY�ɹ�");
        
        UpdateRspflag("CM_TRANSINFOQRY");
    
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCmt910::UpdateState()");
        
        return RTN_SUCCESS;
    }

	strSql  = "";
	strSql += "UPDATE CM_PMTRTRCL t SET t.PROCSTATE = '";
	strSql += m_strProcSts;
    strSql += "', t.PROCESSCODE = '";
    strSql += m_cCmt910.sProcCode;
    strSql += "', t.RJCTINF = '";
    strSql += m_cCmt910.sRemark;
    strSql += "', t.BUSISTATE = '";
    strSql += m_strBusistate;
    strSql += "', t.STATETIME = sysdate";
    strSql += " WHERE t.RSFLAG <> '2' AND t.MESGREFID = '";
	strSql += m_strMesgID.c_str();
	strSql += "'";
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=%s", strSql.c_str());
    
    iRet = m_entitybase.execsql(strSql.c_str());
    //iRet = m_entitybase.execsql(strSql.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iRet=[%d]",iRet);
    if(RTN_SUCCESS == iRet)
    {
        m_strTableName = "CM_PMTRTRCL";
        
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "���±�CM_PMTRTRCL�ɹ�");
        
        UpdateRspflag("CM_PMTRTRCL");
    
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCmt910::UpdateState()");
        
        return RTN_SUCCESS;
    }
    
	strSql  = "";
	strSql += "UPDATE HV_SEALERR t SET t.RSPFLAG = '1', t.PROCSTATE = '";
	strSql += m_strProcSts;
    strSql += "', t.PROCESSCODE = '";
    strSql += m_cCmt910.sProcCode;
    strSql += "', t.RJCTINF = '";
    strSql += m_cCmt910.sRemark;
    strSql += "', t.BUSISTATE = '";
    strSql += m_strBusistate;
    strSql += "', t.STATETIME = sysdate";
    strSql += " WHERE t.MESGREFID = '";
	strSql += m_strMesgID.c_str();
	strSql += "'";
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=%s", strSql.c_str());
    
    iRet = m_entitybase.execsql(strSql.c_str());
    //iRet = m_entitybase.execsql(strSql.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iRet=[%d]",iRet);
    if(RTN_SUCCESS == iRet)
    {
        
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "���±�HV_SEALERR�ɹ�");        
    
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCmt910::UpdateState()");
        
        return RTN_SUCCESS;
    }    
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCmt910::UpdateState()");
        
	return RTN_FAIL;
}

/******************************************************************************
*  Function:   UpdateRspflag
*  Description:�޸�ԭ���뱨��Ӧ��״̬
*  Input:      ��
*  Output:     
*  Return:     0   : �����ɹ�,
               ����: ����ʧ��
*  Others:     ADD
*  Author:     lj
*  Date:       2012-08-30
*******************************************************************************/
INT32 CRecvCmt910:: UpdateRspflag(LPCSTR TableName)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt910::UpdateRspflag()");
    
    if(strlen(TableName) == 0)
    {
        return RTN_FAIL; 
    }
    
    string strSql = "";
    int    iCount = 0;
    
    if(0 == strcmp(TableName,"CM_TRANSINFOQRY"))
    {
        SETCTX(m_Cmtransqry);
        iCount = 0;
        strSql  = "";
        strSql += " RSFLAG <> '2' AND MESGID = '";
    	strSql += m_strMesgID.c_str();
    	strSql += "'";
    	
    	Trace(L_INFO,  __FILE__,	__LINE__, NULL, "strSql [%s]", strSql.c_str());
    	
    	int iRet = m_Cmtransqry.find(strSql);
    	if(OPERACT_SUCCESS != iRet)
		{
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "m_Cmtransqry find fail:  [%d][%s]", 
				 iRet, m_Cmtransqry.GetSqlErr());
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
		
		while(0 == m_Cmtransqry.fetch())
		{
		    iCount++;
		    if(iCount>1)
		    {
		        Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "�ҵ���ֹ1�����ݼ�¼������[%s]��ͨ�ű�ʶ��[%s]",
		        TableName, m_strMesgID.c_str());
		        PMTS_ThrowException("�ҵ���ֹ1�����ݼ�¼");
		    }
		    
		    if( "CMT302" == m_Cmtransqry.m_msgtp )
		    {
		        strSql = "UPDATE ";
    		    strSql += TableName;
    		    strSql += " t SET t.RSPFLAG = '0'";
                strSql += " WHERE t.RSFLAG = '2' AND MSGTP = 'CMT301' AND t.MSGID = '";
            	strSql += m_Cmtransqry.m_qorgnlmsgid;
            	strSql += "' AND t.INSTGINDRCTPTY = '";
            	strSql += m_Cmtransqry.m_qorgnlinstgdrctpty;
            	strSql += "'";
            	
            	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=%s", strSql.c_str());
		    }
		}
		
		if( "CMT302" == m_Cmtransqry.m_msgtp )
		{
		    Trace(L_INFO,  __FILE__,	__LINE__, NULL, "strSql [%s]", strSql.c_str());
		    
    		iRet = m_Cmtransqry.execsql(strSql.c_str());
    		m_Cmtransqry.closeCursor();
    		if(SQLNOTFOUND == iRet)
        	{
        	     Trace(L_INFO,  __FILE__,  __LINE__, NULL, "SQLNOTFOUND");
        	    //����û���ҵ����ݲ����쳣 ��Ϊ��ȷ����CMT301����302
        	    Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "m_Cmtransqry find fail:  [%d][%s]", 
    				 iRet, m_Cmtransqry.GetSqlErr());
        	    return RTN_FAIL;
        	}
    		else if(RTN_SUCCESS != iRet)
            {
                Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "m_Cmtransqry execsql fail:  [%d][%s]", 
    				 iRet, m_Cmtransqry.GetSqlErr());
    			 PMTS_ThrowException(DB_GET_DATA_FAIL);
            }
        //m_Cmtransqry.commit();
	    }
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCmt910::UpdateRspflag()");
		return RTN_SUCCESS;
	}
	else if(0 == strcmp(TableName,"CM_PMTRTRCL"))
	{
		SETCTX(m_Cmpmtrtrcl);
        iCount = 0;
        strSql  = "";
        strSql += " RSFLAG <> '2' AND MESGID = '";
    	strSql += m_strMesgID.c_str();
    	strSql += "'";
    	
    	Trace(L_INFO,  __FILE__,	__LINE__, NULL, "strSql [%s]", strSql.c_str());
    	
    	int iRet = m_Cmpmtrtrcl.find(strSql);
    	if(OPERACT_SUCCESS != iRet)
		{
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "m_Cmtransqry find fail:  [%d][%s]", 
				 iRet, m_Cmpmtrtrcl.GetSqlErr());
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
		
		while(0 == m_Cmpmtrtrcl.fetch())
		{
		    iCount++;
		    if(iCount>1)
		    {
		        Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "�ҵ���ֹ1�����ݼ�¼������[%s]��ͨ�ű�ʶ��[%s]",
		        TableName, m_strMesgID.c_str());
		        //PMTS_ThrowException("�ҵ���ֹ1�����ݼ�¼");
		    }
		    
		    if( "CMT314" == m_Cmpmtrtrcl.m_msgtp )
		    {
		        strSql = "UPDATE ";
    		    strSql += TableName;
    		    strSql += " t SET t.RSPFLAG = '0'";
                strSql += " WHERE t.RSFLAG = '2' AND MSGTP = 'CMT313' AND t.MSGID = '";
            	strSql += m_Cmpmtrtrcl.m_orgnlmsgid;
            	strSql += "' AND t.INSTGINDRCTPTY = '";
            	strSql += m_Cmpmtrtrcl.m_orgninstgdrctpty;
            	strSql += "'";
            	
            	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=%s", strSql.c_str());
		    }
		}
		
		if( "CMT314" == m_Cmpmtrtrcl.m_msgtp )
		{
		    Trace(L_INFO,  __FILE__,	__LINE__, NULL, "strSql [%s]", strSql.c_str());
		    
    		iRet = m_Cmpmtrtrcl.execsql(strSql.c_str());
    		m_Cmpmtrtrcl.closeCursor();
    		if(SQLNOTFOUND == iRet)
        	{
        	     Trace(L_INFO,  __FILE__,  __LINE__, NULL, "SQLNOTFOUND");
        	    //����û���ҵ����ݲ����쳣 ��Ϊ��ȷ����CMT313����314
        	    Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "m_Cmtransqry find fail:  [%d][%s]", 
    				 iRet, m_Cmpmtrtrcl.GetSqlErr());
        	    return RTN_FAIL;
        	}
    		else if(RTN_SUCCESS != iRet)
            {
                Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "m_Cmtransqry execsql fail:  [%d][%s]", 
    				 iRet, m_Cmpmtrtrcl.GetSqlErr());
    			 PMTS_ThrowException(DB_GET_DATA_FAIL);
            }
        //m_Cmtransqry.commit();
	    }
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCmt910::UpdateRspflag()");
		return RTN_SUCCESS;
	}
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCmt910::UpdateRspflag()");
    return RTN_FAIL;
}

/******************************************************************************
*  Function:   InsertComsendmb
*  Description:������ͨѶ��
*  Input:      ��
*  Output:     
*  Return:     0   : �����ɹ�,
               ����: ����ʧ��
*  Others:     ��
*  Author:     hhc
*  Date:       2012-04-24
*******************************************************************************/
void CRecvCmt910::InsertComsendmb(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt910::InsertComsendmb()");
	
	int    iRet = RTN_FAIL;
	string strRval = "";
    string strSql = "";
		
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt910.GetHeadCmtNO()[%s]", m_cCmt910.GetHeadCmtNO());
	
    if( ( m_strTableName == "HV_SNDEXCHGLIST" ) )
	{
		CHvsndexchglist cHvsndexchglist;
		
		strSql  = "";
		strSql += " MESGID = '";
		strSql += m_strMesgID.c_str();
		strSql += "' ";

		SETCTX(cHvsndexchglist);
			
		iRet = cHvsndexchglist.find(strSql);
		if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "cHvsndexchglist find fail:  [%d][%s]", 
				iRet, cHvsndexchglist.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		while(0 == cHvsndexchglist.fetch())
		{
			iRet = GetTagVal(strRval, cHvsndexchglist.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, "msgid[%s]", cHvsndexchglist.m_msgid.c_str());
				m_strMsgID = cHvsndexchglist.m_msgid;
				//m_strReserve = cHvsndexchglist.m_reserve; //�����ڷ�911ʱ�����ڻ�ȡԭ��������
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cHvsndexchglist.m_mbmsgid.c_str(), 22);
        
			    //�жϼ�ֱ���������ֱ����������ͨѶ�� by add zql 
			    if(cHvsndexchglist.m_msgdirect == "0")
			   	{
					DirectInter(cHvsndexchglist.m_instgindrctpty.c_str(), 
				    			cHvsndexchglist.m_instdindrctpty.c_str(),
				    			cHvsndexchglist.m_instddrctpty.c_str(), 
				    			pchMsg);
			    }
			}
			else if(-2 == iRet)
			{
				Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "ԭҵ�����ڷ���ϵͳ��Ϊ��,����ת��������");
				break;
			}
		}
		
		cHvsndexchglist.closeCursor();
	}
	else if( m_strTableName == "CM_TRANSINFOQRY" )
	{
		CCmtransinfoqry cCmtransinfoqry;
		
		strSql  = "";
		strSql += " MESGID = '";
		strSql += m_strMesgID.c_str();
		//������жϷ����Ƿ�����
		//strSql += "' AND SRCFLSG = '";
		//strSql += strRsflag;
		strSql += "'";
	
		SETCTX(cCmtransinfoqry);
			
		iRet = cCmtransinfoqry.find(strSql);
		if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "cCmtransinfoqry find fail:  [%d][%s]", 
				iRet, cCmtransinfoqry.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		while(0 == cCmtransinfoqry.fetch())
		{
			iRet = GetTagVal(strRval, cCmtransinfoqry.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, "msgid[%s]", cCmtransinfoqry.m_msgid.c_str());
				m_strMsgID = cCmtransinfoqry.m_msgid;
				//m_strReserve = cCmtransinfoqry.m_reserve; //�����ڷ�911ʱ�����ڻ�ȡԭ��������
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cCmtransinfoqry.m_mbmsgid.c_str(), 22);
			
				//�жϼ�ֱ���������ֱ����������ͨѶ�� by add zql 
				//if(cCmtransinfoqry.m_qrytp == "QT01")
				if(strlen(cCmtransinfoqry.m_mbmsgid.c_str()) == 22 &&
				   cCmtransinfoqry.m_rsflag == "0" )
				{
				    DirectInter(cCmtransinfoqry.m_instgindrctpty.c_str(),
			                cCmtransinfoqry.m_instdindrctpty.c_str(), 
			    			cCmtransinfoqry.m_instddrctpty.c_str(), 
			    			pchMsg, 
			    			cCmtransinfoqry.m_sysid.c_str());
		    	}
			}
			else if(-2 == iRet)
			{
				Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "ԭҵ�����ڷ���ϵͳ��Ϊ��,����ת��������");
				break;
			}
		}
	}
	else if( m_strTableName == "CM_FREEINFO" )
	{
		CCmfreeinfo cCmfreeinfo;
		
		strSql  = "";
		strSql += " MESGID = '";
		strSql += m_strMesgID.c_str();
		//strSql += "' AND RSFLSG = '";
		//strSql += strRsflag;
		strSql += "'";
	
		SETCTX(cCmfreeinfo);
			
		iRet = cCmfreeinfo.find(strSql);
		if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "cCmfreeinfo find fail:  [%d][%s]", 
				iRet, cCmfreeinfo.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		while(0 == cCmfreeinfo.fetch())
		{
			iRet = GetTagVal(strRval, cCmfreeinfo.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, "msgid[%s]", cCmfreeinfo.m_msgid.c_str());
				m_strMsgID = cCmfreeinfo.m_msgid;
				//m_strReserve = cCmfreeinfo.m_reserve; //�����ڷ�911ʱ�����ڻ�ȡԭ��������
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cCmfreeinfo.m_mbmsgid.c_str(), 22);
			
				//�жϼ�ֱ���������ֱ����������ͨѶ�� by add zql 
				//if(NULL != strstr(cCmfreeinfo.m_msgcnt.c_str(), "/REF/TFS ref./REFEND/"))
				if(strlen(cCmfreeinfo.m_mbmsgid.c_str()) ==22 &&
				   cCmfreeinfo.m_rsflag == "0" )
				{
				    DirectInter(cCmfreeinfo.m_instgindrctpty.c_str(), 
			    			cCmfreeinfo.m_instdindrctpty.c_str(), 
			    			cCmfreeinfo.m_instddrctpty.c_str(), 
			    			pchMsg, 
			    			cCmfreeinfo.m_sysid.c_str());
		    	}
			}
			else if(-2 == iRet)
			{
				Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "ԭҵ�����ڷ���ϵͳ��Ϊ��,����ת��������");
				break;
			}
		}
	}
	else//����������ͨѶ��
	{
	    Trace(L_INFO, __FILE__, __LINE__, NULL, "������������[%s]", m_cCmt910.GetHeadCmtNO());
	}
	

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt910::InsertComsendmb()");
}
