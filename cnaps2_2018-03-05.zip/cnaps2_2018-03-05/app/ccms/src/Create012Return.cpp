/********************************************************************
文件名：Create012Return.cpp
创建人：hdf
日  期：2013-03-13
修改人：
日  期：
描  述：批量代收付处理主控
版  本：
Copyright (c) 2011  YLINK
********************************************************************/

//#ifdef _LINUX_
//#define SQLCA_STORAGE_CLASS extern
//#include "sqlca.h"
//#endif
#include <sqlca.h>
#include <signal.h>
#include "exception.h"
#include "pubfunc.h"
#include "configparser.h"
#include "logger.h"
#include "connectpool.h"
#include "cfg_obj.h"
#include "mqagent.h"
#include "ProcessCollect.h"
#include "ProcessPayment.h"
using namespace ZFPT;

CConnectPool    *g_DBConnPool;
CCfgObj         pCfgFile;
MQAgent              m_cMQAgent;
char            g_MQmgr[256];
char            g_MqTxtPath[256];
char            g_SendQueue[128];
char            g_SendCBSP[128];
int             g_IsConnCBSP;
char            g_IP[16];
int         	g_IsConnPlatm;
char            g_SendHVPSQueue[128];  //发送队列需分三个,往支付平台发送
char            g_SendCCMSQueue[128];
char            g_SendSAPSQueue[128];
char            g_ReturnQueue[128];  //
char            g_SendMBQueue[128];  //往行内发送队列
char            g_strSapBank[13];
int             g_iCfcaSign = 0;//是否加签名或加押
char            g_SignAddr[496];
DBProc m_dbproc;
char szMaxPayDay[3];
char szMaxCollDay[3];
#define MQ_ERR_MAX_TIMES    3

int LoadConfigFile(stuCfgInfo &CfgInfo)
{
	//注意：在这个函数内不要用trace打日志，加载时，日志没有进行初始化
	CConfigParser& cCfg = CConfigParser::getInstance();

	strcpy(CfgInfo.path, ZFPT_CFG_PATH);
    cCfg.loadConfig(CfgInfo.path);

	strncpy(CfgInfo.szXmlCtgPath, cCfg.getOption("XMLCTGPATH"),sizeof(CfgInfo.szXmlCtgPath)-1);
	strncpy(CfgInfo.szLogPath   , cCfg.getOption("LOGPATH")   , sizeof(CfgInfo.szLogPath)-1  );
    CfgInfo.iPort           = atoi(cCfg.getOption("CCMSPORT")  );
    CfgInfo.iLogLeave       = atoi(cCfg.getOption("LOGLVL")    );
	CfgInfo.dLogMaxSize     = atof(cCfg.getOption("LOGMAXSIZE"));
	
	memset(g_MQmgr     , 0x00, sizeof(g_MQmgr)    );
	memset(g_SendQueue , 0x00, sizeof(g_SendQueue));
	memset(g_MqTxtPath , 0x00, sizeof(g_MqTxtPath));
	memset(g_ReturnQueue , 0x00, sizeof(g_ReturnQueue));
	strncpy(g_MQmgr    , cCfg.getOption("MQMGR")     , sizeof(g_MQmgr)-1    );
    strncpy(g_SendQueue, cCfg.getOption("CCMSSENDMQ"), sizeof(g_SendQueue)-1);
    strncpy(g_MqTxtPath, cCfg.getOption("MQTEXTPATH"), sizeof(g_MqTxtPath)-1);

	strncpy(g_ReturnQueue, cCfg.getOption("CLTRECVRETN"), sizeof(g_ReturnQueue)-1);
    strncpy(CfgInfo.szCltSendMQ  , cCfg.getOption("CLTSENDCCMS"), sizeof(CfgInfo.szCltSendMQ  )-1);
	
    strncpy(CfgInfo.DBUser, cCfg.getOption("DBUSER"), sizeof(CfgInfo.DBUser)-1);
    //alter in 20171130
    CfgInfo.iDBKeyType = atoi(cCfg.getOption("DBKEYTYPE"));
    if (CfgInfo.iDBKeyType == 1) //密码为明文
    {
				strncpy(CfgInfo.DBKey, cCfg.getOption("DBKEY"), sizeof(CfgInfo.DBKey)-1);
    }
    if (CfgInfo.iDBKeyType == 0) //密码为密文
    {
				CfgInfo.DBKey_new.Format("%s", cCfg.getOption("DBKEY"));
				DecodeDBPsw(CfgInfo.DBKey_new);
				strncpy(CfgInfo.DBKey, CfgInfo.DBKey_new.GetBuffer(0), sizeof(CfgInfo.DBKey)-1);
    }
    //alter end
    strncpy(CfgInfo.DBName, cCfg.getOption("DBNAME"), sizeof(CfgInfo.DBName)-1);

    strncpy(CfgInfo.szMqServConn  , cCfg.getOption("MQSERVCONN")  , sizeof(CfgInfo.szMqServConn) - 1  );
    strncpy(CfgInfo.szPmInfoHdFlg1, cCfg.getOption("PMINFOHDFLG1"), sizeof(CfgInfo.szPmInfoHdFlg1) - 1);
    strncpy(CfgInfo.szPmInfoHdFlg2, cCfg.getOption("PMINFOHDFLG2"), sizeof(CfgInfo.szPmInfoHdFlg2) - 1);
    strncpy(CfgInfo.szCbspRecvMQ  , cCfg.getOption("CBSPRECVMQ")  , sizeof(CfgInfo.szCbspRecvMQ) - 1  );    
    CfgInfo.iMqListener         = atoi(cCfg.getOption("MQLISTENER"));
    CfgInfo.iConnPlatm          = atoi(cCfg.getOption("ISCONNPLATM"));      
	strncpy(g_SendCBSP, CfgInfo.szCbspRecvMQ, sizeof(g_SendCBSP)-1);
	g_IsConnCBSP   = CfgInfo.iConnPlatm;	
	g_IsConnPlatm  = CfgInfo.iConnPlatm;
	
	g_iCfcaSign = atoi(cCfg.getOption("CERTSIGN"));
	
    return OPERACT_SUCCESS;
}


int main(int argc, char * argv[])
{
    char sErrDesc[1024 + 1] = {0};
    int iRet                =  0 ;
    stuCfgInfo           CfgInfo ;
    
	//初始化全局参数
	signal(SIGINT , SIG_IGN);							//屏蔽中断信号
	signal(SIGQUIT, SIG_IGN);							//屏蔽终端退出信号
	signal(SIGALRM, SIG_IGN);							//屏蔽超时信号
	signal(SIGHUP , SIG_IGN);							//屏蔽连接断开信号
	signal(SIGSTOP, SIG_IGN); 							//这些信号被忽略
	//signal(SIGCHLD, SIG_IGN);
    
    try
    {
    	//初始化配置文件
        LoadConfigFile(CfgInfo);
			
		//初始化日志	
		ZFPTLOG.setCfgInfo(CfgInfo.szLogPath, "Create012Return", CfgInfo.iLogLeave, CfgInfo.dLogMaxSize);
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化日志...");

		//初始化XML配置文件		
		iRet = pCfgFile.Init(CfgInfo.szXmlCtgPath);  
		if(iRet != 0)
		{
		    sprintf(sErrDesc, "Failed to Init the node Config Object: ErrCode = %d, ErrInfo = %s", pCfgFile.GetLastErrCode(),pCfgFile.GetLastErrInfo());
	    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);
			exit(0);
		}

		//初始化MQ 
        if(m_cMQAgent.Init(g_MQmgr, g_MqTxtPath) != RTN_SUCCESS)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Init MQ manager failed.");
            exit(0);
        }
        
        //创建连接池 
        g_DBConnPool = new CConnectPool(1,1, 3);
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化连接池...");	    
        iRet= g_DBConnPool->InitPool(CfgInfo.iConPoolSize,CfgInfo.DBUser,CfgInfo.DBKey,CfgInfo.DBName);
		
        if(iRet == RTN_SUCCESS)
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "连接池创建成功");
        }
        else
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "连接池创建失败");
            exit(0);
        }

        // 获取连接池
        if(0 != g_DBConnPool->GetConnect(m_dbproc))
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "主线程取连接失败,退出");
            exit(0);
        }

        memset(szMaxPayDay, 0x00, sizeof(szMaxPayDay));
        int iRet = GetSysParam(m_dbproc, "14", szMaxPayDay);
        if (OPERACT_SUCCESS != iRet)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取退汇最大日期失败");
            exit(0);
        }

        memset(szMaxCollDay, 0x00, sizeof(szMaxCollDay));
        iRet = GetSysParam(m_dbproc, "15", szMaxCollDay);
        if (OPERACT_SUCCESS != iRet)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取回执最大日期失败");
            exit(0);
        }
    }
    catch(CException &e)
    {
    	sprintf(sErrDesc, "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);
        exit(0);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "组装批量代付回执包");
    CProcessPayment Payment;
    Payment.Work();
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "组装批量代付回执包完毕");

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "组装批量代收回执包");
    CProcessCollect Collect;
    Collect.Work();
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "组装批量代收回执包完毕");

    g_DBConnPool->PutConnect(m_dbproc); 
    m_cMQAgent.Disconnect();
	DELPOINT_VOID(g_DBConnPool);
    return 0;
}

