/********************************************************************
文件名：recverrmsg.cpp
创建人：hdf
日  期：2011.01.14
修改人：hdf
日  期：
描  述：异常处理主控
版  本：
Copyright (c) 2009  YLINK
********************************************************************/

//#ifdef _LINUX_
//#define SQLCA_STORAGE_CLASS extern
//#include "sqlca.h"
//#endif
#include <sqlca.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include "exception.h"
#include "pubfunc.h"
#include "configparser.h"
#include "connectpool.h"
#include "mqagent.h"
#include "cfg_obj.h"
#include "logger.h"
#include "tsocket.h"
#include "cmrecverrmsg.h"
#include "sysrecvfrommb.h"

using namespace ZFPT;

#define IP_ADDRS_LEN 16

struct stuSocket
{
    char szServerIP[IP_ADDRS_LEN];
    int iCommType;
    int HVPSPort;
    int BEPSPort;
    int CCMSPort;
    int SAPSPort;
};

CConnectPool	*g_DBConnPool;
CCfgObj 		pCfgFile;
stuSocket            SocketInfo;

char			g_MQmgr[256];
char			g_MqTxtPath[256];
char			g_SendQueue[128];
char            g_SendCBSP[128];
int             g_IsConnCBSP;
char            g_IP[16];
int         	g_IsConnPlatm;
char            g_SignAddr[496];

int LoadConfigFile(stuCfgInfo &CfgInfo, stuSocket &SocketInfo, char* HvpsMQ, char* BepsMQ, char* CcmsMQ, char* SapsMQ,
                                        char* sQueHvps, char* sQueBeps, char* sQueCcms, char* sQueSaps,
                                        char* sQueBkHvps, char* sQueBkBeps, char* sQueBkCcms, char* sQueBkSaps)
{
	//注意：在这个函数内不要用trace打日志，加载时，日志没有进行初始化
	CConfigParser& cCfg = CConfigParser::getInstance();

	strcpy(CfgInfo.path, ZFPT_CFG_PATH);
    cCfg.loadConfig(CfgInfo.path);

    strncpy(SocketInfo.szServerIP, cCfg.getOption("CLIENTIP"), sizeof(SocketInfo.szServerIP)-1);
    SocketInfo.HVPSPort = atoi(cCfg.getOption("HVPSPORT")  );
    SocketInfo.BEPSPort = atoi(cCfg.getOption("BEPSPORT")  );
    SocketInfo.CCMSPort = atoi(cCfg.getOption("CCMSPORT")  );
    SocketInfo.SAPSPort = atoi(cCfg.getOption("SAPSPORT")  );
    SocketInfo.iCommType = atoi(cCfg.getOption("COMMUNICATION"));
    
	strncpy(CfgInfo.szXmlCtgPath, cCfg.getOption("XMLCTGPATH"), sizeof(CfgInfo.szXmlCtgPath)-1);
    strncpy(CfgInfo.szLogPath   , cCfg.getOption("LOGPATH")   , sizeof(CfgInfo.szLogPath)-1   );
    CfgInfo.iLogLeave       = atoi(cCfg.getOption("LOGLVL")    );
	CfgInfo.dLogMaxSize     = atof(cCfg.getOption("LOGMAXSIZE"));

	strncpy(CfgInfo.szMQmgr    , cCfg.getOption("MQMGR")     , sizeof(CfgInfo.szMQmgr)-1    );
    strncpy(CfgInfo.RecvQueue  , cCfg.getOption("BEPSRECVMQ"), sizeof(CfgInfo.RecvQueue)-1  );
	strncpy(CfgInfo.szMqTxtPath, cCfg.getOption("MQTEXTPATH"), sizeof(CfgInfo.szMqTxtPath)-1);
	
	memset(g_MQmgr     , 0x00, sizeof(g_MQmgr));
	memset(g_SendQueue , 0x00, sizeof(g_SendQueue));
	memset(g_MqTxtPath , 0x00, sizeof(g_MqTxtPath));
	strncpy(g_MQmgr    , cCfg.getOption("MQMGR")     , sizeof(g_MQmgr)-1    );
    strncpy(g_SendQueue, cCfg.getOption("HVPSSENDMQ"), sizeof(g_SendQueue)-1);
    strncpy(g_MqTxtPath, cCfg.getOption("MQTEXTPATH"), sizeof(g_MqTxtPath)-1);
	
	CfgInfo.iConPoolMinNum          = atoi(cCfg.getOption("HVCONNPOOLMINSIZE")   );
	CfgInfo.iConPoolMaxNum          = atoi(cCfg.getOption("HVCONNPOOLMAXSIZE")   );
	CfgInfo.iNoConWaitTime	        = atoi(cCfg.getOption("HVNOCONNWAITTIME")    );
	CfgInfo.iConPoolSize            = atoi(cCfg.getOption("HVCONNPOOLSIZE")      );
	CfgInfo.iThreadPoolSize         = atoi(cCfg.getOption("HVTHREADPOOLSIZE")    );
	CfgInfo.iThreadPoolTaskSize     = atoi(cCfg.getOption("HVTHREADPOOLTASKSIZE"));
	
    strncpy(CfgInfo.DBUser, cCfg.getOption("DBUSER"), sizeof(CfgInfo.DBUser)-1);
    //alter in 20171130
    CfgInfo.iDBKeyType = atoi(cCfg.getOption("DBKEYTYPE"));
    if (CfgInfo.iDBKeyType == 1) //密码为明文
    {
				strncpy(CfgInfo.DBKey, cCfg.getOption("DBKEY"), sizeof(CfgInfo.DBKey)-1);
    }
    if (CfgInfo.iDBKeyType == 0) //密码为密文
    {
				CfgInfo.DBKey_new.Format("%s", cCfg.getOption("DBKEY"));
				DecodeDBPsw(CfgInfo.DBKey_new);
				strncpy(CfgInfo.DBKey, CfgInfo.DBKey_new.GetBuffer(0), sizeof(CfgInfo.DBKey)-1);
    }
    //alter end
    strncpy(CfgInfo.DBName, cCfg.getOption("DBNAME"), sizeof(CfgInfo.DBName)-1);

    strncpy(CfgInfo.szMqServConn  , cCfg.getOption("MQSERVCONN")  , sizeof(CfgInfo.szMqServConn) - 1  );
    strncpy(CfgInfo.szPmInfoHdFlg1, cCfg.getOption("PMINFOHDFLG1"), sizeof(CfgInfo.szPmInfoHdFlg1) - 1);
    strncpy(CfgInfo.szPmInfoHdFlg2, cCfg.getOption("PMINFOHDFLG2"), sizeof(CfgInfo.szPmInfoHdFlg2) - 1);
    strncpy(CfgInfo.szCbspRecvMQ  , cCfg.getOption("CBSPRECVMQ")  , sizeof(CfgInfo.szCbspRecvMQ) - 1  );    
    strncpy(g_SendCBSP, CfgInfo.szCbspRecvMQ, sizeof(g_SendCBSP)-1);
    
    CfgInfo.iMqListener         = atoi(cCfg.getOption("MQLISTENER"));
    CfgInfo.iConnPlatm          = atoi(cCfg.getOption("ISCONNPLATM"));    
	g_IsConnCBSP = CfgInfo.iConnPlatm;
	
	g_IsConnPlatm           = atoi(cCfg.getOption("ISCONNPLATM"));

	strncpy(sQueHvps , cCfg.getOption("HVPSRECVMQ"), 60-1);
    strncpy(sQueBeps , cCfg.getOption("BEPSRECVMQ"), 60-1);
    strncpy(sQueCcms , cCfg.getOption("CCMSRECVMQ"), 60-1);
    strncpy(sQueSaps , cCfg.getOption("SAPSRECVMQ"), 60-1);

	strncpy(sQueBkHvps , cCfg.getOption("HVPSRECVBKMQ"), 60-1);
    strncpy(sQueBkBeps , cCfg.getOption("BEPSRECVBKMQ"), 60-1);
    strncpy(sQueBkCcms , cCfg.getOption("CCMSRECVBKMQ"), 60-1);
    strncpy(sQueBkSaps , cCfg.getOption("SAPSRECVBKMQ"), 60-1);

	strncpy(HvpsMQ , cCfg.getOption("CLTSENDHVPS"), 60-1);
    strncpy(BepsMQ , cCfg.getOption("CLTSENDBEPS"), 60-1);
    strncpy(CcmsMQ , cCfg.getOption("CLTSENDCCMS"), 60-1);
    strncpy(SapsMQ , cCfg.getOption("CLTSENDSAPS"), 60-1);
    
    return OPERACT_SUCCESS;
}

/*int SendtoHost(STRING strMsg, int iPort)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER SendtoHost..."); 
    
    int iSocket;
	int iRet = 0;
	int iLenth = 0;
    TSocketClient SocketClient;
    
	iSocket = SocketClient.connectServer(SocketInfo.szServerIP, iPort);
	if ( iSocket <= 0)
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "连接SocketClient失败[%d][%d][%s]", 
            iSocket, iPort, SocketInfo.szServerIP);
		return -1;
	}

	if( true != SocketClient.sendMsg(iSocket, strMsg.c_str(), strMsg.length()) )
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "发送数据失败[%s]", strMsg.c_str());
        SocketClient.disConnet();
		return -2;
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "发送数据成功[%s]", strMsg.c_str());

	SocketClient.disConnet();
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Leave SendtoHost...");
    return 0;
}*/

void UpdateStateSend(DBProc	m_dbproc, string strProState, STRING strMsgid)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER UpdateStateSend");

    string strSQL;
	strSQL += "UPDATE sys_recvfrommb t SET t.PROCTIMES = t.PROCTIMES + 1, t.PROCSTATE = '";
	strSQL += strProState;
	strSQL += "' WHERE t.MSGID = '";
	strSQL += strMsgid;
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());

    CCmrecverrmsg cCSysrecvfrommb(m_dbproc);
    int iRet = cCSysrecvfrommb.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "更新状态失败 iRet=%d, %s", iRet, cCSysrecvfrommb.GetSqlErr());
        cCSysrecvfrommb.rollback();
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }
    else
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "更新状态成功");
        cCSysrecvfrommb.commit();
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE UpdateStateSend");
    return ;
}

void UpdateState(DBProc	m_dbproc, string strProState, int iRowid)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER UpdateState");

    char szRowid[33] = {0};
    itoa(szRowid, iRowid);
    string strSQL;
	strSQL += "UPDATE cm_recverrmsg t SET t.PROCTIMES = t.PROCTIMES + 1, t.PROCSTATE = '";    

	strSQL += strProState;
	strSQL += "' WHERE t.ROW_ID = '";
	strSQL += szRowid;
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());

    CCmrecverrmsg cRecverrmsg(m_dbproc);
    int iRet = cRecverrmsg.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "更新状态失败 iRet=%d, %s", iRet, cRecverrmsg.GetSqlErr());
        cRecverrmsg.rollback();
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }
    else
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "更新状态成功");
        cRecverrmsg.commit();
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE UpdateState");
    return ;
}

int main(int argc, char * argv[])
{
    char sErrDesc[1024 + 1] = {0};
    int iRet                =  0 ;
    int iPort               =  0 ;
    stuCfgInfo           CfgInfo ;
    string strErr;
    DBProc	m_dbproc;
    MQAgent     cMQAgent;
    char sPutQueName[60]    = { 0 };
    char sQueNameHvps[60]   = { 0 }; 
    char sQueNameBeps[60]   = { 0 }; 
    char sQueNameCcms[60]   = { 0 }; 
    char sQueNameSaps[60]   = { 0 }; 
    char sQueHvps[60]   = { 0 }; 
    char sQueBeps[60]   = { 0 }; 
    char sQueCcms[60]   = { 0 }; 
    char sQueSaps[60]   = { 0 };     

    char sQueBkHvps[60]   = { 0 }; 
    char sQueBkBeps[60]   = { 0 }; 
    char sQueBkCcms[60]   = { 0 }; 
    char sQueBkSaps[60]   = { 0 };   

	//初始化全局参数
	signal(SIGINT , SIG_IGN);							//屏蔽中断信号
	signal(SIGQUIT, SIG_IGN);							//屏蔽终端退出信号
	signal(SIGALRM, SIG_IGN);							//屏蔽超时信号
	signal(SIGHUP , SIG_IGN);							//屏蔽连接断开信号
	signal(SIGSTOP, SIG_IGN); 							//这些信号被忽略
	//signal(SIGCHLD, SIG_IGN);

    try
    {
    	//初始化配置文件    
		LoadConfigFile(CfgInfo, SocketInfo, sQueNameHvps, sQueNameBeps, sQueNameCcms, sQueNameSaps,
		                        sQueHvps, sQueBeps, sQueCcms, sQueSaps,
		                        sQueBkHvps, sQueBkBeps, sQueBkCcms, sQueBkSaps);    
  
		//初始化日志
		ZFPTLOG.setCfgInfo(CfgInfo.szLogPath, "recverrmsg", CfgInfo.iLogLeave, CfgInfo.dLogMaxSize);
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化日志...");	

        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "HVPSRECVMQ = [%s]", sQueNameHvps);
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "BEPSRECVMQ = [%s]", sQueNameBeps);
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "CCMSRECVMQ = [%s]", sQueNameCcms);	
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "SAPSRECVMQ = [%s]", sQueNameSaps);
	
        //初始化MQ 
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化MQ...[%s][%s]", CfgInfo.szMQmgr, CfgInfo.szMqTxtPath);        
        if(cMQAgent.Init(CfgInfo.szMQmgr, CfgInfo.szMqTxtPath) != RTN_SUCCESS)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Init MQ manager failed.");
            exit(0);
        }
        
		//初始化XML配置文件		    	
		iRet = pCfgFile.Init(CfgInfo.szXmlCtgPath);  
		if(iRet != 0)
		{
		    sprintf(sErrDesc, "Failed to Init the node Config Object: ErrCode = %d, ErrInfo = %s", pCfgFile.GetLastErrCode(),pCfgFile.GetLastErrInfo());
	    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);
			exit(0);
		}
        
        //创建连接池 
         g_DBConnPool = new CConnectPool(1,1, CfgInfo.iNoConWaitTime);

        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化连接池...");	    
        iRet= g_DBConnPool->InitPool(CfgInfo.iConPoolSize,CfgInfo.DBUser,CfgInfo.DBKey,CfgInfo.DBName);
        if(iRet == RTN_SUCCESS)
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "连接池创建成功");
        }
        else
        {
            strErr = "连接池创建失败";
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, strErr.c_str());
            exit(0);
        }

        if(0 != g_DBConnPool->GetConnect(m_dbproc))
        {
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取数据库连接失败");
            PMTS_ThrowException(DB_CNNCT_FAIL);
        }
    }    
    catch(CException &e)
    {
    	sprintf(sErrDesc, "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());
    	DELPOINT_VOID(g_DBConnPool);
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);
        exit(0);
    }

    
    while(true)
    {
        //异常来帐处理
        try
        {    
            string strSQL;
            strSQL += "procstate = '01' and row_id = (select min(row_id) from CM_RECVERRMSG where procstate = '01')";
            //Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, strSQL.c_str());

            CCmrecverrmsg cRecverrmsg;
            SETCTX(cRecverrmsg);
            int iRet = cRecverrmsg.find(strSQL);
            if(RTN_SUCCESS != iRet)
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "打开游标失败iRet=%d, %s", iRet, cRecverrmsg.GetSqlErr());
                PMTS_ThrowException(DB_OPT_FAIL);
            }
            
            while(0 == cRecverrmsg.fetch())
            {
                Trace(L_INFO,  __FILE__,  __LINE__, NULL, "查询出记录 rowid[%d][%s]", cRecverrmsg.m_row_id, cRecverrmsg.m_msgtp.c_str());
                
                if(0 == STRCASECMP(cRecverrmsg.m_syscode.c_str(), "HVPS"))
                {
                    strncpy(sPutQueName, sQueHvps, sizeof(sPutQueName)-1);
                }
                else if(0 == STRCASECMP(cRecverrmsg.m_syscode.c_str(), "BEPS"))
                {
                    strncpy(sPutQueName, sQueBeps, sizeof(sPutQueName)-1);
                }
                else if(0 == STRCASECMP(cRecverrmsg.m_syscode.c_str(), "CCMS"))
                {
                    strncpy(sPutQueName, sQueCcms, sizeof(sPutQueName)-1);
                }
                else if(0 == STRCASECMP(cRecverrmsg.m_syscode.c_str(), "SAPS"))
                {
                    strncpy(sPutQueName, sQueSaps, sizeof(sPutQueName)-1);
                }
                else if(0 == STRCASECMP(cRecverrmsg.m_syscode.c_str(), "BKHV"))
                {
                    strncpy(sPutQueName, sQueBkHvps, sizeof(sPutQueName)-1);
                }
                else if(0 == STRCASECMP(cRecverrmsg.m_syscode.c_str(), "BKBP"))
                {
                    strncpy(sPutQueName, sQueBkBeps, sizeof(sPutQueName)-1);
                }
                else if(0 == STRCASECMP(cRecverrmsg.m_syscode.c_str(), "BKCM"))
                {
                    strncpy(sPutQueName, sQueBkCcms, sizeof(sPutQueName)-1);
                }
                else if(0 == STRCASECMP(cRecverrmsg.m_syscode.c_str(), "BKSP"))
                {
                    strncpy(sPutQueName, sQueBkSaps, sizeof(sPutQueName)-1);
                }

                Trace(L_INFO,  __FILE__,  __LINE__, NULL, "查询出记录 rowid[%d]msgtp[%s]QueName[%s]", cRecverrmsg.m_row_id, cRecverrmsg.m_msgtp.c_str(), sPutQueName);
                iRet = cMQAgent.PutMsg( sPutQueName,
                                        cRecverrmsg.m_msgtext.c_str(),
                                        cRecverrmsg.m_msgtext.length(),
                                        NULL,
                                        NULL,
                                        2,
                                        NULL,
                                        NULL,
                                        cRecverrmsg.m_row_id);

                if(RTN_SUCCESS != iRet)
                {
                    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "添加MQ失败 rowid[%d]", cRecverrmsg.m_row_id);
                    
                    cMQAgent.RollBack();
                    UpdateState(m_dbproc, "00", cRecverrmsg.m_row_id);
                }
                else
                {
                    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "添加MQ成功 rowid[%d]", cRecverrmsg.m_row_id);
                    
                    cMQAgent.Commit();
                    UpdateState(m_dbproc, "03", cRecverrmsg.m_row_id);
                }
          
            }
            cRecverrmsg.closeCursor();
      
            usleep(1000);            
        }    
        catch(CException &e)
        {
            cMQAgent.RollBack();
        	sprintf(sErrDesc, "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);
            break;
        }

        
        #if 0
        //异常往帐处理
        try
        {
            string strSQL1;
            strSQL1 += " PROCSTATE = '01'";

            CSysrecvfrommb cSysrecvfrommb;
            SETCTX(cSysrecvfrommb);
            int iRet = cSysrecvfrommb.find(strSQL1);
            if(RTN_SUCCESS != iRet)
            {
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "打开游标失败iRet=%d, %s", iRet, cSysrecvfrommb.GetSqlErr());
                PMTS_ThrowException(DB_OPT_FAIL);
            }

            while(0 == cSysrecvfrommb.fetch())
            {                
                if(0 == STRCASECMP(cSysrecvfrommb.m_sysflag.c_str(), "0"))
                {
                    strncpy(sPutQueName, sQueNameHvps, sizeof(sPutQueName)-1);
                    iPort = SocketInfo.HVPSPort;
                }
                else if(0 == STRCASECMP(cSysrecvfrommb.m_sysflag.c_str(), "1"))
                {
                    strncpy(sPutQueName, sQueNameBeps, sizeof(sPutQueName)-1);
                    iPort = SocketInfo.BEPSPort;
                }
                else if(0 == STRCASECMP(cSysrecvfrommb.m_sysflag.c_str(), "3"))
                {
                    strncpy(sPutQueName, sQueNameCcms, sizeof(sPutQueName)-1);
                    iPort = SocketInfo.CCMSPort;
                }
                else if(0 == STRCASECMP(cSysrecvfrommb.m_sysflag.c_str(), "4"))
                {
                    strncpy(sPutQueName, sQueNameSaps, sizeof(sPutQueName)-1);
                    iPort = SocketInfo.SAPSPort;
                }

                Trace(L_INFO,  __FILE__,  __LINE__, NULL, "查询出记录 msgid[%s]队列名[%s]", cSysrecvfrommb.m_msgid.c_str(), sPutQueName);

                if(2 == SocketInfo.iCommType)
                {
                    iRet = cMQAgent.PutMsg( sPutQueName,
                            cSysrecvfrommb.m_bankmsg.c_str(),
                            cSysrecvfrommb.m_bankmsg.length(),
                            NULL,
                            NULL,
                            0,
                            NULL,
                            NULL,
                            0);

                    if(RTN_SUCCESS != iRet)
                    {
                        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "添加MQ失败 msgid[%s]", cSysrecvfrommb.m_msgid.c_str());
                        
                        cMQAgent.RollBack();
                        UpdateStateSend(m_dbproc, "00", cSysrecvfrommb.m_msgid);
                    }
                    else
                    {
                        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "添加MQ成功 msgid[%s]", cSysrecvfrommb.m_msgid.c_str());

                        cMQAgent.Commit();
                        UpdateStateSend(m_dbproc, "03", cSysrecvfrommb.m_msgid);
                    }
                }
                if(1 == SocketInfo.iCommType)
                {
                   /* iRet = SendtoHost(cSysrecvfrommb.m_bankmsg, iPort);
                    if(RTN_SUCCESS != iRet)
                    {
                        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "发送失败 msgid[%s]", cSysrecvfrommb.m_msgid.c_str());
                        
                        UpdateStateSend(m_dbproc, "00", cSysrecvfrommb.m_msgid);
                    }
                    else
                    {
                        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "发送成功 msgid[%s]", cSysrecvfrommb.m_msgid.c_str());

                        UpdateStateSend(m_dbproc, "03", cSysrecvfrommb.m_msgid);
                    }  */                  
                }
                else
                {
                    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "没有找到匹配的通讯方式[%d]", SocketInfo.iCommType);
                    continue;
                }
                
                break;
            }
            cSysrecvfrommb.closeCursor();
      
            usleep(1000);              
        }
        catch(CException &e)
        {
            if(2 == SocketInfo.iCommType)
            {
                cMQAgent.RollBack();
            }
            
        	sprintf(sErrDesc, "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);
            break;        
        }
        #endif
        
    }
    g_DBConnPool->PutConnect(m_dbproc);
    
}


