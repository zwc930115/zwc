/********************************************************************
文件名：sendtocm.cpp
创建人：zhj
日  期：2011-03-03
修改人：
日  期：
描  述：客户端业务往账处理主控
版  本：
Copyright (c) 2011  YLINK
********************************************************************/

//#ifdef _LINUX_
//#define SQLCA_STORAGE_CLASS extern
//#include "sqlca.h"
//#endif
#include <sqlca.h>
#include <signal.h>
#include "exception.h"
#include "pubfunc.h"
#include "configparser.h"
#include "logger.h"
#include "thread.h"
#include "sendccmswork.h"
#include "tsocket.h"
#include "connectpool.h"
#include "cfg_obj.h"

//#include "CNAPS2hsm.h"
//#include "assist.h"

using namespace ZFPT;

CThreadPool<CSendCcmsWork> cPool;

CConnectPool    *g_DBConnPool;
CCfgObj         pCfgFile;

char            g_MQmgr[256];
char            g_MqTxtPath[256];
char            g_SendQueue[128];
char            g_SendCBSP[128];
int             g_IsConnCBSP;
char            g_IP[16];
int         	g_IsConnPlatm;

char            g_SignAddr[496];

char            g_SendHVPSQueue[128];  //发送队列需分三个,往支付平台发送
char            g_SendCCMSQueue[128];
char            g_SendSAPSQueue[128];
char            g_ReturnQueue[128];  //
char            g_SendMBQueue[128];  //往行内发送队列

char            g_strSapBank[13];

int             g_iCfcaSign = 0;//是否加签名或加押

#define MQ_ERR_MAX_TIMES    3
bool  DoWork(char* strMsg, int ClientSocket, char * strClientIP)
{
    int iRet = -1;

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Enter DoWork...");
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strMsg=[%s]", strMsg);
	
	CSendCcmsWork CSendCcmsWork;
	CSendCcmsWork.ClientSocket = ClientSocket;
	CSendCcmsWork.UnpackMsgHead(strMsg);

	while(JOBPOOL_FULL == (iRet = cPool.push(CSendCcmsWork)))
	{
	    printf("任务满,等待5秒!");
	    usleep(5);
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Leave DoWork...");

	return true;
}

int LoadConfigFile(stuCfgInfo &CfgInfo)
{
	//注意：在这个函数内不要用trace打日志，加载时，日志没有进行初始化
	CConfigParser& cCfg = CConfigParser::getInstance();

	strcpy(CfgInfo.path, ZFPT_CFG_PATH);
    cCfg.loadConfig(CfgInfo.path);

	strncpy(CfgInfo.szXmlCtgPath, cCfg.getOption("XMLCTGPATH"),sizeof(CfgInfo.szXmlCtgPath)-1);
	strncpy(CfgInfo.szLogPath   , cCfg.getOption("LOGPATH")   , sizeof(CfgInfo.szLogPath)-1  );
    CfgInfo.iPort           = atoi(cCfg.getOption("CCMSPORT")  );
    CfgInfo.iLogLeave       = atoi(cCfg.getOption("LOGLVL")    );
	CfgInfo.dLogMaxSize     = atof(cCfg.getOption("LOGMAXSIZE"));
	
	memset(g_MQmgr     , 0x00, sizeof(g_MQmgr)    );
	memset(g_SendQueue , 0x00, sizeof(g_SendQueue));
	memset(g_MqTxtPath , 0x00, sizeof(g_MqTxtPath));
	memset(g_ReturnQueue , 0x00, sizeof(g_ReturnQueue));
  memset(g_SignAddr , 0x00, sizeof(g_SignAddr));
  
  strncpy(g_SignAddr, cCfg.getOption("SIGNADDR"), sizeof(g_SignAddr)-1);		
	strncpy(g_MQmgr    , cCfg.getOption("MQMGR")     , sizeof(g_MQmgr)-1    );
    strncpy(g_SendQueue, cCfg.getOption("CCMSSENDMQ"), sizeof(g_SendQueue)-1);
    strncpy(g_MqTxtPath, cCfg.getOption("MQTEXTPATH"), sizeof(g_MqTxtPath)-1);

	strncpy(g_ReturnQueue, cCfg.getOption("CLTRECVRETN"), sizeof(g_ReturnQueue)-1);
    strncpy(CfgInfo.szCltSendMQ  , cCfg.getOption("CLTSENDCCMS"), sizeof(CfgInfo.szCltSendMQ  )-1);

    
	CfgInfo.iConPoolMinNum      = atoi(cCfg.getOption("CMCONNPOOLMINSIZE")   );
	CfgInfo.iConPoolMaxNum      = atoi(cCfg.getOption("CMCONNPOOLMAXSIZE")   );
	CfgInfo.iNoConWaitTime	    = atoi(cCfg.getOption("CMNOCONNWAITTIME")    );
	CfgInfo.iConPoolSize        = atoi(cCfg.getOption("CMCONNPOOLSIZE")      );
	CfgInfo.iThreadPoolSize     = atoi(cCfg.getOption("CMTHREADPOOLSIZE")    );
    CfgInfo.iThreadPoolTaskSize = atoi(cCfg.getOption("CMTHREADPOOLTASKSIZE"));
	
    strncpy(CfgInfo.DBUser, cCfg.getOption("DBUSER"), sizeof(CfgInfo.DBUser)-1);
    //alter in 20171130
    CfgInfo.iDBKeyType = atoi(cCfg.getOption("DBKEYTYPE"));
    if (CfgInfo.iDBKeyType == 1) //密码为明文
    {
				strncpy(CfgInfo.DBKey, cCfg.getOption("DBKEY"), sizeof(CfgInfo.DBKey)-1);
    }
    if (CfgInfo.iDBKeyType == 0) //密码为密文
    {
				CfgInfo.DBKey_new.Format("%s", cCfg.getOption("DBKEY"));
				DecodeDBPsw(CfgInfo.DBKey_new);
				strncpy(CfgInfo.DBKey, CfgInfo.DBKey_new.GetBuffer(0), sizeof(CfgInfo.DBKey)-1);
    }
    //alter end
    strncpy(CfgInfo.DBName, cCfg.getOption("DBNAME"), sizeof(CfgInfo.DBName)-1);

    strncpy(CfgInfo.szMqServConn  , cCfg.getOption("MQSERVCONN")  , sizeof(CfgInfo.szMqServConn) - 1  );
    strncpy(CfgInfo.szPmInfoHdFlg1, cCfg.getOption("PMINFOHDFLG1"), sizeof(CfgInfo.szPmInfoHdFlg1) - 1);
    strncpy(CfgInfo.szPmInfoHdFlg2, cCfg.getOption("PMINFOHDFLG2"), sizeof(CfgInfo.szPmInfoHdFlg2) - 1);
    strncpy(CfgInfo.szCbspRecvMQ  , cCfg.getOption("CBSPRECVMQ")  , sizeof(CfgInfo.szCbspRecvMQ) - 1  );    
    CfgInfo.iMqListener         = atoi(cCfg.getOption("MQLISTENER"));
    CfgInfo.iConnPlatm          = atoi(cCfg.getOption("ISCONNPLATM"));      
	strncpy(g_SendCBSP, CfgInfo.szCbspRecvMQ, sizeof(g_SendCBSP)-1);
	g_IsConnCBSP   = CfgInfo.iConnPlatm;	
	g_IsConnPlatm  = CfgInfo.iConnPlatm;
	
	//g_iCfcaSign = atoi(cCfg.getOption("CERTSIGN"));
	
    return OPERACT_SUCCESS;
}


int main(int argc, char * argv[])
{
	
	//SigLoad();
	
    char sErrDesc[1024 + 1] = {0};
    int iRet                =  0 ;
    stuCfgInfo           CfgInfo ;
    MQAgent              cAgent;
    
	//初始化全局参数
	signal(SIGINT , SIG_IGN);							//屏蔽中断信号
	signal(SIGQUIT, SIG_IGN);							//屏蔽终端退出信号
	signal(SIGALRM, SIG_IGN);							//屏蔽超时信号
	signal(SIGHUP , SIG_IGN);							//屏蔽连接断开信号
	signal(SIGSTOP, SIG_IGN); 							//这些信号被忽略
	//signal(SIGCHLD, SIG_IGN);
    
    try
    {
    	//初始化配置文件
        LoadConfigFile(CfgInfo);
			
		//初始化日志	
		ZFPTLOG.setCfgInfo(CfgInfo.szLogPath, "sendtoccms", CfgInfo.iLogLeave, CfgInfo.dLogMaxSize);
        
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化日志...");

		//获取本机ip
        char* IP = GetLocalIp();
        if(IP != NULL)
        {
            strncpy(g_IP, IP, sizeof(g_IP) - 1);
        }
        else
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取本机IP失败,与平台连接标志重新设置为断开状态,并且不向平台发送错误日志");
            g_IsConnCBSP = 0;
        }

		//初始化XML配置文件		
		iRet = pCfgFile.Init(CfgInfo.szXmlCtgPath);  
		if(iRet != 0)
		{
		    sprintf(sErrDesc, "Failed to Init the node Config Object: ErrCode = %d, ErrInfo = %s", pCfgFile.GetLastErrCode(),pCfgFile.GetLastErrInfo());
	    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);
	    	
			exit(0);
		}

		//初始化MQ 
        if(cAgent.Init(g_MQmgr, g_MqTxtPath) != RTN_SUCCESS)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Init MQ manager failed.");
            exit(0);
        }
        
        //创建连接池 
        g_DBConnPool = new CConnectPool(CfgInfo.iConPoolMinNum,CfgInfo.iConPoolMaxNum, CfgInfo.iNoConWaitTime);

        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化连接池...");	    
	    
        iRet= g_DBConnPool->InitPool(CfgInfo.iConPoolSize,CfgInfo.DBUser,CfgInfo.DBKey,CfgInfo.DBName);
		
        if(iRet == RTN_SUCCESS)
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "连接池创建成功");
        }
        else
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "连接池创建失败");
            
            exit(0);
        }

        cPool.start(CfgInfo.iThreadPoolSize, CfgInfo.iThreadPoolTaskSize);
        
    }
    catch(CException &e)
    {
    	sprintf(sErrDesc, "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);
        
        exit(0);
    }

    bool        IsHasMsg              = false; //是否读到了消息
    int         iErrMsgFlag           = 0 ;
    int         iErrTimes             = 0 ;
    STRING      sMsg                  = "";    //MQ报文
    STRING      sFile                 = "";    //MQ收到的文件名称
    char        szMQMsgID[64];    //MQ消息ID
    char        szMsgNo[3 + 1]        = { 0 };
    
    //获取MQ中消息报文
    while(true)
    {
        try
        {
            IsHasMsg  = false;
            sMsg      = "";
            sFile     = "";	
            
            //从实时队列中读取消息
            iErrMsgFlag = 0;
            memset(szMQMsgID, 0x00, sizeof(szMQMsgID));
			iRet = cAgent.GetMsg(CfgInfo.szCltSendMQ, sMsg, sFile, iErrMsgFlag, GET_MQMSG_MAXTIME);
            if(0 == iRet)
            {		
                //读到消息
                cAgent.Commit();
                iErrTimes = 0;
                IsHasMsg = true;
                
                memcpy(szMQMsgID, cAgent.GetMsgId(), sizeof(szMQMsgID)-1);

                string strtest = MbBinToHex((unsigned char* )szMQMsgID,24);
                
                Trace(L_INFO,  __FILE__,  __LINE__, NULL, "unchange:szMQMsgID=[%s]", szMQMsgID);
                Trace(L_INFO,  __FILE__,  __LINE__, NULL, "changed:szMQMsgID=[%s]", strtest.c_str());   

                
                CSendCcmsWork CSendCcmsWork;
            	memcpy(CSendCcmsWork.m_MQMsgId ,szMQMsgID, sizeof(szMQMsgID));
            	CSendCcmsWork.UnpackMsgHead(sMsg.c_str());
            
            	while(JOBPOOL_FULL == (iRet = cPool.push(CSendCcmsWork)))
            	{
            	    printf("任务满,等待5秒!");
            	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "任务满,等待5秒");
            	    sleep(5);
            	}
            	
                if(0 == iRet)
                {
                    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "添加任务成功");
                }
            }
            else if (1 == iRet)
            {            
                IsHasMsg =false;
            }
            else if(-1 == iRet)
            {   
            	//读取消息失败
                iErrTimes++;
				
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Get MQ message failed:[%s]", CfgInfo.szCltSendMQ);
    			
                if(iErrTimes >= MQ_ERR_MAX_TIMES) 
                {
                    break;
                }
            }
			
            if(!IsHasMsg)
            {
                usleep(1000);
                continue;		
            }
			
        }
        catch(CException &e)
        {
            sprintf(sErrDesc, "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);
            sleep(3);
	
        }

    }
	DELPOINT_VOID(g_DBConnPool);
	
    return 0;
}

