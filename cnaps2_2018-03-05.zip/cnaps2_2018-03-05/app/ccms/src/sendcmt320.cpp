/******************************************************************** 
�ļ����� sendcmt320.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt320.h"

using namespace ZFPT;

CSendCmt320::CSendCmt320(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{
}

CSendCmt320::~CSendCmt320()
{
}

INT32 CSendCmt320::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt320::doWorkSelf");

    GetData();
    
    SetData();

    buildCmtMsg();
    
    UpdateState();

    // ���ͱ���
    AddQueue(m_cmt320.m_strCmtmsg.c_str(), m_cmt320.m_strCmtmsg.length());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt320::doWorkSelf"); 
    return 0;
}

INT32 CSendCmt320::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt320::SetData");
    
    strncpy(m_cmt320.sConsigndate,          m_cmpmtrtrcl.m_consigndate.c_str(),  sizeof(m_cmt320.sConsigndate)-1);    //ί������              CHAR(8)      NOT NULL 
    strncpy(m_cmt320.sOldsendsapbk,         m_cmpmtrtrcl.m_instddrctpty.c_str(),   sizeof(m_cmt320.sOldrecvsapbk)-1); 
    strncpy(m_cmt320.sOldsendbk,            m_cmpmtrtrcl.m_instdindrctpty.c_str(),  sizeof(m_cmt320.sOldrecvbk)-1);
    strncpy(m_cmt320.sReplyno,             m_cmpmtrtrcl.m_msgid.c_str()+8,   sizeof(m_cmt320.sReplyno)-1);
    strncpy(m_cmt320.sOldrebackdate,         m_cmpmtrtrcl.m_orgnlmsgid.c_str(),   sizeof(m_cmt320.sOldrebackdate)-1); 
    strncpy(m_cmt320.sOldmssno,          m_cmpmtrtrcl.m_orgnlmsgid.c_str()+8,    sizeof(m_cmt320.sOldmssno)-1);
    strncpy(m_cmt320.sRebacktype,          m_cmpmtrtrcl.m_returntype.c_str(),    sizeof(m_cmt320.sRebacktype)-1);
    strncpy(m_cmt320.sReplyflag,            m_cmpmtrtrcl.m_retunstat.c_str(),  sizeof(m_cmt320.sReplyflag)-1);
    //strncpy(m_cmt320.sTextkey,     ,sizeof(m_cmt320.sTextkey)-1);         //��Ѻ                   40x           NULL
    strncpy(m_cmt320.sRemark,     m_cmpmtrtrcl.m_rtinfo.c_str(),    sizeof(m_cmt320.sRemark)-1);          //�˻����븽��           60g           NULL
    
    
    SETCTX(m_Orgncmpmtrtrcl);
		m_Orgncmpmtrtrcl.m_sysid = "BEPS";
		m_Orgncmpmtrtrcl.m_instgindrctpty = m_cmpmtrtrcl.m_orgninstgdrctpty;
		m_Orgncmpmtrtrcl.m_msgid = m_cmpmtrtrcl.m_orgnlmsgid;
		m_Orgncmpmtrtrcl.m_rsflag = "2";
		
	  int iRet = m_Orgncmpmtrtrcl.findByPK();
	  if (SQL_SUCCESS != iRet) 
		{
			sprintf(m_sErrMsg, "��ѯԭ�����鷢������[%s], [%s], [%d][%s]",
			   m_cmpmtrtrcl.m_orgninstgdrctpty.c_str(), m_cmpmtrtrcl.m_orgnlmsgid.c_str(), iRet, m_Orgncmpmtrtrcl.GetSqlErr());
			
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
			
			PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
		}
		
		strncpy(m_cmt320.sOldrecvsapbk,            m_Orgncmpmtrtrcl.m_instdindrctpty.c_str(),  sizeof(m_cmt320.sOldsendsapbk)-1);
    strncpy(m_cmt320.sOldrecvbk,           m_Orgncmpmtrtrcl.m_instddrctpty.c_str(), sizeof(m_cmt320.sOldsendbk)-1);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt320::SetData"); 
    return 0;
}

int CSendCmt320::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendCmt320::getData");

	SETCTX(m_cmpmtrtrcl);
	
    m_cmpmtrtrcl.m_sysid = "BEPS";
  	m_cmpmtrtrcl.m_instgindrctpty = m_szSndNO;
  	m_cmpmtrtrcl.m_msgid        = m_szMsgFlagNO;
  	m_cmpmtrtrcl.m_rsflag        = "1";
  	
  	int iRet = m_cmpmtrtrcl.findByPK();
  	if (SQLNOTFOUND == iRet)
	{
		sprintf(m_sErrMsg, "�Ҳ���ָ��ҵ��[%s], [%s], [%d][%s]", 
		    m_szSndNO, m_szMsgFlagNO, iRet, m_cmpmtrtrcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	} 	
	else if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg, "��ѯ���ܱ���������[%s], [%s], [%d][%s]",
		    m_szSndNO, m_szMsgFlagNO, iRet, m_cmpmtrtrcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}
   
    if("0" == m_cmpmtrtrcl.m_returntype)
    {
        SETCTX(m_cmpmtrtrlist);
        
	    STRING strSql;
	    strSql = "msgid";
	    strSql += " = '"+ m_cmpmtrtrcl.m_msgid +"'";
	    strSql += " and rsflag = '1' and instgdrctpty = '" ;
	    strSql += m_szSndNO;
	    strSql += "' ";
	    
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql = [%s]", strSql.c_str());
	    if(SQL_SUCCESS == m_cmpmtrtrlist.find(strSql))
	    {
		    m_cmpmtrtrlist.fetch();
            m_orgnltxid = m_cmpmtrtrlist.m_orgnltxid;
		    m_cmpmtrtrlist.closeCursor();
	    }
	    else
	    {
    		sprintf(m_sErrMsg, "��ѯ��ϸ����������[%s], [%s], [%s]",
    		    m_cmpmtrtrcl.m_orgnlmsgid.c_str(), m_cmpmtrtrcl.m_msgid.c_str(), m_cmpmtrtrlist.GetSqlErr());
    		
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
    		
    		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    	}  
    }
 
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendCmt320::getData"); 
    
	return iRet;
}


int CSendCmt320::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt123::buildCmtMsg...");

    int iRet = m_cmt320.CreateCmt("320", m_szSndNO, m_cmpmtrtrcl.m_instddrctpty.c_str(), m_sMesgId.c_str(), m_sMesgId.c_str(), m_cmpmtrtrcl.m_wrkdate.c_str(), "3");
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt320::buildCmtMsg...");
    return iRet;
}


int CSendCmt320::UpdateState(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendCmt320::UpdateDb");

	string strSQL;
	strSQL += "UPDATE CM_PMTRTRCL t SET t.Procstate = '";
    strSQL += PR_HVBP_08;
	strSQL += "', t.STATETIME = sysdate ";
	strSQL += ", t.MESGID='"+m_sMesgId+"' ";
    strSQL += ", t.MESGREFID ='"+m_sMesgId+"' ";
    strSQL += " WHERE t.msgid = '";
	strSQL += m_cmpmtrtrcl.m_msgid;
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_cmpmtrtrcl.m_instgindrctpty; 
	strSQL += "' AND t.RSFLAG = '";
	strSQL += m_cmpmtrtrcl.m_rsflag; 
	strSQL += "'";
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, strSQL.c_str());
	
    SETCTX(m_cmpmtrtrcl);
	int iRet = m_cmpmtrtrcl.execsql(strSQL.c_str());
	if (iRet != SQL_SUCCESS)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]",
		    iRet, m_cmpmtrtrcl.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
	}
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt320::UpdateDb...");
    
    return iRet;
    
    //�������Ϊ�޸�ԭ�����ԭҵ��״̬�ģ��Ѿ����������޸�״̬�ˣ�����ռʱ����
    SETCTX(m_Orgncmpmtrtrcl);
	m_Orgncmpmtrtrcl.m_sysid = "BEPS";
	m_Orgncmpmtrtrcl.m_instgindrctpty = m_cmpmtrtrcl.m_orgninstgdrctpty;
	m_Orgncmpmtrtrcl.m_msgid = m_cmpmtrtrcl.m_orgnlmsgid;
	m_Orgncmpmtrtrcl.m_rsflag = "2";
	
    iRet = m_Orgncmpmtrtrcl.findByPK();
  	if (SQLNOTFOUND == iRet)
	{
		sprintf(m_sErrMsg, "�Ҳ���ָ��ҵ��[%s], [%s], [%d][%s]", 
		   m_cmpmtrtrcl.m_orgninstgdrctpty.c_str(), m_cmpmtrtrcl.m_orgnlmsgid.c_str(), iRet, m_Orgncmpmtrtrcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	} 	
	else if (SQL_SUCCESS != iRet) 
	{
		sprintf(m_sErrMsg, "��ѯԭ�����鷢������[%s], [%s], [%d][%s]",
		   m_cmpmtrtrcl.m_orgninstgdrctpty.c_str(), m_cmpmtrtrcl.m_orgnlmsgid.c_str(), iRet, m_Orgncmpmtrtrcl.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}
	
    if (m_cmpmtrtrcl.m_retunstat=="1")
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ͬ���˻�, ��������״̬.");
        
        if(m_Orgncmpmtrtrcl.m_returntype=="1")
        {
            SETCTX(m_bpbcoutrcvcl);
             CreateSql("bp_bcoutrcvcl",m_Orgncmpmtrtrcl.m_orgnlmsgid.c_str(),m_Orgncmpmtrtrcl.m_orgnlmsgnmid.c_str(),
                m_Orgncmpmtrtrcl.m_orgninstgdrctpty.c_str());
                
             iRet = m_bpbcoutrcvcl.execsql(m_strSql);
             if (iRet != SQL_SUCCESS)
             {
                SETCTX(m_bpbcoutrcvclhis);
                CreateSql("bp_bcoutrcvclhis",m_Orgncmpmtrtrcl.m_orgnlmsgid.c_str(),m_Orgncmpmtrtrcl.m_orgnlmsgnmid.c_str(),
                m_Orgncmpmtrtrcl.m_orgninstgdrctpty.c_str());
                
                iRet = m_bpbcoutrcvclhis.execsql(m_strSql);
                if (iRet != SQL_SUCCESS)
                {
                    Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]",
                        iRet, m_bpbcoutrcvcl.GetSqlErr());
                    Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]",
                        iRet, m_bpbcoutrcvclhis.GetSqlErr());
                    PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
                }
             }
             
        }
        else if(m_Orgncmpmtrtrcl.m_returntype=="0")
        {
            SETCTX(m_bpbcoutrecvlist);
            CreateSql("bp_bcoutrecvlist",m_Orgncmpmtrtrcl.m_orgnlmsgid.c_str(),m_Orgncmpmtrtrcl.m_orgnlmsgnmid.c_str(),
                m_Orgncmpmtrtrcl.m_orgninstgdrctpty.c_str(),m_orgnltxid.c_str(),true);
             iRet = m_bpbcoutrecvlist.execsql(m_strSql);
             if (iRet != SQL_SUCCESS)
             {
                SETCTX(m_bpbcoutrecvlisthis);
                CreateSql("bp_bcoutrecvlisthis",m_Orgncmpmtrtrcl.m_orgnlmsgid.c_str(),m_Orgncmpmtrtrcl.m_orgnlmsgnmid.c_str(),
                     m_Orgncmpmtrtrcl.m_orgninstgdrctpty.c_str(),m_orgnltxid.c_str(),true);
                
                iRet = m_bpbcoutrecvlisthis.execsql(m_strSql);
                if (iRet != SQL_SUCCESS)
                {
                    Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]",
                        iRet, m_bpbcoutrcvcl.GetSqlErr());
                    Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]",
                        iRet, m_bpbcoutrcvclhis.GetSqlErr());
                    PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
                }
             }
        }
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendCmt320::UpdateDb");
    return RTN_SUCCESS;
}

int CSendCmt320::CreateSql(const char *sTableName,const char *sMsgid,const char *sMsgTp,const char *sSendBank,const char *txid,bool sFlag)
{
     m_strSql = "UPDATE ";
     m_strSql += sTableName;
     m_strSql += " t SET t.Procstate = '";
     m_strSql += PR_HVBP_33;
     m_strSql += "', t.STATETIME = sysdate ";
     m_strSql += " WHERE t.msgid = '";
     m_strSql += sMsgid;
     m_strSql += "' AND t.INSTGDRCTPTY = '";
     m_strSql += sSendBank; 
     m_strSql += "' ";
     
     if(sFlag==1)
     {
        m_strSql += " AND T.TXID = '";
        m_strSql += txid; 
        m_strSql += "' ";
     }
     
     Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strSql = [%s]", m_strSql.c_str());
     return 0;
}




