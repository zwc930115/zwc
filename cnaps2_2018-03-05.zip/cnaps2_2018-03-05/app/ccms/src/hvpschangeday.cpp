/******************************************************************** 
文件名： hvpschangeday.cpp
创建人： handongfeng
日  期： 2011-05-09
修改人： aps-zhj
日  期： 
描  述： 大额日切类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "hvpschangeday.h"
#include "exception.h"
#include "StorProc.h"

using namespace ZFPT;

CHvpsChangeDay::CHvpsChangeDay()
{
    memset(m_sOrgnlSysDt, NULL_CHAR, sizeof(m_sOrgnlSysDt   ));
	memset(m_sCurSysDt  , NULL_CHAR, sizeof(m_sCurSysDt     )); 
	memset(m_szNextSysDt, NULL_CHAR, sizeof(m_szNextSysDt   ));
	memset(m_sBankNo    , NULL_CHAR, sizeof(m_sBankNo       ));
	m_szFeastFlg = "";
}

int CHvpsChangeDay::doChangeWork(DBProc &dbproc, int iFun, int iDayCutType, LPCSTR sBankNo, LPCSTR sOrgnlSysDt, LPCSTR sCurSysDt)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::doChangeWork()");
	
	strncpy(m_sOrgnlSysDt   , sOrgnlSysDt   , sizeof(m_sOrgnlSysDt  ) - 1);
	strncpy(m_sCurSysDt     , sCurSysDt     , sizeof(m_sCurSysDt    ) - 1);
	strncpy(m_sBankNo       , sBankNo       , sizeof(m_sBankNo      ) - 1);
	m_dbproc = dbproc;
    
    // 日切处理
	try
	{
	    GetData();

        switch(iFun)
        {
            case 0:
            {
                if (0 == iDayCutType)   //0正常日切
                {
                    //CompareCheckState();
                    MoveData();
                }
                
                resetSerialNo();        //2.序号重置
                
                changEffect();			//3.生效变更
                
                break;
            }
            case 1:
            {
                if (0 == iDayCutType)   //0正常日切
                {
                    CompareCheckState();
                }
                break;
            }
            case 2:
            {
                resetSerialNo();        //2.序号重置
                break; 
            }
            case 3:
            {
                changEffect();			//3.生效变更
                break;
            }
            default:
            {
                Trace(L_ERROR, __FILE__, __LINE__, NULL, "没有匹配的函数入口标志iFun=%d", iFun);
            }
         }
	}
	catch (CException &e)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, 
        	"Catch a exception from [%s][%d][%s]", e.file(), e.line(), e.what());
		
		return RTN_FAIL;
	}

    string sTellInfo = "";
    if (0 == iDayCutType)//0正常日切
    {
        sTellInfo += "大额正常日切成功,当前工作日期:";
    }
	else
	{
	    sTellInfo += "大额强制日切成功,当前工作日期:";
	}

    sTellInfo += m_sCurSysDt;
	//NotifyOprUser(m_dbproc, "2" "00", sTellInfo.c_str(), m_sBankNo);
	
	Trace(L_INFO, __FILE__, __LINE__, NULL, "sTellInfo = [%s]", sTellInfo.c_str());

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsChangeDay::doChangeWork()");
	return RTN_SUCCESS;
}

void CHvpsChangeDay::GetData()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::GetData()");

    SETCTX(m_Hvsapbankinfo);
    m_Hvsapbankinfo.m_sapbank   = m_sBankNo;

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_Hvsapbankinfo.m_sapbank =[%s]", m_Hvsapbankinfo.m_sapbank.c_str());
    
	int iRet = m_Hvsapbankinfo.findByPK();
	if(SQL_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
                "获取数据失败iRet=%d, %s", iRet, m_Hvsapbankinfo.GetSqlErr());
        //NotifyOprUser(m_dbproc, "0", "00", "大额待日切信息表中找不到当前日期日切记录", m_sBankNo);
        PMTS_ThrowException(DB_GET_DATA_FAIL);
    }
	
    m_szFeastFlg = m_Hvsapbankinfo.m_feastflag;
    strncpy(m_szNextSysDt, m_Hvsapbankinfo.m_nextdate.c_str(), sizeof(m_szNextSysDt));

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsChangeDay::GetData()");
}

void CHvpsChangeDay::CompareCheckState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::CompareCheckState()");
    
    char szISOOrgnlDt[10 + 1] = { 0 };
    
    chgToISODate(m_sOrgnlSysDt, szISOOrgnlDt);
    
    SETCTX(m_Hvbkchkst);
    
    m_Hvbkchkst.m_sapbank   = m_sBankNo;
    m_Hvbkchkst.m_checkdate = szISOOrgnlDt;

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_Hvbkchkst.m_sapbank    =[%s]", m_Hvbkchkst.m_sapbank.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_Hvbkchkst.m_checkdate  =[%s]", m_Hvbkchkst.m_checkdate.c_str());
    
    int iRet = m_Hvbkchkst.findByPK();
    if(SQL_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
                "获取数据失败iRet=%d, %s", iRet, m_Hvbkchkst.GetSqlErr());
        //NotifyOprUser(m_dbproc,"2" "01", "大额对帐状态信息表中找不到当前日期日切记录", m_sBankNo);
        PMTS_ThrowException(DB_GET_DATA_FAIL);
    }
    
    if("01" != m_Hvbkchkst.m_checkstate)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "大额对账状态不符");
        //NotifyOprUser(m_dbproc, "2","01", "对账不符", m_sBankNo);
        PMTS_ThrowException(OPT_TRADE_CHECK__FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsChangeDay::CompareCheckState()");

}


void CHvpsChangeDay::changEffect()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::changEffect()");

	changcmlist();			//1.1 业务种类与类型管理<ccms.906.001.01>
    changbclsstpmslist();
    changBankinfo();
    changccpcchng();
    changCitychng();
    changBktpchng();
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsChangeDay::changEffect()");
}

/*********************************************/
void CHvpsChangeDay::InsertMsgType(const CCmbclsstpmglist* cmlist)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::InsertMsgType()");

    SETCTX(m_cmmsgtype);

    m_cmmsgtype.m_msgtype           = cmlist->m_mt;         
    m_cmmsgtype.m_biztype           = cmlist->m_txtpcd;     
    m_cmmsgtype.m_bizdtltypepurpose = cmlist->m_ctgypurpcd; 

    //删除原有记录
    int iRet = m_cmmsgtype.remove();
	if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "删除表记录失败[%d][%s]",
		    iRet, m_cmmsgtype.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_DEL_FAIL, "删除表记录失败");
	}

    //如果变更类型是新增/变更，则新增记录
    if ( "CC00" == cmlist->m_chngtp || "CC01" == cmlist->m_chngtp)
    {
        int iValue = m_cmmsgtype.insert();
        if(RTN_SUCCESS != iValue)
        {
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "插入表失败[%d][%s]", iValue, m_cmmsgtype.GetSqlErr());	
    		PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, "插入表失败");
        }
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::InsertMsgType()");
}

void CHvpsChangeDay::changcmlist()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::changcmlist()");

    try
    {
        string sSQLHead = "UPDATE cm_bclsstpmglist t SET t.PROCSTATE = '";
        ChangTableState(&m_cmlist, 1, sSQLHead);
    }
    catch(CException &e)
    {
        m_cmlist.closeCursor();
        PMTS_ThrowException(UNKNOWN_ERR);
    }
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsChangeDay::changcmlist()");
}
/*********************************************/

/*********************************************/
void CHvpsChangeDay::InsertSysparm(const CCmsyspamntfctnlist* bclsstpmslist)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::Insertmsgtype()");

    SETCTX(m_cmsysparm);

    m_cmsysparm.m_syscode= bclsstpmslist->m_sysid  ; 
    m_cmsysparm.m_datatype= bclsstpmslist->m_cmondatatp  ; 
    m_cmsysparm.m_datacode= bclsstpmslist->m_cmondatacd  ; 
    m_cmsysparm.m_datachgtype= bclsstpmslist->m_chgtp  ; 
    m_cmsysparm.m_dataname= bclsstpmslist->m_cmondatanm  ; 
    m_cmsysparm.m_datavalue= bclsstpmslist->m_cmondataval  ; 

    //删除原有记录
    int iRet = m_cmsysparm.remove();
	if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "删除表记录失败[%d][%s]",
		    iRet, m_cmsysparm.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_DEL_FAIL, "删除表记录失败");
	}

    //如果变更类型是新增/变更，则新增记录
    if ( "CC00" == bclsstpmslist->m_chgtp || "CC01" == bclsstpmslist->m_chgtp)
    {
        int iValue = m_cmsysparm.insert();
        if(RTN_SUCCESS != iValue)
        {
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "插入表失败[%d][%s]", iValue, m_cmsysparm.GetSqlErr());	
    		PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, "插入表失败");
        }
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsChangeDay::Insertmsgtype()");
}

void CHvpsChangeDay::changbclsstpmslist()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::changbclsstpmslist()");
	
    try
    {
        string sSQLHead = "UPDATE cm_bclsstpmglist t SET t.PROCSTATE = '";
        ChangTableState(&m_Cmsyspamntfctnlist, 2, sSQLHead);
    }
    catch(CException &e)
    {
        m_Cmsyspamntfctnlist.closeCursor();
        PMTS_ThrowException(UNKNOWN_ERR);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsChangeDay::changbclsstpmslist()");
}
/*********************************************/

/*********************************************/
void CHvpsChangeDay::Insertbankinfo(const CCmbkcdchgntfctnlist* bankinfo)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::InsertCity()");

    SETCTX(m_Cmbankinfo);

    m_Cmbankinfo.m_bankcode = bankinfo->m_bankcode;
    m_Cmbankinfo.m_bankname = bankinfo->m_bankname;
    m_Cmbankinfo.m_bankcatalog= bankinfo->m_bankcatalog;
    m_Cmbankinfo.m_banktype = bankinfo->m_banktype;
    m_Cmbankinfo.m_pbccode = bankinfo->m_pbccode;
    m_Cmbankinfo.m_bankcenter = bankinfo->m_bankcenter;
    m_Cmbankinfo.m_bankagent = bankinfo->m_drctbkcd;
    m_Cmbankinfo.m_agentsettbank = "";//代理清算参与机构号
    m_Cmbankinfo.m_dreccode = bankinfo->m_dreccode;
    m_Cmbankinfo.m_syscode = bankinfo->m_sysid;
    m_Cmbankinfo.m_addr = bankinfo->m_addr;
    m_Cmbankinfo.m_postcode = bankinfo->m_postcode;
    m_Cmbankinfo.m_tel = bankinfo->m_tel;
    m_Cmbankinfo.m_email = bankinfo->m_email;
    m_Cmbankinfo.m_effectdate = bankinfo->m_fctvdt;
    m_Cmbankinfo.m_expdate = bankinfo->m_ifctvdt;
    m_Cmbankinfo.m_sbstitnbk = bankinfo->m_sbstitnbk;
    m_Cmbankinfo.m_debtorcity = bankinfo->m_debtorcity;
    m_Cmbankinfo.m_bankaliasname = bankinfo->m_bankaliasname;
    m_Cmbankinfo.m_procstate = bankinfo->m_procstate;
    m_Cmbankinfo.m_proctime = bankinfo->m_proctime;

    //删除原有记录
    int iRet = m_Cmbankinfo.remove();
	if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "删除表记录失败[%d][%s]",
		    iRet, m_Cmbankinfo.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_DEL_FAIL, "删除表记录失败");
	}

    //如果变更类型是新增/变更，则新增记录
    if ( "CC00" == bankinfo->m_chngtp || "CC01" == bankinfo->m_chngtp)
    {
        int iValue = m_Cmbankinfo.insert();
        if(RTN_SUCCESS != iValue)
        {
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "插入表失败[%d][%s]", 
    			                                                iValue, m_Cmbankinfo.GetSqlErr());	
    		PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, "插入表失败");
        }
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsChangeDay::InsertCity()");
}

void CHvpsChangeDay::changBankinfo()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::changBankinfo()");
	
    try
    {
        string sSQLHead = "UPDATE cm_syspamntfctnlist t SET t.PROCSTATE = '";
        ChangTableState(&m_Cmsyspamntfctnlist, 3, sSQLHead);
    }
    catch(CException &e)
    {
        m_Cmsyspamntfctnlist.closeCursor();
        PMTS_ThrowException(UNKNOWN_ERR);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsChangeDay::changBankinfo()");
}
/*********************************************/

/*********************************************/
void CHvpsChangeDay::Insertccpc(const CCmccpcchng* ccpc)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::InsertCity()");

    SETCTX(m_ccpc);
    m_ccpc.m_nodecode = ccpc->m_nodecode; 
    m_ccpc.m_ndname = ccpc->m_ndname; 
    m_ccpc.m_nodetype = ccpc->m_nodetype; 
    m_ccpc.m_citycd = ccpc->m_citycd; 
    m_ccpc.m_procstate = ccpc->m_procstate; 

    //删除原有记录
    int iRet = m_ccpc.remove();
	if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "删除表记录失败[%d][%s]",
		    iRet, m_ccpc.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_DEL_FAIL, "删除表记录失败");
	}

    //如果变更类型是新增/变更，则新增记录
    if ( "CC00" == ccpc->m_chngtp || "CC01" == ccpc->m_chngtp)
    {
        int iValue = m_ccpc.insert();
        if(RTN_SUCCESS != iValue)
        {
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "插入表失败[%d][%s]", iValue, m_ccpc.GetSqlErr());	
    		PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, "插入表失败");
        }
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsChangeDay::InsertCity()");
}

void CHvpsChangeDay::changccpcchng()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::changccpcchng()");

    try
    {
        string sSQLHead = "UPDATE cm_ccpcchng t SET t.PROCSTATE = '";
        ChangTableState(&m_ccpcchng, 4, sSQLHead);
    }
    catch(CException &e)
    {
        m_ccpcchng.closeCursor();
        PMTS_ThrowException(UNKNOWN_ERR);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsChangeDay::changccpcchng()");
}
/*********************************************/

/*********************************************/
void CHvpsChangeDay::InsertCity(const CCmcitychng* citychng)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::InsertCity()");

    SETCTX(m_city);

    m_city.m_citycode = citychng->m_citycode; 
    m_city.m_cityname = citychng->m_cityname; 
    m_city.m_nodecode = citychng->m_nodecode; 
    m_city.m_citytp = citychng->m_citytp; 

    //删除原有记录
    int iRet = m_city.remove();
	if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "删除表记录失败[%d][%s]",
		    iRet, m_city.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_DEL_FAIL, "删除表记录失败");
	}

    //如果变更类型是新增/变更，则新增记录
    if ( "CC00" == citychng->m_chngtp || "CC01" == citychng->m_chngtp)
    {
        int iValue = m_city.insert();
        if(RTN_SUCCESS != iValue)
        {
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "插入表失败[%d][%s]", iValue, m_city.GetSqlErr());	
    		PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, "插入表失败");
        }
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsChangeDay::InsertCity()");
}

void CHvpsChangeDay::changCitychng()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::changCitychng()");

    try
    {
        string sSQLHead = "UPDATE cm_citychng t SET t.PROCSTATE = '";
        ChangTableState(&m_citychng, 5, sSQLHead);
    }
    catch(CException &e)
    {
        m_citychng.closeCursor();
        PMTS_ThrowException(UNKNOWN_ERR);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsChangeDay::changCitychng()");
}
/*********************************************/

/*********************************************/
void CHvpsChangeDay::InsertBktype(const CCmbktpchng* bktpchng)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::InsertBktype()");

    SETCTX(m_bktype);

    char szBuff[128]                 = {0};
    m_bktype.m_clscode = bktpchng->m_banktype; 
    m_bktype.m_clsname = bktpchng->m_banktypename; 
    m_bktype.m_catgno = itoa(szBuff, bktpchng->m_tpcd, 0); 
    m_bktype.m_catgname = bktpchng->m_tpnm ; 
    m_bktype.m_bankstatus = bktpchng->m_procstate; 

    //删除原有记录
    int iRet = m_bktype.remove();
	if (iRet != SQL_SUCCESS && iRet != SQLNOTFOUND)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "删除表记录失败[%d][%s]",
		    iRet, m_bktype.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_DEL_FAIL, "删除表记录失败");
	}

    //如果变更类型是新增/变更，则新增记录
    if ( "CC00" == bktpchng->m_chngtp || "CC01" == bktpchng->m_chngtp)
    {
        int iValue = 0;
        iValue = m_bktype.insert();
        if(OPERACT_SUCCESS != iRet)
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "插入表失败, iValue=%d, %s", iValue,m_bktype.GetSqlErr());
            PMTS_ThrowException(DB_INSERT_FAIL);          
        }
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::InsertBktype()");
}

void CHvpsChangeDay::changBktpchng()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::changBktpchng()");

    try
    {
        string sSQLHead = "UPDATE cm_bktpchng t SET t.PROCSTATE = '";
        ChangTableState(&m_bktpchng, 6, sSQLHead);
    }
    catch(CException &e)
    {
        m_bktpchng.closeCursor();
        PMTS_ThrowException(UNKNOWN_ERR);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsChangeDay::changBktpchng()");
}
/*********************************************/

void CHvpsChangeDay::ChangTableState(CEntityBase* BaseListObj, int iTableFlag, string sSQLHead)
{
    if(0 != BaseListObj->setctx(m_dbproc))  
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "set connect failed!");
        PMTS_ThrowException(DB_CNNCT_FAIL); 
    }
    
    int iRetCode = -1;
    string sUpdateStr = "";
    string whereStr   = "";
    
    whereStr =" FCTVDT <= '";
    whereStr += m_sCurSysDt;
    whereStr += "' AND PROCSTATE = '";
    whereStr += PR_HVBP_34;
    whereStr += "' AND SysId = '";
    whereStr += "hvps";
    whereStr += "' AND FctvTp = '";
    whereStr += "EF01";
    whereStr += "' ";
    
	Trace(L_INFO, __FILE__, __LINE__, NULL, "whereStr = [%s]", whereStr.c_str());

	iRetCode = BaseListObj->find(whereStr);
	if (SQL_SUCCESS != iRetCode) 
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
		        "查询表失败[%d][%s]", iRetCode, BaseListObj->GetSqlErr());
		
		BaseListObj->closeCursor();
		PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, "查询表失败");
	}
	
	while ( SQL_SUCCESS == iRetCode ) 
	{
	    iRetCode = BaseListObj->fetch();
	    if( SQLNOTFOUND == iRetCode )
        {
            break;
        }
	    else if(SQL_SUCCESS != iRetCode)
	    {
	        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
		        "fetch表失败[%d][%s]", iRetCode, BaseListObj->GetSqlErr());
		    
    		BaseListObj->closeCursor();
    		PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, "fetch查询表失败");
	    }
	    
        switch(iTableFlag)
        {
            case 1:
            {
                InsertMsgType(&m_cmlist);
                break;
            }
            case 2:
            {
                InsertSysparm(&m_Cmsyspamntfctnlist);
                break;
            }
            case 3:
            {
                Insertbankinfo(&m_Cmbkcdchgntfctnlist);
                break;
            }
            case 4:
            {
                Insertccpc(&m_ccpcchng);
                break;
            }
            case 5:
            {
                InsertCity(&m_citychng);
                break;
            }
            case 6:
            {
                InsertBktype(&m_bktpchng);
                break;
            }
        }    
	}
	
	BaseListObj->closeCursor();

	sUpdateStr += sSQLHead;
	sUpdateStr += PR_HVBP_35;
	sUpdateStr += "' where ";
	sUpdateStr += whereStr;
	
	Trace(L_INFO, __FILE__, __LINE__, NULL, "sUpdateStr = [%s]", sUpdateStr.c_str());
	
	iRetCode = BaseListObj->execsql(sUpdateStr);
	if (iRetCode != SQLNOTFOUND && iRetCode != SQL_SUCCESS)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
		        "更新失败[%d][%s]", iRetCode, BaseListObj->GetSqlErr());
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "更新状态失败");
	}
}

void CHvpsChangeDay::resetSerialNo()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::resetSerialNo()");
    
	string strSQL = "";
	SETCTX(m_Hvbkchkst);
	
	strSQL = "update HV_SERIALNO set SNVALUE = MINVALUE where RESETFLG = '1' and SENDBANKCODE='";
	strSQL += m_sBankNo;
	strSQL += "'";
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL = [%s]", strSQL.c_str());
	
    int iRet = m_Hvbkchkst.execsql(strSQL);
    if (SQL_SUCCESS != iRet )
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新BP_SERIALNO表失败[%d][%s]",
            iRet, m_Hvbkchkst.GetSqlErr());

        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "更新BP_SERIALNO表失败");
    }
    
	strSQL = "update SYS_SERIALNO set SNVALUE = MINVALUE where RESETFLG = '1' and SENDBANKCODE='";
	strSQL += m_sBankNo;
	strSQL += "'";
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL = [%s]", strSQL.c_str());
	
    iRet = m_Hvbkchkst.execsql(strSQL);
    if (SQL_SUCCESS != iRet )
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "更新BP_SERIALNO表失败[%d][%s]",
            iRet, m_Hvbkchkst.GetSqlErr());

        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "更新BP_SERIALNO表失败");
    }
        
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsChangeDay::resetSerialNo()");
}

void CHvpsChangeDay::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::UpdateState()");
    
    SETCTX(m_Hvbkchkst);
    SETCTX(m_Hvsapwtchgedt);

    string strSQL;
	strSQL += "UPDATE hv_bkchkst t SET ";
	strSQL += " t.checkstate = '";
    strSQL += "02";
    strSQL += "' ";
    
	strSQL += " WHERE t.sapbank = '";
	strSQL += m_sBankNo;								
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    int iRet = m_Hvbkchkst.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "修改发送状态失败iRet=%d, %s", iRet, m_Hvbkchkst.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    strSQL = "";
	strSQL += "UPDATE hv_sapwtchgedt t SET ";
	strSQL += " t.changestate = '";
    strSQL += "1";
    strSQL += "' ";
    
	strSQL += " WHERE t.sapbank = '";
	strSQL += m_sBankNo;								
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    iRet = m_Hvsapwtchgedt.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "修改发送状态失败iRet=%d, %s", iRet, m_Hvsapwtchgedt.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsChangeDay::UpdateState()");
}

void CHvpsChangeDay::MoveData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::MoveData()");
    CEntityBase entitybase;
    char szErrMsg[1024] = {0};
    
    /*取大额历史数据保留天数*/
    char szHvSaveDay[255 + 1] = {0};
    GetSysParam(m_dbproc, "11", szHvSaveDay);
    
    string strSql1="";
    string strSql2="";
    string strSql3="";
    
    /*贷记往帐明细表和历史表*/
    /* 迁移历史数据 */
    strSql1 = (string)"insert into hv_sndexchglisthis"
					"( WORKDATE ,CONSIGNDATE ,MSGTP ,MESGID ,MESGREFID ,MSGID ,"
					"ENDTOENDID ,MSGDIRECT ,INSTGDRCTPTY ,INSTGINDRCTPTY,INSTDDRCTPTY ,INSTDINDRCTPTY,STTLMPRTY ,DBTMMBID ,DBTNM ,DBTRACCTID ,DBTADDR ,DBTID ,DBTRISSR ,"
					"DBTRLSSRNM ,CDTMMBID ,CDTRNM ,CDTID ,CDTRACCTID ,CDTADDR ,CDTRISSR ,CDTRLSSRNM ,CURRENCY ,AMOUNT ,CTGYPURPPRTRY ,PURPPRTRY ,PROCSTATE ,STATETIME ,"
					"FINALSTATEDATE, BUSISTATE ,PROCESSCODE ,RJCTINF ,ACCTSTATE ,ACSTATETIME ,ACCTREGNUM ,REACREGNUM ,CHECKSTATE ,MBCHECKSTATE ,USTRDSTR ,RMK ,MBMSG ,"
					"NPCMSG ,RESERVE , ISTSTATETIME ,INPUTTIME ,CHECKTIME ,GRANTTIME ,INPUTOPER ,CHECKOPER ,GRANTOPER ,PRINTNO ,ISRBFLG ,MBMSGID ,MBINSTPTY ,MBPROCSTATE ,"
					"MBAMOUNT ,ISWAIT ,WAITSTART ,WAITEND ,CLRMBID1 ,CLRMBID1NAME ,CLRMBID2 ,CLRMBID2NAME ,REMARK ,ADDINFO ,ADDINFO2 ,TRANSFLAG ,TRANSTIMES ,OUTSENDBANK ,"
					"OUTTXSSNO ,OUTCONSIGNDATE,INSENDBANK ,INTTXSSNO ,INCONSIGNDATE ,DBTNMALL ,DBTADDRALL ,CDTRNMALL ,CDTADDRALL ,ADDINFOALL ,BATCHNO ,BCMTNO ) "
			    "select" 
					" WORKDATE ,CONSIGNDATE ,MSGTP ,MESGID ,MESGREFID ,MSGID ,"
					"ENDTOENDID ,MSGDIRECT ,INSTGDRCTPTY ,INSTGINDRCTPTY,INSTDDRCTPTY ,INSTDINDRCTPTY,STTLMPRTY ,DBTMMBID ,DBTNM ,DBTRACCTID ,DBTADDR ,DBTID ,DBTRISSR ,"
					"DBTRLSSRNM ,CDTMMBID ,CDTRNM ,CDTID ,CDTRACCTID ,CDTADDR ,CDTRISSR ,CDTRLSSRNM ,CURRENCY ,AMOUNT ,CTGYPURPPRTRY ,PURPPRTRY ,PROCSTATE ,STATETIME ,"
					"FINALSTATEDATE, BUSISTATE ,PROCESSCODE ,RJCTINF ,ACCTSTATE ,ACSTATETIME ,ACCTREGNUM ,REACREGNUM ,CHECKSTATE ,MBCHECKSTATE ,USTRDSTR ,RMK ,MBMSG ,"
					"NPCMSG ,RESERVE , ISTSTATETIME ,INPUTTIME ,CHECKTIME ,GRANTTIME ,INPUTOPER ,CHECKOPER ,GRANTOPER ,PRINTNO ,ISRBFLG ,MBMSGID ,MBINSTPTY ,MBPROCSTATE ,"
					"MBAMOUNT ,ISWAIT ,WAITSTART ,WAITEND ,CLRMBID1 ,CLRMBID1NAME ,CLRMBID2 ,CLRMBID2NAME ,REMARK ,ADDINFO ,ADDINFO2 ,TRANSFLAG ,TRANSTIMES ,OUTSENDBANK ,"
					"OUTTXSSNO ,OUTCONSIGNDATE,INSENDBANK ,INTTXSSNO ,INCONSIGNDATE ,DBTNMALL ,DBTADDRALL ,CDTRNMALL ,CDTADDRALL ,ADDINFOALL ,BATCHNO ,BCMTNO  "
	            "from hv_sndexchglist t where to_date(t.CONSIGNDATE, 'yyyymmdd') < (to_date('" + m_sCurSysDt + "', 'yyyymmdd') - to_number('" + szHvSaveDay + "')) and t.instgdrctpty = '" + m_sBankNo + "'";
	
    strSql2 = (string)"delete from hv_sndexchglist where to_date(CONSIGNDATE, 'yyyymmdd') < (to_date('" + m_sCurSysDt + "', 'yyyymmdd') - to_number('" + szHvSaveDay + "'))  and instgdrctpty = '" + m_sBankNo + "'";

    /* 清除往帐历史表 */
    strSql3 = (string)"delete from hv_sndexchglisthis where to_date(CONSIGNDATE, 'yyyymmdd') < (to_date('" + m_sCurSysDt + "', 'yyyymmdd') - to_number('" + szHvSaveDay + "')) and instgdrctpty = '" + m_sBankNo + "'";
    
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql1=[%s]", strSql1.c_str());

    SETCTX(entitybase);
    int iRet = entitybase.execsql(strSql1);
    if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"迁移历史数据时未找到数据[%s]", 
			strSql1.c_str());
	}
	else if(iRet != SQL_SUCCESS)
	{
	    Trace(L_INFO, __FILE__, __LINE__, NULL,"strSql1 = [%s]", 
			strSql1.c_str());
		sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
			iRet, entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
		//PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
	}
	
    SETCTX(entitybase);
	iRet = entitybase.execsql(strSql2);
    if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"迁移历史数据时未找到数据[%s]", 
			strSql2.c_str());
	}
	else if(iRet != SQL_SUCCESS)
	{
	    Trace(L_INFO, __FILE__, __LINE__, NULL,"strSql2 = [%s]", 
			strSql2.c_str());
		sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
			iRet, entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
		//PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
	}
	
	#if 0
	iRet = entitybase.execsql(strSql3);
    if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"清除往帐历史表未找到数据[%s]", 
			strSql3.c_str());
	}
	else if(iRet != SQL_SUCCESS)
	{
	    Trace(L_INFO, __FILE__, __LINE__, NULL,"strSql2 = [%s]", 
			strSql3.c_str());
		sprintf(szErrMsg,  "清除往帐历史表更新失败[%d][%s]", 
			iRet, entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
	}
	#endif
	
	/*贷记来帐明细表和历史表*/
	/* 迁移历史数据 */
    strSql1 = (string)"insert into hv_rcvexchglisthis "
		"( WORKDATE ,CONSIGNDATE ,MSGTP ,MESGID ,MESGREFID ,MSGID ,ENDTOENDID ,INSTGDRCTPTY ,INSTGINDRCTPTY,INSTDDRCTPTY ,INSTDINDRCTPTY,"
		" STTLMPRTY ,DBTRMMBID ,DBTNM ,DBTRACCTID ,DBTID ,DBTRISSR ,DBTRLSSRNM ,CDTRMMBID ,CDTRNM ,CDTRACCTID ,CDTID ,CDTRISSR ,CDTRLSSRNM ,"
		" PROCSTATE ,AMOUNT ,CURRENCY ,CTGYPURPPRTRY ,FINALSTATEDATE,PURPPRTRY ,BUSISTATE ,PROCESSCODE ,RJCTINF ,ACCTSTATE ,STATETIME ,ACSTATETIME ,"
		" ACCTREGNUM ,CHECKSTATE ,MBCHECKSTATE ,MBPROCSTATE ,MBAMOUNT ,USTRDSTR ,RMK ,RESERVE ,NPCMSG ,MBMSG ,PRINTNO ,ISTSTATETIME ,ISRBFLG ,"
		" RECVDEST ,DBTADDR ,CDTADDR ,SRCFLAG ,CLRMBID1 ,CLRMBID1NAME ,CLRMBID2 ,CLRMBID2NAME ,REMARK ,ADDINFO ,ADDINFO2 ,MBMSGID ,MBRECVBK )"
		"select "
		" WORKDATE ,CONSIGNDATE ,MSGTP ,MESGID ,MESGREFID ,MSGID ,ENDTOENDID ,INSTGDRCTPTY ,INSTGINDRCTPTY,INSTDDRCTPTY ,INSTDINDRCTPTY,"
		" STTLMPRTY ,DBTRMMBID ,DBTNM ,DBTRACCTID ,DBTID ,DBTRISSR ,DBTRLSSRNM ,CDTRMMBID ,CDTRNM ,CDTRACCTID ,CDTID ,CDTRISSR ,CDTRLSSRNM ,"
		" PROCSTATE ,AMOUNT ,CURRENCY ,CTGYPURPPRTRY ,FINALSTATEDATE,PURPPRTRY ,BUSISTATE ,PROCESSCODE ,RJCTINF ,ACCTSTATE ,STATETIME ,ACSTATETIME ,"
		" ACCTREGNUM ,CHECKSTATE ,MBCHECKSTATE ,MBPROCSTATE ,MBAMOUNT ,USTRDSTR ,RMK ,RESERVE ,NPCMSG ,MBMSG ,PRINTNO ,ISTSTATETIME ,ISRBFLG ,"
		" RECVDEST ,DBTADDR ,CDTADDR ,SRCFLAG ,CLRMBID1 ,CLRMBID1NAME ,CLRMBID2 ,CLRMBID2NAME ,REMARK ,ADDINFO ,ADDINFO2 ,MBMSGID ,MBRECVBK "
	"from hv_rcvexchglist t where to_date(t.CONSIGNDATE, 'yyyymmdd') < (to_date('" + m_sCurSysDt + "', 'yyyymmdd') - to_number('" +szHvSaveDay + "')) and t.instddrctpty = '" + m_sBankNo + "'";
    strSql2 = (string)"delete from hv_rcvexchglist where to_date(CONSIGNDATE, 'yyyymmdd') < (to_date('" + m_sCurSysDt + "', 'yyyymmdd') - to_number('" + szHvSaveDay + "'))  and instddrctpty = '" + m_sBankNo + "'";

    /* 清除历史表 */
    strSql3 = (string)"delete from hv_rcvexchglisthis where to_date(CONSIGNDATE, 'yyyymmdd') < (to_date('" + m_sCurSysDt + "', 'yyyymmdd') - to_number('" + szHvSaveDay + "')) and instddrctpty = '" + m_sBankNo + "'";
    
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql1=[%s]", strSql1.c_str());

    iRet = entitybase.execsql(strSql1);
    if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"迁移历史数据时未找到数据[%s]", 
			strSql1.c_str());
	}
	else if(iRet != SQL_SUCCESS)
	{
	    Trace(L_INFO, __FILE__, __LINE__, NULL,"strSql1 = [%s]", 
			strSql1.c_str());
		sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
			iRet, entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
		//PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
	}
	
	iRet = entitybase.execsql(strSql2);
    if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"迁移历史数据时未找到数据[%s]", 
			strSql2.c_str());
	}
	else if(iRet != SQL_SUCCESS)
	{
	    Trace(L_INFO, __FILE__, __LINE__, NULL,"strSql2 = [%s]", 
			strSql2.c_str());
		sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
			iRet, entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
		//PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
	}
	
	#if 0
	iRet = entitybase.execsql(strSql3);
    if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"清除往帐历史表未找到数据[%s]", 
			strSql3.c_str());
	}
	else if(iRet != SQL_SUCCESS)
	{
	    Trace(L_INFO, __FILE__, __LINE__, NULL,"strSql2 = [%s]", 
			strSql3.c_str());
		sprintf(szErrMsg,  "清除往帐历史表更新失败[%d][%s]", 
			iRet, entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
	}
	#endif
	
	/*即时转帐来帐表和历史表*/
	/* 迁移历史数据 */
    strSql1 = (string)"insert into hv_trofacrcvlisthis"
     "( WORKDATE ,CONSIGNDATE ,MSGTP ,MESGID ,MESGREFID ,MSGID ,CDCODE ,INSTGDRCTPTY ,INSTGINDRCTPTY ,INSTDDRCTPTY ,INSTDINDRCTPTY ,SPJOINMMBID ,RMK ,ENDTOENDID , STTLMPRTY ,"
	 "DBTMMBID ,DBTNM ,DBTRACCTID ,DBTID ,DBTRISSR ,DBTRLSSRNM ,CDTMMBID ,CDTRNM ,CDTID ,CDTRACCTID ,CDTRISSR ,CDTRLSSRNM ,TRANMUNUM ,CURRENCY ,AMOUNT ,CTGYPURPPRTRY ,PURPPRTRY ,"
	 "PROCSTATE ,STATETIME ,FINALSTATEDATE ,BUSISTATE ,PROCESSCODE ,RJCTINF ,ACCTSTATE ,ACSTATETIME ,ACCTREGNUM , DUPACREGNUM ,CHECKSTATE ,MBCHECKSTATE ,MBPROCSTATE ,MBAMOUNT ,"
	 "MBMSGID ,USTRDSTR ,MBMSG ,NPCMSG ,RESERVE ,ISTSTATETIME ,INPUTTIME ,CHECKTIME ,GRANTTIME ,INPUTOPER ,CHECKOPER ,GRANTOPER ,PRINTNO ,DBTADDR ,CDTADDR ,ISRBFLG ,RECVDEST ,SRCFLAG ,REMARK ,NTCETP ,ORGNLMSGID )"
     " select "
	"WORKDATE ,CONSIGNDATE ,MSGTP ,MESGID ,MESGREFID ,MSGID ,CDCODE ,INSTGDRCTPTY ,INSTGINDRCTPTY ,INSTDDRCTPTY ,INSTDINDRCTPTY ,SPJOINMMBID ,RMK ,ENDTOENDID , STTLMPRTY ,"
	"DBTMMBID ,DBTNM ,DBTRACCTID ,DBTID ,DBTRISSR ,DBTRLSSRNM ,CDTMMBID ,CDTRNM ,CDTID ,CDTRACCTID ,CDTRISSR ,CDTRLSSRNM ,TRANMUNUM ,CURRENCY ,AMOUNT ,CTGYPURPPRTRY ,PURPPRTRY ,"
	"PROCSTATE ,STATETIME ,FINALSTATEDATE ,BUSISTATE ,PROCESSCODE ,RJCTINF ,ACCTSTATE ,ACSTATETIME ,ACCTREGNUM , DUPACREGNUM ,CHECKSTATE ,MBCHECKSTATE ,MBPROCSTATE ,MBAMOUNT ,"
	"MBMSGID ,USTRDSTR ,MBMSG ,NPCMSG ,RESERVE ,ISTSTATETIME ,INPUTTIME ,CHECKTIME ,GRANTTIME ,INPUTOPER ,CHECKOPER ,GRANTOPER ,PRINTNO ,DBTADDR ,CDTADDR ,ISRBFLG ,RECVDEST ,SRCFLAG ,REMARK ,NTCETP ,ORGNLMSGID "      
     " from hv_trofacrcvlist t where to_date(t.CONSIGNDATE, 'yyyymmdd') < (to_date('" + m_sCurSysDt + "', 'yyyymmdd') - to_number('" +szHvSaveDay + "')) and t.instddrctpty = '" + m_sBankNo + "'";
    strSql2 = (string)"delete from hv_trofacrcvlist where to_date(CONSIGNDATE, 'yyyymmdd') < (to_date('" + m_sCurSysDt + "', 'yyyymmdd') - to_number('" +szHvSaveDay + "'))  and instddrctpty = '" + m_sBankNo + "'";

    /* 清除历史表 */
    strSql3 = (string)"delete from hv_trofacrcvlisthis where to_date(CONSIGNDATE, 'yyyymmdd') < (to_date('" + m_sCurSysDt + "', 'yyyymmdd') - to_number('" + szHvSaveDay + "')) and instddrctpty = '" + m_sBankNo + "'";
    
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strSql1=[%s]", strSql1.c_str());

    iRet = entitybase.execsql(strSql1);
    if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"迁移历史数据时未找到数据[%s]", 
			strSql1.c_str());
	}
	else if(iRet != SQL_SUCCESS)
	{
	    Trace(L_INFO, __FILE__, __LINE__, NULL,"strSql1 = [%s]", 
			strSql1.c_str());
		sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
			iRet, entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
		//PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
	}
	
	iRet = entitybase.execsql(strSql2);
    if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"迁移历史数据时未找到数据[%s]", 
			strSql2.c_str());
	}
	else if(iRet != SQL_SUCCESS)
	{
	    Trace(L_INFO, __FILE__, __LINE__, NULL,"strSql2 = [%s]", 
			strSql2.c_str());
		sprintf(szErrMsg,  "迁移历史数据更新失败[%d][%s]", 
			iRet, entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
		//PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
	}
	

	#if 0	
	/* 查询查复表 */
    /* 清除历史 */
    strSql3 = (string)"delete from cm_transinfoqry where to_date(CONSIGNDATE, 'yyyymmdd') < (to_date('" + m_sCurSysDt + "', 'yyyymmdd') - to_number('" + szHvSaveDay + "')) and ((instddrctpty = '" + m_sBankNo + "' and rsflag = '2') or (instgdrctpty = '" + m_sBankNo + "' and rsflag <> '2'))";
	iRet = entitybase.execsql(strSql3);
    if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"清除往帐历史表未找到数据[%s]", 
			strSql3.c_str());
	}
	
    /*大额对账明细表*/
    /* 清除历史 */
    strSql3 = (string)"delete from hv_chklstlist where to_date(WORKDATE, 'yyyymmdd') < (to_date('" + m_sCurSysDt + "', 'yyyymmdd') - to_number('" + szHvSaveDay + "')) and instddrctpty = '" + m_sBankNo + "'";
	iRet = entitybase.execsql(strSql3);
    if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"清除往帐历史表未找到数据[%s]", 
			strSql3.c_str());
	}
	else if(iRet != SQL_SUCCESS)
	{
	    Trace(L_INFO, __FILE__, __LINE__, NULL,"strSql2 = [%s]", 
			strSql3.c_str());
		sprintf(szErrMsg,  "清除往帐历史表更新失败[%d][%s]", 
			iRet, entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
		//PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
	}
	
	/*大额对帐汇总表*/
    /* 清除历史 */
    strSql3 = (string)"delete from hv_checkcl where to_date(WORKDATE, 'yyyymmdd') < (to_date('" + m_sCurSysDt + "', 'yyyymmdd') - to_number('" + szHvSaveDay + "')) and instddrctpty = '" + m_sBankNo + "'";
	iRet = entitybase.execsql(strSql3);
    if (iRet == SQLNOTFOUND)
	{
		Trace(L_INFO, __FILE__, __LINE__, NULL,"清除往帐历史表未找到数据[%s]", 
			strSql3.c_str());
	}
	else if(iRet != SQL_SUCCESS)
	{
	    Trace(L_INFO, __FILE__, __LINE__, NULL,"strSql2 = [%s]", 
			strSql3.c_str());
		sprintf(szErrMsg,  "清除往帐历史表更新失败[%d][%s]", 
			iRet, entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, szErrMsg);
	}
	#endif
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsChangeDay::MoveData()");
}


