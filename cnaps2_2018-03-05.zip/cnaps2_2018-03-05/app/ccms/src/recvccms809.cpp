/******************************************************************** 
�ļ����� recvccms809.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-03-05
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvccms809.h"


CRecvCcms809::CRecvCcms809()
{
    m_Flag = 0;
	
}


CRecvCcms809::~CRecvCcms809()
{
	
}

INT32 CRecvCcms809::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms809::Work()");

	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "sMsg = [%s]", sMsg);	

	//1����������
	unPack(sMsg);

    SetData(sMsg);
    
	//2���޸�ԭ��ѯҵ��״̬
	if(1 == m_Flag)
	{
	    UpdataState();
	}
	
	string strInstdpty = m_cParser809.m_PMTSHeader.getOrigReceiver();
	Trim(strInstdpty);

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strInstdpty=[%s]", strInstdpty.c_str());
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms809::work()");

	return RTN_SUCCESS;
}



INT32 CRecvCcms809::unPack(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms809::unPack");	

	int iRet = RTN_FAIL;

	//1�������Ƿ�Ϊ��
	if (NULL == sMsg || '\0' == sMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
	}

	/*//2����ȡ���������
	if (RTN_SUCCESS != GetParserObj(sMsg))
	{
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRSMSG_FAIL, "��ȡ���������ʧ��");
	}*/

	//3����������
	iRet = m_cParser809.ParseXml(sMsg);
	if (RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= %d", iRet);	
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
	}

    ZFPTLOG.SetLogInfo("809", m_cParser809.MsgId.c_str());
	
	m_strMsgID	=	m_cParser809.MsgId;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms809::unPack");	

	return RTN_SUCCESS;
}


/*INT32 CRecvCcms809::GetParserObj(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms809::GetParserObj");

	// �ж��ǵڼ�������
	int iVer = JudgeMsgVer(sMsg);
	if (MSG_VER_2ND == iVer)
	{
		// ��������
		m_cParser809.Init(MSG_VER_2ND, 809);
	}
	else if (MSG_VER_1ST == iVer)
	{
		// һ������
		int iMsgCode = GetMsgCode(sMsg);
		if (HV_1ST_FAIL != iMsgCode)
		{
			m_cParser809.Init(MSG_VER_1ST, iMsgCode);
		}
		else
		{
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "GetMsgCode error:%d", iMsgCode);
			return RTN_FAIL;
		}
	}
	else
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "JudgeMsgVer iVer=[%d]", iVer);
		return RTN_FAIL;
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms809::GetParserObj");

	return RTN_SUCCESS;
}*/


INT32 CRecvCcms809::SetData(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms809::SetData");
    char RcvCCPCNode[30] 	= {0};
    char szSapBankCode[14]  = {0};
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "OrigReceiver = [%s]",m_cParser809.m_PMTSHeader.getOrigReceiver());
    GetSapBank(m_dbproc,  Trim(m_cParser809.m_PMTSHeader.getOrigReceiver()), szSapBankCode);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "SapBankCode = [%s]", szSapBankCode);
    
    GetSapBkToCCPC(m_dbproc, szSapBankCode, RcvCCPCNode);
    if( 0 == strcmp(m_cParser809.NdCd.c_str(), "0000"))
    {
        m_Flag = 1;
    }
    else if( 0 == strcmp(m_cParser809.NdCd.c_str(), RcvCCPCNode))
    {
        int iNum = m_cParser809.m_pXMLProc.m_PMTSSpecilDataMap.size();
        for(int i = 0; i < iNum; i++)
        {
            string strTemp = m_cParser809.GetPtyId(i);
            if(0 == strcmp(m_cParser809.InstdDrctPty.c_str(), strTemp.c_str()))
            {
                m_Flag = 1;
                break;
            }
        }
    }
    /*
    NS00��NPCͣ��  06
    NS01��NPC����  04
    NS02:CCPCͣ��  07
    NS03��CCPC���� 05

    01������
	02��ͣ��
	03��ά��
	04��NPC����
	05: CCPC����
	06��NPCͣ��
	07��CCPCͣ��
	10���ռ�
	00��Ӫҵ׼��
	20��ҵ���ֹ
	30�����㴰��
	40�����մ���
	15������
    */
    
	if(0==memcmp(m_cParser809.NewSts.c_str(),"NS00",4)) 
    {
    	szOBankStatus =  "06";
    }
    else if(0==memcmp(m_cParser809.NewSts.c_str(),"NS01",4))
    {
    	szOBankStatus= "04";
    }
	else if(0==memcmp(m_cParser809.NewSts.c_str(),"NS02",4))
    {
    	szOBankStatus= "07";
    }
    else if (0==memcmp(m_cParser809.NewSts.c_str(),"NS03",4))
    {
    	szOBankStatus= "05";
    }
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "szOBankStatus=%s", szOBankStatus.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvCcms809::SetData");
    
	return RTN_SUCCESS;
}

INT32 CRecvCcms809::InsertData()
{
	return RTN_SUCCESS;
}

INT32 CRecvCcms809::UpdataState()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms809::UpdateState");
	
	int    iRet = RTN_FAIL;
	string strSapBank = "";
	string strSQL = "";
	
	strSapBank = Trim(m_cParser809.m_PMTSHeader.getOrigReceiver());
	
	if ( "HVPS" == m_cParser809.SysCd )
	{
		CHvsapbankinfo cHvsapbankinfo;
		
		SETCTX(cHvsapbankinfo);
		
		cHvsapbankinfo.m_sapbank = strSapBank;
		
		iRet = cHvsapbankinfo.findByPK();
		if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "��ȡ����ʧ��, iRet = %d", iRet, cHvsapbankinfo.GetSqlErr());
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_NOT_FOUND);
		}
		
		if (cHvsapbankinfo.m_workdate == m_cParser809.FctvDt)
		{
			strSQL = "";
			strSQL  = "UPDATE hv_sapbankinfo t SET ";
			strSQL += "t.sysstate = '";
			strSQL += szOBankStatus.c_str();
			strSQL += "', t.FctvDt = '";
			strSQL += m_cParser809.FctvDt.c_str();
			strSQL += "', t.EstmtdStartSvc = '";
			strSQL += m_cParser809.EstmtdStartSvc.c_str();    
			strSQL += "', t.STATETIME = sysdate ";
			
			strSQL += " WHERE t.sapbank = '";
			strSQL += strSapBank.c_str();	
			strSQL += "'";
	
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
			
			int iRet = cHvsapbankinfo.execsql(strSQL.c_str());
			if(OPERACT_SUCCESS != iRet)
			{
				sprintf(m_szErrMsg, "CRecvCcms809::UpdateSate():�޸�logon������ʧ��!iRet=[%d], %s", iRet, cHvsapbankinfo.GetSqlErr() );
				
				Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
				
				PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg); 
			}
		}
		else
		{
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
				"������Ч����[%s]�뵱ǰ��������[%s]���������������ݿ⡣", m_cParser809.FctvDt.c_str(), cHvsapbankinfo.m_workdate.c_str());
		}
	}
	else if ( "BEPS" == m_cParser809.SysCd )
	{
		CBpsapbankinfo cBpsapbankinfo;
		
		SETCTX(cBpsapbankinfo);
		
		cBpsapbankinfo.m_sapbank = strSapBank;
		
		iRet = cBpsapbankinfo.findByPK();
		if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "��ȡ����ʧ��, iRet = %d", iRet, cBpsapbankinfo.GetSqlErr());
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_NOT_FOUND);
		}
		
		if (cBpsapbankinfo.m_workdate == m_cParser809.FctvDt)
		{
			strSQL = "";
			strSQL  = "UPDATE bp_sapbankinfo t SET ";
			strSQL += "t.sysstate = '";
			strSQL += szOBankStatus.c_str();
			strSQL += "', t.FctvDt = '";
			strSQL += m_cParser809.FctvDt.c_str();
			strSQL += "', t.EstmtdStartSvc = '";
			strSQL += m_cParser809.EstmtdStartSvc.c_str();    
			strSQL += "', t.STATETIME = sysdate ";
			
			strSQL += " WHERE t.sapbank = '";
			strSQL += strSapBank.c_str();	
			strSQL += "'";
	
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
			
			int iRet = cBpsapbankinfo.execsql(strSQL.c_str());
			if(OPERACT_SUCCESS != iRet)
			{
				sprintf(m_szErrMsg, "CRecvCcms809::UpdateSate():�޸�logon������ʧ��!iRet=[%d], %s", iRet, cBpsapbankinfo.GetSqlErr() );
				
				Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
				
				PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg); 
			}
		}
		else 
		{
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
				"������Ч����[%s]�뵱ǰ��������[%s]���������������ݿ⡣", m_cParser809.FctvDt.c_str(), cBpsapbankinfo.m_workdate.c_str());
		}
	}
	else
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����ʶ���ϵͳ���[%s]", m_cParser809.SysCd.c_str());
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms809::UpdateState");

	return RTN_SUCCESS;
}

