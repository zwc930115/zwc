/******************************************************************** 
�ļ����� sendcmt302.cpp
�����ˣ� hq
��  �ڣ� 2011-07-01
�޸��ˣ� 
��  �ڣ� 
��  ���� CMT302�鸴�����˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt302.h"

using namespace ZFPT;

CSendCmt302::CSendCmt302(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{

}

CSendCmt302::~CSendCmt302()
{

}

int CSendCmt302::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt302::doWork...");

    // ��ȡ����
    GetData();

    // �鱨��
    CreateNpcMsg();

    // ����״̬
    UpdateState();

    // ���ͱ���
    AddQueue(m_cmt302.m_strCmtmsg.c_str(), m_cmt302.m_strCmtmsg.length());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt302::doWork..."); 
    return RTN_SUCCESS;
}

int CSendCmt302::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt302::GetData...");

    m_ctransqry.setctx(m_dbproc);
    SetDBKey();

    int iRet = m_ctransqry.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��[%d][%s]",
                iRet, m_ctransqry.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt302::GetData...");
    return iRet;
}

void CSendCmt302::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt302::SetDBKey...");

    char szSys[4 + 1] = {0};
    strncpy(szSys, m_szSysFlagNO, sizeof(szSys) - 1);
    StrUpperCase(szSys);

    m_ctransqry.m_sysid        = szSys;
    m_ctransqry.m_msgid        = m_szMsgFlagNO; 
    m_ctransqry.m_instgindrctpty = m_szSndNO;
    m_ctransqry.m_rsflag       = m_szSrcflg;

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_ctransqry.m_sysid = [%s]", m_ctransqry.m_sysid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_ctransqry.m_msgid = [%s]", m_ctransqry.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_ctransqry.m_instgindrctpty = [%s]", m_ctransqry.m_instgindrctpty.c_str());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt302::SetDBKey...");
}

void CSendCmt302::CreateNpcMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt302::CreateNpcMsg...");
    
    char SndCCPCNode[4 + 1] = {0};	
    char RcvCCPCNode[4 + 1] = {0};
    int  iSysCd = 1;
    int  iRet   = -1;

    strncpy(m_cmt302.sReplydate,      m_ctransqry.m_wrkdate.c_str(),        sizeof(m_cmt302.sReplydate) - 1);
    strncpy(m_cmt302.sReplybank,      m_ctransqry.m_instgindrctpty.c_str(), sizeof(m_cmt302.sReplybank) - 1);
    strncpy(m_cmt302.sReplyno,        m_ctransqry.m_msgid.c_str() + 8,      sizeof(m_cmt302.sReplyno)   - 1);
    strncpy(m_cmt302.sRecvsapbk,      m_ctransqry.m_instddrctpty.c_str(),   sizeof(m_cmt302.sRecvsapbk) - 1);
    strncpy(m_cmt302.sSendsapbk,      m_ctransqry.m_instgdrctpty.c_str(),   sizeof(m_cmt302.sSendsapbk) - 1);
    strncpy(m_cmt302.sOldquerybank,   m_ctransqry.m_instdindrctpty.c_str(), sizeof(m_cmt302.sOldquerybank) - 1);
    strncpy(m_cmt302.sOldquerydate,   m_ctransqry.m_qorgnlmsgid.c_str(),     sizeof(m_cmt302.sOldquerydate) - 1);
    strncpy(m_cmt302.sOldqueryno,     m_ctransqry.m_qorgnlmsgid.c_str() + 8, sizeof(m_cmt302.sOldqueryno) - 1);

    
    if(m_ctransqry.m_sysid=="HVPS")
    {
        strncpy(m_cmt302.sOldtxssno,      m_ctransqry.m_orgnlmsgid.c_str()+8, sizeof(m_cmt302.sOldtxssno)      - 1);
        strncpy(m_cmt302.sOldconsigndate, m_ctransqry.m_orgnlmsgid.c_str(),     sizeof(m_cmt302.sOldconsigndate) - 1);
        strncpy(m_cmt302.sOldsendbank,    m_ctransqry.m_orgnlinstgdrctpty.c_str(), sizeof(m_cmt302.sOldsendbank) - 1);
        strncpy(m_cmt302.sOldrecvbank,    m_ctransqry.m_orgninstdindrctpty.c_str(), sizeof(m_cmt302.sOldrecvbank) - 1);
    }
    else
    {
        
        strncpy(m_cmt302.sOldtxssno,      m_ctransqry.m_orgnltxmsgid.c_str()+8, sizeof(m_cmt302.sOldtxssno)      - 1);
        strncpy(m_cmt302.sOldconsigndate, m_ctransqry.m_orgnltxmsgid.c_str(),     sizeof(m_cmt302.sOldconsigndate) - 1);
        strncpy(m_cmt302.sOldsendbank,    m_ctransqry.m_orgninstgindrctpty.c_str(), sizeof(m_cmt302.sOldsendbank) - 1);
        strncpy(m_cmt302.sOldrecvbank,    m_ctransqry.m_orgninstdindrctpty.c_str(), sizeof(m_cmt302.sOldrecvbank) - 1);
    }
    
    //strncpy(m_cmt302.sOldtradetype,   m_ctransqry.m_orgnlmsgtp.c_str(),   sizeof(m_cmt302.sOldtradetype)   - 1);m_oripmttpprtry 
   strncpy(m_cmt302.sOldtradetype,   m_ctransqry.m_oripmttpprtry.c_str(),   sizeof(m_cmt302.sOldtradetype)   - 1); 
   Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cmt302.sOldtradetype=[%s]", m_cmt302.sOldtradetype);
    strncpy(m_cmt302.sOldcur,         m_ctransqry.m_qryccy.c_str(),         sizeof(m_cmt302.sOldcur) - 1);
    m_cmt302.dOldamount = m_ctransqry.m_qryamt;
    strncpy(m_cmt302.sRemark,         m_ctransqry.m_msgcnt.c_str(),         sizeof(m_cmt302.sRemark)-1);

    GetSapBkToCCPC(m_dbproc, m_cmt302.sSendsapbk, SndCCPCNode);
    GetSapBkToCCPC(m_dbproc, m_cmt302.sRecvsapbk, RcvCCPCNode);
    strncpy(m_cmt302.sSendcenter,     SndCCPCNode,                          sizeof(m_cmt302.sSendcenter) - 1);
    strncpy(m_cmt302.sRecvcenter,     RcvCCPCNode,                          sizeof(m_cmt302.sRecvcenter) - 1);
                         
    chgSysCd(m_ctransqry.m_sysid.c_str(), iSysCd);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iSysCd[%d]", iSysCd);
    iRet = m_cmt302.CreateCmt("302",
                           	  m_ctransqry.m_instgdrctpty.c_str(),
                           	  m_ctransqry.m_instddrctpty.c_str(),
                           	  m_sMesgId.c_str(),
                           	  m_sMesgId.c_str(), 
                           	  m_ctransqry.m_wrkdate.c_str(),
                           	  "0",
                           	  iSysCd);
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�鱨��ʧ��,iRet[%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt302::CreateNpcMsg...");
}

int CSendCmt302::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt302::UpdateState...");

    string strNpcMsg = "";
	int nSysID = m_ctransqry.m_sysid == "BEPS" ? SYS_BEPS : SYS_HVPS;
	if(!m_ctransqry.write_blob(m_cmt302.m_strCmtmsg.c_str(), strNpcMsg, nSysID)){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"д���ֶα�����:[%s]", m_ctransqry.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}

    string strSQL;
    //���ｫί��������Ϊ��̬����д�����ݿ� �������
    char szIOSdate[10 + 1] = {0};
    chgToISODate(m_ctransqry.m_consigndate.c_str(), szIOSdate);

    strSQL += "UPDATE cm_transinfoqry t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_08;
    strSQL += "', t.npcmsg='";
    strSQL += strNpcMsg;
    strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
    strSQL += "', t.MESGREFID = '";
    strSQL += m_sMesgId;
    strSQL += "', t.FINALSTATEDATE = '";
    strSQL += szIOSdate;
    strSQL += "', t.STATETIME = sysdate ";

    strSQL += " WHERE t.MSGTP = '";
    strSQL += m_ctransqry.m_msgtp.c_str();
    strSQL += "' AND t.MSGID = '";
    strSQL += m_ctransqry.m_msgid.c_str();
    strSQL += "' AND t.INSTGINDRCTPTY = '";
    strSQL += m_ctransqry.m_instgindrctpty.c_str(); 									
    strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL[%s]", strSQL.c_str());

    int iRet = m_ctransqry.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��[%d][%s]",
            iRet, m_ctransqry.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }
    /*
    strSQL = "UPDATE cm_transinfoqry t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_31;
    strSQL += "', t.STATETIME = sysdate ";
    strSQL += " WHERE t.MSGTP = 'CMT301' and t.RSFLAG='2' AND  t.MSGID='";
    strSQL += m_ctransqry.m_qorgnlmsgid.c_str();
    strSQL += "' AND t.INSTGINDRCTPTY = '";
    strSQL += m_ctransqry.m_qorgnlinstgdrctpty.c_str(); 									
    strSQL += "'";

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL[%s]", strSQL.c_str());

    iRet = m_ctransqry.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸�����״̬ʧ��[%d][%s]",
            iRet, m_ctransqry.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }
    */
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt302::UpdateState...");
    return RTN_SUCCESS;
}


