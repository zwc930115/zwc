/********************************************************************
�ļ�����send991.cpp
�����ˣ�handongfeng
��  �ڣ�2011.01.14
��  ����
��  ����
Copyright (c) 2009  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendccms991.h"

CSendCcms991::CSendCcms991(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{
}

CSendCcms991::~CSendCcms991()
{
}

void CSendCcms991::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms991::SetDBKey...");
    
    char row_id[8+1]={0};
    char workdate[8+1]={0};
    
    memcpy(workdate,m_szMsgFlagNO,8);
    memcpy(row_id,m_szMsgFlagNO+8,8);
    
      m_Cmchckreqrspn.m_row_id = atoi(row_id);
	  m_Cmchckreqrspn.m_workdate = workdate; 
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Cmchckreqrspn.m_workdate = %s", m_Cmchckreqrspn.m_workdate.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Cmchckreqrspn.m_row_id = %d", m_Cmchckreqrspn.m_row_id);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms991::SetDBKey...");
    return;
}

void CSendCcms991::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms991::SetData...");
    
	char szSyscd[4+1] = {0};

    int iSysflg = -1;
    int iRet = -1;
    chgSysCd(m_szSysFlagNO,iSysflg);
    
    iRet = GetIsoDateTime(m_dbproc, iSysflg, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }


    m_ccms991.SndNd                              = m_Cmchckreqrspn.m_sndnd;//���ķ���ڵ�
    m_ccms991.SndSvcrNm                          = m_Cmchckreqrspn.m_sndsvcrnm;// ���ͷ�������
    m_ccms991.SndLineMgrNm                       = m_Cmchckreqrspn.m_sndlinemgrnm;//������й�������
    m_ccms991.SndRoadNm                          = m_Cmchckreqrspn.m_sndroadnm;//����ͨ����
    
    string timeTmp = m_Cmchckreqrspn.m_workdate.substr(0,2)+m_Cmchckreqrspn.m_snddt.substr(0,2)+"-"+
                     m_Cmchckreqrspn.m_snddt.substr(2,2)+"-"+m_Cmchckreqrspn.m_snddt.substr(4,2)+" "+
                     m_Cmchckreqrspn.m_snddt.substr(6,2)+":"+m_Cmchckreqrspn.m_snddt.substr(8,2)+":"+
                     m_Cmchckreqrspn.m_snddt.substr(10,2);
    m_Cmchckreqrspn.m_snddt = timeTmp;
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Cmchckreqrspn.m_snddt = %s", m_Cmchckreqrspn.m_snddt.c_str());
    time_t time = stingToTime(m_Cmchckreqrspn.m_snddt.c_str());
    char tmp[1024]={0};
    sprintf(tmp,"%d",time);
    m_ccms991.SndDt                              = tmp;//����ʱ��
    m_ccms991.RcvNd                              = m_Cmchckreqrspn.m_rcvnd;//���սڵ�
    m_ccms991.RcvSvcrNm                          = m_Cmchckreqrspn.m_rcvsvcrnm;//���շ�������
    m_ccms991.RcvLineMgr                         = m_Cmchckreqrspn.m_rcvlinemgr;// ���ն��й�����
    m_ccms991.RspnLineNm                         = m_Cmchckreqrspn.m_rspnlinenm;//MBFE��̽���Ӧ���ķ���Ķ�����
    m_ccms991.SndSvcrRcvSts                      = m_Cmchckreqrspn.m_sndsvcrrcvsts;//���𷽷���������״̬
    //m_ccms991.SndNdMgmtSts                       = "1";
    //m_ccms991.RcvNdMgmtSts                       = "1";
        
    // ���ļ�ͷ
    m_ccms991.CreateXMlHeader("CCMS",                        \
                                m_Cmchckreqrspn.m_workdate.c_str(), \
                                m_Cmchckreqrspn.m_instgindrctpty.c_str(),\
                                m_Cmchckreqrspn.m_instgindrctpty.c_str(),\
                                "ccms.991.001.01",              \
                                m_sMesgId.c_str()); 
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms991::SetData...");
    return;
}

int CSendCcms991::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms991::GetData...");
    
    SETCTX(m_Cmchckreqrspn);
    SetDBKey();
    int iRet = m_Cmchckreqrspn.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��,iRet=%d, %s", iRet, m_Cmchckreqrspn.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms991::GetData...");
    return iRet;
}

int CSendCcms991::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms991::UpdateState...");
 
    char tmpRow_id[1024]={0};
    sprintf(tmpRow_id,"%d",m_Cmchckreqrspn.m_row_id);
    
    string strSQL;
	strSQL += "UPDATE cm_chckreqrspn t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_08;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
    
	strSQL += "' WHERE t.row_id = ";
	strSQL += tmpRow_id;
    strSQL += " AND t.workdate = '";
	strSQL += m_Cmchckreqrspn.m_workdate.c_str();									
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    int iRet = m_Cmchckreqrspn.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��,iRet=%d, %s", iRet, m_Cmchckreqrspn.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms991::UpdateState...");
    return iRet;
}

int CSendCcms991::doWorkSelf()
{
   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms991::doWork...");

	//��ȡҵ��Ҫ��
    int iRet = 0;

    GetData();
    
    SetData();

    iRet = m_ccms991.CreateXml();
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��991����ʧ��,iRet[%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }

    AddQueue(m_ccms991.m_sXMLBuff.c_str(), m_ccms991.m_sXMLBuff.length());
    
    UpdateState();
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms991::doWork..."); 
    return RTN_SUCCESS;
}

time_t CSendCcms991::stingToTime(const char * szTime) 
{
    struct tm tm1; 
    time_t time1; 
    sscanf(szTime, "%4d-%2d-%2d %2d:%2d:%2d",    
                      &tm1.tm_year, 
                      &tm1.tm_mon, 
                      &tm1.tm_mday, 
                      &tm1.tm_hour, 
                      &tm1.tm_min, 
                      &tm1.tm_sec);    
                                
    tm1.tm_year -= 1900; 
    tm1.tm_mon --; 
    tm1.tm_isdst=-1;  
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "tm1.tm_year = %d", tm1.tm_year);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "tm1.tm_mon = %d", tm1.tm_mon);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "tm1.tm_mday = %d", tm1.tm_mday);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "tm1.tm_hour = %d", tm1.tm_hour);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "tm1.tm_min = %d", tm1.tm_min);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "tm1.tm_sec = %d", tm1.tm_sec);
    time1 = mktime(&tm1); 
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "time1 = %d", time1);
    return time1; 
 } 



