/********************************************************************
�ļ�����send307.cpp
�����ˣ�hq
��  �ڣ�2011.01.14
��  ����
��  ����
Copyright (c) 2009  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif


#include "sendccms307.h"

CSendCcms307::CSendCcms307(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{

}

CSendCcms307::~CSendCcms307()
{

}

int CSendCcms307::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms307::doWork...");

    int iRet = RTN_FAIL;

    // ��ȡ����
    GetData();

    // ���ĸ�ֵ
    SetData();

    // ��ǩ
    AddSign307();

    // �鱨��
    iRet = m_ccms307.CreateXml();
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CreateMsg error,iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }

    // ��������״̬
    UpdateState();

    // ���ͱ���
    AddQueue(m_ccms307.m_sXMLBuff.c_str(), m_ccms307.m_sXMLBuff.length());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms307::doWork..."); 
    return RTN_SUCCESS;
}

void CSendCcms307::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms307::SetDBKey...");

    m_CmTrRepeal.m_sysid = m_szSysFlagNO; 
    m_CmTrRepeal.m_msgid = m_szMsgFlagNO; 
    m_CmTrRepeal.m_instgindrctpty = m_szSndNO; 

    //Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSysFlagNO = %s", m_szSysFlagNO);
    //Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgFlagNO = %s", m_szMsgFlagNO);
    //Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndNO = %s", m_szSndNO);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms307::SetDBKey...");
    return;
}

int CSendCcms307::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms307::GetData...");

    //��������
    if (0 != m_CmTrRepeal.setctx(m_dbproc))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
        return DB_GET_DATA_FAIL;
    }

    //������ֵ
    SetDBKey();

    //��ѯ����
    int iRet = m_CmTrRepeal.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��");
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms307::GetData...");
    return iRet;
}

void CSendCcms307::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms307::SetData...");

    int iSysflg = -1;
    int iRet = -1;
    chgSysCd(m_szSysFlagNO,iSysflg); 
    iRet = GetIsoDateTime(m_dbproc, iSysflg, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }
    
    //������
    m_ccms307.Id              = m_CmTrRepeal.m_msgid;        //���ı�ʶ��
    m_ccms307.AssgnrMmbId     = m_CmTrRepeal.m_instgindrctpty; //�����������к�
    m_ccms307.AssgneMmbId     = m_CmTrRepeal.m_instdindrctpty; //���ղ�������к� 
    m_ccms307.CreDtTm         = m_ISODateTime;               //���ķ���ʱ��
    m_ccms307.OrgnlMsgId      = m_CmTrRepeal.m_orgnlmsgid;   //ԭ���ı�ʶ��
    m_ccms307.OrgnlMsgNmId    = m_CmTrRepeal.m_orgnlmsgtp;   //ԭ�������ʹ���
    m_ccms307.AddtlInf        = m_CmTrRepeal.m_rmkinf;       //��ע
    char szSyscd[4+1] = {0};
    strcpy(szSyscd,m_szSysFlagNO);
    StrUpperCase_ZFPT(szSyscd);
  
    // ���ļ�ͷ
    m_ccms307.CreateXMlHeader(szSyscd,                        \
                                m_CmTrRepeal.m_wrkdate.c_str(), \
                                m_CmTrRepeal.m_instgdrctpty.c_str(),\
                                m_CmTrRepeal.m_instddrctpty.c_str(),\
                                "ccms.307.001.02",              \
                                m_sMesgId.c_str()); 
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms307::SetData...");
    return;
}

int CSendCcms307::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms307::UpdateState...");

    string strSQL;

    strSQL += "UPDATE CM_TRANSREPEAL t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_08;
    strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
    strSQL += "', t.MESGREFID = '";
    strSQL += m_sMesgId;
    strSQL += "', t.STATETIME = sysdate ";

    strSQL += " WHERE t.SYSID = '";
    strSQL += m_szSysFlagNO;
    strSQL += "' AND t.MSGID = '";
    strSQL += m_szMsgFlagNO;
    strSQL += "' AND t.INSTGINDRCTPTY = '";
    strSQL += m_szSndNO; 									
    strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());

    int iRet = m_CmTrRepeal.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "UpdateState error:[%d]", iRet);
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms307::UpdateState...");
    return RTN_SUCCESS;
}

void CSendCcms307::AddSign307()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms307::AddSign307...");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_ccms307.getOriSignStr();
	
	AddSign(m_ccms307.m_sSignBuff.c_str(), 
					sSignedStr, 
					RAWSIGN,
					m_CmTrRepeal.m_instgdrctpty.c_str());
	
	m_ccms307.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms307::AddSign307...");
}

