/********************************************************************
�ļ�����sendccms312.cpp
�����ˣ�aps-lel
��  �ڣ�2011.04.02
��  ����ͨ��ǩ����Ϣҵ����
��  ����
Copyright (c) 2011  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendccms312.h"


CSendCcms312::CSendCcms312(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{

}

CSendCcms312::~CSendCcms312()
{

}

void CSendCcms312::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms312::SetDBKey...");
    
	m_Cmcnotsgninfbiz.m_msgid = m_szMsgFlagNO; 
	m_Cmcnotsgninfbiz.m_instgpty = m_szSndNO; 
	
	m_Cmcnotsgninfbiz.m_srcflag = m_szSrcflg;
	m_Cmcnotsgninfbiz.m_syscd    = m_szSysFlagNO;     //ϵͳID  


    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMsgFlagNO = %s", m_szMsgFlagNO);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szSndNO = %s", m_szSndNO);
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms312::SetDBKey...");
    return;
}

void CSendCcms312::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms312::SetData...");
	
	int iSysflg = -1;
    int iRet = -1;
    chgSysCd(m_szSysFlagNO,iSysflg); 
    iRet = GetIsoDateTime(m_dbproc, iSysflg, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_ISODateTime = %s", m_ISODateTime);
	char szLen[8+1] = {0}; 
    char szSyscd[4+1] = {0};
    strcpy(szSyscd,m_Cmcnotsgninfbiz.m_syscd.c_str());
    StrUpperCase_ZFPT(szSyscd);
    
    // ���ļ�ͷ
    m_ccms312.CreateXMlHeader(szSyscd,                        \
                                m_Cmcnotsgninfbiz.m_workdate.c_str(), \
                                m_Cmcnotsgninfbiz.m_instgdrctpty.c_str(), \ 
                                m_Cmcnotsgninfbiz.m_instddrctpty.c_str(),\
                                "ccms.312.001.01",              \
                                m_sMesgId.c_str()); 
//      //m_Cmcnotsgninfbiz.m_instgdrctpty.c_str(),\
	//����С��ʱ���ղ�����������ֱ�Ӳ������Ҫ�ر��뱣��һ�£���д����ֱ�Ӳ��������
	//����С��ʱ�����������뷢��ֱ�Ӳ������Ҫ�ر��뱣��һ�£���д����ֱ�Ӳ��������
	
	m_ccms312.InstgDrctPty                  = m_Cmcnotsgninfbiz.m_instgdrctpty; //����ֱ�Ӳ������
	m_ccms312.GrpHdrInstgPty                = m_Cmcnotsgninfbiz.m_instgpty;     //����������
	m_ccms312.InstdDrctPty                  = m_Cmcnotsgninfbiz.m_instddrctpty; //����ֱ�Ӳ������
	m_ccms312.GrpHdrInstdPty                = m_Cmcnotsgninfbiz.m_instdpty;     //���ղ������
	
	m_ccms312.MsgId                         = m_Cmcnotsgninfbiz.m_msgid;        //���ı�ʶ��    
	m_ccms312.CreDtTm                       = m_ISODateTime;                    //���ķ���ʱ��
	
	m_ccms312.SysCd                         = m_Cmcnotsgninfbiz.m_syscd;	  	//ϵͳ���
	m_ccms312.Rmk                           = m_Cmcnotsgninfbiz.m_rmk;		    //��ע
	m_ccms312.CtgyPurpCd					= m_Cmcnotsgninfbiz.m_ctgypurpcd;	//ҵ���������
	m_ccms312.TxTpCd                        = m_Cmcnotsgninfbiz.m_txtpcd;		//ҵ�����ͱ���
	m_ccms312.Titl                          = m_Cmcnotsgninfbiz.m_titl;			//��Ϣ����
	m_ccms312.CmonSgntrInfBizInfCntt        = m_Cmcnotsgninfbiz.m_cntt;			//��Ϣ����
    sprintf(szLen,"%08d",m_Cmcnotsgninfbiz.m_attchmtlen);
	m_ccms312.AttchmtLen                    = szLen;	//��������
	m_ccms312.AttchmtNm                     = m_Cmcnotsgninfbiz.m_attchmtnm;	//��������
	if(0==STRNCASECMP("bigdata",m_Cmcnotsgninfbiz.m_attchmtcntt.substr(0,8).c_str(),7))
    {
        QueryBigdataTable(m_Cmcnotsgninfbiz.m_attchmtcntt.c_str());
    }   
	m_ccms312.AttchmtCnttCntt               = m_Cmcnotsgninfbiz.m_attchmtcntt;	//��������
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms312::SetData...");
    m_Cmcnotsgninfbiz.closeCursor();
    return;
}

int CSendCcms312::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms312::GetData...");
	
	SETCTX(m_Cmcnotsgninfbiz);
	
    SetDBKey();
	/*
    //int iRet = m_Cmcnotsgninfbiz.findByPK();
    
    char strSql[1024]={0};
    sprintf(strSql ,"INSTGPTY='%s' and MSGID='%s' and srcflag='%s' "
                    ,m_Cmcnotsgninfbiz.m_instgpty.c_str()
                    ,m_Cmcnotsgninfbiz.m_msgid.c_str()
                    ,m_Cmcnotsgninfbiz.m_srcflag.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=[%s]",strSql);
	int iRet = m_Cmcnotsgninfbiz.find(strSql);
	if(0 != iRet)
	{
		sprintf( m_sErrMsg,"find error,error code =[%d] error cause = [%s]",iRet,m_Cmcnotsgninfbiz.GetSqlErr());
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_sErrMsg);
		PMTS_ThrowException(__FILE__,__LINE__,DB_NOT_FOUND,m_sErrMsg);
	}
	iRet = m_Cmcnotsgninfbiz.fetch();
	if(iRet ==SQLNOTFOUND)
	{
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������");
        m_Cmcnotsgninfbiz.closeCursor();
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "m_Cmcnotsgninfbizû���ҵ�����������ԭҵ��");
	}
	
	if(RTN_SUCCESS != iRet)
	{
	   sprintf( m_sErrMsg,"findByPK() error,error code =[%d] error cause = [%s]",iRet,m_Cmcnotsgninfbiz.GetSqlErr());
	   Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_sErrMsg);
	   PMTS_ThrowException(__FILE__,__LINE__,DB_NOT_FOUND,m_sErrMsg);
			
	}
   */
   
	m_isFromBank = false;

    int iRet = m_Cmcnotsgninfbiz.findByPK();
	if(RTN_SUCCESS != iRet)
	{
	    m_isFromBank = true;
	    m_szSrcflg[0] = '0';
	    m_Cmcnotsgninfbiz.m_srcflag = m_szSrcflg;
	    iRet = m_Cmcnotsgninfbiz.findByPK();
    	if(0 != iRet)
    	{
    		sprintf( m_sErrMsg,"findByPK() error,error code =[%d] error cause = [%s]",iRet,m_Cmcnotsgninfbiz.GetSqlErr());
    		Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_sErrMsg);
    		PMTS_ThrowException(__FILE__,__LINE__,DB_NOT_FOUND,m_sErrMsg);
        }
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms312::GetData...");
	
    return iRet;
}

int CSendCcms312::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms312::UpdateState...");
    SetDBKey();
    string strSQL;
	strSQL += "UPDATE cm_cnotsgninfbiz  t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_08;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
    strSQL += "' , t.PROCTIME = sysdate ";   
	strSQL += " WHERE t.MSGID = '";
	strSQL += m_Cmcnotsgninfbiz.m_msgid.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_Cmcnotsgninfbiz.m_instgpty.c_str(); 									
	strSQL += "' AND t.SRCFLAG = '";
	strSQL += m_szSrcflg;
	strSQL += "' ";
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	
	int iRet = m_Cmcnotsgninfbiz.execsql(strSQL.c_str());
	
    if(RTN_SUCCESS != iRet)
    {	  
	   sprintf( m_sErrMsg,"execsql() error,error code =[%d] error cause = [%s]",iRet,m_Cmcnotsgninfbiz.GetSqlErr());
	   Trace(L_ERROR,  __FILE__,  __LINE__, NULL,m_sErrMsg);
	   PMTS_ThrowException(__FILE__,__LINE__,DB_UPDATE_FAIL,m_sErrMsg);

    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms312::UpdateState...");
    return RTN_SUCCESS;
}

int CSendCcms312::doWorkSelf()
{
   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms312::doWork...");

    int iRet = 0;

    GetData();

   // m_ccms312.Init(m_iVersion, atoi(m_szMsgType));
    SetData();
    
    AddSign312();
    
    iRet = m_ccms312.CreateXml();
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    AddQueue( m_ccms312.m_sXMLBuff.c_str(), m_ccms312.m_sXMLBuff.length());

    UpdateState();
    
    if(m_isFromBank)
    {
        m_szSrcflg[0] = '1';
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms312::doWork..."); 
    return RTN_SUCCESS;
}

void CSendCcms312::AddSign312()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms312::AddSign312...");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_ccms312.getOriSignStr();
	
	AddSign(m_ccms312.m_sSignBuff.c_str(), 
					sSignedStr, 
					RAWSIGN,
					m_ccms312.InstgDrctPty.c_str());
	
	m_ccms312.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms312::AddSign312...");
}

void CSendCcms312::QueryBigdataTable(const char * pQryWhere)
{   
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendCcms312::QueryBigdataTable...");
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendCcms312::QueryBigdataTable...");
}

