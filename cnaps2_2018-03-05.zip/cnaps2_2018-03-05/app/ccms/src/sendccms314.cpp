/********************************************************************
�ļ�����send314.cpp
�����ˣ�handongfeng
��  �ڣ�2011.01.14
��  ����
��  ����
Copyright (c) 2009  YLINK
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendccms314.h"

CSendCcms314::CSendCcms314(const stuMsgHead& Smsg):CSendCcmsBase(Smsg)
{
}

CSendCcms314::~CSendCcms314()
{

}

void CSendCcms314::AddSign314()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms314::AddSign314");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_ccms314.getOriSignStr();
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "getOriSignStr=[%s]",m_ccms314.m_sSignBuff.c_str());
	AddSign(m_ccms314.m_sSignBuff.c_str(), 
					sSignedStr, 
					RAWSIGN,
					m_ccms314.InstgDrctPty.c_str());
	
	m_ccms314.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms314::AddSign314");
}

void CSendCcms314::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms314::SetDBKey...");
    
    string  strSys = "";
    
    strSys = m_szSysFlagNO;
    
    Upper(strSys);
    m_CTransQry.m_sysid = strSys;
	m_CTransQry.m_msgid = m_szMsgFlagNO; 
	m_CTransQry.m_instgindrctpty = m_szSndNO;
	m_CTransQry.m_rsflag = m_szSrcflg;
   
    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_sysid=[%s]",m_CTransQry.m_sysid.c_str());
    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_msgid=[%s]",m_CTransQry.m_msgid.c_str());
    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_instgindrctpty=[%s]",m_CTransQry.m_instgindrctpty.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms314::SetDBKey...");
    return;
}

void CSendCcms314::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms314::SetData...");
    
	char sAmount[255] = {0};	
    int iSysflg = -1;
    int iRet = -1;
    chgSysCd(m_szSysFlagNO,iSysflg); 
    iRet = GetIsoDateTime(m_dbproc, iSysflg, m_ISODateTime);
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
    }

    m_ccms314.MsgId				= m_CTransQry.m_msgid;
	m_ccms314.CreDtTm			= m_ISODateTime;
	m_ccms314.InstgDrctPty		= m_CTransQry.m_instgdrctpty;
	m_ccms314.GrpHdrInstgPty	= m_CTransQry.m_instgindrctpty;
	m_ccms314.InstdDrctPty		= m_CTransQry.m_instddrctpty;
	m_ccms314.GrpHdrInstdPty	= m_CTransQry.m_instdindrctpty;
	m_ccms314.SysCd				= m_CTransQry.m_sysid;
	m_ccms314.Rmk				= m_CTransQry.m_rjctinf;
	m_ccms314.OrgnlMsgId		= m_CTransQry.m_orgnlmsgid;
	m_ccms314.OrgnlInstgPty		= m_CTransQry.m_orgnlinstgdrctpty;
	m_ccms314.OrgnlMT           = m_CTransQry.m_orgnlmsgtp;
	m_ccms314.QryTp				= m_CTransQry.m_qrytp;
    if(0==STRNCASECMP("QT01",m_ccms314.QryTp.c_str(),4))
    {                                                 
        m_ccms314.InstgIndrctPty		= m_CTransQry.m_orgninstgindrctpty;
        m_ccms314.InstdIndrctPty		= m_CTransQry.m_orgninstdindrctpty;
        m_ccms314.OrgnlTxId			    = m_CTransQry.m_orgnltxmsgid;
        m_ccms314.OrgnlTxTpCd		    = m_CTransQry.m_oripmttpprtry;
    }
	m_ccms314.Ccy				= m_CTransQry.m_qryccy;
	m_ccms314.Amt				= ftoa(sAmount,m_CTransQry.m_qryamt, 2);
	m_ccms314.Cntt				= m_CTransQry.m_msgcnt;

	//__wsh 2013-01-21 Ʊ�ݲ�ѯ�����û�и�ֵ
	m_ccms314.BllNb     = m_CTransQry.m_bllnb; //Ʊ�ݺ���
	m_ccms314.AccptDt   = m_CTransQry.m_accptdt; //�ж�����
	m_ccms314.BllDt     = m_CTransQry.m_blldt; //Ʊ������
	m_ccms314.DrftDueDt = m_CTransQry.m_drftduedt; //��Ʊ������
	m_ccms314.DrwrFullNm= m_CTransQry.m_drwrfullnm; //��Ʊ��ȫ��
	m_ccms314.CdtrBkFullNm = m_CTransQry.m_cdtrbkfullnm; //�տ���ȫ��
	m_ccms314.DbtrBkFullNm = m_CTransQry.m_dbtrbkfullnm; //������ȫ��


    // ���ļ�ͷ
    m_ccms314.CreateXMlHeader(m_szSysFlagNO,                        \
                                m_CTransQry.m_wrkdate.c_str(), \
                                m_CTransQry.m_instgdrctpty.c_str(),\
                                m_CTransQry.m_instddrctpty.c_str(),\
                                "ccms.314.001.01",              \
                                m_sMesgId.c_str()); 
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms314::SetData...");
    return;
}

int CSendCcms314::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms314::GetData...");

    SETCTX(m_CTransQry);
    SetDBKey();
    int iRet = m_CTransQry.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��,iRet=%d, %s", iRet, m_CTransQry.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms314::GetData...");
    return iRet;
}

int CSendCcms314::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms314::UpdateState...");
    SetDBKey();
    string strSQL;
    
    string strNpcMsg = "";
	int nSysID = m_CTransQry.m_sysid == "BEPS" ? SYS_BEPS : SYS_HVPS;
	if(!m_CTransQry.write_blob(m_ccms314.m_sXMLBuff.c_str(), strNpcMsg, nSysID)){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"д���ֶα�����:[%s]", m_CTransQry.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}

    //���ｫί��������Ϊ��̬����д�����ݿ� �������
    char szIOSdate[10 + 1] = {0};
    chgToISODate(m_CTransQry.m_consigndate.c_str(), szIOSdate);
    
	strSQL += "UPDATE cm_transinfoqry t SET t.PROCSTATE = '";
    strSQL += PR_HVBP_08;
    strSQL += "', t.npcmsg='";
    strSQL += strNpcMsg;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
	strSQL += "', t.FINALSTATEDATE = '";
    strSQL += szIOSdate;
    strSQL += "', t.STATETIME = sysdate ";
    
	strSQL += " WHERE t.MSGTP = '";
	strSQL += m_CTransQry.m_msgtp.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_CTransQry.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_CTransQry.m_instgindrctpty.c_str(); 									
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    int iRet = m_CTransQry.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��,iRet=%d, %s", iRet, m_CTransQry.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms314::UpdateState...");
    return iRet;
}

int CSendCcms314::doWorkSelf()
{
   Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCcms314::doWork...");

    int iRet = 0;

    GetData();
    
    SetData();

    //��ǩ
    if(2 == m_iVersion)
    {
        AddSign314();
    }
    
    iRet = m_ccms314.CreateXml();
    if(0 != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    //3)	ҵ���飨�ͻ������룩
    //.......
    //4)	���������ͻ������룩
    //.....
    
    UpdateState();
    
    AddQueue(m_ccms314.m_sXMLBuff.c_str(), m_ccms314.m_sXMLBuff.length());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCcms314::doWork..."); 
    return RTN_SUCCESS;
}



