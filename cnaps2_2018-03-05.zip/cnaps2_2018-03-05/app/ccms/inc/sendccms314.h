/********************************************************************
�ļ�����send314.h
�����ˣ�handongfeng
��  �ڣ�2011.01.14
��  ����
��  ����
Copyright (c) 2009  YLINK
********************************************************************/
#ifndef __SENDCCMS314_H__
#define __SENDCCMS314_H__

#include "sendccmsbase.h"
#include "ccms314.h"
#include "cmtransinfoqry.h"

class CSendCcms314 : public CSendCcmsBase
{
public:
	CSendCcms314(const stuMsgHead& Smsg);
	~CSendCcms314();
	int doWorkSelf();
private:
	void AddSign314();
	void SetData();
	int GetData();
	int UpdateState();
	void SetDBKey();
	
private:
	CCmtransinfoqry m_CTransQry;
	ccms314         m_ccms314;
};

#endif


