/******************************************************************** 
文件名： ProcessPayment.cpp
创建人： hdf
日  期： 2013-03-13
修改人： hdf
日  期： 
描  述： 处理批量代付回执包
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef _PROCESSPAYMENT_H_
#define _PROCESSPAYMENT_H_

#include "pubfunc.h"
#include "logger.h"
#include "mqagent.h"
#include "exception.h"

#include "pkg012.h"
#include "bpcolltnchrgscl.h"
#include "bpbcoutsendlist.h"
#include "bpcolltnchrgslist.h"

class CProcessPayment
{

public:
    CProcessPayment();
    ~CProcessPayment();

    INT32 Work();
    void ProcessPkg012();
    void FillFactInfo();
    void FillHeadInfo();
    void UpdateCurReturnDay(int iCurReturnDay);
    void UpDateOrgn012();
    void AddQueue(string msgtx, int length);
    void UpDateOrgnCD();
private:

    pkg012 m_pkg012;
    CBpbcoutsendlist m_BpBcList;
    CBpcolltnchrgscl m_colltnchrgscl;
    CBpcolltnchrgslist m_colltnchrgslist;
    int m_iTotalNum;
    int m_iFacNum;//回执要素数目
    double m_dTotalAmt;
    string m_strTempAppData;
    int m_iOrgnDbNum;
    double m_dOrgnFacAmt;//原交易付款总金额
};

#endif
