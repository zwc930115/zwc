#ifndef __SENDCCMSWORK_H__
#define __SENDCCMSWORK_H__

#include "basicapi.h"
#include "pubfunc.h"
#include "logger.h"

using namespace ZFPT;

class CSendCcmsWork
{
public:
    CSendCcmsWork();
    CSendCcmsWork(const CSendCcmsWork &e);
    ~CSendCcmsWork();
	
    INT32 doWork();

	void clear();

    void UnpackMsgHead(const char* strMsg);

    CSendCcmsWork& operator=(const CSendCcmsWork & e)
    {
        if(this != &e)
        {
            m_sTrsCode = e.m_sTrsCode;
            ClientSocket = e.ClientSocket;
            memcpy(&m_MsgHead, &e.m_MsgHead, sizeof(e.m_MsgHead));
            memcpy(m_MQMsgId , e.m_MQMsgId, sizeof(e.m_MQMsgId));
        }
        return *this;
    }

    //在这里添加成员的时候记得在操作符重载函数和构造函数里也添加!
    int			ClientSocket;
    char m_MQMsgId[64];
private:
    string		m_sTrsCode;
    stuMsgHead	m_MsgHead;
    
};

#endif


