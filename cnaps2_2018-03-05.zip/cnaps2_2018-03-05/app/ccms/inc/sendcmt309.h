/******************************************************************** 
文件名： sendcmt309.h
创建人： aps-xcm
日  期： 2011-06-23
修改人： 
日  期： 
描  述： 一代大额往账银行汇票支付报文
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifndef _SENDCMT309_H_
#define _SENDCMT309_H_

#include "sendccmsbase.h"
#include "cmt309.h"
#include "hvsealerr.h"

class CSendCmt309 : public CSendCcmsBase
{
public:
    CSendCmt309(const stuMsgHead& Smsg);
    ~CSendCmt309();
    int doWorkSelf();
private:
    int buildCmtMsg();
    int GetData();
    int UpdateState();
    void SetData();
private:
    CHvsealerr m_Hvsealerr;
    
    cmt309 m_cCmt309;
};
#endif







