/******************************************************************** 
�ļ����� sendcmt321.h
�����ˣ� handonfeng
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef __SENDCMT321_H__
#define __SENDCMT321_H__

#include "cmt321.h"
#include "cmtransrepeal.h" 
#include "sendccmsbase.h"

class CSendCmt321 : public CSendCcmsBase
{
public:
    CSendCmt321(const stuMsgHead& Smsg);
    ~CSendCmt321();
    
    int  doWorkSelf();
    
private:
    int buildCmtMsg();
	int GetData();
	INT32 SetData();
    int UpdateState();

    cmt321              m_cmt321;
    CCmtransrepeal m_CmTrRepeal;
};

#endif


