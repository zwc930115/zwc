/******************************************************************** 
文件名： recvccms921.h
创建人： handongfeng
日  期： 2011-04-02
修改人： 
日  期： 
描  述： 数字证书绑定通知报文<ccms.921.001.02>来账处理
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef _RECVCCMS921_H_
#define _RECVCCMS921_H_

#include "recvccmsbase.h"
#include "ccms921.h"
#include "ccms903.h"
#include "cmbnddigcert.h"
#include "cmbankcertinfo.h"

class CRecvCcms921 : public CRecvCcmsBase
{
	
public:
	CRecvCcms921();
	~CRecvCcms921();

	//业务入口函数
	INT32 Work(LPCSTR sMsg);

	//解析报文串
	INT32 unPack(LPCSTR sMsg);

	//实体类赋值
	INT32 SetData(LPCSTR pchMsg);

	//新增数据库
	INT32 InsertData(void);
    void UpdateState();
    //void UpdataCertData();
    void ParserCert(const char* pCert);
private:
	CCmbnddigcert m_CCmbnddigcert;
	CCmbankcertinfo m_CCmbankcertinfo;
    ccms921 m_ccms921;

    int m_iChgTp; /*变更类型:0：新增，1：撤销*/
};

#endif


