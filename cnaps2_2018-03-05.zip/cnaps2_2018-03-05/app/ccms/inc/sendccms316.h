/********************************************************************
�ļ�����sendccms316.h
�����ˣ�aps-lel	
��  �ڣ�2011.03.31
��  ����
��  ����
Copyright (c) 2011  YLINK
********************************************************************/
#ifndef __SENDCCMS316_H__
#define __SENDCCMS316_H__

#include "sendccmsbase.h"
#include "ccms316.h"
#include "cmtransstqry.h"

class CSendCcms316 : public CSendCcmsBase
{
public:
    CSendCcms316(const stuMsgHead& Smsg);
    ~CSendCcms316();
    int doWorkSelf();
private:
    void SetData();
    int  GetData();
    int  UpdateState();
	void SetDBKey();

private:
    CCmtransstqry m_Cmtransstqry;
    ccms316 m_ccms316;
};

#endif


