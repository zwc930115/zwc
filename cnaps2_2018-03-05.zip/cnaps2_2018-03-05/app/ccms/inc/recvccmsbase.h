#ifndef _RECVCCMSBASE_H_
#define _RECVCCMSBASE_H_

#include "pubfunc.h"
#include "exception.h"
#include "logger.h"
#include "cmrecvmsg.h"
#include "cmrecverrmsg.h" 
#include "mqagent.h"

using namespace ZFPT;
extern MQAgent m_cMQAgent; 
extern DBProc  m_dbproc;
extern char        g_SapBank[17];

class CRecvCcmsBase
{
public:
    CRecvCcmsBase();
    virtual ~CRecvCcmsBase();

	INT32 doWork(LPCSTR pchMsg);
    
    INT32 SetData(LPCSTR pchMsg);
    
    INT32 InsertData(void);
    
    INT32 DelCmRecvMsg(void);
    
    INT32 WriteErrTable(LPCSTR pchMsg, int nErrCode, LPCSTR pchErrDesc);

	INT32 WriteErrFile(const char * pchErrText = NULL);

    void GetSapBkToCCPC(DBProc &dbproc, string sSapBank, char* sCCPCCode);
    
    int CheckSign(const char *srcSign, const char *dstSign, const char * sSendBankCode, int iFlag = RAWSIGN);

	void DirectInter(LPCSTR cpSendBank, 
					 LPCSTR cpRecvBank, 
					 LPCSTR cpRecvSapBank, 
					 LPCSTR cpNpcMsg, 
					 LPCSTR cpSysflg = "HVPS");
	void DirectInterBEPS(LPCSTR cpSendBank, 
					 LPCSTR cpRecvBank, 
					 LPCSTR cpRecvSapBank, 
					 LPCSTR cpNpcMsg, 
					 LPCSTR cpSysflg = "BEPS",
					 LPCSTR cpIngoingDetailTable = NULL);
public:
	string	m_strBizCode;       //交易码(写错误文件名用,recvcmwork赋值)
	string	m_strRcvMsgID;      //来帐MSGID(自拼标识符,删除通讯表用,recvcmwork赋值)
	char	m_sCommHead[42 + 1];//通讯层报文头
    string  m_strSendMsg;       //发送报文串
	int     m_iErrMsgFlag;  //异常消息标志
	string  m_ErrMsgTp;
	int		m_iMsgVer;			//1:一代报文;2:二代报文
	
protected:
	
	//业务处理入口函数
	virtual INT32  Work(LPCSTR szMsg) = 0; 
	
	int		AddQueue(string msgtx, int length);

	//DBProc	m_dbproc;
	//MQAgent m_cMQAgent;
	string	m_strMsgID;         //报文MSGID(写错误文件名用,子业务赋值)
	bool	m_bIfOptBigData;    //操作大字段表
	char	m_szErrMsg[1024 + 1];	//错误描述
	char    m_sWorkDate[8 + 1];	//工作日期
	char    m_szDisSys[3 + 1];       //原目标系统
	char    m_szOrgnlMbMsgId[22 + 1];//原行内报文标识号
	string	m_strWorkDate;		//工作日期
	string	m_strMsgTp;			//报文类型:二代HVPS开头,一代CMT开头
	char	m_szIngoingDetailTable[40 + 1];		// 来账明细表名
	int iBaseCertSign;	//是否验签名或核押标识
private:
	
	
    CCmrecvmsg		m_cCmrecvmsg;       
    CCmrecverrmsg	m_cCmrecverrmsg;

	void GetDBConnect(void);

	void GetMqConn(void);

    INT32 DoException(LPCSTR pchMsg, int nErrCode, LPCSTR pchErrDesc);
    
    void	Send990(LPCSTR pchMsg);
    void Init();
};

#endif


