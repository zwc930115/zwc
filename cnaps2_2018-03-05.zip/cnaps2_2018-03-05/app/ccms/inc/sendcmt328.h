/******************************************************************** 
文件名： sendcmt328.h
创建人： handonfeng
日  期： 2011-04-18
修改人： 
日  期： 
描  述：小额借记止付往帐328报文处理类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef __SENDCMT328_H__
#define __SENDCMT328_H__

#include "cmt328.h"
#include "cmt327.h"
#include "bpcstbdpcxlcl.h"
#include "bpcstbdpcxllist.h"
#include "bpbdrcvcl.h"
#include "bpbdrecvlist.h"
#include "sendccmsbase.h"

class CSendCmt328 : public CSendCcmsBase
{
public:
    CSendCmt328(const stuMsgHead& Smsg);
    ~CSendCmt328();
    
    INT32  doWorkSelf();
private:
    
    int GetData();
    int setBdPcxlList();
	int buildPmtsMsg();


	//修改原查询业务状态
    int UpdateState();
    
    void UpdateDb(void);
    
	cmt328				m_cmt328;
    cmt327              m_cmt327;
    CBpcstbdpcxlcl		m_cBpcstbdpcxlcl;
    CBpcstbdpcxlcl		m_OrgncBpcstbdpcxlcl;
    CBpcstbdpcxllist	m_cOrgnBpcstbdpcxllist;
    CBpbdrcvcl          m_cBpbdrcvcl;    
    CBpbdrecvlist       m_cBpbdrecvlist;
};

#endif


