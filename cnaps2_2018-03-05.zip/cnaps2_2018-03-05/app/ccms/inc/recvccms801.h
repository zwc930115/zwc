/******************************************************************** 
文件名： recvccms801.h
创建人： hq
日  期： 2011-03-19
修改人： hdf
日  期： 
描  述： 系统状态变更通知报文<ccms.801.001.02>
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef _RECVCCMS801_H_
#define _RECVCCMS801_H_

#include "recvccmsbase.h"
#include "ccms801.h"
#include "bpsapbankinfo.h"
#include "hvsapbankinfo.h"
#include "bepschangeday.h"
#include "hvbkchkst.h"
#include "hvsapwtchgedt.h"
#include "bpbchkstate.h"

class CRecvCcms801 : public CRecvCcmsBase
{
	
public:
	CRecvCcms801();
	~CRecvCcms801();

	INT32   Work(LPCSTR sMsg);
	INT32   unPack(LPCSTR sMsg);
	INT32   UpdateDB(LPCSTR sMsg);
	INT32   ChangeHVPSDay();
	INT32   ChangeBEPSDay();
	void    InsertHvbkchkst();
    void    InsertHvsapwtchgedt();
    void    GetHvbkchkst();
    void    insertChkst();
    
private:
    bool           m_bFlag;
	ccms801        m_ccms801;
	CBpsapbankinfo m_Bpsapbankinfo;
	CHvsapbankinfo m_Hvsapbankinfo;
    CBepsChangeDay m_BpChgDay;
    CHvbkchkst     m_Hvbkchkst;
    CBpbchkstate   m_Bpbchkstate;
    CHvsapwtchgedt m_Hvsapwtchgedt;
    
    char m_sOrgnlSysDt[8 + 1];
    char m_sCurSysDt[8 + 1];
    char m_sNxtSysDt[8 + 1];
    int  m_iSysCd;
    char m_sfeastflg[1 + 1];
    char m_szHeadInstdDrctPty[14+1];
};

#endif

