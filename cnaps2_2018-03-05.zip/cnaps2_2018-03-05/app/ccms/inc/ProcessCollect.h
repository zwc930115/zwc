/******************************************************************** 
文件名： ProcessCollect.cpp
创建人： hdf
日  期： 2013-03-13
修改人： hdf
日  期： 
描  述： 处理批量代收回执包
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef _PROCESSCOLLECT_H_
#define _PROCESSCOLLECT_H_

#include "pubfunc.h"
#include "logger.h"
#include "mqagent.h"
#include "exception.h"

#include "bpcolltnchrgscl.h"
#include "bpcolltnchrgslist.h"
#include "bpbdsendlist.h"
#include "pkg012.h"

class CProcessCollect
{
public:

    CProcessCollect();
    ~CProcessCollect();
    INT32 Work();

private:

    void Create012Pack();
    void FillFactInfo();
    void FillHeadInfo();
    void UpDateOrgn012();
    void AddQueue(string msgtx, int length);
    void UpdateCurReturnDay(int iCurReturnDay);
    void UpDateOrgnBD();

private:

    CBpbdsendlist    m_orgnlbiz;
    int              m_iTotalNum;//成功总笔数
    double           m_dTotalAmt;//成功总金额
    double           m_dFacAmt;//原代收业务收款要求总金额
    int              m_iOrgnCdNum;//原代收业务收款人数目
    int              m_iFacNum;//回执要素数目
    string           m_strTempAppData;
    pkg012           m_pkg012;
    CBpcolltnchrgscl m_colltnchrgscl;
    CBpcolltnchrgslist m_colltnchrgslist;
};

#endif 
