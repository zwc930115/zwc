/******************************************************************** 
文件名： recvhvpsbase.h 
创建人： yszhong
日  期： 2011-03-01
修改人： 
日  期： 
描  述： 大额接收基类 
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef _RECVHVPSBASE_H_
#define _RECVHVPSBASE_H_

#include "pubfunc.h"
#include "exception.h"
#include "logger.h"
#include "hvrecvmsg.h"
#include "cmrecverrmsg.h" 
#include "charge.h"
#include "mqagent.h"

extern MQAgent m_cMQAgent; 
extern DBProc  m_dbproc;

class CRecvHvpsBase
{
public:
	CRecvHvpsBase();
	virtual ~CRecvHvpsBase();

	INT32 doWork(LPCSTR pchMsg);
	INT32 doChildWork(LPCSTR pchMsg);
		
	INT32 SetData(LPCSTR pchMsg);
	int AddSign(const char *srcSign, char *dstSign, int iFlag,const char * pSendSapbank);

	string  m_strBizCode;       //交易码(写错误文件名用,recvhvwork赋值)
	string  m_strRcvMsgID;      //来帐MSGID(自拼标识符,删除通讯表用,recvhvwork赋值)
	char	m_sCommHead[42 + 1];//通讯层报文头
    string  m_strSendMsg;       //发送报文串
    int     m_iErrMsgFlag;  //异常消息标志
	int		m_iMsgVer;			                //1:一代报文;2:二代报文
    
protected:
    // 业务处理入口函数
	virtual INT32 Work(LPCSTR pchMsg) = 0;

	INT32 InsertData(void);
    void  DirectInter(LPCSTR cpSendBank, LPCSTR cpRecvBank, LPCSTR cpRecvSapBank, LPCSTR cpNpcMsg, LPCSTR cpIngoingDetailTable = NULL, LPCSTR cpPmtTpPrtry = NULL);
	int AddQueue(string msgtx, int length);
    int CheckSign(const char *srcSign, const char *dstSign, const char * sSendBankCode, int iFlag = RAWSIGN);
    
    //DBProc  m_dbproc;
	string  m_strMsgID;                         //报文MSGID(写错误文件名用,子业务赋值)
	bool    m_bIfOptBigData;                    //操作大字段表
	char    m_szErrMsg[1024];                   //错误描述
	char    m_sWorkDate[8 + 1];	                //工作日期
	string	m_strWorkDate;		                //工作日期
	string	m_strMsgTp;			                //报文类型:二代HVPS开头,一代CMT开头
    //MQAgent m_cMQAgent;                         
    string  m_ErrMsgTp;                         
    string  m_strCdCode;                        //用于存储141,142的借贷标识
	char    m_szOprUser[20 + 1];                //最终操作用户
	char    m_szOprUserNetId[20 + 1];           //用户所属机构
    CCharge m_charge;	                        //记账及虚拟清算
	char    m_szDisSys[3 + 1];                  //原目标系统
	char    m_szOrgnlMbMsgId[22 + 1];           //原行内报文标识号
	char	m_szIngoingDetailTable[40 + 1];		// 来账明细表名
	char	m_szPmtTpPrtry[6 + 1];				// 业务类型编码
	int iBaseCertSign;
private:
	
	CHvrecvmsg       m_cHvrecvmsg;              //大额来帐通讯表
	CCmrecverrmsg    m_cCmrecverrmsg;           //异常来帐表

	void GetDBConnect(void);

	void GetMqConn(void);

    INT32 DoException(LPCSTR pchMsg, int nErrCode, LPCSTR pchErrDesc);

	INT32 WriteErrTable(const char * pchMsg, int nErrCode, const char * pchErrDesc);

	INT32 WriteErrFile(const char * pchErrText = NULL);

	INT32 DelHvRecvMsg(void);
	
	void	Send990(LPCSTR pchMsg);
	void Init();
};

#endif


