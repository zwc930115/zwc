/******************************************************************** 
�ļ����� sendhvps143.h
�����ˣ� handongfeng
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __SENDHVPS143_H__
#define __SENDHVPS143_H__

#include "sendhvpsbase.h"
#include "hvps143.h"
#include "hvpvpsetofac.h"

class CSendHvps143 : public CSendHvpsBase
{
public:
	CSendHvps143(const stuMsgHead& Smsg);
	~CSendHvps143();
	int doWorkSelf();
private:
	void AddSign143();
	void SetData();
	int GetData();
	int UpdateState();
	void SetDBKey();
	
private:
	CHvpvpsetofac m_Hvpvpsetofac;
	hvps143 m_cParser143;
};

#endif

