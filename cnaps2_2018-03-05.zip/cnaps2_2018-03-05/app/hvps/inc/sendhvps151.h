/******************************************************************** 
�ļ����� send151.h
�����ˣ� handongfeng
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __SENDHVPS151_H__
#define __SENDHVPS151_H__

#include "sendhvpsbase.h"
#include "hvps151.h"
#include "hvdraft.h"

class CSendHvps151 : public CSendHvpsBase
{
public:
    CSendHvps151(const stuMsgHead& Smsg);
    ~CSendHvps151();
    int doWorkSelf();
private:
    void AddSign151();
    void SetData();
    int GetData();
    int UpdateState();
    void SetDBKey();

private:
    CHvdraft m_CHvdraft;
    hvps151 m_cParser151;
};

#endif




