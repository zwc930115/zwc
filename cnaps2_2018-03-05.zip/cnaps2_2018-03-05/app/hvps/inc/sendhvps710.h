/******************************************************************** 
�ļ����� send710.h
�����ˣ� handongfeng
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __SENDHVPS710_H__
#define __SENDHVPS710_H__

#include "sendhvpsbase.h"
#include "hvps710.h"
#include "hvbkchkst.h"
#include "cmcheckqry.h"

class CSendHvps710 : public CSendHvpsBase
{
public:
    CSendHvps710(const stuMsgHead& Smsg);
    ~CSendHvps710();
    int doWorkSelf();
private:
    void AddSign710();
    void SetData();
    int GetData();
    int UpdateState();
    void SetDBKey();
    void InsertDB();

    CHvbkchkst m_Hvbkchkst;
    hvps710 m_hvps710;
    string m_strISOData;
};

#endif



