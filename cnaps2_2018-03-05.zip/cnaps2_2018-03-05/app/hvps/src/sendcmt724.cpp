/******************************************************************** 
�ļ����� sendcmt724.cpp
�����ˣ� aps-xcm
��  �ڣ� 2011-06-27
�޸��ˣ� 
��  �ڣ� 
��  ���� һ������������л�Ʊ�����˻ر���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt724.h"

CSendCmt724::CSendCmt724(const stuMsgHead& Smsg):CSendHvpsBase(Smsg)
{
   
}

CSendCmt724::~CSendCmt724()
{
    
}

void CSendCmt724::SetDBKey()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt724::SetDBKey...");

    m_CHvdraft.m_msgtp = "CMT";
    m_CHvdraft.m_msgtp = m_CHvdraft.m_msgtp + m_szMsgType;

    m_CHvdraft.m_msgid = m_szMsgFlagNO;
    m_CHvdraft.m_instgindrctpty = m_szSndNO;

    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "m_CHvdraft.m_msgtp = [%s]", m_CHvdraft.m_msgtp.c_str());
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "m_CHvdraft.m_msgid = [%s]", m_CHvdraft.m_msgid.c_str());
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "m_CHvdraft.m_instgindrctpty = [%s]", m_CHvdraft.m_instgindrctpty.c_str());

    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt724::SetDBKey...");
}


int CSendCmt724::GetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt724::GetData...");

    SETCTX(m_CHvdraft);

    SetDBKey();

    int iRet = m_CHvdraft.findByPK();

    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ȡ����ʧ��iRet[%d],[%s]", iRet, m_CHvdraft.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt724::GetData...");
    return iRet;
}

void CSendCmt724::SetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt724::SetData...");

    strncpy(m_cCmt724.sConsigndate, m_CHvdraft.m_consigndate.c_str(), sizeof(m_cCmt724.sConsigndate) - 1);//ί������
    strncpy(m_cCmt724.sSendbank, m_CHvdraft.m_instgdrctpty.c_str(), sizeof(m_cCmt724.sSendbank) - 1);//�����к�
    strncpy(m_cCmt724.sRecvbank, m_CHvdraft.m_instddrctpty.c_str(), sizeof(m_cCmt724.sRecvbank) - 1);//�����к�
    strncpy(m_cCmt724.sPayopenbk, m_CHvdraft.m_drftissrbk.c_str(), sizeof(m_cCmt724.sPayopenbk) - 1);//�����˿������к� = ��Ʊǩ�����к�

    strncpy(m_cCmt724.sBilldate, m_CHvdraft.m_drftdt.c_str(), sizeof(m_cCmt724.sBilldate) - 1);//Ʊ������
    strncpy(m_cCmt724.sBillno, m_CHvdraft.m_drftnb.c_str(), sizeof(m_cCmt724.sBillno) - 1);//Ʊ�ݺ���
    strncpy(m_cCmt724.sDrafttype, m_CHvdraft.m_drfttp.c_str(), sizeof(m_cCmt724.sDrafttype) - 1);//��Ʊ���

    strncpy(m_cCmt724.sDraftmac, itoa(m_CHvdraft.m_drfttstcd), sizeof(m_cCmt724.sDraftmac) -1);//��Ʊ��Ѻ
    m_cCmt724.dTicketamount = m_CHvdraft.m_amount;//��Ʊ���
    strncpy(m_cCmt724.sRemark, m_CHvdraft.m_reserve.c_str(), sizeof(m_cCmt724.sRemark) - 1);//���� = ������

    string strTemp;
    GetTag1ST("D01:", strTemp, m_CHvdraft.m_ustrdstr);
    strncpy(m_cCmt724.sOldbankcode, strTemp.c_str(), sizeof(m_cCmt724.sOldbankcode) - 1);

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt724::SetData...");
}


int CSendCmt724::UpdateState()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt724::UpdateState...");

    SETCTX(m_CHvdraft);
    string strSQL;
    strSQL += "UPDATE hv_draft t SET t.STATETIME = sysdate, t.PROCSTATE = '";
	strSQL += PR_HVBP_08;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
    strSQL += "' ";
    
	strSQL += " WHERE t.MSGTP = '";
	strSQL += m_CHvdraft.m_msgtp.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_CHvdraft.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_CHvdraft.m_instgindrctpty.c_str(); 									
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=[%s]", strSQL.c_str());
    int iRet = m_CHvdraft.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ�� iRet = %[d], [%s]", iRet, m_CHvdraft.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt724::UpdateState...");
    return iRet;
    
}

int CSendCmt724::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt724::buildCmtMsg...");

    int iRet = m_cCmt724.CreateCmt("724", m_CHvdraft.m_instgdrctpty.c_str(), m_CHvdraft.m_instddrctpty.c_str(), m_sMesgId.c_str(), m_sMesgId.c_str(), m_CHvdraft.m_wrkdate.c_str(), "3");
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt724::buildCmtMsg...");

    return iRet;
}

int CSendCmt724::doWorkSelf()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt724::doworkSelf...");
    //1)�������
    GetData();

    //2)��ֵ
    SetData();

    
    buildCmtMsg();

    
    //3)	ҵ���飨�ͻ������룩
    //.......
    //4)	���������ͻ������룩


    UpdateState();

    AddQueue(m_cCmt724.m_strCmtmsg, m_cCmt724.m_strCmtmsg.length());
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt724::doworkSelf...");
    return RTN_SUCCESS;
    
}

