/******************************************************************** 
�ļ����� sendcmt223.cpp
�����ˣ� aps-xcm
��  �ڣ� 2011-07-04
�޸��ˣ� 
��  �ڣ� 
��  ���� һ��������˴���ʱת�����㱨��
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt223.h"


CSendCmt223::CSendCmt223(const stuMsgHead & Smsg):CSendHvpsBase(Smsg)
{

}


CSendCmt223::~CSendCmt223()
{

}


int CSendCmt223::doWorkSelf()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt223::doworkSelf...");
    //1)�������
    GetData();

    //2)��ֵ
    SetData();

    
    buildCmtMsg();
    
    //3)	ҵ���飨�ͻ������룩
    //.......
    //4)	���������ͻ������룩


    UpdateState();

    AddQueue(m_cCmt223.m_strCmtmsg, m_cCmt223.m_strCmtmsg.length());
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt223::doworkSelf...");
    return RTN_SUCCESS;
    
}


void CSendCmt223::SetDBKey()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt223::SetDBKey...");

    m_Hvtrofacsndlist.m_msgid = m_szMsgFlagNO; 
	m_Hvtrofacsndlist.m_instgindrctpty = m_szSndNO; 
   
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvtrofacsndlist.m_msgid = %s", m_Hvtrofacsndlist.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvtrofacsndlist.m_instgindrctpty = %s", m_Hvtrofacsndlist.m_instgindrctpty.c_str());

    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt223::SetDBKey...");

}

int CSendCmt223::GetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt223::GetData...");

    SetDBKey();
	
    SETCTX(m_Hvtrofacsndlist);
	int iRet = m_Hvtrofacsndlist.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ�� iRet = [%d], [%s]", iRet, m_Hvtrofacsndlist.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    if(!m_Hvtrofacsndlist.m_endtoendid.empty())
    {
        m_sEndtoEnd = m_Hvtrofacsndlist.m_endtoendid;
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sEndtoEnd = %s", m_sEndtoEnd.c_str());
    }

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt223::GetData...");

    return iRet;
}


void CSendCmt223::SetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt223::SetData...");

    string strTemp;
    GetTag1ST("02B:", strTemp, m_Hvtrofacsndlist.m_ustrdstr);
    strncpy(m_cCmt223.sOldcmtno, strTemp.c_str(), sizeof(m_cCmt223.sOldcmtno) -1);
    strncpy(m_cCmt223.sConsigndate, m_Hvtrofacsndlist.m_consigndate.c_str(), sizeof(m_cCmt223.sConsigndate) -1);
    strTemp.erase();
    strTemp = m_Hvtrofacsndlist.m_msgid.substr(8, 8);
    m_cCmt223.iTxssno = atoi(strTemp.c_str());

    strncpy(m_cCmt223.sCur, m_Hvtrofacsndlist.m_currency.c_str(), sizeof(m_cCmt223.sCur) -1);
    m_cCmt223.dAmount = m_Hvtrofacsndlist.m_amount;
    strTemp.erase();
    GetTag1ST("CEB:", strTemp, m_Hvtrofacsndlist.m_ustrdstr);
    strncpy(m_cCmt223.sTradetype, strTemp.c_str(), sizeof(m_cCmt223.sTradetype) -1);
    strncpy(m_cCmt223.sSendsapbk, m_Hvtrofacsndlist.m_instgdrctpty.c_str(), sizeof(m_cCmt223.sSendsapbk) -1);
    strncpy(m_cCmt223.sSendbank, m_Hvtrofacsndlist.m_instgindrctpty.c_str(), sizeof(m_cCmt223.sSendbank) -1);
    strncpy(m_cCmt223.sRecvsapbk, m_Hvtrofacsndlist.m_instddrctpty.c_str(), sizeof(m_cCmt223.sRecvsapbk) -1);

    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt223::SetData...");

}

int CSendCmt223::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt223::buildCmtMsg...");

    int iRet = m_cCmt223.CreateCmt("223", m_Hvtrofacsndlist.m_instgdrctpty.c_str(), m_Hvtrofacsndlist.m_instddrctpty.c_str(), m_sMesgId.c_str(), m_sMesgId.c_str(), m_Hvtrofacsndlist.m_workdate.c_str(), "0");
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt223::buildCmtMsg...");
    return iRet;
}

int CSendCmt223::UpdateState()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt223::UpdateState...");

    SETCTX(m_Hvtrofacsndlist);

    string strSQL;

    strSQL += "UPDATE hv_trofacsndlist t SET t.STATETIME = sysdate, t.PROCSTATE = '08'";
	strSQL += ", t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
	strSQL += "', t.endtoendid = '";
	strSQL += m_sEndtoEnd;
    strSQL += "' ";
    
    strSQL += " WHERE t.MSGID = '";
	strSQL += m_Hvtrofacsndlist.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Hvtrofacsndlist.m_instgindrctpty.c_str(); 									
	strSQL += "'";
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "strSQL=[%s]", strSQL.c_str());
    int iRet = m_Hvtrofacsndlist.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��iRet=[%d], [%s]", iRet, m_Hvtrofacsndlist.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
        
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt223::UpdateState...");
    return iRet;
}





