/******************************************************************** 
文件名： send111.cpp
创建人： handongfeng
日  期： 2011-02-23
修改人：
日  期：
描  述：
版  本：
Copyright (c) 2011  YLINK 
********************************************************************/ 
    
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendhvps111.h"


CSendHvps111::CSendHvps111(const stuMsgHead& Smsg):CSendHvpsBase(Smsg)
{
   
}

CSendHvps111::~CSendHvps111()
{
    
}

void CSendHvps111::AddSign111()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendHvps111::AddSign111");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_cParser111.getOriSignStr();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSignBuff = [%s]", m_cParser111.m_sSignBuff.c_str());
	
	AddSign(m_cParser111.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_Hvsndlist.m_instgdrctpty.c_str());
	
	m_cParser111.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendHvps111::AddSign111");
}

string CSendHvps111::GetTag2ND(const string& QryVal, const string& QryStr, int& iDepth)
{
	string strTemp;
	if(RTN_SUCCESS == GetTagVal(strTemp, QryStr, QryVal))
	{ 
		strTemp = QryVal + strTemp;
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iDepth = [%d]", iDepth);
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strTemp = [%s]",strTemp.c_str());
		m_cParser111.SetUstrd(iDepth, strTemp.c_str());
		iDepth++;
	}
	
	return strTemp;
}

void CSendHvps111::SetData()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps111::SetData...");
	
	char szBuff[128]                 = {0};
	
	m_cParser111.m_szDigitSign       = "";
	m_cParser111.MsgId               = m_szMsgFlagNO;
	m_cParser111.DbtrAgtMmbId        = m_Hvsndlist.m_dbtmmbid;
	m_cParser111.DbtrAgtId           = m_Hvsndlist.m_dbtid;
	m_cParser111.CdtrAgtMmbId        = m_Hvsndlist.m_cdtmmbid;      
	m_cParser111.SttlmMtd            = "CLRG";                             
	m_cParser111.CdtrNm              = m_Hvsndlist.m_cdtrnm;
	m_cParser111.PurpPrtry           = m_Hvsndlist.m_purpprtry;                             
	m_cParser111.Ccy                 = m_Hvsndlist.m_currency;                           
	m_cParser111.TxId                = m_Hvsndlist.m_msgid;
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cParser111.TxId=%s", m_cParser111.TxId.c_str());
	m_cParser111.DbtrNm              = m_Hvsndlist.m_dbtnm;
	m_cParser111.CtgyPurpPrtry       = m_Hvsndlist.m_ctgypurpprtry;  
	m_cParser111.DbtrAcctId          = m_Hvsndlist.m_dbtracctid;
	m_cParser111.CdtrAgtId           = m_Hvsndlist.m_cdtid;
	m_cParser111.NbOfTxs             = "1";
	m_cParser111.CdtrAcctIssr        = m_Hvsndlist.m_cdtrissr;
	m_cParser111.SttlmPrty           = m_Hvsndlist.m_sttlmprty;
	m_cParser111.EndToEndId          = m_sEndtoEnd;
	m_cParser111.IntrBkSttlmAmt      = ftoa(szBuff, m_Hvsndlist.m_amount, 2);
	m_cParser111.ChrgBr              = "DEBT";                        
	m_cParser111.DbtrAcctIssr        = m_Hvsndlist.m_dbtrissr;
	m_cParser111.CdtrAdrLine         = m_Hvsndlist.m_cdtaddr;
	m_cParser111.DbtrAdrLine         = m_Hvsndlist.m_dbtaddr;   
	m_cParser111.ClrMbId1             =   m_Hvsndlist.m_clrmbid1                ;//中介机构1
	m_cParser111.ClrMbId1Nm           =   m_Hvsndlist.m_clrmbid1name            ;// 中介机构1名称
	m_cParser111.ClrMbId2             =   m_Hvsndlist.m_clrmbid2                ;//中介机构2
	m_cParser111.ClrMbId2Nm           =   m_Hvsndlist.m_clrmbid2name            ;//中介机构2名称
	m_cParser111.DbtrAcctIssrNm       =   m_Hvsndlist.m_dbtrlssrnm              ;// 付款人开户行名称
	m_cParser111.CbtrAcctIssrNm       =   m_Hvsndlist.m_cdtrlssrnm              ;//收款人开户行名称
	
	int iRet = GetIsoDateTime(m_dbproc, SYS_HVPS, m_ISODateTime);
	if(RTN_SUCCESS != iRet)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
		PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
	}
	
	m_cParser111.CreDtTm             = m_ISODateTime;
	m_cParser111.CdtrAcctId          = m_Hvsndlist.m_cdtracctid;
	
	int iDepth = 0;
	string strTemp = "/H01/";
	strTemp = strTemp + m_Hvsndlist.m_rmk.c_str();
	m_cParser111.SetUstrd(iDepth++, strTemp.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iDepth[%d]", iDepth);
	
	strTemp = "/H02/";
	strTemp = strTemp + m_Hvsndlist.m_remark.c_str();
	m_cParser111.SetUstrd(iDepth++, strTemp.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iDepth[%d]", iDepth);
	
	strTemp = "/H03/";
	strTemp = strTemp + m_Hvsndlist.m_addinfo.c_str();
	m_cParser111.SetUstrd(iDepth++, strTemp.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iDepth[%d]", iDepth);
	
	strTemp = "/H04/";
	strTemp = strTemp + m_Hvsndlist.m_addinfo2.c_str();
	m_cParser111.SetUstrd(iDepth++, strTemp.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iDepth[%d]", iDepth);
	
	// 组文件头
	m_cParser111.CreateXMlHeader("HVPS",                        \
	                  m_Hvsndlist.m_workdate.c_str(), \
	                  m_Hvsndlist.m_instgdrctpty.c_str(),\
	                  m_Hvsndlist.m_instddrctpty.c_str(),\
	                  "hvps.111.001.01",              \
	                  m_sMesgId.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]",m_Hvsndlist.m_workdate.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]",m_Hvsndlist.m_instgdrctpty.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]",m_Hvsndlist.m_instddrctpty.c_str());
	
	if("A105" == m_Hvsndlist.m_ctgypurpprtry)//退汇
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "A105");
		
		GetTag2ND("/E51/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/A70/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/F40/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/H20/", m_Hvsndlist.m_ustrdstr, iDepth);
	}
	
		if("A109" == m_Hvsndlist.m_ctgypurpprtry)//委托收款
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "A109");
		
		GetTag2ND("/C0C/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/F1A/", m_Hvsndlist.m_ustrdstr, iDepth);
	}
	
		if("A110" == m_Hvsndlist.m_ctgypurpprtry)//托收承付
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "A110");
		
		GetTag2ND("/C0D/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/D38/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/D39/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/D0M/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/D0N/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/D0O/", m_Hvsndlist.m_ustrdstr, iDepth);
	}
	
	if("A111" == m_Hvsndlist.m_ctgypurpprtry)//商业汇票
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "A111");
		
		GetTag2ND("/C03/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/D15/", m_Hvsndlist.m_ustrdstr, iDepth); 
		GetTag2ND("/B18/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/B15/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/D16/", m_Hvsndlist.m_ustrdstr, iDepth);  
		GetTag2ND("/D17/", m_Hvsndlist.m_ustrdstr, iDepth); 
	
	}
	
	if("A113" == m_Hvsndlist.m_ctgypurpprtry)//跨境业务
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "A113");
		//if(("02112" == m_Hvsndlist.m_purpprtry) || ("02113" == m_Hvsndlist.m_purpprtry) || ("02114" == m_Hvsndlist.m_purpprtry) || ("02115" == m_Hvsndlist.m_purpprtry))
		//{
			GetTag2ND("/C14/", m_Hvsndlist.m_ustrdstr, iDepth);
			GetTag2ND("/F56/", m_Hvsndlist.m_ustrdstr, iDepth);
			GetTag2ND("/D63/", m_Hvsndlist.m_ustrdstr, iDepth);
			GetTag2ND("/D64/", m_Hvsndlist.m_ustrdstr, iDepth);
			GetTag2ND("/H19/", m_Hvsndlist.m_ustrdstr, iDepth);
			//__ wsh 2012-11-19 人行1.4标准新增域
			GetTag2ND("/H33/", m_Hvsndlist.m_ustrdstr, iDepth);
			GetTag2ND("/H34/", m_Hvsndlist.m_ustrdstr, iDepth);
			GetTag2ND("/H35/", m_Hvsndlist.m_ustrdstr, iDepth);
			GetTag2ND("/H36/", m_Hvsndlist.m_ustrdstr, iDepth);
			GetTag2ND("/H37/", m_Hvsndlist.m_ustrdstr, iDepth);
			GetTag2ND("/B29/", m_Hvsndlist.m_ustrdstr, iDepth);
			GetTag2ND("/H38/", m_Hvsndlist.m_ustrdstr, iDepth);
			GetTag2ND("/H39/", m_Hvsndlist.m_ustrdstr, iDepth);
			GetTag2ND("/H40/", m_Hvsndlist.m_ustrdstr, iDepth);
			GetTag2ND("/H41/", m_Hvsndlist.m_ustrdstr, iDepth);  
			GetTag2ND("/H42/", m_Hvsndlist.m_ustrdstr, iDepth); 
			GetTag2ND("/H43/", m_Hvsndlist.m_ustrdstr, iDepth); 
			GetTag2ND("/B30/", m_Hvsndlist.m_ustrdstr, iDepth); 
		//}
		
	}
	
	if("A201" == m_Hvsndlist.m_ctgypurpprtry)//支票
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "A201");
		
		GetTag2ND("/C17/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/B21/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/D30/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/D0A/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/E41/", m_Hvsndlist.m_ustrdstr, iDepth);
	}
	
	if("A202" == m_Hvsndlist.m_ctgypurpprtry)//城市商业银行汇票
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "A202");
		
		GetTag2ND("/C10/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/E15/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/F51/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/D14/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/A59/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/B11/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/B17/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/B13/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/A60/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/B12/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/B22/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/D31/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/D11/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/C19/", m_Hvsndlist.m_ustrdstr, iDepth);
		GetTag2ND("/A07/", m_Hvsndlist.m_ustrdstr, iDepth);
	} 
	
	if("A203" == m_Hvsndlist.m_ctgypurpprtry || "A204" == m_Hvsndlist.m_ctgypurpprtry)//银行汇票||银行本票
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "A203 || A204");
		
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iDepth[%d]", iDepth);
		GetTag2ND("/C03/", m_Hvsndlist.m_ustrdstr, iDepth);
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iDepth[%d]", iDepth);
		GetTag2ND("/D15/", m_Hvsndlist.m_ustrdstr, iDepth);
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iDepth[%d]", iDepth);
		GetTag2ND("/B18/", m_Hvsndlist.m_ustrdstr, iDepth);
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iDepth[%d]", iDepth);
		GetTag2ND("/B15/", m_Hvsndlist.m_ustrdstr, iDepth);
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iDepth[%d]", iDepth);
		GetTag2ND("/D16/", m_Hvsndlist.m_ustrdstr, iDepth);
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iDepth[%d]", iDepth);
		GetTag2ND("/D17/", m_Hvsndlist.m_ustrdstr, iDepth);
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iDepth[%d]", iDepth);
		GetTag2ND("/F52/", m_Hvsndlist.m_ustrdstr, iDepth);
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iDepth[%d]", iDepth);
	} 
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps111::SetData...");
	return;
}

void CSendHvps111::SetDBKey()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps111::SetDBKey...");
	
	// m_Hvsndlist.m_msgtp= "hvps.111.001.01";
	m_Hvsndlist.m_msgid = m_szMsgFlagNO; 
	m_Hvsndlist.m_instgindrctpty = m_szSndNO; 
	
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_msgid = %s", m_Hvsndlist.m_msgid.c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_instgindrctpty = %s", m_Hvsndlist.m_instgindrctpty.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps111::SetDBKey...");
	return;
}

int CSendHvps111::GetData()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps111::GetData...");
	
	SETCTX(m_Hvsndlist);
	SetDBKey();
	int iRet = m_Hvsndlist.findByPK();
	if(RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取数据失败, iRet = %d,", iRet, m_Hvsndlist.GetSqlErr());
		PMTS_ThrowException(DB_NOT_FOUND);
	}
	
	if(!m_Hvsndlist.m_endtoendid.empty())
	{
		m_sEndtoEnd = m_Hvsndlist.m_endtoendid;
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sEndtoEnd = %s", m_sEndtoEnd.c_str());
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps111::GetData...");
	return iRet;
}

int CSendHvps111::UpdateState()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps111::UpdateState...");
	
	string strNpcMsg = "";
	if(!m_Hvsndlist.write_blob(m_cParser111.m_sXMLBuff.c_str(), strNpcMsg, SYS_HVPS)){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"写大字段表出错:[%s]", m_Hvsndlist.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}

	string strSQL = "";
	strSQL += "UPDATE hv_sndexchglist t SET t.STATETIME = sysdate, t.PROCSTATE = '";
	strSQL += m_szProState;
	strSQL += "', t.MESGID = '";
	strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
	strSQL += "', t.endtoendid = '";
	strSQL += m_sEndtoEnd;
	strSQL += "', t.npcmsg='";
	strSQL += strNpcMsg;
	strSQL += "' WHERE t.MSGTP = '";
	strSQL += m_Hvsndlist.m_msgtp.c_str();
	strSQL += "' AND t.MSGID = '";
	strSQL += m_Hvsndlist.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Hvsndlist.m_instgindrctpty.c_str(); 									
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());
	
	SETCTX(m_Hvsndlist);
	int iRet = m_Hvsndlist.execsql(strSQL.c_str());
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "修改发送状态失败iRet=%d, %s", iRet, m_Hvsndlist.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}   
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps111::UpdateState...");
	return iRet;
}

int CSendHvps111::doWorkSelf()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps111::doWork...");
	
	GetData();
	
	SetData();
	
	AddSign111();
	
	int iRet = m_cParser111.CreateXml();
	if(RTN_SUCCESS != iRet)        
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CreateXml iRet=%d", iRet);
		PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
	}
	
	//3)	业务检查（客户化代码）
	//.......
	//4)	账务处理（客户化代码）
	iRet = 0;
	if(RTN_SUCCESS != iRet)        
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "ChargeMB iRet=%d", iRet);
		PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
	}
	
	strcpy(m_szProState,PR_HVBP_08); //如果业务没有排队，处理状态会是08已发送

	//5) 虚拟头寸功能
	FundSettle();
	
	UpdateState();
	
	if(strcmp(m_szProState,PR_HVBP_08) == 0)//如果处理状态为已发送，则可以将报文写MQ
	{
		AddQueue(m_cParser111.m_sXMLBuff.c_str(), m_cParser111.m_sXMLBuff.length());
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps111::doWork..."); 
	
	return RTN_SUCCESS;
}

int CSendHvps111::ChargeMB()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps111::ChargeMB...");
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps111::ChargeMB..."); 
	
	return RTN_SUCCESS;
}

int CSendHvps111::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps111::FundSettle...");

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps111::FundSettle..."); 
	
	return RTN_SUCCESS;
}


