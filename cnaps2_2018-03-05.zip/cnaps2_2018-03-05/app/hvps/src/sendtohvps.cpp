/********************************************************************
文件名：sendthvps.cpp
创建人：hdf
日  期：2011.01.14
修改人：hdf
日  期：
描  述：客户端业务往账处理主控
版  本：
Copyright (c) 2009  YLINK
********************************************************************/

//#ifdef _LINUX_
//#define SQLCA_STORAGE_CLASS extern
//#include "sqlca.h"
//#endif
#include <sqlca.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include "exception.h"
#include "pubfunc.h"
#include "configparser.h"
#include "thread.h"
#include "sendhvpswork.h"
#include "tsocket.h"
#include "connectpool.h"
#include "cfg_obj.h"
#include "logger.h"


//#include "CNAPS2hsm.h"
//#include "assist.h"


using namespace ZFPT;

#define MQ_ERR_MAX_TIMES 3

CThreadPool<CSendHvpsWork> cPool;
CConnectPool	*g_DBConnPool;
CCfgObj 		 pCfgFile;

char			g_MQmgr[256];
char			g_MqTxtPath[256];
char			g_SendQueue[128];
char			g_ReturnQueue[128];
char            g_SendCBSP[128];
int             g_IsConnCBSP;
char            g_IP[16];
int         	g_IsConnPlatm;
char			g_CfcaPfxPath[256];//pfx证书文件名
char			g_CfcaCrlPath[256];//crl证书文件名
char			g_CfcaP7bPath[256];//p7b证书文件名
char			g_CfcaKey[128];   //证书文件名key
int         	g_iCfcaSign = 0;//是否加签名或加押
char            g_SignAddr[496];

int LoadConfigFile(stuCfgInfo &CfgInfo)
{
	//注意：在这个函数内不要用trace打日志，加载时，日志没有进行初始化
	CConfigParser& cCfg = CConfigParser::getInstance();

	strcpy(CfgInfo.path, ZFPT_CFG_PATH);
    cCfg.loadConfig(CfgInfo.path);

	strncpy(CfgInfo.szXmlCtgPath, cCfg.getOption("XMLCTGPATH"), sizeof(CfgInfo.szXmlCtgPath)-1);
    strncpy(CfgInfo.szLogPath   , cCfg.getOption("LOGPATH")   , sizeof(CfgInfo.szLogPath)-1   );
    CfgInfo.iPort           = atoi(cCfg.getOption("HVPSPORT")  );
    CfgInfo.iLogLeave       = atoi(cCfg.getOption("LOGLVL")    );
	CfgInfo.dLogMaxSize     = atof(cCfg.getOption("LOGMAXSIZE"));
	
	memset(g_MQmgr     , 0x00, sizeof(g_MQmgr));
	memset(g_SendQueue , 0x00, sizeof(g_SendQueue));
	memset(g_SendQueue , 0x00, sizeof(g_SendQueue));
	memset(g_MqTxtPath , 0x00, sizeof(g_MqTxtPath));
	memset(g_ReturnQueue , 0x00, sizeof(g_ReturnQueue));	
	memset(g_CfcaPfxPath , 0x00, sizeof(g_CfcaPfxPath));
	memset(g_CfcaCrlPath , 0x00, sizeof(g_CfcaCrlPath));
	memset(g_CfcaP7bPath , 0x00, sizeof(g_CfcaP7bPath));
	memset(g_CfcaKey     , 0x00, sizeof(g_CfcaKey));
  memset(g_SignAddr , 0x00, sizeof(g_SignAddr));
  
  strncpy(g_SignAddr, cCfg.getOption("SIGNADDR"), sizeof(g_SignAddr)-1);		
	strncpy(g_MQmgr    , cCfg.getOption("MQMGR")     , sizeof(g_MQmgr)-1    );
    strncpy(g_SendQueue, cCfg.getOption("HVPSSENDMQ"), sizeof(g_SendQueue)-1);
    //strncpy(g_SendQueue, cCfg.getOption("HVPSYALIMQ"), sizeof(g_SendQueue)-1);
    strncpy(g_MqTxtPath, cCfg.getOption("MQTEXTPATH"), sizeof(g_MqTxtPath)-1);   
    strncpy(g_ReturnQueue, cCfg.getOption("CLTRECVRETN"), sizeof(g_ReturnQueue)-1);   
    strncpy(g_CfcaPfxPath, cCfg.getOption("CFCAPFX"), sizeof(g_CfcaPfxPath)-1);
    strncpy(g_CfcaCrlPath, cCfg.getOption("CFCACRL"), sizeof(g_CfcaCrlPath)-1);
    strncpy(g_CfcaP7bPath, cCfg.getOption("CFCAP7B"), sizeof(g_CfcaP7bPath)-1);
    strncpy(g_CfcaKey    , cCfg.getOption("CFCAKEY"), sizeof(g_CfcaKey)-1);
    
    strncpy(CfgInfo.szCltSendMQ  , cCfg.getOption("CLTSENDHVPS"), sizeof(CfgInfo.szCltSendMQ  )-1);

	CfgInfo.iConPoolMinNum          = atoi(cCfg.getOption("HVCONNPOOLMINSIZE")   );
	CfgInfo.iConPoolMaxNum          = atoi(cCfg.getOption("HVCONNPOOLMAXSIZE")   );
	CfgInfo.iNoConWaitTime	        = atoi(cCfg.getOption("HVNOCONNWAITTIME")    );
	CfgInfo.iConPoolSize            = atoi(cCfg.getOption("HVCONNPOOLSIZE")      );
	CfgInfo.iThreadPoolSize         = atoi(cCfg.getOption("HVTHREADPOOLSIZE")    );
	CfgInfo.iThreadPoolTaskSize     = atoi(cCfg.getOption("HVTHREADPOOLTASKSIZE"));
	
    strncpy(CfgInfo.DBUser, cCfg.getOption("DBUSER"), sizeof(CfgInfo.DBUser)-1);
    //alter in 20171130
    CfgInfo.iDBKeyType = atoi(cCfg.getOption("DBKEYTYPE"));
    if (CfgInfo.iDBKeyType == 1) //密码为明文
    {
				strncpy(CfgInfo.DBKey, cCfg.getOption("DBKEY"), sizeof(CfgInfo.DBKey)-1);
    }
    if (CfgInfo.iDBKeyType == 0) //密码为密文
    {
				CfgInfo.DBKey_new.Format("%s", cCfg.getOption("DBKEY"));
				DecodeDBPsw(CfgInfo.DBKey_new);
				strncpy(CfgInfo.DBKey, CfgInfo.DBKey_new.GetBuffer(0), sizeof(CfgInfo.DBKey)-1);
    }
    //alter end
    strncpy(CfgInfo.DBName, cCfg.getOption("DBNAME"), sizeof(CfgInfo.DBName)-1);

    strncpy(CfgInfo.szMqServConn  , cCfg.getOption("MQSERVCONN")  , sizeof(CfgInfo.szMqServConn) - 1  );
    strncpy(CfgInfo.szPmInfoHdFlg1, cCfg.getOption("PMINFOHDFLG1"), sizeof(CfgInfo.szPmInfoHdFlg1) - 1);
    strncpy(CfgInfo.szPmInfoHdFlg2, cCfg.getOption("PMINFOHDFLG2"), sizeof(CfgInfo.szPmInfoHdFlg2) - 1);
    strncpy(CfgInfo.szCbspRecvMQ  , cCfg.getOption("CBSPRECVMQ")  , sizeof(CfgInfo.szCbspRecvMQ) - 1  );    
    strncpy(g_SendCBSP, CfgInfo.szCbspRecvMQ, sizeof(g_SendCBSP)-1);
    
    CfgInfo.iMqListener         = atoi(cCfg.getOption("MQLISTENER"));
    CfgInfo.iConnPlatm          = atoi(cCfg.getOption("ISCONNPLATM"));    
	g_IsConnCBSP   = CfgInfo.iConnPlatm;	
	g_IsConnPlatm  = CfgInfo.iConnPlatm;
	
	//g_iCfcaSign = atoi(cCfg.getOption("CERTSIGN"));
	g_iCfcaSign = 0;
	
    return OPERACT_SUCCESS;
}


void SigLoad()
{
	unsigned char pReturnCode;
	unsigned char ucMacAlgFlag='1';
	unsigned int uiIndex = 511;
	unsigned int uiTextLen = 128;
	unsigned char pucText[512 + 1] = {0};
	unsigned char pucMax[20] = {0};
	
	strcpy((char *)pucText, "KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK");
	//uiTextLen = strlen((char *)pucText);    	
	
	//CNAPS2_GenerateMac_ByKeyIndex(&pReturnCode, ucMacAlgFlag, uiIndex, uiTextLen, pucText, pucMax);
	
	if(pReturnCode == 0x00)
	{
//			Trace(L_INFO, __FILE__, __LINE__, NULL, "加押成功。");
//			strcpy(pMacStr, MbBinToHex(pucMax, strlen((char *)pucMax)).c_str());
//			iRet = 0;
		
		printf("加押成功\n");
	}
	else
	{
//			Trace(L_ERROR, __FILE__, __LINE__, NULL, "加押失败，错误代码[%02x]", ucReturnCode);
//			sprintf((char *)pucMax, "加押失败, 错误代码=[%02x]", ucReturnCode);
//			strcpy(pMacStr, (char *)pucMax);
//			iRet = -1;
		printf("加押失败，错误代码[%02x]\n", pReturnCode);
		printf("pucMax=[%s]\n", pucMax);
	}
}


int main(int argc, char * argv[])
{
	SigLoad();
	
    char sErrDesc[1024 + 1] = {0};
    int iRet                =  0 ;
    stuCfgInfo           CfgInfo ;
    string strErr;
    MQAgent              cAgent;
    
    memset(g_IP, 0x00, sizeof(g_IP));
    
	//初始化全局参数
	signal(SIGINT , SIG_IGN);							//屏蔽中断信号
	signal(SIGQUIT, SIG_IGN);							//屏蔽终端退出信号
	signal(SIGALRM, SIG_IGN);							//屏蔽超时信号
	signal(SIGHUP , SIG_IGN);							//屏蔽连接断开信号
	signal(SIGSTOP, SIG_IGN); 							//这些信号被忽略
	//signal(SIGCHLD, SIG_IGN);
    
    try
    {
    	//初始化配置文件    
		LoadConfigFile(CfgInfo);    
  
		//初始化日志
		ZFPTLOG.setCfgInfo(CfgInfo.szLogPath, "sendtohvps", CfgInfo.iLogLeave, CfgInfo.dLogMaxSize);
    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化日志...");	

        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "g_IsConnCBSP=%d",  g_IsConnCBSP);
        
		//获取本机ip
        char* IP = GetLocalIp();
        if(IP != NULL)
        {
            strncpy(g_IP, IP, sizeof(g_IP)-1);
        }
        else
        {
            strErr = "获取本机IP失败,与平台连接标志重新设置为断开状态,并且不向平台发送错误日志";
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, strErr.c_str());
            g_IsConnCBSP = 0;
        }
		
		//初始化XML配置文件		    	
		iRet = pCfgFile.Init(CfgInfo.szXmlCtgPath);  
		if(iRet != 0)
		{
		    sprintf(sErrDesc, "Failed to Init the node Config Object: ErrCode = %d, ErrInfo = %s", pCfgFile.GetLastErrCode(),pCfgFile.GetLastErrInfo());
	    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);
			exit(0);
		}
		
		//初始化MQ 
        if(cAgent.Init(g_MQmgr, g_MqTxtPath) != RTN_SUCCESS)
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Init MQ manager failed.");
            exit(0);
        }
        
        //创建连接池 
         g_DBConnPool = new CConnectPool(CfgInfo.iConPoolMinNum,CfgInfo.iConPoolMaxNum, CfgInfo.iNoConWaitTime);

        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化连接池...");	    
	    
        iRet= g_DBConnPool->InitPool(CfgInfo.iConPoolSize,CfgInfo.DBUser,CfgInfo.DBKey,CfgInfo.DBName);
        
        if(iRet == RTN_SUCCESS)
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "连接池创建成功");
        }
        else
        {
            strErr = "连接池创建失败";
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, strErr.c_str());
            exit(0);
        }

        cPool.start(CfgInfo.iThreadPoolSize,CfgInfo.iThreadPoolTaskSize);
        
    }
    catch(CException &e)
    {
    	sprintf(sErrDesc, "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());
    	DELPOINT_VOID(g_DBConnPool);
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);
        exit(0);
    }
    
    bool        IsHasMsg              = false; //是否读到了消息
    int         iErrMsgFlag           = 0 ;
    int         iErrTimes             = 0 ;
    STRING      sMsg                  = "";    //MQ报文
    STRING      sFile                 = "";    //MQ收到的文件名称
    char        szMQMsgID[64];    //MQ消息ID
    DBProc      m_dbproc;
    
    //获取MQ中消息报文
    while(true)
    {
        try
        {
            IsHasMsg  = false;
            sMsg      = "";
            sFile     = "";	
            memset(szMQMsgID, 0x00, sizeof(szMQMsgID));
                    
			
            //从实时队列中读取消息
            iErrMsgFlag = 0;
			iRet = cAgent.GetMsg(CfgInfo.szCltSendMQ, sMsg, sFile, iErrMsgFlag,GET_MQMSG_MAXTIME);
            if(0 == iRet)
            {		
                //读到消息
                cAgent.Commit();
                iErrTimes = 0;
                IsHasMsg = true;            
                
               	memcpy(szMQMsgID, cAgent.GetMsgId(), sizeof(szMQMsgID)-1);
               	
//               	char szTemp[512] = {0};
//				for (int j = 0; j < 24; j++)
//				{
//					sprintf((char *)&szTemp[j*2], "%02x", szMQMsgID[j]^0);
//				}
		
//				Trace(L_INFO, __FILE__, __LINE__, NULL, "szTemp=[%s]", szTemp);

                string strtest = MbBinToHex((unsigned char* )szMQMsgID,24);
                
                Trace(L_INFO,  __FILE__,  __LINE__, NULL, "收到交易:[%s]", sMsg.c_str());
                Trace(L_INFO,  __FILE__,  __LINE__, NULL, "unchange:szMQMsgID=[%s]", szMQMsgID);
                Trace(L_INFO,  __FILE__,  __LINE__, NULL, "changed:szMQMsgID=[%s]", strtest.c_str());
                
                CSendHvpsWork CSendHvpsWork;
            	memcpy(CSendHvpsWork.m_MQMsgId ,szMQMsgID, sizeof(szMQMsgID));            	
            	CSendHvpsWork.UnpackMsgHead(sMsg.c_str());
            
            	while(JOBPOOL_FULL == (iRet = cPool.push(CSendHvpsWork)))
            	{
            	    printf("任务满,等待5秒!");
            	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "任务满,等待5秒");
            	    sleep(5);
            	}
            	
                if(0 == iRet)
                {
                    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "添加任务成功");
                }
            }
            else if (1 == iRet)
            {            
                IsHasMsg =false;
            }
            else if(-1 == iRet)
            {   
            	//读取消息失败
                iErrTimes++;
				
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Get MQ message failed:[%s]", CfgInfo.szCltSendMQ);
    			
                if(iErrTimes >= MQ_ERR_MAX_TIMES) 
                {
                    break;
                }
            }
			
            if(!IsHasMsg)
            {
                usleep(1000);
                continue;		
            }
        }
        catch(CException &e)
        {
            sprintf(sErrDesc, "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);
            sleep(3);
        }
    }

	DELPOINT_VOID(g_DBConnPool);
	
    return 0;
}

