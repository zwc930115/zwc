#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include "exception.h"
#include "connectpool.h"
#include "configparser.h"
#include "logger.h"
#include "thread.h"
#include "recvhvpswork.h"
#include "pubfunc.h"
#include "hvrecvmsg.h"
#include "cfg_obj.h"

CConnectPool *g_DBConnPool;
int InsertRecvMsg(DBProc &dbProc, const char *pchMsg, const char *pchMsgID);
int main(int argc, char **argv)
{
    DBProc      dbproc;                        //����	
    string      sBizCode              = "";    //������

	
    signal(SIGINT , SIG_IGN);							//�����ж��ź�
    signal(SIGQUIT, SIG_IGN);							//�����ն��˳��ź�
    signal(SIGALRM, SIG_IGN);							//���γ�ʱ�ź�
    signal(SIGHUP , SIG_IGN);							//�������ӶϿ��ź�
    signal(SIGSTOP, SIG_IGN);							//��Щ�źű�����
    //signal(SIGCHLD, SIG_IGN);
	

		
    //�������ӳ� 
    g_DBConnPool = new CConnectPool(1,3,1);
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "��ʼ�����ӳ�...");
    
    int iRet= g_DBConnPool->InitPool(2,"cnaps2","cnaps2","ORCL");	
    
    
    // ��ȡ���ӳ�	
    if(0 != g_DBConnPool->GetConnect(dbproc))
    {					
        exit(0);
    }
    


    iRet = InsertRecvMsg(dbproc, "nihaohahahaha", "123455");
    if (0 != iRet)
    {
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "insert error");
    }


    g_DBConnPool->PutConnect(dbproc);

    return 0;
}


int InsertRecvMsg(DBProc &dbProc, const char *pchMsg, const char *pchMsgID)
{

    
    CHvrecvmsg cHvrecvmsg(dbProc);

    cHvrecvmsg.m_msgtext   = pchMsg;
    cHvrecvmsg.m_msgid     = pchMsgID;
    cHvrecvmsg.m_procstate = "03";
    cHvrecvmsg.m_wrkdate   = "20120326";
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "cHvrecvmsg.m_msgid = %s", (cHvrecvmsg.m_msgid).c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "cHvrecvmsg.m_wrkdate = %s", (cHvrecvmsg.m_wrkdate).c_str());

    int iRet = cHvrecvmsg.insert();
    if (0 == iRet)
    {
        cHvrecvmsg.commit();
    }
    else
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "pRecvmsg insert ʧ��[%d][%s]",
            iRet, cHvrecvmsg.GetSqlErr());
        cHvrecvmsg.rollback();
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving InsertRecvMsg");
    return iRet;
}


