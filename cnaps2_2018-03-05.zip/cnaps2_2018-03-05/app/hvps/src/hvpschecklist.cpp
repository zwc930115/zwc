/********************************************************************
文件名： hvpsckecklist.cpp
创建人： hq
日  期： 2011-05-16
修改人： 
日  期： 
描  述： 大额明细对账类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/  

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "hvpschecklist.h"
#include "exception.h"
#include "logger.h"
#include "pubfunc.h"
#include "hvsndexchglist.h"
#include "hvsndexchglisthis.h"
#include "hvrcvexchglist.h"
#include "hvrcvexchglisthis.h"
#include "hvtrofacrcvlist.h"
#include "hvtrofacrcvlisthis.h"
#include "cmtransinfoqry.h"
#include "hvmnetstlntc.h"
#include "cmcheckqry.h"


using namespace ZFPT;

CHvpsCheckList::CHvpsCheckList()
{
    m_iTtlCnt        = 0;
    m_szChkDt        = "";
    m_szBkCode       = "";
    m_sCycleDigntr   = "";
    m_bSndExChgList  = false;
    m_bRcvExChgList  = false;
    m_bSndTroFacList = false;
    m_bRcvTroFacList = false;
    m_bTransInfoQry  = false;
}

CHvpsCheckList::~CHvpsCheckList()
{
    
}

void CHvpsCheckList::doCheckListWork(DBProc &dbProc,
                                 int iChkTp, 
                                 LPCSTR sChkDt, 
                                 LPCSTR sBankCode, 
                                 MQAgent &cMQAgent, 
                                 LPCSTR sSendQueue)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsCheckList::doCheckListWork()");

    // 说明；明细对账类型:0收713调用，1其他调用
    
    m_szChkDt     = sChkDt;
    m_szBkCode    = sBankCode;
    m_dbproc.pCtx = dbProc.pCtx;

    // 设置连接
    SetAllCtx();

    // 统计报文类型
    if (1 == iChkTp)
    {
    	//CountMsgTp();
	}
	
	
	
	
	
    // 更新大额明细核对表和业务表的状态
	UpdateState();
	
	//查询本地多的情况
	FindLocalMore();

	// 判断对账是否相符
	IsSend714(cMQAgent, sSendQueue);
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsCheckList::doCheckListWork()");
}

void CHvpsCheckList::FindLocalMore()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsCheckList::FindLocalMore()"); 
//该函数在所有往来表中查询对账日期对应的所有业务，只要没有对账状态的则认为是本地多
//将本地多的数据插入明细核对表中
	CHvsndexchglist hvsndlist;
	CHvsndexchglisthis hvsndlisthis;
	CHvrcvexchglist hvrcvlist;
	CHvrcvexchglisthis hvrcvlisthis;
	CHvtrofacrcvlist hvtrolist;
	CHvtrofacrcvlisthis hvtrolisthis;
	CHvmnetstlntc hvmnetstlntc;
	CCmtransinfoqry cmtransinfoqry;

	SETCTX(hvsndlist);
	SETCTX(hvrcvlist);
	SETCTX(hvtrolist);
	SETCTX(hvmnetstlntc);
	SETCTX(cmtransinfoqry);
	SETCTX(hvsndlisthis);
	SETCTX(hvrcvlisthis);
	SETCTX(hvtrolisthis);

	int iRet = -1;

	string hvstat = " AND BUSISTATE IN('PR04','PR09','PR08')";//已清算，已拒绝，已撤销
	string cmstat = " AND BUSISTATE IN('PR00','PR09')";// 已拒绝，已转发

	/*往来报字段不同，所以先组织好SQL*/
	string strSqlsndhv = "(CHECKSTATE IS NULL OR CHECKSTATE = '05') AND FINALSTATEDATE ='";
	strSqlsndhv += m_szChkDt;
	strSqlsndhv += "' AND INSTGDRCTPTY = '";
	strSqlsndhv += m_szBkCode;
	strSqlsndhv += "'";
	strSqlsndhv += hvstat;

	string strSqlrcvhv = "(CHECKSTATE IS NULL OR CHECKSTATE = '05') AND FINALSTATEDATE ='";
	strSqlrcvhv += m_szChkDt;
	strSqlrcvhv += "' AND INSTDDRCTPTY = '";
	strSqlrcvhv += m_szBkCode;
	strSqlrcvhv += "'";
	strSqlrcvhv += hvstat;

	char tmp[256] = {0};
	chgToDate(m_szChkDt.c_str(), tmp);
	
	string strSqlsndcm = "(CHECKSTATE IS NULL OR CHECKSTATE = '05' OR CHECKSTATE = '00') AND SYSID = 'HVPS' AND CONSIGNDATE ='";
	strSqlsndcm += tmp;
	strSqlsndcm += "' AND RSFLAG <> '2' AND INSTGDRCTPTY = '";
	strSqlsndcm += m_szBkCode;
	strSqlsndcm += "'";
	strSqlsndcm += cmstat;

	string strSqlrcvcm = "(CHECKSTATE IS NULL OR CHECKSTATE = '05' OR CHECKSTATE = '00') AND SYSID = 'HVPS' AND CONSIGNDATE ='";
	strSqlrcvcm += tmp;
	strSqlrcvcm += "' AND RSFLAG = '2' AND INSTDDRCTPTY = '";
	strSqlrcvcm += m_szBkCode;
	strSqlrcvcm += "'";
	strSqlrcvcm += cmstat;
	
	string strSqlrcvmnetstlntc = "(CHECKSTATE IS NULL OR CHECKSTATE = '05' OR CHECKSTATE = '00') AND STTLMDT ='";
	strSqlsndhv += m_szChkDt;
	strSqlsndhv += "' AND INSTGDRCTPTY = '";
	strSqlsndhv += m_szBkCode;
	strSqlsndhv += "'";
	strSqlsndhv += " AND NPCPRCSTS IN('PR04','PR09','PR08')";

	char szErrMsg[1024] = {0};
	
  Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSqlsndhv[%s]",  strSqlsndhv.c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSqlrcvhv[%s]",  strSqlrcvhv.c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSqlsndcm[%s]",  strSqlsndcm.c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSqlrcvcm[%s]",  strSqlrcvcm.c_str());

	#define _FindMore(tablename, sqlstr, ctgypurpprtry, sndrcvtp, procsts, amt, ccy) \
	{ \
		if(SQL_SUCCESS == tablename.find(sqlstr)) \
		{\
			while(SQL_SUCCESS == tablename.fetch())\
			{\
				InsertLocalMore(tablename.m_msgtp.c_str(),\
								tablename.m_msgid.c_str(),\
								tablename.m_instgindrctpty.c_str(),\
								ctgypurpprtry,\
								sndrcvtp,\
								procsts,\
								ccy,\
								amt );\
				\
				tablename.m_checkstate = PR_CNCH_05;\
				iRet = tablename.updatestate();\
				if(OPERACT_SUCCESS != iRet)\
				{\
					sprintf(szErrMsg, "updatestate fail:  [%d][%s]", \
					 iRet, tablename.GetSqlErr());\
					Trace(L_ERROR,  __FILE__,	__LINE__, NULL, szErrMsg);\
					PMTS_ThrowException(DB_GET_DATA_FAIL);\
				}\
			}\
			tablename.closeCursor();\
		}\
	}

	_FindMore(hvsndlist, strSqlsndhv, hvsndlist.m_ctgypurpprtry.c_str(), "SR00", hvsndlist.m_busistate.c_str(), hvsndlist.m_amount, hvsndlist.m_currency.c_str() );
	//_FindMore(hvsndlisthis, strSqlsndhv, hvsndlisthis.m_ctgypurpprtry.c_str(), "SR00", hvsndlisthis.m_busistate.c_str(), hvsndlisthis.m_amount, hvsndlisthis.m_currency.c_str() );
	_FindMore(hvrcvlist, strSqlrcvhv, hvrcvlist.m_ctgypurpprtry.c_str(), "SR01", hvrcvlist.m_busistate.c_str(), hvrcvlist.m_amount, hvrcvlist.m_currency.c_str() );
	//_FindMore(hvrcvlisthis, strSqlrcvhv, hvrcvlisthis.m_ctgypurpprtry.c_str(), "SR01", hvrcvlisthis.m_busistate.c_str(), hvrcvlisthis.m_amount, hvrcvlisthis.m_currency.c_str() );
	_FindMore(hvtrolist, strSqlrcvhv, hvtrolist.m_ctgypurpprtry.c_str(), "SR01", hvtrolist.m_busistate.c_str(), hvtrolist.m_amount, hvtrolist.m_currency.c_str() );
	//_FindMore(hvtrolisthis, strSqlrcvhv, hvtrolisthis.m_ctgypurpprtry.c_str(), "SR01", hvtrolisthis.m_busistate.c_str(), hvtrolisthis.m_amount, hvtrolisthis.m_currency.c_str() );
	_FindMore(cmtransinfoqry, strSqlsndcm, "K100", "SR00", cmtransinfoqry.m_busistate.c_str(), 0.00, "CNY" );
	_FindMore(cmtransinfoqry, strSqlrcvcm, "K100", "SR01", cmtransinfoqry.m_busistate.c_str(), 0.00, "CNY" );
	_FindMore(hvmnetstlntc, strSqlrcvmnetstlntc, hvmnetstlntc.m_txtp.c_str(), "SR01", hvmnetstlntc.m_npcprcsts.c_str(), hvmnetstlntc.m_amt, hvmnetstlntc.m_currency.c_str() );
		
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsCheckList::FindLocalMore()"); 
}

void CHvpsCheckList::InsertLocalMore(LPCSTR orgnlmsgtp,
									 LPCSTR orgnlmsgid,
									 LPCSTR orgnlinstgpty,
									 LPCSTR txtpcd,
									 LPCSTR sndrcvtp,
									 LPCSTR prcsts,
									 LPCSTR ccy,
									 double amt )
{
	string ctgy = txtpcd;
	if( NULL != strstr(orgnlmsgtp, "CMT") 	 || 
		  NULL != strstr(orgnlmsgtp, "CMT302") || 
		  NULL != strstr(orgnlmsgtp, "CMT301") || 
		  NULL != strstr(orgnlmsgtp, "314")    || 
		  NULL != strstr(orgnlmsgtp, "315")     )
	{
		if( NULL != strstr(orgnlmsgtp, "CMT302") || 
		  	NULL != strstr(orgnlmsgtp, "315") )
		{
			ctgy = "K101";
		}
		else if( NULL != strstr(orgnlmsgtp, "314")    || 
						 NULL != strstr(orgnlmsgtp, "CMT301")  )
		{
			ctgy = "K100";
		}
		else
		{
			ctgy = orgnlmsgtp;
		}
	}
	m_hvchklstlist.m_chckdt = m_szChkDt;
	m_hvchklstlist.m_checkstate = PR_CNCH_05;
	m_hvchklstlist.m_dtltxtpcd = ctgy;
	m_hvchklstlist.m_instddrctpty = m_szBkCode;
	m_hvchklstlist.m_instgdrctpty = "1111";//人行下发的发起行号是"0000",为表示区别这里赋值"1111"
	m_hvchklstlist.m_isdownload = "1";
	m_hvchklstlist.m_msgtype = orgnlmsgtp;
	m_hvchklstlist.m_orgnlamount = amt;
	m_hvchklstlist.m_orgnlccy = ccy;
	m_hvchklstlist.m_orgnlinstgdrpty = orgnlinstgpty;
	m_hvchklstlist.m_orgnlmsgid = orgnlmsgid;
	m_hvchklstlist.m_orgnlmsgtp = orgnlmsgtp;
	m_hvchklstlist.m_prcsts = prcsts;
	m_hvchklstlist.m_sndrcvtp = sndrcvtp;
	//m_hvchklstlist.m_stattime
	//m_hvchklstlist.m_workdate = m_sWorkDate;

	
	//1、设置连接
	SETCTX(m_hvchklstlist);

	//2、新增数据库
	int iRet = m_hvchklstlist.insert();
	
	if (0 != iRet)
	{
		char szErrMsg[1024] = {0};
		sprintf(szErrMsg,"insert error,error code = [%d] error cause =[%s]",iRet,m_hvchklstlist.GetSqlErr());
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, szErrMsg);
	}
	
	m_hvchklstlist.commit();
}


void CHvpsCheckList::IsSend714(MQAgent &cMQAgent, LPCSTR sSendQueue)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsCheckList::IsSend714()"); 

    int iRet      = -1;
    int iCount714 = 0;
    int iCount    = 0;
    
    STRING szFindSql = "";

    // 查询条件:对账日期+行号+状态为"本地少"
    szFindSql = " SNDRCVTP = 'SR01' AND CHCKDT = '";
    szFindSql += m_szChkDt;
    szFindSql += "' and INSTDDRCTPTY = '";
    szFindSql += m_szBkCode;
    szFindSql += "' and CHECKSTATE ='";
    szFindSql += PR_CNCH_04;
    szFindSql += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "szFindSql=[%s]", szFindSql.c_str());

    iRet = m_hvchklstlist.find(szFindSql);
    if (SQL_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "查询HV_CHKLSTLIST表失败[%d][%s]", 
            iRet, m_hvchklstlist.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "查询HV_CHKLSTLIST表失败");
    }

    while(SQL_SUCCESS == iRet)
    {
    	iRet = m_hvchklstlist.fetch();
      	if (SQLNOTFOUND == iRet) 
    	{
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "*****Checklist account is over*****");
            m_hvchklstlist.closeCursor();
            break;
    	}
    	else if (SQL_SUCCESS != iRet) 
    	{
            Trace(L_ERROR, __FILE__, __LINE__, NULL, "查询HV_CHKLSTLIST表失败[%d][%s]", 
                iRet, m_hvchklstlist.GetSqlErr());

            m_hvchklstlist.closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "查询HV_CHKLSTLIST表失败");
    	}

        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "msgtp[%s],sndflag[%s],msgid[%s],bank[%s]", 
              m_hvchklstlist.m_orgnlmsgtp.c_str(),m_hvchklstlist.m_sndrcvtp.c_str(),
              m_hvchklstlist.m_orgnlmsgid.c_str(),m_hvchklstlist.m_orgnlinstgdrpty.c_str());

        
        iCount714++;
        m_iTtlCnt++;
        
    	//组714中的循环部分
        AddDetail714();

        //714报文中，最多包含1000笔明细,满1000笔，就发送
        if(0 == iCount714%1000)
        {   
        	CreateHvps714(cMQAgent, sSendQueue);
        	m_iTtlCnt = 0;
        	m_hvps714.m_pXMLProc.Reset();
        	m_hvps714.Init(); //多次发送必需INIT()
        	m_sCycleDigntr = "";
        }
        
    }
 
    m_hvchklstlist.closeCursor();

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "对账不符笔数[%d]下载明细笔数[%d]", iCount, iCount714); 
    
	// 如果不平，发送714报文下载明细
    if ( 0 < iCount714 )
    {
        // 更新与中心对账表中的状态为"25：需要下载明细"
		updateBkChkSt(PR_CNCH_25);
		
        // 组大额业务下载申请报文,并发送
        if(0 != iCount714%1000)
        {
            CreateHvps714(cMQAgent, sSendQueue);
        }
    }
    else
    {
    	 //如果没有，将状态更新为23 明细核对完成
    	updateBkChkSt(PR_CNCH_23);
    }
    // 如果平，进行汇总核对
    /*
    else 
    {
        m_hvchecksum.doCheckSumWork(m_dbproc, 
	                            1, 
	                            m_szChkDt.c_str(),
	                            m_szBkCode.c_str(),
	                            cMQAgent,
	                            sSendQueue);
    }
    */
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsCheckList::IsSend714()");
}

void CHvpsCheckList::AddDetail714()
{
    string strCDFLAG = "";
    
    if(NULL != strstr(m_hvps714.OrgnlMT.c_str(),"hvps.141") ||
       NULL != strstr(m_hvps714.OrgnlMT.c_str(),"CMT232")  )
    {
        strCDFLAG = m_hvchklstlist.m_sndrcvtp; 
   		m_hvchklstlist.m_sndrcvtp = "SR01";
    }
    
    m_hvps714.AddNodeToSubcycle("SndRcvTp"      , m_hvchklstlist.m_sndrcvtp.c_str());
    m_hvps714.AddNodeToSubcycle("OrgnlMsgId"    , m_hvchklstlist.m_orgnlmsgid.c_str());
    m_hvps714.AddNodeToSubcycle("OrgnlInstgPty" , m_hvchklstlist.m_orgnlinstgdrpty.c_str());
    m_hvps714.AddNodeToSubcycle("OrgnlMT"       , m_hvchklstlist.m_orgnlmsgtp.c_str());
    if(NULL != strstr(m_hvchklstlist.m_orgnlmsgtp.c_str(),"hvps.141") ||
       NULL != strstr(m_hvchklstlist.m_orgnlmsgtp.c_str(),"CMT232") )
    {
        m_hvps714.AddNodeToSubcycle("DbtCdtId"       , strCDFLAG.c_str());
    }
    m_hvps714.AddSubcycleToNode("TxsDtls");   
    //modify  by luna 20120517原加签有误不采用,暂不考虑借贷标志
    m_hvps714.SndRcvTp          =     m_hvchklstlist.m_sndrcvtp.c_str();
    m_hvps714.OrgnlMsgId        =     m_hvchklstlist.m_orgnlmsgid.c_str();
    m_hvps714.OrgnlInstgPty     =   m_hvchklstlist.m_orgnlinstgdrpty.c_str();
    m_hvps714.OrgnlMT          =   m_hvchklstlist.m_orgnlmsgtp.c_str();
    if(NULL != strstr(m_hvchklstlist.m_orgnlmsgtp.c_str(),"hvps.141") ||
       NULL != strstr(m_hvchklstlist.m_orgnlmsgtp.c_str(),"CMT232") )
    {
        m_hvps714.DbtCdtId        =  strCDFLAG.c_str(); 
    }
    
    m_hvps714.getTxsDtls();
    
    m_sCycleDigntr += Trim(m_hvchklstlist.m_sndrcvtp) + "|";
    m_sCycleDigntr += Trim(m_hvchklstlist.m_orgnlmsgid) + "|";
    m_sCycleDigntr += Trim(m_hvchklstlist.m_orgnlinstgdrpty) + "|";
    m_sCycleDigntr += Trim(m_hvchklstlist.m_orgnlmsgtp) + "|";
    if(NULL != strstr(m_hvchklstlist.m_orgnlmsgtp.c_str(),"hvps.141") ||
       NULL != strstr(m_hvchklstlist.m_orgnlmsgtp.c_str(),"CMT232") )
    {
        m_sCycleDigntr += Trim(strCDFLAG) + "|";
    }
}

void CHvpsCheckList::updateBkChkSt(LPCSTR _sChkSt)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CHvpsCheckList::updateBkChkSt()");

    int iRet = -1;
    
    iRet = m_checkaccount.upHvBkChkSt(m_szBkCode.c_str(), m_szChkDt.c_str(), _sChkSt);
    if ( iRet != SQL_SUCCESS )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "更新HV_BKCHKST表失败[%d][%s]", 
            iRet, m_checkaccount.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "更新HV_BKCHKST表失败");
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CHvpsCheckList::updateBkChkSt()");
}

void CHvpsCheckList::CreateHvps714(MQAgent &cMQAgent, LPCSTR sSendQueue)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsCheckList::CreateHvps714()");

    char sBankNo[14 + 1] = {0};
    char sMesgId[20 + 1] = {0};
    char sMsgId[35 + 1] = {0};
    char sISODateTime[19 + 1] = {0};
    char sTemp[128 + 1] = {0};
    int  iRet = -1;
    char sSignedStr[4096 + 1]    = {0};
    string szDgtSgntr = "";
    char sChkDt[8 + 1] = {0};
	
    strncpy(sBankNo, m_szBkCode.c_str(), sizeof(sBankNo) - 1);
    
    // 报文头赋值
    if ( !GetMsgIdValue(m_dbproc, sMesgId, eRefId,  SYS_HVPS, sBankNo) )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "取报文参考号失败");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_SYS_PARA_FAIL, "取报文参考号失败");
    }
    chgToDate(m_szChkDt.c_str(),sChkDt);
    m_hvps714.CreateXMlHeader("HVPS",
                              sChkDt,
                              m_szBkCode.c_str(),
                              "0000",
                              "hvps.714.001.01",
                              sMesgId);
                              
    // 报文体赋值
    if ( !GetMsgIdValue(m_dbproc, sMsgId, eMsgId,  SYS_HVPS, sBankNo) )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "取报文标识号失败");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_SYS_PARA_FAIL, "取报文标识号失败");
    }
    GetIsoDateTime(m_dbproc, SYS_HVPS, sISODateTime);
    
    m_hvps714.MsgId           = sMsgId;         //报文标识号
    m_hvps714.CreDtTm         = sISODateTime;   //报文发送时间
    m_hvps714.InstgDrctPty    = m_szBkCode;     //发起直接参与机构
    m_hvps714.GrpHdrInstgPty  = m_szBkCode;     //发起参与机构
    m_hvps714.InstdDrctPty    = "0000"; //接收直接参与机构
    m_hvps714.GrpHdrInstdPty  = "0000"; //接收参与机构
    m_hvps714.SysCd           = "HVPS";         //系统编号

    sprintf(sTemp, "%d", m_iTtlCnt);
    m_hvps714.NbOfTxs         = sTemp;          //明细数目
      //luna 20120517 
    m_hvps714.getOriSignStr();
    // 加签
    szDgtSgntr = m_hvps714.m_sSignBuff;

    char *sOrigenStr = new char[szDgtSgntr.length() + 1];
    strcpy(sOrigenStr, szDgtSgntr.c_str());
	
	signTrim(sOrigenStr);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sOrigenStr=[%s]", sOrigenStr);
	
    iRet = digitSign(m_dbproc, sOrigenStr, sSignedStr, SYS_HVPS, RAWSIGN, m_szBkCode.c_str());
	if ( RTN_SUCCESS != iRet)
	{ 
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "714加签失败[%d]", iRet);
        //测试时，暂时不抛异常
		//PMTS_ThrowException(__FILE__, __LINE__, OPT_DIGITSIGN_FAIL, "714加签失败");
	}
    m_hvps714.m_szDigitSign = sSignedStr;
    
    // 组报文
    iRet = m_hvps714.CreateXml();
    if (0 != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "组714报文失败[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, "组714报文失败");    
    }

	CMcheckqry m_checkqry;
	m_checkqry.m_msgid = m_hvps714.MsgId;
	m_checkqry.m_msgtype = "hvps.714.001.01";
	m_checkqry.m_sapbank = m_hvps714.InstgDrctPty;
	m_checkqry.m_checkdate = m_szChkDt;

	SETCTX(m_checkqry);
	iRet = m_checkqry.insert();
	if( 0 != iRet)
	{
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "INSERT CM_CHECKQRY FILED[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "INSERT CM_CHECKQRY FILED!");
	}

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sXMLBuff[%s]", m_hvps714.m_sXMLBuff.c_str());
    
    // 发送报文
    int i = m_hvps714.m_sXMLBuff.length();
	iRet = cMQAgent.PutMsg(sSendQueue, m_hvps714.m_sXMLBuff.c_str(), i);
	if (0 != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "将714报文PUTMQ失败[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_MQ_ADD_FAIL, "将714报文PUTMQ失败");    
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsCheckList::CreateHvps714()");
}

void CHvpsCheckList::SetAllCtx()
{
    int iRet = -1;
    
    iRet = m_checkaccount.setctx(m_dbproc);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }
    
    iRet = m_hvchklstlist.setctx(m_dbproc);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }
}


void CHvpsCheckList::TransTable(string &msgtp, string &sndrcvtp, string &tablename)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsCheckList::TransTable()");
	
	tablename = "";	
	
	if ( "hvps.111.001.01" == msgtp 
      || "hvps.112.001.01" == msgtp
      || "CMT100" == msgtp
      || "CMT101" == msgtp
      || "CMT102" == msgtp
      || "CMT103" == msgtp
      || "CMT105" == msgtp
      || "CMT108" == msgtp
      || "CMT121" == msgtp
      || "CMT122" == msgtp
      || "CMT123" == msgtp
      || "CMT124" == msgtp )
    {
        if ( "SR00" == sndrcvtp )
        {
            tablename = "HV_SNDEXCHGLIST";
        }
        else
        {
            tablename = "HV_RCVEXCHGLIST";
        }
    }
    else if ( "hvps.141.001.01" == msgtp 
           || "CMT232" == msgtp
           || "CMT407" == msgtp
           || "CMT408" == msgtp )
    {
		tablename = "HV_TROFACRCVLIST";
    }
    else if ( "hvps.633.001.01" == msgtp 
           || "hvps.631.001.01" == msgtp )
    {
		tablename = "HV_MNETSTLNTC";
    }
    else if ( "ccms.314.001.01" == msgtp 
           || "ccms.315.001.01" == msgtp
           || "CMT301"          == msgtp
           || "CMT302"          == msgtp)
    {
        tablename = "CM_TRANSINFOQRY";
    }
    else
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "未知的报文类型[%s]",  msgtp.c_str());
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsCheckList::TransTable()");
}

INT32 CHvpsCheckList::FindOriInfo(string &sTablename, string &sOutState ) 
{

	/*状态 : 00 初始状态 01对账相符 02 对账不符 03状态不符 04本地少 05本地多 06金额不符 07 状态金额不符 */

	int iRet = -1;
	char m_szErrMsg[1024] = {0};
	if(sTablename == "HV_SNDEXCHGLIST")
	{
	    
		CHvsndexchglist hvsndlist;
		SETCTX(hvsndlist);
		hvsndlist.m_msgid = m_hvchklstlist.m_orgnlmsgid;
		hvsndlist.m_instgindrctpty = m_hvchklstlist.m_orgnlinstgdrpty;

		iRet = hvsndlist.findByPK();
		if (SQLNOTFOUND == iRet) 
    	{
    	    sOutState = PR_CNCH_04;

			return RTN_SUCCESS;
    	}
		else if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "hvsndlist findByPK fail:  [%d][%s]", 
			 iRet, hvsndlist.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}

		ComparState(hvsndlist.m_amount, hvsndlist.m_busistate, sOutState);

		if(sOutState == PR_CNCH_03)
		{
			hvsndlist.m_busistate = m_hvchklstlist.m_prcsts;
			hvsndlist.m_finalstatedate = m_hvchklstlist.m_chckdt;
    	    sOutState = PR_CNCH_01;
		}
		
		hvsndlist.m_checkstate = sOutState;
		iRet = hvsndlist.updatestate();
		if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "hvsndlist updatestate fail:  [%d][%s]", 
			 iRet, hvsndlist.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
		
	}
	else if(sTablename == "HV_RCVEXCHGLIST")
	{
	    
		CHvrcvexchglist hvrcvlist;
		SETCTX(hvrcvlist);
		hvrcvlist.m_msgid = m_hvchklstlist.m_orgnlmsgid;
		hvrcvlist.m_instgindrctpty = m_hvchklstlist.m_orgnlinstgdrpty;

		iRet = hvrcvlist.findByPK();
		if (SQLNOTFOUND == iRet) 
    	{
    		sOutState = PR_CNCH_04;

			return RTN_SUCCESS;
    	}
		else if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "hvrcvlist findByPK fail:  [%d][%s]", 
			 iRet, hvrcvlist.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
		
		ComparState(hvrcvlist.m_amount, hvrcvlist.m_busistate, sOutState);

		if(sOutState == PR_CNCH_03)
		{
			hvrcvlist.m_busistate = m_hvchklstlist.m_prcsts;
			hvrcvlist.m_finalstatedate = m_hvchklstlist.m_chckdt;
    	    sOutState = PR_CNCH_01;
		}

		hvrcvlist.m_checkstate = sOutState;
		iRet = hvrcvlist.updatestate();
		if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "hvrcvlist updatestate fail:  [%d][%s]", 
			 iRet, hvrcvlist.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}

	}
	else if(sTablename == "HV_TROFACRCVLIST")
	{
	    
		CHvtrofacrcvlist hvtrolist;
		SETCTX(hvtrolist);
		hvtrolist.m_msgid = m_hvchklstlist.m_orgnlmsgid;
		hvtrolist.m_instgindrctpty = m_hvchklstlist.m_orgnlinstgdrpty;
		hvtrolist.m_cdcode = m_hvchklstlist.m_sndrcvtp;

		iRet = hvtrolist.findByPK();
		if (SQLNOTFOUND == iRet) 
    	{
    	    sOutState = PR_CNCH_04;

			return RTN_SUCCESS;
		}
		else if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "hvtrolist findByPK fail:  [%d][%s]", 
			 iRet, hvtrolist.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
		
		ComparState(hvtrolist.m_amount, hvtrolist.m_busistate, sOutState);

		if(sOutState == PR_CNCH_03)
		{
			hvtrolist.m_busistate = m_hvchklstlist.m_prcsts;
			hvtrolist.m_finalstatedate = m_hvchklstlist.m_chckdt;
    	    sOutState = PR_CNCH_01;
		}

		hvtrolist.m_checkstate = sOutState;
		iRet = hvtrolist.updatestate();
		if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "hvtrolist updatestate fail:  [%d][%s]", 
			 iRet, hvtrolist.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
		
	}
	else if(sTablename == "HV_MNETSTLNTC")
	{
		CHvmnetstlntc hvmnetstlntc;
		SETCTX(hvmnetstlntc);
		string strSql = "MSGID = '";
		strSql += m_hvchklstlist.m_orgnlmsgid;
		strSql += "' and INSTDDRCTPTY='";
		strSql += m_hvchklstlist.m_instddrctpty;
		strSql += "' ";

		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "HV_MNETSTLNTC find(strSql)[%s]",  strSql.c_str());

		iRet = hvmnetstlntc.find(strSql);
		if(SQL_SUCCESS == iRet) 
		{
			int iCount = 0;
			while(SQL_SUCCESS == hvmnetstlntc.fetch())
			{
				iCount++;
				ComparState(hvmnetstlntc.m_amt, hvmnetstlntc.m_npcprcsts, sOutState);

				hvmnetstlntc.m_checkstate = sOutState;
				iRet = hvmnetstlntc.updatestate();
				if(OPERACT_SUCCESS != iRet)
				{
					sprintf(m_szErrMsg, "hvmnetstlntc updatestate fail:  [%d][%s]", 
					 iRet, hvmnetstlntc.GetSqlErr());
					Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
					PMTS_ThrowException(DB_GET_DATA_FAIL);
				}
				Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "HV_MNETSTLNTC find(iCount)[%d]",  iCount);
			}
			hvmnetstlntc.closeCursor();
		}
		else if(SQLNOTFOUND == iRet)
		{
			sOutState = PR_CNCH_04;

			return RTN_SUCCESS;
		}
		else
		{
			sprintf(m_szErrMsg, "hvmnetstlntc find fail(strSql):  [%d][%s]", 
			 iRet, hvmnetstlntc.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	}
	else if(sTablename == "CM_TRANSINFOQRY")
	{
	    
		CCmtransinfoqry cmtransinfoqry;
		SETCTX(cmtransinfoqry);
		cmtransinfoqry.m_sysid = "HVPS";
		cmtransinfoqry.m_msgid = m_hvchklstlist.m_orgnlmsgid;
		cmtransinfoqry.m_instgindrctpty = m_hvchklstlist.m_orgnlinstgdrpty;
		if(m_hvchklstlist.m_sndrcvtp == "SR00") // 如果是往报
		{
			cmtransinfoqry.m_rsflag = "1";
		}
		else 
		{
			cmtransinfoqry.m_rsflag = "2";
		}
		
		iRet = cmtransinfoqry.findByPK();
		
		if (SQLNOTFOUND == iRet && cmtransinfoqry.m_rsflag == "1") 
	    {
	    		cmtransinfoqry.m_rsflag = "0";
	    		iRet = cmtransinfoqry.findByPK();
				if (SQLNOTFOUND == iRet) 
				{
					sOutState = PR_CNCH_04;

					return RTN_SUCCESS;
				}
				else if(OPERACT_SUCCESS != iRet)
				{
					sprintf(m_szErrMsg, "cmtransinfoqry findByPK fail:  [%d][%s]", 
					 iRet, cmtransinfoqry.GetSqlErr());
					Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
					PMTS_ThrowException(DB_GET_DATA_FAIL);
				}
	    }
	    else if(SQLNOTFOUND == iRet)
	    {
	    	sOutState = PR_CNCH_04;
	    	return RTN_SUCCESS;
	    }
		else if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "cmtransinfoqry findByPK fail:  [%d][%s]", 
			 iRet, cmtransinfoqry.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
		ComparState(0.00, cmtransinfoqry.m_busistate, sOutState);

		if(sOutState == PR_CNCH_03)
		{
			cmtransinfoqry.m_busistate = m_hvchklstlist.m_prcsts;
			cmtransinfoqry.m_finalstatedate = m_hvchklstlist.m_chckdt;
    	    sOutState = PR_CNCH_01;
		}

		cmtransinfoqry.m_checkstate = sOutState;
		iRet = cmtransinfoqry.updatestate();
		if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "cmtransinfoqry updatestate fail:  [%d][%s]", 
			 iRet, cmtransinfoqry.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	}
	else
	{
		return RTN_FAIL;
	}
	return RTN_SUCCESS;
}



void CHvpsCheckList::UpdateState()
{  Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CHvpsCheckList::UpdateState()"); 

    int iRet = -1;
	string strSql = "CHCKDT ='";
	strSql += m_szChkDt;
	strSql += "' AND INSTDDRCTPTY = '";
	strSql += m_szBkCode;
	strSql += "'";

	int iCount = 0;
	
	SETCTX(m_hvchklstlist);
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSql[%s]",  strSql.c_str());
    
	if(SQL_SUCCESS == m_hvchklstlist.find(strSql))
	{
		while(SQL_SUCCESS ==m_hvchklstlist.fetch())
		{
		/*状态 : 00 初始状态 01对账相符 02 对账不符 03状态不符 04本地少 05本地多 06金额不符 07 状态金额不符 */
		
			string state = ""; //对账状态
			string tablename = "";

			//通过报文类型得到对应的表名
			TransTable(m_hvchklstlist.m_orgnlmsgtp, m_hvchklstlist.m_sndrcvtp, tablename);		
			Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "tablename[%s]",  tablename.c_str());

			//找到原业务状态和金额并比较
			FindOriInfo(tablename,state);

			Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "该条记录对账完毕 msgid[%s],state[%s]",m_hvchklstlist.m_orgnlmsgid.c_str(), state.c_str());
			
			m_hvchklstlist.m_checkstate = state;

			if(state != PR_CNCH_04)
			{
				m_hvchklstlist.m_isdownload = "1";
			}
			//如果本地少往帐，则视为严重错误
			else if(m_hvchklstlist.m_sndrcvtp == "SR00")
			{
			    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "严重错误 ！！！本地少往帐 msgid[%s],state[%s]",m_hvchklstlist.m_orgnlmsgid.c_str(), state.c_str());
			    // 更新与中心对账表中的状态为"10：待人工处理"
		        updateBkChkSt(PR_CNCH_10);
		        //PMTS_ThrowException("本地少往帐");
			}
			
        	int iRet = m_hvchklstlist.updatestate();
        	if(iRet != RTN_SUCCESS)
        	{
        		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "修改发送状态失败iRet=%d, %s", iRet, m_hvchklstlist.GetSqlErr());
        		PMTS_ThrowException(DB_UPDATE_FAIL);
        	} 
			
			if(++iCount%250 == 0)
			{
			    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, " 到达250笔, m_hvbeforecheck.commit()");
			    m_hvchklstlist.commit();
		    }
				
		}
		m_hvchklstlist.commit();
		m_hvchklstlist.closeCursor();
	}

	 Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CHvpsCheckList::UpdateState()"); 			
}

//将本地数据与核对明细表中数据比较 得到对账状态
void CHvpsCheckList::ComparState(double dLamt, string &sLstate, string &sOutState)
{
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "本地[%s][%f] 来报[%s][%f]",sLstate.c_str(),dLamt,m_hvchklstlist.m_prcsts.c_str(),m_hvchklstlist.m_orgnlamount);

	/*状态 : 00 初始状态 01对账相符 02 对账不符 03状态不符 04本地少 05本地多 06金额不符 07 状态金额不符 */


	//浮点型精度不准确 将本地的金额与来报金额相减 如果误差小于千分位则认为相等
	double amtsub = dLamt - m_hvchklstlist.m_orgnlamount;
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "amtsub[%.5f]", amtsub);
	
	if( (sLstate != m_hvchklstlist.m_prcsts) && (dLamt*100 != m_hvchklstlist.m_orgnlamount*100) )
	{
		sOutState = PR_CNCH_07;//金额状态不符
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "金额状态不符不符 msgid[%s]",m_hvchklstlist.m_orgnlmsgid.c_str());
	}
	else if( sLstate != m_hvchklstlist.m_prcsts )
	{
		sOutState = PR_CNCH_03;//状态不符
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "状态不符 msgid[%s]",m_hvchklstlist.m_orgnlmsgid.c_str());
	}
	else if( (dLamt*100 != m_hvchklstlist.m_orgnlamount*100) )
	{
		sOutState = PR_CNCH_06;//金额不符
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "金额不符 msgid[%s]",m_hvchklstlist.m_orgnlmsgid.c_str());
	}
	else
	{
		Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "对账相符 msgid[%s]",m_hvchklstlist.m_orgnlmsgid.c_str());
		sOutState = PR_CNCH_01;//对账相符
	}
}

 


