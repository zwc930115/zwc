/******************************************************************** 
文件名： recvhvps143.cpp
创建人： zys
日  期： 2011-03-31
修改人： 
日  期： 
描  述： 大额来账处理
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvhvps143.h"

using namespace ZFPT;

CRecvHvps143::CRecvHvps143()
{
    m_iMsgVer           = 2;
    m_strMsgTp          = "hvps.143.001.01";

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps143::CRecvHvps143()");
}

CRecvHvps143::~CRecvHvps143()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps143::~CRecvHvps143()");
}

INT32 CRecvHvps143::Work(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps143::doWork()");
	
	// 解析报文串
	unPack(pchMsg);
	
	// 新增数据库
	InsertData(pchMsg);    

	//更新发送状态
	UpdateState();	
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps143::doWork()");
	
	return RTN_SUCCESS;
}

INT32 CRecvHvps143::unPack(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps143::unPack()");
    
    // 1、报文是否为空
    if (NULL == pchMsg || '\0' == pchMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_strBizCode.c_str(), "报文为空");
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "报文为空");
    }
    
    int iRet = RTN_FAIL;
    
    // 2、解析报文
    iRet = m_cHvps143.ParseXml(pchMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CRecvHvps143::Work(): 解析报文失败");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文解析出错!");
    }

    //ZFPTLOG.SetLogInfo("143", m_cHvps143.MsgId.c_str());
    
    // 报文标识符,用于写错误文件名用
    m_strMsgID = m_cHvps143.MsgId;
    
    // 获取工作日期
    GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
    m_strWorkDate = m_sWorkDate;
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps143::unPack()");    
    
    return RTN_SUCCESS;
}

/******************************************************************************
*  Function:   InsertData
*  Description:大额PVP结算业务表hv_pvpsetofac插入记录
*  Input:      无
*  Output:     
*  Return:     0   : 操作成功,
               其他: 操作失败
*  Others:     无
*  Author:     zys
*  Date:       2011-02-17
*******************************************************************************/
INT32 CRecvHvps143::InsertData(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps143::InsertData()");
    
    //赋值
    m_cHvpvpsetofac.m_msgid                         = m_cHvps143.MsgId                           ;// 报文标识号     
    m_cHvpvpsetofac.m_msgtp                         = m_strMsgTp                                 ;// 报文类型
    m_cHvpvpsetofac.m_instgindrctpty                = m_cHvps143.GrpHdrInstgPty                  ;// 发起参与机构
    m_cHvpvpsetofac.m_workdate                      = m_strWorkDate                              ;// 工作日期
    m_cHvpvpsetofac.m_consigndate                   = m_strWorkDate                              ;// 委托日期:二代报文等于工作日期
    m_cHvpvpsetofac.m_mesgid                        = m_cHvps143.m_PMTSHeader.getMesgID()        ;// 通信级标识号
    m_cHvpvpsetofac.m_mesgrefid                     = m_cHvps143.m_PMTSHeader.getMesgRefID()     ;// 通信级参考号
    m_cHvpvpsetofac.m_msgdirect                     = SRC_FRMB                                   ;// 业务来源0:MB1:PMTS2:NPC
    m_cHvpvpsetofac.m_instgdrctpty                  = m_cHvps143.InstgDrctPty                    ;// 发起直接参与机构
    m_cHvpvpsetofac.m_instddrctpty                  = m_cHvps143.InstdDrctPty                    ;// 接收直接参与机构:付款清算行
    m_cHvpvpsetofac.m_instdindrctpty                = m_cHvps143.GrpHdrInstdPty                  ;// 接收参与机构:付款行行号 
    m_cHvpvpsetofac.m_dbtnm                         = m_cHvps143.Nm                              ;// 付款人名称
    m_cHvpvpsetofac.m_dbtracctid                    = m_cHvps143.OthrId                          ;// 付款人帐号
    m_cHvpvpsetofac.m_dbtrissr                      = m_cHvps143.Issr                            ;// 付款人开户行行号
    m_cHvpvpsetofac.m_txlctrctnb                    = m_cHvps143.TxlCtrctNb                      ;// 交易合同号码
    m_cHvpvpsetofac.m_purchspric                    = atof(m_cHvps143.PurchsPric.c_str()+3)      ;// 买入价
    m_cHvpvpsetofac.m_purchspricccy.assign(m_cHvps143.PurchsPric,0,3)                            ;// 买入价币种
    m_cHvpvpsetofac.m_buyamt                        = atof(m_cHvps143.BuyAmt.c_str())            ;// 买入汇数
    m_cHvpvpsetofac.m_buyamtccy                     = m_cHvps143.Tp                              ;// 买入汇数币种
    m_cHvpvpsetofac.m_currency                      = m_cHvps143.Tp                              ;// 买入币种
    m_cHvpvpsetofac.m_procstate                     = PR_HVBP_95                                 ;// 处理状态:95待发送
    m_cHvpvpsetofac.m_finalstatedate                = m_strWorkDate                              ;// 处理日期/终态日期
    m_cHvpvpsetofac.m_busistate                     = PROCESS_PR06                               ;// 业务状态:PR00：已转发
    m_cHvpvpsetofac.m_mbmsg                         = pchMsg                                     ;// MB报文
    m_cHvpvpsetofac.m_npcmsg                        = ""                                         ;// NPC报文
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_msgid=%s",m_cHvpvpsetofac.m_msgid.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_msgtp=%s",m_cHvpvpsetofac.m_msgtp.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_instgindrctpty=%s",m_cHvpvpsetofac.m_instgindrctpty.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_workdate=%s",m_cHvpvpsetofac.m_workdate.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_consigndate=%s",m_cHvpvpsetofac.m_consigndate.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_mesgid=%s",m_cHvpvpsetofac.m_mesgid.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_mesgrefid=%s",m_cHvpvpsetofac.m_mesgrefid.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_msgdirect=%s",m_cHvpvpsetofac.m_msgdirect.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_instgdrctpty=%s",m_cHvpvpsetofac.m_instgdrctpty.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_instddrctpty=%s",m_cHvpvpsetofac.m_instddrctpty.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_instdindrctpty=%s",m_cHvpvpsetofac.m_instdindrctpty.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_dbtnm=%s",m_cHvpvpsetofac.m_dbtnm.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_dbtracctid=%s",m_cHvpvpsetofac.m_dbtracctid.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_dbtrissr=%s",m_cHvpvpsetofac.m_dbtrissr.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_txlctrctnb=%s",m_cHvpvpsetofac.m_txlctrctnb.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_purchspric=%f",m_cHvpvpsetofac.m_purchspric);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_purchspricccy=%s",m_cHvpvpsetofac.m_purchspricccy.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_buyamt=%f",m_cHvpvpsetofac.m_buyamt);
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_buyamtccy=%s",m_cHvpvpsetofac.m_buyamtccy.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_currency=%s",m_cHvpvpsetofac.m_currency.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_procstate=%s",m_cHvpvpsetofac.m_procstate.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_finalstatedate=%s",m_cHvpvpsetofac.m_finalstatedate.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_busistate=%s",m_cHvpvpsetofac.m_busistate.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.m_mbmsg=%s",m_cHvpvpsetofac.m_mbmsg.c_str());

		//入表
    int iRet = RTN_FAIL;
    
    iRet = m_cHvpvpsetofac.setctx(m_dbproc);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_cHvpvpsetofac.setctx error[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "m_cHvpvpsetofac.setctx error");
    }

    iRet = m_cHvpvpsetofac.insert();
    if (RTN_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg, "大额PVP结算表hv_pvpsetofac插入数据失败[%s], [%d][%s]", 
            m_strMsgID.c_str(), iRet, m_cHvpvpsetofac.GetSqlErr());
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps143::InsertData()");

    return iRet;
}

//更新发送状态
INT32 CRecvHvps143::UpdateState()
{
  Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendHvps143::UpdateState...");
  
     string strSQL;
  
     strSQL += "UPDATE hv_pvpsetofac t SET t.PROCSTATE = '";
     strSQL += PR_HVBP_08;
     strSQL += "'";
  
     strSQL += " WHERE t.MSGID = '";
     strSQL += m_cHvps143.MsgId;
     strSQL += "' AND t.INSTGDRCTPTY = '";
     strSQL += m_cHvps143.InstgDrctPty;                  
     strSQL += "'";
     Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
  
     int iRet = m_cHvpvpsetofac.execsql(strSQL.c_str());
     if(RTN_SUCCESS != iRet)
     {
         Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "UpdateState error:[%d]", iRet);
         PMTS_ThrowException(DB_UPDATE_FAIL);
     }
  
     Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendHvps143::UpdateState...");
     return RTN_SUCCESS;
  
 }


