/******************************************************************** 
文件名： recv141.002.cpp
创建人： luoyutian
日  期： 2017-03-22
修改人： 
日  期： 
描  述： 大额来账处理
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvhvps141.002.h"

using namespace ZFPT;

CRecvHvps141_002::CRecvHvps141_002()
{
    m_iMsgVer  = 2;
    m_strMsgTp = "hvps.141.002.01";
	
	strcpy(m_szIngoingDetailTable, "hv_trofacrcvlist");	//往主键表中插入来账保存在的明细表名

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps141_002::CRecvHvps141_002()");
}

CRecvHvps141_002::~CRecvHvps141_002()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps141_002::~CRecvHvps141_002()");
}

INT32 CRecvHvps141_002::Work(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps141_002::doWork()");
	
	// 1.解析报文
	unPack(pchMsg);
	
	// 2.给m_cHvtrofacrcvlist的成员赋值
	SetData(pchMsg);
	
	// 4.操作及时转账表hv_trofacsndlist，插入数据
	InsertData();
	
	// 3.核签
	CheckSign141();

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps141_002::doWork()");
	return RTN_SUCCESS;
}

INT32 CRecvHvps141_002::unPack(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps141_002::unPack()");
    
    // 1、报文是否为空
    if (NULL == pchMsg || '\0' == pchMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_strBizCode.c_str(), "报文为空");
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "报文为空");
    }
    
    int iRet = RTN_FAIL;
    
    // 3、解析报文
    iRet = m_cParser141_002.ParseXml(pchMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CRecvHvps141_002::Work(): 解析报文失败");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文解析出错!");
    }

    //ZFPTLOG.SetLogInfo("141.002", m_cParser141_002.MsgId.c_str());
    
    // 报文标识符,用于写错误文件名用
    m_strMsgID = m_cParser141_002.MsgId;
    //std::stringstream sstr;
    //m_cParser141_002.m_pXMLProc.PrintMap(sstr);
    
    //Trace(L_INFO,  __FILE__,  __LINE__, NULL, "CRecvHvps141_002::unPack MapData[\n%s]", sstr.str().c_str());
   
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps141_002::unPack()");    
    
    return RTN_SUCCESS;
}

void CRecvHvps141_002::CheckSign141()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps141_002::CheckSign141()");
	
	//核签要素串
	m_cParser141_002.m_sSignBuff = m_cParser141_002.CHECKVALUE(m_cParser141_002.MsgId) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.CreDtTm) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.InstgAgtMmbId) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.InstdAgtMmbId) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.EndToEndId) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.TxId) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.TypePrtry) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.ClassPrtry) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.Ccy + m_cParser141_002.IntrBkSttlmAmt) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.DbtrMmbId) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.DbtrId) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.CdtrMmbId) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.CdtrId) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.DbtrNm) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.DbtrAdrLine) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.DbtrAcctId) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.DbtrAcctIssr) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.DbtrAcctIssrNm) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.CdtrAcctIssr)
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.CdtrAcctIssrNm)
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.CdtrNm) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.CdtrAdrLine) 
								+m_cParser141_002.CHECKVALUE(m_cParser141_002.CdtrAcctId);

  //RemittanceInformation 核签要素串
  int iCount = m_cParser141_002.m_pXMLProc.m_PMTSUstrdDataMap.size();
  for(int iDepth = 0;iDepth < iCount ;iDepth++)
  {
      string strTemp = m_cParser141_002.GetUstrd(iDepth);
      string strBusiType="";

      //当业务类型为“公开市场交易结算”、“债券市场交易结算”、“债券发行、兑付及收益划拨”时需要添加以下项
      if (("G101"==m_cParser141_002.TypePrtry)
	  	 ||("G102"==m_cParser141_002.TypePrtry)
	  	 ||("G103"==m_cParser141_002.TypePrtry)
	  	 ||("G110"==m_cParser141_002.TypePrtry)
	  	 ||("G111"==m_cParser141_002.TypePrtry)	)
      {
      	if(NULL != strstr(strTemp.c_str(), "/E40"))  //债券/央票代码
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));  
	      }
	      else if(NULL != strstr(strTemp.c_str(), "/D14/")) //债券/央票面额
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      }
	      else if(NULL != strstr(strTemp.c_str(), "/D32/"))  //净价金额	
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      }	
	      else if(NULL != strstr(strTemp.c_str(), "/D33/"))  //债券/央票利息
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      }	
	      else if(NULL != strstr(strTemp.c_str(), "/D11/"))  // 回购首期结算额
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      }
	      else if(NULL != strstr(strTemp.c_str(), "/D34/"))  // 回购利息
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      }
	      else if(NULL != strstr(strTemp.c_str(), "/C19/"))  // 回购到期日
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      }  	
      }
      //业务类型为“外汇交易市场结算”时需要添加以下项：
      else if("G106"==m_cParser141_002.TypePrtry)
      {
      	if(NULL != strstr(strTemp.c_str(), "/F58/"))  // 外汇交易币种
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      } 	
      }
      //业务类型为“质押融资”业务种类为“融资支付”时需要添加以下项：
      else if(("G109"==m_cParser141_002.TypePrtry)&&("03501"==strBusiType))
      {
      	if(NULL != strstr(strTemp.c_str(), "/D35/"))  // 质押债券总面额
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      }else if(NULL != strstr(strTemp.c_str(), "/A07/"))  // 出质行行号
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      }else if(NULL != strstr(strTemp.c_str(), "/E50/"))  //  原报文标识号
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      }else if(NULL != strstr(strTemp.c_str(), "/A70/"))  //  原发起参与机构	
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      }else if(NULL != strstr(strTemp.c_str(), "/F60/"))  // 业务状态		
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      }	
      }
      //业务类型为“质押融资”业务种类为“融资扣款”时需要添加以下项：
      else if(("G109"==m_cParser141_002.TypePrtry)&&("03502"==strBusiType))
      {
      	if(NULL != strstr(strTemp.c_str(), "/D36/"))  // 融资本金
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      }else if(NULL != strstr(strTemp.c_str(), "/D35/"))  // 质押债券总面额
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      }else if(NULL != strstr(strTemp.c_str(), "/A07/"))  // 出质行行号
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      }else if(NULL != strstr(strTemp.c_str(), "/D37/"))  //  融资利息
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      }else if(NULL != strstr(strTemp.c_str(), "/F59/"))  //  还款类型	
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      }
      }
      //业务类型为“资金池结算”或“日终自动拆借”时需要添加以下项：
      else if(("G107"==m_cParser141_002.TypePrtry)||("G108"==m_cParser141_002.TypePrtry))
      {
      	if(NULL != strstr(strTemp.c_str(), "/E39/"))  // 业务协议号
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      }else if(NULL != strstr(strTemp.c_str(), "/F50/"))  //  金额正负标识
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      }else if(NULL != strstr(strTemp.c_str(), "/F61/"))  // 业务状态
	      {
	        m_cParser141_002.m_sSignBuff += m_cParser141_002.CHECKVALUE(strTemp.substr(5));
	      }
      }    
  }
  
  m_cParser141_002.m_sSignBuff += 	 m_cParser141_002.CHECKVALUE(m_cParser141_002.PlaceAndName)
									+m_cParser141_002.CHECKVALUE(m_cParser141_002.TxBatNo);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cParser141_002.m_sSignBuff=[%s]",m_cParser141_002.m_sSignBuff.c_str());
	CheckSign(m_cParser141_002.m_sSignBuff.c_str(),
						m_cParser141_002.m_szDigitSign.c_str(),
						//m_cParser141_002.DbtrMmbId.c_str());
						m_cParser141_002.InstgAgtMmbId.c_str());//LJJ 20140918 
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps141_002::CheckSign141()");
}

/******************************************************************************
*  Function:   SetData
*  Description:
*  Input:      无
*  Output:     
*  Return:     0   : 操作成功,
               其他: 操作失败
*  Others:     无
*  Author:     zys
*  Date:       2011-02-17
*******************************************************************************/
INT32 CRecvHvps141_002::SetData(LPCSTR pchMsg)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps141_002::SetData()");

    //memcpy(m_sWorkDate,m_cParser141_002.MsgId.substr(0,8).c_str(),sizeof(m_sWorkDate)-1);
    m_strWorkDate = m_sWorkDate;
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strWorkDate=[%s]", m_strWorkDate.c_str());
    string strTemp;
    
    //==============================m_cHvtrofacrcvlist字段==============================
    m_cHvtrofacrcvlist.m_msgid            = m_cParser141_002.MsgId;        // 报文标识号

    m_cHvtrofacrcvlist.m_instgdrctpty     = Trim(m_cParser141_002.m_PMTSHeader.getOrigSender());// 发起直接参与机构=特许参与者
    
    m_cHvtrofacrcvlist.m_workdate         = m_strWorkDate;             // 工作日期
    m_cHvtrofacrcvlist.m_srcflag = "0";

    m_cHvtrofacrcvlist.m_consigndate  = m_strWorkDate;                 //委托日期:二代报文等于工作日期
    
    m_cHvtrofacrcvlist.m_mesgid       = m_cParser141_002.m_PMTSHeader.getMesgID();       // 通信级标识号
    m_cHvtrofacrcvlist.m_mesgrefid    = m_cParser141_002.m_PMTSHeader.getMesgRefID();    // 通信级参考号
    
    m_cHvtrofacrcvlist.m_msgtp            = m_strMsgTp;                // 报文类型
    m_cHvtrofacrcvlist.m_endtoendid       = m_cParser141_002.EndToEndId;   // 端到端标识号
    //m_cHvtrofacrcvlist.m_msgdirect        = "2";                       // 业务来源0:MB1:PMTS2:NPC
    m_cHvtrofacrcvlist.m_instgindrctpty   = Trim(m_cParser141_002.m_PMTSHeader.getOrigSender());   // 发起参与机构
    m_cHvtrofacrcvlist.m_instddrctpty     = Trim(m_cParser141_002.m_PMTSHeader.getOrigReceiver());    // 接收直接参与机构:付款清算行
    m_cHvtrofacrcvlist.m_instdindrctpty   = Trim(m_cParser141_002.m_PMTSHeader.getOrigReceiver());       // 接收参与机构:付款行行号
    m_cHvtrofacrcvlist.m_spjoinmmbid      = Trim(m_cParser141_002.InstgAgtMmbId); 	// 特许参与者机构
    m_cHvtrofacrcvlist.m_dbtmmbid         = m_cParser141_002.DbtrMmbId;    // 付款清算行行号
    m_cHvtrofacrcvlist.m_dbtnm            = m_cParser141_002.DbtrNm;       // 付款人名称
    m_cHvtrofacrcvlist.m_dbtracctid       = m_cParser141_002.DbtrAcctId;   // 付款人帐号
    m_cHvtrofacrcvlist.m_dbtid            = m_cParser141_002.DbtrId;       // 付款行行号
    m_cHvtrofacrcvlist.m_dbtrissr         = m_cParser141_002.DbtrAcctIssr; // 付款人开户行行号
    m_cHvtrofacrcvlist.m_dbtrlssrnm       = m_cParser141_002.DbtrAcctIssrNm; // 付款人开户行行号
    m_cHvtrofacrcvlist.m_cdtmmbid         = m_cParser141_002.CdtrMmbId;    // 收款清算行行号
    m_cHvtrofacrcvlist.m_cdtrnm           = m_cParser141_002.CdtrNm;       // 收款人户名
    m_cHvtrofacrcvlist.m_cdtid            = m_cParser141_002.CdtrId;       // 收款行行号
    m_cHvtrofacrcvlist.m_cdtracctid       = m_cParser141_002.CdtrAcctId;   // 收款人帐号
    m_cHvtrofacrcvlist.m_cdtrissr         = m_cParser141_002.CdtrAcctIssr; // 收款人开户行行号
    m_cHvtrofacrcvlist.m_cdtrlssrnm         = m_cParser141_002.CdtrAcctIssrNm; // 收款人开户行行号
    m_cHvtrofacrcvlist.m_currency         = m_cParser141_002.Ccy;          // 货币符号
    m_cHvtrofacrcvlist.m_amount           = atof(m_cParser141_002.IntrBkSttlmAmt.c_str());     // 交易金额
    m_cHvtrofacrcvlist.m_ctgypurpprtry    = m_cParser141_002.TypePrtry;        // 业务类型编码
    m_cHvtrofacrcvlist.m_procstate        = PR_HVBP_06;               //处理状态: 06 待回执
    m_cHvtrofacrcvlist.m_finalstatedate   = m_strWorkDate;             // 清算日期
    m_cHvtrofacrcvlist.m_busistate        = PROCESS_PR06;              // 业务状态:PR06：待处理
    //m_cHvtrofacrcvlist.m_processcode      = "";                        // 业务处理码
    m_cHvtrofacrcvlist.m_rjctinf          = "";                        // 业务拒绝信息
    m_cHvtrofacrcvlist.m_acctstate        = "";                        // 记账状态
    m_cHvtrofacrcvlist.m_acctregnum       = "";                        // 记账流水号
    //m_cHvtrofacrcvlist.m_reacregnum       = "";                      // 冲正流水号
    m_cHvtrofacrcvlist.m_checkstate       = PR_HVBP_00;               // 与NPC对账状态
    m_cHvtrofacrcvlist.m_mbcheckstate     = PR_HVBP_00;               // 与行内对账状态
    m_cHvtrofacrcvlist.m_ustrdstr         = m_cParser141_002.Ustrd;        // 附加域
    m_cHvtrofacrcvlist.m_mbmsg            = "";                        // MB报文
    m_cHvtrofacrcvlist.m_npcmsg           = pchMsg;                    // NPC报文
    m_cHvtrofacrcvlist.m_reserve          = "";                        // 保留域
    m_cHvtrofacrcvlist.m_printno          = 0;                         // 打印次数
    m_cHvtrofacrcvlist.m_dbtaddr          = m_cParser141_002.DbtrAdrLine;  // 付款人地址
    m_cHvtrofacrcvlist.m_cdtaddr          = m_cParser141_002.CdtrAdrLine;  // 收款人地址
    m_cHvtrofacrcvlist.m_isrbflg          = "";                        // 是否退汇标志
    m_cHvtrofacrcvlist.m_sttlmprty        = "0";                       //优先级

    m_cHvtrofacrcvlist.m_purpprtry        = m_cParser141_002.ClassPrtry; //业务种类编码
    m_cHvtrofacrcvlist.m_tranmunum        = m_cParser141_002.TxBatNo; //交易批次号
    m_cHvtrofacrcvlist.m_cdcode           = m_cParser141_002.Cdcode; //借贷标识
    if("CRDT"==m_cHvtrofacrcvlist.m_cdcode)
    {
        m_cHvtrofacrcvlist.m_instdindrctpty   = m_cParser141_002.CdtrId; //发起参与机构
    }
    else
    {
        m_cHvtrofacrcvlist.m_instdindrctpty   = m_cParser141_002.DbtrId; //接收参与机构
    }
    m_cHvtrofacrcvlist.m_rmk  = m_cParser141_002.Remark; // 备注
    m_cHvtrofacrcvlist.m_finalstatedate = m_cParser141_002.SettleDate; // 清算日期

	//3、按业务类型区分的附加域

    int iCount = m_cParser141_002.m_pXMLProc.m_PMTSUstrdDataMap.size();
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "iCount = [%d]",iCount);
    
    for(int iDepth = 0;iDepth < iCount ;iDepth++)
    {
        strTemp = m_cParser141_002.GetUstrd(iDepth);

        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strTemp = [%s]",strTemp.c_str());
        
    
        if("G101" == m_cHvtrofacrcvlist.m_ctgypurpprtry ||
        	"G102" == m_cHvtrofacrcvlist.m_ctgypurpprtry ||
        	"G103" == m_cHvtrofacrcvlist.m_ctgypurpprtry ||
        	"G110" == m_cHvtrofacrcvlist.m_ctgypurpprtry ||
        	"G111" == m_cHvtrofacrcvlist.m_ctgypurpprtry )//公开市场交易结算||债券市场交易结算||债券发行、兑付及收益划拨
        {
            
            if(NULL != strstr(strTemp.c_str(),"/E40/")) //债券/央票代码
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp + ":";            
            }
            else if(NULL != strstr(strTemp.c_str(),"/D14/")) //债券/央票面额
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";            
            }
            else if(NULL != strstr(strTemp.c_str(),"/D32/")) //净价金额
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";           
            }
            else if(NULL != strstr(strTemp.c_str(),"/D33/")) //债券/央票利息
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";           
            }
            else if(NULL != strstr(strTemp.c_str(),"/D11/")) // 回购首期结算额
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";            
            }
            else if(NULL != strstr(strTemp.c_str(),"/D34/")) // 回购利息
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";
            }
            else if(NULL != strstr(strTemp.c_str(),"/C19/")) //回购到期日
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";
            }
        }

        else if("G106" == m_cHvtrofacrcvlist.m_ctgypurpprtry) //外汇交易市场结算
        {            
            if(NULL != strstr(strTemp.c_str(),"/F58/")) //  外汇交易币种
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp + ":";            
            }
        }

        else if(("G109" == m_cHvtrofacrcvlist.m_ctgypurpprtry) && ("03501" == m_cHvtrofacrcvlist.m_purpprtry)) //质押融资&&融资支付
        {            
            if(NULL != strstr(strTemp.c_str(),"/D35/")) //质押债券总面额
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp + ":";            
            }
            else if(NULL != strstr(strTemp.c_str(),"/A07/")) //出质行行号
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";            
            }
            else if(NULL != strstr(strTemp.c_str(),"/E50/")) //原报文标识号
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";           
            }
            else if(NULL != strstr(strTemp.c_str(),"/A70/")) //原发起参与机构
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";           
            }
            else if(NULL != strstr(strTemp.c_str(),"/F60/")) // 业务状态
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";            
            }
        }

        else if(("G109" == m_cHvtrofacrcvlist.m_ctgypurpprtry) && ("03502" == m_cHvtrofacrcvlist.m_purpprtry)) //质押融资&&融资扣款
        {   
            
            if(NULL != strstr(strTemp.c_str(),"/D36/")) // 融资本金
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp + ":";            
            }
            else if(NULL != strstr(strTemp.c_str(),"/D35/")) //质押债券总面额
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";            
            }
            else if(NULL != strstr(strTemp.c_str(),"/A07/")) //出质行行号
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";           
            }
            else if(NULL != strstr(strTemp.c_str(),"/D37/")) // 融资利息
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";           
            }
            else if(NULL != strstr(strTemp.c_str(),"/F59/")) //  还款类型
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";            
            }
        }

		else if(("G107" == m_cHvtrofacrcvlist.m_ctgypurpprtry) || ("G108" == m_cHvtrofacrcvlist.m_ctgypurpprtry)) //资金池结算"或"日终自动拆借
        { 
            
            if(NULL != strstr(strTemp.c_str(),"/E39/")) // 业务协议号
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp + ":";            
            }
            else if(NULL != strstr(strTemp.c_str(),"/F50/")) //金额正负标识
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";            
            }
            else if(NULL != strstr(strTemp.c_str(),"/F61/")) //业务状态
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";           
            }
            else if(NULL != strstr(strTemp.c_str(),"/G00/")) // 业务拒绝处理码
            {
                m_cHvtrofacrcvlist.m_ustrdstr = m_cHvtrofacrcvlist.m_ustrdstr +  strTemp +":";           
            }
        }        
    }     

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps141_002::SetData()");
    
    return RTN_SUCCESS;
}

/******************************************************************************
*  Function:   InsertData
*  Description:大额及时转账业务表hv_trofacsndlist插入记录
*  Input:      无
*  Output:     
*  Return:     0   : 操作成功,
               其他: 操作失败
*  Others:     无
*  Author:     zys
*  Date:       2017-04-10
*******************************************************************************/
INT32 CRecvHvps141_002::InsertData(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvHvps141_002::InsertData()");

    int iRet = RTN_FAIL;

    iRet = m_cHvtrofacrcvlist.setctx(m_dbproc);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_strMsgID.c_str(), "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }
    iRet = m_cHvtrofacrcvlist.insert();
    if (RTN_SUCCESS != iRet)
    {
        memset(m_szErrMsg, 0, sizeof(m_szErrMsg));sprintf(m_szErrMsg, "大额及时转账业务表hv_trofacrcvlist插入数据失败[%s], [%d][%s]", 
            m_strMsgID.c_str(), iRet, m_cHvtrofacrcvlist.GetSqlErr());
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvHvps141_002::InsertData()");

    return RTN_SUCCESS;
}

	
