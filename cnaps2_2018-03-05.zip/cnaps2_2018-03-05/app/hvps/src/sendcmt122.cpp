/******************************************************************** 
�ļ����� sendcmt122.cpp
�����ˣ� aps-xcm
��  �ڣ� 2011-06-22
�޸��ˣ� 
��  �ڣ� 
��  ���� һ����������������л�Ʊ�ʽ���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendcmt122.h"

CSendCmt122::CSendCmt122(const stuMsgHead& Smsg):CSendHvpsBase(Smsg)
{
   
}

CSendCmt122::~CSendCmt122()
{
    
}

void CSendCmt122::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt122::SetDBKey...");

    m_Hvsndlist.m_msgtp = "CMT";
    m_Hvsndlist.m_msgtp = m_Hvsndlist.m_msgtp + m_szMsgType;
    
	m_Hvsndlist.m_msgid = m_szMsgFlagNO; 
	m_Hvsndlist.m_instgindrctpty = m_szSndNO; 

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_msgtp = %s", m_Hvsndlist.m_msgtp.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_msgid = %s", m_Hvsndlist.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Hvsndlist.m_instgindrctpty = %s", m_Hvsndlist.m_instgindrctpty.c_str());
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt122::SetDBKey...");
}

int CSendCmt122::GetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt122::GetData...");

    SETCTX(m_Hvsndlist);
    SetDBKey();
    int iRet = m_Hvsndlist.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ȡ����ʧ�ܣ� iRet = [%d]", iRet);
        PMTS_ThrowException(DB_NOT_FOUND);
    }

    if(!m_Hvsndlist.m_endtoendid.empty())
    {
        m_sEndtoEnd = m_Hvsndlist.m_endtoendid;
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sEndtoEnd = %s", m_sEndtoEnd.c_str());
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt122::GetData...");
    return iRet;
    
}



void CSendCmt122::SetData()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt122::SetData...");

    strncpy(m_cCmt122.sConsigndate, m_Hvsndlist.m_workdate.c_str(), sizeof(m_cCmt122.sConsigndate) - 1);
    m_cCmt122.iTxssno = atoi(m_szMsgSerial);
    
    strncpy(m_cCmt122.sCur, m_Hvsndlist.m_currency.c_str(), sizeof(m_cCmt122.sCur) - 1);
    m_cCmt122.dAmount = m_Hvsndlist.m_amount;
    strncpy(m_cCmt122.sSendsapbk, m_Hvsndlist.m_dbtmmbid.c_str(), sizeof(m_cCmt122.sSendsapbk) - 1);
    strncpy(m_cCmt122.sSendbank, m_Hvsndlist.m_dbtid.c_str(), sizeof(m_cCmt122.sSendbank) - 1);
    strncpy(m_cCmt122.sRecvsapbk, m_Hvsndlist.m_cdtmmbid.c_str(), sizeof(m_cCmt122.sRecvsapbk) - 1);
    strncpy(m_cCmt122.sRecvbank, m_Hvsndlist.m_cdtid.c_str(), sizeof(m_cCmt122.sRecvbank) - 1);
    strncpy(m_cCmt122.sPayeeopenbk, m_Hvsndlist.m_cdtrissr.c_str(), sizeof(m_cCmt122.sPayeeopenbk) - 1);
    strncpy(m_cCmt122.sPayopenbk, m_Hvsndlist.m_dbtrissr.c_str(), sizeof(m_cCmt122.sPayopenbk) - 1);

    string strTemp;
    GetTag1ST("59E:", strTemp, m_Hvsndlist.m_ustrdstr);
    strncpy(m_cCmt122.sLastholdno, strTemp.c_str(), sizeof(m_cCmt122.sLastholdno) -1);
    strTemp.erase();
    GetTag1ST("59D:", strTemp, m_Hvsndlist.m_ustrdstr);
    strncpy(m_cCmt122.sLastholdname, strTemp.c_str(), sizeof(m_cCmt122.sLastholdname) -1);
    strTemp.erase();
    GetTag1ST("30B:", strTemp, m_Hvsndlist.m_ustrdstr);
    strncpy(m_cCmt122.sBilldate, strTemp.c_str(), sizeof(m_cCmt122.sBilldate) -1);
    strTemp.erase();
    GetTag1ST("21A:", strTemp, m_Hvsndlist.m_ustrdstr);
    strncpy(m_cCmt122.sBillno, strTemp.c_str(), sizeof(m_cCmt122.sBillno) -1);
    strTemp.erase();
    GetTag1ST("C10:", strTemp, m_Hvsndlist.m_ustrdstr);
    strncpy(m_cCmt122.sDraftmac, strTemp.c_str(), sizeof(m_cCmt122.sDraftmac) -1);
    strTemp.erase();
    GetTag1ST("33C:", strTemp, m_Hvsndlist.m_ustrdstr);
    m_cCmt122.dTicketamount = atof(strTemp.c_str());
    strTemp.erase();
    GetTag1ST("33D:", strTemp, m_Hvsndlist.m_ustrdstr);
    m_cCmt122.dExcesamount = atof(strTemp.c_str());

    strncpy(m_cCmt122.sPayeracc, m_Hvsndlist.m_dbtracctid.c_str(), sizeof(m_cCmt122.sPayeracc) - 1);
    strncpy(m_cCmt122.sPayername, m_Hvsndlist.m_dbtnm.c_str(), sizeof(m_cCmt122.sPayername) - 1);
    strncpy(m_cCmt122.sPayeraddr, m_Hvsndlist.m_dbtaddr.c_str(), sizeof(m_cCmt122.sPayeraddr) - 1);

    //strncpy(m_cCmt122.sPayeeacc, m_Hvsndlist.m_cdtracctid.c_str(), sizeof(m_cCmt122.sPayeeacc) - 1);
    strncpy(m_cCmt122.sPayeename, m_Hvsndlist.m_cdtrnm.c_str(), sizeof(m_cCmt122.sPayeename) - 1);
    //strncpy(m_cCmt122.sPayeeaddr, m_Hvsndlist.m_cdtaddr.c_str(), sizeof(m_cCmt122.sPayeeaddr) - 1);

    char SndCCPCNode[4 + 1] 	= {0};	
	char RcvCCPCNode[4 + 1] 	= {0};
    GetSapBkToCCPC(m_dbproc, m_Hvsndlist.m_instgindrctpty, SndCCPCNode);
	GetSapBkToCCPC(m_dbproc, m_Hvsndlist.m_instdindrctpty, RcvCCPCNode);
	strncpy(m_cCmt122.sSendsenter, SndCCPCNode, sizeof(m_cCmt122.sSendsenter) - 1);
	strncpy(m_cCmt122.sRecvsenter, RcvCCPCNode, sizeof(m_cCmt122.sRecvsenter) - 1);

    strncpy(m_cCmt122.sRemark, m_Hvsndlist.m_addinfo.c_str(), sizeof(m_cCmt122.sRemark) - 1);

    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt122::SetData...");

    
}

int CSendCmt122::buildCmtMsg()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt122::buildCmtMsg...");

    int iRet = m_cCmt122.CreateCmt("122", m_Hvsndlist.m_instgdrctpty.c_str(), m_Hvsndlist.m_instddrctpty.c_str(), m_sMesgId.c_str(), m_sMesgId.c_str(), m_Hvsndlist.m_workdate.c_str(), m_Hvsndlist.m_sttlmprty.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "iRet = [%d]", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt122::buildCmtMsg...");
    return iRet;
}
int CSendCmt122::UpdateState()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt122::UpdateState...");

    SETCTX(m_Hvsndlist);

    string strSQL;

    strSQL += "UPDATE hv_sndexchglist t SET t.STATETIME = sysdate, t.PROCSTATE = '08'";
	strSQL += ", t.MESGID = '";
    strSQL += m_sMesgId;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMesgId;
	strSQL += "', t.endtoendid = '";
	strSQL += m_sEndtoEnd;
    strSQL += "' ";
    
	strSQL += " WHERE t.MSGTP = '";
	strSQL += m_Hvsndlist.m_msgtp.c_str();
    strSQL += "' AND t.MSGID = '";
	strSQL += m_Hvsndlist.m_msgid.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_Hvsndlist.m_instgindrctpty.c_str(); 									
	strSQL += "'";
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "strSQL=[%s]", strSQL.c_str());
    int iRet = m_Hvsndlist.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��iRet=[%d], [%s]", iRet, m_Hvsndlist.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
        
    }
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt122::UpdateState...");
    return iRet;
}

int CSendCmt122::doWorkSelf()
{
    Trace(L_INFO, __FILE__, __LINE__, NULL, "ENTER CSendCmt122::doworkSelf...");
    //1)�������
    GetData();

    //2)��ֵ
    SetData();

    AddMac();
	
    buildCmtMsg();

    
    //3)	ҵ���飨�ͻ������룩
    //.......
    //4)	���������ͻ������룩


    UpdateState();

    AddQueue(m_cCmt122.m_strCmtmsg, m_cCmt122.m_strCmtmsg.length());
    
    Trace(L_INFO, __FILE__, __LINE__, NULL, "LEAVE CSendCmt122::doworkSelf...");
    return RTN_SUCCESS;
    
}

int CSendCmt122::AddMac()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendCmt122::AddMac...");
	int iRet = -1;
	
	m_cCmt122.SetSeal();//��ȡ��Ѻ��

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt122.sSendsapbk[%s]",m_cCmt122.sSendsapbk);
	
    iRet = CodeMac(m_dbproc,m_cCmt122.m_Seal.c_str(),m_cCmt122.sSendsapbk,m_cCmt122.m_szMacStr);
    if(0 != iRet)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "AddMac failed");
    	PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "[%s]",m_cCmt122.m_szMacStr);
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendCmt122::AddMac..."); 
    
    return RTN_SUCCESS;
}
