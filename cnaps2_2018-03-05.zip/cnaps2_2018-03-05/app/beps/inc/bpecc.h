/*
 *  bpecc.h
 *  Description: С����ظ�������дECC��־���ú궨��
 *  Created on: 2012-10-19
 *  Author: __wsh
 */
 
#ifndef BPECC_H
#define BPECC_H

#include "mbpubfunc.h"

#define BP_ECC_LOG(LEVEL, CSTRMSG) NYMB_Trace(LEVEL, CMIBP, __FILE__":"CSTRMSG)

#define ECC_CONN_DB_FAIL()  NYMB_Trace(CMI_ERROR, CMIBP, __FILE__":failed get DB connect")

#define ECC_CONN_MQ_FAIL()  NYMB_Trace(CMI_ERROR, CMIBP, __FILE__":can't connect to MQ")

#define ECC_INIT_CFG_FAIL() NYMB_Trace(CMI_ERROR, CMIBP, __FILE__":failed init the config file")

#define ECC_GET_MSGTP_FAIL() NYMB_Trace(CMI_INFO, CMIBP, __FILE__":get msgtype fail")

#define ECC_PUT_MQ_FAIL()   NYMB_Trace(CMI_ERROR, CMIBP, __FILE__":put message to MQ failure")

#define ECC_GET_MQ_FAIL()   NYMB_Trace(CMI_ERROR, CMIBP, __FILE__":get message from MQ failure")

#define ECC_SYS_ERROR()     NYMB_Trace(CMI_ERROR, CMIBP, __FILE__":system is error")

#endif /*BPECC_H*/
    
