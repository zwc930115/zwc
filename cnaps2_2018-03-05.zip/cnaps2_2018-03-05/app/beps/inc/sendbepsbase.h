#ifndef _SENDBEPSBASE_H
#define _SENDBEPSBASE_H

#include "pubfunc.h"
#include "logger.h"
#include "exception.h"
#include "bprecvmsg.h"
#include "charge.h"

#include "mqagent.h"

using namespace ZFPT;


class CSendBepsBase
{
public:
    CSendBepsBase(const stuMsgHead& Smsg);

    virtual ~CSendBepsBase();
	
    INT32  doWork();
    
    //一代加押
    int GetMac(string& strMacH, string& strBody, 
                const char* pszSendSapBk, char* szMacOut);
    
    //二代打包辅助表的更新
    int UpPKGAssist(LPTSTR pMsgId);

    //一代打包辅助表的更新
    int UpPKGAssist1(LPTSTR pMsgId);
	
    int AddSign(const char *srcSign, char *dstSign, int iFlag, const char * pSendSapbank);

    void AddAppendData(const string& strSrcAppData, 
            char* szBussType[], string& strAppData,int iCount, int iArraySize);
    
	void SetFieldAsGbk(const string& strVal, char* szField, int iLen);
    
    void Utf8ToGbk(char* szData, int nSize, const char* fmt);
    
    void FormatAppendData(string& strDest, const string& strSrc, int nCnt,
    		char* szBizFmts[], int nBfCnt, char* szDtlFmts[] = NULL, int nDfCnt = 0);    
            
    char          m_MQMsgId[64];
protected:

	//业务处理入口函数
	virtual INT32  doWorkSelf() = 0; 
    
    //异常时子业务处理
	virtual int	SetErrACK(int iErrCode, LPCSTR pErrDesc){return 0;};
    
	int InitSysParam();
	int AddQueue();
	DBProc	m_dbproc;
	CCharge m_charge;	//记账及虚拟清算
	string	m_sMsgTxt;
	int		iRet;
	int		m_iVersion;
	char	m_sErrMsg[1024];   //错误描述
	char	m_sSqlStr[1024];   //sql语句
    char	m_sSysName[4 + 1];	//系统标识号
    char	m_sMsgUse[1 + 1];   //消息用途    
    char	m_sMsgType[3 + 1];  //报文格式类型
    char	m_sMsgNo[3 + 1];    //报文类型    
    char	m_sMsgId[28 + 1];   //报文标识号  
    char	m_sSendOrg[14 + 1]; //发起机构号  
    
    char	m_sSapBank[14 + 1]; //支付系统默认清算行号
    char	m_sWorkDate[8 + 1]; //小额系统当前工作日期
    char	m_sIsoWorkDate[19 + 1]; //系统工作iso日期
    char	m_sMsgRefId[20 + 1];//通信级参考号
    char    m_sMesgID[20 + 1]; //通信级标识号
    char	m_sPkgDtNSn[16 + 1];//小额包委托日期+包序号
    char	m_sPkgDest[40 + 1];	//小额包密押
    char	m_sSrcFlag[1 + 1];	//补发标志
    char    m_szConsignDate[8 + 1];
    char    m_szMsgSerial[28 - 8 + 1];    
    char    m_ISODateTime[19 + 1];
    char    m_BusinessType[5 + 1];
    char    m_user[35 + 1];
    char    m_EndFlag[3];
	
	string  m_strSendMsg;
    stuPKGAssist m_strAssist;
	char 	m_szOprUser[20+1];//最终操作用户
	char 	m_szOprUserNetId[20+1]; //用户所属机构
	char 	m_szReserve[36+1];		//保留yu
	char    m_szSrcflg[1+1];//业务来源标志
private:
	MQAgent         m_cMQAgent;
	
    CBprecvmsg		m_bprecv;

	void			GetDBConnect(void);
	
	void			GetMqConn(void);
	
	void            SendToMB(stuSndMsg SndMsg);
};

#endif


