#ifndef RECVPKG008_H
#define RECVPKG008_H

#include "recvbepsbase.h"
#include "pkg008.h"

#include "bpbcoutrecvlist.h"
#include "bpbcoutrcvcl.h"

#include "bpbdsendlist.h"


class CRecvPkg008 : public CRecvBepsBase
{
public:
	CRecvPkg008();

	~CRecvPkg008();

	INT32 Work(LPCSTR szMsg);

private:
	int  UnPack(const char* szmsg);

	int  QryOrgnlBiz(void);

	int  InsertData(void);

	int  InsertData_cl(void);

	int  InsertData_list(void);

	void SetData_006(void);

	void SetData_007(void);

	int  UpdateOrgnlBiz(void);

	void ChkMac008(void);


private:
	CBpbcoutrcvcl    m_bcrcvcl;

	CBpbcoutrecvlist m_bcrcvlist;

	CBpbdsendlist    m_orgnlbiz;

	pkg008           m_cPkg008;

	string           m_strNpcMsg;

	char             m_szMsgId[32+1];

	char             m_szTxId[32+1];

	bool             m_bUpdate;
};

#endif /*RECVPKG008_H*/


