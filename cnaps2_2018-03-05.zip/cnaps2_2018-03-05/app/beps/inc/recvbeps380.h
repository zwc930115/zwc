/******************************************************************** 
文件名： recvbeps380.h
创建人： handongfeng
日  期： 2011-02-23
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __RECVBEPS380_H__
#define __RECVBEPS380_H__

#include "recvbepsbase.h"
#include "beps380.h"
#include "beps381.h"
#include "bpcolltnchrgscl.h"
#include "bpcolltnchrgslist.h"

class CRecvbeps380 : public CRecvBepsBase
{
public:
    CRecvbeps380();
    ~CRecvbeps380();
    int Work(LPCSTR szMsg);
    void CheckSign380();
private:
    INT32 InsertData();
    INT32 SetData(LPCSTR pchMsg);
    INT32 unPack(LPCSTR szMsg);

	beps380			    m_beps380;
    beps381			    m_beps381;
	CBpcolltnchrgscl	m_colltnchrgscl;
    CBpcolltnchrgslist	m_colltnchrgslist;
	
    int					m_iTotalNum;
    double				m_iTotalAmt;
    int					m_iChgTp; /*变更类型:0：新增，1：撤销*/
};

#endif


