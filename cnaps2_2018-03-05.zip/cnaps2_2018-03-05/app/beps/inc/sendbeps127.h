/******************************************************************** 
�ļ����� sendbeps127.h
�����ˣ� zwy
��  ��   �� 2011-03-07
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __SENDBEPS127_H__
#define __SENDBEPS127_H__

#include "beps127.h"
#include "bpbdsendlist.h"
#include "bpbdsndcl.h"
#include "sendbepsbase.h"

class CSendBeps127 : public CSendBepsBase
{
public:
    CSendBeps127(const stuMsgHead& Smsg);
    ~CSendBeps127();
    
    INT32  doWorkSelf();
    
    //static void doMd5(string& strSrc, string& strDst);
    
private:
    
    int getData();
    INT32 CheckValues();
    INT32 ChargeMb();
    INT32 UpdatePkg();
    INT32 UpdateSendList(LPCSTR sProcstate);
    INT32 SetErrACK(int iErrCode, LPCSTR pErrDesc);
	int   insertSum();
	int   updatePkgId();
	int   CreatPmtsMsg();
	int   updateState();
	
	void AddSign127(beps127& xml127);

    char		   m_sPkgNo[35 + 1];
    CBpbdsendlist  m_cBpbdsendlist;
	CBpbdsndcl     m_cBpbdsndcl;
};

#endif


