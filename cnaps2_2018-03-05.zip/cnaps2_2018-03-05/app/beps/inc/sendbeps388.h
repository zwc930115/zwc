/*
 *  sendbeps388.h
 *  Description: ���ո�ҵ��ܾ�֪ͨ����beps.388.001.01����������
 *  Created on: 2012-06-20
 *  Author: __wsh
 */

#ifndef SENDBEPS388_H__
#define SENDBEPS388_H__

#include "beps388.h"
#include "sendbepsbase.h"
#include "bpbizpubntce.h"

class CSendBeps388 : public CSendBepsBase
{
public:
    CSendBeps388(const stuMsgHead& Smsg);

    ~CSendBeps388();
    
    INT32  doWorkSelf();

private:
    int GetData(void);

    void SetData(void);

    void AddSign388(void);

    int BuildPmtsMsg(void);

    int UpdateState(void);

private:
    beps388 m_cBeps388;

    CBpbizpubntce m_bizpn;
};

#endif



