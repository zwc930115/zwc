/*
 *  sendbeps393.h
 *  Description:
 *  Created on: 2012-6-1
 *  Author: __wsh
 */

#ifndef SENDBEPS393_H_
#define SENDBEPS393_H_

#include "beps393.h"
#include "sendbepsbase.h"

#include "bpcstctrctmgcl.h"
#include "bpcstctrctmglist.h"

class CSendBeps393 : public CSendBepsBase
{
public:
	CSendBeps393(const stuMsgHead& Smsg);

    ~CSendBeps393();

    INT32  doWorkSelf();

private:

    int GetData();

    int CheckValues();

    void AddSign393();

    void SetAcctDtls();

	int BuildPmtsMsg();

    int UpdateState();

private:

    beps393 m_cBeps393;

    CBpcstctrctmgcl m_ccmcl;

    CBpcstctrctmglist m_ccmlist;

};


#endif /* SENDBEPS393_H_ */
