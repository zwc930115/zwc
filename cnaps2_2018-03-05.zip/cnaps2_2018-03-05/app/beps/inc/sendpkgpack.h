#ifndef _SENDXMLPACK_H_
#define _SENDXMLPACK_H_

#include "cmcomsend.h"
#include "mqagent.h"
#include "bpbcoutsndcl.h"
#include "bpbdsndcl.h"
#include "pubfunc.h"
#include "pkgbase.h"
extern DBProc	m_dbproc;

class CSendPkgPack
{
public:
    CSendPkgPack();
    virtual ~CSendPkgPack();

	void setData(stPkgTab &_PkgTab);

	INT32 Work();
	
private:
	void GetDBConnect(void);
	void InitSysParam();
    void SendMsgToMQ();
	void UpdPkgAssistState(LPCSTR pProstate);

	void PackPkg001();
	void PackPkg002();
    void PackPkg005();
    void PackPkg006();
    void PackPkg007();
    void PackPkg008(LPCSTR sTypeNo);
	void InsertDbBcCl();
    void InsertDbBdCl();
    void GetCodeMac(pkgbase& oPkgBase,char* pMac);//取编押串


private:
	//DBProc	m_dbproc;
	char	m_szErrMsg[1024+1];		//错误描述
	char	m_sWorkDate[8 + 1];		//小额系统当前工作日期
	char	m_sIsoWorkDate[19 + 1];	//系统工作iso日期
	char	m_sMsgRefId[20 + 1];	//报文参考号
	
	char    m_szMac[40 + 1];        //编押后的串
	
	string	m_strWrkDate ;
	string	m_strSendBank;
    string	m_strRecvBank;
    string	m_strMsgType ;
	string	m_strMsgID   ;			//包序号
	int		m_iMsgNo	 ;
	
	string	m_strMsgTxt  ;

	CCmcomsend	m_cCCmcomsend;

	MQAgent         m_cMQAgent;

	void			GetMqConn(void);
	CBpbcoutsndcl   m_cBpbcoutsndcl;
    CBpbdsndcl      m_bpbdsndcl;
	stPkgTab        m_stPkgTab; 
};

#endif


