/******************************************************************** 
�ļ����� recvpkg001.h
�����ˣ� aps-lel
��  �ڣ� 2011-05-25
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __RECVPKG001_H__
#define __RECVPKG001_H__

#include "recvbepsbase.h"
#include "pkg001.h"
#include "bpbcoutrecvlist.h"
#include "bpbcoutrcvcl.h"

class CRecvPkg001 : public CRecvBepsBase
{
public:
    CRecvPkg001();
    ~CRecvPkg001();
    int Work(LPCSTR szMsg);
    
private:

    void ParserAppData(const char* szSrcAppData, string& szDstAppData);
    
    int InsertData();
    int SetData(LPCSTR pchMsg);
    int unPack(LPCSTR szMsg);
    int FundSettle();
	int CheckMac001();
	
    pkg001              m_cPkg001;
    CBpbcoutrecvlist	m_cBpbcoutrecvlist;
    CBpbcoutrcvcl		m_cBpbcoutrcvcl;

};

#endif

