/******************************************************************** 
�ļ����� sendcmt323.h
�����ˣ� handonfeng
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifndef __SENDCMT323_H__
#define __SENDCMT323_H__

#include "cmt323.h"
#include "bpcstpmtcxl.h" 
#include "sendbepsbase.h"

class CSendCmt323 : public CSendBepsBase
{
public:
    CSendCmt323(const stuMsgHead& Smsg);
    ~CSendCmt323();
    
    int  doWorkSelf();
    
private:
    int buildCmtMsg();
	int GetData();
	INT32 SetData();
    int UpdateState();

    cmt323              m_cmt323;
    CBpcstpmtcxl        m_cBpcstpmtcxl;    
};

#endif

