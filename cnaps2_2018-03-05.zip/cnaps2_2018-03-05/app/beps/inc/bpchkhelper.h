
#ifndef BPCHKHELPER_H
#define BPCHKHELPER_H

#include "basic.h"
#include "connectpool.h"
#include "mqagent.h"
#include "pubfunc.h"
#include "logger.h"
#include "exception.h"
const int MODE_CHECK_LIST    = 1;
const int MODE_CHECK_SUM     = 2;
const int MODE_CHECK_BEFORE  = 3;

#define TAG_SEND "SR00"
#define TAG_RECV "SR01"
#define TAG_PT00 "PT00"
#define TAG_PT01 "PT01"
extern DBProc m_dbproc;

enum _TABLE_NO{
	TBL_CDTR = 1, /*���Ǳ�*/
	TBL_DBTR = 2, /*��Ǳ�*/
	TBL_COLL = 3, /*���ո�*/
	TBL_TXIQ = 4  /*��ѯ�鸴*/
};

class CBpChkHelper
{
public:
	CBpChkHelper();

	~CBpChkHelper();
//ת��ҵ���
public:
	int  ToBizTable(int iMode, LPCSTR szMT, LPCSTR szSR = NULL, LPCSTR szPT = NULL);
private:
	inline void FillTable(int iMode, LPCSTR szSR,
			LPCSTR STCL, LPCSTR STLIST, LPCSTR RTCL, LPCSTR RTLIST);
public:
	char m_szTblNmCl[128];   //���ܱ�, ��������
	char m_szTblNmList[128]; //��ϸ��, ��������

	char m_szSTblNmCl[128];  //�������ܱ�
	char m_szSTblNmList[128];//������ϸ��

	char m_szRTblNmCl[128];  //�������ܱ�
	char m_szRTblNmList[128];//������ϸ��

	int  m_iTblNo;

//��������
public:
	int  GetLocalSum(bool bIsPmt, string& strMsgTp, string& strSSql, string& strRSql);
	
	int  GetLocalSum(string& strMsgTp, string& strSSql, string& strRSql);
	
	int  GetDCSum(LPCSTR SR, string& strSql);
	
	int  GetCollSum(LPCSTR SR, string& strSql);
	
	int  GetTiqSum(LPCSTR SR, string& strSql);
	
	bool IsPmtMsg(const string& strMT);
	
	int  InitBizMbCheckState(const string& strSapBank, const string& strChkDt);
	
	int  UpdateBChkState(const string& strSapBank, const string& strChkDt, LPCSTR szSts,int iDetailNm = 0, int iRcvNm = 0);

public:
	int    m_iLocalSTtlCnt;
	double m_dLocalSTtlAmt;
	int    m_iLocalRTtlCnt;
	double m_dLocalRTtlAmt;

	bool   m_bIsPmt;

//��ϸ����
public:
	int GetLocalBiz(string& strMsgTp, string& strMsgId,
			string& strInstgDrctPty, LPCSTR szSR, LPCSTR szPT=NULL);
public:
	int    m_iLocalTtlCnt;  //����ϸ��Ŀ
	double m_dLocalCtrlSum; //����ϸ�ܽ��
	string m_strLocalBizSt; //ҵ��״̬
	string m_strLocalFinalStateDate;


public:
	friend class CRecvBeps721;
	friend class CRecvBeps723;
	friend class CRecvBeps726;

private:
    //extern DBProc m_dbproc;
};

#endif /*BPCHKHELPER_H*/
