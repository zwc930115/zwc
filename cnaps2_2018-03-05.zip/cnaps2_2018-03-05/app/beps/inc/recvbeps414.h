/*
 * 	recvbeps414.cpp
 *	Description: ʵʱ����Ӧ����beps.414.001.01������
 *  Created on: 2012-07-09
 *  Author: __wsh
 */

#ifndef RECVBEPS414_H
#define RECVBEPS414_H

#include "beps414.h"
#include "recvbepsbase.h"

#include "bpcstpmtcxl.h" 

class CRecvBeps414 : public CRecvBepsBase
{
public:
    CRecvBeps414();

    ~CRecvBeps414();

    INT32 Work(LPCSTR szMsg);
    
private:
    int UnPack(LPCSTR szMsg);

    void SetData(void);

    int InsertData(void);

    void  CheckSign414();
    
    int UpdateOrgnBiz(void);

    int ChargeMb();
    
	int UpdateBusState(void);
	void  GetSql(const string strTableName,string &strSql);
private:
    beps414           m_cBeps414;
    
    CBpcstpmtcxl      m_cpc;
	CEntityBase  m_entitybase;
	
};

#endif /*RECVBEPS414_H*/


