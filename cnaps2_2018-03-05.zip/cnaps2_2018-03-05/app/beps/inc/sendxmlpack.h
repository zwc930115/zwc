#ifndef _SENDXMLPACK_H_
#define _SENDXMLPACK_H_

#include "cmcomsend.h"
#include "mqagent.h"
#include "bpbcoutsndcl.h"
#include "bpbdsndcl.h"
#include "pubfunc.h"
#include "pmtsmsgbase.h"

class CSendXmlPack
{
public:
    CSendXmlPack();
    virtual ~CSendXmlPack();

	void setData(stPkgTab &_PkgTab);

	INT32 Work();
	
private:
	void GetDBConnect(void);

	void InitSysParam();
    
    void SendMsgToMQ();

	void UpdPkgAssistState(LPCSTR pProstate);
	
	void InsertBcoutsndcl();//入贷记汇总表
	void InsertBdsndcl();//入借记汇总表
	int  AddSign( PMTSMsgBase &oMsgBase, const char *pSapSendBank, int iFlag);
	void PackXml121();
	void PackXml122();
	void PackXml125();
	void PackXml127();
	void PackXml128();
	void PackXml130();
	void PackXml133();
	void PackXml134();

private:
	DBProc	m_dbproc;
	char	m_szErrMsg[1024+1];		//错误描述
	char	m_sWorkDate[8 + 1];		//小额系统当前工作日期
	char	m_sIsoWorkDate[19 + 1];	//系统工作iso日期
	char	m_sMsgRefId[20 + 1];	//报文参考号
	
	string	m_strWrkDate;
	string	m_strSendBank;
    string	m_strRecvBank;
    string	m_strMsgType ;
	string	m_strMsgID   ;			//包序号
	int		m_iMsgNo	 ;
	
	string	m_strMsgTxt  ;

	CCmcomsend	    m_cCCmcomsend;

	MQAgent         m_cMQAgent;

	void			GetMqConn(void);
	CBpbcoutsndcl   m_cBpbcoutsndcl;
    CBpbdsndcl      m_cBpbdsndcl;
    stPkgTab        m_stPkgTab;
};

#endif


