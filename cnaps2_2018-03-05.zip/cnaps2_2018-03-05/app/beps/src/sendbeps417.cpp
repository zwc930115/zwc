/******************************************************************** 
�ļ����� sendbeps417.cpp
�����ˣ� zys
��  �ڣ� 2011-04-27
�޸��ˣ� 
��  �ڣ� 
��  ���� С��ʵʱ��Ϣ����Ӧ����beps.417������
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps417.h"

using namespace ZFPT;

CSendBeps417::CSendBeps417(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
    bCheck  = false;
}

CSendBeps417::~CSendBeps417()
{

}

INT32 CSendBeps417::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps417::doWorkSelf");

    //��ҵ����л�ȡ����
    getData();

    //ҵ����:������
    CheckValues();

    //�����ʧ��ʱ������Ҫ��֧��ϵͳ����
    if (!bCheck)
    {
        //��pmts����
        buildPmtsMsg();
        
        //����Զ�̶���
        AddQueue();
    }

    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps417::doWorkSelf"); 
    return 0;
}

int CSendBeps417::getData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps417::getData");
    
    SETCTX(m_cBpcstinfcxl);
    
    m_cBpcstinfcxl.m_instgdrctpty = m_sSendOrg;
    m_cBpcstinfcxl.m_msgid        = m_sMsgId;
    
    iRet = m_cBpcstinfcxl.findByPK();
    
    if (SQLNOTFOUND == iRet)
    {
        sprintf(m_sErrMsg, "ʵʱ��Ϣ���������Ҳ���ָ��ҵ��[%s], [%s], [%d][%s]", 
        m_sSendOrg, m_sMsgId, iRet, m_cBpcstinfcxl.GetSqlErr());
        
        Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);
    
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    }
    else if (SQL_SUCCESS != iRet) 
    {
        sprintf(m_sErrMsg, "��ѯʵʱ��Ϣ��������������[%s], [%s], [%d][%s]",
        m_sSendOrg, m_sMsgId, iRet, m_cBpcstinfcxl.GetSqlErr());
        
        Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);
        
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps417::getData"); 
    
    return iRet;
}


int CSendBeps417::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps417::CheckValues");

    //���ԭ���ҵ���Ƿ��Ѹ�����Ѹ������Ҫ����ֹ�����뽻��
	/*if (0 != m_cBpbdsndcl.setctx(m_dbproc))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, OTHER_ERR, "setctx error");
    }

    m_cBpbdsndcl.m_msgid        = m_cBpcstbdpcxlcl.m_orgnlmsgid;
    m_cBpbdsndcl.m_instgdrctpty = m_cBpcstbdpcxlcl.m_orgnlinstgpty;

    iRet = m_cBpbdsndcl.findByPK();
    if (SQL_SUCCESS != iRet)
    {
		sprintf(m_sErrMsg, "��ѯ������˻��ܱ���������[%s], [%s], [%d][%s]",
		    m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(), 
		    m_cBpcstbdpcxlcl.m_orgnlinstgpty.c_str(), 
		    iRet, m_cBpcstbdpcxllist.GetSqlErr());

		Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, MB_PFR0018, m_sErrMsg);         
    }
    else if (SQLNOTFOUND == iRet)
    {
		sprintf(m_sErrMsg, "��ѯ������˻��ܱ��޼�¼[%s], [%s], [%d][%s]",
		    m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(), 
		    m_cBpcstbdpcxlcl.m_orgnlinstgpty.c_str(), 
		    iRet, m_cBpcstbdpcxllist.GetSqlErr());

		Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, MB_OTR0103, m_sErrMsg);        
    }

    if (m_cBpbdsndcl.m_busistate == "PR02")
    {
        bCheck = true;

		sprintf(m_sErrMsg, "��ѯ�ñʽ�ǰ��Ѹ���, �޷�ֹ��[%s], [%s], [%s]",
		    m_cBpcstbdpcxlcl.m_orgnlmsgid.c_str(), 
		    m_cBpcstbdpcxlcl.m_orgnlinstgpty.c_str(), 
		    m_cBpbdsndcl.m_busistate.c_str());

		Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);

		return 0;
    }*/
    
    
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps417::CheckValues");
    return 0;
}

int CSendBeps417::buildPmtsMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps417::buildPmtsMsg");
    
    char sTemp[128]  = {0};
    string strTemp;
    
    SETCTX(m_cBpcstinfcxl);
    
    //��ֵ
	bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get datetime fail");
	    PMTS_ThrowException(PRM_FAIL);
    }

    //����ͷҪ������
    m_cBeps417.m_PMTSHeader.SetPMTSXMlHeader("BEPS", 
                                             m_cBpcstinfcxl.m_workdate.c_str(),
                                             m_cBpcstinfcxl.m_instgdrctpty.c_str(),
                                             m_cBpcstinfcxl.m_instddrctpty.c_str(),
                                             "beps.417.001.01",
                                             m_sMsgRefId);              
    
    //m_cBeps417��ֵ    
    m_cBeps417.MsgId                          = m_cBpcstinfcxl.m_msgid               ;    //���ı�ʶ��
    m_cBeps417.CreDtTm                        = m_sIsoWorkDate                       ;    //���ķ���ʱ��
    m_cBeps417.InstgDrctPty                   = m_cBpcstinfcxl.m_instgdrctpty        ;    //����ֱ�Ӳ������
    //m_cBeps417.GrpHdrInstgPty                 = m_cBpcstinfcxl.m_instgdrctpty        ;    //���������� ???
    m_cBeps417.InstdDrctPty                   = m_cBpcstinfcxl.m_instddrctpty        ;    //����ֱ�Ӳ������
    //m_cBeps417.GrpHdrInstdPty                 = m_cBpcstinfcxl.m_instddrctpty        ;    //���ղ������ ???
    //m_cBeps417.SysCd                          = m_cBpcstinfcxl.                      ;    //ϵͳ���
    //m_cBeps417.Rmk                            = m_cBpcstinfcxl.m_mesgid              ;    // ???
    m_cBeps417.RealTmInfRvslRspnOrgnlMsgId    = m_cBpcstinfcxl.m_oricxlmsgid         ;    //ԭ�������ı�ʶ��
    m_cBeps417.RealTmInfRvslRspnOrgnlInstgPty = m_cBpcstinfcxl.m_oricxlinstgdrctpty  ;    //ԭ����������
    m_cBeps417.RealTmInfRvslRspnOrgnlMT       = m_cBpcstinfcxl.m_oricxlmsgtp         ;    //ԭ������������
    m_cBeps417.Sts                            = m_cBpcstinfcxl.m_status              ;    //ҵ��״̬
    m_cBeps417.RjctCd                         = m_cBpcstinfcxl.m_rjctcd              ;    //ҵ��ܾ�������
    m_cBeps417.RjctInf                        = m_cBpcstinfcxl.m_rjctinf             ;    //ҵ��ܾ���Ϣ
    m_cBeps417.PrcPty                         = m_cBpcstinfcxl.m_rjcprcpty           ;    //ҵ�����������
    m_cBeps417.OrgnlTxOrgnlMsgId              = m_cBpcstinfcxl.m_orimsgid            ;    //ԭҵ���ı�ʶ��
    m_cBeps417.OrgnlTxOrgnlInstgPty           = m_cBpcstinfcxl.m_oriinstgdrctpty     ;    //ԭҵ����������
    m_cBeps417.OrgnlTxOrgnlMT                 = m_cBpcstinfcxl.m_orimsgtp            ;    //ԭҵ��������




    //��ǩ
    AddSign417();

    //��������
    iRet = m_cBeps417.CreateXml();
    if (0 != iRet)
    {
        sprintf(m_sErrMsg, "Create beps.417.001.01 XML is Error!iRet[%d]", iRet);
        
        Trace(L_ERROR,  __FILE__,  __LINE__, m_sMsgId, m_sErrMsg);
        
        PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, m_sErrMsg); 
    }
    
    m_sMsgTxt = m_cBeps417.m_sXMLBuff;
    
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps417::buildPmtsMsg");
    return 0;   
}

void CSendBeps417::AddSign417()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms417::AddSign417");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_cBeps417.getOriSignStr();
	
	AddSign(m_cBeps417.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_cBpcstinfcxl.m_instgdrctpty.c_str());
	
	m_cBeps417.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms417::AddSign417");
}


