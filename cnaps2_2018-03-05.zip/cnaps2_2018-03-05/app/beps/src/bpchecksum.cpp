/******************************************************************** 
�ļ����� bpckecksum.cpp
�����ˣ� hq
��  �ڣ� 2011-05-31
�޸��ˣ� 
��  �ڣ� 
��  ���� С����ܶ�����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "bpchecksum.h"
#include "exception.h"
#include "logger.h"
#include "pubfunc.h"

using namespace ZFPT;

CBpCheckSum::CBpCheckSum()
{
    m_iPkgTtlCnt  = 0;
    m_iMsgTtlCnt  = 0;
    m_szChkDt     = "";
    m_szBkCode    = "";
    m_szMT        = "";
    m_szTxNetgDt  = "";
    m_szTxNetgRnd = "";
    m_szPrcSts    = "";
    m_szCcy       = "";
}

CBpCheckSum::~CBpCheckSum()
{
    
}

void CBpCheckSum::doCheckSumWork(DBProc &dbProc,
                                 int iChkTp, 
                                 LPCSTR sChkDt, 
                                 LPCSTR sBankCode, 
                                 MQAgent &cMQAgent, 
                                 LPCSTR sSendQueue)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBpCheckSum::doCheckSumWork()");

    // ˵�������ܶ�������:0��721���ã�1��������
    m_szChkDt     = sChkDt;
    m_szBkCode    = sBankCode;
    m_dbproc.pCtx = dbProc.pCtx;

    // ��������
    SetAllCtx();

    // ͳ�Ʊ�������
    if (1 == iChkTp)
    {
    	CountLocalInfo();
	}

	// ��������ģ�����ҵ����Ķ���״̬
	UpdateSts();
	
    // ���´�����״̬��Ϣ��
	updateBkChkSt();
	
	// ���˲�ƽ������ҵ����ϸ�˶����뱨��
	if ( 0 < m_iPkgTtlCnt || 0 < m_iMsgTtlCnt )
	{
	    //ɾ��"С����ϸ�˶Ա�"
	    DeleteCheckList();
	    
	    //����722����
	    SndToNpcFor722(cMQAgent, sSendQueue);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBpCheckSum::doCheckSumWork()");
}

void CBpCheckSum::CountLocalInfo()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBpCheckSum::CountLocalInfo()");

    int iRet = -1;
    int iCountNum = 0;
    STRING strSqlStr = "";
    
	//��ѯ����:�������ں��к���ȣ��Ҷ���״̬�����
    strSqlStr = (STRING)" CHCKDT = '" + m_szChkDt;
    strSqlStr += "' and INSTDDRCTPTY = '" + m_szBkCode;
    strSqlStr += "' and CHECKSTATE <> '";
    strSqlStr += PBC_CHKCNFRM_01;
    strSqlStr += "' order by MSGTYPE,PACKPRCSTS";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSqlStr[%s]", strSqlStr.c_str());        

    iRet = m_bpcheckcl.find(strSqlStr);
    if (SQL_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ѯBP_CHECKCL��ʧ��[%d][%s]",
            iRet, m_bpcheckcl.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "��ѯBP_CHECKCL��ʧ��");
    }

    while(SQL_SUCCESS == iRet)
    {
    	iRet = m_bpcheckcl.fetch();
      	if (SQLNOTFOUND == iRet) 
    	{
    	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "*****CountLocalInfo is over*****");
            break;
    	}
    	else if (SQL_SUCCESS != iRet) 
    	{
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ѯBP_CHECKCL��ʧ��[%d][%s]",
                iRet, m_bpcheckcl.GetSqlErr());
                
            m_bpcheckcl.closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "��ѯBP_CHECKCL��ʧ��");
    	}

        iCountNum++;
        
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
                "msgtype[%s], packprcsts[%s], txnetgdt[%s], txnetgrnd[%s]", 
                m_bpcheckcl.m_msgtype.c_str(),  m_bpcheckcl.m_packprcsts.c_str(), 
                m_bpcheckcl.m_txnetgdt.c_str(), m_bpcheckcl.m_txnetgrnd.c_str());

        m_szMT = m_bpcheckcl.m_msgtype;
        
		if ( "beps.121.001.01" == m_szMT 
          || "beps.122.001.01" == m_szMT
          || "beps.124.001.01" == m_szMT
          || "beps.125.001.01" == m_szMT
          || "beps.128.001.01" == m_szMT
          || "beps.130.001.01" == m_szMT
          || "beps.132.001.01" == m_szMT
          || "beps.134.001.01" == m_szMT)
        {
            UpdateCheckCl("BCOUTSNDCL", "BCOUTRCVCL");
        }
        else if ( "beps.381.001.01" == m_szMT 
              || "beps.383.001.01" == m_szMT
              || "beps.385.001.01" == m_szMT
              || "beps.387.001.01" == m_szMT)
        {
            UpdateCheckCl("SNDCOLLTNCHRGSCL", "RCVCOLLTNCHRGSCL");
        }
        else if ("beps.127.001.01" == m_szMT 
            || "beps.133.001.01" == m_szMT)
        {
            UpdateCheckCl("BDSNDCL", "BDRCVCL");
        }
        else if ( "ccms.314.001.01" == m_szMT 
              || "ccms.315.001.01" == m_szMT
              || "CMT301" == m_szMT
              || "CMT302" == m_szMT )
        {
            UpdateCheckCl("SNDTRANSINFOQRY", "RCVTRANSINFOQRY");
        }
        else
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�������ʹ���[%s]", 
                m_bpcheckcl.m_msgtype.c_str());
                
            m_bpcheckcl.closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "�������ʹ���");
        }
    }
    
    m_bpcheckcl.closeCursor();

    if ( 0 == iCountNum )
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���ܱ�BP_CHECKCL������");
        PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "���ܱ�BP_CHECKCL������");
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBpCheckSum::CountLocalInfo()");    
}

void CBpCheckSum::UpdateCheckCl(LPCSTR sSndTableNm, LPCSTR sRcvTableNm)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBpCheckSum::UpdateCheckCl()");

    int  iRet = -1;
    int  iLSndCount = 0;
    int  iLRcvCount = 0;
    double dLSndSum = 0.00;
    double dLRcvSum = 0.00;
    char sUpdateSql[1024 + 1];
    string szUpdateSql= "";
    char sCheckState[2 + 1] = {0};
    stCheckSum stTemp;
    
    // ͳ�Ʊ�������
    iRet = m_checkaccount.getBpLocalSumData(sSndTableNm, 
                            m_bpcheckcl.m_msgtype.c_str(),
                            m_bpcheckcl.m_instddrctpty.c_str(),
                            m_bpcheckcl.m_packprcsts.c_str(),
                            m_bpcheckcl.m_chckdt.c_str(),
                            m_bpcheckcl.m_txnetgdt.c_str(),
                            m_bpcheckcl.m_txnetgrnd.c_str(),
                            m_bpcheckcl.m_sndttlamtccy.c_str());
    if ( iRet != SQL_SUCCESS )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "���ܱ�������ʧ��[%d][%s]", 
            iRet, m_checkaccount.GetSqlErr());

        m_bpcheckcl.closeCursor();
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "���ܱ�������ʧ��");
    }
    iLSndCount = m_checkaccount.m_iCount;
    dLSndSum   = m_checkaccount.m_amount;

    // ͳ�Ʊ�������
    iRet = m_checkaccount.getBpLocalSumData(sRcvTableNm, 
                            m_bpcheckcl.m_msgtype.c_str(),
                            m_bpcheckcl.m_instddrctpty.c_str(),
                            m_bpcheckcl.m_packprcsts.c_str(),
                            m_bpcheckcl.m_chckdt.c_str(),
                            m_bpcheckcl.m_txnetgdt.c_str(),
                            m_bpcheckcl.m_txnetgrnd.c_str(),
                            m_bpcheckcl.m_rcvttlamtccy.c_str());
    if ( iRet != SQL_SUCCESS )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "���ܱ�������ʧ��[%d][%s]", 
            iRet, m_checkaccount.GetSqlErr());

        m_bpcheckcl.closeCursor();
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "���ܱ�������ʧ��");
    }
    iLRcvCount = m_checkaccount.m_iCount;
    dLRcvSum   = m_checkaccount.m_amount;

    m_szPrcSts    = m_bpcheckcl.m_packprcsts;
    m_szTxNetgDt  = m_bpcheckcl.m_txnetgdt;
    m_szTxNetgRnd = m_bpcheckcl.m_txnetgrnd;
        
    // �Ƚ�����
    if (   m_bpcheckcl.m_sndttlcnt == iLSndCount
        && m_bpcheckcl.m_sndttlamt == dLSndSum
        && m_bpcheckcl.m_rcvttlcnt == iLRcvCount
        && m_bpcheckcl.m_rcvttlamt == dLRcvSum )
    {
        strcpy(sCheckState, PBC_CHKCNFRM_01); //�������
    }
    else 
    {
        strcpy(sCheckState, PBC_CHKNOCNFRM_13); //���˲���
        //
        if ( m_bpcheckcl.m_sndttlcnt != iLSndCount
          || m_bpcheckcl.m_sndttlamt != dLSndSum)
        {   
            //���˲���,�����б���������ʱ����������ϸ
            if ( 0 < m_bpcheckcl.m_sndttlcnt )
            {
                //PKG���˲���
                if ( 0 == strcmp(sSndTableNm, "BCOUTSNDCL")
                  || 0 == strcmp(sSndTableNm, "SNDCOLLTNCHRGSCL"))
                {
                    m_iPkgTtlCnt++;
                    AddDetail("SR00", "PKG");
                }
                //��Ϣ���˲���
                else if (0 == strcmp(sSndTableNm, "BDSNDCL")
                      || 0 == strcmp(sSndTableNm, "SNDTRANSINFOQRY"))
                {
                    m_iMsgTtlCnt++;
                    AddDetail("SR00", "MSG");
                }
            }
            //���˲���,�����б���Ϊ��ʱ,ֱ�Ӹ��±���״̬Ϊ���ض�
            else
            {
                m_iLocalMore++;
                memset(&stTemp, 0x00, sizeof(stTemp));
                strncpy(stTemp.sTableNm,   sSndTableNm,                        sizeof(stTemp.sTableNm)  - 1);
                strncpy(stTemp.sCheckSt,   PBC_LOCALMORE_03,                   sizeof(stTemp.sTableNm)  - 1);
                strncpy(stTemp.sMt,        m_szMT.c_str(),                     sizeof(stTemp.sMt)       - 1);
                strncpy(stTemp.sBkCode,    m_szBkCode.c_str(),                 sizeof(stTemp.sBkCode)   - 1);
                strncpy(stTemp.sPrcSts,    m_szPrcSts.c_str(),                 sizeof(stTemp.sPrcSts)   - 1);
                strncpy(stTemp.sChkDt,     m_szChkDt.c_str(),                  sizeof(stTemp.sChkDt)    - 1);
                strncpy(stTemp.sTxNetgDt,  m_szTxNetgDt.c_str(),               sizeof(stTemp.sTxNetgDt) - 1);
                strncpy(stTemp.sTxNetgRnd, m_szTxNetgRnd.c_str(),              sizeof(stTemp.sTxNetgRnd)- 1);
                strncpy(stTemp.sCcy,       m_bpcheckcl.m_sndttlamtccy.c_str(), sizeof(stTemp.sCcy)      - 1);
               
                VCheckArray.push_back(stTemp);
            }
        }
        if ( m_bpcheckcl.m_rcvttlcnt != iLRcvCount
          || m_bpcheckcl.m_rcvttlamt != dLRcvSum )
        {
            //���˲���,�����б���������ʱ����������ϸ
            if ( 0 < m_bpcheckcl.m_sndttlcnt )
            {
                //PKG���˲���
                if ( 0 == strcmp(sSndTableNm, "BCOUTRCVCL")
                  || 0 == strcmp(sSndTableNm, "RCVCOLLTNCHRGSCL"))
                {
                    m_iPkgTtlCnt++;
                    AddDetail("SR01", "PKG");
                }
                //��Ϣ���˲���
                else if (0 == strcmp(sSndTableNm, "BDRCVCL")
                      || 0 == strcmp(sSndTableNm, "RCVTRANSINFOQRY"))
                {
                    m_iMsgTtlCnt++;
                    AddDetail("SR01", "MSG");
                }
            }
            //���˲���,�����б���Ϊ��ʱ,ֱ�Ӹ��±���״̬Ϊ���ض�
            else
            {
                m_iLocalMore++;
                memset(&stTemp, 0x00, sizeof(stTemp));
                strncpy(stTemp.sTableNm,   sRcvTableNm,                        sizeof(stTemp.sTableNm)  - 1);
                strncpy(stTemp.sCheckSt,   PBC_LOCALMORE_03,                   sizeof(stTemp.sTableNm)  - 1);
                strncpy(stTemp.sMt,        m_szMT.c_str(),                     sizeof(stTemp.sMt)       - 1);
                strncpy(stTemp.sBkCode,    m_szBkCode.c_str(),                 sizeof(stTemp.sBkCode)   - 1);
                strncpy(stTemp.sPrcSts,    m_szPrcSts.c_str(),                 sizeof(stTemp.sPrcSts)   - 1);
                strncpy(stTemp.sChkDt,     m_szChkDt.c_str(),                  sizeof(stTemp.sChkDt)    - 1);
                strncpy(stTemp.sTxNetgDt,  m_szTxNetgDt.c_str(),               sizeof(stTemp.sTxNetgDt) - 1);
                strncpy(stTemp.sTxNetgRnd, m_szTxNetgRnd.c_str(),              sizeof(stTemp.sTxNetgRnd)- 1);
                strncpy(stTemp.sCcy,       m_bpcheckcl.m_rcvttlamtccy.c_str(), sizeof(stTemp.sCcy)      - 1);
               
                VCheckArray.push_back(stTemp);
            }
        }
    }

    // �����������ұ���������:����Ҫ���µı����浽vector����
    if (   m_bpcheckcl.m_sndttlcnt == iLSndCount
        && m_bpcheckcl.m_sndttlamt == dLSndSum
        && 0 < iLSndCount )
    {
        memset(&stTemp, 0x00, sizeof(stTemp));
        strncpy(stTemp.sTableNm,   sSndTableNm,                        sizeof(stTemp.sTableNm)   - 1);
        strncpy(stTemp.sCheckSt,   PBC_CHKCNFRM_01,                    sizeof(stTemp.sTableNm)   - 1);
        strncpy(stTemp.sMt,        m_szMT.c_str(),                     sizeof(stTemp.sMt)        - 1);
        strncpy(stTemp.sBkCode,    m_szBkCode.c_str(),                 sizeof(stTemp.sBkCode)    - 1);
        strncpy(stTemp.sPrcSts,    m_szPrcSts.c_str(),                 sizeof(stTemp.sPrcSts)    - 1);
        strncpy(stTemp.sChkDt,     m_szChkDt.c_str(),                  sizeof(stTemp.sChkDt)     - 1);
        strncpy(stTemp.sTxNetgDt,  m_szTxNetgDt.c_str(),               sizeof(stTemp.sTxNetgDt)  - 1);
        strncpy(stTemp.sTxNetgRnd, m_szTxNetgRnd.c_str(),              sizeof(stTemp.sTxNetgRnd) - 1);
        strncpy(stTemp.sCcy,       m_bpcheckcl.m_sndttlamtccy.c_str(), sizeof(stTemp.sCcy)       - 1);
        
        VCheckArray.push_back(stTemp);
    }
    if ( m_bpcheckcl.m_rcvttlcnt == iLRcvCount
      && m_bpcheckcl.m_rcvttlamt == dLRcvSum 
      && 0 < iLRcvCount )
    {
        memset(&stTemp, 0x00, sizeof(stTemp));
        strncpy(stTemp.sTableNm,   sRcvTableNm,                        sizeof(stTemp.sTableNm)   - 1);
        strncpy(stTemp.sCheckSt,   PBC_CHKCNFRM_01,                    sizeof(stTemp.sTableNm)   - 1);
        strncpy(stTemp.sMt,        m_szMT.c_str(),                     sizeof(stTemp.sMt)        - 1);
        strncpy(stTemp.sBkCode,    m_szBkCode.c_str(),                 sizeof(stTemp.sBkCode)    - 1);
        strncpy(stTemp.sPrcSts,    m_szPrcSts.c_str(),                 sizeof(stTemp.sPrcSts)    - 1);
        strncpy(stTemp.sChkDt,     m_szChkDt.c_str(),                  sizeof(stTemp.sChkDt)     - 1);
        strncpy(stTemp.sTxNetgDt,  m_szTxNetgDt.c_str(),               sizeof(stTemp.sTxNetgDt)  - 1);
        strncpy(stTemp.sTxNetgRnd, m_szTxNetgRnd.c_str(),              sizeof(stTemp.sTxNetgRnd) - 1);
        strncpy(stTemp.sCcy,       m_bpcheckcl.m_rcvttlamtccy.c_str(), sizeof(stTemp.sCcy)       - 1);
        
        VCheckArray.push_back(stTemp);
    }
    
    // ����BP_CHECKCL
    sprintf(sUpdateSql, "update BP_CHECKCL set "
                " LSNDTTLAMTCCY = SNDTTLAMTCCY,LRCVTTLAMTCCY = RCVTTLAMTCCY"
                " LSNDTTLCNT = %d,"
                " LSNDTTLAMT = %f," 
                " LRCVTTLCNT = %d,"
                " LRCVTTLAMT = %f,"
                " CHECKSTATE = '%s', CHECKSTATTIME = sysdate"
                " where CHCKDT = '%s'"
                " and MSGTYPE = '%s'"
                " and TXNETGDT = '%s'"
                " and TXNETGRND = '%s'"
                " and PACKPRCSTS = '%s'"
                " and INSTDDRCTPTY = '%s'",
                iLSndCount,
                dLSndSum,
                iLRcvCount,
                dLRcvSum,
                sCheckState,
                m_bpcheckcl.m_chckdt.c_str(),
                m_bpcheckcl.m_msgtype.c_str(),
                m_bpcheckcl.m_txnetgdt.c_str(),
                m_bpcheckcl.m_txnetgrnd.c_str(),
                m_bpcheckcl.m_packprcsts.c_str(),
                m_bpcheckcl.m_instddrctpty.c_str()); 
    Trace(L_INFO, __FILE__, __LINE__, NULL, "sUpdateSql[%s]", sUpdateSql);

    szUpdateSql = sUpdateSql;
    iRet = m_bpcheckcl.execsql(szUpdateSql);
    if (iRet != SQL_SUCCESS )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "����BP_CHECKCLʧ��[%d][%s]",
            iRet, m_bpcheckcl.GetSqlErr());
        m_bpcheckcl.closeCursor();
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "����BP_CHECKCLʧ��");
    }
        
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBpCheckSum::UpdateCheckCl()");    
}

void CBpCheckSum::UpdateSts()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBpCheckSum::UpdateSts()");

    int iRet = -1;
    char sPkgSqlStr[1024 + 1];
    char sListSqlStr[1024 + 1];
    char sErrMsg[1024 + 1];
    char sShortDt[8 + 1];

    memset(sPkgSqlStr, 0x00, sizeof(sPkgSqlStr));
    memset(sErrMsg,    0x00, sizeof(sErrMsg));
    memset(sShortDt,   0x00, sizeof(sShortDt));

    //��ʱ�������ָ��£��Ժ�����Ҫ�ټ���
    
    //�����Ӹ�����ϸ��

    for ( vector<stCheckSum>::size_type ix = 0; ix != VCheckArray.size(); ++ix )
    {
        chgToDate(VCheckArray[ix].sChkDt, sShortDt); //8λ��������
        
        //С�����ʴ��ǻ��ܱ�/��ϸ��
        if ( 0 == strcmp("BCOUTSNDCL", VCheckArray[ix].sTableNm) )
        {
            sprintf(sPkgSqlStr, "UPDATE BP_BCOUTSNDCL t SET "
                             "t.CHECKSTATE = '%s', t.STATETIME = sysdate "
                             " WHERE MSGTP = '%s'"
                             " AND INSTGDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s'"
                             " AND NETGDT = '%s'"
                             " AND NETGRND = '%s'"
                             /*" AND CCY = '%s'"*/,
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt,
                             VCheckArray[ix].sTxNetgDt,
                             VCheckArray[ix].sTxNetgRnd/*,
                             VCheckArray[ix].sCcy*/);
                             
            sprintf(sListSqlStr, "UPDATE BP_BCOUTSENDLIST t SET "
                             "t.CHECKSTATE = '%s', t.STATETIME = sysdate "
                             " WHERE MSGTP = '%s'"
                             " AND INSTGDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s'"
                             " AND NETGDT = '%s'"
                             " AND NETGRND = '%s'"
                             /*" AND CCY = '%s'"*/,
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt,
                             VCheckArray[ix].sTxNetgDt,
                             VCheckArray[ix].sTxNetgRnd/*,
                             VCheckArray[ix].sCcy*/);
        }
        //С�����ʴ��ǻ��ܱ�/��ϸ��
        else if ( 0 == strcmp("BP_BCOUTRCVCL", VCheckArray[ix].sTableNm) )
        {
            sprintf(sPkgSqlStr, "UPDATE BP_BCOUTRCVCL t SET "
                             "t.CHECKSTATE = '%s', t.STATETIME = sysdate "
                             " WHERE MSGTP = '%s'"
                             " AND INSTDDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s'"
                             " AND NETGDT = '%s'"
                             " AND NETGRND = '%s'"
                             /*" AND CCY = '%s'"*/,
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt,
                             VCheckArray[ix].sTxNetgDt,
                             VCheckArray[ix].sTxNetgRnd/*,
                             VCheckArray[ix].sCcy*/);
                             
            sprintf(sListSqlStr, "UPDATE BP_BCOUTRECVLIST t SET "
                             "t.CHECKSTATE = '%s', t.STATETIME = sysdate "
                             " WHERE MSGTP = '%s'"
                             " AND INSTDDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s'"
                             " AND NETGDT = '%s'"
                             " AND NETGRND = '%s'"
                             /*" AND CCY = '%s'"*/,
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt,
                             VCheckArray[ix].sTxNetgDt,
                             VCheckArray[ix].sTxNetgRnd/*,
                             VCheckArray[ix].sCcy*/);
        }
        //С�����ʽ�ǻ��ܱ�/��ϸ��
        else if ( 0 == strcmp("BDSNDCL", VCheckArray[ix].sTableNm) )
        {
            sprintf(sPkgSqlStr, "UPDATE BP_BDSNDCL t SET "
                             "t.CHECKSTATE = '%s', t.STATETIME = sysdate "
                             " WHERE MSGTP = '%s'"
                             " AND INSTGDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s'",
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt);

            sprintf(sListSqlStr, "UPDATE BP_BDSENDLIST t SET "
                             "t.CHECKSTATE = '%s', t.STATETIME = sysdate "
                             " WHERE MSGTP = '%s'"
                             " AND INSTGDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s'",
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt);
        }
        //С�����ʽ�ǻ��ܱ�/��ϸ��
        else if ( 0 == strcmp("BDRCVCL", VCheckArray[ix].sTableNm) )
        {
            sprintf(sPkgSqlStr, "UPDATE BP_BDRCVCL t SET "
                             "t.CHECKSTATE = '%s', t.STATETIME = sysdate "
                             " WHERE MSGTP = '%s'"
                             " AND INSTDDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s'",
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt);

            sprintf(sListSqlStr, "UPDATE BP_BDRECVLIST t SET "
                             "t.CHECKSTATE = '%s', t.STATETIME = sysdate "
                             " WHERE MSGTP = '%s'"
                             " AND INSTDDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s'",
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt);
        }
        //���ո�ҵ����ܱ�-����/��ϸ��
        else if ( 0 == strcmp("SNDCOLLTNCHRGSCL", VCheckArray[ix].sTableNm) )
        {
            sprintf(sPkgSqlStr, "UPDATE BP_COLLTNCHRGSCL t SET "
                             "t.CHECKSTATE = '%s', t.STATETIME = sysdate "
                             " WHERE MSGTP = '%s'"
                             " AND INSTGDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s'"
                             " AND NETGDT = '%s'"
                             " AND NETGRND = '%s' AND SRCFLAG = '3'"
                             /*" AND CURRENCY = '%s'"*/,
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt,
                             VCheckArray[ix].sTxNetgDt,
                             VCheckArray[ix].sTxNetgRnd/*,
                             VCheckArray[ix].sCcy*/);   

            sprintf(sListSqlStr, "UPDATE BP_COLLTNCHRGSLIST t SET "
                             "t.CHECKSTATE = '%s', t.STATETIME = sysdate "
                             " WHERE MSGTP = '%s'"
                             " AND INSTGDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s'"
                             " AND NETGDT = '%s'"
                             " AND NETGRND = '%s' AND SRCFLAG = '3'"
                             /*" AND CURRENCY = '%s'"*/,
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt,
                             VCheckArray[ix].sTxNetgDt,
                             VCheckArray[ix].sTxNetgRnd/*,
                             VCheckArray[ix].sCcy*/);
        }
        //���ո�ҵ����ܱ�-����/��ϸ��
        else if ( 0 == strcmp("RCVCOLLTNCHRGSCL", VCheckArray[ix].sTableNm) )
        {
            sprintf(sPkgSqlStr, "UPDATE BP_COLLTNCHRGSCL t SET "
                             "t.CHECKSTATE = '%s', t.STATETIME = sysdate "
                             " WHERE MSGTP = '%s'"
                             " AND INSTDDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s'"
                             " AND NETGDT = '%s'"
                             " AND NETGRND = '%s' AND SRCFLAG < '3'"
                             /*" AND CURRENCY = '%s'"*/,
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt,
                             VCheckArray[ix].sTxNetgDt,
                             VCheckArray[ix].sTxNetgRnd/*,
                             VCheckArray[ix].sCcy*/);

            sprintf(sListSqlStr, "UPDATE BP_COLLTNCHRGSLIST t SET "
                             "t.CHECKSTATE = '%s', t.STATETIME = sysdate "
                             " WHERE MSGTP = '%s'"
                             " AND INSTDDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND FINALSTATEDATE = '%s'"
                             " AND NETGDT = '%s'"
                             " AND NETGRND = '%s' AND SRCFLAG < '3'"
                             /*" AND CURRENCY = '%s'"*/,
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             VCheckArray[ix].sChkDt,
                             VCheckArray[ix].sTxNetgDt,
                             VCheckArray[ix].sTxNetgRnd/*,
                             VCheckArray[ix].sCcy*/);
        }
        //ҵ��״̬��ѯ��-����
        else if ( 0 == strcmp("SNDTRANSINFOQRY", VCheckArray[ix].sTableNm) )
        {
            sprintf(sPkgSqlStr, "UPDATE CM_TRANSINFOQRY t SET "
                             "t.CHECKSTATE = '%s', t.STATETIME = sysdate "
                             " WHERE MSGTP = '%s'"
                             " AND INSTGDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND WRKDATE = '%s' AND RSFLAG = '1'  AND SYSID = 'BEPS'",
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             sShortDt); 
        }
        //ҵ��״̬��ѯ��-����
        else if ( 0 == strcmp("RCVTRANSINFOQRY", VCheckArray[ix].sTableNm) )
        {
            sprintf(sPkgSqlStr, "UPDATE CM_TRANSINFOQRY t SET "
                             "t.CHECKSTATE = '%s', t.STATETIME = sysdate "
                             " WHERE MSGTP = '%s'"
                             " AND INSTDDRCTPTY = '%s'"
                             " AND BUSISTATE = '%s'"
                             " AND WRKDATE = '%s' AND RSFLAG = '2'  AND SYSID = 'BEPS'",
                             VCheckArray[ix].sCheckSt,
                             VCheckArray[ix].sMt,
                             VCheckArray[ix].sBkCode,
                             VCheckArray[ix].sPrcSts,
                             sShortDt);
        }       
        else
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "do not support the table[%s]", VCheckArray[ix].sTableNm);
            m_bpcheckcl.closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "sTableNm error");
        } 

    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "sPkgSqlStr[%s]", sPkgSqlStr);

    	// ���»��ܱ�
        iRet = m_bpcheckcl.execsql(sPkgSqlStr);
        if ( iRet != SQL_SUCCESS )
        {
            sprintf(sErrMsg, "����[%s]��ʧ��[%d][%s]", 
                VCheckArray[ix].sTableNm, iRet, m_bpcheckcl.GetSqlErr());
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrMsg);
            m_bpcheckcl.closeCursor();
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, sErrMsg);
        }

        // ������ϸ��
        if ( 0 != strcmp("SNDTRANSINFOQRY", VCheckArray[ix].sTableNm)
          && 0 != strcmp("RCVTRANSINFOQRY", VCheckArray[ix].sTableNm) )
        {
            iRet = m_bpcheckcl.execsql(sListSqlStr);
            if ( iRet != SQL_SUCCESS )
            {
                sprintf(sErrMsg, "����[%s]��ϸ��ʧ��[%d][%s]", 
                    VCheckArray[ix].sTableNm, iRet, m_bpcheckcl.GetSqlErr());
                Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrMsg);
                m_bpcheckcl.closeCursor();
                PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, sErrMsg);
            }
        }
        
    	// Ϊ���������ÿ�ζ��ύ
        m_bpcheckcl.commit();
    }
        
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBpCheckSum::UpdateSts()");  
}

void CBpCheckSum::updateBkChkSt()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CBpCheckSum::updateBkChkSt()");

    int iRet = -1;
    char sCheckState[2 + 1];
    
    if ( 0 < m_iPkgTtlCnt || 0 < m_iMsgTtlCnt || 0 < m_iLocalMore )
    {
        strcpy(sCheckState, PBC_CHKNOCNFRM_13); //���˲���
    }
    else
    {
        strcpy(sCheckState, PBC_CHKCNFRM_01); //�������
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_iPkgTtlCnt[%d]m_iMsgTtlCnt[%d]m_iLocalMore[%d]sCheckState[%s]", 
        m_iPkgTtlCnt, m_iMsgTtlCnt, m_iLocalMore, sCheckState);
    
    
    iRet = m_checkaccount.upBpBChkState(m_szBkCode.c_str(), m_szChkDt.c_str(), sCheckState);
    if ( iRet != SQL_SUCCESS )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "����BP_BCHKSTATE��ʧ��[%d][%s]", 
            iRet, m_checkaccount.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "����BP_BCHKSTATE��ʧ��");
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CBpCheckSum::updateBkChkSt()");
}

void CBpCheckSum::DeleteCheckList()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBpCheckSum::DeleteCheckList()");

    int  iRet = -1;
    char sDeleteSql[1024 + 1];
    
    //�����ϸ�˶Ը�����
    sprintf(sDeleteSql, "delete from BP_CHKLSTCL "
                " where INSTDDRCTPTY = '%s'",
                m_szBkCode.c_str()); 
    Trace(L_INFO, __FILE__, __LINE__, NULL, "sDeleteSql[%s]", sDeleteSql);

    iRet = m_bpcheckcl.execsql(sDeleteSql);
    if ( iRet != SQL_SUCCESS && iRet != SQLNOTFOUND )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "ɾ��BP_CHKLSTCLʧ��[%d][%s]",
            iRet, m_bpcheckcl.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "ɾ��BP_CHKLSTCLʧ��");
    }

    //�����ϸ�˶Ա�
    sprintf(sDeleteSql, "delete from BP_CHKLSTLIST "
                " where INSTDDRCTPTY = '%s'",
                m_szBkCode.c_str()); 
    Trace(L_INFO, __FILE__, __LINE__, NULL, "sDeleteSql[%s]", sDeleteSql);

    iRet = m_bpcheckcl.execsql(sDeleteSql);
    if ( iRet != SQL_SUCCESS && iRet != SQLNOTFOUND )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "ɾ��BP_CHKLSTLISTʧ��[%d][%s]",
            iRet, m_bpcheckcl.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "ɾ��BP_CHKLSTLISTʧ��");
    }
        
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBpCheckSum::DeleteCheckList()");    
}

void CBpCheckSum::SndToNpcFor722(MQAgent &cMQAgent, LPCSTR sSendQueue)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CBpCheckSum::SndToNpcFor722()");

    char sBankNo[14 + 1] = {0};
    char sMesgId[20 + 1] = {0};
    char sMsgId[35 + 1] = {0};
    char sISODateTime[19 + 1] = {0};
    char sTemp[128 + 1] = {0};
    char sChkDt[8 + 1] = {0};
    int  iRet = -1;

    strncpy(sBankNo, m_szBkCode.c_str(), sizeof(sBankNo) - 1);
    
    //����ͷ��ֵ
    if ( !GetMsgIdValue(m_dbproc, sMesgId, 8,  SYS_BEPS, sBankNo) )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "ȡ���Ĳο���ʧ��");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_SYS_PARA_FAIL, "ȡ���Ĳο���ʧ��");
    }

    chgToDate(m_szChkDt.c_str(), sChkDt);
    m_beps722.CreateXMlHeader("BEPS",
                              sChkDt,
                              m_szBkCode.c_str(),
                              "000000000000",
                              "beps.722.001.01",
                              sMesgId);
                              
    //�����帳ֵ
    if ( !GetMsgIdValue(m_dbproc, sMsgId, 1,  SYS_BEPS, sBankNo) )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "ȡ���ı�ʶ��ʧ��");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_SYS_PARA_FAIL, "ȡ���ı�ʶ��ʧ��");
    }
    GetIsoDateTime(m_dbproc, SYS_BEPS, sISODateTime);
    
    m_beps722.MsgId           = sMsgId;         //���ı�ʶ��
    m_beps722.CreDtTm         = sISODateTime;   //���ķ���ʱ��
    m_beps722.InstgDrctPty    = m_szBkCode;     //����ֱ�Ӳ������
    m_beps722.GrpHdrInstgPty  = m_szBkCode;     //����������
    m_beps722.InstdDrctPty    = "000000000000"; //����ֱ�Ӳ������
    m_beps722.GrpHdrInstdPty  = "000000000000"; //���ղ������
    m_beps722.SysCd           = "BEPS";         //ϵͳ���
    m_beps722.ChckDt          = m_szChkDt;      //��������

    sprintf(sTemp, "%d", m_iPkgTtlCnt);
    m_beps722.DtlChckPmtInfNbOfTxs = sTemp;     //ҵ���������ϸ��Ŀ
    sprintf(sTemp, "%d", m_iMsgTtlCnt);
    m_beps722.DtlChckMsgNbOfTxs    = sTemp;     //��Ϣ����������ϸ��Ŀ

    //�鱨��
    iRet = m_beps722.CreateXml();
    if (0 != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "��722����ʧ��[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, "��722����ʧ��");    
    }

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sXMLBuff[%s]", m_beps722.m_sXMLBuff.c_str());
    
    //���ͱ���
	iRet = cMQAgent.PutMsg(sSendQueue, m_beps722.m_sXMLBuff.c_str(), m_beps722.m_sXMLBuff.length());
	if (0 != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "��722����PUTMQʧ��[%d]", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_MQ_ADD_FAIL, "��722����PUTMQʧ��");    
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CBpCheckSum::SndToNpcFor722()");
}

void CBpCheckSum::AddDetail(LPCSTR sSndRcvTp, LPCSTR sMsgTp)
{
    m_beps722.AddNodeToSubcycle("MT"       , m_szMT.c_str());
    m_beps722.AddNodeToSubcycle("SndRcvTp" , sSndRcvTp);
    m_beps722.AddNodeToSubcycle("PrcSts"   , m_szPrcSts.c_str());

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szMT[%s]",     m_szMT.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "sSndRcvTp[%s]",  sSndRcvTp);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szPrcSts[%s]", m_szPrcSts.c_str());
    
    if ( 0 == strcmp(sMsgTp, "PKG"))
    {
        m_beps722.AddNodeToSubcycle("TxNetgDt",  m_szTxNetgDt.c_str());
        m_beps722.AddNodeToSubcycle("TxNetgRnd", m_szTxNetgRnd.c_str());
        m_beps722.AddSubcycleToNode("DtlChckPmtDtls");

        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szTxNetgDt[%s]",  m_szTxNetgDt.c_str());
        Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_szTxNetgRnd[%s]", m_szTxNetgRnd.c_str());
    }
    else
    {
        m_beps722.AddSubcycleToNode("DtlChckMsgDtls");
    }
}

void CBpCheckSum::SetAllCtx()
{
    int iRet = -1;
    
    iRet = m_bpcheckcl.setctx(m_dbproc);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }

    iRet = m_checkaccount.setctx(m_dbproc);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
    }
}
