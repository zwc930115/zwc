/******************************************************************** 
�ļ����� recvcmt325.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-04-28
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvcmt325.h"

using namespace ZFPT;

CRecvCmt325::CRecvCmt325()
{
    m_strMsgTp	  = "CMT325";
    memset(m_sOldMsgId, 0x00, sizeof(m_sOldMsgId));
}

CRecvCmt325::~CRecvCmt325()
{
	
}

void CRecvCmt325::GetOrgnBuss()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CRecvCmt325::GetOrgnBuss");

    SETCTX(m_cOrgnBpcstpmtcxl);
    char m_sOrgnMsgId[35 + 1] = {0};
    sprintf(m_sOrgnMsgId, "%8s%08s", m_cmt325.sOldconsigndate, m_cmt325.sRevctmssno);        
    
    m_cBpcstpmtcxl.m_msgid = m_sOrgnMsgId ; 
    m_cBpcstpmtcxl.m_instgdrctpty = m_cmt325.sOldsendsapbk ; 
    
    int iRet = m_cOrgnBpcstpmtcxl.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��, iRet = %d", iRet, m_cOrgnBpcstpmtcxl.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CRecvCmt325::GetOrgnBuss"); 
}

INT32 CRecvCmt325::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CRecvCmt325::CheckValues");
    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CRecvCmt325::CheckValues"); 
    return OPERACT_SUCCESS;
}

void CRecvCmt325::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CRecvCmt325::SetData");

    char m_sMsgRefId[20 + 1] = {0};
  
    m_cBpcstpmtcxl.m_msgid = m_strMsgID; 
    
    m_cBpcstpmtcxl.m_instgdrctpty = "0000" ; 
    m_cBpcstpmtcxl.m_instddrctpty = m_cmt325.sOldrecvsapbk  ; 
    m_cBpcstpmtcxl.m_oricxlinstgdrctpty = m_cmt325.sOldsendsapbk ; 
    //m_cBpcstpmtcxl.m_addtlinf = m_cmt325.sRemark  ; 
	SetGbkToUtf8(m_cmt325.sRemark, m_cBpcstpmtcxl.m_addtlinf);
    m_cBpcstpmtcxl.m_procstate = "01"  ; 
    //m_cBpcstpmtcxl.m_proctime = m_cmt325.  ; 
    m_cBpcstpmtcxl.m_oriinstgdrctpty = m_cmt325.sOldsendsapbk  ; 

    char m_sOrgnMsgId[35 + 1] = {0};
    sprintf(m_sOrgnMsgId, "%8s%08s", m_cmt325.sOldpackdate, m_cmt325.sOldpackno);        
    m_cBpcstpmtcxl.m_orimsgid = m_sOrgnMsgId ; 
    
    m_cBpcstpmtcxl.m_orimsgtp = m_cmt325.sOldpacktype; 
    
    m_cBpcstpmtcxl.m_oricxlmsgid = m_sOrgnMsgId; 
    m_cBpcstpmtcxl.m_oricxlmsgtp = m_cmt325.sOldpacktype; 
        
    //m_cBpcstpmtcxl.m_prcsts = m_cmt325.  ; 
    //m_cBpcstpmtcxl.m_prccd = m_cmt325.  ; 
    //m_cBpcstpmtcxl.m_rjctinf = m_cmt325.  ; 
    //m_cBpcstpmtcxl.m_netgdt = m_cmt325.sNetdate  ; 
    //m_cBpcstpmtcxl.m_netgrnd = m_cmt325.sNetno  ; 
    //m_cBpcstpmtcxl.m_sttlmdt = m_cmt325.sSapdate  ; 

    m_cBpcstpmtcxl.m_workdate = m_strWorkDate  ; 
    
    m_cBpcstpmtcxl.m_msgtp = "CMT325"; 
    //m_cBpcstpmtcxl.m_mesgid = m_cmt325.m_CMTHeaderMap.mesgID;  ; 
    //m_cBpcstpmtcxl.m_mesgrefid = m_cmt325.m_CMTHeaderMap.mesgReqNo ; 

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_msgid[%s]",m_cBpcstpmtcxl.m_msgid.c_str());	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_instgdrctpty[%s]",m_cBpcstpmtcxl.m_instgdrctpty.c_str());	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_instddrctpty[%s]",m_cBpcstpmtcxl.m_instddrctpty.c_str());	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_oricxlinstgdrctpty[%s]",m_cBpcstpmtcxl.m_oricxlinstgdrctpty.c_str());	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_oricxlmsgid[%s]",m_cBpcstpmtcxl.m_oricxlmsgid.c_str());	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_oricxlmsgtp[%s]",m_cBpcstpmtcxl.m_oricxlmsgtp.c_str());	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_orimsgid[%s]",m_cBpcstpmtcxl.m_orimsgid.c_str());	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_mesgid[%s]",m_cBpcstpmtcxl.m_mesgid.c_str());	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_mesgrefid[%s]",m_cBpcstpmtcxl.m_mesgrefid.c_str());	

    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CRecvCmt325::SetData"); 
}


INT32 CRecvCmt325::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt325::Work()");	

	// ��������
	unPack(sMsg);

    // ҵ����
    CheckValues();
    
    SetData();
    
	InsertDb(sMsg);

	UpdateBusState();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt325::work()");

	return RTN_SUCCESS;
}

INT32 CRecvCmt325::unPack(LPCSTR sMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt325::unPack");	

    int iRet = RTN_FAIL;
    char sMsgId[35 + 1] = { 0 };

    // �����Ƿ�Ϊ��
    if (NULL == sMsg || '\0' == sMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }

    // ��������
    iRet = m_cmt325.ParseCmt(sMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������,iRet[%d]", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
    }

    // ���ı�ʶ�š�ϵͳ���
    sprintf(sMsgId, "%8s%08s", m_cmt325.sOldconsigndate, m_cmt325.sRevctmssno);
    m_strMsgID = sMsgId;
    ZFPTLOG.SetLogInfo("325", m_strMsgID.c_str());
            
    // ��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;      

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt325::unPack");	

    return RTN_SUCCESS;
}

INT32 CRecvCmt325::InsertDb(LPCSTR pchMsg)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt325::InsertDb");	

    // ��������
	SETCTX(m_cBpcstpmtcxl);

	// �������ݿ�
	int iRet = m_cBpcstpmtcxl.insert();
	if (0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "������ʧ��[%d][%s]",
		    iRet, m_cBpcstpmtcxl.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "������ʧ��");
	}

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt325::InsertDb");	

    return RTN_SUCCESS;
}

int CRecvCmt325::UpdateBusState(void)
{
	Trace(L_INFO, __FILE__, __LINE__,NULL, "Enter CRecvCmt325::UpdateBusState");

	string sqlCl;
	string sqlList;
	int iRet;
	if ( "003" == m_cBpcstpmtcxl.m_oricxlmsgtp)
	{
		GetSql("Bp_Bcoutrcvcl",sqlCl);		
		GetSql("Bp_Bcoutrecvlist",sqlList);
	}
	else if("004" == m_cBpcstpmtcxl.m_oricxlmsgtp)
	{
		GetSql("Bp_Bdrcvcl",sqlCl);		
		GetSql("Bp_Bdrecvlist",sqlList);
	}
	else
	{}

	Trace(L_ERROR, __FILE__, __LINE__, NULL,"sqlCl=[%s]", sqlCl.c_str());
	Trace(L_ERROR, __FILE__, __LINE__, NULL,"sqlList=[%s]", sqlList.c_str());
	
	SETCTX(m_cBpcstpmtcxl);
	iRet = m_cBpcstpmtcxl.execsql(sqlCl);
	if (iRet != SQL_SUCCESS
	&& 1403 != iRet)
	{
		sprintf(m_szErrMsg,  "����ԭ����ҵ��ʧ��[%d][%s]", 
			iRet, m_cBpcstpmtcxl.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}

	iRet = m_cBpcstpmtcxl.execsql(sqlList);
	if (iRet != SQL_SUCCESS
	&& 1403 != iRet)
	{
		sprintf(m_szErrMsg,  "����ԭ��ϸҵ��ʧ��[%d][%s]", 
			iRet, m_cBpcstpmtcxl.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}
	

	Trace(L_INFO, __FILE__, __LINE__,NULL, "Leave CRecvCmt325::UpdateBusState");

	return iRet;
}

void  CRecvCmt325::GetSql(const string strTableName,string &strSql)
{
	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Enter CRecvCmt325::UpdateBusState");

//	char szIOSdate[10 + 1] = {0};
//	chgToISODate(m_cBeps414.m_PMTSHeader.getOrigSendDate(), szIOSdate);  

	
	char cSql[1024] = {0};
	sprintf(cSql,"UPDATE %s t SET"
                            " t.busistate = 'PR22', t.procstate = '18' "
//                            " t.finalstatedate = '%s' "
                            " WHERE t.MSGID = '%s' AND t.INSTGDRCTPTY = '%s'",
                            strTableName.c_str(),
//                            szIOSdate,
                            m_cBpcstpmtcxl.m_oricxlmsgid.c_str(),
                            m_cBpcstpmtcxl.m_oricxlinstgdrctpty.c_str());
	
	strSql = cSql;
	return;
}


