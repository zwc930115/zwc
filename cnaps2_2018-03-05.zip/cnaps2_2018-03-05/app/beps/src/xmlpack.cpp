/********************************************************************
文件名：xmlback.cpp
创建人：zhj
日  期   ：2011-04-11
修改人：
日  期   ：
描  述   ：XML打包处理服务主控
版  本   ：
Copyright (c) 2011  YLINK
********************************************************************/

//#ifdef _LINUX_
//#define SQLCA_STORAGE_CLASS extern
//#include "sqlca.h"
//#endif
#include <sqlca.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <vector>

#include "exception.h"
#include "connectpool.h"
#include "configparser.h"
#include "thread.h"
#include "logger.h"
#include "cfg_obj.h"
#include "pubfunc.h"

#include "bpecc.h"

#include "xmlpackwork.h"
#include "bppkgassist.h"
#include "bpsapbankinfo.h" 


using namespace ZFPT;

#define MQ_ERR_MAX_TIMES    20

CConnectPool *g_DBConnPool;
CCfgObj      pCfgFile;

char g_MQmgr[256];
char g_MqTxtPath[256];
char g_SendQueue[128];
char g_SendCBSP[128];
int  g_IsConnCBSP;
char g_IP[16];

stuCfgInfo  CfgInfo;

/************************************************************************/
//加载配置文件
int LoadConfigFile(stuCfgInfo &CfgInfo);
//初始化环境
void InitEnv(void);
//
bool CheckSapBankXmlPack(CBpsapbankinfo& oCBpsapbankinfo, 
                         const char* pSapBank, char* pBuffer);
//                         
bool IsXmlPack(DBProc &dbProc, int &iListSum);
//
void getXmlPackInfo(DBProc &dbProc, vector<stPkgTab> &array, int iCount);
//
bool isRunTime(const char* pDateTime, int iTimeOut, char* pNowDateTime);
/************************************************************************/

int main(int argc, char **argv)
{
    char        szRecvMq[60]   = { 0 };
    char        sErrDesc[1024] = { 0 };
    int         iRet           = 0    ;
    DBProc      dbproc;
	int			iCount = 0;
	
	vector<stPkgTab> VArray;
	
	//屏蔽信号量
    signal(SIGINT , SIG_IGN); //屏蔽中断信号
    signal(SIGQUIT, SIG_IGN); //屏蔽终端退出信号
    signal(SIGALRM, SIG_IGN); //屏蔽超时信号
    signal(SIGHUP , SIG_IGN); //屏蔽连接断开信号
    signal(SIGSTOP, SIG_IGN); //这些信号被忽略
    //signal(SIGCHLD, SIG_IGN);

	CBppkgassist pCBppkgassist;//用于数据库回滚
	
	//初始化环境
	InitEnv();
	
    //轮询查看满足条件的待打包数据
    while(1){
        try{
        	iCount = 0;

		    if(0 != g_DBConnPool->GetConnect(dbproc))
			{	
		    	Trace(L_ERROR,  __FILE__,  __LINE__, 
		    	        NULL, "Get DB Connection Failed, Process Exit!");
		        exit(0);
		    }
			
        	//是否满足打包条件
			if( !IsXmlPack(dbproc, iCount) )
			{
			    g_DBConnPool->PutConnect(dbproc);
    
				sleep(1);//为了测试使用10秒
                continue;
			}

			//获取打包要素
			getXmlPackInfo(dbproc, VArray, iCount);

			for(int i = 0; i <  iCount; i++ ){
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
				    "VArray[%d].szWrkDate      =[%s]", i, VArray[i].szWrkDate);
				    
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
				    "VArray[%d].szSendBank     =[%s]", i, VArray[i].szSendBank);
				    
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
				    "VArray[%d].szRecvBank     =[%s]", i, VArray[i].szRecvBank);
				    
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
				    "VArray[%d].szMsgType      =[%s]", i, VArray[i].szMsgType);
				    
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
				    "VArray[%d].szMsgID        =[%s]", i, VArray[i].szMsgID);
				    
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
				    "VArray[%d].iListCount     =[%d]", i, VArray[i].iListCount);
				    
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
				    "VArray[%d].szHandPackFlag =[%s]", i, VArray[i].szHandPackFlag);
				    
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, 
				    "VArray[%d].szProstate     =[%s]", i, VArray[i].szProstate);				
			
				CXmlPackWork pCXmlPackWork;

				pCXmlPackWork.setData(VArray[i]);
				
				pCXmlPackWork.doWork();
				
			}//end for
        }
        catch(CException &e){		
            sprintf(sErrDesc, "Catch a exception from [%s %d][%s]",
                         e.file(), e.line(), e.what());

            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);
            
			//事物回滚
			pCBppkgassist.rollback();
            
            sleep(1);
        }

		//释放连接
	    g_DBConnPool->PutConnect(dbproc);
    }//end while
    
	g_DBConnPool->PutConnect(dbproc);
    return RTN_SUCCESS;
}


int LoadConfigFile(stuCfgInfo &CfgInfo)
{
    CConfigParser& cCfg = CConfigParser::getInstance();

    strcpy(CfgInfo.path, ZFPT_CFG_PATH);
    cCfg.loadConfig(CfgInfo.path);

	strncpy(CfgInfo.szXmlCtgPath, cCfg.getOption("XMLCTGPATH"), sizeof(CfgInfo.szXmlCtgPath)-1);
    strncpy(CfgInfo.szLogPath   , cCfg.getOption("LOGPATH")   , sizeof(CfgInfo.szLogPath)-1   );
    CfgInfo.iPort				= atoi(cCfg.getOption("BEPSPORT"));
    CfgInfo.iLogLeave			= atoi(cCfg.getOption("LOGLVL"));
	CfgInfo.dLogMaxSize			= atof(cCfg.getOption("LOGMAXSIZE"));

	memset(g_MQmgr     , 0x00, sizeof(g_MQmgr)    );
	memset(g_SendQueue , 0x00, sizeof(g_SendQueue));
	memset(g_MqTxtPath , 0x00, sizeof(g_MqTxtPath));
	strncpy(g_MQmgr    , cCfg.getOption("MQMGR")     , sizeof(g_MQmgr)-1    );
    //strncpy(g_SendQueue, cCfg.getOption("BEPSSENDMQ"), sizeof(g_SendQueue)-1);
    strncpy(g_SendQueue, cCfg.getOption("BEPSYALIMQ"), sizeof(g_SendQueue)-1);
    strncpy(g_MqTxtPath, cCfg.getOption("MQTEXTPATH"), sizeof(g_MqTxtPath)-1);
	
    CfgInfo.iConPoolMinNum		= atoi(cCfg.getOption("XMLCONNPOOLMINSIZE"));
    CfgInfo.iConPoolMaxNum		= atoi(cCfg.getOption("XMLCONNPOOLMAXSIZE"));
    CfgInfo.iNoConWaitTime		= atoi(cCfg.getOption("XMLNOCONNWAITTIME"));
    CfgInfo.iConPoolSize		= atoi(cCfg.getOption("XMLCONNPOOLSIZE"));
    CfgInfo.iThreadPoolSize		= atoi(cCfg.getOption("XMLTHREADPOOLSIZE"));
    CfgInfo.iThreadPoolTaskSize	= atoi(cCfg.getOption("XMLTHREADPOOLTASKSIZE"));

    strncpy(CfgInfo.DBUser,		cCfg.getOption("DBUSER"),sizeof(CfgInfo.DBUser)-1);
    //alter in 20171130
    CfgInfo.iDBKeyType = atoi(cCfg.getOption("DBKEYTYPE"));
    if (CfgInfo.iDBKeyType == 1) //密码为明文
    {
				strncpy(CfgInfo.DBKey, cCfg.getOption("DBKEY"), sizeof(CfgInfo.DBKey)-1);
    }
    if (CfgInfo.iDBKeyType == 0) //密码为密文
    {
				CfgInfo.DBKey_new.Format("%s", cCfg.getOption("DBKEY"));
				DecodeDBPsw(CfgInfo.DBKey_new);
				strncpy(CfgInfo.DBKey, CfgInfo.DBKey_new.GetBuffer(0), sizeof(CfgInfo.DBKey)-1);
    }
    //alter end
    strncpy(CfgInfo.DBName,		cCfg.getOption("DBNAME"),sizeof(CfgInfo.DBName)-1);

    strncpy(CfgInfo.szMqServConn  , cCfg.getOption("MQSERVCONN")  , sizeof(CfgInfo.szMqServConn) - 1  );
    strncpy(CfgInfo.szPmInfoHdFlg1, cCfg.getOption("PMINFOHDFLG1"), sizeof(CfgInfo.szPmInfoHdFlg1) - 1);
    strncpy(CfgInfo.szPmInfoHdFlg2, cCfg.getOption("PMINFOHDFLG2"), sizeof(CfgInfo.szPmInfoHdFlg2) - 1);
    strncpy(CfgInfo.szCbspRecvMQ  , cCfg.getOption("CBSPRECVMQ")  , sizeof(CfgInfo.szCbspRecvMQ) - 1  );    
    CfgInfo.iMqListener         = atoi(cCfg.getOption("MQLISTENER"));
    CfgInfo.iConnPlatm          = atoi(cCfg.getOption("ISCONNPLATM"));     
	
    return OPERACT_SUCCESS;
}

void InitEnv(void)
{
    int iRet = -1;
    
    try{
        //1.加载配置文件
        LoadConfigFile(CfgInfo);

        //2.初始化日志
		ZFPTLOG.setCfgInfo(CfgInfo.szLogPath, "xmlpack", (LOG_LEVEL)CfgInfo.iLogLeave, CfgInfo.dLogMaxSize);
		
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Init Log...");	

        //3.读XML配置文件
        iRet = pCfgFile.Init(CfgInfo.szXmlCtgPath);		//配置文件路径
        if(iRet != 0){
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
                "Failed to Init the node Config Object: ErrCode = %d, ErrInfo = %s", 
                pCfgFile.GetLastErrCode(),pCfgFile.GetLastErrInfo());
						
            exit(0);
        }
		
        //4.创建连接池 
        g_DBConnPool = new CConnectPool(CfgInfo.iConPoolMinNum, 
                        CfgInfo.iConPoolMaxNum, CfgInfo.iNoConWaitTime);
		
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Init Connection Pool...");    
	    
        iRet= g_DBConnPool->InitPool(CfgInfo.iConPoolSize, 
                    CfgInfo.DBUser, CfgInfo.DBKey, CfgInfo.DBName);
		
        if(iRet != RTN_SUCCESS){
            Trace(L_ERROR,  __FILE__,  __LINE__, 
                        NULL, "Create Connection Pool Failed!");
            exit(0);
        }
        
        Trace(L_INFO,  __FILE__,  __LINE__, 
                        NULL, "Create Connection Pool succeeded!");
                     

    	Trace(L_INFO, __FILE__, __LINE__, NULL, "Connect database sucessful.");                

    }
	catch(CException &e){
	    
	    
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, 
			"Init environment Catch a exception from [%s]",  e.what());
		
        exit(0);
    }
}

bool CheckSapBankXmlPack(CBpsapbankinfo& oCBpsapbankinfo, const char* pSapBank, char* pBuffer)
{
	bool bTimeOut = false;

	char sErrDesc[1024] = {0};

	oCBpsapbankinfo.m_sapbank = pSapBank;
	int iRetCode = oCBpsapbankinfo.findByPK();
	if (iRetCode != SQL_SUCCESS){
		sprintf(sErrDesc,"[bp_sapbankinfo]Query Failed [%s], [%d][%s]",
			oCBpsapbankinfo.m_sapbank.c_str(), iRetCode, oCBpsapbankinfo.GetSqlErr());

		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);

		PMTS_ThrowException(DB_NOT_FOUND);
	}
	
	//Trace(L_DEBUG, __FILE__, __LINE__, NULL, "sapbank=[%s]", oCBpsapbankinfo.m_sapbank.c_str());
	//Trace(L_DEBUG, __FILE__, __LINE__, NULL, "pkgnums=[%d]", oCBpsapbankinfo.m_pkgnums);
	//Trace(L_DEBUG, __FILE__, __LINE__, NULL, "pkgtimes=[%d]", oCBpsapbankinfo.m_pkgtimes);
	//Trace(L_DEBUG, __FILE__, __LINE__, NULL, "lasttime=[%s]", oCBpsapbankinfo.m_lasttimepack.c_str());
	
	//Trace(L_DEBUG, __FILE__, __LINE__, NULL, "sapbank=[%s] pkgtimes=[%d], pkgnums=[%d]",
	//    oCBpsapbankinfo.m_sapbank.c_str(), oCBpsapbankinfo.m_pkgtimes, oCBpsapbankinfo.m_pkgnums);

	char sNowDateTime[32] = {0};
	if( isRunTime(oCBpsapbankinfo.m_lasttimepack.c_str(), 
	                oCBpsapbankinfo.m_pkgtimes, sNowDateTime)){
		//更新小额清算行信息表打包时间
		sprintf(pBuffer,"update bp_sapbankinfo set "
					" lasttimepack = to_date('%s', 'yyyy-mm-dd hh24:mi:ss')"
					" where sapbank = '%s' ",
					sNowDateTime, pSapBank);
					
        //Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__pBuffer=[%s]", pBuffer);
        
		iRetCode = oCBpsapbankinfo.execsql(pBuffer);
		if (SQL_SUCCESS != iRetCode){
			sprintf(sErrDesc,"[bp_sapbankinfo]Update Failed,[%s][%s]",
				oCBpsapbankinfo.m_sapbank.c_str(), oCBpsapbankinfo.GetSqlErr());

			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);

			PMTS_ThrowException(DB_OPT_FAIL);
		}

		sprintf(pBuffer,"update bp_pkgassist set procstate ='02' "
					" where sendbank='%s' and procstate in ('00', '01') and listcount > 0 ",
					pSapBank);

		bTimeOut = true;
	}
	//2. 有手动打包或达量打包
	else{
		sprintf(pBuffer,"update bp_pkgassist set procstate ='02' "
						" where sendbank='%s' and procstate = '01' and listcount >=%d",
						pSapBank, oCBpsapbankinfo.m_pkgnums);
		bTimeOut = false;
	}

	return bTimeOut;
}

bool IsXmlPack(DBProc &dbProc, int &iListSum)
{

	int iRet = RTN_FAIL	;

	char	szSql[1024 + 1]  = {0};
	char	sErrDesc[1024 + 1] = {0};
	
	char	sNowDateTime[20 + 1]= {0}; 
	bool	bTimeOut		= false;
	
	//更新处理状态
	CBppkgassist  oCBppkgassist;
	oCBppkgassist.setctx(dbProc);

    CBpsapbankinfo oCBpsapbankinfo;
	oCBpsapbankinfo.setctx(dbProc);
	
	
	//清算行列表
	const char* szSapBanks[2] = {
			"501290000012"};
	
	bool bNoData = true;
	for(int i = 0; i < 1; ++i){
		try{
		    
			bTimeOut = CheckSapBankXmlPack(
					oCBpsapbankinfo, szSapBanks[i], szSql);
			iRet = oCBppkgassist.execsql(szSql);
			if(SQLNOTFOUND == iRet){
			    //Trace(L_DEBUG, __FILE__, __LINE__, NULL, "No Data:%s", szSql);
				oCBppkgassist.commit();
				continue;
			}
			else if (SQL_SUCCESS != iRet){
				sprintf(sErrDesc, "[bp_pkgassist]Update Failed, [%d][%s]",
						iRet, oCBppkgassist.GetSqlErr());

				Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);

				PMTS_ThrowException(DB_OPT_FAIL);
			}
			bNoData = false;
			oCBppkgassist.commit();
		}
		catch(CException &e){
			sprintf(sErrDesc, "Catch a exception from [%s %d][%s]",
						e.file(), e.line(), e.what());
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);

			//事物回滚
			oCBppkgassist.rollback();
		}
	}//end for


	//事物提交
	oCBppkgassist.commit();
	//if(bNoData){
	//    return false;
	//}
	
	string whereClause = "procstate ='02' ";
	iRet = oCBppkgassist.findcount(whereClause);
	if (SQL_SUCCESS != iRet) 
    {
        sprintf(sErrDesc, "[bp_pkgassist]Query Failed, [%d][%s]",
			iRet, oCBppkgassist.GetSqlErr());	
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);		

        PMTS_ThrowException(__FILE__, __LINE__, DB_FIND_BY_PK_FAIL, sErrDesc);
    }
	
	iListSum = oCBppkgassist.m_iCount;
	if(iListSum < 1){
	    return false;
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "%s amount, iListSum = [%d]", 
					bTimeOut?"Timeout Package" :"Reached Count Limit Or Manipulate", iListSum);
	return true;
}


void getXmlPackInfo(DBProc &dbProc, vector<stPkgTab> &array, int iCount)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering getXmlPackInfo()");	
	
	CBppkgassist oCBppkgassist		;
	int iRetCode		= RTN_FAIL	;

	stPkgTab    tmpPkgTab = {0};
	char sErrDesc[1024 + 1]= {0};
	char sSqlStr[4000 + 1] = {0};
	char sWorkDate[8 + 1]  = {0};
	char sMsgId[35 + 1]	   = {0};

	//动态分配容器大小,清空容器
	array.resize(iCount);
	array.clear();
	
	string whereClause = "procstate ='02' ";
	
	//查找出辅助表待打包记录并新增包记录
	iRetCode = oCBppkgassist.setctx(dbProc); 
    if(0 != iRetCode)                                                  {                                                                         
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "set connect failed!");     
        PMTS_ThrowException(DB_CNNCT_FAIL);                                   
    }
    
	iRetCode = oCBppkgassist.find(whereClause);
	if (SQL_SUCCESS != iRetCode) {
        sprintf(sErrDesc, "oCBppkgassist Query Failed, [%d][%s]",
			iRetCode, oCBppkgassist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, sErrDesc);

        PMTS_ThrowException(__FILE__, __LINE__, DB_FIND_BY_PK_FAIL, sErrDesc);
    }

	while(SQL_SUCCESS == iRetCode){
		memset(&tmpPkgTab, 0x00, sizeof(tmpPkgTab));
		iRetCode = oCBppkgassist.fetch();	
		if (SQLNOTFOUND == iRetCode){ 
			break;
		}
		else if (SQL_SUCCESS != iRetCode) {
			oCBppkgassist.closeCursor();
			
			sprintf(sErrDesc, "oCBppkgassist Fetch Failed, [%d][%s]",
				iRetCode, oCBppkgassist.GetSqlErr()); 
			
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, sErrDesc);
	
			PMTS_ThrowException(__FILE__, __LINE__, DB_FIND_BY_PK_FAIL, sErrDesc);
		}

		strncpy(tmpPkgTab.szWrkDate, oCBppkgassist.m_wrkdate.c_str(), 
		        sizeof(tmpPkgTab.szWrkDate) - 1);
		        
		strncpy(tmpPkgTab.szSendBank,oCBppkgassist.m_sendbank.c_str(),
		        sizeof(tmpPkgTab.szSendBank) - 1);
		        
		strncpy(tmpPkgTab.szRecvBank,oCBppkgassist.m_recvbank.c_str(),
		        sizeof(tmpPkgTab.szRecvBank) - 1);
		        
		strncpy(tmpPkgTab.szMsgType, oCBppkgassist.m_msgtype.c_str(), 
		        sizeof(tmpPkgTab.szMsgType) - 1);
		        
		strncpy(tmpPkgTab.szMsgID,   oCBppkgassist.m_msgid.c_str(),   
		        sizeof(tmpPkgTab.szMsgID) - 1);
		        
		tmpPkgTab.iListCount = oCBppkgassist.m_listcount;

		strncpy(tmpPkgTab.szIsRspn, oCBppkgassist.m_isrspn.c_str(), 
		        sizeof(tmpPkgTab.szIsRspn) - 1);
		        
		strncpy(tmpPkgTab.szIsAllRspn, oCBppkgassist.m_isallrspn.c_str(), 
		        sizeof(tmpPkgTab.szIsAllRspn) - 1);
		        
		tmpPkgTab.iPKGRtrltd = oCBppkgassist.m_pkgrtrltd;
		
		strncpy(tmpPkgTab.szPmttpPrtry, oCBppkgassist.m_pmttpprtry.c_str(), 
		        sizeof(tmpPkgTab.szPmttpPrtry) - 1);
		        
		strncpy(tmpPkgTab.szIssr, oCBppkgassist.m_issr.c_str(), 
		        sizeof(tmpPkgTab.szIssr) - 1);
		        
		strncpy(tmpPkgTab.szAcctId, oCBppkgassist.m_acctid.c_str(), 
		        sizeof(tmpPkgTab.szAcctId) - 1);
		        
		strncpy(tmpPkgTab.szOriMsgTp, oCBppkgassist.m_orimsgtp.c_str(), 
		        sizeof(tmpPkgTab.szOriMsgTp) - 1);
		        
		strncpy(tmpPkgTab.szOriMsgId, oCBppkgassist.m_orimsgid.c_str(), 
		        sizeof(tmpPkgTab.szOriMsgId) - 1);
		
		strncpy(tmpPkgTab.szProstate, oCBppkgassist.m_procstate.c_str(),
		         sizeof(tmpPkgTab.szProstate) - 1);
	
		array.push_back(tmpPkgTab);
			
	}//end while
	
	oCBppkgassist.closeCursor();
	
	//修正状态为正在打包
	string strSqlUd = "update bp_pkgassist set procstate='03' where procstate='02'";
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strSqlUd=[%s]", strSqlUd.c_str());
	iRetCode = oCBppkgassist.execsql(strSqlUd);
	if(iRetCode != SQL_SUCCESS){
	    Trace(L_ERROR, __FILE__, __LINE__, NULL, 
	        "[bp_pkgassist]Update Failed:[%s]", oCBppkgassist.GetSqlErr());
	    PMTS_ThrowException(DB_UPDATE_FAIL);
	}
    
    oCBppkgassist.commit();

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit getXmlPackInfo()");	
}


//将比较时间精确到分
bool isRunTime(const char* pDateTime, int iTimeOut, char* pNowDateTime)
{
	struct tm	*nowtime;
    time_t		longtime;
	
	char	sDay[2 + 1]		= {0};
	char	sHour[2 + 1]	= {0};
	char	sMin[2 + 1]		= {0};
	char	sSec[2 + 1]		= {0};

	int		iDay			=  0 ;
	int		iHour			=  0 ;
	int		iMin			=  0 ;
	int		iSec			=  0 ;

	int		iTotalMin		=  0 ;
	int		iTotalMin1		=  0 ;

	//日期格式110413143000
	memcpy(sDay , pDateTime + 4 , sizeof(sDay ) - 1);
	memcpy(sHour, pDateTime + 6 , sizeof(sHour) - 1);
	memcpy(sMin , pDateTime + 8 , sizeof(sMin ) - 1);
	memcpy(sSec , pDateTime + 10, sizeof(sSec ) - 1);
	
	iDay		= atoi(sDay );
	iHour		= atoi(sHour);
	iMin		= atoi(sMin );
	iSec		= atoi(sSec );
	
	//获取当前时间
    time(&longtime);
	nowtime		= localtime(&longtime);
    
    int iTmp = iTimeOut % 60 == 0 ? iTimeOut / 60: iTimeOut / 60 + 1;
    
	iTotalMin	= iHour*60 + iMin + iTmp;
	if(iDay == nowtime->tm_mday){//在同一日期内
		iTotalMin1	= nowtime->tm_hour*60 + nowtime->tm_min;
	}
	else{//不在同一日期内，最多认为为一天
		iTotalMin1	= 24*60 + nowtime->tm_hour*60 + nowtime->tm_min;
	}
	
	//Trace(L_DEBUG, __FILE__, __LINE__, NULL, "iTotalMin=%d, iTotalMin1=%d", 
	//    iTotalMin, iTotalMin1);
		
	if(iTotalMin > iTotalMin1){
		return false;
	}
	else{
		sprintf(pNowDateTime, "%04d-%02d-%02d %02d:%02d:%02d", 
							nowtime->tm_year+1900,
							nowtime->tm_mon+1,
							nowtime->tm_mday, 
							nowtime->tm_hour,
							nowtime->tm_min,
							nowtime->tm_sec);
		return true;
	}
}


