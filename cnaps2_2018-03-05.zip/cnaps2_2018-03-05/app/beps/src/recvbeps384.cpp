/******************************************************************** 
文件名： recvbeps384.cpp
创建人： aps-lel
日  期： 2011-04-09
修改人： 
日  期： 
描  述：小额来帐beps.384报文处理类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbeps384.h"


CRecvbeps384::CRecvbeps384()
{
    m_cBpcolltnchrgscl.m_msgtp = "beps.384.001.01";
    m_cBpcolltnchrgslist.m_msgtp = "beps.384.001.01";

}

CRecvbeps384::~CRecvbeps384()
{

}

int CRecvbeps384::Work(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps384::Work()...");

    // 解析报文
    unPack(szMsg);

	CheckArgeeAndUser();
	
    SetData(szMsg);
	
    // 插入数据
    InsertData();
	
	//数字核签
	CheckSign384();


	if(m_agreeanduser)
	{
		//实时回执一个报文
		Send385Msg();
		
		//385数据存入表
		Insert385Data();

	}
	else
	{
		Send388Msg();
	}

	m_IsSendMB = false;
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps384::Work()...");
	
    return OPERACT_SUCCESS;
}

void CRecvbeps384::Send388Msg()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "ENTER CRecvbeps384::SetRtuMsg");
   char szISOchDate[12 + 1]  = {0};
   char szchMsgId[128 +1] = {0};
   
   //获取ISOdate
   GetIsoDateTime(m_dbproc, SYS_BEPS, szISOchDate);
   
   //取msgid
   GetMsgIdValue(m_dbproc, szchMsgId, eMsgId, SYS_BEPS);

   bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);
   if(false == bRet)
   {
       Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "参数错误");
       PMTS_ThrowException(PRM_FAIL);
   }

   m_Bpbizpubntce.m_msgid = szchMsgId; 


    m_beps388.MsgId           = szchMsgId;//报文标识卿
    m_beps388.CreDtTm         = szISOchDate;//报文发送时长
    m_beps388.InstgDrctPty    = m_cBeps384.InstdDrctPty;//发起直接参与机构
    m_beps388.GrpHdrInstgPty  = m_cBeps384.InstdDrctPty;//间接发起参与机构
    m_beps388.InstdDrctPty    = m_cBeps384.InstgDrctPty;//接收直接参与机构
    m_beps388.GrpHdrInstdPty  = m_cBeps384.InstgDrctPty;//间接接收参与机构
    m_beps388.SysCd           = m_cBeps384.SysCd;//系统编号
    //m_beps388.Rmk           = m_colltnchrgscl387.m_rmk;//备注
    m_beps388.OrgnlMsgId      = m_cBeps384.MsgId;//原报文标识号
    m_beps388.OrgnlInstgPty   = m_cBeps384.InstgDrctPty;//原发起参与机朿
    m_beps388.OrgnlBtchNb     = m_cBeps384.BtchNb;//原报文类圿
    m_beps388.Sts             = "PR09";//业务状徿
    m_beps388.RjctCd          = "RJ90";
    m_beps388.RjctInf         = m_strErrDesc;

    // 组文件头
    m_beps388.CreateXMlHeader("BEPS",                        \
                                m_beps388.MsgId.substr(0, 8).c_str(), \
                                m_beps388.InstgDrctPty.c_str(),\
                                m_beps388.InstdDrctPty.c_str(),\                                
                                "beps.388.001.01",              \
                                m_sMsgRefId);
    AddSign388();
    m_beps388.CreateXml();
    AddQueue(m_beps388.m_sXMLBuff, m_beps388.m_sXMLBuff.size());

    //////////////////////////////////////////////////////////////////////////
    m_Bpbizpubntce.m_workdate = m_beps388.MsgId.substr(0, 8); 
    m_Bpbizpubntce.m_msgtp = "beps.388.001.01"; 
    m_Bpbizpubntce.m_status = m_beps388.Sts; 
    m_Bpbizpubntce.m_rjctcd = m_beps388.RjctCd; 
    m_Bpbizpubntce.m_rjctinf = m_beps388.RjctInf;    
    
   Insert388Data();

    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "LEAVE CRecvbeps384::SetRtuMsg");
    return ;
}

void CRecvbeps384::Insert388Data()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBeps384::Insert388Data()");

    m_Bpbizpubntce.m_mesgid = m_sMsgRefId; 
    m_Bpbizpubntce.m_mesgrefid = m_sMsgRefId; 
    m_Bpbizpubntce.m_instgdrctpty = m_cBeps384.InstdDrctPty; 
    m_Bpbizpubntce.m_instgpty = m_cBeps384.GrpHdrInstdPty; 
    m_Bpbizpubntce.m_instddrctpty = m_cBeps384.InstgDrctPty; 
    m_Bpbizpubntce.m_instdpty = m_cBeps384.GrpHdrInstgPty; 
    m_Bpbizpubntce.m_syscd = "BEPS"; 
    //m_Bpbizpubntce.m_rmk = ; 
    m_Bpbizpubntce.m_orgnlmsgid = m_cBeps384.MsgId; 
    m_Bpbizpubntce.m_orgnlinstgpty = m_cBeps384.GrpHdrInstgPty; 
	m_Bpbizpubntce.m_orgnlmt = "beps.384.001.01"; 
    m_Bpbizpubntce.m_orgnlbtchnb = atoi(m_cBeps384.BtchNb.c_str()); 
    //m_Bpbizpubntce.m_rjcprcpty = ; 
    m_Bpbizpubntce.m_procstate = PR_HVBP_08; //已回执
    m_Bpbizpubntce.m_proctime = ""; 
    m_Bpbizpubntce.m_addtlinf = ""; 

    SETCTX(m_Bpbizpubntce);
    int iRet = m_Bpbizpubntce.insert();
    if (OPERACT_SUCCESS != iRet)
    { 
        sprintf(m_szErrMsg,"insert() error,error code = [%d],error cause = [%s]",iRet,m_Bpbizpubntce.GetSqlErr());	  
        Trace(L_INFO,  __FILE__,	__LINE__, NULL, m_szErrMsg);	  
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL,m_szErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBeps384::Insert388Data()");
}

int CRecvbeps384::AddSign388()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbeps384::AddSign388...");

    int iRet = 0;
    char sOrigenStr[10240] = {0};
    char szDigitSign[10240 + 1] = {0};

    m_beps388.getOriSignStr();
    AddSign(m_beps388.m_sSignBuff.c_str(),szDigitSign,RAWSIGN,m_cBpcolltnchrgslist.m_instddrctpty.c_str());
    m_beps388.m_szDigitSign = szDigitSign;

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbeps384::AddSign388...");
    return RTN_SUCCESS;
}

INT32 CRecvbeps384::unPack(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps384::unPack()...");
    
    int iRet = -1;
    
    // 报文是否为空
    if (NULL == szMsg || '\0' == szMsg)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");	
    	PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "报文为空");
    }
    
    //获取工作日期
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(iRet != RTN_SUCCESS)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");	
    	PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;    

    // 解析报文
    if (OPERACT_SUCCESS != m_cBeps384.ParseXml(szMsg))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错! iRet= [%d]", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文解析出错!");
    }
	
	m_strMsgID = m_cBeps384.MsgId;
	
	//ZFPTLOG.SetLogInfo("384", m_strMsgID.c_str());
	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps384::unPack()...");
	
    return OPERACT_SUCCESS;
}

int CRecvbeps384::CheckArgeeAndUser()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbeps384::CheckArgeeAndUser()");


    if(!CheckUserState("beps.384.001.01",m_cBeps384.DbtrAcctId))
    {
        m_agreeanduser = false;
        return OPERACT_FAILED;
    } 

	m_agreeanduser = true;

    return OPERACT_SUCCESS;

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbeps384::CheckArgeeAndUser()");
}


INT32 CRecvbeps384::SetData(LPCSTR pchMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps384::SetData()");
   
	m_cBpcolltnchrgslist.m_msgid = m_cBeps384.MsgId		  ;//报文标识号 
	m_cBpcolltnchrgslist.m_workdate =  m_sWorkDate 	  ;//报文工作日期
	m_cBpcolltnchrgslist.m_consigdate = m_sWorkDate;
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.MsgId = [%s]",m_cBeps384.MsgId.c_str());
	//m_cBpcolltnchrgslist.m_c = m_cBeps384.CreDtTm 	  ;//报文发送时间	  
	m_cBpcolltnchrgslist.m_instgdrctpty= m_cBeps384.InstgDrctPty  ;//发起直接参与机构 
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.InstgDrctPty = [%s]",m_cBeps384.InstgDrctPty.c_str());
	m_cBpcolltnchrgslist.m_instgpty = m_cBeps384.GrpHdrInstgPty;//发起参与机构	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.GrpHdrInstgPty = [%s]",m_cBeps384.GrpHdrInstgPty.c_str());
	m_cBpcolltnchrgslist.m_instddrctpty = m_cBeps384.InstdDrctPty  ;//接收直接参与机构 
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.InstdDrctPty = [%s]",m_cBeps384.InstdDrctPty.c_str());
	m_cBpcolltnchrgslist.m_instdpty = m_cBeps384.GrpHdrInstdPty;//接收参与机构	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.GrpHdrInstdPty = [%s]",m_cBeps384.GrpHdrInstdPty.c_str());
	m_cBpcolltnchrgslist.m_syscd = m_cBeps384.SysCd		  ;//系统编号		  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.SysCd = [%s]",m_cBeps384.SysCd.c_str());
	m_cBpcolltnchrgslist.m_rmk = m_cBeps384.Rmk 		  ;//备注	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.Rmk = [%s]",m_cBeps384.Rmk.c_str());
	m_cBpcolltnchrgslist.m_srcflag = "2";//1：往帐 2：付款方来帐 3：收款方来帐
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.m_srcflag = [%s]",m_cBpcolltnchrgslist.m_srcflag.c_str());
	m_cBpcolltnchrgslist.m_btchnb = m_cBeps384.BtchNb		  ;//批次序号		  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.BtchNb = [%s]",m_cBeps384.BtchNb.c_str());
	m_cBpcolltnchrgslist.m_txid = m_cBeps384.TxId		  ;//明细标识号 	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.TxId = [%s]",m_cBeps384.TxId.c_str());
	m_cBpcolltnchrgslist.m_dbtrnm = m_cBeps384.DbtrNm		  ;//付款人户名 	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.DbtrNm = [%s]",m_cBeps384.DbtrNm.c_str());
	m_cBpcolltnchrgslist.m_dbtrid = m_cBeps384.DbtrAcctId	  ;//付款人账号 	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.DbtrAcctId = [%s]",m_cBeps384.DbtrAcctId.c_str());
	m_cBpcolltnchrgslist.m_dbtrmmbid = m_cBeps384.DbtrAgtMmbId  ;//付款清算行行号   
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.DbtrAgtMmbId = [%s]",m_cBeps384.DbtrAgtMmbId.c_str());
	m_cBpcolltnchrgslist.m_dbtrbrnchid = m_cBeps384.DbtrAgtId	  ;//付款行行号 	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.DbtrAgtId = [%s]",m_cBeps384.DbtrAgtId.c_str());
	m_cBpcolltnchrgslist.m_cdtrmmbid = m_cBeps384.CdtrAgtMmbId  ;//收款清算行行号   
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.CdtrAgtMmbId = [%s]",m_cBeps384.CdtrAgtMmbId.c_str());
	m_cBpcolltnchrgslist.m_cdtrbrnchid = m_cBeps384.CdtrAgtId	  ;//收款行行号 	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.CdtrAgtId = [%s]",m_cBeps384.CdtrAgtId.c_str());
	m_cBpcolltnchrgslist.m_cdtrnm = m_cBeps384.CdtrNm		  ;//收款人名称 	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.CdtrNm = [%s]",m_cBeps384.CdtrNm.c_str());
	m_cBpcolltnchrgslist.m_cdtrid = m_cBeps384.CdtrAcctId	  ;//收款人账号 
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.CdtrAcctId = [%s]",m_cBeps384.CdtrAcctId.c_str());
	m_cBpcolltnchrgslist.m_amout = atof(m_cBeps384.Amt.c_str()) 	;//货币金额		  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.m_amout = [%s]",m_cBeps384.Amt.c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.MsgId = [%s]",m_cBeps384.MsgId.c_str());
	m_cBpcolltnchrgslist.m_currency = m_cBeps384.Ccy 		  ;//货币符号		  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.Ccy = [%s]",m_cBeps384.Ccy.c_str());
	m_cBpcolltnchrgslist.m_ctgyprtry = m_cBeps384.CtgyPurpPrtry ;//业务类型编码	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.CtgyPurpPrtry = [%s]",m_cBeps384.CtgyPurpPrtry.c_str());
	m_cBpcolltnchrgslist.m_puryprtry = m_cBeps384.PurpPrtry	  ;//业务种类编码	  
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.PurpPrtry = [%s]",m_cBeps384.PurpPrtry.c_str());
	m_cBpcolltnchrgslist.m_endtoendid = m_cBeps384.EndToEndId	  ;//合同（协议）号
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.EndToEndId = [%s]",m_cBeps384.EndToEndId.c_str());

	if(m_agreeanduser)
	{
		m_cBpcolltnchrgslist.m_procstate = PR_HVBP_07;
	}
	else
	{
		m_cBpcolltnchrgslist.m_procstate = PR_HVBP_24;
	}
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.MsgId = [%s]",m_cBeps384.MsgId.c_str());
	m_cBpcolltnchrgslist.m_chckflg = m_cBeps384.ChckFlg 	  ;//核验标识	
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cBeps384.ChckFlg = [%s]",m_cBeps384.ChckFlg.c_str());

	char szFinalStateDate[32] = {0};
	chgToISODate(m_cBeps384.MsgId.substr(0, 8).c_str(), szFinalStateDate);
    m_cBpcolltnchrgslist.m_finalstatedate = szFinalStateDate;     
	m_cBpcolltnchrgslist.m_busistate = "PR00";

	//明细表插入数据
	SETCTX(m_cBpcolltnchrgslist);
	iRet = m_cBpcolltnchrgslist.insert();
	
	if(OPERACT_SUCCESS != iRet)
	{
		sprintf(m_szErrMsg,"insert() error,error code = [%d],error cause = [%s]",iRet,m_cBpcolltnchrgslist.GetSqlErr());
		
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, m_szErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL,m_szErrMsg);
				
	}

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps384::SetData()");
	
    return OPERACT_SUCCESS;
}

INT32 CRecvbeps384::InsertData()
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps384::InsertData()...");
    
	SETCTX(m_cBpcolltnchrgscl);
	m_cBpcolltnchrgscl.m_busistate = PROCESS_PR00;	
	m_cBpcolltnchrgscl.m_finalstatedate = m_cBeps384.CreDtTm.substr(0, 10);
	m_cBpcolltnchrgscl.m_instgdrctpty = m_cBeps384.InstgDrctPty  ;//发起直接参与机构 
	m_cBpcolltnchrgscl.m_instgpty = m_cBeps384.GrpHdrInstgPty ;//发起参与机构
	m_cBpcolltnchrgscl.m_workdate = m_sWorkDate;
	m_cBpcolltnchrgscl.m_btchnb = m_cBeps384.BtchNb		  ;//批次序号	
	m_cBpcolltnchrgscl.m_instddrctpty = m_cBeps384.InstdDrctPty  ;//接收直接参与机构 
	m_cBpcolltnchrgscl.m_instdpty = m_cBeps384.GrpHdrInstdPty;//接收参与机构
	m_cBpcolltnchrgscl.m_consigdate = m_sWorkDate;//委托日期
	//m_cBpcolltnchrgscl.m_dbtrnm = m_cBeps384.DbtrNm		  ;//付款人户名 	  
	//m_cBpcolltnchrgscl.m_dbtrid = m_cBeps384.DbtrAcctId	  ;//付款人账号 	  
	m_cBpcolltnchrgscl.m_dbtrmmbid = m_cBeps384.DbtrAgtMmbId  ;//付款清算行行号   
	//m_cBpcolltnchrgscl.m_dbtrbrnchid = m_cBeps384.DbtrAgtId	  ;//付款行行号 	  
	m_cBpcolltnchrgscl.m_cdtrmmbid = m_cBeps384.CdtrAgtMmbId  ;//收款清算行行号   
	m_cBpcolltnchrgscl.m_cdbtrbrnchid = m_cBeps384.CdtrAgtId	  ;//收款行行号 
	m_cBpcolltnchrgscl.m_cdbtrnm= m_cBeps384.CdtrNm		  ;//收款人名称 	  
	m_cBpcolltnchrgscl.m_cdbtrid = m_cBeps384.CdtrAcctId	  ;//收款人账号 	  
	m_cBpcolltnchrgscl.m_ttlamt = atof(m_cBeps384.Amt.c_str()) ;//货币金额		  
	m_cBpcolltnchrgscl.m_currency = m_cBeps384.Ccy 		  ;//货币符号		  
	m_cBpcolltnchrgscl.m_ctgyprtry = m_cBeps384.CtgyPurpPrtry ;//业务类型编码	  
	//m_cBpcolltnchrgscl.m_puryprtry = m_cBeps384.PurpPrtry	  ;//业务种类编码	  
	//m_cBpcolltnchrgscl.m_endtoendid = m_cBeps384.EndToEndId	  ;//合同（协议）号 
	m_cBpcolltnchrgscl.m_rmk = m_cBeps384.Rmk 		  ;//备注
	m_cBpcolltnchrgscl.m_srcflag = "2";//1：往帐 2：付款方来帐 3：收款方来帐
	m_cBpcolltnchrgscl.m_currency = "CNY";
	m_cBpcolltnchrgscl.m_procstate = m_cBpcolltnchrgslist.m_procstate;//已收妥

    if( m_agreeanduser)
    {
        m_cBpcolltnchrgscl.m_npcprcsts =  "PR02"; 
    }
    else
    {
        m_cBpcolltnchrgscl.m_npcprcsts = "PR09"; 
        m_cBpcolltnchrgscl.m_npcprccd  = "RJ90";
        m_cBpcolltnchrgscl.m_npcrjctinf= "其他";
    }
	
	m_cBpcolltnchrgscl.m_msgid = m_cBeps384.MsgId		  ;//报文标识号
	m_cBpcolltnchrgscl.m_syscd = "BEPS"		  ;//系统编号
	m_cBpcolltnchrgscl.m_checkstate= "1";
	m_cBpcolltnchrgscl.m_finalstatedate = m_cBpcolltnchrgslist.m_finalstatedate;
	//m_cBpcolltnchrgscl.m_txid = m_cBeps384.TxId		  ;//明细标识号 	    
	//m_cBpcolltnchrgscl.m_chckflg = m_cBeps384.ChckFlg 	  ;//核验标识	
	
    iRet = m_cBpcolltnchrgscl.insert();
	
    if (OPERACT_SUCCESS != iRet)
    {
      	
		sprintf(m_szErrMsg,"insert() error ,error code = [%d] error cause = [%s]",iRet,m_cBpcolltnchrgscl.GetSqlErr());		
		Trace(L_ERROR ,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL,m_szErrMsg);

    }
	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps384::InsertData()...");

	return OPERACT_SUCCESS;
}

void CRecvbeps384::CheckSign384()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbeps384::CheckSign384...");

	m_cBeps384.getOriSignStr();
	
	CheckSign(m_cBeps384.m_sSignBuff.c_str(),
			m_cBeps384.m_szDigitSign.c_str(),
			m_cBeps384.InstgDrctPty.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbeps384::CheckSign384...");
}

int CRecvbeps384::DigitSign()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbeps384::DigitSign...");

    int iRet = 0;
	char sOrigenStr[10240] = {0};
	char szDigitSign[40960 + 1] = {0};
    m_cBeps385.getOriSignStr();
    AddSign(m_cBeps385.m_sSignBuff.c_str(),szDigitSign,RAWSIGN,m_cBeps385.InstgDrctPty.c_str());
	m_cBeps385.m_szDigitSign = szDigitSign;

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbeps384::DigitSign...");
	return RTN_SUCCESS;
}

int CRecvbeps384::Send385Msg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps385::Send385Msg...");
    
	//取报文发送时间
    GetIsoDateTime(m_dbproc, SYS_BEPS, m_sIsoWorkDate);
	char szPkgno[9] = {0};//包序号
	char szAmont[22+1] = {0};
	
	//取报文标识号
	if(false == GetMsgIdValue(m_dbproc, m_sMsgId, eMsgId, SYS_BEPS ))
	{	
		PMTS_ThrowException( OPT_GET_MSGID_FAIL);
	}
		    
	if(false == GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS ))
	{
		Trace(L_INFO,  __FILE__,  __LINE__,NULL, "获取通信级参考号失败！");
		
		PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_MESGREFID_FAIL, "获取通信级参考号失败！");
	}
		
	m_cBeps385.CreateXMlHeader("BEPS", 
								m_sWorkDate,
								m_cBpcolltnchrgscl.m_instddrctpty.c_str(),								
								m_cBpcolltnchrgslist.m_cdtrbrnchid.c_str(),
				  				"beps.385.001.01",
				  				m_sMsgRefId);					  					
	

	m_cBeps385.MsgId		      = m_sMsgId ;
	m_cBeps385.CreDtTm 		  = m_sIsoWorkDate ;
	//m_cBeps385.InstgDrctPty	  = m_cBpcolltnchrgslist.m_instgdrctpty ;
	//m_cBeps385.GrpHdrInstgPty	  = m_cBpcolltnchrgslist.m_instgpty ;
	//m_cBeps385.InstdDrctPty	  = m_cBpcolltnchrgslist.m_instddrctpty ;
	//m_cBeps385.GrpHdrInstdPty	  = m_cBpcolltnchrgslist.m_instdpty ;

	m_cBeps385.InstgDrctPty	  = m_cBpcolltnchrgslist.m_instddrctpty ;
	m_cBeps385.GrpHdrInstgPty	  = m_cBpcolltnchrgslist.m_instdpty ;
	m_cBeps385.InstdDrctPty	  = m_cBpcolltnchrgslist.m_cdtrbrnchid ;
	m_cBeps385.GrpHdrInstdPty	  = m_cBpcolltnchrgslist.m_cdtrbrnchid ;

	
	m_cBeps385.SysCd			  = m_cBpcolltnchrgslist.m_syscd ;
	m_cBeps385.Rmk 			  = m_cBpcolltnchrgslist.m_rmk ;
	m_cBeps385.OrgnlMsgId		  = m_cBpcolltnchrgslist.m_msgid ;
	m_cBeps385.OrgnlInstgPty	  = m_cBpcolltnchrgslist.m_instgdrctpty ;
	m_cBeps385.OrgnlBtchNb 	  = m_cBpcolltnchrgslist.m_orgnlbtchnb ;
	//m_cBeps385.PrcSts		  = m_cBpcolltnchrgslist.m_pr
	//m_cBeps385.PrcCd			 
	//m_cBeps385.NPCPrcInfRjctInf 
	m_cBeps385.NetgDt			  = m_cBpcolltnchrgslist.m_netgdt ;
	m_cBeps385.NetgRnd 		  = m_cBpcolltnchrgslist.m_netgrnd ;
	//m_cBeps385.SttlmDt 		  = m_cBpcolltnchrgslist.m_finalstatedate ;//终态日期

	//m_cBeps385.PrcSts = "PR02" ;//终态日期
	//m_cBeps385.PrcCd = "PU1O0000"
	//m_cBeps385.RcvTm			 
	//m_cBeps385.TrnsmtTm	
	m_cBeps385.Sts              = "PR02";//已付款 PR09：已拒绝
	
	//m_cBeps385.RjctCd = "PU1O0000";//已付款 PR09：已拒绝
	//m_cBeps385.RspsnInfRjctInf = "yifukuan";
	m_cBeps385.Rmk = "yifukuan";
	m_cBeps385.PrcPty = "501290000012";
	
	//m_cBeps385.RjctCd			  = m_cBpcolltnchrgslist.m_busistate ;
	m_cBeps385.RspsnInfRjctInf  = m_cBpcolltnchrgslist.m_rjctinf ;
	m_cBeps385.PrcPty			  = m_cBpcolltnchrgslist.m_rjctprcpty ;//业务拒绝参与机构
	m_cBeps385.TxId             = m_cBpcolltnchrgslist.m_txid ;//原明细标识号
	m_cBeps385.DbtrNm			  = m_cBpcolltnchrgslist.m_dbtrnm ;
	m_cBeps385.DbtrAcctId		  = m_cBpcolltnchrgslist.m_dbtrid ;//付款人账号
	m_cBeps385.DbtrAgtId		  = m_cBpcolltnchrgslist.m_dbtrbrnchid ;//付款行号
	m_cBeps385.CdtrAgtId		  = m_cBpcolltnchrgslist.m_cdtrbrnchid ;//收款行号
	m_cBeps385.CdtrNm			  = m_cBpcolltnchrgslist.m_cdtrnm ;
	m_cBeps385.CdtrAcctId		  = m_cBpcolltnchrgslist.m_cdtrid ;
	m_cBeps385.Amt 			  = ftoa(szAmont,m_cBpcolltnchrgslist.m_amout) ;
	m_cBeps385.Ccy 			  = m_cBpcolltnchrgslist.m_currency ;
	m_cBeps385.CtgyPurpPrtry	  = m_cBpcolltnchrgslist.m_ctgyprtry ;//业务类型编码
	m_cBeps385.PurpPrtry		  = m_cBpcolltnchrgslist.m_puryprtry ;//业务种类编码
	m_cBeps385.OrgnlBtchNb        = m_cBeps384.BtchNb;
	//数字加签
    DigitSign();			

	int iRet = m_cBeps385.CreateXml();	
	if (0 != iRet)
	{		
		sprintf(m_szErrMsg,"创建往账报文失败iRet = [%d]! ",iRet);
		
		Trace(L_ERROR,  __FILE__,  __LINE__,m_sMsgId, m_szErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, m_szErrMsg);
	}	

		
	AddQueue(m_cBeps385.m_sXMLBuff,m_cBeps385.m_sXMLBuff.size());
		
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "leave CSendBeps385::Send385Msg..."); 
    
	return iRet;

}

int CRecvbeps384::Insert385Data()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps385::Insert385Data()...");

    char szPayerBankNm[256 + 1]   = { 0 };
    char szPayeeBankNm[256 + 1]   = { 0 };

    m_cBpcolltnchrgscl.m_procstate = PR_HVBP_08 ; 
    m_cBpcolltnchrgscl.m_workdate = m_strWorkDate ;   
    m_cBpcolltnchrgscl.m_consigdate = m_strWorkDate ; 
    m_cBpcolltnchrgscl.m_msgtp = "beps.385.001.01";
    m_cBpcolltnchrgscl.m_srcflag = "1";//1：往帐 2：付款方来帐 3：收款方来帐

    m_cBpcolltnchrgscl.m_mesgid = m_sMsgRefId; 
    m_cBpcolltnchrgscl.m_mesgrefid = m_sMsgRefId;
    m_cBpcolltnchrgscl.m_msgid = m_cBeps385.MsgId; 
    m_cBpcolltnchrgscl.m_instgdrctpty = m_cBeps385.InstgDrctPty; 
    m_cBpcolltnchrgscl.m_instgpty = m_cBeps385.GrpHdrInstgPty; 
    m_cBpcolltnchrgscl.m_instddrctpty = m_cBeps385.InstdDrctPty; 
    m_cBpcolltnchrgscl.m_instdpty = m_cBeps385.GrpHdrInstdPty; 
    m_cBpcolltnchrgscl.m_rmk = m_cBeps385.Rmk; 
    m_cBpcolltnchrgscl.m_syscd = m_cBeps385.SysCd;  

    m_cBpcolltnchrgscl.m_orgnlmsgid = m_cBeps385.OrgnlMsgId;// 原报文标识号
    m_cBpcolltnchrgscl.m_orgnlinstgpty = m_cBeps385.OrgnlInstgPty;//原发起参与机构
    m_cBpcolltnchrgscl.m_orgnlbtchnb = m_cBeps385.OrgnlBtchNb;//原批次序号
    m_cBpcolltnchrgscl.m_currency = m_cBeps385.Ccy;//原总金额货币符号

	m_cBpcolltnchrgscl.m_orgnlttlnb = 1;
	m_cBpcolltnchrgscl.m_orgnlttlam = atof(m_cBeps385.Amt.c_str());
	m_cBpcolltnchrgscl.m_rcvsndgttlamt = atof(m_cBeps385.Amt.c_str());
	m_cBpcolltnchrgscl.m_rcvsndgttlnb = 1; 

    m_cBpcolltnchrgscl.m_ctgyprtry = m_cBeps385.CtgyPurpPrtry;//业务类型编码
    m_cBpcolltnchrgscl.m_cdbtrid = m_cBeps385.CdtrAcctId;// 收款人账号
    m_cBpcolltnchrgscl.m_cdbtrnm = m_cBeps385.CdtrNm;//收款人名称
    m_cBpcolltnchrgscl.m_cdbtrbrnchid = m_cBeps385.CdtrAgtId;//收款行行号

    SETCTX(m_cBpcolltnchrgscl);
    int m_iRet = m_cBpcolltnchrgscl.insert();
    if (OPERACT_SUCCESS != m_iRet)
    {

        sprintf(m_szErrMsg,"insert() error ,error code = [%d] error cause = [%s]",m_iRet,m_cBpcolltnchrgscl.GetSqlErr());		
        Trace(L_ERROR ,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL,m_szErrMsg);

    }

    m_cBpcolltnchrgslist.m_procstate = PR_HVBP_08;
    m_cBpcolltnchrgslist.m_busistate = m_cBeps385.Sts;//业务状态
    m_cBpcolltnchrgslist.m_processcode = m_cBeps385.RjctCd;//业务拒绝处理码
    m_cBpcolltnchrgslist.m_rjctinf = m_cBeps385.RspsnInfRjctInf;//业务拒绝信息
    m_cBpcolltnchrgslist.m_rjctprcpty = m_cBeps385.PrcPty;//业务处理参与机构

    m_cBpcolltnchrgslist.m_msgid = m_cBeps385.MsgId;//报文标识号        	
    m_cBpcolltnchrgslist.m_instgpty = m_cBeps385.GrpHdrInstgPty; 
    m_cBpcolltnchrgslist.m_txid = m_cBeps385.TxId;//明细标识号        
    m_cBpcolltnchrgslist.m_dbtrnm = m_cBeps385.DbtrNm           ;//付款人户名
    m_cBpcolltnchrgslist.m_dbtrid = m_cBeps385.DbtrAcctId           ;//付款人账号
    m_cBpcolltnchrgslist.m_dbtrbrnchid = m_cBeps385.DbtrAgtId           ;//付款行行号
    m_cBpcolltnchrgslist.m_cdtrbrnchid = m_cBeps385.CdtrAgtId           ;//收款行行号
    m_cBpcolltnchrgslist.m_cdtrnm = m_cBeps385.CdtrNm;//收款人名称
    m_cBpcolltnchrgslist.m_cdtrid = m_cBeps385.CdtrAcctId;//收款人账号
    m_cBpcolltnchrgslist.m_currency = m_cBeps385.Ccy;//货币符号
    m_cBpcolltnchrgslist.m_amout = atof(m_cBeps385.Amt.c_str());//金额  
    m_cBpcolltnchrgslist.m_puryprtry = m_cBeps385.PurpPrtry;  //业务种类编码
    m_cBpcolltnchrgslist.m_srcflag = "1";//1：往帐 2：付款方来帐 3：收款方来帐

    //明细表插入数据
    SETCTX(m_cBpcolltnchrgslist);
    m_iRet = m_cBpcolltnchrgslist.insert();
    if(OPERACT_SUCCESS != m_iRet)
    {
        sprintf(m_szErrMsg,"insert() error,error code = [%d],error cause = [%s]",m_iRet,m_cBpcolltnchrgslist.GetSqlErr());
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL,m_szErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps385::Insert385Data()...");
    return OPERACT_SUCCESS;
}
