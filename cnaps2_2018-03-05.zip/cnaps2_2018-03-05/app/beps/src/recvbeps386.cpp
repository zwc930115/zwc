/******************************************************************** 
文件名： recvbeps386.cpp
创建人： aps-lel
修改人： 
日  期： 
描  述：小额来帐beps.386报文处理类
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbeps386.h"


CRecvbeps386::CRecvbeps386()
{
    m_cBpcolltnchrgscl.m_msgtp = "beps.386.001.01";
    m_cBpcolltnchrgslist.m_msgtp = "beps.386.001.01";
    memset(m_MsgRefId387, 0x00, sizeof(m_MsgRefId387));
}

CRecvbeps386::~CRecvbeps386()
{

}

int CRecvbeps386::Work(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps386::Work()...");

    // 解析报文
    unPack(szMsg);

	CheckArgeeAndUser();

    SetData(szMsg);
	
    // 插入数据
    InsertData();
	
	//数字核签
	CheckSign386();

	m_IsSendMB = false;    

    //if as the 
    if ("RT00" == m_cBeps386.RcvTp)//付款人开户行接收
    {
        SendRtuMsg();
    }
    else    //收款单位开户行接收
    {
        CreatePmtsMsg();
    }
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps386::Work()...");
		
    return OPERACT_SUCCESS;
}

int CRecvbeps386::CheckArgeeAndUser()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBeps386::CheckArgeeAndUser()");

    if ("RT00" == m_cBeps386.RcvTp)
    {
    	/*
		if(!CheckAgreemet(m_cBeps386.EndToEndId,"CT01",m_cBeps386.DbtrAcctId,"AS04"))
		{
			m_agreeanduser = false;
			return OPERACT_FAILED;
		}	
		*/
        if(!CheckUserState("beps.386.001.01",m_cBeps386.DbtrAcctId))
        {
            m_agreeanduser = false;
            return OPERACT_FAILED;
        } 
    }
    else
    {
    	/*
        if(!CheckAgreemet(m_cBeps386.EndToEndId,"CT01",m_cBeps386.CdtrAcctId,"AS04"))
        {
            m_agreeanduser = false;
            return OPERACT_FAILED;
        }	
        */
        if(!CheckUserState("beps.386.001.01",m_cBeps386.CdtrAcctId))
        {
            m_agreeanduser = false;
            return OPERACT_FAILED;
        } 
    }



    return OPERACT_SUCCESS;

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBeps386::CheckArgeeAndUser()");
}

INT32 CRecvbeps386::unPack(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps386::unPack()...");
    
    int iRet = -1;
    
    // 报文是否为空
    if (NULL == szMsg || '\0' == szMsg)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");	
    	PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "报文为空");
    }
    
    //获取工作日期
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(iRet != RTN_SUCCESS)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");	
    	PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;    

    // 解析报文
    if (OPERACT_SUCCESS != m_cBeps386.ParseXml(szMsg))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错! iRet= [%d]", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文解析出错!");
    }

	m_strMsgID = m_cBeps386.MsgId;
	
	//ZFPTLOG.SetLogInfo("386", m_strMsgID.c_str());
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps386::unPack()...");
	
    return OPERACT_SUCCESS;
}

INT32 CRecvbeps386::SetData(LPCSTR pchMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps386::SetData()");
	
	m_cBpcolltnchrgslist.m_workdate =  m_sWorkDate 	  ;//报文工作日期
	m_cBpcolltnchrgslist.m_consigdate = m_sWorkDate;    
	m_cBpcolltnchrgslist.m_msgid = m_cBeps386.MsgId		  ;//报文标识号 	
	//m_cBpcolltnchrgslist.m_c = m_cBeps386.CreDtTm 	  ;//报文发送时间	  
	m_cBpcolltnchrgslist.m_instgdrctpty= m_cBeps386.InstgDrctPty  ;//发起直接参与机构 
	m_cBpcolltnchrgslist.m_instgpty = m_cBeps386.GrpHdrInstgPty;//发起参与机构	  
    if ("RT01" == m_cBeps386.RcvTp)//付款人开户行接收
	{		
		m_cBpcolltnchrgslist.m_instddrctpty = m_cBeps386.m_PMTSHeader.getOrigReceiver();//接收直接参与机构 
		m_cBpcolltnchrgslist.m_instdpty = m_cBeps386.m_PMTSHeader.getOrigReceiver();//接收参与机构	  
		m_cBpcolltnchrgslist.m_instddrctpty = trim(m_cBpcolltnchrgslist.m_instddrctpty.c_str());
		m_cBpcolltnchrgslist.m_instdpty = trim(m_cBpcolltnchrgslist.m_instdpty.c_str());
	}
	else
	{
		m_cBpcolltnchrgslist.m_instddrctpty = m_cBeps386.InstdDrctPty  ;//接收直接参与机构 
		m_cBpcolltnchrgslist.m_instdpty = m_cBeps386.GrpHdrInstdPty;//接收参与机构	  
	}

    if ("RT00" == m_cBeps386.RcvTp
		&& m_agreeanduser == true)
    {
		m_cBpcolltnchrgslist.m_procstate = PR_HVBP_28;
    }
    else if("RT00" == m_cBeps386.RcvTp
		 && m_agreeanduser == false)    
    {
		m_cBpcolltnchrgslist.m_procstate = PR_HVBP_24;
    }
	else
	{
		m_cBpcolltnchrgslist.m_procstate = PR_HVBP_07;
	}

	
	Trim(m_cBpcolltnchrgslist.m_instddrctpty);//接收直接参与机构 
	Trim(m_cBpcolltnchrgslist.m_instdpty);//接收参与机构	  
	
	m_cBpcolltnchrgslist.m_syscd = m_cBeps386.SysCd		  ;//系统编号		  
	m_cBpcolltnchrgslist.m_rmk = m_cBeps386.Rmk 		  ;//备注			  
	m_cBpcolltnchrgslist.m_btchnb = m_cBeps386.BtchNb		  ;//批次序号		  
	m_cBpcolltnchrgslist.m_txid = m_cBeps386.TxId		  ;//明细标识号 	  
	m_cBpcolltnchrgslist.m_dbtrnm = m_cBeps386.DbtrNm		  ;//付款人户名 	  
	m_cBpcolltnchrgslist.m_dbtrid = m_cBeps386.DbtrAcctId	  ;//付款人账号 	  
	m_cBpcolltnchrgslist.m_dbtrmmbid = m_cBeps386.DbtrAgtMmbId  ;//付款清算行行号   
	m_cBpcolltnchrgslist.m_dbtrbrnchid = m_cBeps386.DbtrAgtId	  ;//付款行行号 	  
	m_cBpcolltnchrgslist.m_cdtrmmbid = m_cBeps386.CdtrAgtMmbId  ;//收款清算行行号   
	m_cBpcolltnchrgslist.m_cdtrbrnchid = m_cBeps386.CdtrAgtId	  ;//收款行行号 	  
	m_cBpcolltnchrgslist.m_cdtrnm = m_cBeps386.CdtrNm		  ;//收款人名称 	  
	m_cBpcolltnchrgslist.m_cdtrid = m_cBeps386.CdtrAcctId	  ;//收款人账号 	  
	m_cBpcolltnchrgslist.m_amout = atof(m_cBeps386.Amt.c_str())  ;//货币金额		  
	m_cBpcolltnchrgslist.m_currency = "CNY";//m_cBeps386.Ccy 		  ;//货币符号		  
	m_cBpcolltnchrgslist.m_ctgyprtry = m_cBeps386.CtgyPurpPrtry ;//业务类型编码	  
	m_cBpcolltnchrgslist.m_puryprtry = m_cBeps386.PurpPrtry	  ;//业务种类编码	  
	m_cBpcolltnchrgslist.m_endtoendid = m_cBeps386.EndToEndId	  ;//合同（协议）号   
	m_cBpcolltnchrgslist.m_chckflg = m_cBeps386.ChckFlg 	  ;//核验标识	

	char szFinalStateDate[32] = {0};
	chgToISODate(m_cBeps386.MsgId.substr(0, 8).c_str(), szFinalStateDate);
    m_cBpcolltnchrgslist.m_finalstatedate = szFinalStateDate;  
	
    if ("RT00" == m_cBeps386.RcvTp)//付款人开户行接收
    {
        m_cBpcolltnchrgslist.m_srcflag = "2";//业务来源 1：往帐 2：付款方来帐 3：收款方来帐
    }
    else    //收款单位开户行接收
    {
        m_cBpcolltnchrgslist.m_srcflag = "3";//业务来源 1：往帐 2：付款方来帐 3：收款方来帐
    }

	//明细表插入数据
	SETCTX(m_cBpcolltnchrgslist);
	iRet = m_cBpcolltnchrgslist.insert();
	
	if(OPERACT_SUCCESS != iRet)
	{
		sprintf(m_szErrMsg,"insert() error,error code = [%d],error cause = [%s]",iRet,m_cBpcolltnchrgslist.GetSqlErr());
		
	    Trace(L_INFO,  __FILE__,  __LINE__, NULL, m_szErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL,m_szErrMsg);
		
	}
   
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps386::SetData()");
	
    return OPERACT_SUCCESS;
}

INT32 CRecvbeps386::InsertData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps386::InsertData()...");
    
	m_cBpcolltnchrgscl.m_busistate = PROCESS_PR00;	
	m_cBpcolltnchrgscl.m_finalstatedate = m_cBeps386.CreDtTm.substr(0, 10);;
	m_cBpcolltnchrgscl.m_instgdrctpty = m_cBeps386.InstgDrctPty  ;//发起直接参与机构 
	
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cParser384.InstgDrctPty = [%s]",m_cBeps386.InstgDrctPty.c_str());
	m_cBpcolltnchrgscl.m_instgpty = m_cBeps386.GrpHdrInstgPty;//发起参与机构 

	m_cBpcolltnchrgscl.m_instddrctpty = m_cBpcolltnchrgslist.m_instddrctpty;//接收直接参与机构 
	m_cBpcolltnchrgscl.m_instdpty = m_cBpcolltnchrgslist.m_instdpty;//接收参与机构

	m_cBpcolltnchrgscl.m_workdate = m_sWorkDate;
	m_cBpcolltnchrgscl.m_btchnb = m_cBeps386.BtchNb		  ;//批次序号	
	m_cBpcolltnchrgscl.m_consigdate = m_sWorkDate ;//委托日期
	//m_cBpcolltnchrgscl.m_dbtrnm = m_cBeps386.DbtrNm		  ;//付款人户名 	  
	//m_cBpcolltnchrgscl.m_dbtrid = m_cBeps386.DbtrAcctId	  ;//付款人账号 	  
	m_cBpcolltnchrgscl.m_dbtrmmbid = m_cBeps386.DbtrAgtMmbId  ;//付款清算行行号   
	//m_cBpcolltnchrgscl.m_dbtrbrnchid = m_cBeps386.DbtrAgtId	  ;//付款行行号 	  
	m_cBpcolltnchrgscl.m_cdtrmmbid = m_cBeps386.CdtrAgtMmbId  ;//收款清算行行号   
	m_cBpcolltnchrgscl.m_cdbtrbrnchid = m_cBeps386.CdtrAgtId	  ;//收款行行号 
	m_cBpcolltnchrgscl.m_cdbtrnm= m_cBeps386.CdtrNm		  ;//收款人名称 	  
	m_cBpcolltnchrgscl.m_cdbtrid = m_cBeps386.CdtrAcctId	  ;//收款人账号 	  
	m_cBpcolltnchrgscl.m_ttlamt = atof(m_cBeps386.Amt.c_str()) ;//货币金额		  
	m_cBpcolltnchrgscl.m_currency = m_cBeps386.Ccy 		  ;//货币符号		
	m_cBpcolltnchrgscl.m_ctgyprtry = m_cBeps386.CtgyPurpPrtry ;//业务类型编码	  
	//m_cBpcolltnchrgscl.m_puryprtry = m_cBeps386.PurpPrtry	  ;//业务种类编码	  
	//m_cBpcolltnchrgscl.m_endtoendid = m_cBeps386.EndToEndId	  ;//合同（协议）号 
	m_cBpcolltnchrgscl.m_rmk = m_cBeps386.Rmk 		  ;//备注
	m_cBpcolltnchrgscl.m_procstate = m_cBpcolltnchrgslist.m_procstate;//因这里是直接回执,所以直接改为已回执
	
	m_cBpcolltnchrgscl.m_msgid = m_cBeps386.MsgId		  ;//报文标识号
	m_cBpcolltnchrgscl.m_syscd = "BEPS"		  ;//系统编号
	m_cBpcolltnchrgscl.m_checkstate= "1";
    m_cBpcolltnchrgscl.m_srcflag = m_cBpcolltnchrgslist.m_srcflag;
	m_cBpcolltnchrgscl.m_finalstatedate = m_cBpcolltnchrgslist.m_finalstatedate;
	m_cBpcolltnchrgscl.m_endtoendid = m_cBeps386.EndToEndId;
	m_cBpcolltnchrgscl.m_rcvtp = m_cBeps386.RcvTp;
	m_cBpcolltnchrgscl.m_chckflg = m_cBeps386.ChckFlg;

    if ("RT00" == m_cBeps386.RcvTp)//付款人开户行接收
    {
		if( m_agreeanduser)
		{
			m_cBpcolltnchrgscl.m_npcprcsts =  "PR02"; 
		}
		else
		{
			m_cBpcolltnchrgscl.m_npcprcsts = "PR09"; 
			m_cBpcolltnchrgscl.m_npcprccd  = "RJ90";
			m_cBpcolltnchrgscl.m_npcrjctinf= "其他";
		}
    }
    else    //收款单位开户行接收
    {
		if( m_agreeanduser)
		{
			m_cBpcolltnchrgscl.m_npcprcsts =  "PR02"; 
		}
		else
		{
			m_cBpcolltnchrgscl.m_npcprcsts = "PR09"; 
			m_cBpcolltnchrgscl.m_npcprccd  = "RJ90";
			m_cBpcolltnchrgscl.m_npcrjctinf= "其他";
		}
    }	

	
	SETCTX(m_cBpcolltnchrgscl);
    iRet = m_cBpcolltnchrgscl.insert();
    if (OPERACT_SUCCESS != iRet)
    {
	  sprintf(m_szErrMsg,"insert() error,error code = [%d],error cause = [%s]",iRet,m_cBpcolltnchrgscl.GetSqlErr());
	  Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
	  PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL,m_szErrMsg);
    }
	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps386::InsertData()...");
    return OPERACT_SUCCESS;
}

void CRecvbeps386::CheckSign386()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbeps386::CheckSign386...");

	m_cBeps386.getOriSignStr();
	
	CheckSign(m_cBeps386.m_sSignBuff.c_str(),
			m_cBeps386.m_szDigitSign.c_str(),
			m_cBeps386.InstgDrctPty.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbeps386::CheckSign386...");
}

void CRecvbeps386::SendRtuMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "ENTER CRecvbeps386::SetRtuMsg");
   char szISOchDate[12 + 1]  = {0};
   char szchMsgId[128 +1] = {0};
   
   //获取ISOdate
   GetIsoDateTime(m_dbproc, SYS_BEPS, szISOchDate);
   
   //取msgid
   GetMsgIdValue(m_dbproc, szchMsgId, eMsgId, SYS_BEPS);

   bool bRet = GetMsgIdValue(m_dbproc, m_MsgRefId387, eRefId, SYS_BEPS);
   if(false == bRet)
   {
       Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "参数错误");
       PMTS_ThrowException(PRM_FAIL);
   }

   m_Bpbizpubntce.m_msgid = szchMsgId; 
   if(m_agreeanduser)
   {
        m_beps389.MsgId           = szchMsgId;//报文标识卿
        m_beps389.CreDtTm         = szISOchDate;//报文发送时长
        m_beps389.InstgDrctPty    = m_cBeps386.InstdDrctPty;//发起直接参与机构
        m_beps389.GrpHdrInstgPty  = m_cBeps386.InstdDrctPty;//间接发起参与机构
        //m_beps389.InstdDrctPty    = m_cBeps386.InstgDrctPty;//接收直接参与机构
        //m_beps389.GrpHdrInstdPty  = m_cBeps386.InstgDrctPty;//间接接收参与机构

        m_beps389.InstdDrctPty    = "0000";//接收直接参与机构
        m_beps389.GrpHdrInstdPty  = "0000";//间接接收参与机构
		
        m_beps389.SysCd           = m_cBeps386.SysCd;//系统编号
        //m_beps389.Rmk             = m_colltnchrgscl387.m_rmk;//备注
        m_beps389.OrgnlMsgId      = m_cBeps386.MsgId;//原报文标识号
        m_beps389.OrgnlInstgPty   = m_cBeps386.InstgDrctPty;//原发起参与机朿
        m_beps389.OrgnlMT         = "beps.386.001.01";//原报文类圿
        m_beps389.Sts             = "PR02";//业务状徿
        m_beps389.RjctCd          = m_strErrCode; 
        m_beps389.RjctInf         = m_strErrDesc;
       
            // 组文件头
        /*
        m_beps389.CreateXMlHeader("BEPS",                        \
                                    m_beps389.MsgId.substr(0, 8).c_str(), \
                                    m_cBeps386.InstdDrctPty.c_str(),\
                                    m_cBeps386.InstgDrctPty.c_str(),\                                
                                    "beps.389.001.01",              \
                                    m_MsgRefId387);
		*/
        m_beps389.CreateXMlHeader("BEPS",                        \
                                    m_beps389.MsgId.substr(0, 8).c_str(), \
                                    m_beps389.InstgDrctPty.c_str(),\
                                    "0000",\                                
                                    "beps.389.001.01",              \
                                    m_MsgRefId387);

        AddSign389();
        m_beps389.CreateXml();
        
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "389[%s]",m_beps389.m_sXMLBuff.c_str());
        
        AddQueue(m_beps389.m_sXMLBuff, m_beps389.m_sXMLBuff.size());

        m_Bpbizpubntce.m_instddrctpty = "0000"; 
        m_Bpbizpubntce.m_instdpty = "0000"; 
        //////////////////////////////////////////////////////////////////////////
        m_Bpbizpubntce.m_workdate = m_beps389.MsgId.substr(0, 8); 
        m_Bpbizpubntce.m_msgtp = "beps.389.001.01"; 
        m_Bpbizpubntce.m_status = m_beps389.Sts; 
        m_Bpbizpubntce.m_rjctcd = m_beps389.RjctCd; 
        m_Bpbizpubntce.m_rjctinf = m_beps389.RjctInf; 

   }
   else
   {
        m_beps388.MsgId           = szchMsgId;//报文标识卿
        m_beps388.CreDtTm         = szISOchDate;//报文发送时长
        m_beps388.InstgDrctPty    = m_cBeps386.InstdDrctPty;//发起直接参与机构
        m_beps388.GrpHdrInstgPty  = m_cBeps386.InstdDrctPty;//间接发起参与机构
        m_beps388.InstdDrctPty    = m_cBeps386.InstgDrctPty;//接收直接参与机构
        m_beps388.GrpHdrInstdPty  = m_cBeps386.InstgDrctPty;//间接接收参与机构
        m_beps388.SysCd           = m_cBeps386.SysCd;//系统编号
        //m_beps388.Rmk           = m_colltnchrgscl387.m_rmk;//备注
        m_beps388.OrgnlMsgId      = m_cBeps386.MsgId;//原报文标识号
        m_beps388.OrgnlInstgPty   = m_cBeps386.InstgDrctPty;//原发起参与机朿
        m_beps388.OrgnlBtchNb     = m_cBeps386.BtchNb;//原报文类圿
        m_beps388.Sts             = "PR09";//业务状徿
        m_beps388.RjctCd          = "RJ90";
        m_beps388.RjctInf         = m_strErrDesc;

        // 组文件头
        m_beps388.CreateXMlHeader("BEPS",                        \
                                    m_beps388.MsgId.substr(0, 8).c_str(), \
                                    m_beps388.InstgDrctPty.c_str(),\
                                    m_beps388.InstdDrctPty.c_str(),\                                
                                    "beps.388.001.01",              \
                                    m_MsgRefId387);
        AddSign388();
        m_beps388.CreateXml();
        AddQueue(m_beps388.m_sXMLBuff, m_beps388.m_sXMLBuff.size());

        m_Bpbizpubntce.m_instddrctpty = m_beps388.InstdDrctPty; 
        m_Bpbizpubntce.m_instdpty = m_beps388.GrpHdrInstdPty; 
        //////////////////////////////////////////////////////////////////////////
        m_Bpbizpubntce.m_workdate = m_beps388.MsgId.substr(0, 8); 
        m_Bpbizpubntce.m_msgtp = "beps.388.001.01"; 
        m_Bpbizpubntce.m_status = m_beps388.Sts; 
        m_Bpbizpubntce.m_rjctcd = m_beps388.RjctCd; 
        m_Bpbizpubntce.m_rjctinf = m_beps388.RjctInf;         
   }
    
   InsertReturnData();

    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "LEAVE CRecvbeps386::SetRtuMsg");
    return ;
}

void CRecvbeps386::InsertReturnData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBeps381::InsertReturnData()");

    m_Bpbizpubntce.m_mesgid = m_MsgRefId387; 
    m_Bpbizpubntce.m_mesgrefid = m_MsgRefId387; 
    m_Bpbizpubntce.m_instgdrctpty = m_cBeps386.InstdDrctPty; 
    m_Bpbizpubntce.m_instgpty = m_cBeps386.GrpHdrInstdPty; 

    m_Bpbizpubntce.m_syscd = "BEPS"; 
    //m_Bpbizpubntce.m_rmk = ; 
    m_Bpbizpubntce.m_orgnlmsgid = m_cBeps386.MsgId; 
    m_Bpbizpubntce.m_orgnlinstgpty = m_cBeps386.GrpHdrInstgPty; 
    m_Bpbizpubntce.m_orgnlmt = "beps.386.001.01"; 
    m_Bpbizpubntce.m_orgnlbtchnb = atoi(m_cBeps386.BtchNb.c_str()); 
    //m_Bpbizpubntce.m_rjcprcpty = ; 
    m_Bpbizpubntce.m_procstate = PR_HVBP_08; //已回执
    m_Bpbizpubntce.m_proctime = ""; 
    m_Bpbizpubntce.m_addtlinf = ""; 

    SETCTX(m_Bpbizpubntce);
    int iRet = m_Bpbizpubntce.insert();
    if (OPERACT_SUCCESS != iRet)
    { 
        sprintf(m_szErrMsg,"insert() error,error code = [%d],error cause = [%s]",iRet,m_Bpbizpubntce.GetSqlErr());	  
        Trace(L_INFO,  __FILE__,	__LINE__, NULL, m_szErrMsg);	  
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL,m_szErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBeps381::InsertReturnData()");
}

int CRecvbeps386::CreatePmtsMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "enter CSendBeps385::CreatePmtsMsg...");
    
    GetIsoDateTime(m_dbproc,SYS_BEPS,m_sIsoWorkDate);
	
	char sErrordsc[1024] = {0};
	
	char szPkgno[9] = {0};//包序号
    char szMsgId[35 + 1] = {0};
	char sAmount[25] = {0};
	
	//取通信级ID
	if(false == GetMsgIdValue(m_dbproc, m_MsgRefId387, eRefId, SYS_BEPS))
	{
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, sErrordsc);
		PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_MSGID_FAIL, sErrordsc);
	}
	
    //取msgid
    GetMsgIdValue(m_dbproc, szMsgId, eMsgId, SYS_BEPS);

	m_cBeps387.CreateXMlHeader("BEPS", 
								m_sWorkDate,
								m_cBpcolltnchrgscl.m_instddrctpty.c_str(),
								m_cBeps386.InstdDrctPty.c_str(),
				  				"beps.387.001.01",
				  				m_MsgRefId387);

	m_cBeps387.MsgId			  = szMsgId ;
	m_cBeps387.CreDtTm		  = m_sIsoWorkDate ;
	m_cBeps387.InstdDrctPty	  = m_cBeps386.InstdDrctPty ;
	m_cBeps387.GrpHdrInstdPty   = m_cBeps386.GrpHdrInstdPty ;
	m_cBeps387.InstgDrctPty	  = m_cBpcolltnchrgslist.m_instddrctpty ;
	m_cBeps387.GrpHdrInstgPty   = m_cBpcolltnchrgslist.m_instdpty ;
	
	m_cBeps387.SysCd			  = m_cBpcolltnchrgslist.m_syscd ;
	m_cBeps387.Rmk			  = m_cBpcolltnchrgslist.m_rmk ;
	m_cBeps387.OrgnlMsgId 	  = m_cBpcolltnchrgslist.m_msgid ;
	m_cBeps387.OrgnlInstgPty	  = m_cBpcolltnchrgslist.m_instgdrctpty ;
	m_cBeps387.OrgnlBtchNb	  = m_cBpcolltnchrgslist.m_btchnb ;
	//m_cBeps387.PrcSts		  = m_cBpcolltnchrgslist.m_pr
	//m_cBeps387.PrcCd			 
	//m_cBeps387.NPCPrcInfRjctInf 
	m_cBeps387.NetgDt 		  = m_cBpcolltnchrgslist.m_netgdt ;
	m_cBeps387.NetgRnd		  = m_cBpcolltnchrgslist.m_netgrnd ;
	//m_cBeps387.SttlmDt		  = m_cBpcolltnchrgslist.m_finalstatedate ;//终态日期
	//m_cBeps387.RcvTm			 
	//m_cBeps387.TrnsmtTm 
	
	if(m_agreeanduser)
  {
  	m_cBeps387.Sts			  = "PR10";//已付款 PR09：已拒绝

  }
  else{
    m_cBeps387.Sts			  = "PR09";//已付款 PR09：已拒绝
    m_cBeps387.RjctCd = "RJ90";
    m_cBeps387.RspsnInfRjctInf  = "其他" ;
  }
	//m_cBeps387.RjctCd 		  = m_cBpcolltnchrgslist.m_busistate ;
	
	m_cBeps387.PrcPty 		  = m_cBpcolltnchrgslist.m_rjctprcpty ;//业务拒绝参与机构
	m_cBeps387.TxId			  = m_cBpcolltnchrgslist.m_txid ;//原明细标识号
	m_cBeps387.DbtrNm 		  = m_cBpcolltnchrgslist.m_dbtrnm ;
	m_cBeps387.DbtrAcctId 	  = m_cBpcolltnchrgslist.m_dbtrid ;//付款人账号
	m_cBeps387.DbtrAgtId		  = m_cBpcolltnchrgslist.m_dbtrbrnchid ;//付款行号
	m_cBeps387.CdtrAgtId		  = m_cBpcolltnchrgslist.m_cdtrbrnchid ;//收款行号
	m_cBeps387.CdtrNm 		  = m_cBpcolltnchrgslist.m_cdtrnm ;
	m_cBeps387.CdtrAcctId 	  = m_cBpcolltnchrgslist.m_cdtrid ;
	m_cBeps387.Amt			  = ftoa(sAmount,m_cBpcolltnchrgslist.m_amout) ;
	m_cBeps387.Ccy			  = m_cBpcolltnchrgslist.m_currency ;
	m_cBeps387.CtgyPurpPrtry	  = m_cBpcolltnchrgslist.m_ctgyprtry ;//业务类型编码
	m_cBeps387.PurpPrtry		  = m_cBpcolltnchrgslist.m_puryprtry ;//业务种类编码
	
	//数字加签
	AddSign387();
	int iRet = m_cBeps387.CreateXml();
	if (0 != iRet)
	{
		sprintf(sErrordsc,"创建往账报文失败iRet = [%d]! ",iRet);
		Trace(L_ERROR,  __FILE__,  __LINE__,m_sMsgId, sErrordsc);
		PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, sErrordsc);
	}
	
    Insert387Data();
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "387[%s]",m_cBeps387.m_sXMLBuff.c_str()); 
    
	  //AddQueue(m_cBeps387.m_sXMLBuff,m_cBeps387.m_sXMLBuff.size());

    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "leave CSendBeps385::CreatePmtsMsg..."); 
	return iRet;
}

void CRecvbeps386::Insert387Data()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBeps381::Insert387Data()");

    m_colltnchrgscl387.m_procstate = PR_HVBP_08 ; 
    m_colltnchrgscl387.m_workdate = m_strWorkDate ;   
    m_colltnchrgscl387.m_consigdate = m_strWorkDate ; 
    m_colltnchrgscl387.m_msgtp = "beps.387.001.01";
    m_colltnchrgscl387.m_srcflag = '1' ; //1：往帐 2：付款方来帐 3：收款方来帐

    m_colltnchrgscl387.m_mesgid = m_MsgRefId387; 
    m_colltnchrgscl387.m_mesgrefid = m_MsgRefId387;
    m_colltnchrgscl387.m_msgid = m_cBeps387.MsgId; 
    m_colltnchrgscl387.m_instgdrctpty = m_cBeps387.InstgDrctPty; 
    m_colltnchrgscl387.m_instgpty = m_cBeps387.GrpHdrInstgPty; 
    m_colltnchrgscl387.m_instddrctpty = m_cBeps387.InstdDrctPty; 
    m_colltnchrgscl387.m_instdpty = m_cBeps387.GrpHdrInstdPty; 
    m_colltnchrgscl387.m_rmk = m_cBeps387.Rmk; 
    m_colltnchrgscl387.m_syscd = m_cBeps387.SysCd;  
    m_colltnchrgscl387.m_btchnb = m_cBeps387.OrgnlBtchNb;

    m_colltnchrgscl387.m_dbtrmmbid = m_cBeps386.DbtrAgtMmbId;
    m_colltnchrgscl387.m_cdtrmmbid = m_cBeps386.CdtrAgtMmbId;
    m_colltnchrgscl387.m_orgnlmsgid = m_cBeps387.OrgnlMsgId;// 原报文标识号
    m_colltnchrgscl387.m_orgnlinstgpty = m_cBeps387.OrgnlInstgPty;//原发起参与机构
    m_colltnchrgscl387.m_orgnlbtchnb = m_cBeps387.OrgnlBtchNb;//原批次序号

    m_colltnchrgscl387.m_npcprcsts = m_cBeps387.Sts;//NPC处理状态
    m_colltnchrgscl387.m_npcprccd = m_cBeps387.RjctCd;//NPC处理码
    m_colltnchrgscl387.m_npcrjctinf = m_cBeps387.RspsnInfRjctInf;//NPC拒绝信息

	m_colltnchrgscl387.m_orgnlttlnb = 1;
	m_colltnchrgscl387.m_orgnlttlam = atof(m_cBeps387.Amt.c_str());
	m_colltnchrgscl387.m_rcvsndgttlamt = atof(m_cBeps387.Amt.c_str());
	m_colltnchrgscl387.m_rcvsndgttlnb = 1; 

    m_colltnchrgscl387.m_currency = m_cBeps387.Ccy;//成功收款总金额货币符号
    m_colltnchrgscl387.m_cdbtrid = m_cBeps387.DbtrAcctId;// 付款人账号
    m_colltnchrgscl387.m_cdbtrnm = m_cBeps387.DbtrNm;//付款人名称
    m_colltnchrgscl387.m_cdbtrbrnchid = m_cBeps387.DbtrAgtId;//付款行行号
    m_colltnchrgscl387.m_ctgyprtry = m_cBeps387.CtgyPurpPrtry;//业务类型编码
    m_colltnchrgscl387.m_checkstate = "1";

    SETCTX(m_colltnchrgscl387);
    int iRet = m_colltnchrgscl387.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__,  __LINE__, NULL, 
            "m_colltnchrgscl387.insert() failed:error code =[%d],error cause =[%s]", iRet,m_colltnchrgscl387.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "新增表失败");
    }

    SETCTX(m_colltnchrgslist387);
    m_colltnchrgslist387.m_instgdrctpty = m_cBeps387.InstgDrctPty; 
    m_colltnchrgslist387.m_instgpty = m_cBeps387.GrpHdrInstgPty; 
    m_colltnchrgslist387.m_instddrctpty = m_cBeps387.InstdDrctPty; 
    m_colltnchrgslist387.m_instdpty = m_cBeps387.GrpHdrInstdPty; 
    m_colltnchrgslist387.m_workdate = m_strWorkDate ;   
    m_colltnchrgslist387.m_consigdate = m_strWorkDate ; 
    m_colltnchrgslist387.m_msgtp = "beps.387.001.01";
    m_colltnchrgslist387.m_syscd = m_cBeps387.SysCd;  
    m_colltnchrgslist387.m_dbtrmmbid = m_cBeps386.DbtrAgtMmbId;
    m_colltnchrgslist387.m_cdtrmmbid = m_cBeps386.CdtrAgtMmbId;
    m_colltnchrgslist387.m_btchnb = m_cBeps387.OrgnlBtchNb;
    m_colltnchrgslist387.m_busistate = m_cBeps387.Sts;//业务状态
    m_colltnchrgslist387.m_processcode = m_cBeps387.RjctCd;//业务状态
    m_colltnchrgslist387.m_rjctinf = m_cBeps387.RspsnInfRjctInf;//业务拒绝信息
    m_colltnchrgslist387.m_rjctprcpty = m_cBeps387.PrcPty;//业务处理参与机构
    m_colltnchrgslist387.m_msgid = m_cBeps387.MsgId;//报文标识号        	
    m_colltnchrgslist387.m_instgpty = m_cBeps387.GrpHdrInstgPty; 
    m_colltnchrgslist387.m_txid = m_cBeps387.TxId;//明细标识号        
    m_colltnchrgslist387.m_dbtrnm = m_cBeps387.DbtrNm           ;//付款人户名
    m_colltnchrgslist387.m_dbtrid = m_cBeps387.DbtrAcctId           ;//付款人账号
    m_colltnchrgslist387.m_dbtrbrnchid = m_cBeps387.DbtrAgtId           ;//付款行行号
    m_colltnchrgslist387.m_cdtrbrnchid = m_cBeps387.CdtrAgtId           ;//收款行行号
    m_colltnchrgslist387.m_cdtrnm = m_cBeps387.CdtrNm;//收款人名称
    m_colltnchrgslist387.m_cdtrid = m_cBeps387.CdtrAcctId;//收款人账号
    m_colltnchrgslist387.m_currency = m_cBeps387.Ccy;//货币符号
    m_colltnchrgslist387.m_amout = atof(m_cBeps387.Amt.c_str());//金额  
    m_colltnchrgslist387.m_ctgyprtry = m_cBeps387.CtgyPurpPrtry;//业务类型编码
    m_colltnchrgslist387.m_puryprtry = m_cBeps387.PurpPrtry;  //业务种类编码  
    m_colltnchrgslist387.m_checkstate = "1";
    m_colltnchrgslist387.m_srcflag = "1";//1：往帐 2：付款方来帐 3：收款方来帐
    m_colltnchrgslist387.m_procstate = m_colltnchrgscl387.m_procstate;

    //明细表插入数据
    SETCTX(m_colltnchrgslist387);
    iRet = m_colltnchrgslist387.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__,  __LINE__, NULL, 
            "m_colltnchrgslist387.insert() failed:error code =[%d],error cause =[%s]", iRet,m_colltnchrgslist387.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "新增表失败");
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBeps381::Insert387Data()");
}
int CRecvbeps386::AddSign387()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbeps387::AddSign387...");

    int iRet = 0;
    char sOrigenStr[10240] = {0};
    char szDigitSign[10240 + 1] = {0};

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_instddrctpty=[%s]",m_cBpcolltnchrgslist.m_instddrctpty.c_str());

    m_cBeps387.getOriSignStr();
    AddSign(m_cBeps387.m_sSignBuff.c_str(),szDigitSign,RAWSIGN,m_cBpcolltnchrgslist.m_instddrctpty.c_str());
    m_cBeps387.m_szDigitSign = szDigitSign;

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbeps387::AddSign387...");
    return RTN_SUCCESS;
}

int CRecvbeps386::AddSign388()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbeps387::AddSign388...");

    int iRet = 0;
    char sOrigenStr[10240] = {0};
    char szDigitSign[10240 + 1] = {0};

    m_beps388.getOriSignStr();
    AddSign(m_beps388.m_sSignBuff.c_str(),szDigitSign,RAWSIGN,m_cBpcolltnchrgslist.m_instddrctpty.c_str());
    m_beps388.m_szDigitSign = szDigitSign;

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbeps387::AddSign388...");
    return RTN_SUCCESS;
}

int CRecvbeps386::AddSign389()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbeps387::AddSign389...");

    int iRet = 0;
    char sOrigenStr[10240] = {0};
    char szDigitSign[10240 + 1] = {0};

    m_beps389.getOriSignStr();
    AddSign(m_beps389.m_sSignBuff.c_str(),szDigitSign,RAWSIGN,m_cBpcolltnchrgslist.m_instddrctpty.c_str());
    m_beps389.m_szDigitSign = szDigitSign;

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvbeps387::AddSign389...");
    return RTN_SUCCESS;
}

STRING CRecvbeps386::Trim(STRING& sStr)
{
  if(sStr.length() < 0)
  {
		return sStr;
  }    

  //去掉字符串头部的空格
  string::size_type nBeginPos = 0;
  LPCSTR lpTmp = sStr.c_str();
  while(' ' == *lpTmp)
  {
    nBeginPos++;
    lpTmp++;
  }    

  //去掉字符串尾部的空格
  string::size_type nLen = strlen(lpTmp);
  while(nLen > 0 && ' ' == lpTmp[nLen - 1])
  {
    nLen--;
  }    

  sStr.erase(0, nBeginPos);
  sStr.erase(nLen);    

  return sStr;
}

