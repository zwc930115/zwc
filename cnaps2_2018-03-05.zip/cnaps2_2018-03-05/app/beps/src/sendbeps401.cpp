/******************************************************************** 
�ļ����� sendbeps401.cpp
�����ˣ� aps-lel	
��  �ڣ� 2011-04-25
�޸��ˣ� 
��  �ڣ� 
��  ���� С������beps.401���Ĵ�����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps401.h"


CSendBeps401::CSendBeps401(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{

}

CSendBeps401::~CSendBeps401()
{

}


INT32 CSendBeps401::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CSendBeps401::doWorkSelf");
    
    /*��ҵ����л�ȡ����*/
    
    GetData();
      
    
    /*��pmts����*/
    CreatePmtsMsg();
    
    
    /*����Զ�̶���*/
    AddQueue();
    
    
    /*�޸�״̬*/
    updateState();
    
    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "leave CSendBeps401::doWorkSelf..."); 
    return 0;
}


int CSendBeps401::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CSendBeps401::GetData...");
	
	SETCTX(m_cBprealtmcstacctmg);
	
  	m_cBprealtmcstacctmg.m_instgpty = m_sSendOrg;//���������
  	
  	m_cBprealtmcstacctmg.m_msgid = m_sMsgId;      
  	
  	iRet = m_cBprealtmcstacctmg.findByPK();
  	
  	if (OPERACT_SUCCESS != iRet)
	{
		sprintf(m_sErrMsg,"findByPK error ,error code = [%d],error cause = [%s]", iRet,m_cBprealtmcstacctmg.GetSqlErr());
		
		Trace(L_INFO,  __FILE__,  __LINE__,NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_FIND_BY_PK_FAIL, m_sErrMsg);
	} 	

    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "leave CSendBeps401::GetData..."); 
    
	return iRet;
}

int CSendBeps401::updateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CSendBeps401::updateState...");

	SETCTX(m_cBprealtmcstacctmg);

	
    string strSQL;
	
	strSQL += "UPDATE BP_REALTMCSTACCTMG  t SET t.PROCTIME = sysdate, t.PROCSTATE = '08'"; //02:��ת��
	strSQL += " WHERE t.MSGID = '";
	strSQL += m_cBprealtmcstacctmg.m_msgid.c_str();
	strSQL += "' AND t.instgpty = '";
	strSQL += m_cBprealtmcstacctmg.m_instgpty.c_str(); 
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());

	iRet = m_cBprealtmcstacctmg.execsql(strSQL.c_str());
    if(OPERACT_SUCCESS != iRet)
    {
		sprintf(m_sErrMsg,"execsql error,error code = [%d],error cause = [%s]",iRet,m_cBprealtmcstacctmg.GetSqlErr());
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_sErrMsg);

    }

    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "leave CSendBeps401::updateState...");
    return 0;
}

int CSendBeps401::CreatePmtsMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CSendBeps401::CreatePmtsMsg...");
	
    int iRet = GetIsoDateTime(m_dbproc,SYS_BEPS,m_sIsoWorkDate);
    if(iRet != SUCCESSED)
    {
		Trace(L_INFO,  __FILE__,  __LINE__,NULL, "��ȡ���ķ���ʱ��ʧ�ܣ�");		
		PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_SYS_DATETIME_FAIL, "��ȡ���ķ���ʱ��ʧ�ܣ�");       
    }
	
	//��ȡ����ͨѶ���
	if(false == GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS))
	{
		Trace(L_INFO,  __FILE__,  __LINE__,NULL, "��ȡ����ͨѶ���ʧ�ܣ�");		
		PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_MESGREFID_FAIL, "��ȡ����ͨѶ���ʧ�ܣ�");
	}
	
	m_beps401.CreateXMlHeader("BEPS", 
								m_sWorkDate,
								m_cBprealtmcstacctmg.m_instgdrctpty.c_str(),
								m_cBprealtmcstacctmg.m_instddrctpty.c_str(),
				  				"beps.401.001.01",
				  				m_sMsgRefId);
				  					
	m_beps401.MsgId			     = m_cBprealtmcstacctmg.m_msgid ;
	m_beps401.CreDtTm 		     = m_sIsoWorkDate ;
	m_beps401.InstgDrctPty	     = m_cBprealtmcstacctmg.m_instgdrctpty ;
	m_beps401.GrpHdrInstgPty	 = m_cBprealtmcstacctmg.m_instgpty ;
	m_beps401.InstdDrctPty	     = m_cBprealtmcstacctmg.m_instddrctpty ;
	m_beps401.GrpHdrInstdPty	 = m_cBprealtmcstacctmg.m_instdpty ;
	m_beps401.SysCd			     = m_cBprealtmcstacctmg.m_syscd ;
	m_beps401.Rmk 			     = m_cBprealtmcstacctmg.m_rmk ;

	m_beps401.AcctPmtTp          = m_cBprealtmcstacctmg.m_acctpmttp;// �˻�֧������
	m_beps401.AcctId             = m_cBprealtmcstacctmg.m_acctid;// �ͻ��˻��˺�
	m_beps401.AcctNm             = m_cBprealtmcstacctmg.m_acctnm;// �ͻ��˻�����
	m_beps401.ChckMd             = m_cBprealtmcstacctmg.m_chckmd;// У��ģʽ��������֤���㷨��
	char szTemp[8+1] = {0};
    sprintf(szTemp,"%08d",m_cBprealtmcstacctmg.m_chckcdlen);
	m_beps401.ChckCdLen          = szTemp;// ������֤�볤��
	m_beps401.Cntt               = m_cBprealtmcstacctmg.m_chckcdcntt;// ������֤��ֵ
	m_beps401.QryBalOrStsTp      = m_cBprealtmcstacctmg.m_qrybalorststp;// ��ѯ����״̬
	
	// ��ǩ
	AddSign401();
	
	iRet = m_beps401.CreateXml();
	
	if (0 != iRet)
	{
		
		sprintf(m_sErrMsg,"�������˱���ʧ��iRet = [%d]! ",iRet);
		
		Trace(L_INFO,  __FILE__,  __LINE__,NULL, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, m_sErrMsg);
	}
	
	
	m_sMsgTxt = m_beps401.m_sXMLBuff ;
	
	
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "leave CSendBeps401::CreatePmtsMsg..."); 
    
	return iRet;
}

void CSendBeps401::AddSign401()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms401::AddSign401");
	
	char   sSignedStr[4096 + 1] = {0};
	
	m_beps401.getOriSignStr();
	
	AddSign(m_beps401.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_cBprealtmcstacctmg.m_instgdrctpty.c_str());
	
	m_beps401.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms401::AddSign401");
}


