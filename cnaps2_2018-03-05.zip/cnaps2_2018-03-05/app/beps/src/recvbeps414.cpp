/*
 * 	recvbeps414.cpp
 *	Description: ʵʱ����Ӧ����beps.414.001.01������
 *  Created on: 2012-07-09
 *  Author: __wsh
 */

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbeps414.h"

using namespace ZFPT;

CRecvBeps414::CRecvBeps414()
{
}

CRecvBeps414::~CRecvBeps414()
{
}

//__wsh 2012-07-09 ҵ�������
INT32 CRecvBeps414::Work(LPCSTR szMsg)
{
	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Enter CRecvBeps414::Work");
	int iRet = 0;

	//����XML����
	UnPack(szMsg);

	//����ʵʱ����ʵ��������
	SetData();

	//��¼���ݿ�
	InsertData();

	//��ǩ
	CheckSign414();

	//����ԭҵ��״̬
	UpdateOrgnBiz();

	//��������ɹ����±�����ҵ��״̬Ϊ�ѳ���
	if(PROCESS_PR05 == m_cBeps414.PrcSts)
	{
		UpdateBusState();
	}

	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Leave CRecvBeps414::Work");

	return iRet;
}
//__wsh 2012-07-09 ����XML����
int CRecvBeps414::UnPack(LPCSTR szMsg)
{
	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Enter CRecvBeps414::UnPack");
	int iRet = -1;

	if(NULL == szMsg || '\0' == szMsg[0]){
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "���ĳ���Ϊ��");
		PMTS_ThrowException(PRM_FAIL);
	}

	//��������
	iRet = m_cBeps414.ParseXml(szMsg);
	if (OPERACT_SUCCESS != iRet){
		Trace(L_ERROR,  __FILE__,  __LINE__,
				NULL, "���Ľ�������! iRet= %d", iRet);

		PMTS_ThrowException(__FILE__, __LINE__,
				OPT_PRS_MSG_FAIL, "���Ľ�������");
	}

	//��ȡ��������
	iRet = GetWorkDate(m_dbproc, m_sWorkDate,
			SYS_BEPS, m_cBeps414.InstdDrctPty.c_str());
	if(RTN_SUCCESS != iRet){
		Trace(L_ERROR,  __FILE__, __LINE__,
				NULL, "��ȡ��������ʧ�ܣ�");
		PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
	}
	m_strWorkDate = m_sWorkDate;

	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Leave CRecvBeps414::UnPack");

	return OPERACT_SUCCESS;
}

//__wsh 2012-07-09 ����ʵ��������
void CRecvBeps414::SetData(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Enter CRecvBeps414::SetData");

	m_cpc.m_workdate 	= m_strWorkDate;	 //��������
	m_cpc.m_msgtp 		= m_cBeps414.m_PMTSHeader.getMesgType(); //��������
	m_cpc.m_mesgid		= m_cBeps414.m_PMTSHeader.getMesgID();   //ͨ�ż���ʶ
	m_cpc.m_mesgrefid	= m_cBeps414.m_PMTSHeader.getMesgRefID();//ͨ�Ųο���
	m_cpc.m_msgid		= m_cBeps414.MsgId;	       //���ı�ʶ
	m_cpc.m_instgdrctpty= m_cBeps414.InstgDrctPty; //����ֱ�Ӳ�����
	m_cpc.m_instddrctpty= m_cBeps414.InstdDrctPty; //����ֱ�Ӳ�����
	m_cpc.m_procstate   = PR_HVBP_01; //����״̬�� ������

	//ԭ������Ϣ
	m_cpc.m_orimsgid = m_cBeps414.RealTmBizRvslRspnOrgnlMsgId;
	m_cpc.m_oriinstgdrctpty = m_cBeps414.RealTmBizRvslRspnOrgnlInstgPty;
	m_cpc.m_orimsgtp = m_cBeps414.RealTmBizRvslRspnOrgnlMT;

	//NPC������Ϣ
	m_cpc.m_prcsts = m_cBeps414.PrcSts;
	m_cpc.m_prccd  = m_cBeps414.PrcCd;
	m_cpc.m_rjctinf= m_cBeps414.RjctInf;
	m_cpc.m_netgdt = m_cBeps414.NetgDt;
	m_cpc.m_netgrnd= m_cBeps414.NetgRnd;
	m_cpc.m_sttlmdt= m_cBeps414.SttlmDt;

	//������ҵ����Ϣ
	m_cpc.m_oricxlmsgid = m_cBeps414.OrgnlTxOrgnlMsgId;
	m_cpc.m_oricxlinstgdrctpty = m_cBeps414.OrgnlTxOrgnlInstgPty;
	m_cpc.m_oricxlmsgtp = m_cBeps414.OrgnlTxOrgnlMT;

	Trace(L_INFO, __FILE__, __LINE__,
						NULL, "Leave CRecvBeps414::SetData");
}

//__wsh 2012-07-09 ��¼���ݿ�
int CRecvBeps414::InsertData(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Enter CRecvBeps414::InsertData");
	int iRet = -1;

	SETCTX(m_cpc);
	iRet = m_cpc.insert();
	if(iRet != SQL_SUCCESS){
		char szErr[512] = {0};
		sprintf(szErr, "[bp_cstpmtcxl]���������iRet=%d cause=%s",
						iRet, m_cpc.GetSqlErr());

		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErr);

		PMTS_ThrowException(DB_INSERT_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Leave CRecvBeps414::InsertData");

	return iRet;
}
//__wsh 2012-07-09 ���±�����ҵ��״̬
int CRecvBeps414::UpdateBusState(void)
{
	Trace(L_INFO, __FILE__, __LINE__,NULL, "Enter CRecvBeps414::UpdateBusState");

	string sqlCl;
	string sqlList;
	int iRet;
	if ( "beps.123.001.01" == m_cpc.m_oricxlmsgtp)
	{
		GetSql("Bp_Bcoutsndcl",sqlCl);		
		GetSql("Bp_Bcoutsendlist",sqlList);
	}
	else if("beps.131.001.01" == m_cpc.m_oricxlmsgtp)
	{
		GetSql("Bp_Bdsndcl",sqlCl);		
		GetSql("Bp_Bdsendlist",sqlList);
	}
	else
	{}

	Trace(L_ERROR, __FILE__, __LINE__, NULL,"sqlCl=[%s]", sqlCl.c_str());
	Trace(L_ERROR, __FILE__, __LINE__, NULL,"sqlList=[%s]", sqlList.c_str());
	
	SETCTX(m_entitybase);
	iRet = m_entitybase.execsql(sqlCl);
	if (iRet != SQL_SUCCESS)
	{
		sprintf(m_szErrMsg,  "����ԭ����ҵ��ʧ��[%d][%s]", 
			iRet, m_entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}

	iRet = m_entitybase.execsql(sqlList);
	if (iRet != SQL_SUCCESS)
	{
		sprintf(m_szErrMsg,  "����ԭ��ϸҵ��ʧ��[%d][%s]", 
			iRet, m_entitybase.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}

	Trace(L_INFO, __FILE__, __LINE__,NULL, "Leave CRecvBeps414::UpdateBusState");

	return iRet;
}

void  CRecvBeps414::GetSql(const string strTableName,string &strSql)
{
	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Enter CRecvBeps414::UpdateBusState");

	char szIOSdate[10 + 1] = {0};
	chgToISODate(m_cBeps414.m_PMTSHeader.getOrigSendDate(), szIOSdate);  

	
	char cSql[1024] = {0};
	sprintf(cSql,"UPDATE %s t SET"
                            " t.busistate = 'PR22', t.procstate = '18',"
                            " t.finalstatedate = '%s' "
                            " WHERE t.MSGID = '%s' AND t.INSTGDRCTPTY = '%s'",
                            strTableName.c_str(),
                            szIOSdate,
                            m_cpc.m_oricxlmsgid.c_str(),
                            m_cpc.m_oricxlinstgdrctpty.c_str());
	
	strSql = cSql;
	return;
}
//__wsh 2012-07-09 ����ԭҵ��״̬
int CRecvBeps414::UpdateOrgnBiz(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Enter CRecvBeps414::UpdateOrgnBiz");

	int iRet = -1;

	string strProcState = (m_cBeps414.PrcSts == "PR05") ?
			PR_HVBP_07 : PR_HVBP_24;
    string strBizSts = (m_cBeps414.PrcSts == "PR05") ? "PR22" : "PR09";
	string strSql = "update bp_cstpmtcxl set procstate='";
	strSql += strProcState;
	strSql += "', prcsts='";
	strSql += strBizSts;
	strSql += "', prccd='";
	strSql += m_cBeps414.PrcCd;
	strSql += "', rjctinf='";
	strSql += m_cBeps414.RjctInf;
	strSql += "', proctime=sysdate where msgid='";
	strSql += m_cBeps414.RealTmBizRvslRspnOrgnlMsgId;
	strSql += "' and instgdrctpty='";
	strSql += m_cBeps414.RealTmBizRvslRspnOrgnlInstgPty;
	strSql += "' and msgtp='";
	strSql += m_cBeps414.RealTmBizRvslRspnOrgnlMT;
	strSql += "' ";

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strSql=%s", strSql.c_str());

	iRet = m_cpc.execsql(strSql);
	if(iRet != SQL_SUCCESS){
		char szErr[512] = {0};
		sprintf(szErr, "[bp_cstpmtcxl]���³�����iRet=%d cause=%s",
						iRet, m_cpc.GetSqlErr());

		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErr);

		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Leave CRecvBeps414::UpdateOrgnBiz");

	return iRet;
}

//__wsh 2012-07-09 ��ǩ
void CRecvBeps414::CheckSign414()
{
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CRecvBeps414::CheckSign414");
	
	m_cBeps414.getOriSignStr();
	
	CheckSign(m_cBeps414.m_sSignBuff.c_str(),
						m_cBeps414.m_szDigitSign.c_str(),
						m_cBeps414.InstgDrctPty.c_str());
	
	
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CRecvBeps414::CheckSign414");
}



