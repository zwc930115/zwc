/******************************************************************** 
�ļ����� sendpkg002.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendpkg002.h"

using namespace ZFPT;

CSendPkg002::CSendPkg002(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
    memset(m_sPkgNo, 0x00, sizeof(m_sPkgNo));
}

CSendPkg002::~CSendPkg002()
{

}

INT32 CSendPkg002::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg002::doWorkSelf");

    //��ҵ����л�ȡ����
    GetData();

    //��һ�����ı�����*/
    CreateNpcMsg();

    //�޸Ĵ��������
    UpdatePkg();
    
    //�޸�״̬/NPCMSG
    UpdateSndList(PR_HVBP_03);

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg002::doWorkSelf"); 
    return 0;
}

INT32 CSendPkg002::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg002::GetData");

    SETCTX(m_cBpbdsndlist);
    
    m_cBpbdsndlist.m_cdtrbrnchid = m_sSendOrg;
    m_cBpbdsndlist.m_txid = m_sMsgId;

    iRet = m_cBpbdsndlist.findByPK();
    if (SQLNOTFOUND == iRet)
    {
        sprintf(m_sErrMsg, "С�����ʽ����ϸ�����Ҳ���ָ��ҵ��[%s][%s]", 
            m_sSendOrg, m_sMsgId);

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    }     
    else if (SQL_SUCCESS != iRet) 
    {
        sprintf(m_sErrMsg,"��ѯС�����ʴ�����ϸ����������[%d][%s]",
            iRet, m_cBpbdsndlist.GetSqlErr());

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg002::GetData"); 

    return iRet;
}

INT32 CSendPkg002::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg002::CheckValues");

    int iRet = -1;
    
    //������޼��
    iRet = isOutOfLimit(m_dbproc, 
                        m_cBpbdsndlist.m_msgtp.c_str(), 
                        m_cBpbdsndlist.m_purpprtry.c_str(),
                        m_cBpbdsndlist.m_amount, 
                        m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_AMT_OUT_OF_LIMIT, m_sErrMsg);
    }
    
    //�����кż��
    iRet = isBankRight(m_dbproc, m_cBpbdsndlist.m_instddrctpty.c_str(), m_sErrMsg);
    if ( 0 != iRet )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_RECVBANK_CHECK_FAIL, m_sErrMsg);
    }
    
    //�˺ż��
    CheckAcct();
    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CSendPkg002::CheckValues"); 
    return 0;
}

INT32 CSendPkg002::CheckAcct()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CSendPkg002::CheckAcct");
    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CSendPkg002::CheckAcct"); 
    return 0;
}


INT32 CSendPkg002::CreateNpcMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg002::CreateNpcMsg");

    char sTemp[32 + 1] ={0};
    char sMsgText[512 + 1] ={0};

    m_pkg002.m_szCurElementNo              = "001";
    strncpy(m_pkg002.stBody001.szTrxsType , m_cBpbdsndlist.m_pmttpprtry.c_str(), 
        sizeof(m_pkg002.stBody001.szTrxsType)-1);
        
    strncpy(m_pkg002.stBody001.szOdfiCode , m_cBpbdsndlist.m_cdtrbrnchid.c_str(), 
        sizeof(m_pkg002.stBody001.szOdfiCode)-1);
        
    strncpy(m_pkg002.stBody001.szRdfiCode , m_cBpbdsndlist.m_dbtrbrnchid.c_str(), 
        sizeof(m_pkg002.stBody001.szRdfiCode)-1);
        
    strncpy(m_pkg002.stBody001.szConsignDate , m_cBpbdsndlist.m_consigdate.c_str(), 
        sizeof(m_pkg002.stBody001.szConsignDate)-1);
        
    strncpy(m_pkg002.stBody001.szTxssNo , m_szMsgSerial, 
        sizeof(m_pkg002.stBody001.szTxssNo)-1);

    memset(sTemp, '\0', sizeof(sTemp));
    sprintf(sTemp,"%015.0f", m_cBpbdsndlist.m_amount*100);    
    
    strncpy(m_pkg002.stBody001.szAmount ,sTemp, sizeof(m_pkg002.stBody001.szAmount)-1);
    
    strncpy(m_pkg002.stBody001.szPayOpenAccBkCode , m_cBpbdsndlist.m_dbtrissr.c_str(), 
        sizeof(m_pkg002.stBody001.szPayOpenAccBkCode)-1);
        
    strncpy(m_pkg002.stBody001.szPayerAcc , m_cBpbdsndlist.m_dbtracctid.c_str(), 
        sizeof(m_pkg002.stBody001.szPayerAcc)-1);
    
    SetFieldAsGbk(m_cBpbdsndlist.m_dbtnm, m_pkg002.stBody001.szPayerName , 
        sizeof(m_pkg002.stBody001.szPayerName)-1);   
        
    SetFieldAsGbk(m_cBpbdsndlist.m_dbtaddr, m_pkg002.stBody001.szPayerAddr , 
        sizeof(m_pkg002.stBody001.szPayerAddr)-1);
        
    strncpy(m_pkg002.stBody001.szRecOpenAccBkCode , m_cBpbdsndlist.m_cdtrissr.c_str(), 
        sizeof(m_pkg002.stBody001.szRecOpenAccBkCode)-1);
        
    strncpy(m_pkg002.stBody001.szRecipientAcc , m_cBpbdsndlist.m_cdtracctid.c_str(), 
        sizeof(m_pkg002.stBody001.szRecipientAcc)-1);
    
    SetFieldAsGbk(m_cBpbdsndlist.m_cdtrnm, m_pkg002.stBody001.szRecipientName, 
        sizeof(m_pkg002.stBody001.szRecipientName)-1);
        
    SetFieldAsGbk(m_cBpbdsndlist.m_cdtaddr,m_pkg002.stBody001.szRecipientAddr, 
        sizeof(m_pkg002.stBody001.szRecipientAddr)-1);
    
    strncpy(m_pkg002.stBody001.szTrxKind, m_cBpbdsndlist.m_purpprtry.c_str(), 
        sizeof(m_pkg002.stBody001.szTrxKind)-1);
        
    SetFieldAsGbk(m_cBpbdsndlist.m_addtlinf, m_pkg002.stBody001.szPost ,
        sizeof(m_pkg002.stBody001.szPost)-1);

    string strAppData;
    int iCount = 0;
    int iRet = GetTagCount(m_cBpbdsndlist.m_cstmrcdttrfaddtlinf, "72C:", iCount);
    if( (RTN_SUCCESS == iRet) && (iCount > 0) )
    {
        if("00113" == m_cBpbdsndlist.m_pmttpprtry)//�����ʽ��ǻ���
        {
            //_wsh_2012.04.24
            char* szBizFmts[10] = {"%08s", "%018s", "%010s", "%010s", "%01s", "%01s", "%01s", "%08s","%03s","%03d"};
            char* szDtlFmts[3]  = {"%010s", "%-20s", "%018s"};
            FormatAppendData(strAppData, m_cBpbdsndlist.m_cstmrcdttrfaddtlinf, iCount, 
                szBizFmts, 10, szDtlFmts, 3);
        }
        else if( ("20103" == m_cBpbdsndlist.m_pmttpprtry) || ("20104" == m_cBpbdsndlist.m_pmttpprtry))//����ֱ��֧��,������Ȩ֧��
        {
            //_wsh_2012.04.25
            char* szBizFmts[10] = {"%010s", "%-32s", "%-12s", "%01s", "%01s", "%018s", "%018s", "%08s", "%08s", "%03d"};
            char* szDtlFmts[5]  = {"%-15s", "%-20s", "%-20s", "%01s", "%018s"};
            FormatAppendData(strAppData, m_cBpbdsndlist.m_cstmrcdttrfaddtlinf, iCount, 
                szBizFmts, 10, szDtlFmts, 5);
        }  
        else if("20105" == m_cBpbdsndlist.m_pmttpprtry)//�����ʽ��ծ�Ҹ���ǻ���
        { 
            //_wsh_2012.04.25
            char* szBizFmts[7] = {"%08s", "%018s", "%010s", "%010s", "%08s", "%03s", "%03d"};
            char* szDtlFmts[5]  = {"%012s", "%-12s", "%018s", "%-12s", "%018s"};
            FormatAppendData(strAppData, m_cBpbdsndlist.m_cstmrcdttrfaddtlinf, iCount, 
                szBizFmts, 10, szDtlFmts, 5);        
        }
        else if("30102" == m_cBpbdsndlist.m_pmttpprtry)//֧Ʊ����ҵ��
        {            
            Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "__@@@@__%s", m_cBpbdsndlist.m_cstmrcdttrfaddtlinf.c_str());
            char* szBizFmts[13] = {"%08s", "%012s", "%12s", "%-32s", "%-32s", 
                                   "%015s", "%-60s", "%02d", "%-512s", "%08s", "%s", "%08s", "%s"};
            char* szDtlFmts[1] = {"%-60s"};

            FormatAppendData(strAppData, m_cBpbdsndlist.m_cstmrcdttrfaddtlinf, iCount, 
                szBizFmts, 13, szDtlFmts, 1);
            
            Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "After FormatAppendData");
        }
        else if("30103" == m_cBpbdsndlist.m_pmttpprtry)//ͨ�ý���ҵ��
        {
            //char *szTypeTag[29] = {"%08s", "%020s", "%012d", "%012s", "%015s", "%060s", "%02d", "%s", "%0512s", "%02s", 
            //                      "%08s", "%020s", "%08s", "%020s", "%020s", "%08s", "%060s", "%060s", "%032s", "%060s",
            //                      "%060s", "%060s", "%032s", "%060s", "%060s", "%08d", "%s", "%08d", "%s"};
            //AddAppendData(m_cBpbdsndlist.m_cstmrcdttrfaddtlinf, szTypeTag, strAppData, iCount, 29);

            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ClientDat[%s]", m_cBpbdsndlist.m_cstmrcdttrfaddtlinf.c_str());

            char* szBizFmts[] = {"%-8s", "%-20s", "%-12s", "%-12s", "%015s", "%-60s", "%02s", "%-60s", "%-512s", "%02s", 
                                  "%-8s", "%-20s", "%-8s", "%-20s", "%-20s", "%-8s", "%-60s", "%-60s", "%-32s", "%-60s",
                                  "%-60s", "%-60s", "%-32s", "%-60s", "%-60s", "%08d", "%s", "%08d", "%s"};
            char* szDtlFmts[1] = {"%-60s"};

            //FormatAppendData(strAppData, m_cBpbdsndlist.m_cstmrcdttrfaddtlinf, iCount, 
            //    szBizFmts, 29, NULL, 0);
            Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "After FormatAppendData");
        }
        else if("00119" == m_cBpbdsndlist.m_pmttpprtry)//�������ҵ��
        {
            m_cBpbdsndlist.m_cstmrcdttrfaddtlinf = "";
        }
        else
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "û���ҵ���Ӧ����ҵ������");
            PMTS_ThrowException(OPT_TRADE_NOTFOUND__FAIL);
        }
    }
    
    sprintf(m_pkg002.stBody001.szAppLen,"%08d",strAppData.length());
    strcpy(m_pkg002.stBody001.szAppData, strAppData.c_str());

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "Before AddBussiness");
    m_pkg002.AddBussiness();
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "After  AddBussiness");
    
    m_sMsgTxt = m_pkg002.m_szPkgBody;

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, " m_sMsgTxt = [%s]", m_sMsgTxt.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg002::CreateNpcMsg"); 
    return iRet;
}

INT32 CSendPkg002::UpdatePkg()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg002::UpdatePkg");

    strncpy(m_strAssist.sSendBank, m_cBpbdsndlist.m_instgdrctpty.c_str(), sizeof(m_strAssist.sSendBank) - 1);
    strncpy(m_strAssist.sRecvBank, m_cBpbdsndlist.m_instddrctpty.c_str(), sizeof(m_strAssist.sRecvBank) - 1);
    strncpy(m_strAssist.sMsgType,  m_cBpbdsndlist.m_msgtp.c_str(),        sizeof(m_strAssist.sMsgType)  - 1);
    
    m_strAssist.iPkgRtrltd = m_cBpbdsndlist.m_pkgrtrltd;
    
    
    strcpy(m_strAssist.sPmttpPrtry, "0");
    strcpy(m_strAssist.sIssr,       "0");
    strcpy(m_strAssist.sAcctId,     "0");
    strcpy(m_strAssist.sOriMsgTp,   "0");
    strcpy(m_strAssist.sOriMsgId,   "0");
    
    iRet = UpPKGAssist1(m_sPkgNo);
    if (iRet != SQL_SUCCESS)
    {
        memcpy(m_sPkgNo, m_cBpbdsndlist.m_msgid.c_str(), sizeof(m_sPkgNo) - 1);
        sprintf(m_sErrMsg,  "UpPKGAssist1 is error,iRet=[%d][%s]", iRet, m_sPkgNo);
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg002::UpdatePkg");
    return 0;
}

class CTempBlobWriter : public CBpbdsendlist
{
public:
    bool writeBlob(const char * pchWrite, STRING &strOutWrite, int iSysflag)
    {
        return write_blob(pchWrite, strOutWrite, iSysflag);
    }
};

//! ������4000Bytes���ַ�д��bp_bigdata����
string CSendPkg002::getShortNpcMsg(const string& origNpcMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg002::getShortNpcMsg");
    if (origNpcMsg.length()<1000)
        return origNpcMsg;

    CTempBlobWriter writer;
    SETCTX(writer);

    string bigdatIndex;
    if (!writer.writeBlob(origNpcMsg.c_str(), bigdatIndex, SYS_BEPS))
    {
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "Write NPCMSG to bigdata Fail");
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leave CSendPkg002::getShortNpcMsg");
    return bigdatIndex;
}
   
/*
�޸ļ�¼:
    2012/5/2 ������  m_sMsgTxt���ܳ���4000k, ����bigdata����.
                     ��Ӧ��Ҫ�޸�С����ʱȡҵ����ϸ�Ĵ���.
*/
INT32 CSendPkg002::UpdateSndList(LPCSTR sProcstate)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg002::UpdateSndList");
    string npcMsg = getShortNpcMsg(m_sMsgTxt);
    
    size_t nBufferSize = npcMsg.length()  + 1024;
    char *pBuffer = new char[nBufferSize];
    memset(pBuffer, 0x00, nBufferSize);
    snprintf(pBuffer, nBufferSize-1, "UPDATE bp_bdsendlist t SET t.STATETIME = sysdate,"
                            "t.MSGID  = '%s', "
                            "t.NPCMSG = '%s', "
                            "t.PROCSTATE = '%s'"
                            " WHERE t.txid = '%s'",
                            m_sPkgNo,
                            npcMsg.c_str(),
                            sProcstate,
                            m_sMsgId);
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "SQL[%s]",pBuffer);
    
    iRet = m_cBpbdsndlist.execsql(pBuffer);
    delete []pBuffer;

    if (iRet != SQL_SUCCESS)
    {
        sprintf(m_sErrMsg,  "update bp_bdsendlist  is error!iRet=[%d]", iRet);
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        if ( 0 == strcmp(sProcstate, PR_HVBP_95))
        {
            //��������ʱ�����쳣,������쳣������״̬,���ﲻ���쳣
            PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
        }
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg002::UpdateSndList");
    return 0;
}

INT32 CSendPkg002::SetErrACK(int iErrCode, LPCSTR pErrDesc)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg002::SetErrACK");

    //�޸�״̬Ϊ"���޸�"
    UpdateSndList(PR_HVBP_93);

    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CSendPkg002::SetErrACK");
    return 0;
}

