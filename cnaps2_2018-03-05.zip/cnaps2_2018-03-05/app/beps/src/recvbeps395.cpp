/*
 *  recvbeps395.cpp
 *  Description: 指量客户账户查询来报处理类beps.395.001.01
 *  Created on: 2012-6-5
 *  Author: __wsh
 */

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbeps395.h"

const char* _AcctDtls = "AcctDtls";

//
CRecvbeps395::CRecvbeps395()
{
    //m_ccmcl.m_msgtp = "beps.395.001.01";
	m_strMsgTp = "beps.395.001.01";
}

//
CRecvbeps395::~CRecvbeps395()
{
}

//__wsh 2012-05-25 //业务处理入口
int CRecvbeps395::Work(const char* szmsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CRecvbeps395::Work");
	int iRet = -1;

	//解析报文
	UnPack(szmsg);

	//新增汇�?�来账记�?
	InsertData_cl();

	//新增明细来账记录
	InsertData_list();

	//更新原业务报文状�?
	UpdateOrgnBiz();

	//核签
	CheckSign395();
	
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvbeps395::Work");
	return 0;
}

//__wsh 2012-06-05
int CRecvbeps395::UnPack(const char* szMsg)
{
	Trace(L_DEBUG, __FILE__, __LINE__,
			NULL, "Enter CRecvbeps395::UnPack");
	int iRet = -1;

	if(NULL == szMsg || '\0' == szMsg[0]){
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "报文长度为空");
		PMTS_ThrowException(PRM_FAIL);
	}

	//获取工作日期
	iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
	if(RTN_SUCCESS != iRet){
		Trace(L_ERROR,  __FILE__, __LINE__,
				NULL, "获取工作日期失败�?");
		PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
	}
	m_strWorkDate = m_sWorkDate;

	//解析报文
	if (OPERACT_SUCCESS != m_cBeps395.ParseXml(szMsg)){
		Trace(L_ERROR,  __FILE__,  __LINE__,
				NULL, "报文解析出错! iRet= %d", iRet);

		PMTS_ThrowException(__FILE__, __LINE__,
				OPT_PRS_MSG_FAIL, "报文解析出错");
	}

    //ZFPTLOG.SetLogInfo("395", m_cBeps395.MsgId.c_str());
    
	Trace(L_DEBUG, __FILE__, __LINE__,
			NULL, "Leave CRecvbeps395::UnPack");

	return OPERACT_SUCCESS;
}

//__wsh 2012-06-05
int CRecvbeps395::SetData_cl(void)
{
	int iRet = -1;

	m_caqcl.m_workdate     = m_sWorkDate;               //工作日期
	m_caqcl.m_msgtp        = m_strMsgTp;                //报文类型
	m_caqcl.m_mesgid       = m_cBeps395.m_PMTSHeader.getMesgID();    //通信级标�?
	m_caqcl.m_mesgrefid    = m_cBeps395.m_PMTSHeader.getMesgRefID(); //参与通信标识
	m_caqcl.m_msgid        = m_cBeps395.MsgId;          //报文标识
	m_caqcl.m_instgdrctpty = m_cBeps395.InstgDrctPty;   //发起清算�?
	m_caqcl.m_instgpty     = m_cBeps395.GrpHdrInstgPty; //发起�?
	m_caqcl.m_instddrctpty = m_cBeps395.InstdDrctPty;   //接收清算�?
	m_caqcl.m_instdpty     = m_cBeps395.GrpHdrInstdPty; //接收�?
	m_caqcl.m_syscd        = m_cBeps395.SysCd;          //系统�?
	m_caqcl.m_rmk          = m_cBeps395.Rmk;            //备注
	m_caqcl.m_procstate    = PR_HVBP_01;                //处理状�??
	m_caqcl.m_srcflag      = "2";                //处理状�??
    m_caqcl.m_orgnlinstgpty = m_cBeps395.OrgnlInstgPty;
	m_caqcl.m_orgnlmesgid   = m_cBeps395.OrgnlMsgId;
	m_caqcl.m_orgnlmsgtp    = m_cBeps395.OrgnlMT;
	m_caqcl.m_busistate     = m_cBeps395.Sts;
	m_caqcl.m_acctcnt       = m_cBeps395.AcctCnt;

	iRet = 0;
	return iRet;
}

//__wsh 2012-06-05 来账汇�?�记录入�?
int CRecvbeps395::InsertData_cl(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CRecvbeps395::InsertData_cl");
	int iRet = -1;

	SETCTX(m_caqcl);

	//设置汇�?�数�?
	iRet = SetData_cl();

	//插入数据
	iRet = m_caqcl.insert();

	if(SQL_SUCCESS != iRet){
		char szErr[512] = {0};
		sprintf(szErr,
			"插入批量账户查询汇�?�表失败  iRet=%d cause=%s",
			iRet, m_caqcl.GetSqlErr());
		Trace(L_ERROR, __FILE__, __LINE__,
				NULL, "%s", szErr);

		PMTS_ThrowException(DB_INSERT_FAIL);
	}
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvbeps395::InsertData_cl");
	return iRet;
}

//__wsh 2012-06-05 获取循环中账户信息明�?
int CRecvbeps395::GetAcctDtls(int iCount)
{
	int iRet = -1;

	//账户账号（卡号）
	m_cBeps395.Id      = m_cBeps395.
			GetValueFromCycle(_AcctDtls, "Id", iCount);
	//账户名称
	m_cBeps395.Nm      = m_cBeps395.
			GetValueFromCycle(_AcctDtls, "Nm", iCount);
	//应答状�??
	m_cBeps395.Sts     = m_cBeps395.
			GetValueFromCycle(_AcctDtls, "Sts", iCount);
	//拒绝�?
	m_cBeps395.RjctCd  = m_cBeps395.
			GetValueFromCycle(_AcctDtls, "RjctCd", iCount);
	//拒绝信息
	m_cBeps395.RjctInf = m_cBeps395.
			GetValueFromCycle(_AcctDtls, "RjctInf", iCount);
	//处理参与机构�?
	m_cBeps395.PrcPty  = m_cBeps395.
			GetValueFromCycle(_AcctDtls, "PrcPty", iCount);
	//账户状�??
	m_cBeps395.AcctSts = m_cBeps395.
			GetValueFromCycle(_AcctDtls, "AcctSts", iCount);
	//�?户行行号
	m_cBeps395.AcctBk  = m_cBeps395.
			GetValueFromCycle(_AcctDtls, "AcctBk", iCount);

	//add begin by jienjunj 20160326 ���й涨���ӹ������ݺ��뼰�绰�ֶ�	
	m_cBeps395.CtznIDNbRst= m_cBeps395.
			GetValueFromCycle(_AcctDtls, "CtznIDNmVrfctnRslt", iCount);
	
	m_cBeps395.TelRst= m_cBeps395.
			GetValueFromCycle(_AcctDtls, "TelVrfctnRslt", iCount);	
	//add end by jienjunj 20160326 ���й涨���ӹ������ݺ��뼰�绰�ֶ�	

	iRet = 0;
	return iRet;
}

//设置明细
int CRecvbeps395::SetData_list(int iCount)
{
	int iRet = -1;

	//获取循环中账户信息明�?
	GetAcctDtls(iCount);

	//设置批量账户查询明细表信�?
	m_caqlist.m_acctid   = m_cBeps395.Id;
	m_caqlist.m_acctnm   = m_cBeps395.Nm;
	m_caqlist.m_rspsnsts = m_cBeps395.Sts;
	m_caqlist.m_acctsts  = m_cBeps395.AcctSts;
	m_caqlist.m_acctbk   = m_cBeps395.AcctBk;
	//add begin by jienjunj 20160326 ���й涨���ӹ������ݺ��뼰�绰�ֶ�	
	m_caqlist.m_CtznIDNbRst= m_cBeps395.CtznIDNbRst;
	m_caqlist.m_TelRst= m_cBeps395.TelRst;
	//add end by jienjunj 20160326 ���й涨���ӹ������ݺ��뼰�绰�ֶ�	
	
	m_caqlist.m_rjctcd   = m_cBeps395.RjctCd;
	m_caqlist.m_rjctinf  = m_cBeps395.RjctInf;

	iRet = 0;
	return iRet;
}

//__wsh 2012-06-05 明细入库
int CRecvbeps395::InsertData_list(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CRecvbeps395::InsertData_list");
	int iRet = -1;

	SETCTX(m_caqlist);

	//设置公共部份明细
	m_caqlist.m_workdate 	 = m_strWorkDate; 		      //工作日期
	m_caqlist.m_msgid        = m_cBeps395.MsgId;          //报文标识
	m_caqlist.m_instgdrctpty = m_cBeps395.InstgDrctPty;   //发�?�清算行
	m_caqlist.m_instgpty     = m_cBeps395.GrpHdrInstgPty; //发�?�行
	m_caqlist.m_procstate	 = PR_HVBP_01;//处理状�??
	m_caqlist.m_srcflag      = "2";//处理状�??

	//设置循环部份明细
	int iAcctCnt = atoi(m_cBeps395.AcctCnt.c_str());
	int iCount = m_cBeps395.GetNodeCountByName("AcctDtls");
	if(iAcctCnt != iCount){
	    Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
	        "疑似出错，查询数目不�?�? iCount=%d, iAcctCnt=%d", 
	        iCount, iAcctCnt); 
	}
	
	for(int i = 0; i < iCount; ++i){
		//设置数据
		SetData_list(i);
		//插入数据
		iRet = m_caqlist.insert();
		if(SQL_SUCCESS != iRet){
			char szErr[512] = {0};
			sprintf(szErr, "插入批量账户查询明细失败 iRet=%d cause=%s",
					iRet, m_caqlist.GetSqlErr());
			Trace(L_ERROR, __FILE__, __LINE__,
					NULL, "%s", szErr);

			PMTS_ThrowException(DB_INSERT_FAIL);
		}// end if
		//循环加签
		m_cBeps395.AddTxStr();
	}// end for
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvbeps395::InsertData_list");
	return iRet;
}

//__wsh 2012-06-05 核签
void CRecvbeps395::CheckSign395()
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CheckSign395");

	m_cBeps395.getOriSignStr();

	CheckSign(
		m_cBeps395.m_sSignBuff.c_str(),
		m_cBeps395.m_szDigitSign.c_str(),
		m_cBeps395.InstgDrctPty.c_str());

	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CheckSign395");
}

//__wsh 2012-06-05 更新原业务状�?
int CRecvbeps395::UpdateOrgnBiz(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CRecvbeps395::UpdateOrgnBiz");
	int iRet = -1;

	string strSql = "update bp_cstacctqrycl set procstate='";
	strSql += PR_HVBP_07;
	strSql += "', statetime=sysdate where msgid='";
	strSql += m_cBeps395.OrgnlMsgId;
	strSql += "' and instgdrctpty='";
	strSql += m_cBeps395.OrgnlInstgPty;
	strSql += "' and msgtp='";
	strSql += m_cBeps395.OrgnlMT;
	strSql += "' and srcflag='1' ";

	Trace(L_DEBUG, __FILE__, __LINE__,
			NULL, "__strSql=%s", strSql.c_str());

	iRet = m_caqcl.execsql(strSql.c_str());
	if(iRet != SQL_SUCCESS){
		char szErr[512] = {0};
		sprintf(szErr, "更新批量账户查询汇�?? 表失�? iRet=%d cause=%s",
				iRet, m_caqcl.GetSqlErr());
		Trace(L_ERROR, __FILE__, __LINE__,
				NULL, "%s", szErr);

		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Leave CRecvbeps395::UpdateOrgnBiz");

	return iRet;
}

