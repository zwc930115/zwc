/******************************************************************** 
�ļ����� recvbeps416.cpp
�����ˣ� zys
��  �ڣ� 2011-04-27
�޸��ˣ� 
��  �ڣ� 
��  ���� ʵʱ��Ϣ�������뱨��< beps.416.001.01>���˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbeps416.h"

using namespace ZFPT;

CRecvBeps416::CRecvBeps416()
{
    m_szOriSign = "";
    m_strMsgTp  = "beps.416.001.01";
}

CRecvBeps416::~CRecvBeps416()
{

}

INT32 CRecvBeps416::Work(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBeps416::Work()");
           
    // ��������
    unPack(szMsg);
    
    // ҵ����
    CheckValues();
    
    // ���
    InsertDb(szMsg);
        
    // ��ǩ
    CheckSign416();
        
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBeps416::Work()");
    return OPERACT_SUCCESS;
}

INT32 CRecvBeps416::unPack(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvBeps416::unPack()");
    
    int iRet = OPERACT_FAILED;
    
     // �����Ƿ�Ϊ��
    if (NULL == szMsg || '\0' == szMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��"); 
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }
    //��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;      
    
    // ��������
    iRet = m_cBeps416.ParseXml(szMsg);
    if (OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= %d", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");
    }
    
    // ���ı�ʶ��
    m_strMsgID = m_cBeps416.AssgnmtId;
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CRecvBeps416::unPack()");
    return OPERACT_SUCCESS;
}


/******************************************************************************
*  Function:   CheckValues
*  Description:ҵ����
*  Input:	   ��
*  Output:	   
*  Return:	   0   : �����ɹ�,
			   ����: ����ʧ��
*  Others:	   ��
*  Author:	   zys
*  Date:	   2011-04-20
*******************************************************************************/
INT32 CRecvBeps416::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CSendBeps416::CheckValues");

    /*int iRet = OPERACT_FAILED;

    //������޼��
    iRet = isOutOfLimit(m_dbproc, 
                        m_cbpbdsendlist.m_msgtp.c_str(), 
                        m_cbpbdsendlist.m_purpprtry.c_str(),
                        m_cbpbdsendlist.m_amount, 
                        m_sErrMsg);
    if ( OPERACT_SUCCESS != iRet)
    {
        return iRet;
    }
    
    //�����кż��
    iRet = isBankRight(m_dbproc, m_cbpbdsendlist.m_instddrctpty.c_str(), m_sErrMsg);
    if ( 0 != iRet)
    {
        return OPERACT_FAILED;
    }*/
    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CSendBeps416::CheckValues"); 
    return OPERACT_SUCCESS;
}


/******************************************************************************
*  Function:   InsertDb
*  Description:�������
*  Input:	   ��
*  Output:	   
*  Return:	   0   : �����ɹ�,
			   ����: ����ʧ��
*  Others:	   ��
*  Author:	   zys
*  Date:	   2011-04-26
*******************************************************************************/
INT32 CRecvBeps416::InsertDb(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBeps416::InsertDb()");
    
    string strTemp = "";
    char   sTemp[128 + 1] = {0};
    string strTagVal = "";
    int    iRet;
    
    //��������
    SETCTX(m_cBpcstinfcxl);

    m_cBpcstinfcxl.m_mesgid          =    m_cBeps416.AssgnmtId      ;     //���ı�ʶ��
    m_cBpcstinfcxl.m_instgdrctpty    =    m_cBeps416.AssgnrMmbId    ;     //����ֱ�Ӳ������
    m_cBpcstinfcxl.m_instddrctpty    =    m_cBeps416.AssgneMmbId    ;     //����ֱ�Ӳ������
    m_cBpcstinfcxl.m_workdate        =    m_cBeps416.CreDtTm        ;     //���ķ���ʱ��
    //"1"                              =    m_cBeps416.CaseId         ;                               //�̶���
    m_cBpcstinfcxl.m_oriinstgdrctpty =    m_cBeps416.CretrMmbId     ;     //ԭ����ֱ�Ӳ������
    m_cBpcstinfcxl.m_orimsgid        =    m_cBeps416.OrgnlMsgId     ;     //ԭ���ı�ʶ��
    m_cBpcstinfcxl.m_orimsgtp        =    m_cBeps416.OrgnlMsgNmId   ;     //ԭ�������ͺ�
    m_cBpcstinfcxl.m_addtlinf        =    m_cBeps416.AddtlInf       ;     //����

    //��������
    iRet = m_cBpcstinfcxl.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg,"����ʵʱ��Ϣ������ʧ��[%d][%s]", iRet, m_cBpcstinfcxl.GetSqlErr());
        Trace(L_ERROR, __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBeps416::InsertDb()");
    return OPERACT_SUCCESS;
}

/******************************************************************************
*  Function:   CheckSign416
*  Description:��ǩ
*  Input:	   ��
*  Output:	   
*  Return:	   0   : �����ɹ�,
			   ����: ����ʧ��
*  Others:	   ��
*  Author:	   zys
*  Date:	   2011-04-26
*******************************************************************************/
INT32 CRecvBeps416::CheckSign416()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBeps416::CheckSign416");
    
    int    iRet      = 0;
    string strTemp   = "";
    string strTagVal = "";

    m_szOriSign = m_szOriSign + Trim(m_cBeps416.AssgnmtId)        + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps416.AssgnrMmbId)      + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps416.AssgneMmbId)      + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps416.CreDtTm)          + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps416.CretrMmbId)       + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps416.OrgnlMsgId)       + "|";
    m_szOriSign = m_szOriSign + Trim(m_cBeps416.OrgnlMsgNmId)     + "|";
    
    char *sOrigenStr = new char[4096];
    
    memset(sOrigenStr, 0x00, 4096 * sizeof(char));
    strcpy(sOrigenStr, m_szOriSign.c_str());

    iRet = checkSign(m_dbproc,signTrim(sOrigenStr),
                            (char *)m_cBeps416.m_szDigitSign.c_str(),
                            Trim(m_cBpcstinfcxl.m_instgdrctpty).c_str());
    if( RTN_SUCCESS != iRet)
    {
        delete [] sOrigenStr;
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "����ǩ����֤δͨ��:[%d]!", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_CHECKSIGN_FAIL, "����ǩ����֤δͨ��");
    }
    
    delete [] sOrigenStr;
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBeps416::CheckSign416");
    return OPERACT_SUCCESS;
}


