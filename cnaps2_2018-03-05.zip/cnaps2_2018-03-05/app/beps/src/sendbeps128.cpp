/******************************************************************** 
�ļ����� sendbeps128.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-03-07
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps128.h"
#include "bpbcoutsndcl.h" 

using namespace ZFPT;

CSendBeps128::CSendBeps128(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{

}

CSendBeps128::~CSendBeps128()
{

}

INT32 CSendBeps128::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps128::doWorkSelf");
    
    /*ҵ����:������*/
    //CheckValues();
    
    CreatPmtsMsg();

    //����Զ�̶���
    AddQueue();

    /*�޸���ϸ��*/
    UpdateStat(PR_HVBP_08,m_sMsgId);

    //�޸�ԭҵ��״̬
    //UpdateOriStat(PR_HVBP_07,m_cBpbcoutsendlist.m_orgnlmsgid.c_str());
        
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps128::doWorkSelf"); 
    return 0;
}

int CSendBeps128::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps128::CheckValues");

    int iRet = -1;

    //������޼��
    iRet = isOutOfLimit(m_dbproc, 
                        m_cBpbcoutsendlist.m_msgtp.c_str(), 
                        m_cBpbcoutsendlist.m_purpprtry.c_str(),
                        m_cBpbcoutsendlist.m_amount, 
                        m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_AMT_OUT_OF_LIMIT, m_sErrMsg);
    }
    
    //�����кż��
    iRet = isBankRight(m_dbproc, m_cBpbcoutsendlist.m_instddrctpty.c_str(), m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_RECVBANK_CHECK_FAIL, m_sErrMsg);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps128::CheckValues");
    return 0;
}

void CSendBeps128::CreatPmtsMsg()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendBeps128::CreatPmtsMsg()");

	char				sSqlStr[4000 + 1]  = {0};
	string				strWhereClause	= "";
	int					iRetCode		= RTN_FAIL;
	char				sTemp[255]		= { 0 };
	
	
	//ȡ��ϸ������ϸ
	SETCTX(m_cBpbcoutsendlist);

	strWhereClause = strWhereClause + "msgid = '" + m_sMsgId + "' " + "and procstate = " + PR_HVBP_95 + "  order by txid ";
	
	iRetCode = m_cBpbcoutsendlist.find(strWhereClause);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(m_sErrMsg, "oBpbdsndlist.find:��ѯ����¼��, [%d][%s]",
			iRetCode, m_cBpbcoutsendlist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);

        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_sErrMsg);
    }
	
	int nTotal = 0;
	int nTotalOk = 0;
	double dAmtOk = 0.0;

	while(SQL_SUCCESS == iRetCode)
	{
		iRetCode = m_cBpbcoutsendlist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
			break;
		if (SQL_SUCCESS != iRetCode) 
		{
		    //�ر��α�
            m_cBpbcoutsendlist.closeCursor();
            
			sprintf(m_sErrMsg, "m_cBpbcoutsendlist.fetch:��ѯ��ϸ����¼��, [%d][%s]",
				iRetCode, m_cBpbcoutsendlist.GetSqlErr()); 
			
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_sErrMsg);
	
			PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_sErrMsg);
		}

       
        memset(sTemp,0,sizeof(sTemp));
        oBeps128.StsId               = m_cBpbcoutsendlist.m_replystate;
        oBeps128.OrgnlTxId           = m_cBpbcoutsendlist.m_oritxid;
        oBeps128.RsnPrtry            = m_cBpbcoutsendlist.m_replyprocesscode ;
        oBeps128.TxInfAndStsAddtlInf = m_cBpbcoutsendlist.m_replyrjctinf;
        char szAmt[32] = {0};
        sprintf(szAmt, "%.02f", m_cBpbcoutsendlist.m_oriamount);
        oBeps128.IntrBkSttlmAmt      = szAmt;
        oBeps128.Ccy                 = m_cBpbcoutsendlist.m_currency;
        oBeps128.CtgyPurpPrtry       = m_cBpbcoutsendlist.m_pmttpprtry;
        oBeps128.OrgnlCdtrAgtMmbId   = m_cBpbcoutsendlist.m_instddrctpty ;
        oBeps128.OrgnlCdtrAgtId      = m_cBpbcoutsendlist.m_cdtrbrnchid ;
        oBeps128.Ustrd               = m_cBpbcoutsendlist.m_addtlinf ;
        oBeps128.DbtrAgtMmbId        = m_cBpbcoutsendlist.m_instgdrctpty ;
        oBeps128.DbtrAgtId           = m_cBpbcoutsendlist.m_dbtrbrnchid ;
        oBeps128.CdtrAgtMmbId        = m_cBpbcoutsendlist.m_instddrctpty ;
        oBeps128.CdtrAgtId           = m_cBpbcoutsendlist.m_cdtrbrnchid;

        ++nTotal;
        if (m_cBpbcoutsendlist.m_replystate == "PR02"){
        	++nTotalOk;
        	dAmtOk += m_cBpbcoutsendlist.m_amount;
        }

        oBeps128.AddDetail();	        
    }
    
    //�ر��α�
    m_cBpbcoutsendlist.closeCursor();

    CBpbcoutsndcl oBpbcoutsndcl;
    oBpbcoutsndcl.m_msgid = m_sMsgId;
    oBpbcoutsndcl.m_instgdrctpty = m_sSendOrg;
    
    SETCTX(oBpbcoutsndcl);

    iRetCode = oBpbcoutsndcl.findByPK();
    if (SQLNOTFOUND == iRetCode)
	{
		sprintf(m_sErrMsg,"oBpbcoutsndcl.findByPK failed:[%s],[%s],[%d][%s]", 
            m_sSendOrg, m_sMsgId, iRet, oBpbcoutsndcl.GetSqlErr());
		
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);
		
	} 	
	else if (SQL_SUCCESS != iRetCode) 
	{
		sprintf(m_sErrMsg,"oBpbcoutsndcl.findByPK failed:[%d][%s]", iRet, oBpbcoutsndcl.GetSqlErr());
		
		Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, m_sErrMsg);
		
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
	}
	Trace(L_DEBUG, __FILE__, __LINE__, NULL,
			"nTotal[%d], nTotalOk[%d], dAmtOk[%0.2f]", nTotal, nTotalOk, dAmtOk);

	oBeps128.MsgId                  =	m_sMsgId;
	oBeps128.CreDtTm                =	m_sIsoWorkDate;
    oBeps128.OrgnlMsgId             =   m_cBpbcoutsendlist.m_orgnlmsgid;
    oBeps128.OrgnlMsgNmId           =   m_cBpbcoutsendlist.m_orgnlmsgtp;
    memset(sTemp,0,sizeof(sTemp));
    oBeps128.OrgnlNbOfTxs           =   itoa(sTemp, nTotalOk);// ��ִ��ϸҵ��ɹ��ܱ���
    memset(sTemp,0,sizeof(sTemp));
    oBeps128.OrgnlCtrlSum           =   ftoa(sTemp, dAmtOk, 2);;//��ִ��ϸҵ��ɹ��ܽ��
    oBeps128.AddtlInf               =   m_cBpbcoutsendlist.m_rjctinf;
    memset(sTemp,0,sizeof(sTemp));
    oBeps128.DtldNbOfTxs            =   itoa(sTemp, nTotal);//��ִ��ϸҵ���ܱ���
    oBeps128.DtldSts                =   "ACCP"; //m_cBpbcoutsendlist.m_busistate;		
	oBeps128.CtgyPurpPrtry          = 	m_cBpbcoutsendlist.m_pmttpprtry	;//ҵ�����ͱ���
	
	
	//��ȡ����ͨѶ���
	if(false == GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS))
	{
		Trace(L_INFO,  __FILE__,  __LINE__,NULL, "��ȡ����ͨѶ���ʧ�ܣ�");		
		PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_MESGREFID_FAIL, "��ȡ����ͨѶ���ʧ�ܣ�");
	}
    
    AddSign128();
    
	//�鱨��ͷ
	oBeps128.CreateXMlHeader("BEPS", 
								m_sWorkDate,
								m_cBpbcoutsendlist.m_instgdrctpty.c_str(),
								m_cBpbcoutsendlist.m_instddrctpty.c_str(),
				  				"beps.128.001.01",
				  				m_sMsgRefId);
	
	int iRet = oBeps128.CreateXml();
	if (0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��������beps.128.001.01����ʧ��[%d]", iRet);	
		PMTS_ThrowException(__FILE__, __LINE__, OPT_CREAT_MSG_FAIL, NULL);
	}
	
    m_sMsgTxt = oBeps128.m_sXMLBuff;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendBeps128::CreatPmtsMsg()");
}

int CSendBeps128::UpdateStat(LPCSTR sProcstate,LPCSTR pMsgid)
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps128::UpdateStat");

    SETCTX(m_cBpbcoutsendlist);

    //���»��ܱ�    
    sprintf(m_sSqlStr, "UPDATE BP_BCOUTSNDCL t SET t.STATETIME = sysdate,"
            			" t.PROCSTATE = '%s', "
            			" t.MESGID = '%s', "
            			" t.MESGREFID = '%s' "   
            			" WHERE t.MSGID = '%s'",/*�����*/
            			sProcstate,
            			m_sMsgRefId,
            			m_sMsgRefId,
            			pMsgid);

    iRet = m_cBpbcoutsendlist.execsql(m_sSqlStr);
    if (iRet != SQL_SUCCESS)
    {
        sprintf(m_sErrMsg,  "update BP_BCOUTSNDCL  is error!iRet=[%d]", iRet);
        Trace(L_ERROR, __FILE__, __LINE__, pMsgid, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
    }

    //������ϸ��
    sprintf(m_sSqlStr, "UPDATE bp_bcoutsendlist t SET t.STATETIME = sysdate,"
            			" t.PROCSTATE = '%s'"   
            			" WHERE t.MSGID = '%s'",/*�����*/
            			sProcstate,
            			pMsgid);

    iRet = m_cBpbcoutsendlist.execsql(m_sSqlStr);
    if (iRet != SQL_SUCCESS)
    {
        sprintf(m_sErrMsg,  "update bp_bcoutsendlist  is error!iRet=[%d]", iRet);
        Trace(L_ERROR, __FILE__, __LINE__, pMsgid, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps128::UpdateStat");
    return 0;
}

int CSendBeps128::UpdateOriStat(LPCSTR sProcstate,LPCSTR pMsgid)
{
    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "enter CSendBeps128::UpdateOriStat");

    SETCTX(m_cBpbcoutsendlist);

    //���»��ܱ�    
    sprintf(m_sSqlStr, "UPDATE BP_BDRCVCL t SET "
            			" t.PROCSTATE = '%s'"   
            			" WHERE t.MSGID = '%s'",/*�����*/
            			sProcstate,
            			pMsgid);

    iRet = m_cBpbcoutsendlist.execsql(m_sSqlStr);
    if (iRet != SQL_SUCCESS)
    {
        sprintf(m_sErrMsg,  "update BP_BDRCVCL  is error!iRet=[%d][%s]", 
                            iRet,m_cBpbcoutsendlist.GetSqlErr());                  
        Trace(L_ERROR, __FILE__, __LINE__, pMsgid, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
    }

    //������ϸ��
    sprintf(m_sSqlStr, "UPDATE BP_BDRECVLIST t SET "
            			" t.PROCSTATE = '%s'"   
            			" WHERE t.MSGID = '%s'",/*�����*/
            			sProcstate,
            			pMsgid);

    iRet = m_cBpbcoutsendlist.execsql(m_sSqlStr);
    if (iRet != SQL_SUCCESS)
    {
        sprintf(m_sErrMsg,  "update BP_BDRECVLIST  is error!iRet=[%d] [%s]", 
            iRet,m_cBpbcoutsendlist.GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, pMsgid, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, m_sMsgId, "exit CSendBeps128::UpdateOriStat");
    return 0;
}

INT32 CSendBeps128::SetErrACK(int iErrCode, LPCSTR pErrDesc)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendBeps128::SetErrACK");

	//�޸�״̬Ϊ"���޸�"
    UpdateStat(PR_HVBP_93,m_sMsgId);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendBeps128::SetErrACK");
	return 0;
}

int CSendBeps128::ChargeMB()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBeps128::ChargeMB...");

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBeps128::ChargeMB..."); 
    
    return RTN_SUCCESS;
}

int CSendBeps128::FundSettle()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBeps128::FundSettle...");
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û�[%s]", m_szOprUser);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�����û���������[%s]", m_szOprUserNetId);
	Trace(L_INFO, __FILE__, __LINE__, NULL, "�������к�[%s]", m_sSendOrg);

	m_charge.m_amount = m_cBpbcoutsendlist.m_amount;	//ҵ����
	m_charge.m_iDCFlag = iDEBITFLAG;			//�����ʶ
	strcpy(m_charge.m_szOprUserNetId, m_szOprUserNetId);	//�����û���������
	strcpy(m_charge.m_szSendBank, m_sSendOrg);	//������

	int iRet = 0;
	iRet = m_charge.FundSettle();
	if(RTN_SUCCESS != iRet)        
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "FundSettle iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBeps128::FundSettle..."); 
    
    return RTN_SUCCESS;
}

void CSendBeps128::AddSign128()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBeps128::AddSign128...");

	char   sSignedStr[4096 + 1] = {0};
	
	oBeps128.getOriSignStr();
	
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
	    "__128_signdata:%s", oBeps128.m_sSignBuff.c_str());
	AddSign(oBeps128.m_sSignBuff.c_str(), 
			sSignedStr, 
			RAWSIGN, 
			m_cBpbcoutsendlist.m_instgdrctpty.c_str());
			
    
	
	oBeps128.m_szDigitSign = sSignedStr;
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBeps128::AddSign128...");   
}
