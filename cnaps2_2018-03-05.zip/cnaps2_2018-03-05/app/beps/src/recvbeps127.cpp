/******************************************************************** 
�ļ����� recvbeps127.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbeps127.h"

CRecvbeps127::CRecvbeps127()
{
    m_Bpcl.m_msgtp = "beps.127.001.01";
    m_BpList.m_msgtp = "beps.127.001.01";    
}

CRecvbeps127::~CRecvbeps127()
{

}

void CRecvbeps127::CheckSign127()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCcms127::CheckSign127");

    m_cBeps127.getOriSignStr();
	
	CheckSign(m_cBeps127.m_sSignBuff.c_str(),
			m_cBeps127.m_szDigitSign.c_str(),
			m_cBeps127.InstgDrctPty.c_str());
                            
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCcms127::CheckSign127");
}

int CRecvbeps127::Work(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps127::CRecvbeps127()");
    
    // ��������
    unPack(szMsg);
  
    SetData(szMsg); 
    
    // ��������
    InsertData();
    
    //��ǩ   
    CheckSign127();       
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps127::CRecvbeps127()");
    return OPERACT_SUCCESS;
}

void CRecvbeps127::SetRtuMsg()
{

}

INT32 CRecvbeps127::unPack(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps127::unPack()");

	int iRet = OPERACT_FAILED;

	// �����Ƿ�Ϊ��
	if (NULL == szMsg || '\0' == szMsg)
	{
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "���ĳ���Ϊ��!");
        PMTS_ThrowException(PRM_FAIL);
	}
    // ��������
    if (OPERACT_SUCCESS != m_cBeps127.ParseXml(szMsg))
    {
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= %d", iRet);	
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");
    }

	/*
    //��ȡ��������
	iRet = GetWorkDate(m_dbproc, m_sWorkDate,
			SYS_BEPS, m_cBeps127.InstdDrctPty.c_str());
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");
		PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
	}
	*/
	m_strWorkDate = m_sWorkDate;

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps127::unPack()");
    return OPERACT_SUCCESS;
}

INT32 CRecvbeps127::InsertData()
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps127::InsertData()");
    
    //SETCTX(m_Bpcl);
    
    if (0 != m_Bpcl.setctx(m_dbproc))
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
		PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
	}
	
    int iRet = m_Bpcl.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__,  __LINE__, NULL, "m_Bpcl.insert error [%d][%s]", iRet,m_Bpcl.GetSqlErr());
        PMTS_ThrowException(DB_INSERT_FAIL);
    }
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps127::InsertData()");
    return iRet;
}

INT32 CRecvbeps127::SetData(LPCSTR pchMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps127::SetData()");
    
    //SETCTX(m_BpList);
    
    char szParentName[128 + 1] = {0};
    char szChildName[128 + 1] = {0};
    
    m_Bpcl.m_workdate     = m_sWorkDate; 
    m_Bpcl.m_consigdate   = m_cBeps127.MsgId.substr(0, 8); 
    m_Bpcl.m_mesgid       = m_cBeps127.m_PMTSHeader.getMesgID(); 
    m_Bpcl.m_mesgrefid    = m_cBeps127.m_PMTSHeader.getMesgRefID();
    m_Bpcl.m_msgid        = m_cBeps127.MsgId; 
    m_Bpcl.m_instgdrctpty = m_cBeps127.InstgDrctPty; 
    m_Bpcl.m_instddrctpty = m_cBeps127.InstdDrctPty; 
    m_Bpcl.m_npcmsglen    = m_cBeps127.m_sXMLBuff.length();
    m_Bpcl.m_npcfilename  = ""; 
    m_Bpcl.m_busistate    = "PR00"; 
    m_Bpcl.m_processcode  = ""; 
    m_Bpcl.m_rjctinf      = "";
    m_Bpcl.m_procstate    = PR_HVBP_06; 
    m_Bpcl.m_finalstatedate = m_cBeps127.TrnsmtDt; //��̬����, NPC��������
    m_Bpcl.m_nboftxs      = atoi(m_cBeps127.PKGGrpHdrNbOfTxs.c_str());
    m_Bpcl.m_sapsnboftxs  = 0; 
    m_Bpcl.m_ctrlsapssum  = 0.00; 
    m_Bpcl.m_ctrlsum      = atof(m_cBeps127.CtrlSum.c_str()); 
    m_Bpcl.m_dgtsign      ="DIGITAL SIGN";  
    m_Bpcl.m_realtimeflag = "0"; 
    m_Bpcl.m_isrbflg      = "0"; 
    m_Bpcl.m_srcflag      = "0";
    m_Bpcl.m_checkstate   = PR_CNCH_00;
    m_Bpcl.m_ccy          = m_cBeps127.CtrlSumCcy; 
    m_Bpcl.m_recvdest     = "1"; 
    m_Bpcl.m_rmk          = m_cBeps127.Rmk; 
	m_Bpcl.m_pkgrtrltd  = atoi(m_cBeps127.PKGRtrLtd.c_str());
    
    strncpy(szParentName,"CstmrDrctDbtInf",sizeof(szParentName)-1);
    int iNumParent = m_cBeps127.GetDetailCnt();
    
    //��������
	if (0 != m_BpList.setctx(m_dbproc))
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
		PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
	}
    for(int i = 0; i < iNumParent; i++)
    {
        m_cBeps127.ParseDetail(i);
        m_BpList.m_busistate   = "PR00"; 
        m_BpList.m_processcode = "";
        m_BpList.m_rjctinf     = "";
        m_BpList.m_procstate   = PR_HVBP_06;
        m_BpList.m_rmk         = m_cBeps127.Rmk; 
        m_BpList.m_addtlinf    = m_cBeps127.AddtlInf; 
        m_BpList.m_isrbflg     = "0"; 
        m_BpList.m_recvdest    = "1"; 
        m_BpList.m_dbtaddr     = m_cBeps127.DbtrAdrLine ; 
        m_BpList.m_cdtaddr     = m_cBeps127.CdtrAdrLine; 
        m_BpList.m_acctstate   = "00"; 
        m_BpList.m_workdate    = m_sWorkDate;
        m_BpList.m_consigdate  = m_cBeps127.TxId.substr(0, 8);  
        m_BpList.m_msgid       = m_cBeps127.MsgId;  
        m_BpList.m_instgdrctpty = m_cBeps127.InstgDrctPty;
        m_BpList.m_instddrctpty = m_cBeps127.InstdDrctPty; 
        m_BpList.m_txid         = m_cBeps127.TxId; 
        m_BpList.m_agrmtnb      = m_cBeps127.AgrmtNb;
        m_BpList.m_dbtnm        = m_cBeps127.DbtrNm; 
        m_BpList.m_dbtracctid   = m_cBeps127.DbtrAcctId; 
        m_BpList.m_dbtrissr     = m_cBeps127.DbtrAcctIssr; 
        m_BpList.m_dbtrbrnchid  = m_cBeps127.DbtrAgtId;
        m_BpList.m_cdtrnm       = m_cBeps127.CdtrNm; 
        m_BpList.m_cdtracctid   = m_cBeps127.CdtrAcctId;  
        m_BpList.m_cdtrissr     = m_cBeps127.CdtrAcctIssr;  
        m_BpList.m_cdtrbrnchid  = m_cBeps127.CdtrAgtId; //�������к�
        m_BpList.m_currency     = m_cBeps127.CtrlSumCcy; 
        m_BpList.m_amount       = atof(m_cBeps127.CstmrDrctDbtInfAmt.c_str()); 
        m_BpList.m_pmttpprtry   = m_cBeps127.CtgyPurpPrtry; 
        m_BpList.m_purpprtry    = m_cBeps127.CstmrDrctDbtInfPrtry; 
        m_BpList.m_npcmsglen    = m_cBeps127.m_sXMLBuff.length();
        m_BpList.m_finalstatedate = m_Bpcl.m_finalstatedate;
        m_BpList.m_npcmsg = ""; 
        //m_BpList.m_sorinpcmsg = ""; 
        m_BpList.m_mbmsg = ""; 
        //m_BpList.m_sorimbmsg = ""; 
        m_BpList.m_checkstate = PR_CNCH_00;
		m_BpList.m_pkgrtrltd  = atoi(m_cBeps127.PKGRtrLtd.c_str());
		
        //m_BpList.m_printno = 0;
        //ҵ������Ϊ�����ʽ��ǻ���ҵ��
        if("B104" == m_cBeps127.CtgyPurpPrtry)
        {
            strncpy(szChildName,"TxsDtls",sizeof(szChildName)-1);
            m_BpList.m_cstmrcdttrfaddtlinf = "/FlowNb/" + m_cBeps127.NtlTrsrCdtInfFlowNb + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/Amt/" + m_cBeps127.NtlTrsrCdtInfCcy + m_cBeps127.NtlTrsrCdtInfAmt + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/RptCd/" + m_cBeps127.NtlTrsrCdtInfRptCd + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/RcvCd/" + m_cBeps127.NtlTrsrCdtInfRcvCd + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/RptFrms/" + m_cBeps127.NtlTrsrCdtInfRptFrms + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/RptNb/" + m_cBeps127.NtlTrsrCdtInfRptNb + ":";

            m_BpList.m_cstmrcdttrfaddtlinf += "/BugtLvl/" + m_cBeps127.BugtLvl + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/Ind/" + m_cBeps127.Ind + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/BugtTp/" + m_cBeps127.BugtTp + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/NbOfTxs/" + m_cBeps127.NtlTrsrCdtInfNbOfTxs + ":";

            //����
            int iNumChild = atoi(m_cBeps127.NtlTrsrCdtInfNbOfTxs.c_str());
            for(int j = 0; j < iNumChild; j++)
            {
            	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__[%d][%d]", i, j);
                string strTemp = m_cBeps127.GetValueFromLiLCycle(
                        szParentName, i, szChildName, j, "NtlTrsrCdtInfTpCd");
                m_BpList.m_cstmrcdttrfaddtlinf += "/TpCd/" + strTemp + ":";
				m_cBeps127.m_strTx2 += m_cBeps127.CHECKVALUE(strTemp);
				
                strTemp = m_cBeps127.GetValueFromLiLCycle(
                        szParentName, i, szChildName, j, "SbjtCd");
                m_BpList.m_cstmrcdttrfaddtlinf += "/SbjtCd/" + strTemp + ":";
                m_cBeps127.m_strTx2 += m_cBeps127.CHECKVALUE(strTemp);
				
                string strTemp1 = m_cBeps127.GetValueFromLiLCycle(
                        szParentName,i,szChildName,j,"AmtCcy");
                strTemp = strTemp1 + m_cBeps127.GetValueFromLiLCycle(
                        szParentName,i,szChildName,j,"Amt");
                m_BpList.m_cstmrcdttrfaddtlinf += "/Amt/" + strTemp + ":";
            	m_cBeps127.m_strTx2 += m_cBeps127.CHECKVALUE(strTemp);
			}           
        }
        //ҵ������Ϊ�����ʽ��ծ�Ҹ���ǻ���ҵ��
        if("B307" == m_cBeps127.CtgyPurpPrtry)
        {
            //__wsh 2012-05-21 ������ѭ���ĸ������Ҫ��ԭ�ڵ���ͬ����������PMTSXML.CFG���һ��
            //strncpy(szChildName,"NtlTrsrInfTxsDtls",sizeof(szChildName)-1);
            strncpy(szChildName,"TxsDtls",sizeof(szChildName)-1);
            
            m_BpList.m_cstmrcdttrfaddtlinf = "/FlowNb/" + m_cBeps127.NtlTrsrCdtInfFlowNb + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/Amt/" + m_cBeps127.NtlTrsrCdtInfCcy + m_cBeps127.NtlTrsrCdtInfAmt + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/RptCd/" + m_cBeps127.NtlTrsrCdtInfRptCd + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/RcvCd/" + m_cBeps127.NtlTrsrCdtInfRcvCd + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/RptFrms/" + m_cBeps127.NtlTrsrCdtInfRptFrms + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/RptNb/" + m_cBeps127.NtlTrsrCdtInfRptNb + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/NbOfTxs/" + m_cBeps127.NtlTrsrInfNbOfTxs + ":";

            Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
                  "szParentName=%s, szChildName=%s", szParentName, szChildName);
            //����
            int iNumChild = atoi(m_cBeps127.NtlTrsrInfNbOfTxs.c_str());
            for( int j = 0; j < iNumChild ; j++ )
            {
                string strTemp = m_cBeps127.GetValueFromLiLCycle(
                            szParentName,i,szChildName,j,"NtlTrsrInfTpCd");
                m_BpList.m_cstmrcdttrfaddtlinf += "/TpCd/" + strTemp + ":";
				Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strtemp=[%s]", strTemp.c_str());
				m_cBeps127.m_strTx2 += m_cBeps127.CHECKVALUE(strTemp);
				
                strTemp = m_cBeps127.GetValueFromLiLCycle(
                            szParentName,i,szChildName,j,"CptlCd");
                m_BpList.m_cstmrcdttrfaddtlinf += "/CptlCd/" + strTemp + ":";
                Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strtemp=[%s]", strTemp.c_str());
                m_cBeps127.m_strTx2 += m_cBeps127.CHECKVALUE(strTemp);
				
                string strTemp1 = m_cBeps127.GetValueFromLiLCycle(
                            szParentName,i,szChildName,j,"CptlAmtCcy");
                strTemp = strTemp1 + m_cBeps127.GetValueFromLiLCycle(szParentName,i,szChildName,j,"CptlAmt");
                m_BpList.m_cstmrcdttrfaddtlinf += "/CptlAmt/" + strTemp + ":";
				Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strtemp=[%s]", strTemp.c_str());
				m_cBeps127.m_strTx2 += m_cBeps127.CHECKVALUE(strTemp);
				
                strTemp = m_cBeps127.GetValueFromLiLCycle(szParentName,i,szChildName,j,"AcrlCd");
                m_BpList.m_cstmrcdttrfaddtlinf += "/AcrlCd/" + strTemp + ":";
				Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strtemp=[%s]", strTemp.c_str());
				m_cBeps127.m_strTx2 += m_cBeps127.CHECKVALUE(strTemp);
				
                strTemp1 = m_cBeps127.GetValueFromLiLCycle(szParentName,i,szChildName,j, "AcrlAmtCcy");
                strTemp = strTemp1 + m_cBeps127.GetValueFromLiLCycle(szParentName,i,szChildName,j,"AcrlAmt");
                m_BpList.m_cstmrcdttrfaddtlinf += "/AcrlAmt/" + strTemp + ":";
            	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "strtemp=[%s]", strTemp.c_str());
            	m_cBeps127.m_strTx2 += m_cBeps127.CHECKVALUE(strTemp);
            }
        }

        //__wsh 2012-05-31 ����B308 B309 B310 B311�������鴮����ȷ������ͼ����ʾ����ȷ����
        //ҵ������ΪС��֧��ϵͳ֧Ʊ����ҵ��
        if("B308" == m_cBeps127.CtgyPurpPrtry)
        {
            strncpy(szChildName,"EndrsrDtl",sizeof(szChildName)-1);
            m_BpList.m_cstmrcdttrfaddtlinf = "/IsseDt/" + m_cBeps127.ChqInfIsseDt + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/PayDT/" + m_cBeps127.ChqInfPayDT + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/Nb/" + m_cBeps127.ChqInfNb + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/PmtPswd/" + m_cBeps127.ChqInfPmtPswd + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/Purp/" + m_cBeps127.ChqInfPurp + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/ImgTp/" + m_cBeps127.ChqInfImgTp + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/NbOfEndrsr/" + m_cBeps127.ChqInfNbOfEndrsr + ":";

                          
            int iNumChild = atoi(m_cBeps127.ChqInfNbOfEndrsr.c_str());
            for( int j = 0; j < iNumChild; j++)
            {
                string strTemp = m_cBeps127.GetValueFromLiLCycle(szParentName,i,szChildName,j,"ChqInfNm");
                m_BpList.m_cstmrcdttrfaddtlinf += "/Nm/" + strTemp + ":";
            	m_cBeps127.m_strTx2 += m_cBeps127.CHECKVALUE(strTemp);
            }
            //m_BpList.m_cstmrcdttrfaddtlinf += "/ChqInfImgTp/" + m_cBeps127.ChqInfImgTp + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/ImgFrntLen/" + m_cBeps127.ChqInfImgFrntLen + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/ImgBckLen/" + m_cBeps127.ChqInfImgBckLen + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/ImgFrntData/" + m_cBeps127.ChqInfImgFrntData + ":";  
            m_BpList.m_cstmrcdttrfaddtlinf += "/ImgBckData/" + m_cBeps127.ChqInfImgBckData;
            
            //__wsh 2012-05-30 ������ͼƬ��ǩMD5ֵ 
            doMd5(m_cBeps127.ChqInfImgFrntData, m_cBeps127.m_strFrtImgMd5);
            doMd5(m_cBeps127.ChqInfImgBckData, m_cBeps127.m_strBckImgMd5);

        }

        //ҵ������ΪС��֧��ϵͳͨ��Ʊ�ݽ���ҵ��
        if("B309" == m_cBeps127.CtgyPurpPrtry ||
           "B310" == m_cBeps127.CtgyPurpPrtry ||
           "B311" == m_cBeps127.CtgyPurpPrtry)
        {
            //strncpy(szChildName,"BllInfEndrsrDtl",sizeof(szChildName)-1);
            //__wsh 2012-05-30 ������ѭ���ĸ������Ҫ��ԭ�ڵ���ͬ����������PMTSXML.CFG���һ��
            strncpy(szChildName,"EndrsrDtl",sizeof(szChildName)-1);
            m_BpList.m_cstmrcdttrfaddtlinf = "/IsseDt/" + m_cBeps127.BllInfIsseDt + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/Amt/" + m_cBeps127.BllInfCcy + m_cBeps127.BllInfAmt + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/PayDT/" + m_cBeps127.BllInfPayDT + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/Nb/" + m_cBeps127.BllInfNb + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/PmtPswd/" + m_cBeps127.BllInfPmtPswd + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/MtrtyDt/" + m_cBeps127.MtrtyDt + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/Seal/" + m_cBeps127.Seal+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/AccptncAgrmtNb/" + m_cBeps127.AccptncAgrmtNb+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/AccptncDt/" + m_cBeps127.AccptncDt+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/AccptncNm/" + m_cBeps127.AccptncNm+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/ApplyNm/" + m_cBeps127.ApplyNm+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/ApplyAcct/" + m_cBeps127.ApplyAcct+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/DrwrNm/" + m_cBeps127.DrwrNm + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/DrwrAcct/" + m_cBeps127.DrwrAcct+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/TxlCtrctNb/" + m_cBeps127.TxlCtrctNb+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/Purp/" + m_cBeps127.BllInfPurp+ ":";            
            m_BpList.m_cstmrcdttrfaddtlinf += "/NbOfEndrsr/" + m_cBeps127.BllInfNbOfEndrsr + ":";

                          
            int iNumChild = atoi(m_cBeps127.BllInfNbOfEndrsr.c_str());
            for( int j = 0; j < iNumChild ; j++ )
            {
                string strTemp = m_cBeps127.GetValueFromLiLCycle(szParentName,i,szChildName,j,"BllInfNm");
                m_BpList.m_cstmrcdttrfaddtlinf += "/Nm/" + strTemp+ ":";
				//m_cBeps127.m_strTx2 += Trim(strTemp) + "|";
				m_cBeps127.m_strTx2 += m_cBeps127.CHECKVALUE(strTemp);
            }
            m_BpList.m_cstmrcdttrfaddtlinf += "/OrgnlCdtrNm/" + m_cBeps127.OrgnlCdtrNm+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/ImgTp/" + m_cBeps127.BllInfImgTp+ ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/ImgFrntLen/" + m_cBeps127.BllInfImgFrntLen + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/ImgBckLen/" + m_cBeps127.BllInfImgBckLen + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/ImgFrntData/" + m_cBeps127.BllInfImgFrntData + ":";
            m_BpList.m_cstmrcdttrfaddtlinf += "/ImgBckData/" + m_cBeps127.BllInfImgBckData;

            //__wsh 2012-05-30 ������ͼƬ��ǩMD5ֵ
            doMd5(m_cBeps127.BllInfImgFrntData, m_cBeps127.m_strFrtImgMd5);
            doMd5(m_cBeps127.BllInfImgBckData, m_cBeps127.m_strBckImgMd5);
        }
        
        // ���ڼ�ǩ��ѭ��������ѭ����������Ҫ����ѭ������֮�󣬲�����ѭ���ļ�ǩ
		m_cBeps127.AddTxStr();
		m_cBeps127.m_strTx2.clear();
        
        //��ϸ����������
        int iRet = m_BpList.insert();
        if(OPERACT_SUCCESS != iRet)
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_BpList.insert error iRet= [%d],[%s]", iRet, m_BpList.GetSqlErr());
            PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "������ϸ��ʧ��");
           
        }
    }
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps127::SetData()");
    return OPERACT_SUCCESS;
}

