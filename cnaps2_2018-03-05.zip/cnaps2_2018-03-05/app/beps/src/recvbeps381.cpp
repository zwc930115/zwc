/******************************************************************** 
文件名： recvbeps381.cpp
创建人： handongfeng
日  期： 2011-02-23
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbeps381.h"

CRecvbeps381::CRecvbeps381()
{
    m_colltnchrgscl.m_msgtp = "beps.381.001.01";
    m_colltnchrgslist.m_msgtp = "beps.381.001.01";
    memset(m_sMsgRefId389, 0x00, sizeof(m_sMsgRefId389));

}

CRecvbeps381::~CRecvbeps381()
{

}

int CRecvbeps381::Work(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps381::Work()");
    
    m_IsSendMB = false;
    // 解析报文
    unPack(szMsg);

    CheckArgeeAndUser();

    SetData(szMsg);

    // 插入数据
    InsertData();
    
    CheckSign381();

    SendRtuMsg();

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps381::Work()");
    return OPERACT_SUCCESS;
}

void CRecvbeps381::SendRtuMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "ENTER CRecvbeps381::SetRtuMsg");

   char szISOchDate[30 + 1]  = {0};
   char szchMsgId[128 +1] = {0};
   
   //获取ISODateTime
   GetIsoDateTime(m_dbproc, SYS_BEPS, szISOchDate);
   
   //取msgid
   GetMsgIdValue(m_dbproc, szchMsgId, eMsgId, SYS_BEPS);

    m_beps389.MsgId           = szchMsgId;//报文标识号	
    m_beps389.CreDtTm         = szISOchDate;//报文发送时间
    m_beps389.InstgDrctPty    = m_beps381.InstdDrctPty;//发起直接参与机构
    m_beps389.GrpHdrInstgPty  = m_beps381.InstdDrctPty;//间接发起参与机构
    m_beps389.InstdDrctPty    = "0000";//接收直接参与机构
    m_beps389.GrpHdrInstdPty  = "0000";//间接接收参与机构
    m_beps389.SysCd           = "BEPS";//系统编号
    //m_beps389.Rmk             = m_colltnchrgscl.m_rmk;//备注

    m_beps389.OrgnlMsgId      = m_beps381.MsgId;//原报文标识号
    m_beps389.OrgnlInstgPty   = m_beps381.InstgDrctPty;//原发起参与机构
    m_beps389.OrgnlMT     = "beps.381.001.01";//原报文类型

    if(m_agreeanduser)
    {
        m_beps389.Sts             = "PR10";//业务状态
    }
    else
    {
        m_beps389.Sts             = "PR09";//业务状态
        m_beps389.RjctCd          = "RJ90"; 
        m_beps389.RjctInf         = "其他";
    }
    //m_beps389.PrcPty          = m_colltnchrgscl.m_rjctprcpty;//业务处理参与机构

    bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId389, eRefId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "参数错误");
	    PMTS_ThrowException(PRM_FAIL);
    }

    // 组文件头
    m_beps389.CreateXMlHeader("BEPS",                        \
                                m_beps389.MsgId.substr(0, 8).c_str(), \
                                m_beps389.InstgDrctPty.c_str(),\
                                m_beps389.InstdDrctPty.c_str(),\                                
                                "beps.389.001.01",              \
                                m_sMsgRefId389);

    char   sSignedStr[10240 + 1] = {0};
    m_beps389.getOriSignStr();
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_sSignBuff = [%s]", m_beps389.m_sSignBuff.c_str());

    AddSign(m_beps389.m_sSignBuff.c_str(), sSignedStr, RAWSIGN,m_beps389.InstgDrctPty.c_str());

    m_beps389.m_szDigitSign = sSignedStr;

    m_beps389.CreateXml();

    AddQueue(m_beps389.m_sXMLBuff, m_beps389.m_sXMLBuff.size());
    
    Insert389Data();

    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "LEAVE CRecvbeps381::SetRtuMsg");
    return ;
}

void CRecvbeps381::Insert389Data()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBeps381::Insert389Data()");

    m_Bpbizpubntce.m_workdate = m_beps389.MsgId.substr(0, 8); 
    m_Bpbizpubntce.m_msgtp = "beps.389.001.01"; 
    m_Bpbizpubntce.m_mesgid = m_sMsgRefId389; 
    m_Bpbizpubntce.m_mesgrefid = m_sMsgRefId389; 
    m_Bpbizpubntce.m_msgid = m_beps389.MsgId; 
    m_Bpbizpubntce.m_instgdrctpty = m_beps381.InstdDrctPty; 
    m_Bpbizpubntce.m_instgpty = m_beps381.GrpHdrInstdPty; 
    m_Bpbizpubntce.m_instddrctpty = "0000"; 
    m_Bpbizpubntce.m_instdpty = "0000"; 
    m_Bpbizpubntce.m_syscd = "BEPS"; 
    //m_Bpbizpubntce.m_rmk = ; 
    m_Bpbizpubntce.m_orgnlmsgid = m_beps381.MsgId; 
    m_Bpbizpubntce.m_orgnlinstgpty = m_beps381.InstgDrctPty; 
	m_Bpbizpubntce.m_orgnlmt = "beps.381.001.01";
    m_Bpbizpubntce.m_orgnlbtchnb = atoi(m_beps381.OrgnlBtchNb.c_str()); 
    m_Bpbizpubntce.m_status = m_beps389.Sts; 
    m_Bpbizpubntce.m_rjctcd = m_beps389.RjctCd; 
    m_Bpbizpubntce.m_rjctinf = m_beps389.RjctInf; 
    //m_Bpbizpubntce.m_rjcprcpty = ; 
    m_Bpbizpubntce.m_procstate = PR_HVBP_08; //已回执
    m_Bpbizpubntce.m_proctime = ""; 
    m_Bpbizpubntce.m_addtlinf = ""; 

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_status=[%s]",m_Bpbizpubntce.m_status.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_rjctcd=[%s]",m_Bpbizpubntce.m_rjctcd.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_rjctinf=[%s]",m_Bpbizpubntce.m_rjctinf.c_str());	


    SETCTX(m_Bpbizpubntce);
    int iRet = m_Bpbizpubntce.insert();
    if (OPERACT_SUCCESS != iRet)
    { 
        sprintf(m_szErrMsg,"insert() error,error code = [%d],error cause = [%s]",iRet,m_Bpbizpubntce.GetSqlErr());	  
        Trace(L_INFO,  __FILE__,	__LINE__, NULL, m_szErrMsg);	  
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL,m_szErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBeps381::Insert389Data()");

}

INT32 CRecvbeps381::unPack(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps381::unPack()");
    int iRet = -1;
    
    // 报文是否为空
    if (NULL == szMsg || '\0' == szMsg)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");	
    	PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文为空");
    }
    
    //获取工作日期
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(iRet != RTN_SUCCESS)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");	
    	PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;    

    // 解析报文
    iRet = m_beps381.ParseXml(szMsg);
    if (OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错! iRet= %d", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "获取解析对象失败");
    }
    
    m_strMsgID = m_beps381.MsgId;
    //ZFPTLOG.SetLogInfo("381", m_strMsgID.c_str());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps381::unPack()");
    return OPERACT_SUCCESS;
}

INT32 CRecvbeps381::InsertData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps381::InsertData()");

	m_colltnchrgscl.m_busistate = PROCESS_PR00;	
    m_colltnchrgscl.m_procstate = m_colltnchrgslist.m_procstate; //已收妥
    m_colltnchrgscl.m_workdate = m_strWorkDate ; 
    m_colltnchrgscl.m_trnsmtdt = m_beps381.OrgnlTrnsmtDt;     
    m_colltnchrgscl.m_consigdate = m_strWorkDate ; 
    m_colltnchrgscl.m_mesgid = m_beps381.m_PMTSHeader.getMesgID(); 
    m_colltnchrgscl.m_mesgrefid = m_beps381.m_PMTSHeader.getMesgRefID();
    m_colltnchrgscl.m_syscd = "BEPS" ; 
    m_colltnchrgscl.m_srcflag = m_colltnchrgslist.m_srcflag;

    m_colltnchrgscl.m_msgid = m_beps381.MsgId; 
    m_colltnchrgscl.m_checkstate = "1"; 
    m_colltnchrgscl.m_instgdrctpty = m_beps381.InstgDrctPty; 
    m_colltnchrgscl.m_instgpty = m_beps381.GrpHdrInstgPty; 
    m_colltnchrgscl.m_instddrctpty = m_beps381.InstdDrctPty; 
    m_colltnchrgscl.m_instdpty = m_beps381.GrpHdrInstdPty; 
    m_colltnchrgscl.m_rmk = m_beps381.Rmk; 
    m_colltnchrgscl.m_btchnb = m_beps381.OrgnlBtchNb; 
    m_colltnchrgscl.m_dbtrmmbid = m_beps381.RcvgDtlsBrnchId; 
    m_colltnchrgscl.m_cdtrmmbid = m_beps381.RcvgDtlsBrnchId; 
    m_colltnchrgscl.m_cdbtrnm = m_beps381.CdtrNm; 
    m_colltnchrgscl.m_cdbtrid = m_beps381.CdtrAcctId; 
    m_colltnchrgscl.m_cdbtrbrnchid = m_beps381.CdtrAgtId; 
    m_colltnchrgscl.m_currency = m_beps381.AmtCcy; 
	m_colltnchrgscl.m_rcvsndgttlamt = atof(m_beps381.RcvgTtlAmt.c_str()); 
	m_colltnchrgscl.m_rcvsndgttlnb = atoi(m_beps381.RcvgTtlNb.c_str()) ; 

    //m_colltnchrgscl.m_ttlamt = atof(m_beps381.RcvgTtlAmt.c_str()); 
    //m_colltnchrgscl.m_cdbtrnb = atoi(m_beps381.RcvgTtlNb.c_str()) ; 
    m_colltnchrgscl.m_ctgyprtry = m_beps381.OrgnlTxTpCd ; 
    //m_colltnchrgscl.m_puryprtry = m_beps381.OrgnlCtgyPurpCd ; 

    if(m_agreeanduser)
    {
        m_colltnchrgscl.m_npcprcsts = "PR10";//业务状态
    }
    else
    {
        m_colltnchrgscl.m_npcprcsts     = "PR09";//业务状态
        m_colltnchrgscl.m_npcprccd      = "RJ90"; 
        m_colltnchrgscl.m_npcrjctinf    = "其他";
    }

	m_colltnchrgscl.m_orgnlbtchnb = m_beps381.OrgnlBtchNb;
	m_colltnchrgscl.m_orgnlinstgpty = m_beps381.OrgnlInstgPty;
	m_colltnchrgscl.m_orgnlmsgid = m_beps381.OrgnlMsgId;
	m_colltnchrgscl.m_orgnlrtrltd = atoi(m_beps381.OrgnlRtrLtd.c_str());
	m_colltnchrgscl.m_orgnltrnsmtdt = m_beps381.OrgnlTrnsmtDt;
	m_colltnchrgscl.m_orgnlttlam = atof(m_beps381.OrgnlTtlAmt.c_str());
	m_colltnchrgscl.m_orgnlttlnb = atoi(m_beps381.OrgnlTtlNb.c_str());
    m_colltnchrgscl.m_orgnltxtpcd = m_beps381.OrgnlTxTpCd;
	
    m_colltnchrgscl.setctx(m_dbproc);
    int iRet = m_colltnchrgscl.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__,  __LINE__, NULL, 
            "m_colltnchrgscl.insert() failed:error code =[%d],error cause =[%s]", iRet,m_colltnchrgscl.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "新增表失败");
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps381::InsertData()");
    return iRet;
}

INT32 CRecvbeps381::SetData(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvbeps381::SetData()");

    SETCTX(m_colltnchrgslist);
    int iRet = -1;
    int iNum = atoi(m_beps381.OrgnlTtlNb.c_str());

    char sMesgId[20 + 1] = {0};
    
    GetMsgIdValue(m_dbproc, sMesgId, eRefId,  SYS_BEPS);
    
    m_colltnchrgslist.m_instgdrctpty = m_beps381.InstgDrctPty;//发起直接参与机构
    m_colltnchrgslist.m_instgpty = m_beps381.GrpHdrInstgPty;//间接发起参与机构
    m_colltnchrgslist.m_instddrctpty = m_beps381.InstdDrctPty;//接收直接参与机构
    m_colltnchrgslist.m_instdpty = m_beps381.GrpHdrInstdPty;//间接发起参与机构
    m_colltnchrgslist.m_syscd = "BEPS"           ;//系统编号

    if(m_agreeanduser)
    {
		m_colltnchrgslist.m_procstate = PR_HVBP_28;
    }
    else
    {
		m_colltnchrgslist.m_procstate = PR_HVBP_24;
    }

	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iNum[%d]",iNum);
    for(int i = 0; i < iNum; i++)
    {
        m_beps381.ParseDetail(i);

        //add jienjun 20120606
        m_colltnchrgslist.m_workdate = m_strWorkDate;
        m_colltnchrgslist.m_consigdate = m_strWorkDate;
        m_colltnchrgslist.m_msgtp = "beps.381.001.01";
        m_colltnchrgslist.m_mesgid = sMesgId;
        m_colltnchrgslist.m_mesgrefid = sMesgId;
        m_colltnchrgslist.m_msgid = m_beps381.MsgId;//报文标识号	
        m_colltnchrgslist.m_rmk = m_beps381.Rmk;//备注
        m_colltnchrgslist.m_srcflag = "3";//1：往帐 2：付款方来帐 3：收款方来帐
        m_colltnchrgslist.m_btchnb = m_beps381.OrgnlBtchNb;
        m_colltnchrgslist.m_txid = m_beps381.TxId;
        m_colltnchrgslist.m_dbtrnm = m_beps381.DbtrNm           ;//付款人户名
        m_colltnchrgslist.m_dbtrid = m_beps381.DbtrAcctId           ;//付款人账号
        m_colltnchrgslist.m_dbtrmmbid = m_beps381.InstgDrctPty;
        m_colltnchrgslist.m_dbtrbrnchid = m_beps381.RcvgDtlsBrnchId;//付款行行号
        m_colltnchrgslist.m_cdtrmmbid = m_beps381.OrgnlInstgPty;
        m_colltnchrgslist.m_cdtrbrnchid = m_beps381.CdtrAgtId           ;//收款行行号
        m_colltnchrgslist.m_cdtrnm = m_beps381.CdtrNm;//收款人名称
        m_colltnchrgslist.m_cdtrid = m_beps381.CdtrAcctId;//收款人账号
        m_colltnchrgslist.m_currency = m_beps381.AmtCcy;//货币符号
        //m_colltnchrgslist.m_currency = "CNY";//测试用
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_colltnchrgslist.m_currency=%s", m_colltnchrgslist.m_currency.c_str());
        m_colltnchrgslist.m_amout = atof(m_beps381.Amt.c_str());//金额
        m_colltnchrgslist.m_ctgyprtry = m_beps381.OrgnlTxTpCd;
        m_colltnchrgslist.m_puryprtry = m_beps381.OrgnlCtgyPurpCd;
        //m_colltnchrgslist.m_endtoendid = m_beps381.EndToEndId;
        //m_colltnchrgslist.m_chckflg = m_beps381.ChckFlg;

		m_colltnchrgslist.m_processcode = m_beps381.RjctCd;
		m_colltnchrgslist.m_busistate = m_beps381.Sts;
		m_colltnchrgslist.m_rjctinf = m_beps381.RspsnInfRjctInf;

        m_colltnchrgslist.m_addtlinf = m_beps381.AddtlInf;//附言
        
        //明细表插入数据
        if(OPERACT_SUCCESS != m_colltnchrgslist.insert())
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "插入明细表失败,回滚汇总表, ERROR = %s", m_colltnchrgslist.GetSqlErr());
            break; //return OPERACT_FAILED;  回执这里不能直接返回
        }
        
        // 循环加签要素
        m_beps381.AddTxStr();  

        ++m_iTotalNum;
        m_iTotalAmt += m_colltnchrgslist.m_amout;
        
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvbeps381::SetData()");
    return OPERACT_SUCCESS;
}

int CRecvbeps381::CheckArgeeAndUser()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBeps381::CheckArgeeAndUser()");
    	    

    if(!CheckUserState("beps.381.001.01",m_beps381.CdtrAcctId))
    {
        m_agreeanduser = false;
        return OPERACT_FAILED;
    } 

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBeps381::CheckArgeeAndUser()");
    return OPERACT_SUCCESS;
}

void CRecvbeps381::CheckSign381()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBeps381::CheckSign381()");
	
	m_beps381.getOriSignStr();
	
	CheckSign(m_beps381.m_sSignBuff.c_str(),
			m_beps381.m_szDigitSign.c_str(),
			m_beps381.InstgDrctPty.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBeps381::CheckSign381()");
}




