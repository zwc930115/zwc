/******************************************************************** 
�ļ����� recvcmt324.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-04-28
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvcmt324.h"

using namespace ZFPT;

CRecvCmt324::CRecvCmt324()
{
    m_strMsgTp	  = "CMT324";
    memset(m_sOldMsgId, 0x00, sizeof(m_sOldMsgId));
}

CRecvCmt324::~CRecvCmt324()
{
	
}

void CRecvCmt324::GetOrgnBuss()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CRecvCmt324::GetOrgnBuss");

    SETCTX(m_cOrgnBpcstpmtcxl);
    char m_sOrgnMsgId[35 + 1] = {0};
    sprintf(m_sOrgnMsgId, "%8s%08s", m_cmt324.sConsigndate, m_cmt324.sRevctmssno);        
    m_cBpcstpmtcxl.m_msgid = m_sOrgnMsgId ; 
    m_cBpcstpmtcxl.m_instgdrctpty = m_cmt324.sOldsendsapbk ; 
    
    int iRet = m_cOrgnBpcstpmtcxl.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��, iRet = %d", iRet, m_cOrgnBpcstpmtcxl.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CRecvCmt324::GetOrgnBuss"); 
}

INT32 CRecvCmt324::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CRecvCmt324::CheckValues");
    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CRecvCmt324::CheckValues"); 
    return OPERACT_SUCCESS;
}

void CRecvCmt324::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CRecvCmt324::SetData");

    char m_sMsgRefId[20 + 1] = {0};
    bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Get MsgRefId fail");
	    PMTS_ThrowException(PRM_FAIL);
    }
    
    char m_szchMsgId[35 + 1] = {0};
    bRet = GetMsgIdValue(m_dbproc, m_szchMsgId, eMsgId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡmsgidʧ��");
        PMTS_ThrowException(PRM_FAIL);    
    }    
    m_cBpcstpmtcxl.m_msgid = m_szchMsgId; 
    
    m_cBpcstpmtcxl.m_instgdrctpty = m_cmt324.m_CMTHeaderMap.startAddr  ; 
    m_cBpcstpmtcxl.m_instddrctpty = m_cmt324.m_CMTHeaderMap.destAddr  ; 
    m_cBpcstpmtcxl.m_oricxlinstgdrctpty = m_cmt324.sOldsendsapbk ; 
    m_cBpcstpmtcxl.m_oricxlmsgid = m_cOrgnBpcstpmtcxl.m_msgid; 
    m_cBpcstpmtcxl.m_oricxlmsgtp = m_cOrgnBpcstpmtcxl.m_msgtp; 
    //m_cBpcstpmtcxl.m_addtlinf = m_cmt324.sRemark  ; 
	SetGbkToUtf8(m_cmt324.sRemark, m_cBpcstpmtcxl.m_addtlinf);
    m_cBpcstpmtcxl.m_procstate = "04"  ; 
    //m_cBpcstpmtcxl.m_proctime = m_cmt324.  ; 
    m_cBpcstpmtcxl.m_oriinstgdrctpty = m_cmt324.sOldsendsapbk  ; 

    char m_sOrgnMsgId[35 + 1] = {0};
    sprintf(m_sOrgnMsgId, "%8s%08s", m_cmt324.sOldpackdate, m_cmt324.sOldpackno);        
    m_cBpcstpmtcxl.m_orimsgid = m_sOrgnMsgId ; 
    
    m_cBpcstpmtcxl.m_orimsgtp = m_cOrgnBpcstpmtcxl.m_orimsgtp; 
    //m_cBpcstpmtcxl.m_prcsts = m_cmt324.  ; 
    //m_cBpcstpmtcxl.m_prccd = m_cmt324.  ; 
    //m_cBpcstpmtcxl.m_rjctinf = m_cmt324.  ; 
    m_cBpcstpmtcxl.m_netgdt = m_cmt324.sNetdate  ; 
    m_cBpcstpmtcxl.m_netgrnd = m_cmt324.sNetno  ; 
    m_cBpcstpmtcxl.m_sttlmdt = m_cmt324.sSapdate  ; 

	//��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS,m_cmt324.sOldsendsapbk);
	if(iRet != RTN_SUCCESS)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");	
		PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
	}    
    m_cBpcstpmtcxl.m_workdate = m_sWorkDate  ; 
    
    m_cBpcstpmtcxl.m_msgtp = "CMT324"; 
    m_cBpcstpmtcxl.m_mesgid = m_cmt324.GetHeadMesgID()  ; 
    m_cBpcstpmtcxl.m_mesgrefid = m_cmt324.GetHeadMesgReqNo()  ; 

    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CRecvCmt324::SetData"); 
}

void CRecvCmt324::UpdateDB()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt324::UpdateDb()");	

	string strSQL;
	strSQL += "UPDATE BP_CSTPMTCXL t SET t.Procstate = '04'";
	strSQL += " WHERE t.msgid = '";
	strSQL += m_cBpcstpmtcxl.m_msgid;
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_cBpcstpmtcxl.m_instgdrctpty; 
	strSQL += "'";
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, strSQL.c_str());
	
    SETCTX(m_cBpcstpmtcxl);
	int iRet = m_cBpcstpmtcxl.execsql(strSQL.c_str());
    if (iRet != SQL_SUCCESS)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "���±�ʧ��[%d][%s]",
		    iRet, m_cBpcstpmtcxl.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, "���±�ʧ��");
	}
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt324::UpdateDb()");	
}

INT32 CRecvCmt324::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt324::Work()");	

	// ��������
	unPack(sMsg);

    // ҵ����
    CheckValues();

    GetOrgnBuss();
    
    SetData();
    
	InsertDb(sMsg);
	
	UpdateDB();

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt324::work()");

	return RTN_SUCCESS;
}

INT32 CRecvCmt324::unPack(LPCSTR sMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt324::unPack");	

    int iRet = RTN_FAIL;
    char sMsgId[35 + 1] = { 0 };

    // �����Ƿ�Ϊ��
    if (NULL == sMsg || '\0' == sMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }

    // ��������
    iRet = m_cmt324.ParseCmt(sMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������,iRet[%d]", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
    }

    // ���ı�ʶ�š�ϵͳ���
    sprintf(sMsgId, "%8s%08s", m_cmt324.sConsigndate, m_cmt324.sRevctmssno);
    m_strMsgID = sMsgId;
    ZFPTLOG.SetLogInfo("324", m_strMsgID.c_str());
            
    // ��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;      

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt324::unPack");	

    return RTN_SUCCESS;
}

INT32 CRecvCmt324::InsertDb(LPCSTR pchMsg)
{    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvCmt324::InsertDb");	

    // ��������
	SETCTX(m_cBpcstpmtcxl);

	// �������ݿ�
	int iRet = m_cBpcstpmtcxl.insert();
	if (0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "������ʧ��[%d][%s]",
		    iRet, m_cBpcstpmtcxl.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "������ʧ��");
	}

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvCmt324::InsertDb");	

    return RTN_SUCCESS;
}


