/*
 *  sendpkg012.cpp
 *  Description: һ��PKG012����������
 *  Created on: 2012-07-04
 *  Author: __wsh
 */

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendpkg012.h"

using namespace ZFPT;

CSendPkg012::CSendPkg012(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
	memset(&(m_cPkg012.stBizBody005),
		        0x00, sizeof(m_cPkg012.stBizBody005));

	memset(&(m_cPkg012.stPkgHead012),
			0x00, sizeof(m_cPkg012.stPkgHead012));

	m_pEntity = NULL;

	memset(m_szTblNm, 0x00, sizeof(m_szTblNm));

		m_strAppendData.clear();
}

CSendPkg012::~CSendPkg012()
{
}

//__wsh 2012-07-04 ���Ĵ������
INT32 CSendPkg012::doWorkSelf()
{
	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CSendPkg012::doWorkSelf");

	int iRet = -1;

	//��ȡҵ������
	GetData();

	//�鱨��
	CreateNpcMsg();

	//����ҵ��״̬
	UpdateState();

	//���ͱ���
	iRet = AddQueue();

	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Leave CSendPkg012::doWorkSelf");

	//������Ϣ
	return iRet;
}

//__wsh 2012-07-04 ��ȡҵ������
INT32 CSendPkg012::GetData(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CSendPkg012::GetData");

	int iRet = -1;

    Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "__ҵ������=%s", m_BusinessType);

	if( NULL != strstr(m_BusinessType, "40503") ||
		NULL != strstr(m_BusinessType, "40504")){
		//���ո���ִҵ��
		iRet = GetData_colltn();
	}
	else if(NULL != strstr(m_BusinessType, "00500")){
	    iRet = GetData_cminfbiz();
	}
	else{
		//δ֪ҵ������
		sprintf(m_sErrMsg, "PKG012δ֪ҵ������[%s]", m_BusinessType);

		Trace(L_ERROR, __FILE__, __LINE__, NULL, "%s", m_sErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, m_sErrMsg);
	}

	//������ȡԭҵ��ʧ�� ���
	if(SQL_SUCCESS != iRet){
		if(SQLNOTFOUND == iRet){
			sprintf(m_sErrMsg, "[%s]�Ҳ���ָ��ҵ��[%s][%s]",
					m_szTblNm, m_sSendOrg, m_sMsgId);
		}
		else{
			sprintf(m_sErrMsg, "[%s]����ָ��ҵ�����[%s][%s]:%s",
					m_szTblNm, m_sSendOrg, m_sMsgId,
					m_pEntity->GetSqlErr());
		}

		Trace(L_ERROR, __FILE__, __LINE__, NULL, "%s", m_sErrMsg);

		PMTS_ThrowException(DB_FIND_FAIL);
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendPkg012::GetData");

	return iRet;
}

//__wsh 2012-07-04
int CSendPkg012::GetData_colltn(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CSendPkg012::GetData_colltn");

	int iRet = -1;

	//��ȡ���ܱ�����
	SETCTX(m_colltncl);
	//��������
	m_colltncl.m_msgid    = m_sMsgId;
	m_colltncl.m_instgpty = m_sSendOrg;
	m_colltncl.m_srcflag  = "1";

	iRet = m_colltncl.findByPK();

	m_strWorkDate     = m_colltncl.m_workdate.c_str();
	m_strInstgdrctpty = m_colltncl.m_instgdrctpty.c_str();
	m_strInstgpty     = m_colltncl.m_instgpty.c_str();
	m_strInstddrctpty = m_colltncl.m_instddrctpty.c_str();
	m_strInstdpty     = m_colltncl.m_instdpty.c_str();
	m_strRmk          = m_colltncl.m_rmk.c_str();

	strcpy(m_szTblNm, "bp_colltnchrgscl");
	m_pEntity = &m_colltncl;

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "m_BusinessType=%s", m_BusinessType);

	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Leave CSendPkg012::GetData_colltn");

	return iRet;
}

//__wsh 2012-07-04
int CSendPkg012::GetData_cminfbiz(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CSendPkg012::GetData_cminfbiz");

	int iRet = -1;

	//��ȡ���ܱ�����
	SETCTX(m_cminfbiz);
	//��������
	m_cminfbiz.m_msgid    = m_sMsgId;
	m_cminfbiz.m_instgpty = m_sSendOrg;
	m_cminfbiz.m_srcflag  = "1";
	m_cminfbiz.m_syscd    = "BEPS";

	iRet = m_cminfbiz.findByPK();

	m_strWorkDate     = m_cminfbiz.m_workdate.c_str();
	m_strInstgdrctpty = m_cminfbiz.m_instgdrctpty.c_str();
	m_strInstgpty     = m_cminfbiz.m_instgpty.c_str();
	m_strInstddrctpty = m_cminfbiz.m_instddrctpty.c_str();
	m_strInstdpty     = m_cminfbiz.m_instdpty.c_str();
	m_strRmk          = m_cminfbiz.m_rmk.c_str();

	strcpy(m_szTblNm, "cm_cnotsgninfbiz");
	m_pEntity = &m_cminfbiz;

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "m_BusinessType=%s", m_BusinessType);

	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Leave CSendPkg012::GetData_cminfbiz");

	return iRet;
}

//__wsh 2012-07-04 ���ӷ�����
void CSendPkg012::AddAddtlField(string &strVal,
			int iFieldLen, const char* szFmt, bool bToGbk)
{
	if(szFmt == NULL){
		m_strAppendData += strVal;
		return;
	}

	char* szVal  = (char*)strVal.c_str();
	long iValLen = strVal.length();
	memset(m_szBuffer, 0x00, sizeof(m_szBuffer));
	//�������ΪUTF8��תΪGBK
	if(szVal != NULL && bToGbk){
		if(IsUTF8(szVal, iValLen)){
			char szTmp[1024] = {0};
			changeEncode(szVal, szTmp, "UTF-8", "GB18030");
			snprintf(m_szBuffer, iFieldLen+1, szFmt, szTmp);
		}
	}
	else{
		snprintf(m_szBuffer, iFieldLen+1, szFmt, szVal);
	}
	m_strAppendData += m_szBuffer;
}

//__wsh 2012-07-04 ���ӷ�����
void CSendPkg012::AddAddtlField(long lVal, 
                int iFieldLen, const char* szFmt)
{
	memset(m_szBuffer, 0x00, sizeof(m_szBuffer));
	snprintf(m_szBuffer, iFieldLen+1, szFmt, lVal);
	m_strAppendData += m_szBuffer;
}

//__wsh 2012-07-04 ��丽����
void CSendPkg012::FillAppendData(void)
{
	if( NULL != strstr(m_BusinessType, "40503") ||
		NULL != strstr(m_BusinessType, "40504")){
		//������ִ������
		FillAppendData_colltn_ans();
	}
	else if(NULL != strstr(m_BusinessType, "00500")){
	    FillAppendData_common_info();
	}
}

//__wsh 2012-07-04 �����ջ�ִ������
void CSendPkg012::FillAppendData_colltn_ans(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CSendPkg012::FillAppendData_colltn_ans");

	string strTmp;
	//ԭ����ί������
	strTmp = m_colltncl.m_orgnlmsgid.substr(0, 8);
	AddAddtlField(strTmp, 8, "%08s");

	//ԭ�������
	strTmp = m_colltncl.m_orgnlmsgid.substr(8);
	AddAddtlField(strTmp, 8, "%08s");

	//��/�������к�
	AddAddtlField(m_colltncl.m_cdbtrbrnchid, 12, "%12s");

	//��/�����˿������к�, ���ݿ���û�и��ֶ�
	AddAddtlField(m_colltncl.m_cdbtrbrnchid, 12, "%12s");

    //�ո������˺�
    AddAddtlField(m_colltncl.m_cdbtrid, 32, "%-32s");
    if(NULL != strstr(m_BusinessType, "40503")){//������ִ  	   
    	//�տ��������к�
    	AddAddtlField(m_colltncl.m_cdtrmmbid, 12, "%12s");
    }
    else{//���ջ�ִ
    	//�����������к�
    	AddAddtlField(m_colltncl.m_dbtrmmbid, 12, "%12s");
    }

	//ԭ�����ܽ��
	AddAddtlField((long)(m_colltncl.m_orgnlttlam*100), 15, "%015d");

	//�ɹ��տ���
	AddAddtlField((long)(m_colltncl.m_rcvsndgttlamt*100), 15, "%015d");

	//ԭ�տ�����Ŀ
	AddAddtlField(m_colltncl.m_orgnlttlnb, 8, "%08d");

	//�ɹ�����
	AddAddtlField(m_colltncl.m_rcvsndgttlnb, 8, "%08d");

	//��ϸ�б�
	FillAppendData_colltn_dtls();

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendPkg012::FillAppendData_colltn_ans");
}

//__wsh 2012-07-04
void CSendPkg012::FillAppendData_colltn_dtls(void)
{

    //��ȡ��ϸ�嵥
	SETCTX(m_colltnlist);

	//ʹ����������
	string strSql = "msgid='";
	strSql += m_sMsgId;
	strSql += "' and instgpty='";
	strSql += m_sSendOrg;
	strSql += "' and srcflag='1' ";
	Trace(L_DEBUG, __FILE__, __LINE__, m_sMsgId, strSql.c_str());

	int iRet = -1;
	iRet = m_colltnlist.find(strSql);
	if(SQL_SUCCESS != iRet){
		sprintf(m_sErrMsg,
				"[bp_colltnchrgslist]��ѯ������iRet=%d cause=%s",
				iRet, m_colltnlist.GetSqlErr());

		Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId,
				"��ѯ�쳣��%s", m_sErrMsg);

		PMTS_ThrowException(DB_OPT_FAIL);
	}
	char szTmp[256] = {0};
	while(true){
		iRet = m_colltnlist.fetch();
		if(iRet != SQL_SUCCESS){
			if(SQLNOTFOUND == iRet){
				m_colltnlist.closeCursor();
				Trace(L_DEBUG, __FILE__, __LINE__,
						NULL, "�����Ѿ�ȡ��");
				break;
			}
			else{
				m_colltnlist.closeCursor();

				sprintf(m_sErrMsg,
						"[bp_colltnchrgslist]��ѯ������iRet=%d cause=%s",
						iRet, m_colltnlist.GetSqlErr());

				Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId,
						"��ѯ�쳣��%s", m_sErrMsg);

				PMTS_ThrowException(DB_OPT_FAIL);
			}
		}// end if
		//ԭ��ϸ��ʶ
		AddAddtlField(m_colltnlist.m_txid, 8, "%08s");
		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "m_BusinessType=%s", m_BusinessType);
		if(strstr(m_BusinessType, "40503") != NULL){
			//�տ����˺�
			AddAddtlField(m_colltnlist.m_cdtrid, 32, "%-32s");
		}
		else{
			//�������˺�
			AddAddtlField(m_colltnlist.m_dbtrid, 32, "%-32s");
		}
		//���
		AddAddtlField((long)(m_colltnlist.m_amout*100), 15, "%015d");
		//��ִ״̬
		AddAddtlField(m_colltnlist.m_busistate, 2, "%02s");
		//����
		AddAddtlField(m_colltnlist.m_addtlinf, 60, "%-60s", true);
	}// end while
}

//__wsh 2012-07-04 ���һ��ͨ����Ϣ������
void CSendPkg012::FillAppendData_common_info(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CSendPkg012::FillAppendData_common_info");
    /*
	����	M	60g
	��������	M	255g
	�����ļ���	O	60g
	��������	M	8n
	��������	O	nE
	*/
    //����
    AddAddtlField(m_cminfbiz.m_titl, 60, "%-60s", true);
    //��������
    AddAddtlField(m_cminfbiz.m_cntt, 255, "%-255s", true);
    //�����ļ���
    AddAddtlField(m_cminfbiz.m_attchmtnm, 60, "%-60s", true);
    //��������
    AddAddtlField(m_cminfbiz.m_attchmtlen, 8, "%08d");
    //��������
    AddAddtlField(m_cminfbiz.m_attchmtcntt);

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendPkg012::FillAppendData_common_info");

}

//__wsh 2012-07-04 ���ҵ��ҵ��ͷ����
void CSendPkg012::FillBizHead(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CSendPkg012::FillBizHead");

	//������ 012
	strcpy(m_cPkg012.stPkgHead012.szPkgType, "012");

	//ֱ�ӷ�����
	strncpy(m_cPkg012.stPkgHead012.szOdfiCode,
			m_strInstgdrctpty.c_str(),
			sizeof(m_cPkg012.stPkgHead012.szOdfiCode)-1);

	//ֱ�ӽ�����
	strncpy(m_cPkg012.stPkgHead012.szRdfiCode,
			m_strInstddrctpty.c_str(),
			sizeof(m_cPkg012.stPkgHead012.szRdfiCode)-1);

	//��ί������
	strncpy(m_cPkg012.stPkgHead012.szPkgCDate,
			m_strWorkDate.c_str(),
			sizeof(m_cPkg012.stPkgHead012.szPkgCDate) - 1);

	//�������
	strncpy(m_cPkg012.stPkgHead012.szPkgserNo,
			m_szMsgSerial,
			sizeof(m_cPkg012.stPkgHead012.szPkgserNo)-1);

	//Ͻ�ڷַ���־
	sprintf(m_cPkg012.stPkgHead012.szSoFlag,
			"%d", 0);

	//ҵ������
	strncpy(m_cPkg012.stPkgHead012.szTradetype,
			m_BusinessType,
			sizeof(m_cPkg012.stPkgHead012.szTradetype)-1);

	//��ϸ��Ŀ �̶�1
	sprintf(m_cPkg012.stPkgHead012.szDetailCnt,
			"%d", 1);

	//��ע�����Ժ����ģ�Ҫ��GBKת��
	SetFieldAsGbk(m_strRmk,
	        m_cPkg012.stPkgHead012.szAppData, 
			sizeof(m_cPkg012.stPkgHead012.szAppData)-1);

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendPkg012::FillBizHead");
}

//__wsh 2012-07-04 ���ҵ��Ҫ��������
void CSendPkg012::FillBizBody(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CSendPkg012::FillBizBody");

	//Ҫ�ؼ�5
	m_cPkg012.m_szCurElementNo = "005";

	//ҵ������
	strncpy(m_cPkg012.stBizBody005.szTrxsType,
			m_BusinessType,
			sizeof(m_cPkg012.stBizBody005.szTrxsType)-1);

	//�����к�
	strncpy(m_cPkg012.stBizBody005.szOdfiCode,
			m_strInstgpty.c_str(),
			sizeof(m_cPkg012.stBizBody005.szOdfiCode)-1);

	//�����к�
	strncpy(m_cPkg012.stBizBody005.szRdfiCode,
			m_strInstdpty.c_str(),
			sizeof(m_cPkg012.stBizBody005.szRdfiCode)-1);

	//ί������
	strncpy(m_cPkg012.stBizBody005.szConsignDate,
			m_strWorkDate.c_str(),
			sizeof(m_cPkg012.stBizBody005.szConsignDate)-1);

	//�������
	strncpy(m_cPkg012.stBizBody005.szTxssNo,
			m_szMsgSerial,
			sizeof(m_cPkg012.stBizBody005.szTxssNo)-1);

	//��ʽ������丽��������
	FillAppendData();
	//�����򳤶�
	int nAddtlLen = m_strAppendData.length();
	sprintf(m_cPkg012.stBizBody005.szAppLen, "%d", nAddtlLen);
	//��������򳤶ȹ����� ��ʱִ�нض�
	if(nAddtlLen > sizeof(m_cPkg012.stBizBody005.szAppData)-1){
		Trace(L_INFO, __FILE__, __LINE__,
				NULL, "__������[%d]������ �ض�!!!", nAddtlLen);

		nAddtlLen = sizeof(m_cPkg012.stBizBody005.szAppData)-1;
	}
	//������
	memcpy(m_cPkg012.stBizBody005.szAppData,
				m_strAppendData.c_str(), nAddtlLen);

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendPkg012::FillBizBody");
}

//__wsh 2012-07-04 ��Ѻ
void CSendPkg012::AddMac012(void)
{
	char szMac[40 + 1] = {0};
	string strCodeMac;//ȡ��Ѻ��
	m_cPkg012.GetMacStr(m_cPkg012, strCodeMac);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL,
				"__strCodeMac = [%s]", strCodeMac.c_str());

	int iRetCode = CodeMac(m_dbproc, strCodeMac.c_str(),
								m_strInstgdrctpty.c_str(), szMac);
	if (RTN_SUCCESS != iRetCode) {
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "��Ѻʧ��");
		PMTS_ThrowException(__FILE__, __LINE__, OPT_CODEMAC_FAIL, "��Ѻʧ��");
	}
	memcpy(m_cPkg012.stPkgHead012.szPkgDest, szMac, sizeof(szMac)-1);
}

//__wsh 2012-07-04 ����PKG����
INT32 CSendPkg012::CreateNpcMsg(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CSendPkg012::CreateNpcMsg");

	int iRet = -1;

	//��ȡͨ�ż���ʶ
	if(!GetMsgIdValue(m_dbproc, m_sMsgRefId,
				eRefId, SYS_BEPS, m_strInstgdrctpty.c_str())){
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "��ȡͨ�ű�ʶʧ��!");
		PMTS_ThrowException(OPT_GET_MESGREFID_FAIL);
	}

	//�鱨ͷ
	iRet = m_cPkg012.CreateMsgHeader(
			"012",
			 m_strInstgdrctpty.c_str(),
			 m_strInstddrctpty.c_str(),
			 m_sMsgRefId,
			 m_sMsgRefId,
			 m_strWorkDate.c_str(),
			 "1");

	Trace(L_DEBUG, __FILE__, __LINE__, NULL,
	                "__%s", m_cPkg012.m_szMsgHead.c_str());

    Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "m_BusinessType=%s", m_BusinessType);
	//���ҵ��ͷ
	FillBizHead();

	//���ҵ����Ҫ��
	FillBizBody();

	//��ҵ����
	m_cPkg012.AddBussiness();

	Trace(L_DEBUG, __FILE__, __LINE__, NULL,
	                "__%s", m_cPkg012.m_szPkgBody.c_str());

	//��Ѻ
	AddMac012();

	//�鱨��β
	m_cPkg012.CreateMsgTail();

	//�鱨��
	iRet = m_cPkg012.CreateMsg();

	m_sMsgTxt = m_cPkg012.m_szMsgText;

	Trace(L_INFO,  __FILE__,  __LINE__,
	             NULL, "__m_sMsgTxt=%s", m_sMsgTxt.c_str());

    Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendPkg012::CreateNpcMsg");

	return iRet;
}

//__wsh 2012-07-04 ����״̬
INT32 CSendPkg012::UpdateState(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CSendPkg012::UpdateState");

	int iRet = -1;

	string strSql = " update ";
	strSql.append(m_szTblNm);
	strSql.append(" set mesgid='");
	strSql.append(m_sMsgRefId);
	strSql.append("', mesgrefid='");
	strSql.append(m_sMsgRefId);
	strSql.append("', procstate='08' ");
	strSql.append(" where msgid='");
	strSql.append(m_sMsgId);
	strSql.append("' and instgpty='");
	strSql.append(m_strInstgpty);
	strSql.append("' and srcflag='1' ");

	Trace(L_DEBUG, __FILE__, __LINE__,
			NULL, "__strSql=%s", strSql.c_str());

	iRet = m_pEntity->execsql(strSql.c_str());
	if(SQL_SUCCESS != iRet){
		sprintf(m_sErrMsg, "[%s]����ָ��ҵ�����[%s][%s]:%s",
				m_szTblNm, m_sSendOrg, m_sMsgId,
				m_pEntity->GetSqlErr());
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "%s", m_sErrMsg);

		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CSendPkg012::UpdateState");

	return iRet;
}


