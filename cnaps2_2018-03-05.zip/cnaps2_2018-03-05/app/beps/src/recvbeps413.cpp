/******************************************************************** 
�ļ����� recvbeps413.cpp
�����ˣ� zys
��  �ڣ� 2011-04-26
�޸��ˣ� 
��  �ڣ� 
��  ���� ʵʱҵ��������뱨��< beps.413.001.01>���˴���
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbeps413.h"

using namespace ZFPT;

CRecvBeps413::CRecvBeps413()
{
    m_strMsgTp  = "beps.413.001.01";
}

CRecvBeps413::~CRecvBeps413()
{

}

INT32 CRecvBeps413::Work(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBeps413::Work()");
        
    // ��������
    unPack(szMsg);
    
    // ҵ����
    CheckValues();
    
    // ���
    InsertDb(szMsg);  
        
    // ���·���״̬
    UpdateState();

         
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBeps413::Work()");
    return OPERACT_SUCCESS;
}

INT32 CRecvBeps413::unPack(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CRecvBeps413::unPack()");

    int iRet = OPERACT_FAILED;
    // �����Ƿ�Ϊ��
    if (NULL == szMsg || '\0' == szMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��"); 
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }
    //��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;    
    // ��������
    iRet = m_cBeps413.ParseXml(szMsg);
    if (OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= %d", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");
    }
    
    // ���ı�ʶ��
    m_strMsgID = m_cBeps413.AssgnmtId;
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CRecvBeps413::unPack()");
    return OPERACT_SUCCESS;
}


/******************************************************************************
*  Function:   CheckValues
*  Description:ҵ����
*  Input:	   ��
*  Output:	   
*  Return:	   0   : �����ɹ�,
			   ����: ����ʧ��
*  Others:	   ��
*  Author:	   zys
*  Date:	   2011-04-20
*******************************************************************************/
INT32 CRecvBeps413::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CSendBeps413::CheckValues");

    /*int iRet = OPERACT_FAILED;

    //������޼��
    iRet = isOutOfLimit(m_dbproc, 
                        m_cbpbdsendlist.m_msgtp.c_str(), 
                        m_cbpbdsendlist.m_purpprtry.c_str(),
                        m_cbpbdsendlist.m_amount, 
                        m_sErrMsg);
    if ( OPERACT_SUCCESS != iRet)
    {
        return iRet;
    }
    
    //�����кż��
    iRet = isBankRight(m_dbproc, m_cbpbdsendlist.m_instddrctpty.c_str(), m_sErrMsg);
    if ( 0 != iRet)
    {
        return OPERACT_FAILED;
    }*/
    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CSendBeps413::CheckValues"); 
    return OPERACT_SUCCESS;
}


/******************************************************************************
*  Function:   InsertDb
*  Description:�������
*  Input:	   ��
*  Output:	   
*  Return:	   0   : �����ɹ�,
			   ����: ����ʧ��
*  Others:	   ��
*  Author:	   zys
*  Date:	   2011-04-26
*******************************************************************************/
INT32 CRecvBeps413::InsertDb(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBeps413::InsertDb()");
    
    string strTemp = "";
    char   sTemp[128 + 1] = {0};
    string strTagVal = "";
    int    iRet;
    
    //��������
    SETCTX(m_cBpcstpmtcxl);
    
    m_cBeps413.AddtlInf                 =   m_cBeps413.GetAddtlInf();
    
    m_cBpcstpmtcxl.m_msgid              =   m_cBeps413.AssgnmtId                     ;    //���ı�ʶ��
    m_cBpcstpmtcxl.m_instgdrctpty       =   m_cBeps413.AssgnrMmbId                   ;    //����ֱ�Ӳ������
    m_cBpcstpmtcxl.m_workdate           =   m_sWorkDate                              ;    //���ķ���ʱ��             
    m_cBpcstpmtcxl.m_msgtp              =   m_strMsgTp                               ;    //��������:����BEPS��ͷ,һ��PKG��ͷ
    m_cBpcstpmtcxl.m_mesgid             =   m_cBeps413.m_PMTSHeader.getMesgID()      ;    //ͨ�ż���ʶ��      
    m_cBpcstpmtcxl.m_mesgrefid          =   m_cBeps413.m_PMTSHeader.getMesgRefID()   ;    //ͨ�ż��ο��� 
    m_cBpcstpmtcxl.m_instddrctpty       =   m_cBeps413.AssgneMmbId                   ;    //����ֱ�Ӳ������
    m_cBpcstpmtcxl.m_addtlinf           =   m_cBeps413.AddtlInf                      ;    //����
    m_cBpcstpmtcxl.m_procstate          =   PR_HVBP_95                               ;    //����״̬:95������
    m_cBpcstpmtcxl.m_orimsgid           =   m_cBeps413.OrgnlMsgId                    ;    //ԭҵ���ı�ʶ��
    m_cBpcstpmtcxl.m_oriinstgdrctpty    =   m_cBeps413.CretrMmbId                    ;    //ԭҵ����������
    m_cBpcstpmtcxl.m_orimsgtp           =   m_cBeps413.OrgnlMsgNmId                  ;    //ԭҵ��������   
   
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_msgid=%s",m_cBpcstpmtcxl.m_msgid.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_instgdrctpty=%s",m_cBpcstpmtcxl.m_instgdrctpty.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_workdate=%s",m_cBpcstpmtcxl.m_workdate.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_mesgid=%s",m_cBpcstpmtcxl.m_mesgid.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_mesgrefid=%s",m_cBpcstpmtcxl.m_mesgrefid.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_instddrctpty=%s",m_cBpcstpmtcxl.m_instddrctpty.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_addtlinf=%s",m_cBpcstpmtcxl.m_addtlinf.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_procstate=%s",m_cBpcstpmtcxl.m_procstate.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_orimsgid=%s",m_cBpcstpmtcxl.m_orimsgid.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_oriinstgdrctpty=%s",m_cBpcstpmtcxl.m_oriinstgdrctpty.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cBpcstpmtcxl.m_orimsgtp=%s",m_cBpcstpmtcxl.m_orimsgtp.c_str());
    

    //��������
    iRet = m_cBpcstpmtcxl.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        sprintf(m_szErrMsg,"����ʵʱҵ�������ʧ��[%d][%s]", iRet, m_cBpcstpmtcxl.GetSqlErr());
        Trace(L_ERROR, __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBeps413::InsertDb()");
    return OPERACT_SUCCESS;
}

INT32 CRecvBeps413::UpdateState()
{
  Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBeps413::UpdateState...");
  
     string strSQL;
  
     strSQL += "UPDATE bp_cstpmtcxl t SET t.PROCSTATE = '";
     strSQL += PR_HVBP_08;
     strSQL += "'";
  
     strSQL += " WHERE t.MSGID = '";
     strSQL += m_cBeps413.AssgnmtId;
     strSQL += "' AND t.INSTGDRCTPTY = '";
     strSQL += m_cBeps413.AssgnrMmbId;                  
     strSQL += "'";
     Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
  
     int iRet = m_cBpcstpmtcxl.execsql(strSQL.c_str());
     if(RTN_SUCCESS != iRet)
     {
         Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "UpdateState error:[%d]", iRet);
         PMTS_ThrowException(DB_UPDATE_FAIL);
     }
     
     m_cBpcstpmtcxl.commit();
  
     Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBeps413::UpdateState...");
     return RTN_SUCCESS;
 }


