/*
 *  sendbeps395.cpp
 *  Description: �����ͻ���Ϣ��ѯ����beps.395.001.01����������
 *  Created on: 2012-6-4
 *  Author: __wsh
 */

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps395.h"

//
CSendBeps395::CSendBeps395(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
}

//
CSendBeps395::~CSendBeps395()
{
}

//__wsh 2012-06-12 ҵ�������
INT32 CSendBeps395::doWorkSelf(void)
{
	int iRet = -1;

	//��ȡ����
	GetData();

	//������Ϣ
	BuildPmtsMsg();

    //����ҵ��״̬
	iRet = UpdateState();
	
	//������Ϣ
	iRet = AddQueue();

	return iRet;
}

//__wsh 2012-06-12 ��ȡ���ܱ�����
int CSendBeps395::GetData(void)
{
	int iRet = -1;

	Trace(L_INFO,  __FILE__,  __LINE__,
						NULL, "Enter CSendBeps395::GetData");

	SETCTX(m_caqcl);

	//���ò�ѯ����
	m_caqcl.m_msgid    = m_sMsgId;
	m_caqcl.m_instgpty = m_sSendOrg;
	m_caqcl.m_srcflag  = "1";

	Trace(L_DEBUG, __FILE__, __LINE__, NULL,
			"MSGID=[%s],INSTGPTY=[%s]",
			m_caqcl.m_msgid.c_str(), m_caqcl.m_srcflag.c_str());

	iRet = m_caqcl.findByPK();
	if(iRet != SQL_SUCCESS){
		sprintf(m_sErrMsg, "��ѯ�����˻���ѯ���ܱ�������iRet=%d cause=%s",
				iRet, m_caqcl.GetSqlErr());

		Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId,
				"��ѯ�쳣��%s", m_sErrMsg);

		PMTS_ThrowException(DB_OPT_FAIL);
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CSendBeps395::GetData");

	return iRet;
}

//__wsh 2012-06-12 ��ǩ
void CSendBeps395::AddSign395()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Enter AddSign395");

	char   sSignedStr[4096 + 1] = {0};

	m_cBeps395.getOriSignStr();

	AddSign(m_cBeps395.m_sSignBuff.c_str(),
			sSignedStr,
			RAWSIGN,
			m_caqcl.m_instgdrctpty.c_str());

	m_cBeps395.m_szDigitSign = sSignedStr;

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Leave AddSign395");
}

//__wsh 2012-06-12 ������ϸ
void CSendBeps395::SetAcctDtls(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
                NULL, "Enter CSendBeps395::SetAcctDtls");

    Trace(L_DEBUG, __FILE__, __LINE__, NULL,
            "m_caqlist.m_acctid=[%s]", m_caqlist.m_acctid.c_str());
    Trace(L_DEBUG, __FILE__, __LINE__, NULL,
            "m_caqlist.m_acctnm=[%s]", m_caqlist.m_acctnm.c_str());
    Trace(L_DEBUG, __FILE__, __LINE__, NULL,
            "m_caqlist.m_acctbk=[%s]", m_caqlist.m_acctbk.c_str());

	//������ϸ
	m_cBeps395.Id     = m_caqlist.m_acctid;
	m_cBeps395.Nm     = m_caqlist.m_acctnm;
	m_cBeps395.AcctBk = m_caqlist.m_acctbk;
	m_cBeps395.AcctSts= m_caqlist.m_acctsts;
	m_cBeps395.RjctCd = m_caqlist.m_rjctcd;
	m_cBeps395.RjctInf= m_caqlist.m_rjctinf;
	m_cBeps395.PrcPty = m_caqlist.m_prcpty;
	m_cBeps395.Sts    = m_caqlist.m_rspsnsts;

	//������ϸ���ڵ�
	m_cBeps395.AddNodeToSubcycle("Id", m_cBeps395.Id.c_str());
	m_cBeps395.AddNodeToSubcycle("Nm", m_cBeps395.Nm.c_str());
	
	m_cBeps395.AddNodeToSubcycle("Sts", m_cBeps395.Sts.c_str());
	m_cBeps395.AddNodeToSubcycle("RjctCd", m_cBeps395.RjctCd.c_str());
	m_cBeps395.AddNodeToSubcycle("RjctInf", m_cBeps395.RjctInf.c_str());
	m_cBeps395.AddNodeToSubcycle("PrcPty", m_cBeps395.PrcPty.c_str());
	
	m_cBeps395.AddNodeToSubcycle("AcctBk", m_cBeps395.AcctBk.c_str());
	m_cBeps395.AddNodeToSubcycle("AcctSts", m_cBeps395.AcctSts.c_str());

	m_cBeps395.AddSubcycleToNode("AcctDtls");

	//ѭ����ǩ
	m_cBeps395.AddTxStr();

	Trace(L_INFO,  __FILE__,  __LINE__,
	            NULL, "Leave CSendBeps395::SetAcctDtls");
}

//__wsh 2012-06-13 ����Ӧ����ϸ
int CSendBeps395::SetRespInfo(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
	            NULL, "Enter CSendBeps395::SetRespInfo");
	            
    int iRet = -1;
    
    m_cBeps395.AcctCnt = m_caqcl.m_acctcnt; //�˻���Ŀ
	
	SETCTX(m_caqlist);

	string strSqlWhere = "";
	strSqlWhere += " msgid='";
	strSqlWhere += m_sMsgId;
	strSqlWhere += "' and instgdrctpty='";
	strSqlWhere += m_sSendOrg;
	strSqlWhere += "' and srcflag=1 ";

	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL,
				"___strSqlWhere=%s", strSqlWhere.c_str());

	iRet = m_caqlist.find(strSqlWhere.c_str());
	if(iRet != SQL_SUCCESS){
		sprintf(m_sErrMsg, "��ѯǩԼ��ϸ��������iRet=%d cause=%s",
				iRet, m_caqlist.GetSqlErr());

		Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId,
				"��ѯ�쳣��%s", m_sErrMsg);

		PMTS_ThrowException(DB_NOT_FOUND);
	}
	int nCnt = 0;
	while(true){
		//��ȡ�˻���ϸ
		iRet = m_caqlist.fetch();
		if(iRet != SQL_SUCCESS){
			if(SQLNOTFOUND == iRet){
				Trace(L_DEBUG, __FILE__, __LINE__,
						NULL, "�����Ѿ�ȡ��");
				break;
			}
			else{
			    m_caqlist.closeCursor();
			    
				sprintf(m_sErrMsg, "��ѯ�����˻���ѯ��ϸ��������iRet=%d cause=%s",
						iRet, m_caqlist.GetSqlErr());

				Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId,
						"��ѯ�쳣��%s", m_sErrMsg);

				PMTS_ThrowException(DB_OPT_FAIL);
			}
		}//end 1 if

		//�����˻���Ϣ��ϸ
		SetAcctDtls();
		++nCnt;
	}//end while
    
    m_caqlist.closeCursor();
    
    if(0 == nCnt || (atoi(m_cBeps395.AcctCnt.c_str())) != nCnt){
        Trace(L_INFO, __FILE__, __LINE__, NULL,
            "���Ƴ���,��ϸ��Ŀ��һ�»�Ϊ0��nCnt=%d, m_cBeps395.AcctCnt=%s",
            nCnt, m_cBeps395.AcctCnt.c_str());
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__,
	            NULL, "Leave CSendBeps395::SetRespInfo");
	            
    return iRet;
}

//__wsh 2012-06-12 ����PMTS XML����
int CSendBeps395::BuildPmtsMsg(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__,
	            NULL, "Enter CSendBeps395::BuildPmtsMsg");

	int iRet = -1;
	
	//��ȡ���Ĵ�������ʱ��
	iRet = GetIsoDateTime(m_dbproc, SYS_BEPS, m_ISODateTime);
	if(iRet != RTN_SUCCESS){
	    Trace(L_ERROR, __FILE__, __LINE__, 
	                NULL, "��ȡiso datetimeʧ�ܣ�");
	    PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
	}

	//ҵ��ͷ
	m_cBeps395.MsgId            = m_caqcl.m_msgid;
	m_cBeps395.CreDtTm          = m_ISODateTime;
	m_cBeps395.InstgDrctPty     = m_caqcl.m_instgdrctpty;
	m_cBeps395.GrpHdrInstgPty   = m_caqcl.m_instgdrctpty;
	m_cBeps395.InstdDrctPty     = m_caqcl.m_instddrctpty;
	m_cBeps395.GrpHdrInstdPty   = m_caqcl.m_instddrctpty;
	m_cBeps395.SysCd            = "BEPS";
	m_cBeps395.Rmk              = m_caqcl.m_rmk;
	
	//ԭҵ������
	m_cBeps395.OrgnlMsgId       = m_caqcl.m_orgnlmsgid;
	m_cBeps395.OrgnlInstgPty    = m_caqcl.m_orgnlinstgpty;
	m_cBeps395.OrgnlMT          = m_caqcl.m_orgnlmt;
	
	//Ӧ����ϸ��Ϣ
	iRet = SetRespInfo();
    
	//��ȡͨ�Ų����
	if( !GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS) ){
		Trace(L_ERROR, __FILE__, __LINE__,
				m_sMsgId, "��ȡͨ�Ų���ų���!");
		PMTS_ThrowException(PRM_FAIL);
	}

	//������Ϣͷ
	m_cBeps395.CreateXMlHeader(
				"BEPS",
				m_sWorkDate,
				m_sSendOrg,
				m_caqcl.m_instddrctpty.c_str(),
				"beps.395.001.01",
				m_sMsgRefId);

	//��ǩ
	AddSign395();

	//����XML����
	iRet = m_cBeps395.CreateXml();
	if(RTN_SUCCESS != iRet){
		Trace(L_ERROR,  __FILE__,  __LINE__,
				NULL, "��������ʧ��,iRet=%d", iRet);
		PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
	}

	m_sMsgTxt = m_cBeps395.m_sXMLBuff.c_str();

	Trace(L_INFO,  __FILE__,  __LINE__,
						NULL, "Leave CSendBeps395::BuildPmtsMsg");
	return iRet;
}

//__wsh 2012-06-12 ����ԭҵ������
int CSendBeps395::UpdateState(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
						NULL, "Enter CSendBeps395::UpdateState");

	int iRet = -1;

	//���»��ܱ�״̬
	string strSqlCl = " update bp_cstacctqrycl set procstate='";
	strSqlCl += PR_HVBP_08;
	strSqlCl += "', mesgid='";
	strSqlCl += m_sMsgRefId;
	strSqlCl += "', mesgrefid='";
	strSqlCl += m_sMsgRefId;
	strSqlCl += "', statetime=sysdate where msgid='";
	strSqlCl += m_caqcl.m_msgid;
	strSqlCl += "' and instgpty='";
	strSqlCl += m_caqcl.m_instgpty;
	strSqlCl += "' and srcflag=1 ";

	Trace(L_DEBUG, __FILE__, __LINE__, m_sMsgId,
			"__strSqlCl=[%s]", strSqlCl.c_str());

	iRet = m_caqcl.execsql(strSqlCl.c_str());
	if(SQL_SUCCESS != iRet){
		sprintf(m_sErrMsg, "���������˻���ѯ���ܱ�������iRet=%d cause=%s",
				iRet, m_caqcl.GetSqlErr());

		Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId,
				"�����쳣��%s", m_sErrMsg);

		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	//������ϸ��״̬
	string strSqlList = " update bp_cstacctqrylist set procstate='";
	strSqlList += PR_HVBP_08;
	strSqlList += "', proctime=sysdate where msgid='";
	strSqlList += m_caqcl.m_msgid;
	strSqlList += "' and instgdrctpty='";
	strSqlList += m_caqcl.m_instgpty;
	strSqlList += "' and srcflag=1 ";

	Trace(L_DEBUG, __FILE__, __LINE__, m_sMsgId,
				"__strSqlList=[%s]", strSqlList.c_str());

	iRet = m_caqlist.execsql(strSqlList.c_str());
	if(SQL_SUCCESS != iRet){
		sprintf(m_sErrMsg, "���������˻���ѯ��ϸ��������iRet=%d cause=%s",
				iRet, m_caqlist.GetSqlErr());

		Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId,
				"�����쳣��%s", m_sErrMsg);

		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CSendBeps395::UpdateState");

	return iRet;
}






