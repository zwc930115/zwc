/******************************************************************** 
文件名： sendpkgpack.cpp
创建人： lify
日  期： 2011-05-24
修改人： 
日  期： 
描  述：    XML打包处理类 
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendpkgpack.h"

#include "pubfunc.h"
#include "exception.h"
#include "logger.h"

#include "pkg001.h"
#include "pkg002.h"
#include "pkg005.h"
#include "pkg006.h"
#include "pkg007.h"
#include "pkg008.h"

#include "bppkgassist1.h"
#include "bpbcoutsendlist.h"
#include "bpbdsendlist.h"


using namespace ZFPT;

extern CConnectPool			*g_DBConnPool;

extern char					g_MQmgr[256];
extern char					g_MqTxtPath[256];
extern char					g_SendQueue[128];


CSendPkgPack::CSendPkgPack()
{
	memset(m_szErrMsg, 0x00, sizeof(m_szErrMsg));
	memset(m_sWorkDate, 0x00, sizeof(m_sWorkDate));
	memset(m_sIsoWorkDate, 0x00, sizeof(m_sIsoWorkDate));
	memset(m_sMsgRefId, 0x00, sizeof(m_sMsgRefId));
	memset(m_szMac, 0x00, sizeof(m_szMac));
	
	m_strWrkDate	= "";
	m_strSendBank	= "";
	m_strRecvBank	= "";
	m_strMsgType	= "";
	m_strMsgID		= "";
	m_strMsgTxt		= "";

	m_iMsgNo		= 0 ;
}

CSendPkgPack::~CSendPkgPack()
{
}

void CSendPkgPack::setData(stPkgTab &_PkgTab)
{
	char sMsgNo[3 + 1] = { 0 };

	memcpy(&m_stPkgTab, &_PkgTab, sizeof(m_stPkgTab));
	
	m_strWrkDate	= m_stPkgTab.szWrkDate;     //工作日期
	m_strSendBank	= m_stPkgTab.szSendBank;    //发起清算行
	m_strRecvBank	= m_stPkgTab.szRecvBank;    //接收清算行
	m_strMsgType	= m_stPkgTab.szMsgType;     //报文类型
	m_strMsgID		= m_stPkgTab.szMsgID;       //报文标识号
 
    //存在bp_bcoutsendlist表中数据为pkg001
	memcpy(sMsgNo, m_stPkgTab.szMsgType + 3, sizeof(sMsgNo) - 1);
	m_iMsgNo = atoi(sMsgNo);

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strWrkDate  =[%s]", m_strWrkDate .c_str()	);
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strSendBank =[%s]", m_strSendBank.c_str()  );
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strRecvBank =[%s]", m_strRecvBank.c_str()  );
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgType  =[%s]", m_strMsgType .c_str()  );
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strMsgID    =[%s]", m_strMsgID	  .c_str()  );
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_iMsgNo      =[%d]", m_iMsgNo               );
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iPKGRtrltd    =[%d]", m_stPkgTab.iPKGRtrltd  );
}

INT32 CSendPkgPack::Work()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendPkgPack::Work()");	
	
    int iRet = RTN_FAIL;
	
    try
    {	
    	//获取MQ连接
    	GetMqConn();
			
        //获取数据库连接
        GetDBConnect();

		//Init
		InitSysParam();
		
		//业务处理
		switch(m_iMsgNo)
	    {
	        case 1:
	        {
				PackPkg001();
	            break;
	        }
	        case 2:
	        {
				PackPkg002();
	            break;
	        }
	        case 5:
	        {
				PackPkg005();
	            break;
	        }
	        case 6:
	        {
				PackPkg006();
	            break;
	        }
	        case 7:
	        {
				PackPkg007();
	            break;
	        }
	        case 8:
	        {
				PackPkg008("008");
	            break;
	        }
	        case 11:
	        {
				PackPkg008("011");
	            break;
	        }
	        default:
	        {
	            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "未找到相应报文号");	
	            return RTN_FAIL;
	        }
	    }

		//put MQ
		SendMsgToMQ();

		//更新打包辅助表处理状态为"03: 已打包"
		UpdPkgAssistState("03");

	    SETCTX(m_cCCmcomsend);
		m_cCCmcomsend.commit();
		m_cMQAgent.Commit();
		
        //释放连接
        g_DBConnPool->PutConnect(m_dbproc);	
    }
    catch(CException &e)
    {        
        Trace(L_ERROR, __FILE__, __LINE__, NULL, 
            "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());

		//数据库事物回滚
		m_cCCmcomsend.setctx(m_dbproc);
		m_cCCmcomsend.rollback();

		// 释放连接
        g_DBConnPool->PutConnect(m_dbproc);

		//MQ事物回滚
		m_cMQAgent.RollBack();
    }
    catch(...)
    {
        //Trace
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendPkgPack::Work()");	

    return 0;
}


void CSendPkgPack::GetMqConn(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendPkgPack::GetMqConn()");	
	
	 //初始化MQ
    if(0 != m_cMQAgent.Init(g_MQmgr, g_MqTxtPath))
    {
    	snprintf(m_szErrMsg, sizeof(m_szErrMsg), 
			"CSendPkgPack::GetMqConn(),Init Thread MQ manager failed.");
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		
        PMTS_ThrowException(__FILE__, __LINE__, OPT_GET_MQ_CNNCT_FAIL, m_szErrMsg);
    }
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendPkgPack::GetMqConn()");		
}


/******************************************************************************
*  Function:   GetDBConnect
*  Description:获取数据库连接
*  Input:      无
*  Output:     无
*  Return:     无
*  Others:     无
*  Author:     zys
*  Date:       2011-03-01
*******************************************************************************/
void CSendPkgPack::GetDBConnect(void)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendPkgPack::GetDBConnect()");	

    if(0 != g_DBConnPool->GetConnect(m_dbproc))
    {
        snprintf(m_szErrMsg, sizeof(m_szErrMsg), 
			"CSendPkgPack::GetDBConnect():获取数据库连接失败");
		
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		
        PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, m_szErrMsg);
    }
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendPkgPack::GetDBConnect()");		
}


void CSendPkgPack::InitSysParam()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendPkgPack::InitSysParam()");
	
	int iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS, m_strSendBank.c_str());
	if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Get Work Date fail, iRet=%d, m_strSendBank=%s", iRet, m_strSendBank.c_str());		
        PMTS_ThrowException(OPT_GET_DATE_FAIL);
    }
    
    iRet = GetIsoDateTime(m_dbproc, SYS_BEPS, m_sIsoWorkDate);
	if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Get time fail, iRet=%d, m_strSendBank=%s", iRet, m_strSendBank.c_str());		
        PMTS_ThrowException(OPT_GET_TIME_FAIL);
    }
    
    bool bRet = GetMsgIdValue(m_dbproc,  m_sMsgRefId, eRefId, SYS_BEPS, m_strSendBank.c_str());
	if(true != bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "Get msgrefid fail, m_strSendBank=%s", m_strSendBank.c_str());		
        PMTS_ThrowException(OPT_GET_MESGREFID_FAIL);
    }
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendPkgPack::InitSysParam()");
}

void CSendPkgPack::SendMsgToMQ()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendPkgPack::AddQueue()");

	int iRet = -1;

	if(m_strMsgTxt == "")
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_strMsgTxt is NULL");
		PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "m_strMsgTxt is NULL");
	}

	int iLength = m_strMsgTxt.length();
    iRet = m_cMQAgent.PutMsg(g_SendQueue, m_strMsgTxt.c_str(),iLength);
	if(0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "向远程队列[%s]发送往账报文[%s]失败", 
												g_SendQueue, m_strMsgID.c_str());
		
		//写往NPC通讯表
		m_cCCmcomsend.setctx(m_dbproc);

		m_cCCmcomsend.m_syscode	 	= "BEPS" ;
		m_cCCmcomsend.m_wrkdate		= m_sWorkDate ;
		m_cCCmcomsend.m_msgtp       = m_strMsgType  ;
		m_cCCmcomsend.m_sendbankcode= m_strSendBank ;
		m_cCCmcomsend.m_msgid		= m_strMsgID ;
		m_cCCmcomsend.m_recvbankcode= m_strRecvBank ;
		m_cCCmcomsend.m_msglevel	= "2" ;
		m_cCCmcomsend.m_msgtext		= m_strMsgTxt ; 
		m_cCCmcomsend.m_procstate	= "01" ;
		m_cCCmcomsend.m_sendtimes	= 0 ;

		iRet = m_cCCmcomsend.insert();
		if (SQL_SUCCESS != iRet) 
	    {
	        sprintf(m_szErrMsg, "m_cCCmcomsend.insert:插入往NPC通讯表错误, m_msgid[%s], [%d][%s]",
				m_cCCmcomsend.m_msgid.c_str(), iRet, m_cCCmcomsend.GetSqlErr()); 
			
	        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);

	        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
	    }
		
	}
	
   	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "成功向远程队列[%s]发送往账报文[%s][%s]",
												g_SendQueue, m_strMsgID.c_str(), m_strMsgTxt.c_str());
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendPkgPack::AddQueue()");
}


void CSendPkgPack::UpdPkgAssistState(LPCSTR pProstate)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendPkgPack::UpdPkgAssistState()");
	
	CBppkgassist1   oCBppkgassist		;
	string		    strProstate = ""	;
	
	oCBppkgassist.setctx(m_dbproc);
	 
	oCBppkgassist.m_recvbank	= m_strRecvBank;
	oCBppkgassist.m_msgtype		= m_strMsgType;
	oCBppkgassist.m_msgid		= m_strMsgID;
	strProstate					= pProstate;
	
	int iUpdCode = oCBppkgassist.setstate(strProstate);
	if (SQL_SUCCESS != iUpdCode)  
    {
        sprintf(m_szErrMsg, "oCBppkgassist.find:查询打包辅助表记录错, setstate[%s], [%d][%s]",
		    strProstate.c_str(), iUpdCode, oCBppkgassist.GetSqlErr());
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);

        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
    }
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendPkgPack::UpdPkgAssistState()");
}


void CSendPkgPack::PackPkg001()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendPkgPack::PackPkg001()");
	
	pkg001				oPkg001;
	CBpbcoutsendlist	oBpbclist;

	char				sSqlStr[4000 + 1]  = {0};
	string				strWhereClause	= "";
	int					iRetCode		= RTN_FAIL;
	int					iUpdCode		= RTN_FAIL;
	char				sTemp[32]		= {0};
	string				strTemp				;
	int 				iCount				;
	int 				iNbOfTxs		= 0;
	double				dCtrlSum		= 0.00;
	
	//1、组报文头
	int iRet = oPkg001.CreateMsgHeader("001",
				  m_strSendBank.c_str(),
				  m_strRecvBank.c_str(),
				  m_sMsgRefId,
				  m_sMsgRefId,
				  m_sWorkDate,
				  "1"	
				  )	;
    if (SQL_SUCCESS != iRet) 
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "创建报文头失败！");

        PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "创建报文头失败！");
    }
    
	//2、组批量包头｛P:
	strncpy(oPkg001.stPkgHead001.szPkgType , "001",                 sizeof(oPkg001.stPkgHead001.szPkgType )-1);                     //02C   包类型号
    strncpy(oPkg001.stPkgHead001.szOdfiCode, m_strSendBank.c_str(), sizeof(oPkg001.stPkgHead001.szOdfiCode)-1); //011   包发起清算行
    strncpy(oPkg001.stPkgHead001.szRdfiCode, m_strRecvBank.c_str(), sizeof(oPkg001.stPkgHead001.szRdfiCode)-1); //012   包接收清算行
    strncpy(oPkg001.stPkgHead001.szPkgCDate, m_strMsgID.c_str(),    sizeof(oPkg001.stPkgHead001.szPkgCDate)-1); //30E   包委托日期
    strncpy(oPkg001.stPkgHead001.szPkgserNo, m_strMsgID.c_str()+8,  sizeof(oPkg001.stPkgHead001.szPkgserNo)-1); //0BD   包序号   
	
	//3、取明细，组报文体
	oBpbclist.setctx(m_dbproc);

	strWhereClause = "msgid = '" + m_strMsgID + "' " + "and procstate = '" + PR_HVBP_95 + "'  order by txid ";
	
    Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "strWhereClause=[%s]",strWhereClause.c_str());
        
	iRetCode = oBpbclist.find(strWhereClause);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(m_szErrMsg, "oBpbclist.find:查询小额往帐贷记明细表记录错, [%d][%s]",
			iRetCode, oBpbclist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
    }
	
	while(SQL_SUCCESS == iRetCode)
	{
		iRetCode = oBpbclist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
			break;
		if (SQL_SUCCESS != iRetCode) 
		{
			sprintf(m_szErrMsg, "oBpbclist.fetch:查询小额往帐贷记明细表记录错, [%d][%s]",
				iRetCode, oBpbclist.GetSqlErr()); 
				
			oBpbclist.closeCursor();
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
		}

		/**************************************************************/
		//增加最大报文长度控制
		
		oPkg001.m_szPkgBody += oBpbclist.m_npcmsg;
		iNbOfTxs++;
		dCtrlSum += oBpbclist.m_amount;
	}
    oBpbclist.closeCursor();
    
	if ( 0 >= iNbOfTxs )
    {
        Trace(L_ERROR,	__FILE__,  __LINE__, NULL, " 未找到相关打包记录[%s]", m_strMsgID.c_str());
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, "未找到相关打包记录");
    }
    
    /* 将从数据库中取出的UTF-8正文体转换成GB18030 */
    
    sprintf(oPkg001.stPkgHead001.szDetailCnt, "%08d", iNbOfTxs);    //B63   明细业务总笔数
    sprintf(oPkg001.stPkgHead001.szDetailAmt  , "RMB%015.0f", dCtrlSum*100);    //32B   明细业务总金额
    
    GetCodeMac(oPkg001, m_szMac);	
	strcpy(m_szMac,"123334444444");
    memcpy(oPkg001.stPkgHead001.szPkgDest, m_szMac, sizeof(m_szMac) - 1);    //C15   包密押
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_szMac = [%s]oPkg001.stPkgHead001.szPkgDest[%s]", m_szMac, oPkg001.stPkgHead001.szPkgDest);

    
    //在这赋值入汇总表
    m_cBpbcoutsndcl.m_nboftxs  = iNbOfTxs;//明细业务总笔数    
    m_cBpbcoutsndcl.m_ctrlsum  = dCtrlSum;//明细业务总金额
    InsertDbBcCl();

    //4、组报文尾
    oPkg001.CreateMsgTail();
    
    //5、组报文
    oPkg001.CreateMsg();
	m_strMsgTxt = 	oPkg001.m_szMsgText;
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_szMsgText = [%s]", m_strMsgTxt.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "len = [%d]", m_strMsgTxt.length());

	//并更新处理状态为"已发送"
	sprintf(sSqlStr,"update bp_bcoutsendlist set procstate = '%s' "
            			" where msgid = '%s' and procstate = '%s' ", PR_HVBP_08,m_strMsgID.c_str(),PR_HVBP_95);
	
	iUpdCode = oBpbclist.execsql(sSqlStr);
	if (SQL_SUCCESS != iUpdCode) 
	{
		sprintf(m_szErrMsg, "oCBppkgassist.setstate:更新小额往帐贷记明细表记录错, [%d][%s]",
			iUpdCode, oBpbclist.GetSqlErr()); 
		
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendPkgPack::PackPkg001()");
}

void CSendPkgPack::PackPkg002()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendPkgPack::PackPkg002()");
	
	pkg002			oPkg002;
	CBpbdsendlist	oBpbdlist;

	char		    sSqlStr[4000 + 1]  = {0};
	string			strWhereClause	= "";
	int				iRetCode		= RTN_FAIL;
	int				iUpdCode		= RTN_FAIL;
	char			sTemp[32]		= {0};
	string			strTemp				;
	int 			iCount				;
	int 			iNbOfTxs		= 0;
	double			dCtrlSum		= 0.00;
	
	//1、组报文头
	int iRet = oPkg002.CreateMsgHeader("002",
				  m_strSendBank.c_str(),
				  m_strRecvBank.c_str(),
				  m_sMsgRefId,
				  m_sMsgRefId,
				  m_sWorkDate,
				  "1"	
				  )	;
    if (SQL_SUCCESS != iRet) 
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "创建报文头失败！");
        PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "创建报文头失败！");
    }
    
	//2、组批量包头｛P:
	strncpy(oPkg002.stHead002.szPkgType , "002",                 sizeof(oPkg002.stHead002.szPkgType )-1); //02C   包类型号
    strncpy(oPkg002.stHead002.szOdfiCode, m_strSendBank.c_str(), sizeof(oPkg002.stHead002.szOdfiCode)-1); //011   包发起清算行
    strncpy(oPkg002.stHead002.szRdfiCode, m_strRecvBank.c_str(), sizeof(oPkg002.stHead002.szRdfiCode)-1); //012   包接收清算行
    strncpy(oPkg002.stHead002.szPkgCDate, m_strMsgID.c_str(),    sizeof(oPkg002.stHead002.szPkgCDate)-1); //30E   包委托日期
    strncpy(oPkg002.stHead002.szPkgserNo, m_strMsgID.c_str()+8,  sizeof(oPkg002.stHead002.szPkgserNo)-1); //0BD   包序号 
    sprintf(oPkg002.stHead002.szRespdays, "%02d",                m_stPkgTab.iPKGRtrltd);                  //BS6   回执期限（天数）  
	
	//3、取明细，组报文体
	oBpbdlist.setctx(m_dbproc);

	strWhereClause = "msgid = '" + m_strMsgID + "' " + "and procstate = '" + PR_HVBP_95 +"' order by txid ";
	
	iRetCode = oBpbdlist.find(strWhereClause);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(m_szErrMsg, "oBpbdlist.find:查询小额往帐借记明细表记录错[%d][%s]",
			iRetCode, oBpbdlist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
    }
	
	while(SQL_SUCCESS == iRetCode)
	{
		iRetCode = oBpbdlist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
			break;
		if (SQL_SUCCESS != iRetCode) 
		{
			sprintf(m_szErrMsg, "oBpbdlist.fetch:查询小额往帐借记明细表记录错[%d][%s]",
				iRetCode, oBpbdlist.GetSqlErr()); 

			oBpbdlist.closeCursor();
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
		}

		/**************************************************************/
		//增加最大报文长度控制
		
		oPkg002.m_szPkgBody += oBpbdlist.m_npcmsg;
		iNbOfTxs++;
		dCtrlSum += oBpbdlist.m_amount;
	}
    oBpbdlist.closeCursor();
    
	if ( 0 >= iNbOfTxs )
    {
        Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "未找到相关打包记录[%s]", m_strMsgID.c_str());
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, "未找到相关打包记录");
    }
    
	
	sprintf(oPkg002.stHead002.szDetailCnt, "%08d", iNbOfTxs);                               //B63   明细业务总笔数
    sprintf(oPkg002.stHead002.szDetailAmt  , "RMB%015.0f",dCtrlSum*100);    //32B   明细业务总金  }
    
    GetCodeMac(oPkg002, m_szMac);
    memcpy(oPkg002.stHead002.szPkgDest, m_szMac, sizeof(m_szMac) - 1);  //C15   包密押 
    
    //在这赋值入汇总表
    m_bpbdsndcl.m_nboftxs  = iNbOfTxs;//明细业务总笔数    
    m_bpbdsndcl.m_ctrlsum  = dCtrlSum;//明细业务总金额
    InsertDbBdCl();

    //4、组报文尾
    oPkg002.CreateMsgTail();
    
    //5、组报文
    oPkg002.CreateMsg();
	m_strMsgTxt = 	oPkg002.m_szMsgText;
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_szMsgText = [%s]", m_strMsgTxt.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "len = [%d]", m_strMsgTxt.length());

	//并更新处理状态为"已发送"
	sprintf(sSqlStr,"update bp_bdsendlist set procstate = '%s' "
            			" where msgid = '%s' and procstate = '%s' ", PR_HVBP_08,m_strMsgID.c_str(),PR_HVBP_95);

	
	iUpdCode = oBpbdlist.execsql(sSqlStr);
	if (SQL_SUCCESS != iUpdCode) 
	{
		sprintf(m_szErrMsg, "更新小额往帐借记明细表记录错, [%d][%s]",
			iUpdCode, oBpbdlist.GetSqlErr()); 
		
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendPkgPack::PackPkg002()");
}

void CSendPkgPack::PackPkg005()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendPkgPack::PackPkg005()");
	
	pkg005				opkg005;
	CBpbcoutsendlist	oBpbclist;

	char				sSqlStr[4000 + 1]  = {0};
	string				strWhereClause	= "";
	int					iRetCode		= RTN_FAIL;
	int					iUpdCode		= RTN_FAIL;
	char				sTemp[32]		= {0};
	string				strTemp;
	int 				iCount;
	int 				iNbOfTxs		= 0;
	double				dCtrlSum		= 0.00;
	CString	            m_cstrListStr;	    //收款人清单
	CString	            m_TmpCstrListStr;	//收款人清单
	
	
	//1、组报文头
	int iRet = opkg005.CreateMsgHeader("005",
				  m_strSendBank.c_str(),
				  m_strRecvBank.c_str(),
				  m_sMsgRefId,
				  m_sMsgRefId,
				  m_sWorkDate,
				  "1"	
				  )	;
    if (SQL_SUCCESS != iRet) 
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "创建报文头失败！");

        PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "创建报文头失败！");
    }
    
	//2、组批量包头｛P:
	strncpy(opkg005.stHead001.szPkgType , "005",                 sizeof(opkg005.stHead001.szPkgType )-1); //02C   包类型号
    strncpy(opkg005.stHead001.szOdfiCode, m_strSendBank.c_str(), sizeof(opkg005.stHead001.szOdfiCode)-1); //011   包发起清算行
    strncpy(opkg005.stHead001.szRdfiCode, m_strRecvBank.c_str(), sizeof(opkg005.stHead001.szRdfiCode)-1); //012   包接收清算行
    strncpy(opkg005.stHead001.szPkgCDate, m_strMsgID.c_str(),    sizeof(opkg005.stHead001.szPkgCDate)-1); //30E   包委托日期
    strncpy(opkg005.stHead001.szPkgserNo, m_strMsgID.c_str()+8,  sizeof(opkg005.stHead001.szPkgserNo)-1); //0BD   包序号   
	
	//3、取明细，组报文体
	oBpbclist.setctx(m_dbproc);

	strWhereClause = "msgid = '" + m_strMsgID + "' " + "and procstate = '" + PR_HVBP_95 + "'  order by txid ";
	
	iRetCode = oBpbclist.find(strWhereClause);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(m_szErrMsg, "oBpbclist.find:查询小额往帐贷记明细表记录错, [%d][%s]",
			iRetCode, oBpbclist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
    }
	
	while(SQL_SUCCESS == iRetCode)
	{
		iRetCode = oBpbclist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
			break;
		if (SQL_SUCCESS != iRetCode) 
		{
			sprintf(m_szErrMsg, "oBpbclist.fetch:查询小额往帐贷记明细表记录错, [%d][%s]",
				iRetCode, oBpbclist.GetSqlErr()); 

			oBpbclist.closeCursor();
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
		}
        
		/**************************************************************/
		//增加最大报文长度控制
		m_TmpCstrListStr = oBpbclist.m_npcmsg.c_str();
		m_cstrListStr = m_cstrListStr + m_TmpCstrListStr;
		
		iNbOfTxs++;
		dCtrlSum += oBpbclist.m_amount;
	}
    oBpbclist.closeCursor();
    
    Trace(L_INFO,	__FILE__,  __LINE__, NULL, "m_cstrListStr[%s]", m_cstrListStr.GetBuffer(0));

	//给要素集的公共部分赋值
    if ( 0 < iNbOfTxs )
    {
        strncpy(opkg005.stBody003.szTrxsType,         oBpbclist.m_pmttpprtry.c_str(), sizeof(opkg005.stBody003.szTrxsType)-1);
        strncpy(opkg005.stBody003.szOdfiCode,         m_strSendBank.c_str(),          sizeof(opkg005.stBody003.szOdfiCode)-1);
        strncpy(opkg005.stBody003.szConsignDate,      oBpbclist.m_consigdate.c_str(), sizeof(opkg005.stBody003.szConsignDate)-1);
        strncpy(opkg005.stBody003.szPayOpenAccBkCode, oBpbclist.m_dbtrissr.c_str(),   sizeof(opkg005.stBody003.szPayOpenAccBkCode)-1);
        strncpy(opkg005.stBody003.szPayerAcc,         oBpbclist.m_dbtracctid.c_str(), sizeof(opkg005.stBody003.szPayerAcc)-1);
        strncpy(opkg005.stBody003.szPayerName,        oBpbclist.m_dbtnm.c_str(),      sizeof(opkg005.stBody003.szPayerName)-1);
        strncpy(opkg005.stBody003.szPayerAddr,        oBpbclist.m_dbtaddr.c_str(),    sizeof(opkg005.stBody003.szPayerAddr)-1);
        sprintf(opkg005.stBody003.szTrxKind,          "%-12s",  oBpbclist.m_purpprtry.c_str());
        sprintf(opkg005.stBody003.szListNum,          "%d",                           iNbOfTxs);
        opkg005.m_cstrListStr = m_cstrListStr;
        opkg005.m_szCurElementNo = "003";
        opkg005.AddBussiness();
    }
    else
    {
        Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "未找到相关打包记录[%s]", m_strMsgID.c_str());
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, "未找到相关打包记录");
    }
    
	
    sprintf(opkg005.stHead001.szDetailCnt, "%08d", iNbOfTxs);         //B63   明细业务总笔数
    sprintf(opkg005.stHead001.szDetailAmt  , "RMB%015.0f", dCtrlSum*100);    //32B   明细业务总金额
    
    GetCodeMac(opkg005, m_szMac);
    memcpy(opkg005.stHead001.szPkgDest, m_szMac, sizeof(m_szMac) - 1 );    //C15   包密押 暂时留空
    
    //在这赋值入汇总表
    m_cBpbcoutsndcl.m_nboftxs  = iNbOfTxs;//明细业务总笔数    
    m_cBpbcoutsndcl.m_ctrlsum  = dCtrlSum;//明细业务总金额
    InsertDbBcCl();
    
    //4、组报文尾
    opkg005.CreateMsgTail();
    
    //5、组报文
    opkg005.CreateMsg();
	m_strMsgTxt = 	opkg005.m_szMsgText;
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_szMsgText = [%s]", m_strMsgTxt.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "len = [%d]", m_strMsgTxt.length());

	//并更新处理状态为"已发送"
	sprintf(sSqlStr,"update bp_bcoutsendlist set procstate = '%s' "
            			" where msgid = '%s' and procstate = '%s' ", PR_HVBP_08,m_strMsgID.c_str(),PR_HVBP_95);

	
	iUpdCode = oBpbclist.execsql(sSqlStr);
	if (SQL_SUCCESS != iUpdCode) 
	{
		sprintf(m_szErrMsg, "oCBppkgassist.setstate:更新小额往帐贷记明细表记录错, [%d][%s]",
			iUpdCode, oBpbclist.GetSqlErr()); 
		
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendPkgPack::PackPkg005()");
}

void CSendPkgPack::PackPkg006()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendPkgPack::PackPkg006()");
	
	pkg006			opkg006;
	CBpbdsendlist	oBpbdlist;

	char			sSqlStr[4000 + 1]  = {0};
	string			strWhereClause	= "";
	int				iRetCode		= RTN_FAIL;
	int				iUpdCode		= RTN_FAIL;
	char			sTemp[32]		= {0};
	string			strTemp;
	int 			iCount;
	int 			iNbOfTxs		= 0;
	double			dCtrlSum		= 0.00;
	CString	        m_cstrListStr;	    //付款人清单
	CString	        m_TmpCstrListStr;	//付款人清单
	
	
	//1、组报文头
	int iRet = opkg006.CreateMsgHeader("006",
				  m_strSendBank.c_str(),
				  m_strRecvBank.c_str(),
				  m_sMsgRefId,
				  m_sMsgRefId,
				  m_sWorkDate,
				  "1"	
				  )	;
    if (SQL_SUCCESS != iRet) 
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "创建报文头失败！");

        PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "创建报文头失败！");
    }
    
	//2、组批量包头｛P:
	strncpy(opkg006.stHead002.szPkgType , "006",                 sizeof(opkg006.stHead002.szPkgType )-1); //02C   包类型号
    strncpy(opkg006.stHead002.szOdfiCode, m_strSendBank.c_str(), sizeof(opkg006.stHead002.szOdfiCode)-1); //011   包发起清算行
    strncpy(opkg006.stHead002.szRdfiCode, m_strRecvBank.c_str(), sizeof(opkg006.stHead002.szRdfiCode)-1); //012   包接收清算行
    strncpy(opkg006.stHead002.szPkgCDate, m_strMsgID.c_str(),    sizeof(opkg006.stHead002.szPkgCDate)-1); //30E   包委托日期
    strncpy(opkg006.stHead002.szPkgserNo, m_strMsgID.c_str()+8,  sizeof(opkg006.stHead002.szPkgserNo)-1); //0BD   包序号   
	sprintf(opkg006.stHead002.szRespdays, "%02d",                m_stPkgTab.iPKGRtrltd);                  //BS6   回执期限（天数）
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "opkg006.stHead002.szRespdays[%s] m_stPkgTab.iPKGRtrltd[%d]", opkg006.stHead002.szRespdays, m_stPkgTab.iPKGRtrltd);

	//3、取明细，组报文体
	oBpbdlist.setctx(m_dbproc);

	strWhereClause = "msgid = '" + m_strMsgID + "' " + "and procstate = '" + PR_HVBP_95 + "'  order by txid ";
	
	iRetCode = oBpbdlist.find(strWhereClause);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(m_szErrMsg, "oBpbdlist.find:查询小额往帐借记明细表记录错, [%d][%s]",
			iRetCode, oBpbdlist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
    }
	
	while(SQL_SUCCESS == iRetCode)
	{
		iRetCode = oBpbdlist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
			break;
		if (SQL_SUCCESS != iRetCode) 
		{
			sprintf(m_szErrMsg, "oBpbdlist.fetch:查询小额往帐借记明细表记录错, [%d][%s]",
				iRetCode, oBpbdlist.GetSqlErr()); 

			oBpbdlist.closeCursor();
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
		}
        
		/**************************************************************/
		//增加最大报文长度控制
		m_TmpCstrListStr = oBpbdlist.m_npcmsg.c_str();
		m_cstrListStr = m_cstrListStr + m_TmpCstrListStr;
		
		iNbOfTxs++;
		dCtrlSum += oBpbdlist.m_amount;
	}
    oBpbdlist.closeCursor();
    
    Trace(L_INFO,	__FILE__,  __LINE__, NULL, "m_cstrListStr[%s]", m_cstrListStr.GetBuffer(0));
    
	//给要素集的公共部分赋值
    if ( 0 < iNbOfTxs )
    {
        strncpy(opkg006.stBody004.szTrxsType,         oBpbdlist.m_pmttpprtry.c_str(), sizeof(opkg006.stBody004.szTrxsType)-1);
        strncpy(opkg006.stBody004.szOdfiCode,         m_strSendBank.c_str(),          sizeof(opkg006.stBody004.szOdfiCode)-1);
        strncpy(opkg006.stBody004.szConsignDate,      oBpbdlist.m_consigdate.c_str(), sizeof(opkg006.stBody004.szConsignDate)-1);
        strncpy(opkg006.stBody004.szRecOpenAccBkCode, oBpbdlist.m_cdtrissr.c_str(),   sizeof(opkg006.stBody004.szRecOpenAccBkCode)-1);
        strncpy(opkg006.stBody004.szRecipientAcc,     oBpbdlist.m_cdtracctid.c_str(), sizeof(opkg006.stBody004.szRecipientAcc)-1);
        strncpy(opkg006.stBody004.szRecipientName,    oBpbdlist.m_cdtrnm.c_str(),     sizeof(opkg006.stBody004.szRecipientName)-1);
        strncpy(opkg006.stBody004.szRecipientAddr,    oBpbdlist.m_cdtaddr.c_str(),    sizeof(opkg006.stBody004.szRecipientAddr)-1);
        sprintf(opkg006.stBody004.szTrxKind,		  "%-12s",        				  oBpbdlist.m_purpprtry.c_str());
        sprintf(opkg006.stBody004.szListNum,          "%08d",                           iNbOfTxs);

        opkg006.m_cstrListStr = m_cstrListStr;
        opkg006.m_szCurElementNo = "004";
        opkg006.AddBussiness();
    }
    else
    {
        Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "未找到相关打包记录[%s]", m_strMsgID.c_str());
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, "未找到相关打包记录");
    }
    
    sprintf(opkg006.stHead002.szDetailCnt, "%08d", iNbOfTxs);         //B63   明细业务总笔数
    sprintf(opkg006.stHead002.szDetailAmt  , "RMB%015.0f", dCtrlSum*100);    //32B   明细业务总金额
    
    GetCodeMac(opkg006, m_szMac);   
	memcpy(opkg006.stHead002.szPkgDest,  m_szMac,   sizeof(m_szMac) - 1);  //C15   包密押 暂时留空

    //在这赋值入汇总表
    m_bpbdsndcl.m_nboftxs  = iNbOfTxs;//明细业务总笔数    
    m_bpbdsndcl.m_ctrlsum  = dCtrlSum;//明细业务总金额
    InsertDbBdCl();

    //4、组报文尾
    opkg006.CreateMsgTail();
    
    //5、组报文
    opkg006.CreateMsg();
	m_strMsgTxt = 	opkg006.m_szMsgText;
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_szMsgText = [%s]", m_strMsgTxt.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "len = [%d]", m_strMsgTxt.length());

	//并更新处理状态为"已发送"
	sprintf(sSqlStr,"update bp_bdsendlist set procstate = '%s' "
            			" where msgid = '%s' and procstate = '%s' ", PR_HVBP_08,m_strMsgID.c_str(),PR_HVBP_95);

	
	iUpdCode = oBpbdlist.execsql(sSqlStr);
	if (SQL_SUCCESS != iUpdCode) 
	{
		sprintf(m_szErrMsg, "oCBppkgassist.setstate:更新小额往帐贷记明细表记录错, [%d][%s]",
			iUpdCode, oBpbdlist.GetSqlErr()); 
		
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendPkgPack::PackPkg006()");
}

void CSendPkgPack::PackPkg007()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendPkgPack::PackPkg007()");
	
	pkg007				oPkg007;
	CBpbcoutsendlist	oBpbclist;

	char				sSqlStr[4000 + 1]  = {0};
	string				strWhereClause	= "";
	int					iRetCode		= RTN_FAIL;
	int					iUpdCode		= RTN_FAIL;
	char				sTemp[32]		= {0};
	string				strTemp				;
	int 				iCount				;
	int 				iNbOfTxs		= 0;
	double				dCtrlSum		= 0.00;
	
	//1、组报文头
	int iRet = oPkg007.CreateMsgHeader("007",
				  m_strSendBank.c_str(),
				  m_strRecvBank.c_str(),
				  m_sMsgRefId,
				  m_sMsgRefId,
				  m_sWorkDate,
				  "1"	
				  )	;
    if (SQL_SUCCESS != iRet) 
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "创建报文头失败！");

        PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "创建报文头失败！");
    }
    
	//2、组批量包头｛P:
	strncpy(oPkg007.stHead001.szPkgType , "007",                 sizeof(oPkg007.stHead001.szPkgType )-1);                     //02C   包类型号
    strncpy(oPkg007.stHead001.szOdfiCode, m_strSendBank.c_str(), sizeof(oPkg007.stHead001.szOdfiCode)-1); //011   包发起清算行
    strncpy(oPkg007.stHead001.szRdfiCode, m_strRecvBank.c_str(), sizeof(oPkg007.stHead001.szRdfiCode)-1); //012   包接收清算行
    strncpy(oPkg007.stHead001.szPkgCDate, m_strMsgID.c_str(),    sizeof(oPkg007.stHead001.szPkgCDate)-1); //30E   包委托日期
    strncpy(oPkg007.stHead001.szPkgserNo, m_strMsgID.c_str()+8,  sizeof(oPkg007.stHead001.szPkgserNo)-1); //0BD   包序号   
	
	//3、取明细，组报文体
	oBpbclist.setctx(m_dbproc);

	strWhereClause = "msgid = '" + m_strMsgID + "' " + "and procstate = '" + PR_HVBP_95 + "'  order by txid ";
	
	iRetCode = oBpbclist.find(strWhereClause);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(m_szErrMsg, "oBpbclist.find:查询小额往帐贷记明细表记录错, [%d][%s]",
			iRetCode, oBpbclist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
    }
	
	while(SQL_SUCCESS == iRetCode)
	{
		iRetCode = oBpbclist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
			break;
		if (SQL_SUCCESS != iRetCode) 
		{
			sprintf(m_szErrMsg, "oBpbclist.fetch:查询小额往帐贷记明细表记录错, [%d][%s]",
				iRetCode, oBpbclist.GetSqlErr()); 
			
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
		}

		/**************************************************************/
		//增加最大报文长度控制
		
		oPkg007.m_szPkgBody += oBpbclist.m_npcmsg;
		iNbOfTxs++;
		dCtrlSum += oBpbclist.m_amount;
	}
    oBpbclist.closeCursor();
    
	if ( 0 >= iNbOfTxs )
    {
        Trace(L_ERROR,	__FILE__,  __LINE__, NULL, " 未找到相关打包记录[%s]", m_strMsgID.c_str());
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, "未找到相关打包记录");
    }
	
    sprintf(oPkg007.stHead001.szDetailCnt, "%08d", iNbOfTxs);    //B63   明细业务总笔数
    sprintf(oPkg007.stHead001.szDetailAmt  , "RMB%015.0f", dCtrlSum*100);    //32B   明细业务总金额
    
    char szMac[40+1] = {0};//编押后的串
    GetCodeMac(oPkg007, m_szMac);   
	memcpy(oPkg007.stHead001.szPkgDest, m_szMac, sizeof(m_szMac) - 1);    //C15   包密押
    
    //在这赋值入汇总表
    m_cBpbcoutsndcl.m_nboftxs  = iNbOfTxs;//明细业务总笔数    
    m_cBpbcoutsndcl.m_ctrlsum  = dCtrlSum;//明细业务总金额
    InsertDbBcCl();

    //4、组报文尾
    oPkg007.CreateMsgTail();
    
    //5、组报文
    oPkg007.CreateMsg();
	m_strMsgTxt = 	oPkg007.m_szMsgText;
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_szMsgText = [%s]", m_strMsgTxt.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "len = [%d]", m_strMsgTxt.length());

	//并更新处理状态为"已发送"
	sprintf(sSqlStr,"update bp_bcoutsendlist set procstate ='%s' "
            			" where msgid = '%s' and procstate = '%s' ", PR_HVBP_08,m_strMsgID.c_str(),PR_HVBP_95);
	
	iUpdCode = oBpbclist.execsql(sSqlStr);
	if (SQL_SUCCESS != iUpdCode) 
	{
		sprintf(m_szErrMsg, "oCBppkgassist.setstate:更新小额往帐贷记明细表记录错, [%d][%s]",
			iUpdCode, oBpbclist.GetSqlErr()); 
		
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendPkgPack::PackPkg007()");
}

void CSendPkgPack::PackPkg008(LPCSTR sTypeNo)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendPkgPack::PackPkg008()");
	
	pkg008				oPkg008;
	CBpbcoutsendlist	oBpbclist;

	char				sSqlStr[4000 + 1]  = {0};
	string				strWhereClause	= "";
	int					iRetCode		= RTN_FAIL;
	int					iUpdCode		= RTN_FAIL;
	char				sTemp[32]		= {0};
	string				strTemp				;
	int 				iCount				;
	int 				iNbOfTxs		= 0;
	double				dCtrlSum		= 0.00;
	int 				iSuccNbOfTxs    = 0;
	double				dSuccCtrlSum	= 0.00;
	
	//1、组报文头
	int iRet = oPkg008.CreateMsgHeader(sTypeNo,
				  m_strSendBank.c_str(),
				  m_strRecvBank.c_str(),
				  m_sMsgRefId,
				  m_sMsgRefId,
				  m_sWorkDate,
				  "1"	
				  )	;
    if (SQL_SUCCESS != iRet) 
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "创建报文头失败！");

        PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "创建报文头失败！");
    }
    
	//2、组批量包头｛P:
	strncpy(oPkg008.stHead008.szPkgType , sTypeNo,               sizeof(oPkg008.stHead008.szPkgType )-1); //02C   包类型号
    strncpy(oPkg008.stHead008.szOdfiCode, m_strSendBank.c_str(), sizeof(oPkg008.stHead008.szOdfiCode)-1); //011   包发起清算行
    strncpy(oPkg008.stHead008.szRdfiCode, m_strRecvBank.c_str(), sizeof(oPkg008.stHead008.szRdfiCode)-1); //012   包接收清算行
    strncpy(oPkg008.stHead008.szPkgCDate, m_strMsgID.c_str(),    sizeof(oPkg008.stHead008.szPkgCDate)-1); //30E   包委托日期
    strncpy(oPkg008.stHead008.szPkgserNo, m_strMsgID.c_str()+8,  sizeof(oPkg008.stHead008.szPkgserNo)-1); //0BD   包序号   
	
	//3、取明细，组报文体
	oBpbclist.setctx(m_dbproc);

	strWhereClause = "msgid = '" + m_strMsgID + "' " + "and procstate = '" + PR_HVBP_95 + "'  order by txid ";
	
	iRetCode = oBpbclist.find(strWhereClause);
	if (SQL_SUCCESS != iRetCode) 
    {
        sprintf(m_szErrMsg, "oBpbclist.find:查询小额往帐贷记明细表记录错, [%d][%s]",
			iRetCode, oBpbclist.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
    }
	
	while(SQL_SUCCESS == iRetCode)
	{
		iRetCode = oBpbclist.fetch();	
		if (SQLNOTFOUND == iRetCode) 
			break;
		if (SQL_SUCCESS != iRetCode) 
		{
			sprintf(m_szErrMsg, "oBpbclist.fetch:查询小额往帐贷记明细表记录错, [%d][%s]",
				iRetCode, oBpbclist.GetSqlErr()); 
			
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
		}

		/**************************************************************/
		//增加最大报文长度控制
		
		oPkg008.m_szPkgBody += oBpbclist.m_npcmsg;
		iNbOfTxs++;
		dCtrlSum += oBpbclist.m_amount;

		if ( BZ_PAID_PR02 == oBpbclist.m_busistate)
		{
		    iSuccNbOfTxs++;
		    dSuccCtrlSum += oBpbclist.m_amount;
		}
	}
    oBpbclist.closeCursor();
    
	if ( 0 >= iNbOfTxs )
    {
        Trace(L_ERROR,	__FILE__,  __LINE__, NULL, " 未找到相关打包记录[%s]", m_strMsgID.c_str());
		PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, "未找到相关打包记录");
    }
	
    sprintf(oPkg008.stHead008.szDetailCnt, "%08d",    iNbOfTxs);                        //B63   明细业务总笔数

    sprintf(oPkg008.stHead008.szDetailAmt, "RMB%015.0f", dCtrlSum*100);                 //32B   明细业务总金额

    sprintf(oPkg008.stHead008.szDetailSuccCnt, "%d", iSuccNbOfTxs);                     //B41   明细业务成功总笔数
    sprintf(oPkg008.stHead008.szDetailSuccAmt, "RMB%015.0f", dSuccCtrlSum*100);         //32C   明细业务成功总金额
    
    Trace(L_DEBUG,	__FILE__,  __LINE__, NULL, " m_orgnlmsgtp       = [%s]", oBpbclist.m_orgnlmsgtp.c_str()     );
    Trace(L_DEBUG,	__FILE__,  __LINE__, NULL, " m_oriinstgdrctpty  = [%s]", oBpbclist.m_oriinstgdrctpty.c_str());
    Trace(L_DEBUG,	__FILE__,  __LINE__, NULL, " m_orgnlmsgid       = [%s]", oBpbclist.m_orgnlmsgid.c_str()     );
    
    strncpy(oPkg008.stHead008.szOldPkgType,  oBpbclist.m_orgnlmsgtp.c_str() + 3,  sizeof(oPkg008.stHead008.szPkgDest)-1);     //02D   原包类型号
    strncpy(oPkg008.stHead008.szOldOdfiCode, oBpbclist.m_oriinstgdrctpty.c_str(), sizeof(oPkg008.stHead008.szOldOdfiCode)-1); //CCO   原包发起清算行
    strncpy(oPkg008.stHead008.szOldPkgCDate, oBpbclist.m_orgnlmsgid.c_str(),      sizeof(oPkg008.stHead008.szOldPkgCDate)-1); //30I   原包委托日期
    strncpy(oPkg008.stHead008.szOldPkgserNo, oBpbclist.m_orgnlmsgid.c_str() + 8,  sizeof(oPkg008.stHead008.szOldPkgserNo)-1); //0BE   原包序}
    
    GetCodeMac(oPkg008, m_szMac);   
 	memcpy(oPkg008.stHead008.szPkgDest,   m_szMac,  sizeof(m_szMac) - 1 );    //C15   包密押 
  
    //在这赋值入汇总表
    m_cBpbcoutsndcl.m_nboftxs      = iNbOfTxs;       //明细业务总笔数    
    m_cBpbcoutsndcl.m_ctrlsum      = dCtrlSum;       //明细业务总金额
    m_cBpbcoutsndcl.m_sapsnboftxs  = iSuccNbOfTxs;   //明细业务成功总笔数    
    m_cBpbcoutsndcl.m_ctrlsapssum  = dSuccCtrlSum;   //明细业务成功总金额
    
    //入汇总表
    InsertDbBcCl();

    //4、组报文尾
    oPkg008.CreateMsgTail();
    
    //5、组报文
    oPkg008.CreateMsg();
	m_strMsgTxt = 	oPkg008.m_szMsgText;
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_szMsgText  = [%s]", m_strMsgTxt.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "len          = [%d]", m_strMsgTxt.length());


	//并更新处理状态为"已打包"
	sprintf(sSqlStr,"update bp_bcoutsendlist set procstate = '%s' "
            			" where msgid = '%s' and procstate = '%s' ", PR_HVBP_08,m_strMsgID.c_str(),PR_HVBP_95);

	
	iUpdCode = oBpbclist.execsql(sSqlStr);
	if (SQL_SUCCESS != iUpdCode) 
	{
		sprintf(m_szErrMsg, "oCBppkgassist.setstate:更新小额往帐贷记明细表记录错, [%d][%s]",
			iUpdCode, oBpbclist.GetSqlErr()); 
		
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendPkgPack::PackPkg008()");
}

void CSendPkgPack::InsertDbBcCl()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendPkgPack::InsertDbBcCl()");
    
    SETCTX(m_cBpbcoutsndcl);
    m_cBpbcoutsndcl.m_workdate      = m_strWrkDate;
    m_cBpbcoutsndcl.m_msgtp         = m_strMsgType;
    m_cBpbcoutsndcl.m_dgtsign       = "NULL";                  //数值签名
    m_cBpbcoutsndcl.m_msgid         = m_strMsgID;              //报文标识号/包序号
    m_cBpbcoutsndcl.m_mesgid        = m_sMsgRefId;              //通信级标识号
    m_cBpbcoutsndcl.m_mesgrefid     = m_sMsgRefId;              //通信级标识号参考号
    m_cBpbcoutsndcl.m_instgdrctpty  = m_strSendBank;           //发起直接参与机构/付款清算行
    m_cBpbcoutsndcl.m_instddrctpty  = m_strRecvBank;           //接收直接参与机构/收款清算行
    m_cBpbcoutsndcl.m_workdate      = m_strWrkDate;            //工作日期
    m_cBpbcoutsndcl.m_consigdate    = m_strMsgID.substr(0,8);  //委托日期
    m_cBpbcoutsndcl.m_srcflag       = "0";                     //补发标志
    m_cBpbcoutsndcl.m_realtimeflag  = "0";                     //实时标志
    m_cBpbcoutsndcl.m_procstate     = PR_HVBP_08;              //处理状态
    m_cBpbcoutsndcl.m_checkstate    = "1";                     //对账状态
    m_cBpbcoutsndcl.m_ccy           = "RMB";                   //币种
    
    int iRet = m_cBpbcoutsndcl.insert();
    if(SUCCESSED!=iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_cBpbcoutsndcl insert failed[%d][%s]",
            iRet,m_cBpbcoutsndcl.GetSqlErr());
            
        PMTS_ThrowException(DB_INSERT_FAIL);
    }
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendPkgPack::InsertDbBcCl()");
}

void CSendPkgPack::InsertDbBdCl()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendPkgPack::InsertDbBdCl()");
    
    SETCTX(m_bpbdsndcl);
    m_bpbdsndcl.m_workdate      = m_strWrkDate;
    m_bpbdsndcl.m_msgtp         = m_strMsgType;
    m_bpbdsndcl.m_dgtsign       = "NULL";                 //数值签名
    m_bpbdsndcl.m_msgid         = m_strMsgID;             //报文标识号/包序号
    m_bpbdsndcl.m_mesgid        = m_sMsgRefId;            //通信级标识号
    m_bpbdsndcl.m_mesgrefid     = m_sMsgRefId;            //通信级标识号参考号
    m_bpbdsndcl.m_instgdrctpty  = m_strSendBank;          //发起直接参与机构/付款清算行
    m_bpbdsndcl.m_instddrctpty  = m_strRecvBank;          //接收直接参与机构/收款清算行
    m_bpbdsndcl.m_workdate      = m_strWrkDate;           //工作日期
    m_bpbdsndcl.m_consigdate    = m_strMsgID.substr(0,8); //委托日期
    m_bpbdsndcl.m_srcflag       = "0";                    //补发标志
    m_bpbdsndcl.m_realtimeflag  = "0";                    //实时标志
    m_bpbdsndcl.m_procstate     = PR_HVBP_08;           //处理状态
    m_bpbdsndcl.m_ccy           = "RMB";                  //币种
    m_bpbdsndcl.m_pkgrtrltd     = m_stPkgTab.iPKGRtrltd;  //回执期限
    m_bpbdsndcl.m_checkstate    = "1";//对账状态
    int iRet = m_bpbdsndcl.insert();
    
    if(SUCCESSED!=iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_bpbdsndcl insert failed[%d][%s]",
            iRet,m_bpbdsndcl.GetSqlErr());
            
        PMTS_ThrowException(DB_INSERT_FAIL);
    }
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendPkgPack::InsertDbBdCl()");
}



	
void CSendPkgPack::GetCodeMac(pkgbase& oPkgBase,char* pMac)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendPkgPack::GetCodeMac()");
 
    string strCodeMac;//取加押串
    oPkgBase.GetMacStr(oPkgBase,strCodeMac);
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strCodeMac = [%s]", strCodeMac.c_str());
    
    int iRetCode = CodeMac(m_dbproc,strCodeMac.c_str(),m_strSendBank.c_str(),pMac);
    if (RTN_SUCCESS != iRetCode) 
	{	
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, "编押失败");
		PMTS_ThrowException(__FILE__, __LINE__, OPT_CODEMAC_FAIL, "编押失败");
	}
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendPkgPack::GetCodeMac()");
}
