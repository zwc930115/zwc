/*
 *  sendbeps387.cpp
 *  Description:
 *  Created on: 2012-06-25
 *  Author: __wsh
 */

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps387.h"


CSendBeps387::CSendBeps387(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
}

CSendBeps387::~CSendBeps387()
{
}

//__wsh 2012-06-25 业务处理入口
INT32 CSendBeps387::doWorkSelf(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			m_sMsgId, "Enter CSendBeps387::doWorkSelf");

	int iRet = -1;

	//获取数据
	iRet = GetData();

	//设置XML报文数据
	SetData();

	//构建XML报文
	iRet = BuildPmtsMsg();

	//更新数据库状态
	iRet = UpdateState();

	//发送XML报文
	iRet = AddQueue();

	Trace(L_INFO, __FILE__, __LINE__,
			m_sMsgId, "Leave CSendBeps387::doWorkSelf");

	return iRet;
}

//__wsh 2012-06-25 获取业务数据
int CSendBeps387::GetData(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			m_sMsgId, "Enter CSendBeps387::GetData");

	int iRet = -1;

	//获取汇总表数据
	SETCTX(m_colltncl);
	//主键查找
	m_colltncl.m_msgid    = m_sMsgId;
	m_colltncl.m_instgpty = m_sSendOrg;
	m_colltncl.m_srcflag  = "1";

	iRet = m_colltncl.findByPK();
	if(SQL_SUCCESS != SQL_SUCCESS){
		sprintf(m_sErrMsg,
			"[bp_colltnchrgscl]查询失败[%s][%s] iRet=%d cause=%s",
			m_sMsgId, m_sSendOrg, m_colltncl.GetSqlErr());

		Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId, m_sErrMsg);

		PMTS_ThrowException(DB_FIND_BY_PK_FAIL);
	}

	//获取明细表数据, 一笔业务只有一条明细， 由于TXID未知，不能用主键查询
	SETCTX(m_colltnlist);
	//使用条件查找
	string strSql = "msgid='";
	strSql += m_sMsgId;
	strSql += "' and instgpty='";
	strSql += m_sSendOrg;
	strSql += "' and srcflag='1' ";
	Trace(L_DEBUG, __FILE__, __LINE__, m_sMsgId, strSql.c_str());
	iRet = m_colltnlist.find(strSql);
	if(SQL_SUCCESS == iRet){
		iRet = m_colltnlist.fetch();
		m_colltnlist.closeCursor();
	}

	if(SQL_SUCCESS != SQL_SUCCESS){
		sprintf(m_sErrMsg,
			"[bp_colltnchrgslist]查询失败[%s][%s] iRet=%d cause=%s",
			m_sMsgId, m_sSendOrg, m_colltncl.GetSqlErr());

		Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId, m_sErrMsg);

		PMTS_ThrowException(DB_FIND_BY_PK_FAIL);
	}


	Trace(L_INFO, __FILE__, __LINE__,
			m_sMsgId, "Leave CSendBeps387::GetData");

	return iRet;
}

//__wsh 2012-06-25 设置XML报文数据
void CSendBeps387::SetData(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			m_sMsgId, "Enter CSendBeps387::SetData");

	int iRet = -1;
	//获取报文创建日期时间
	iRet = GetIsoDateTime(m_dbproc, SYS_BEPS, m_ISODateTime);
	if(iRet != RTN_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__,
					NULL, "获取iso datetime失败！");
		PMTS_ThrowException(OPT_GET_SYS_DATETIME_FAIL);
	}

	//业务头 发起行与发起清算行都填写发起清算行，接收同
	m_cBeps387.MsgId            = m_colltncl.m_msgid;
	m_cBeps387.CreDtTm          = m_ISODateTime;
	m_cBeps387.InstgDrctPty     = m_colltncl.m_instgdrctpty;
	m_cBeps387.GrpHdrInstgPty   = m_colltncl.m_instgdrctpty;
	m_cBeps387.InstdDrctPty     = m_colltncl.m_instddrctpty;
	m_cBeps387.GrpHdrInstdPty   = m_colltncl.m_instddrctpty;
	m_cBeps387.SysCd            = m_colltncl.m_syscd;
	m_cBeps387.Rmk              = m_colltncl.m_rmk;

	//原业务信息
	m_cBeps387.OrgnlMsgId    = m_colltncl.m_orgnlmsgid;    //原报文标识
	m_cBeps387.OrgnlInstgPty = m_colltncl.m_orgnlinstgpty; //原发起行
	m_cBeps387.OrgnlBtchNb   = m_colltncl.m_orgnlbtchnb;   //原批次号
	m_cBeps387.TxId          = m_colltnlist.m_txid;        //原明细标识

	//应答信息
	m_cBeps387.Sts             = m_colltnlist.m_busistate;
	m_cBeps387.RjctCd          = m_colltnlist.m_rjctcd;
	m_cBeps387.RspsnInfRjctInf = m_colltnlist.m_rjctinf;
	m_cBeps387.PrcPty          = m_colltnlist.m_rjctprcpty;

	//明细
	m_cBeps387.DbtrNm     = m_colltncl.m_cdbtrnm;      //付款人名称
	m_cBeps387.DbtrAcctId = m_colltncl.m_cdbtrid;      //付款人账号
	m_cBeps387.DbtrAgtId  = m_colltncl.m_cdbtrbrnchid; //付款行行号

	m_cBeps387.CdtrAgtId  = m_colltnlist.m_cdtrbrnchid;  //收款行行号
	m_cBeps387.CdtrNm     = m_colltnlist.m_cdtrnm;       //收款人名称
	m_cBeps387.CdtrAcctId = m_colltnlist.m_cdtrid;       //收款人账号

	m_cBeps387.Ccy        = m_colltnlist.m_currency;    //货币符号
	char szAmt[32] = {0};
	sprintf(szAmt, "%.2f", m_colltnlist.m_amout);
	m_cBeps387.Amt           = szAmt; //金额
	m_cBeps387.CtgyPurpPrtry = m_colltncl.m_ctgyprtry;//业务类型
	m_cBeps387.PurpPrtry     = m_colltnlist.m_puryprtry; //业务种类

	Trace(L_INFO, __FILE__, __LINE__,
			m_sMsgId, "Leave CSendBeps387::SetData");
}

//__wsh 2012-06-25 387往报加签
void CSendBeps387::AddSign387(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Enter AddSign387");

	char   sSignedStr[4096 + 1] = {0};

	m_cBeps387.getOriSignStr();

	AddSign(m_cBeps387.m_sSignBuff.c_str(),
			sSignedStr,
			RAWSIGN,
			m_colltncl.m_instgdrctpty.c_str());

	m_cBeps387.m_szDigitSign = sSignedStr;

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Leave AddSign387");
}

//__wsh 2012-06-25 构建XML报文
int CSendBeps387::BuildPmtsMsg(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			m_sMsgId, "Enter CSendBeps387::BuildPmtsMsg");

	int iRet = -1;

	//获取通信参与号
	if( !GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS) ){
		Trace(L_ERROR, __FILE__, __LINE__,
				m_sMsgId, "获取通信参与号出错!");
		PMTS_ThrowException(PRM_FAIL);
	}

	//创建消息头
	m_cBeps387.CreateXMlHeader(
				"BEPS",
				m_sWorkDate,
				m_sSendOrg,
				m_colltncl.m_instddrctpty.c_str(),
				"beps.387.001.01",
				m_sMsgRefId);

	//加签
	AddSign387();

	//创建XML报文
	iRet = m_cBeps387.CreateXml();
	if(RTN_SUCCESS != iRet){
		Trace(L_ERROR,  __FILE__,  __LINE__,
				NULL, "创建报文失败,iRet=%d", iRet);
		PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
	}

	m_sMsgTxt = m_cBeps387.m_sXMLBuff.c_str();

	Trace(L_INFO, __FILE__, __LINE__,
			m_sMsgId, "Leave CSendBeps387::BuildPmtsMsg");

	return iRet;
}

//__wsh 2012-06-25 更新业务状态
int CSendBeps387::UpdateState(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CSendBeps392::UpdateState");

	int iRet = -1;

	string strNpcMsg = "";
	if(!m_colltncl.write_blob(m_cBeps387.m_sXMLBuff.c_str(), strNpcMsg, SYS_BEPS)){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"写大字段表出错:[%s]", m_colltncl.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}

	//更新汇总表状态
	string strSqlCl = " update bp_colltnchrgscl set procstate='";
	strSqlCl += PR_HVBP_08;
	strSqlCl += "', npcmsg='";
	strSqlCl += strNpcMsg;
	strSqlCl += "', mesgid='";
	strSqlCl += m_sMsgRefId;
	strSqlCl += "', mesgrefid='";
	strSqlCl += m_sMsgRefId;
	strSqlCl += "', statetime=sysdate where msgid='";
	strSqlCl += m_colltncl.m_msgid;
	strSqlCl += "' and instgdrctpty='";
	strSqlCl += m_colltncl.m_instgdrctpty;
	strSqlCl += "' and srcflag=1 ";

	Trace(L_DEBUG, __FILE__, __LINE__, m_sMsgId,
			"__strSqlCl=[%s]", strSqlCl.c_str());

	iRet = m_colltncl.execsql(strSqlCl.c_str());
	if(SQL_SUCCESS != iRet){

		sprintf(m_sErrMsg, "[bp_colltnchrgscl]更新出错，iRet=%d cause=%s",
				iRet, m_colltncl.GetSqlErr());

		Trace(L_ERROR, __FILE__, __LINE__, m_sMsgId,
				"更新异常：%s", m_sErrMsg);

		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Enter CSendBeps392::UpdateState");

	return iRet;
}
