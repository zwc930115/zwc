/*
 *  recvbeps394.cpp
 *  Description: 指量客户账户查询来报处理类beps.394.001.01
 *  Created on: 2012-6-12
 *  Author: __wsh
 */

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbeps394.h"

static const char* _AcctDtls = "AcctDtls";

//
CRecvbeps394::CRecvbeps394()
{
	m_strMsgTp = "beps.394.001.01";
}

//
CRecvbeps394::~CRecvbeps394()
{
}

//__wsh 2012-06-12 //业务处理入口
int CRecvbeps394::Work(const char* szmsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CRecvbeps394::Work");
	int iRet = -1;

	//解析报文
	UnPack(szmsg);

	//新增汇�?�来账记�?
	InsertData_cl();

	//新增明细来账记录
	InsertData_list();

	//核签
	CheckSign394();

	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvbeps394::Work");
	return 0;
}

//__wsh 2012-06-12
int CRecvbeps394::UnPack(const char* szMsg)
{
	Trace(L_DEBUG, __FILE__, __LINE__,
			NULL, "Enter CRecvbeps394::UnPack");
	int iRet = -1;

	if(NULL == szMsg || '\0' == szMsg[0]){
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "报文长度为空");
		PMTS_ThrowException(PRM_FAIL);
	}

	//获取工作日期
	iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
	if(RTN_SUCCESS != iRet){
		Trace(L_ERROR,  __FILE__, __LINE__,
				NULL, "获取工作日期失败�?");
		PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
	}
	m_strWorkDate = m_sWorkDate;

	//解析报文
	if (OPERACT_SUCCESS != m_cBeps394.ParseXml(szMsg)){
		Trace(L_ERROR,  __FILE__,  __LINE__,
				NULL, "报文解析出错! iRet= %d", iRet);

		PMTS_ThrowException(__FILE__, __LINE__,
				OPT_PRS_MSG_FAIL, "报文解析出错");
	}

    //ZFPTLOG.SetLogInfo("394", m_cBeps394.MsgId.c_str());
    
	Trace(L_DEBUG, __FILE__, __LINE__,
			NULL, "Leave CRecvbeps394::UnPack");

	return OPERACT_SUCCESS;
}

//__wsh 2012-06-12
int CRecvbeps394::SetData_cl(void)
{
	int iRet = -1;

	m_caqcl.m_workdate     = m_sWorkDate;               //工作日期
	m_caqcl.m_msgtp        = m_strMsgTp;                //报文类型
	m_caqcl.m_mesgid       = m_cBeps394.m_PMTSHeader.getMesgID();    //通信级标�?
	m_caqcl.m_mesgrefid    = m_cBeps394.m_PMTSHeader.getMesgRefID(); //参与通信标识
	m_caqcl.m_msgid        = m_cBeps394.MsgId;          //报文标识
	m_caqcl.m_instgdrctpty = m_cBeps394.InstgDrctPty;   //发起清算�?
	m_caqcl.m_instgpty     = m_cBeps394.GrpHdrInstgPty; //发起�?
	m_caqcl.m_instddrctpty = m_cBeps394.InstdDrctPty;   //接收清算�?
	m_caqcl.m_instdpty     = m_cBeps394.GrpHdrInstdPty; //接收�?
	m_caqcl.m_syscd        = m_cBeps394.SysCd;          //系统�?
	m_caqcl.m_rmk          = m_cBeps394.Rmk;            //备注
	m_caqcl.m_srcflag      = "2";                       //�?来账标识 1：往�? 2：来�?
	m_caqcl.m_procstate    = PR_HVBP_01;                //处理状�??
	m_caqcl.m_acctcnt      = m_cBeps394.AcctCnt;        //数目

	iRet = 0;
	return iRet;
}

//__wsh 2012-06-12 来账汇�?�记录入�?
int CRecvbeps394::InsertData_cl(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CRecvbeps394::InsertData_cl");
	int iRet = -1;

	SETCTX(m_caqcl);

	//设置汇�?�数�?
	iRet = SetData_cl();

	//插入数据
	iRet = m_caqcl.insert();

	if(SQL_SUCCESS != iRet){
		char szErr[512] = {0};
		sprintf(szErr,
			"插入批量账户查询汇�?�表失败  iRet=%d cause=%s",
			iRet, m_caqcl.GetSqlErr());
		Trace(L_ERROR, __FILE__, __LINE__,
				NULL, "%s", szErr);

		PMTS_ThrowException(DB_INSERT_FAIL);
	}
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvbeps394::InsertData_cl");
	return iRet;
}

//__wsh 2012-06-12 获取循环中账户信息明�?
int CRecvbeps394::GetAcctDtls(int iCount)
{
	int iRet = -1;

	//账户账号（卡号）
	m_cBeps394.Id      = m_cBeps394.GetValueFromCycle(_AcctDtls, "Id", iCount);
	//账户名称
	m_cBeps394.Nm      = m_cBeps394.GetValueFromCycle(_AcctDtls, "Nm", iCount);
	//�?户行行号
	m_cBeps394.AcctBk  = m_cBeps394.GetValueFromCycle(_AcctDtls, "AcctBk", iCount);

	//add begin by jienjunj 20160326 ���й涨���ӹ������ݺ��뼰�绰�ֶ�
	m_cBeps394.CtznIDNb = m_cBeps394.GetValueFromCycle(_AcctDtls, "CtznIDNb", iCount);
	m_cBeps394.Tel      = m_cBeps394.GetValueFromCycle(_AcctDtls, "Tel", iCount);
	//add end by jienjunj 20160326 ���й涨���ӹ������ݺ��뼰�绰�ֶ�
	Trace(L_INFO,  __FILE__,  __LINE__,NULL, "CtznIDNb[%s] Tel[%s]",m_cBeps394.CtznIDNb.c_str(),m_cBeps394.Tel.c_str());

	iRet = 0;
	return iRet;
}

//设置明细
int CRecvbeps394::SetData_list(int iCount)
{
	int iRet = -1;

	//获取循环中账户信息明�?
	GetAcctDtls(iCount);

	//设置批量账户查询明细表信�?
//	m_caqlist.m_row_id   = iCount+1;
	m_caqlist.m_acctid   = m_cBeps394.Id;
	m_caqlist.m_acctnm   = m_cBeps394.Nm;
	m_caqlist.m_acctbk   = m_cBeps394.AcctBk;

	//add begin by jienjunj 20160326 ���й涨���ӹ������ݺ��뼰�绰�ֶ�
	m_caqlist.m_CtznIDNb= m_cBeps394.CtznIDNb;
	m_caqlist.m_Tel= m_cBeps394.Tel;	
	//add end by jienjunj 20160326 ���й涨���ӹ������ݺ��뼰�绰�ֶ�

	iRet = 0;
	return iRet;
}

//__wsh 2012-06-12 明细入库
int CRecvbeps394::InsertData_list(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CRecvbeps394::InsertData_list");
	int iRet = -1;

	SETCTX(m_caqlist);

	//设置公共部份明细
	m_caqlist.m_workdate 	 = m_strWorkDate; 		      //工作日期
	m_caqlist.m_msgid        = m_cBeps394.MsgId;          //报文标识
	m_caqlist.m_instgdrctpty = m_cBeps394.InstgDrctPty;   //发�?�清算行
	m_caqlist.m_instgpty     = m_cBeps394.GrpHdrInstgPty; //发�?�行
	m_caqlist.m_srcflag		 = "2";       //�?来账标识�? 1：往账，2：来
	m_caqlist.m_procstate	 = PR_HVBP_01;//处理状�??

	//设置循环部份明细
	int iCount = atoi(m_cBeps394.AcctCnt.c_str());
	for(int i = 0; i < iCount; ++i){
		//设置数据
		SetData_list(i);
		//插入数据
		iRet = m_caqlist.insert();
		if(SQL_SUCCESS != iRet){
			char szErr[512] = {0};
			sprintf(szErr, "插入批量账户查询明细失败 iRet=%d cause=%s",
					iRet, m_caqlist.GetSqlErr());
			Trace(L_ERROR, __FILE__, __LINE__,
					NULL, "%s", szErr);

			PMTS_ThrowException(DB_INSERT_FAIL);
		}// end if
		//循环加签 
		m_cBeps394.AddTxStr();
	}// end for
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CRecvbeps394::InsertData_list");
	return iRet;
}

//__wsh 2012-06-12 核签
void CRecvbeps394::CheckSign394()
{
	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Enter CheckSign394");

	m_cBeps394.getOriSignStr();

	CheckSign(
		m_cBeps394.m_sSignBuff.c_str(),
		m_cBeps394.m_szDigitSign.c_str(),
		m_cBeps394.InstgDrctPty.c_str());

	Trace(L_INFO,  __FILE__,  __LINE__,
					NULL, "Leave CheckSign394");
}



