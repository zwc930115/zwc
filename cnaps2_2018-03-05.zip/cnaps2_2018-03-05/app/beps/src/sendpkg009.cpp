/******************************************************************** 
�ļ����� sendpkg003.cpp
�����ˣ� handongfeng
��  �ڣ� 2011-04-18
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendpkg003.h"

using namespace ZFPT;

CSendPkg003::CSendPkg003(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{
    memset(m_szchMsgId, 0x00, sizeof(m_szchMsgId));
}

CSendPkg003::~CSendPkg003()
{

}

void CSendPkg003::AddAppendData(string& strAppData,int iTimes)
{
    string strTemp;
    GetTagVal(strTemp, m_cBpbdsndlist.m_cstmrcdttrfaddtlinf, "72C:", iTimes);
    strAppData.append(strTemp);
}

INT32 CSendPkg003::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg003::doWorkSelf");

    bool bRet = GetMsgIdValue(m_dbproc, m_szchMsgId, eMsgId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡmsgidʧ��");
        PMTS_ThrowException(PRM_FAIL);    
    }

    bRet = GetMsgIdValue(m_dbproc, m_sMesgID, eRefId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡm_sMesgIDʧ��");
        PMTS_ThrowException(PRM_FAIL);         
    }
    strcpy(m_sMsgRefId, m_sMesgID);
    
    //��ҵ����л�ȡ����
    GetData();

    //ҵ����
    //CheckValues();

    //��һ�����ı���
    CreatePkg003();

    UpdateState();

    InsertCL();

    AddQueue();
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg003::doWorkSelf"); 
    return 0;
}

void CSendPkg003::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg003::UpdateState"); 
    
    SETCTX(m_cBpbdsndlist);

    string strSQL;
    
	strSQL += "UPDATE Bp_bdsendlist t SET t.PROCSTATE = '02'";
	strSQL += ", t.MSGID = '";
	strSQL += m_szchMsgId;
    strSQL += "' ";
    
	strSQL += " WHERE t.INSTGDRCTPTY = '";
	strSQL += m_cBpbdsndlist.m_instgdrctpty.c_str();
    strSQL += "' AND t.TXID = '";
	strSQL += m_cBpbdsndlist.m_txid.c_str();								
	strSQL += "'";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL= %s", strSQL.c_str());
	
    int iRet = m_cBpbdsndlist.execsql(strSQL.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸ķ���״̬ʧ��iRet=%d, %s", iRet, m_cBpbdsndlist.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }   
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg003::UpdateState"); 
}

void CSendPkg003::InsertCL()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg003::InsertCL"); 
    
    SETCTX(m_Bpbdsndcl);

    m_Bpbdsndcl.m_checkstate = "1" ; 
    m_Bpbdsndcl.m_workdate = m_cBpbdsndlist.m_workdate; 
    m_Bpbdsndcl.m_consigdate = m_cBpbdsndlist.m_consigdate; 
    m_Bpbdsndcl.m_msgtp = m_cBpbdsndlist.m_msgtp; 
    m_Bpbdsndcl.m_mesgid = m_sMesgID; 
    m_Bpbdsndcl.m_mesgrefid = m_sMsgRefId; 
    m_Bpbdsndcl.m_msgid = m_szchMsgId; 
    m_Bpbdsndcl.m_instgdrctpty = m_cBpbdsndlist.m_instgdrctpty ; 
    m_Bpbdsndcl.m_instddrctpty = m_cBpbdsndlist.m_instddrctpty ; 
    m_Bpbdsndcl.m_npcmsglen = m_cBpbdsndlist.m_npcmsglen; 
    m_Bpbdsndcl.m_npcfilename = m_cBpbdsndlist.m_npcmsg; 
    m_Bpbdsndcl.m_busistate = m_cBpbdsndlist.m_busistate; 
    m_Bpbdsndcl.m_processcode = m_cBpbdsndlist.m_processcode; 
    m_Bpbdsndcl.m_rjctinf = m_cBpbdsndlist.m_rjctinf; 
    m_Bpbdsndcl.m_procstate = m_cBpbdsndlist.m_procstate; 
    m_Bpbdsndcl.m_netgdt = m_cBpbdsndlist.m_netgdt; 
    m_Bpbdsndcl.m_netgrnd = m_cBpbdsndlist.m_netgrnd; 
    m_Bpbdsndcl.m_statetime = m_cBpbdsndlist.m_statetime; 
    m_Bpbdsndcl.m_finalstatedate = m_cBpbdsndlist.m_finalstatedate; 
    m_Bpbdsndcl.m_srcflag = "0" ; 
    m_Bpbdsndcl.m_rmk = m_cBpbdsndlist.m_rmk; 
    m_Bpbdsndcl.m_ccy = m_cBpbdsndlist.m_currency; 
    m_Bpbdsndcl.m_nboftxs = 1 ; 
    m_Bpbdsndcl.m_sapsnboftxs = 0 ; 
    m_Bpbdsndcl.m_ctrlsapssum = 0.00; 
    m_Bpbdsndcl.m_ctrlsum = m_cBpbdsndlist.m_amount; 
    m_Bpbdsndcl.m_dgtsign = "����ǩ��" ; 
    m_Bpbdsndcl.m_pkgrtrltd = m_cBpbdsndlist.m_pkgrtrltd; 
    m_Bpbdsndcl.m_realtimeflag = "1" ; 
    m_Bpbdsndcl.m_isrbflg = m_cBpbdsndlist.m_isrbflg; 

    int iRet = m_Bpbdsndcl.insert();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�����¼ʧ��[%d][%s]", iRet, m_Bpbdsndcl.GetSqlErr());
        PMTS_ThrowException(DB_INSERT_FAIL);    
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg003::InsertCL"); 
}

void CSendPkg003::CreatePkg003()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CSendPkgPack::PackPkg003()");

    //1���鱨��ͷ
    int iRet = m_pkg003.CreateMsgHeader("003",
        m_cBpbdsndlist.m_instgdrctpty.c_str(),
        m_cBpbdsndlist.m_instddrctpty.c_str(),
        m_sMsgRefId,
        m_sMesgID,
        m_sWorkDate,
        "1"	
        )	;
    if (SQL_SUCCESS != iRet) 
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��������ͷʧ�ܣ�");
        PMTS_ThrowException(__FILE__, __LINE__, OTH_ERR, "��������ͷʧ�ܣ�");
    }

    //2����������ͷ��P:
    strncpy(m_pkg003.stPkgHead003.szPkgType , "003",                 sizeof(m_pkg003.stPkgHead003.szPkgType )-1); //02C   �����ͺ�
    strncpy(m_pkg003.stPkgHead003.szOdfiCode, m_cBpbdsndlist.m_instgdrctpty.c_str(), sizeof(m_pkg003.stPkgHead003.szOdfiCode)-1); //011   ������������
    strncpy(m_pkg003.stPkgHead003.szRdfiCode, m_cBpbdsndlist.m_instddrctpty.c_str(), sizeof(m_pkg003.stPkgHead003.szRdfiCode)-1); //012   ������������
    strncpy(m_pkg003.stPkgHead003.szPkgCDate, m_szchMsgId,    sizeof(m_pkg003.stPkgHead003.szPkgCDate)-1); //30E   ��ί������
    strncpy(m_pkg003.stPkgHead003.szPkgserNo, m_szchMsgId+8,  sizeof(m_pkg003.stPkgHead003.szPkgserNo)-1); //0BD   ����� 
    strncpy(m_pkg003.stPkgHead003.szPkgDest,   " ",  sizeof(m_pkg003.stPkgHead003.szPkgDest)-1);  //C15   ����Ѻ ��ʱ����
    sprintf(m_pkg003.stPkgHead003.szDetailCnt, "%d", 1);                               //B63   ��ϸҵ���ܱ���
    sprintf(m_pkg003.stPkgHead003.szDetailAmt  , "RMB%015.0f",m_cBpbdsndlist.m_amount*100);    //32B   ��ϸҵ���ܽ��

    //3.�鱨����
    CreateMsgBody();
    
    //4���鱨��β
    m_pkg003.CreateMsgTail();

    //5���鱨��
    m_pkg003.CreateMsg();

    m_sMsgTxt = m_pkg003.m_szMsgText;

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_sMsgTxt=%s", m_sMsgTxt.c_str());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CSendPkgPack::PackPkg003()");
}


INT32 CSendPkg003::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg003::GetData");

    SETCTX(m_cBpbdsndlist);
    
    m_cBpbdsndlist.m_instgdrctpty = m_sSendOrg;
    m_cBpbdsndlist.m_txid = m_sMsgId;

    iRet = m_cBpbdsndlist.findByPK();
    if (SQLNOTFOUND == iRet)
    {
        sprintf(m_sErrMsg, "С�����ʽ����ϸ�����Ҳ���ָ��ҵ��[%s][%s]", 
            m_sSendOrg, m_sMsgId);

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    } 	
    else if (SQL_SUCCESS != iRet) 
    {
        sprintf(m_sErrMsg,"��ѯС�����ʴ�����ϸ����������[%d][%s]",
            iRet, m_cBpbdsndlist.GetSqlErr());

        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_NOT_FOUND, m_sErrMsg);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg003::GetData"); 

    return iRet;
}

INT32 CSendPkg003::CheckValues()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg003::CheckValues");

    int iRet = -1;
    
    //������޼��
    iRet = isOutOfLimit(m_dbproc, 
                        m_cBpbdsndlist.m_msgtp.c_str(), 
                        m_cBpbdsndlist.m_purpprtry.c_str(),
                        m_cBpbdsndlist.m_amount, 
                        m_sErrMsg);
    if ( 0 != iRet)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_AMT_OUT_OF_LIMIT, m_sErrMsg);
    }
    
    //�����кż��
    iRet = isBankRight(m_dbproc, m_cBpbdsndlist.m_instddrctpty.c_str(), m_sErrMsg);
    if ( 0 != iRet )
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_sErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_RECVBANK_CHECK_FAIL, m_sErrMsg);
    }
    
    //�˺ż��
    CheckAcct();
    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CSendPkg003::CheckValues"); 
    return 0;
}

INT32 CSendPkg003::CheckAcct()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "enter CSendPkg003::CheckAcct");
    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "exit CSendPkg003::CheckAcct"); 
    return 0;
}

INT32 CSendPkg003::CreateMsgBody()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter CSendPkg003::CreateNpcMsg");

    char sTemp[32 + 1] ={0};

    m_pkg003.m_szCurElementNo              = "001";
    strncpy(m_pkg003.stBizBody001.szTrxsType , m_cBpbdsndlist.m_pmttpprtry.c_str(), sizeof(m_pkg003.stBizBody001.szTrxsType)-1);
    strncpy(m_pkg003.stBizBody001.szOdfiCode , m_cBpbdsndlist.m_instgdrctpty.c_str(), sizeof(m_pkg003.stBizBody001.szOdfiCode)-1);
    strncpy(m_pkg003.stBizBody001.szRdfiCode , m_cBpbdsndlist.m_instddrctpty.c_str(), sizeof(m_pkg003.stBizBody001.szRdfiCode)-1);
    strncpy(m_pkg003.stBizBody001.szConsignDate , m_cBpbdsndlist.m_consigdate.c_str(), sizeof(m_pkg003.stBizBody001.szConsignDate)-1);
    strncpy(m_pkg003.stBizBody001.szTxssNo , m_szMsgSerial, sizeof(m_pkg003.stBizBody001.szTxssNo)-1);

    memset(sTemp, '\0', sizeof(sTemp));
    sprintf(sTemp,"%015.0f", m_cBpbdsndlist.m_amount*100);    
    strncpy(m_pkg003.stBizBody001.szAmount ,sTemp, sizeof(m_pkg003.stBizBody001.szAmount)-1);
    strncpy(m_pkg003.stBizBody001.szPayOpenAccBkCode , m_cBpbdsndlist.m_dbtrissr.c_str(), sizeof(m_pkg003.stBizBody001.szPayOpenAccBkCode)-1);
    strncpy(m_pkg003.stBizBody001.szPayerAcc , m_cBpbdsndlist.m_dbtracctid.c_str(), sizeof(m_pkg003.stBizBody001.szPayerAcc)-1);
    SetFieldAsGbk(m_cBpbdsndlist.m_dbtnm, m_pkg003.stBizBody001.szPayerName , sizeof(m_pkg003.stBizBody001.szPayerName)-1);
    SetFieldAsGbk(m_cBpbdsndlist.m_dbtaddr, m_pkg003.stBizBody001.szPayerAddr , sizeof(m_pkg003.stBizBody001.szPayerAddr)-1);
    strncpy(m_pkg003.stBizBody001.szRecOpenAccBkCode , m_cBpbdsndlist.m_cdtrissr.c_str(), sizeof(m_pkg003.stBizBody001.szRecOpenAccBkCode)-1);
    strncpy(m_pkg003.stBizBody001.szRecipientAcc , m_cBpbdsndlist.m_cdtracctid.c_str(), sizeof(m_pkg003.stBizBody001.szRecipientAcc)-1);
    SetFieldAsGbk(m_cBpbdsndlist.m_cdtrnm, m_pkg003.stBizBody001.szRecipientName , sizeof(m_pkg003.stBizBody001.szRecipientName)-1);
    SetFieldAsGbk(m_cBpbdsndlist.m_cdtaddr, m_pkg003.stBizBody001.szRecipientAddr, sizeof(m_pkg003.stBizBody001.szRecipientAddr)-1);
    strncpy(m_pkg003.stBizBody001.szTrxKind , m_cBpbdsndlist.m_purpprtry.c_str(), sizeof(m_pkg003.stBizBody001.szTrxKind)-1);
    strncpy(m_cBpbdsndlist.m_addtlinf, m_pkg003.stBizBody001.szPost , sizeof(m_pkg003.stBizBody001.szPost)-1);

    string strTemp;
    string strAppData;
    int iCount = 0;
    int iRet = GetTagCount(m_cBpbdsndlist.m_cstmrcdttrfaddtlinf, "72C:", iCount);
    if(RTN_SUCCESS == iRet)
    {
        if(iCount > 0)
        {
            for(int i = 1; i <= iCount; i++)
            {
                AddAppendData(strAppData, i);
            }    
        }        
    }

    char szBuff[128]                 = {0};
    itoa(szBuff, strAppData.length(), 0);
    strncpy(m_pkg003.stBizBody001.szAppLen ,szBuff,sizeof(m_pkg003.stBizBody001.szAppLen)-1);
    strncpy(m_pkg003.stBizBody001.szAppData, 
            strAppData.c_str(), sizeof(m_pkg003.stBizBody001.szAppData)-1);

    m_pkg003.AddBussiness();

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit CSendPkg003::CreateNpcMsg"); 

    return iRet;
}

