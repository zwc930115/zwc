/*
 * 	recvbeps415.cpp
 *	Description: ʵʱ����֪ͨ����beps.415.001.01������
 *  Created on: 2012-07-09
 *  Author: __wsh
 */

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbeps415.h"

using namespace ZFPT;

CRecvBeps415::CRecvBeps415()
{
}

CRecvBeps415::~CRecvBeps415()
{
}

//__wsh 2012-07-09 ҵ�������
INT32 CRecvBeps415::Work(LPCSTR szMsg)
{
	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Enter CRecvBeps415::Work");
	int iRet = 0;

	//����XML����
	UnPack(szMsg);

	//����ʵʱ����ʵ��������
	SetData();

	//��¼���ݿ�
	InsertData();

	UpdateBusState();

	//��ǩ
	CheckSign415();
	
	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Leave CRecvBeps415::Work");

	return iRet;
}
//__wsh 2012-07-09 ����XML����
int CRecvBeps415::UnPack(LPCSTR szMsg)
{
	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Enter CRecvBeps415::UnPack");
	int iRet = -1;

	if(NULL == szMsg || '\0' == szMsg[0]){
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "���ĳ���Ϊ��");
		PMTS_ThrowException(PRM_FAIL);
	}

	//��������
	iRet = m_cBeps415.ParseXml(szMsg);
	if (OPERACT_SUCCESS != iRet){
		Trace(L_ERROR,  __FILE__,  __LINE__,
				NULL, "���Ľ�������! iRet= %d", iRet);

		PMTS_ThrowException(__FILE__, __LINE__,
				OPT_PRS_MSG_FAIL, "���Ľ�������");
	}

	//��ȡ��������
	iRet = GetWorkDate(m_dbproc, m_sWorkDate,
			SYS_BEPS, m_cBeps415.InstdDrctPty.c_str());
	if(RTN_SUCCESS != iRet){
		Trace(L_ERROR,  __FILE__, __LINE__,
				NULL, "��ȡ��������ʧ�ܣ�");
		PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
	}
	m_strWorkDate = m_sWorkDate;

	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Leave CRecvBeps415::UnPack");

	return OPERACT_SUCCESS;
}

//__wsh 2012-07-09 ����ʵ��������
void CRecvBeps415::SetData(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Enter CRecvBeps415::SetData");

	m_cpc.m_workdate 	= m_strWorkDate;	 //��������
	m_cpc.m_msgtp 		= m_cBeps415.m_PMTSHeader.getMesgType(); //��������
	m_cpc.m_mesgid		= m_cBeps415.m_PMTSHeader.getMesgID();   //ͨ�ż���ʶ
	m_cpc.m_mesgrefid	= m_cBeps415.m_PMTSHeader.getMesgRefID();//ͨ�Ųο���
	m_cpc.m_msgid		= m_cBeps415.MsgId;	       //���ı�ʶ
	m_cpc.m_instgdrctpty= m_cBeps415.InstgDrctPty; //����ֱ�Ӳ�����
	m_cpc.m_instddrctpty= m_cBeps415.InstdDrctPty; //����ֱ�Ӳ�����
	m_cpc.m_procstate   = PR_HVBP_01; //����״̬�� ������

	//ԭ������Ϣ
	m_cpc.m_orimsgid = m_cBeps415.RealTmBizRvslNtfyOrgnlMsgId;
	m_cpc.m_oriinstgdrctpty = m_cBeps415.RealTmBizRvslNtfyOrgnlInstgPty;
	m_cpc.m_orimsgtp = m_cBeps415.RealTmBizRvslNtfyOrgnlMT;


	//������ҵ����Ϣ
	m_cpc.m_oricxlmsgid = m_cBeps415.RealTmBizRvslNtfyInfOrgnlMsgId;
	m_cpc.m_oricxlinstgdrctpty = m_cBeps415.RealTmBizRvslNtfyInfOrgnlInstgPty;
	m_cpc.m_oricxlmsgtp = m_cBeps415.RealTmBizRvslNtfyInfOrgnlMT;

	Trace(L_INFO, __FILE__, __LINE__,
						NULL, "Leave CRecvBeps415::SetData");
}

//__wsh 2012-07-09 ��¼���ݿ�
int CRecvBeps415::InsertData(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Enter CRecvBeps415::InsertData");
	int iRet = -1;

	SETCTX(m_cpc);
	iRet = m_cpc.insert();
	if(iRet != SQL_SUCCESS){
		char szErr[512] = {0};
		sprintf(szErr, "[bp_cstpmtcxl]���������iRet=%d cause=%s",
						iRet, m_cpc.GetSqlErr());

		Trace(L_ERROR, __FILE__, __LINE__, NULL, szErr);

		PMTS_ThrowException(DB_INSERT_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Leave CRecvBeps415::InsertData");

	return iRet;
}

int CRecvBeps415::UpdateBusState(void)
{
	Trace(L_INFO, __FILE__, __LINE__,NULL, "Enter CRecvBeps415::UpdateBusState");

	string sqlCl;
	string sqlList;
	int iRet;
	if ( "beps.123.001.01" == m_cpc.m_oricxlmsgtp)
	{
		GetSql("Bp_Bcoutrcvcl",sqlCl);		
		GetSql("Bp_Bcoutrecvlist",sqlList);
	}
	else if("beps.131.001.01" == m_cpc.m_oricxlmsgtp)
	{
		GetSql("Bp_Bdrcvcl",sqlCl);		
		GetSql("Bp_Bdrecvlist",sqlList);
	}
	else
	{}

	Trace(L_ERROR, __FILE__, __LINE__, NULL,"sqlCl=[%s]", sqlCl.c_str());
	Trace(L_ERROR, __FILE__, __LINE__, NULL,"sqlList=[%s]", sqlList.c_str());
	
	SETCTX(m_cpc);
	iRet = m_cpc.execsql(sqlCl);
	if (iRet != SQL_SUCCESS)
	{
		sprintf(m_szErrMsg,  "����ԭ����ҵ��ʧ��[%d][%s]", 
			iRet, m_cpc.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}

	iRet = m_cpc.execsql(sqlList);
	if (iRet != SQL_SUCCESS)
	{
		sprintf(m_szErrMsg,  "����ԭ��ϸҵ��ʧ��[%d][%s]", 
			iRet, m_cpc.GetSqlErr());
			
		Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
	}

	Trace(L_INFO, __FILE__, __LINE__,NULL, "Leave CRecvBeps415::UpdateBusState");

	return iRet;
}

void  CRecvBeps415::GetSql(const string strTableName,string &strSql)
{
	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Enter CRecvBeps415::UpdateBusState");

	
	char cSql[1024] = {0};
	sprintf(cSql,"UPDATE %s t SET"
                            " t.busistate = 'PR22', t.procstate = '18' "
//                            " t.finalstatedate = '%s' "
                            " WHERE t.MSGID = '%s' AND t.INSTGDRCTPTY = '%s'",
                            strTableName.c_str(),
//                            szIOSdate,
                            m_cpc.m_oricxlmsgid.c_str(),
                            m_cpc.m_oricxlinstgdrctpty.c_str());
	
	strSql = cSql;
	return;
}


//__wsh 2012-07-09 ��ǩ
void CRecvBeps415::CheckSign415()
{
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CRecvBeps415::CheckSign415");

	m_cBeps415.getOriSignStr();
	
	CheckSign(m_cBeps415.m_sSignBuff.c_str(),
						m_cBeps415.m_szDigitSign.c_str(),
						m_cBeps415.InstgDrctPty.c_str());
	
	
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CRecvBeps415::CheckSign415");
}

