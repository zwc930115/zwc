/********************************************************************
文件名：recvfromfe.cpp
创建人：zny
日  期：2009.07.07
修改人：zj
日  期：
描  述：后台业务来账处理主控
版  本：
Copyright (c) 2009  YLINK
********************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "exception.h"
#include "configparser.h"
#include "pubfunc.h"
#include "category.h"
#include "connectpool.h"
#include "hvps111.h"
#include "beps121.h"
#include "nets350.h"
#include "basicapi.h"
#include "cfg_obj.h"

CCategory g_LogObj;
CConnectPool *g_DBConnPool;
CCfgObj pCfgFile;

using namespace ZFPT;
#define MQ_ERR_MAX_TIMES 20

#define	TRANS_PARM		1
#define	STATUS_PARM		2


int getFileText(char *  sFileName,char * sMsg)
{
	
	char sBuff[1024] ;
	//循环读取数据并处理
	FILE *fp = NULL; 
	
	fp = fopen(sFileName, "r");
	
	if ( fp == NULL )
	{
		printf("打开文件出错\n");
		return -1;	
	}
	
	int rendlen = 0;
	int iTotalLen = 0;
	while ( 1 )
	{
		memset(sBuff, 0, sizeof(sBuff));
		fgets(sBuff, sizeof(sBuff), fp)	;
		
        rendlen = strlen(sBuff);
		if (rendlen == 0)
			break;
		strcpy(sMsg+iTotalLen ,sBuff);
		iTotalLen += rendlen;
		
	}
	return 0;
	
} 


int packBeps121()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter packRoopInRoop");
	beps121 obeps121;
	
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "");
	obeps121.m_PMTSHeader.setOrigSendDate("20110310");
	obeps121.m_PMTSHeader.setOrigSender("666666666666");
	obeps121.m_PMTSHeader.setOrigReceiver("888888888888");
	obeps121.m_PMTSHeader.setMesgType("beps.121.001.01");
	obeps121.m_PMTSHeader.setMesgID("66666666666600000001");
	obeps121.m_PMTSHeader.setMesgRefID("66666666666600000001");

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "");
	
	obeps121.MsgId                  =	"66666666666600000001";
	obeps121.CreDtTm                =	"2011-03-10T06:06:06";
	obeps121.InstgDrctPty           =	"666666666666";
	obeps121.InstdDrctPty           =	"888888888888";
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "");
	for(int i=0;i<3;i++)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "");
	
		for(int j=0;j<1;j++)
		{
			obeps121.AddNodeToSubcycle("TpCd","兑付国债银行大类");
			obeps121.AddNodeToSubcycle("CptlCd","本金代码");
			obeps121.AddNodeToSubcycle("CptlAmt","666.00");
			obeps121.AddNodeToSubcycle("CptlAmtCcy","CNY");
			obeps121.AddNodeToSubcycle("AcrlCd","利息代码");
			obeps121.AddNodeToSubcycle("AcrlAmt","888.00");
			obeps121.AddNodeToSubcycle("AcrlAmtCcy","CNY");
			obeps121.AddSubcycleToNode("NtlTrsrInfDtls");
		}
		
		obeps121.AddNodeToSubcycle("FslInf","兑付信息");
		obeps121.AddNodeToSubcycle("NtlTrsrInfNbOfTxs","6");
		
		
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "");
		obeps121.AddNodeToSubcycle("TxId","66666666666600000001");
		obeps121.AddNodeToSubcycle("CtgyPurpPrtry","00001");
		obeps121.AddNodeToSubcycle("CdtrNm","收款人A");
		obeps121.AddNodeToSubcycle("DbtrNm","fu款人A");
		
		obeps121.AddSubcycleToNode("CstmrCdtTrfInf");
	}
	int iRet = obeps121.CreateXml();
	if (iRet != 0)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "fail to CreateXml");
        return iRet;
	}
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, " m_sXMLBuff = [%s]",obeps121.m_sXMLBuff.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit packRoopInRoop");
	return 0;
}


int packHvps111()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter packRoopInRoop");
	hvps111 ohvps111;
	
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "");
	ohvps111.m_PMTSHeader.setOrigSendDate("20110310");
	ohvps111.m_PMTSHeader.setOrigSender("666666666666");
	ohvps111.m_PMTSHeader.setOrigReceiver("888888888888");
	ohvps111.m_PMTSHeader.setMesgType("beps.121.001.01");
	ohvps111.m_PMTSHeader.setMesgID("66666666666600000001");
	ohvps111.m_PMTSHeader.setMesgRefID("66666666666600000001");

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "");
	
	ohvps111.MsgId                  =	"66666666666600000001";
	ohvps111.Ustrd                  =	"33333";
	
	ohvps111.SetUstrd(0,"asddsa");
	ohvps111.SetUstrd(1,"fffffff");
	ohvps111.SetUstrd(2,"4455566");
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "");
	
	int iRet = ohvps111.CreateXml();
	if (iRet != 0)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "fail to CreateXml");
        return iRet;
	}
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, " m_sXMLBuff = [%s]",ohvps111.m_sXMLBuff.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit packRoopInRoop");
	return 0;
}


int packNets350()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "enter packRoopInRoop");
	nets350 onets350;
	
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "");
	onets350.m_PMTSHeader.setOrigSendDate("20110310");
	onets350.m_PMTSHeader.setOrigSender("666666666666");
	onets350.m_PMTSHeader.setOrigReceiver("888888888888");
	onets350.m_PMTSHeader.setMesgType("beps.121.001.01");
	onets350.m_PMTSHeader.setMesgID("66666666666600000001");
	onets350.m_PMTSHeader.setMesgRefID("66666666666600000001");

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "");
	
	onets350.MsgIdId                  =	"66666666666600000001";
	onets350.DmstAcctId                =	"123";
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "");
	
	int iRet = onets350.CreateXml();
	if (iRet != 0)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "fail to CreateXml");
        return iRet;
	}
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, " m_sXMLBuff = [%s]",onets350.m_sXMLBuff.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "exit packRoopInRoop");
	return 0;
}


int unPackBeps121Test()
{
	
	char sMsg[1024 * 10] = {0};
	char sCmt100[256] = {0};
	char sHvps111[256] = {0};
	char sHvps1112[256] = {0};
	char sPkg001[256] = {0};
	char sBeps121[256] = {0};

	strncpy(sCmt100,"/ncb/pmts/mqtest/file/hvps/cmt100.txt",sizeof(sCmt100)-1);
	strncpy(sHvps111,"/ncb/pmts/mqtest/file/hvps/hvps.111.001.01.xml",sizeof(sHvps111)-1);
	strncpy(sHvps1112,"/ncb/pmts/mqtest/file/hvps/hvps111",sizeof(sHvps1112)-1);
	strncpy(sPkg001,"/ncb/pmts/mqtest/file/beps/pkg001",sizeof(sPkg001)-1);
	strncpy(sBeps121,"/ncb/pmts/mqtest/file/beps/loopInloop121.xml",sizeof(sBeps121)-1);
    int iRet = getFileText(sBeps121,sMsg);
    if(0 != iRet)
    {
   		printf("读取报文失败[%d]\n",iRet);
   		return -1;
    }
	beps121 oBeps121;
    iRet =  oBeps121.ParseXml(sMsg);
	if(0 != iRet)
	{
   		printf("解析失败\n");
   		return -1;	
	}
	
	
	char sParentName[64 + 1] = {0};
	strncpy(sParentName,"CstmrCdtTrfInf",sizeof(sParentName)-1);
	
	char sChildName[64 + 1] = {0};
	strncpy(sChildName,"NtlTrsrInfDtls",sizeof(sChildName)-1);
	
   	printf("PKGGrpHdrNbOfTxs = [%s]\n",oBeps121.PKGGrpHdrNbOfTxs.c_str());
   	int iParentNum = atoi(oBeps121.PKGGrpHdrNbOfTxs.c_str());
   	
   	
   	printf("Ustrd[0] = [%s]\n",oBeps121.GetUstrd(0).c_str());//获取第1个Ustrd节点的值
   	printf("Ustrd[1] = [%s]\n",oBeps121.GetUstrd(1).c_str());//获取第2个Ustrd节点的值
   	printf("Ustrd[2] = [%s]\n",oBeps121.GetUstrd(2).c_str());
   	printf("Ustrd[3] = [%s]\n",oBeps121.GetUstrd(3).c_str());
   	
	printf("AddtlInf[0] = [%s]\n",oBeps121.GetAddtlInf(0).c_str());//获取第1个AddtlInf节点的值
   	printf("AddtlInf[1] = [%s]\n",oBeps121.GetAddtlInf(1).c_str());//获取第2个AddtlInf节点的值
   	printf("AddtlInf[2] = [%s]\n",oBeps121.GetAddtlInf(2).c_str());
   	printf("AddtlInf[3] = [%s]\n",oBeps121.GetAddtlInf(3).c_str());
   	
	string szValueTmp;
	for(int i=0;i<iParentNum;i++)
	{
   		printf("\n[---------------------------------------\n");
   		
   		printf("i = [%d]\n",i);
   		
		szValueTmp = oBeps121.GetValueFromCycle(sParentName,"TxId",i);//获取第i个CstmrCdtTrfInf循环体中TxId节点的值
   		printf("TxId = [%s]\n",szValueTmp.c_str());
   		
   		szValueTmp = oBeps121.GetValueFromCycle(sParentName,"NtlTrsrInfNbOfTxs",i);//获取第i个NtlTrsrInfNbOfTxs循环体中TxId节点的值
   		printf("NtlTrsrInfNbOfTxs = [%s]\n",szValueTmp.c_str());
   		
   		
   		szValueTmp = oBeps121.GetValueFromCycle(sParentName,"AddtlInf",i);
   		printf("AddtlInf = [%s]\n",szValueTmp.c_str());
   		
   		int iChildrenNum = atoi(szValueTmp.c_str());
   		printf("NtlTrsrInfNbOfTxs = [%d]\n",iChildrenNum);
   		for(int j=0;j<iChildrenNum;j++)
   		{
   			szValueTmp = oBeps121.GetValueFromLiLCycle(sParentName,i,sChildName,j,"CptlAmt");//获取第i个CstmrCdtTrfInf循环体中第j个循环体NtlTrsrInfDtls中的子节点CptlAmt的值
   			printf("CptlAmt = [%s]\n",szValueTmp.c_str());
   			szValueTmp = oBeps121.GetValueFromLiLCycle(sParentName,i,sChildName,j,"CptlAmtCcy");
   			printf("CptlAmtCcy = [%s]\n",szValueTmp.c_str());
   		}
   		
   		printf("\n---------------------------------------]\n");
	}
	return 0;
}

int packBeps121Test()
{

	beps121 obeps121;


	
	obeps121.m_PMTSHeader.setOrigSendDate("20110310");
	obeps121.m_PMTSHeader.setOrigSender("666666666666");
	obeps121.m_PMTSHeader.setOrigReceiver("888888888888");
	obeps121.m_PMTSHeader.setMesgType("beps.121.001.01");
	obeps121.m_PMTSHeader.setMesgID("66666666666600000001");
	obeps121.m_PMTSHeader.setMesgRefID("66666666666600000001");

	

	obeps121.MsgId                  =	"66666666666600000001";
	obeps121.CreDtTm                =	"2011-03-10T06:06:06";
	obeps121.InstgDrctPty           =	"666666666666";
	obeps121.InstdDrctPty           =	"888888888888";
	obeps121.PKGGrpHdrNbOfTxs       =	"3";
	
	obeps121.SetUstrd(0,"udtrd001");//给节点类型为15的第1个Ustrd([0..n])节点赋值
	obeps121.SetUstrd(1,"udtrd002");//给节点类型为15的第2个Ustrd([0..n])节点赋值
	obeps121.SetUstrd(2,"udtrd003");//给节点类型为15的第3个Ustrd([0..n])节点赋值
	obeps121.SetUstrd(3,"udtrd004");//给节点类型为15的第4个Ustrd([0..n])节点赋值
	
	
	obeps121.SetAddtlInf(0,"addtlinf001");//给节点类型为17的第1个AddtlInf([0..n])节点赋值
	obeps121.SetAddtlInf(1,"addtlinf002");//给节点类型为17的第2个AddtlInf([0..n])节点赋值
	obeps121.SetAddtlInf(2,"addtlinf003");//给节点类型为17的第3个AddtlInf([0..n])节点赋值
	obeps121.SetAddtlInf(3,"addtlinf004");//给节点类型为17的第4个AddtlInf([0..n])节点赋值
	
	
	
	
	obeps121.AddNodeToSubcycle("CptlCd","333");//将子节点CptlCd的值放到临时map中
	obeps121.AddNodeToSubcycle("CptlAmt","666.00");//将子节点CptlAmt的值放到临时map中
	obeps121.AddNodeToSubcycle("CptlAmtCcy","CNY");//将子属性CptlAmtCcy的值放到临时map中
	obeps121.AddSubcycleToNode("NtlTrsrInfDtls");//将临时map添加到节点NtlTrsrInfDtls的子节点list中，并清空临时map
	
	obeps121.AddNodeToSubcycle("CptlCd","363");//将子节点CptlCd的值放到临时map中
	obeps121.AddNodeToSubcycle("CptlAmt","636.00");//将子节点CptlAmt的值放到临时map中
	obeps121.AddNodeToSubcycle("CptlAmtCcy","USD");//将子属性CptlAmtCcy的值放到临时map中
	obeps121.AddSubcycleToNode("NtlTrsrInfDtls");//将临时map添加到节点NtlTrsrInfDtls的子节点list中，并清空临时map
	
	obeps121.AddNodeToSubcycle("NtlTrsrInfDtls","NtlTrsrInfDtls001",1);//将之前给循环节点NtlTrsrInfDtls(节点类型为16)的子节点list(以NtlTrsrInfDtls001作为key放到循环嵌循环map中)作为上级循环节点CstmrCdtTrfInf(节点类型为1)的一个子节点
	obeps121.AddNodeToSubcycle("FslInf","duifuxinxi1");//给循环节点的子节点FslInf赋值
	obeps121.AddNodeToSubcycle("NtlTrsrInfNbOfTxs","3");//同上
	obeps121.AddNodeToSubcycle("TxId","66666666666600000001");//同上
	obeps121.AddNodeToSubcycle("CtgyPurpPrtry","00001");//同上
	obeps121.AddNodeToSubcycle("CdtrNm","cdtr1");//同上
	obeps121.AddNodeToSubcycle("DbtrNm","dbtr1");//同上
	obeps121.AddNodeToSubcycle("AddtlInf","AddtlInfaaaaaaa");//同上

	obeps121.AddSubcycleToNode("CstmrCdtTrfInf");//将循环节点CstmrCdtTrfInf放到循环节点list中，以便组报文时获取
	
	
	
	obeps121.AddNodeToSubcycle("CptlCd","fff");
	obeps121.AddNodeToSubcycle("CptlAmt","777.00");
	obeps121.AddNodeToSubcycle("CptlAmtCcy","CNY");
	obeps121.AddSubcycleToNode("NtlTrsrInfDtls");
	
	obeps121.AddNodeToSubcycle("NtlTrsrInfDtls","NtlTrsrInfDtls002",1);
	obeps121.AddNodeToSubcycle("FslInf","duifuxinxi2");
	obeps121.AddNodeToSubcycle("NtlTrsrInfNbOfTxs","3");
	obeps121.AddNodeToSubcycle("TxId","66666666666600000002");
	obeps121.AddNodeToSubcycle("CtgyPurpPrtry","00002");
	obeps121.AddNodeToSubcycle("CdtrNm","cdtr2");
	obeps121.AddNodeToSubcycle("DbtrNm","dbtr2");
	obeps121.AddNodeToSubcycle("AddtlInf","AddtlInfbbbbbbb");

	obeps121.AddSubcycleToNode("CstmrCdtTrfInf");
	
	
	
	obeps121.AddNodeToSubcycle("CptlCd","aaaa");
	obeps121.AddNodeToSubcycle("CptlAmt","123.00");
	obeps121.AddNodeToSubcycle("CptlAmtCcy","HKD");
	obeps121.AddSubcycleToNode("NtlTrsrInfDtls");
	
	obeps121.AddNodeToSubcycle("CptlCd","bbbb");
	obeps121.AddNodeToSubcycle("CptlAmt","456.00");
	obeps121.AddNodeToSubcycle("CptlAmtCcy","USD");
	obeps121.AddSubcycleToNode("NtlTrsrInfDtls");
	
	obeps121.AddNodeToSubcycle("CptlCd","cccc");
	obeps121.AddNodeToSubcycle("CptlAmt","789.00");
	obeps121.AddNodeToSubcycle("CptlAmtCcy","GBP");
	obeps121.AddSubcycleToNode("NtlTrsrInfDtls");
	
	obeps121.AddNodeToSubcycle("NtlTrsrInfDtls","NtlTrsrInfDtls003",1);
	
	obeps121.AddNodeToSubcycle("FslInf","duifuxinxi3");
	obeps121.AddNodeToSubcycle("NtlTrsrInfNbOfTxs","3");
	obeps121.AddNodeToSubcycle("TxId","66666666666600000003");
	obeps121.AddNodeToSubcycle("CtgyPurpPrtry","00003");
	obeps121.AddNodeToSubcycle("CdtrNm","cdtr3");
	obeps121.AddNodeToSubcycle("DbtrNm","dbtr3");
	obeps121.AddNodeToSubcycle("AddtlInf","AddtlInfccccccc");

	obeps121.AddSubcycleToNode("CstmrCdtTrfInf");
	
	int iRet = obeps121.CreateXml();
	if (iRet != 0)
	{
        return iRet;
	}
	
	printf(" m_sXMLBuff = [%s]\n",obeps121.m_sXMLBuff.c_str());
	return 0;
}


int main(int argc, char **argv)
{
	
    char 		sErrDesc[1024] 		= {0};
    int			iRet				=	0;
    char        sDbUser[32]           = {0};   //数据库用户
    char        sDbPass[32]           = {0};   //数据库密码
    char        sDbSid[128]           = {0};   //数据库服务名
    int         iConnPoolMinSize      = 0;     //连接池中最小连接数
    int         iConnPoolMaxSize      = 0;     //连接池中最大连接数
    int         iNoConnWaitTime       = 0;     //取不到连接时等待时间
    int         iConnPoolSize         = 0;     //连接池中初始连接数
    int         iThreadPoolSize       = 0;     //线程池中线程数
    int         iThreadPoolTaskSize   = 0;     //线程池任务数
     //加载配置文件 
    CConfigParser& cCfg = CConfigParser::getInstance();
	try
	{
				
		cCfg.loadConfig("../cfg/pmts.xml");
    	
    	//初始化日志 
		//ZFPTLOG.setCfgInfo(cCfg.getOption("LOGPATH"), "parsertest", (LOG_LEVEL)atoi(cCfg.getOption("LOGLVL")));
        iRet = g_LogObj.initialize("../log", 
                5, 
                "xmltest",		    // application name
                R_NOSOCKET,	            // Listen the control port
                0,				        // availabel only if R_SOCKET
                9999,			        // Control manager port
                M_SYNC		            // output mode 1-M_SYNC 2-M_ASYNC
                );
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "初始化日志...");		
        
		iRet = pCfgFile.Init("../cfg/pmtsxml.cfg");  //配置文件路径
		if(iRet != 0)
		{
	    	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Failed to Init the node Config Object: ErrCode = %d, ErrInfo = %s", pCfgFile.GetLastErrCode(),pCfgFile.GetLastErrInfo());
			return iRet;
		}

		iConnPoolMinSize = atoi(cCfg.getOption("CONNPOOLMINSIZE"));
        iConnPoolMaxSize = atoi(cCfg.getOption("CONNPOOLMAXSIZE"));
        iNoConnWaitTime	 = atoi(cCfg.getOption("NOCONNWAITTIME"));
        iConnPoolSize    = atoi(cCfg.getOption("CONNPOOLSIZE"));

        strncpy(sDbUser,cCfg.getOption("DBUSER"), sizeof(sDbUser)-1);
        strncpy(sDbPass,cCfg.getOption("DBKEY") , sizeof(sDbPass)-1);
        strncpy(sDbSid,cCfg.getOption("DBNAME") , sizeof(sDbSid) -1);
		
       
        
	}catch(CException &e)
    {
    	sprintf(sErrDesc, "Catch a exception from [%s %d][%s]",e.file(),e.line(),e.what());
    	
        
    }
    /*
	char sMsg[1024 * 10] = {0};
	char sCmt100[256] = {0};
	char sHvps111[256] = {0};
	char sHvps1112[256] = {0};
	char sPkg001[256] = {0};
	char sBeps121[256] = {0};
	
	strncpy(sCmt100,"/ncb/pmts/mqtest/file/hvps/cmt100.txt",sizeof(sCmt100)-1);
	strncpy(sHvps111,"/ncb/pmts/mqtest/file/hvps/hvps.111.001.01.xml",sizeof(sHvps111)-1);
	strncpy(sHvps1112,"/ncb/pmts/mqtest/file/hvps/hvps111",sizeof(sHvps1112)-1);
	strncpy(sPkg001,"/ncb/pmts/mqtest/file/beps/pkg001",sizeof(sPkg001)-1);
	strncpy(sBeps121,"/ncb/pmts/mqtest/file/beps/beps.121.001.01.xml",sizeof(sBeps121)-1);
    iRet = getFileText(sBeps121,sMsg);
    if(0 != iRet)
    {
   		printf("读取报文失败[%d]\n",iRet);
   		return -1;
    }
    
    */
	//packBeps121();
	
	//packHvps111();
	
	packBeps121Test();
	
	unPackBeps121Test();
	
	setsid();  //退出前设置会话session组id,防止影响其子进程 
	
   	
	return RTN_SUCCESS;
}
	
