/******************************************************************** 
�ļ����� sendbeps396.cpp
�����ˣ� handongfeng
��  ��   �� 2011-03-07
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "sendbeps396.h"


CSendBeps396::CSendBeps396(const stuMsgHead& Smsg):CSendBepsBase(Smsg)
{

}

CSendBeps396::~CSendBeps396()
{
}

void CSendBeps396::SetDBKey()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CSendBeps396::SetDBKey...");

	m_Bpgettx.m_msgid = m_sMsgId; 
	m_Bpgettx.m_instgpty = m_sSendOrg; 
	m_Bpgettx.m_rsflag = "1";

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Bpgettx.m_msgid = %s", m_Bpgettx.m_msgid.c_str());
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_Bpgettx.m_instgpty = %s", m_Bpgettx.m_instgpty.c_str());
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CSendBeps396::SetDBKey...");        
}

int CSendBeps396::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "ENTER CSendBeps396::UpdateState");

    SETCTX(m_Bpgettx);
    SetDBKey();

    string strSQL;
	strSQL += "UPDATE bp_gettx t SET t.PROCTIME = sysdate, t.PROCSTATE = '";
    strSQL += PR_HVBP_08;
	strSQL += "', t.MESGID = '";
    strSQL += m_sMesgID;
	strSQL += "', t.MESGREFID = '";
	strSQL += m_sMsgRefId;
    strSQL += "' ";
    
    strSQL += "WHERE t.MSGID = '";
	strSQL += m_Bpgettx.m_msgid.c_str();
	strSQL += "' AND t.instgpty = '";
	strSQL += m_Bpgettx.m_instgpty.c_str();
	strSQL += "'";
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    int iRet = m_Bpgettx.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��, iRet=%d, %s", iRet, m_Bpgettx.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "LEAVE CSendBeps396::UpdateState");
    return iRet;
}

void CSendBeps396::SetTag2ND(int& iDepth, const string& QryStr, const string& Tag)
{
    string strTemp;
    strTemp = Tag + QryStr;
    m_beps396.SetTxRef(iDepth, strTemp.c_str());
    iDepth++;
}

void CSendBeps396::SetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "ENTER CSendBeps396::UpdateState");
    m_beps396.Id = m_Bpgettx.m_msgid; 
    int i = 0;
    SetTag2ND(i, m_Bpgettx.m_instgdrctpty, "/A00/" );
    SetTag2ND(i, m_Bpgettx.m_instgpty, "/A22/");
    SetTag2ND(i, m_Bpgettx.m_instddrctpty, "/A01/");
    SetTag2ND(i, m_Bpgettx.m_purpprtry, "/FA5/");
    SetTag2ND(i, m_Bpgettx.m_chrgid, "/K35/");
    SetTag2ND(i, m_Bpgettx.m_corprtnid, "/K37/");
    SetTag2ND(i, m_Bpgettx.m_cusflag, "/K36/");

    bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��������");
        PMTS_ThrowException(PRM_FAIL);
    }
    strcpy(m_sMesgID,m_sMsgRefId);

    // ���ļ�ͷ
    m_beps396.CreateXMlHeader("BEPS",                        \
                                m_Bpgettx.m_workdate.c_str(), \
                                m_Bpgettx.m_instgdrctpty.c_str(),\
                                m_Bpgettx.m_instddrctpty.c_str(),\
                                "beps.396.001.01",              \
                                m_sMsgRefId);
   
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "LEAVE CSendBeps396::UpdateState");
    return ;
}

INT32 CSendBeps396::doWorkSelf()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "ENTER CSendBeps396::doWorkSelf");
    
    /*��ҵ����л�ȡ����*/
    int iRet = 0;

    GetData();

    SetData();
    
    iRet = m_beps396.CreateXml();
    if(RTN_SUCCESS != iRet)        
    {            
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "iRet=%d", iRet);
        PMTS_ThrowException(OPT_CREAT_MSG_FAIL);
    }    
    
    /*�޸�״̬*/
    UpdateState();

    //û�м�ǩҪ��
    m_sMsgTxt = m_beps396.m_sXMLBuff.c_str();
    
    AddQueue();
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "LEAVE CSendBeps396::doWorkSelf"); 
    return 0;
}


int CSendBeps396::GetData()
{
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "ENTER CSendBeps396::GetData");
    
	SETCTX(m_Bpgettx);
	SetDBKey();
  	iRet = m_Bpgettx.findByPK();
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ����ʧ��,  iRet=%d, %s", iRet, m_Bpgettx.GetSqlErr());
        PMTS_ThrowException(DB_NOT_FOUND);
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__,m_sMsgId, "LEAVE CSendBeps396::GetData"); 
	return iRet;
}


