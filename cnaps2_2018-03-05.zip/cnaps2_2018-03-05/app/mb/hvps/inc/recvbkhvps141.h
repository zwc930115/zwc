#ifndef _RECVHVPS141_H_BK
#define _RECVHVPS141_H_BK

#include "recvbkhvpsbase.h"
#include "hvps141.h"
#include "hvtrofacrcvlist.h"


class CRecvBkHvps141 : public CRecvbkHvpsBase
{
	
public:
	CRecvBkHvps141();
	~CRecvBkHvps141();
	
	// ҵ����ں���
	INT32 Work(LPCSTR sMsg);
	
	// �������Ĵ�
	INT32 unPack(LPCSTR sMsg);
	
	// ʵ���ำֵ
	INT32 SetData(LPCSTR pchMsg);
	
	// �������ݿ�
	INT32 InsertData(void);
	
	// ��ǩ
	void  CheckSign141();
	
	int ChargeMB();
private:
	hvps141          m_cParser141;
	string           m_strSignSub;
	CHvtrofacrcvlist m_cHvtrofacrcvlist; 
};

#endif

