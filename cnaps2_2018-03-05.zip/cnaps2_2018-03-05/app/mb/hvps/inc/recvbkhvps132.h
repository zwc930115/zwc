/*******************************************************************************
           Copyright(C) 2017, Free software engineer and contributor
 *******************************************************************************
  Filename   : recvbkhvps132.h
  Author     : cqli[lichangqing1983@sina.com]
  Date       : 2017-04-26
  Description: 
  History    : 
*******************************************************************************/
#ifndef RECVBKHVPS132_H
#define RECVBKHVPS132_H

#include "recvbkhvpsbase.h"
#include "hvps132.h"
#include "hvtrofacrcvlist.h"

class CRecvBkHvps132 : public CRecvbkHvpsBase
{
public:
	CRecvBkHvps132();
	~CRecvBkHvps132();

	// ҵ����ں���
	INT32 Work(LPCSTR sMsg);

	// �������Ĵ�
	INT32 unPack(LPCSTR sMsg);

	// �������ݿ�
	INT32 UpdateOriData(void);

	// ��ǩ
	void CheckSign132();

private:
	std::string m_rspway;
	CHvtrofacrcvlist m_cHvtrofacrcvlist;
	hvps132 m_hvps132;
	char m_szErrMsg[1024];
};

#endif//RECVBKHVPS132_H
