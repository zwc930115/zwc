/******************************************************************** 
�ļ����� recvcmt328.h
�����ˣ� handongfeng
��  �ڣ� 2011-04-28
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 


#ifndef _RECVBKCMT328_H_
#define _RECVBKCMT328_H_

#include "recvbkccmsbase.h"
#include "cmt328.h"
#include "bpcstbdpcxlcl.h" 
#include "bpcstbdpcxllist.h" 
#include "bpbdrcvcl.h"
#include "bpbdrecvlist.h"

class CRecvBkCmt328 : public CRecvbkCcmsBase
{
	
public:
	CRecvBkCmt328();
	~CRecvBkCmt328();

	//ҵ����ں���
	INT32 Work(LPCSTR sMsg);

	//�������Ĵ�
	INT32 unPack(LPCSTR sMsg);
    
	//�������ݿ�
	INT32 InsertDb(LPCSTR pchMsg);

    void GetOrgnBuss();

    void UpdateState();

    void UpdateDB();
    
private:
    CBpcstbdpcxlcl	m_cBpcstbdpcxlcl;    
    CBpcstbdpcxlcl	m_cOrgnBpcstbdpcxlcl;    
    CBpcstbdpcxllist	m_cBpcstbdpcxllist;
    CBpcstbdpcxllist	m_cOrgnBpcstbdpcxllist;
    char           m_sOldMsgId[35 + 1];
	char           m_szProcState[2+1];
    cmt328	       m_cmt328;
    CBpbdrcvcl          m_cBpbdsndcl;    
    CBpbdrecvlist       m_cBpbdsendlist;    
};

#endif


