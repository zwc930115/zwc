/******************************************************************** 
�ļ����� recvccms368.cpp
�����ˣ� aps-lel
��  �ڣ� 2011-04-19
�޸��ˣ�
��  �ڣ�
��  ����
��  ����
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkccms368.h"

CRecvBkCcms368::CRecvBkCcms368()
{
	m_iMsgVer	=	2;
	m_strMsgTp	=	"ccms.368.001.01";
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms368::CRecvBkCcms368()...");	
}


CRecvBkCcms368::~CRecvBkCcms368()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms368::~CRecvBkCcms368()...");		
}

INT32 CRecvBkCcms368::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms368::Work()...");
  //do nothing
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms368::work()...");

	return RTN_SUCCESS;
}


INT32 CRecvBkCcms368::unPack(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms368::unPack...");	

 
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms368::unPack...");	

	return RTN_SUCCESS;
}

INT32 CRecvBkCcms368::SetData(LPCSTR pchMsg)
{    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms368::SetData...");	
    


	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms368::SetData...");	

	return RTN_SUCCESS;
}

INT32 CRecvBkCcms368::InsertData(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms368::InsertData...");


	return RTN_SUCCESS;
}

void CRecvBkCcms368::CheckSign368()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms368::CheckSign368...");
	

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms368::CheckSign368...");
}

void CRecvBkCcms368::ParserDetail()
{	

				Trace(L_INFO,  __FILE__,  __LINE__, NULL, "CRecvBkCcms368::ParserDetail Prtry=[%s]",m_cmpmtrtrlist.m_ctgypurp.c_str());	
	

}
