/******************************************************************** 
�ļ����� recvccms307.cpp
�����ˣ� lj
��  �ڣ� 2011-03-29
�޸��ˣ� 
��  �ڣ� 
��  ���� ҵ�������뱨��<ccms.307.001.02>
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkccms307.h"

using namespace ZFPT;

CRecvBkCcms307::CRecvBkCcms307()
{
    m_strMsgTp	  = "ccms.307.001.01";
    m_strSysCd    = "";
}


CRecvBkCcms307::~CRecvBkCcms307()
{
	
}

INT32 CRecvBkCcms307::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms307::Work()");	
	
	// ��������
	unPack(sMsg);
	
	// ����ҵ������Ϣ��CM_TRANSREPEAL
	InsertDb(sMsg);
	
	// ���·���״̬
	UpdateState();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms307::work()");
	
	return RTN_SUCCESS;
}

INT32 CRecvBkCcms307::unPack(LPCSTR sMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms307::unPack");	

    int iRet = RTN_FAIL;

    // �����Ƿ�Ϊ��
    if (NULL == sMsg || '\0' == sMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }

    // ��������
    iRet = m_ccms307.ParseXml(sMsg);
    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������,iRet[%d]", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");	
    }

    ZFPTLOG.SetLogInfo("307", m_ccms307.Id.c_str());
    
    // ���ı�ʶ�š�ϵͳ���
    m_strMsgID	  = m_ccms307.Id;
    m_strSysCd    = m_ccms307.m_PMTSHeader.getOrigSenderSID();
            
	int iSysID = (strstr(m_strSysCd.c_str(), "BEPS") != NULL) ? SYS_BEPS : SYS_HVPS;
	iRet = GetWorkDate(m_dbproc, m_sWorkDate, iSysID, m_ccms307.AssgnrMmbId.c_str());
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;      

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms307::unPack");	

    return RTN_SUCCESS;
}



INT32 CRecvBkCcms307::InsertDb(LPCSTR pchMsg)
{    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms307::InsertDb");	
	
	m_ccms307.AddtlInf                 =   m_ccms307.GetAddtlInf();
	
	// ��ֵ
	m_CmTrRepeal.m_sysid			      = m_strSysCd;                              //ϵͳ��ʶ��
	m_CmTrRepeal.m_msgid			      = m_ccms307.Id;                            //���ı�ʶ��
	m_CmTrRepeal.m_instgdrctpty	    = m_ccms307.AssgnrMmbId;	                 //�����������к�
	m_CmTrRepeal.m_instddrctpty     = m_ccms307.AssgneMmbId;                   //���ղ�������к�
	m_CmTrRepeal.m_msgtp			      = m_strMsgTp;                              //��������
	m_CmTrRepeal.m_wrkdate          = m_strWorkDate;                           //��������
	m_CmTrRepeal.m_consigndate      = m_strWorkDate;                           //ί������
	m_CmTrRepeal.m_orgnlmsgid       = m_ccms307.OrgnlMsgId;                    //ԭ���ı�ʶ��
	m_CmTrRepeal.m_orgnlmsgtp       = m_ccms307.OrgnlMsgNmId;                  //ԭ�������ʹ���
	m_CmTrRepeal.m_rmkinf           = m_ccms307.AddtlInf;                      //��ע
	m_CmTrRepeal.m_rspflag			    = "0";                                     //Ӧ���־:0-δ��Ӧ,1-�ѻ�Ӧ
	m_CmTrRepeal.m_npcmsg			      = "";                                      //NPC����
	m_CmTrRepeal.m_mbmsg			      = pchMsg;                                  //MB����
	m_CmTrRepeal.m_stsid            = "";                                      //��������״̬
	m_CmTrRepeal.m_procstate		    = PR_HVBP_95;                              //����״̬:95������
	m_CmTrRepeal.m_mesgid           = m_ccms307.m_PMTSHeader.getMesgID()   ;   //ͨ�ż���ʶ��      
  m_CmTrRepeal.m_mesgrefid        = m_ccms307.m_PMTSHeader.getMesgRefID();   //ͨ�ż��ο���    
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CmTrRepeal.m_sysid=%s",m_CmTrRepeal.m_sysid.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CmTrRepeal.m_msgid=%s",m_CmTrRepeal.m_msgid.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CmTrRepeal.m_instgdrctpty=%s",m_CmTrRepeal.m_instgdrctpty.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CmTrRepeal.m_instddrctpty=%s",m_CmTrRepeal.m_instddrctpty.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CmTrRepeal.m_msgtp=%s",m_CmTrRepeal.m_msgtp.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CmTrRepeal.m_wrkdate=%s",m_CmTrRepeal.m_wrkdate.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CmTrRepeal.m_consigndate=%s",m_CmTrRepeal.m_consigndate.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CmTrRepeal.m_orgnlmsgid=%s",m_CmTrRepeal.m_orgnlmsgid.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CmTrRepeal.m_orgnlmsgtp=%s",m_CmTrRepeal.m_orgnlmsgtp.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CmTrRepeal.m_rmkinf=%s",m_CmTrRepeal.m_rmkinf.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CmTrRepeal.m_rspflag=%s",m_CmTrRepeal.m_rspflag.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CmTrRepeal.m_npcmsg=%s",m_CmTrRepeal.m_npcmsg.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CmTrRepeal.m_mbmsg=%s",m_CmTrRepeal.m_mbmsg.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CmTrRepeal.m_stsid=%s",m_CmTrRepeal.m_stsid.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CmTrRepeal.m_procstate=%s",m_CmTrRepeal.m_procstate.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CmTrRepeal.m_mesgid=%s",m_CmTrRepeal.m_mesgid.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_CmTrRepeal.m_mesgrefid=%s",m_CmTrRepeal.m_mesgrefid.c_str());


	// ��������
	SETCTX(m_CmTrRepeal);

	// �������ݿ�
	int iRet = m_CmTrRepeal.insert();
	if (0 != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����CM_TRANSREPEAL��ʧ��[%d][%s]",
		    iRet, m_CmTrRepeal.GetSqlErr());
		PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "����CM_TRANSREPEAL��ʧ��");
	}
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms307::InsertDb");	

    return RTN_SUCCESS;
}

INT32 CRecvBkCcms307::UpdateState()
{
  Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkCcms307::UpdateState...");
  
     string strSQL;
  
     strSQL += "UPDATE CM_TRANSREPEAL t SET t.PROCSTATE = '";
     strSQL += PR_HVBP_08;
     strSQL += "', t.STATETIME = sysdate ";
  
     strSQL += " WHERE t.SYSID = '";
     strSQL += m_strSysCd;
     strSQL += "' AND t.MSGID = '";
     strSQL += m_ccms307.Id;
     strSQL += "' AND t.INSTGDRCTPTY = '";
     strSQL += m_ccms307.AssgnrMmbId;                  
     strSQL += "'";
     Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
  
     int iRet = m_CmTrRepeal.execsql(strSQL.c_str());
     if(RTN_SUCCESS != iRet)
     {
         Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "UpdateState error:[%d]", iRet);
         PMTS_ThrowException(DB_UPDATE_FAIL);
     }
     
     m_CmTrRepeal.commit();
  
     Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkCcms307::UpdateState...");
     return RTN_SUCCESS;
 }


  /******************************************************************************
  *  Function:   SendToCnaps
  *  Description:�����ķ��͵����ж���
  *  Input:  ��
  *  Output:     
  *  Return:     0   : �����ɹ�,
       ����: ����ʧ��
  *  Others:     ��
  *  Author:     
  *  Date:   2012-3-14
  *******************************************************************************/
  /*
  INT32 CRecvCcmsBase::SendToCnaps(LPCSTR sMsg)
  {
      Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvCcmsBase::SendToCnaps...");
      
     
      int iRet = m_cMQAgent.PutMsg(g_SendQueue, sMsg, strlen(sMsg), NULL, NULL);
      
    if(iRet != RTN_SUCCESS)
    {
      Trace(L_INFO,  __FILE__,  __LINE__, NULL, "��MQ������Ϣʧ�ܣ�");
      Trace(L_INFO,  __FILE__,  __LINE__, NULL, "��Ϣ����:sMsg = %s  length=%d", sMsg, strlen(sMsg));
      PMTS_ThrowException(OPT_MQ_ADD_FAIL);
    }
      Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvCcmsBase::SendToCnaps...");
      return iRet;
  }
*/

