/******************************************************************** 
�ļ����� recvccms319.cpp
�����ˣ� aps-lel
��  �ڣ� 2011-04-19	
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkccms319.h"

extern char		g_RecvTel[128];
CRecvBkCcms319::CRecvBkCcms319()
{
	m_iMsgVer	=	2;
	m_strMsgTp	=	"ccms.319.001.01";
	m_strOrigenlist = "";
	m_strRtnst = "";
	m_strRtntp = "";
    memset(m_szOldMsgNo,0,sizeof(m_szOldMsgNo));
		
}


CRecvBkCcms319::~CRecvBkCcms319()
{
		
}

INT32 CRecvBkCcms319::Work(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms319::Work()...");

	//1����������
	unPack(sMsg);
	
	//3����ѯԭҵ��
    QryOldTrade();
	
	//4����m_cmpmtrtrcl�ĳ�Ա��ֵ
	SetData(sMsg);
	
	//5��������
	InsertData();

    //6�����±�
    UpdateData();

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms319::work()...");

	return RTN_SUCCESS;
}


INT32 CRecvBkCcms319::unPack(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms319::unPack...");	

	int iRet = RTN_FAIL;

	//1�������Ƿ�Ϊ��
	if (NULL == sMsg || '\0' == sMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��! ");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��! ");
	}

	//3����������
	iRet = m_ccms319.ParseXml(sMsg);
	if (RTN_SUCCESS != iRet)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= %d", iRet);	
		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������! ");	
	}

	//������־�ļ����ı�ʶ��
	ZFPTLOG.SetLogInfo("319", m_ccms319.MsgId.c_str());

    //����д�����ļ�����
	m_strMsgID	=	m_ccms319.MsgId;

	
	//4����ȡ��������
	int nSysID = strstr(m_ccms319.m_PMTSHeader.getOrigReceiverSID(), "HVPS")
			!= NULL ? SYS_HVPS : SYS_BEPS;
	iRet = GetWorkDate(m_dbproc, m_sWorkDate, nSysID, g_SapBank);
		
    if(iRet != RTN_SUCCESS)
    {
         Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
         PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    
    m_strWorkDate = m_sWorkDate;      
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms319::unPack...");	

	return RTN_SUCCESS;
}


INT32 CRecvBkCcms319::SetData(LPCSTR pchMsg)
{    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms319::SetData...");	
    
    string strTemp;

	m_cmpmtrtrcl.m_wrkdate        = m_sWorkDate;//��������
	m_cmpmtrtrcl.m_consigndate    = m_ccms319.MsgId.substr(0, 8);//ί������
	m_cmpmtrtrcl.m_sysid          = m_ccms319.m_PMTSHeader.getOrigReceiverSID();	// ϵͳ��ʶ��
	m_cmpmtrtrcl.m_msgtp          = m_ccms319.m_PMTSHeader.getMesgType() ;
	m_cmpmtrtrcl.m_msgid          = m_ccms319.MsgId;
	m_cmpmtrtrcl.m_instgdrctpty   = m_ccms319.GrpHdrMmbId;//����ֱ�Ӳ��������
	m_cmpmtrtrcl.m_instgindrctpty = m_ccms319.GrpHdrId; //�����������к� 		 
	m_cmpmtrtrcl.m_instddrctpty   = m_ccms319.MmbId ;	//����ֱ�Ӳ��������
	m_cmpmtrtrcl.m_instdindrctpty = m_ccms319.Id;//���ղ�������к� 
	m_cmpmtrtrcl.m_rsflag         = "1";//������־ 1:��2:��
	m_cmpmtrtrcl.m_rspflag        = "1"; //��Ӧ״̬0δ��Ӧ1�ѻ�Ӧ
	m_cmpmtrtrcl.m_npcmsg         = pchMsg;	//NPC���� ��Ϊ��
	m_cmpmtrtrcl.m_mesgid         = m_ccms319.m_PMTSHeader.getMesgID()   ; //ͨ�ż���ʶ��
	m_cmpmtrtrcl.m_mesgrefid      = m_ccms319.m_PMTSHeader.getMesgRefID(); //ͨ�ż��ο���
	m_cmpmtrtrcl.m_procstate      = PR_HVBP_01;//����״̬ OPR_RECVND01 ��������
	//m_cmpmtrtrcl.m_statetime;	//��Ĭ��ֵ		 
	//m_cmpmtrtrcl.m_busistate;//ҵ��״̬��			 
	//m_cmpmtrtrcl.m_processcode;		 
	//m_cmpmtrtrcl.m_rjctinf; //ҵ��ܾ���Ϣ			 
	m_cmpmtrtrcl.m_orgninstgdrctpty = m_ccms319.Id;	//ԭ��������� 
	m_cmpmtrtrcl.m_orgnlmsgid       = m_ccms319.OrgnlMsgId ;//ԭ���ı�ʶ��
	m_cmpmtrtrcl.m_orgnlmsgnmid     = m_ccms319.OrgnlMsgNmId;//ԭ�������ʹ���


    int iCount = m_ccms319.m_pXMLProc.m_PMTSSpecilDataMap.size();
    for(int i = 0;i < iCount ;i++)
    {
        strTemp = m_ccms319.GetAddtlInf(i);
        
        if(NULL != strstr(strTemp.c_str(),"/F44/"))
        {
            GetTagVal(m_strRtntp, strTemp, "/F44/"); //�˻����� RP00�������˻�  RP01�������˻� 

        }
        else if(NULL != strstr(strTemp.c_str(),"/F45/"))
        {
            GetTagVal(m_strRtnst, strTemp, "/F45/"); //�˻�Ӧ��״̬ PR23����ʾ�������˻أ���PR09����ʾ�Ѿܾ��� 

        }
        else if(NULL != strstr(strTemp.c_str(),"/H01/"))
        {
            GetTagVal(m_cmpmtrtrcl.m_rtinfo, strTemp, "/H01/"); //����

        }
        else
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "δ֪����Ϣ:strTemp = [%s]",strTemp.c_str());
        }
    }

	m_cmpmtrtrcl.m_busistate    = m_strRtnst;

    //������ҵ���׼�����޸ģ����֧��ϵͳʹ�ñ�����ʱ���˻�������дΪ�����˻أ��˻�Ӧ��������д
    //by add zql 2012-6-11
    if(m_cmpmtrtrcl.m_sysid =="HVPS")
    {
    	m_cmpmtrtrcl.m_returntype = "RP00";    //���ʱ�����˻�
    	m_cmpmtrtrcl.m_retunstat = m_strRtnst; //
    }
    else
    {           		 
		m_cmpmtrtrcl.m_returntype = m_strRtntp;	
		//m_cmpmtrtrcl.m_printno;	//��ӡ����	
		m_cmpmtrtrcl.m_retunstat = m_strRtnst;	
	}
	
	if("PR23" == m_strRtnst)
	{
	    if(m_cmpmtrtrcl.m_sysid =="HVPS")
	    {
	        m_ProState = PR_HVBP_33;
	    }
	    else
	    {
	        m_ProState = PR_HVBP_32;
	    }
	}
	else if("PR09" == m_strRtnst)
	{
		m_ProState = PR_HVBP_24;
	}
	else
	{
	    m_ProState = PR_HVBP_31;
	}
	
	//-----------
	if("PR25" == m_strRtnst)	
	{
		ParserDetail();
	}


	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms319::SetData...");	

	return RTN_SUCCESS;
}

INT32 CRecvBkCcms319::InsertData(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms319::InsertData...");

	//1����������
	SETCTX(m_cmpmtrtrcl);

	//2���������ݿ�
	int iRet = m_cmpmtrtrcl.insert();
	
	if (0 != iRet)
	{
		sprintf(m_szErrMsg,"insert error,error code = [%d] error cause =[%s]",iRet,m_cmpmtrtrcl.GetSqlErr());
		Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
		//PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms319::InsertData...");

	return RTN_SUCCESS;
}

void CRecvBkCcms319::CheckSign319()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms319::CheckSign319...");
	
	m_ccms319.getOriSignStr();
	
	CheckSign(m_ccms319.m_sSignBuff.c_str(),
						m_ccms319.m_szDigitSign.c_str(),
						m_ccms319.GrpHdrMmbId.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms319::CheckSign319...");
}

void CRecvBkCcms319::ParserDetail()
{	

    string strWhere = "";
	
	int iSyclecount = m_ccms319.GetNodeCountByName("TxInfAndSts");
	
	for(int iDepths = 0;iDepths < iSyclecount; iDepths++ )
	{
		m_cmpmtrtrlist.m_msgid        = m_cmpmtrtrcl.m_msgid;

		m_cmpmtrtrlist.m_instgdrctpty = m_cmpmtrtrcl.m_instgdrctpty;
		
		m_cmpmtrtrlist.m_orgnlmsgid   = m_ccms319.GetValueFromCycle(
				"TxInfAndSts","OrgnlInstrId", iDepths);//ԭ���ı�ʶ��

		m_cmpmtrtrlist.m_orgnltxid    = m_ccms319.GetValueFromCycle(
				"TxInfAndSts","OrgnlTxId", iDepths);//ԭ��ϸ��ʶ��

		m_cmpmtrtrlist.m_orgninstgdrctpty   = m_ccms319.GetValueFromCycle(
				"TxInfAndSts","TxInfAndStsMmbId", iDepths);//ԭ����ֱ�Ӳ������

		m_cmpmtrtrlist.m_orgninstgindrctpty = m_ccms319.GetValueFromCycle(
				"TxInfAndSts","TxInfAndStsId",iDepths);//ԭ������������

		m_cmpmtrtrlist.m_orgninstddrctpty   = m_ccms319.GetValueFromCycle(
				"TxInfAndSts","ClrSysMmbIdMmbId", iDepths);//ԭ����ֱ�Ӳ��������
		
		m_cmpmtrtrlist.m_orgninstdindrctpty = m_ccms319.GetValueFromCycle(
				"TxInfAndSts","BrnchIdId", iDepths);//ԭ���ղ�������к�
		
		m_cmpmtrtrlist.m_ctgypurp           = m_ccms319.GetValueFromCycle(
				"TxInfAndSts","Prtry",iDepths);;//ԭҵ�����ͱ���
		
		m_cmpmtrtrlist.m_rsflag = "1";
		m_cmpmtrtrlist.m_busistate = "PR25";
		
	    SETCTX(m_cmpmtrtrlist);
		int iRet = m_cmpmtrtrlist.insert();		
		
		//m_cmpmtrtrlist.commit();
		
		m_ccms319.OrgnlInstrId     = m_cmpmtrtrlist.m_orgnlmsgid;
		m_ccms319.OrgnlTxId        = m_cmpmtrtrlist.m_orgnltxid;
		m_ccms319.TxInfAndStsMmbId = m_cmpmtrtrlist.m_orgninstgdrctpty;	
		m_ccms319.TxInfAndStsId    = m_cmpmtrtrlist.m_orgninstgindrctpty;
		m_ccms319.ClrSysMmbIdMmbId = m_cmpmtrtrlist.m_orgninstddrctpty;
		m_ccms319.BrnchIdId        = m_cmpmtrtrlist.m_orgninstdindrctpty;
		m_ccms319.Prtry            = m_cmpmtrtrlist.m_ctgypurp;

		m_ccms319.AddTxStr();
		
		if (0 != iRet)
		{
			sprintf(m_szErrMsg,"insert error,error code = [%d] error cause =[%s]",iRet,m_cmpmtrtrlist.GetSqlErr());
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, m_szErrMsg);
		}
	}

}

void CRecvBkCcms319::QryOldTrade()//��ѯԭҵ��
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms319::QryOldTrade()");
    
    m_Oricmpmtrtrcl.m_msgid = m_ccms319.OrgnlMsgId;
    m_Oricmpmtrtrcl.m_instgindrctpty = m_ccms319.Id;
    m_Oricmpmtrtrcl.m_sysid = m_ccms319.m_PMTSHeader.getOrigSenderSID();
    m_Oricmpmtrtrcl.m_rsflag = "2";
    
    SETCTX(m_Oricmpmtrtrcl);
    int iRet = m_Oricmpmtrtrcl.findByPK();   
 	if (OPERACT_SUCCESS != iRet)
	{
	    //��û�ҵ������������ڷ��� ����һ�Ρ�
	    m_Oricmpmtrtrcl.m_rsflag = "0";
	    
	    SETCTX(m_Oricmpmtrtrcl);
        iRet = m_Oricmpmtrtrcl.findByPK();
        
    if (iRet == SQLNOTFOUND)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL,"����ʱδ�ҵ�����");
    }    
    else if (OPERACT_SUCCESS != iRet && iRet != SQLNOTFOUND)
    {
    		sprintf(m_szErrMsg,"findByPK error ,error code = [%d],error cause = [%s]", iRet,m_Oricmpmtrtrcl.GetSqlErr());		
    		Trace(L_INFO,  __FILE__,  __LINE__,NULL, m_szErrMsg);		
    		PMTS_ThrowException(__FILE__, __LINE__, DB_FIND_BY_PK_FAIL, m_szErrMsg);
	    }
	} 
    memcpy(m_szOldMsgNo, m_Oricmpmtrtrcl.m_orgnlmsgnmid.c_str() + 5, 3);
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leave CRecvBkCcms319::QryOldTrade()");

}
void CRecvBkCcms319::UpdateData(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms319::UpdateData()");


    SETCTX(m_Oricmpmtrtrcl);
    int iRet = RTN_FAIL;
    	
    
    string strWhere = "";

    //����ԭ�����˻�ҵ����ܱ�
    strWhere = "MSGID = '";
    strWhere += m_Oricmpmtrtrcl.m_msgid+ "' and ";
    strWhere += "INSTGINDRCTPTY = '";
    strWhere += m_Oricmpmtrtrcl.m_instgindrctpty + "' and ";
    strWhere += "SYSID = '";
    strWhere += m_Oricmpmtrtrcl.m_sysid + "' and rsflag <> '1' ";
    
    
    UpdateOriTrade("CM_PMTRTRCL",m_ProState.c_str(),"PROCSTATE",strWhere.c_str(), 1);
    /*
    if("PR09" == m_strRtnst)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "�ܾ��˻أ�����Ҫ����ԭҵ��ֱ�ӷ���...");
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms319::UpdateData()");
        return;
    }
    
    
    //����ԭ�����˻�ҵ����ϸ��    
    //strWhere = "MSGID = '";
    //strWhere += m_Oricmpmtrtrcl.m_msgid + "' and ";
    //strWhere += "INSTGDRCTPTY = '";
    //strWhere += m_Oricmpmtrtrcl.m_instgdrctpty + "'";

    //UpdateOriTrade("CM_PMTRTRLIST",PR_HVBP_20,"PROCSTATE",strWhere.c_str());

    if( 0 == strcmp("111" ,m_szOldMsgNo) || 0 == strcmp("112" ,m_szOldMsgNo) )//���´��ҵ��
    {
        
        //���´�����˻����ϸ��        
        strWhere = "MSGID = '";
        strWhere += m_Oricmpmtrtrcl.m_orgnlmsgid + "' and ";
        strWhere += "INSTGINDRCTPTY = '";
        strWhere += m_Oricmpmtrtrcl.m_orgninstgdrctpty + "'";
        
        UpdateOriTrade("HV_SNDEXCHGLIST",m_ProState.c_str(),"PROCSTATE",strWhere.c_str());
        
    }
    else if( 0 == strcmp("141" ,m_szOldMsgNo) )
    {
        //���´�����˼�ʱת�˱�       
        strWhere = "MSGID = '";
        strWhere += m_Oricmpmtrtrcl.m_orgnlmsgid + "' and ";
        strWhere += "INSTGINDRCTPTY = '";
        strWhere += m_Oricmpmtrtrcl.m_orgninstgdrctpty + "'";
        
        UpdateOriTrade("HV_TROFACSNDLIST",m_ProState.c_str(),"PROCSTATE",strWhere.c_str());
    }
    else if( 0 == strcmp("121" ,m_szOldMsgNo) || 0 == strcmp("122" ,m_szOldMsgNo)||
             0 == strcmp("123" ,m_szOldMsgNo) || 0 == strcmp("125" ,m_szOldMsgNo))//����С�����ҵ��
    {
        
        //����С����ǻ��ܱ�    
        strWhere = "MSGID = '";
        strWhere += m_Oricmpmtrtrcl.m_orgnlmsgid + "' and ";
        strWhere += "INSTGINDRCTPTY = '";
        strWhere += m_Oricmpmtrtrcl.m_orgninstgdrctpty + "'";
        
        UpdateOriTrade("BP_BCOUTSNDCL",m_ProState.c_str(),"PROCSTATE",strWhere.c_str());
         
     
        if(0 == STRNCASECMP("RP00",m_strRtntp.c_str(),4))// �����˻�ֱ�Ӹ��ݱ��ı�ʶ��������
        {
            //����С�������ϸ��    
            strWhere = "MSGID = '";
            strWhere += m_Oricmpmtrtrcl.m_orgnlmsgid + "' and ";
            strWhere += "INSTGINDRCTPTY = '";
            strWhere += m_Oricmpmtrtrcl.m_orgninstgdrctpty + "'";

            UpdateOriTrade("BP_BCOUTSENDLIST",PR_HVBP_33,"PROCSTATE",strWhere.c_str());
  
        }
    }		
    else if( 0 == strcmp("127" ,m_szOldMsgNo) || 0 == strcmp("131" ,m_szOldMsgNo)||
             0 == strcmp("133" ,m_szOldMsgNo) )//����С����ҵ��
    {
        
        //����С���ǻ��ܱ�    
        strWhere = "MSGID = '";
        strWhere += m_Oricmpmtrtrcl.m_orgnlmsgid + "' and ";
        strWhere += "INSTGINDRCTPTY = '";
        strWhere += m_Oricmpmtrtrcl.m_orgninstgdrctpty + "'";
        
        UpdateOriTrade("BP_BDSNDCL",m_ProState.c_str(),"PROCSTATE",strWhere.c_str());
        
     
     
        if(0 == STRNCASECMP("RP00",m_strRtntp.c_str(),4))// �����˻�ֱ�Ӹ��ݱ��ı�ʶ��������
        {
            //����С������ϸ��    
            strWhere = "MSGID = '";
            strWhere += m_Oricmpmtrtrcl.m_orgnlmsgid + "' and ";
            strWhere += "INSTGINDRCTPTY = '";
            strWhere += m_Oricmpmtrtrcl.m_orgninstgdrctpty + "'";

            UpdateOriTrade("BP_BDSENDLIST",PR_HVBP_33,"PROCSTATE",strWhere.c_str());     
        }
    }		
    */
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms319::UpdateData()");


}
	
void CRecvBkCcms319::UpdateOriTrade(LPCSTR pTableNm , LPCSTR  pProcState ,LPCSTR pField,LPCSTR pWhere, int iFlag)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCcms319::UpdateOriTrade()");

    int iRet = RTN_FAIL;
    string strSql = "";
    
    strSql = "update ";
    strSql += pTableNm ;
    strSql += " set ";   
    
    //Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "m_cmpmtrtrcl.m_rtinfo = [%s]",m_cmpmtrtrcl.m_rtinfo.c_str());
    
    if(0 == iFlag)
    {
        strSql += pField;
        strSql += " = '";
        strSql += pProcState;
        strSql += "', STATETIME = sysdate, BUSISTATE = '";
        strSql += m_strRtnst;
        strSql += "'";
    }
    else
    {
        /*
        strSql +="',";
        strSql += "RJCTINF='";
        strSql += m_cmpmtrtrcl.m_rtinfo.c_str();      
        strSql += "', " 
        */
        strSql += "RSPFLAG = 1, retunstat = '";
        strSql += m_strRtnst;
        strSql += "', STATETIME = sysdate, BUSISTATE = '";
        strSql += m_strRtnst;		
        strSql += "'";
    }

    strSql += " where ";
    strSql += pWhere;
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSql = [%s]",strSql.c_str());
    
    SETCTX(m_cmpmtrtrlist);    
    iRet = m_cmpmtrtrlist.execsql(strSql);
    if (iRet == SQLNOTFOUND)
    {
        Trace(L_ERROR, __FILE__, __LINE__, NULL,"����ʱδ�ҵ�����[%s]", strSql.c_str());
    }
    else if (iRet != SQL_SUCCESS)
    {
        sprintf(m_szErrMsg,  "����ԭҵ��ʧ��[%d][%s]", 
            iRet,  m_cmpmtrtrlist.GetSqlErr());          
        Trace(L_ERROR, __FILE__, __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
    }
   
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCcms319::UpdateOriTrade()");

}
