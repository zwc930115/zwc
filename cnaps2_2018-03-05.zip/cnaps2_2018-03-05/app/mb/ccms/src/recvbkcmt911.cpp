/******************************************************************** 
�ļ����� recvcmt911.cpp
�����ˣ� hhc
��  �ڣ� 2012-04-24
�޸��ˣ� 
��  �ڣ� 
��  ���� С�����˴���
��  ���� 
Copyright (c) 2012  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkcmt911.h"
#include "bpbcoutsndcl.h"
#include "bpbdsndcl.h"
#include "bpcolltnchrgscl.h"
#include "bpbcoutsendlist.h"
#include "cmcnotsgninfbiz.h"
#include "cmtransinfoqry.h"
#include "cmpmtrtrcl.h"
#include "bpcstbdpcxlcl.h"
#include "syscbbabankcode.h"
#include "bpcfcaqry.h"
#include "bprealtmcstacctmg.h"
#include "cmfreeinfo.h"
#include <bepsErrFormater.hpp>

using namespace ZFPT;

CRecvBkCmt911::CRecvBkCmt911()
{
    m_strMsgTp = "CMT911";
    m_strMsgNo = "";
}

CRecvBkCmt911::~CRecvBkCmt911()
{

}

INT32 CRecvBkCmt911::Work(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt911::doWork()");

    // ��������
    unPack(pchMsg);
    
    // ֻ����������Ϊʧ�ܵ����
    if ( RTN_SUCCESS == TransProcSts() )
    {
	    // ����ԭҵ��
	    UpdateState();
		
	}
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt911::doWork()");

    return RTN_SUCCESS;
}

INT32 CRecvBkCmt911::unPack(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt911::unPack()");
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "receive msg = [%s]",pchMsg);
    // 1�������Ƿ�Ϊ��
    if (NULL == pchMsg || '\0' == pchMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, m_strBizCode.c_str(), "����Ϊ��");
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }
    
    int iRet = RTN_FAIL;
    
    // 3����������
    iRet = m_cCmt911.ParseCmt(pchMsg);

    if (RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "CRecvBkCmt911::Work(): ��������ʧ��");
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������!");
    }

    m_strMsgNo = m_cCmt911.sOldcmtdate;
    m_strMsgNo += m_cCmt911.sOldmssno;
    
    ZFPTLOG.SetLogInfo("1911", m_strMsgNo.c_str());
   
    // ��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
  
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");
        PMTS_ThrowException(OPT_GET_DATE_FAIL);
    }
    m_strWorkDate   =   m_sWorkDate;
     
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt911::unPack()");	
    
    return RTN_SUCCESS;
}

INT32 CRecvBkCmt911::TransProcSts()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt911::TransProcSts()");

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strProcSts = [%s]", m_cCmt911.sProcode);	
    
    if ( 0 == strncmp(m_cCmt911.sProcode+4,"0000",4))
    {       
        return RTN_FAIL;
    }
    else
    {
        m_strProcSts  = PR_HVBP_14;
        m_strBusistate = PROCESS_PR09;
    }
    /*
    else if ( 0 == strncmp(m_cCmt911.sProcode+4,"0001" ,4))
    {
        m_strProcSts  = PR_HVBP_09;
    }
    else if ( 0 == strncmp(m_cCmt911.sProcode+4,"0002" ,4))
    {
        m_strProcSts  = PR_HVBP_10;
    }
    else if ( 0 == strncmp(m_cCmt911.sProcode+4,"0003",4 ))
    {
        m_strProcSts  = PR_HVBP_11;
    }
    else if ( 0 == strncmp(m_cCmt911.sProcode+4,"0004",4 ))
    {
        m_strProcSts  = PR_HVBP_12;
    }
    else
    {
    	m_strProcSts  = PR_HVBP_12;
    }
    */
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt911::TransProcSts([%s])", m_strProcSts.c_str());
    
    return RTN_SUCCESS;
}	

void CRecvBkCmt911::UpdateState()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt911::UpdateState([%s])", m_cCmt911.sOldcmtno);

    int iNo = atoi(m_cCmt911.sOldcmtno);
    
    switch(iNo)
    {
        case 1:
        case 5:
        case 7:
        case 8:
        case 10:
        case 11:
        {
        	if ( 0 == strcmp(m_cCmt911.sDataflag, "1"))
        	{
            	UpdateStateBcout();
            }
            else
            {
    			UpdateStateBcoutList();
            }
            break;
        }
        case 2:
        case 3:
        case 4:
        case 6:
        case 9:
        {
        	if ( 0 == strcmp(m_cCmt911.sDataflag, "1"))
        	{
            	UpdateStateBd();
            }
            else
            {
    			UpdateStateBdList();
            }
            break;
        }
        case 12:
        {
        	if ( 0 == strcmp(m_cCmt911.sDataflag, "1"))
        	{
            	UpdateState012();
            }
            else
            {
    			UpdateState012List();
            }
            break;
        }
        case 13:
        {
        	if ( 0 == strcmp(m_cCmt911.sDataflag, "2"))
        	{
            	UpdateState013();
            }
			break;
        }
        case 301:
		{
			UpdateStateTransQry(301);
			break;
        }
        case 302:
        {
        	UpdateStateTransQry(302);
            break;
        }
		case 319:
		{
			UpdateStatePmtrtrcl(319);
			break;
		}
		case 320:
		{
			UpdateStatePmtrtrcl(320);
			break;
		}
		case 327:
		{
			UpdateStateCstBdpcxlcl(327);
			break;
		}
		case 328:
		{
			UpdateStateCstBdpcxlcl(328);
			break;
		}
		case 303:
		{
			UpdateCmFreeInfoState();
			break;
		}
        default:
        {
            Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "δ�ҵ���Ӧ���ĺ�[%d]", iNo);
            break;
        }
    }
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvBkCmt911::UpdateState()");
    return ;
}

void CRecvBkCmt911::UpdateStateBcout()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt911::UpdateStateBcout()");

    string	strSQL = "";
    string	strMsgNo = "";
	int		iRet  = RTN_FAIL;
	
	CBpbcoutsndcl cBpbcoutsndcl;
    
    strSQL += " MESGID = '";
    strSQL += m_cCmt911.sOldmssno;
	strSQL += "' AND t.CONSIGDATE = '";
	strSQL += m_cCmt911.sOldcmtdate;
	strSQL += "'";
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());

    SETCTX(cBpbcoutsndcl);
	iRet = cBpbcoutsndcl.find(strSQL);
	if (SQLNOTFOUND == iRet) 
    {
        sprintf(m_szErrMsg, "cBpbcoutsndcl.find():��ѯBP_BCOUTSNDCLδ�ҵ�����"); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
    }
	else if (SQL_SUCCESS != iRet) 
    {
        sprintf(m_szErrMsg, "cBpbcoutsndcl.find():��ѯBP_BCOUTSNDCL��¼��, [%d][%s]",
        		iRet, cBpbcoutsndcl.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
    }
    while(SQL_SUCCESS == iRet)
	{
		iRet = cBpbcoutsndcl.fetch();	
		if (SQLNOTFOUND == iRet) 
		{
			cBpbcoutsndcl.closeCursor();
			break;
		}
		else if (SQL_SUCCESS != iRet) 
		{
			sprintf(m_szErrMsg, "cBpbcoutsndcl.fetch():��ȡBP_BCOUTSNDCL��¼��, [%d][%s]",
					iRet, cBpbcoutsndcl.GetSqlErr()); 
			
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
		}
		
		strMsgNo = cBpbcoutsndcl.m_msgid;
	}
    cBpbcoutsndcl.closeCursor();
    SETCTX(m_entitybase);
    
	strSQL = "";
	strSQL += "UPDATE BP_BCOUTSNDCL t SET t.PROCSTATE = '" + m_strProcSts + "'";
    strSQL += ", t.STATETIME = sysdate";
		strSQL += ", t.BUSISTATE = 'PR09'";
    strSQL += ", t.PROCESSCODE = '";
    strSQL += m_cCmt911.sProcode;
    strSQL += "' WHERE t.MSGID = '";
	strSQL += strMsgNo.c_str();
	//strSQL += "' AND t.INSTGDRCTPTY = '";// ���������в�һ���Ƿ�����
	//strSQL += m_cCmt911.sOldsendbank;
	strSQL += "'";
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
            iRet, m_entitybase.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    strSQL = "";
	strSQL += "UPDATE BP_BCOUTSENDLIST t SET t.PROCSTATE = '" + m_strProcSts + "'";
    strSQL += ", t.STATETIME = sysdate";
    strSQL += ", t.BUSISTATE = 'PR09'";
    strSQL += ", t.PROCESSCODE = '";
    strSQL += m_cCmt911.sProcode;
    strSQL += "' WHERE t.MSGID = '";
	strSQL += strMsgNo.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_cCmt911.sOldsendbank;
	strSQL += "' AND t.CONSIGNDATE = '";
	strSQL += m_cCmt911.sOldcmtdate;
	strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
            iRet, m_entitybase.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvBkCmt911::UpdateStateBcout()");
}

void CRecvBkCmt911::UpdateStateBcoutList()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt911::UpdateStateBcoutList()");

	int		iRet  = RTN_FAIL;
    string  strSQL = "";
    
    char szFinalDate[32] = {0};
    chgToISODate(m_cCmt911.sOldcmtdate, szFinalDate);

    SETCTX(m_entitybase);
    
	strSQL += "UPDATE BP_BCOUTSENDLIST t SET t.PROCSTATE = '" + m_strProcSts + "'";
    strSQL += ", t.STATETIME = sysdate";
    strSQL += ", t.BUSISTATE = 'PR09'";
    strSQL += ", t.PROCESSCODE = '";
    strSQL += m_cCmt911.sProcode;
    strSQL += "' WHERE t.MSGID = '";
	strSQL += m_strMsgNo.c_str();
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_cCmt911.sOldsendbank;
	strSQL += "' AND t.CONSIGDATE = '";
	strSQL += m_cCmt911.sOldcmtdate;
	strSQL += "'";
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
            iRet, m_entitybase.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    strSQL = "UPDATE BP_BCOUTSNDCL t SET t.PROCSTATE = '" + m_strProcSts + "'";
	strSQL += ", t.STATETIME = sysdate";
	strSQL += ", t.BUSISTATE = 'PR09'";
	strSQL += ", t.PROCESSCODE = '";
	strSQL += m_cCmt911.sProcode;
	strSQL += "' WHERE t.MSGID = '";
	strSQL += m_strMsgNo.c_str();
	strSQL += "' AND t.INSTGDRCTPTY = '";
	strSQL += m_cCmt911.sOldsendbank;
	strSQL += "' AND t.CONSIGDATE = '";
	strSQL += m_cCmt911.sOldcmtdate;
	strSQL += "'";
	 Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
	iRet = m_entitybase.execsql(strSQL.c_str());
	if(RTN_SUCCESS != iRet)
	{
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]",
			iRet, m_entitybase.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvBkCmt911::UpdateStateBcoutList()");
}

void CRecvBkCmt911::UpdateStateBd()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt911::UpdateStateBd()");

    int		iRet  = RTN_FAIL;
    string  strSQL = "";
    string	strMsgNo = "";
	
	CBpbdsndcl cBpbdsndcl;
    
    strSQL += " MESGID = '";
    strSQL += m_cCmt911.sOldmssno;
	strSQL += "' AND t.CONSIGDATE = '";
	strSQL += m_cCmt911.sOldcmtdate;
	strSQL += "'";
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());

    SETCTX(cBpbdsndcl);
	iRet = cBpbdsndcl.find(strSQL);
	if (SQLNOTFOUND == iRet) 
    {
        sprintf(m_szErrMsg, "cBpbdsndcl.find():��ѯBP_BDSNDCLδ�ҵ�����"); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
    }
	else if (SQL_SUCCESS != iRet) 
    {
        sprintf(m_szErrMsg, "cBpbdsndcl.find():��ѯBP_BDSNDCL��¼��, [%d][%s]",
        		iRet, cBpbdsndcl.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
    }
    while(SQL_SUCCESS == iRet)
	{
		iRet = cBpbdsndcl.fetch();	
		if (SQLNOTFOUND == iRet) 
		{
			cBpbdsndcl.closeCursor();
			break;
		}
		else if (SQL_SUCCESS != iRet) 
		{
			sprintf(m_szErrMsg, "cBpbdsndcl.fetch():��ȡBP_BDSNDCL��¼��, [%d][%s]",
					iRet, cBpbdsndcl.GetSqlErr()); 
			
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
		}
		
		strMsgNo = cBpbdsndcl.m_msgid;
	}
    
    SETCTX(m_entitybase);
    
	strSQL += "UPDATE BP_BDSNDCL t SET t.STATETIME = '" + m_strProcSts + "'";
    strSQL += ", t.STATETIME = sysdate";
    strSQL += ", t.BUSISTATE = 'PR09'";
    strSQL += ", t.PROCESSCODE = '";
    strSQL += m_cCmt911.sProcode;
    strSQL += "' WHERE t.MSGID = '";
	strSQL += m_strMsgNo.c_str();
	strSQL += "' AND t.CDTRBRNCHID = '";
	strSQL += m_cCmt911.sOldsendbank;
	strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
            iRet, m_entitybase.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    strSQL = "";
	strSQL += "UPDATE BP_BDSENDLIST t SET t.STATETIME = '" + m_strProcSts + "'";
    strSQL += ", t.STATETIME = sysdate";
    strSQL += ", t.BUSISTATE = 'PR09'";
    strSQL += ", t.PROCESSCODE = '";
    strSQL += m_cCmt911.sProcode;
    strSQL += "' WHERE t.MSGID = '";
	strSQL += m_strMsgNo.c_str();
	strSQL += "' AND t.CDTRBRNCHID = '";
	strSQL += m_cCmt911.sOldsendbank;
	strSQL += "' AND t.CONSIGDATE = '";
	strSQL += m_cCmt911.sOldcmtdate;
	strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
            iRet, m_entitybase.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvBkCmt911::UpdateStateBd()");
}

void CRecvBkCmt911::UpdateStateBdList()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt911::UpdateStateBdList()");

    int		iRet  = RTN_FAIL;
    string  strSQL = "";
    
    SETCTX(m_entitybase);
    
	strSQL += "UPDATE BP_BDSENDLIST t SET t.PROCSTATE = '" + m_strProcSts + "'";
    strSQL += ", t.STATETIME = sysdate";
    strSQL += ", t.BUSISTATE = 'PR09'";
    strSQL += ", t.PROCESSCODE = '";
    strSQL += string(m_cCmt911.sProcode) + "' ";

    // ������Ϣ��ʽ��
    strSQL += ", t.RJCTINF = '" + CBpErrFmt::parse(m_cCmt911.sProcode) + "' ";

    strSQL += " WHERE t.MSGID = '";
	strSQL += m_strMsgNo.c_str();
	strSQL += "' AND t.CDTRBRNCHID = '";
	strSQL += m_cCmt911.sOldsendbank;
	strSQL += "' AND t.CONSIGDATE = '";
	strSQL += m_cCmt911.sOldcmtdate;
	strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
            iRet, m_entitybase.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvBkCmt911::UpdateStateBdList()");
}


void CRecvBkCmt911::UpdateState012()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt911::UpdateState012()");

   	int		iRet  = RTN_FAIL;
    string  strSQL = "";
    string	strMsgNo = "";
	
	CBpcolltnchrgscl cBpcolltnchrgscl;
    
    strSQL += " MESGID = '";
    strSQL += m_cCmt911.sOldmssno;
	strSQL += "' AND CONSIGDATE = '";
	strSQL += m_cCmt911.sOldcmtdate;
	strSQL += "'";
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());

    SETCTX(cBpcolltnchrgscl);
	iRet = cBpcolltnchrgscl.find(strSQL);
	if (SQLNOTFOUND == iRet) 
    {
        sprintf(m_szErrMsg, "cBpcolltnchrgscl.find():��ѯBP_COLLTNCHRGSCLδ�ҵ�����"); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
    }
	else if (SQL_SUCCESS != iRet) 
    {
        sprintf(m_szErrMsg, "cBpcolltnchrgscl.find():��ѯBP_COLLTNCHRGSCL��¼��, [%d][%s]",
        		iRet, cBpcolltnchrgscl.GetSqlErr()); 
		
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
    }
    while(SQL_SUCCESS == iRet)
	{
		iRet = cBpcolltnchrgscl.fetch();	
		if (SQLNOTFOUND == iRet) 
		{
			cBpcolltnchrgscl.closeCursor();
			break;
		}
		else if (SQL_SUCCESS != iRet) 
		{
			sprintf(m_szErrMsg, "cBpcolltnchrgscl.fetch():��ȡBP_COLLTNCHRGSCL��¼��, [%d][%s]",
					iRet, cBpcolltnchrgscl.GetSqlErr()); 
			
			Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
		}
		
		strMsgNo = cBpcolltnchrgscl.m_msgid;
	}
    
    SETCTX(m_entitybase);

    //��Ϊ012��ͬҵ�����ͷŲ�ͬ��������ʱ����ҵ�����ͣ���������ȫ�����£���������
	//���ո�ҵ����ܱ�
	strSQL += "UPDATE BP_COLLTNCHRGSCL t SET t.STATETIME = '" + m_strProcSts + "'";
	strSQL += ", t.BUSISTATE = 'PR09'";
    strSQL += ", t.STATETIME = sysdate";
    strSQL += ", t.PROCESSCODE = '";
    strSQL += m_cCmt911.sProcode;
    strSQL += "' WHERE t.MSGID = '";
	strSQL += strMsgNo.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_cCmt911.sOldsendbank;
	strSQL += "'";
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
            iRet, m_entitybase.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }

   
    strSQL = "";
    strSQL += "UPDATE BP_COLLTNCHRGSCL t SET t.PROCTIME = sysdate, t.PROCSTATE = '";   
    strSQL += m_strProcSts + "'";
    strSQL += ", t.BUSISTATE = 'PR09'";
    //strSQL += ", t.PROCESSCODE = '";//�ñ�û������ֶ�
    //strSQL += m_cCmt911.sProcode;
    strSQL += " WHERE t.MESGID = '";
    strSQL += m_cCmt911.sOldmssno;
	strSQL += "' AND t.SRCFLAG <> 2";
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_entitybase.execsql failed:[%d][%s]",iRet,m_entitybase.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "m_entitybase.execsql failed!");
    }    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvBkCmt911::UpdateState012()");
}


void CRecvBkCmt911::UpdateState012List()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt911::UpdateState012List()");

    int		iRet  = RTN_FAIL;
    string  strSQL = "";
    
    SETCTX(m_entitybase);

    //��Ϊ012��ͬҵ�����ͷŲ�ͬ��������ʱ����ҵ�����ͣ���������ȫ�����£���������
	//���ո�ҵ����ϸ��
/*	strSQL += "UPDATE BP_COLLTNCHRGSLIST t SET t.PROCSTATE = '" + m_strProcSts + "'";
    strSQL += ", t.STATETIME = sysdate";
    strSQL += ", t.PROCESSCODE = '";
    strSQL += m_cCmt911.sProcode;
    strSQL += "' WHERE t.MSGID = '";
	strSQL += m_strMsgNo.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_cCmt911.sOldsendbank;
	strSQL += "'";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
            iRet, m_entitybase.GetSqlErr());
        //PMTS_ThrowException(DB_UPDATE_FAIL);
    }
*/
    strSQL = "";
    strSQL += "UPDATE CM_CNOTSGNINFBIZ t SET t.PROCTIME = sysdate, t.PROCSTATE = '";   
    strSQL += m_strProcSts + "'";
    strSQL += ", t.BUSISTATE = 'PR09' ";
    strSQL += " WHERE t.MSGID = '";
	strSQL += m_strMsgNo.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_cCmt911.sOldsendbank;
	strSQL += "' AND t.SRCFLAG <> 2";
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_entitybase.execsql failed:[%d][%s]",iRet,m_entitybase.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "m_entitybase.execsql failed!");
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvBkCmt911::UpdateState012List()");
}


void CRecvBkCmt911::UpdateStateTransQry(int iMsgno)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt911::UpdateStateTransQry()");

    int		iRet  = RTN_FAIL;
    string  strSQL = "";
    
    //������ͷ���Ĺ���������Ϊ��̬����
    char szIOSdate[10 + 1] = {0};
    chgToISODate(m_cCmt911.GetHeadWorkDate(), szIOSdate);
    
    SETCTX(m_entitybase);

    strSQL = "";
    strSQL += "UPDATE CM_TRANSINFOQRY t SET t.STATETIME = sysdate, t.PROCSTATE = '";   
    strSQL += m_strProcSts + "'";
    strSQL += ", t.BUSISTATE = 'PR09' ";
    strSQL += ", t.PROCESSCODE = '";
    strSQL += m_cCmt911.sProcode;
    strSQL += "' WHERE t.MSGID = '";
	strSQL += m_strMsgNo.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_cCmt911.sOldsendbank;
	strSQL += "' AND t.CONSIGNDATE = '";
	strSQL += m_cCmt911.sOldcmtdate;
	strSQL += "' AND t.RSFLAG <> '2'";
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_entitybase.execsql failed:[%d][%s]",iRet,m_entitybase.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "m_entitybase.execsql failed!");
    }
    
    if(iMsgno == 302)
    {
        UpdateRspflag("CM_TRANSINFOQRY");
    }
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvBkCmt911::UpdateStateTransQry()");
}

void CRecvBkCmt911::UpdateStatePmtrtrcl(int iMsgno)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt911::UpdateStatePmtrtrcl()");

    int		iRet  = RTN_FAIL;
    string  strSQL = "";
    
    SETCTX(m_entitybase);

    strSQL = "";
    strSQL += "UPDATE CM_PMTRTRCL t SET t.STATETIME = sysdate, t.PROCSTATE = '";   
    strSQL += m_strProcSts + "'";
    strSQL += ", t.BUSISTATE = 'PR09' ";
    strSQL += ", t.PROCESSCODE = '";
    strSQL += m_cCmt911.sProcode;
    strSQL += "' WHERE t.MSGID = '";
	strSQL += m_strMsgNo.c_str();
	strSQL += "' AND t.INSTGINDRCTPTY = '";
	strSQL += m_cCmt911.sOldsendbank;
	strSQL += "' AND t.CONSIGNDATE = '";
	strSQL += m_cCmt911.sOldcmtdate;
	strSQL += "' AND t.RSFLAG <> 2";
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_entitybase.execsql failed:[%d][%s]",iRet,m_entitybase.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "m_entitybase.execsql failed!");
    }
    
    if(iMsgno == 320)
    {
        UpdateRspflag("CM_PMTRTRCL");
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvBkCmt911::UpdateStatePmtrtrcl()");
}

void CRecvBkCmt911::UpdateStateCstBdpcxlcl(int iMsgno)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt911::UpdateStateCstBdpcxlcl()");

    int		iRet  = RTN_FAIL;
    string  strSQL = "";
    
    SETCTX(m_entitybase);

    strSQL = "";
    strSQL += "UPDATE BP_CSTBDPCXLCL t SET t.STATETIME = sysdate, t.PROCSTATE = '";   
    strSQL += m_strProcSts + "'";
    strSQL += ", t.BUSISTATE = 'PR09' ";
    strSQL += ", t.PROCESSCODE = '";
    strSQL += m_cCmt911.sProcode;
    strSQL += "' WHERE t.MSGID = '";
	strSQL += m_strMsgNo.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_cCmt911.sOldsendbank;
	strSQL += "' AND t.CONSIGDATE = '";
	strSQL += m_cCmt911.sOldcmtdate;
	strSQL += "' AND t.RSFLAG <> '2' ";
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    iRet = m_entitybase.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "m_entitybase.execsql failed:[%d][%s]",iRet,m_entitybase.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_OPT_FAIL, "m_entitybase.execsql failed!");
    }
    
    if(iMsgno == 328)
    {
        UpdateRspflag("BP_CSTBDPCXLCL");
    }
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvBkCmt911::UpdateStateCstBdpcxlcl()");
}

/******************************************************************************
*  Function:   InsertComsendmb
*  Description:������ͨѶ��
*  Input:      ��
*  Output:     
*  Return:     0   : �����ɹ�,
               ����: ����ʧ��
*  Others:     ��
*  Author:     hhc
*  Date:       2012-04-24
*******************************************************************************/
void CRecvBkCmt911::InsertComsendmb(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt911::InsertComsendmb()");
	
	int    iRet = RTN_FAIL;
	string strRval = "";
    
    
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_cCmt911.sOldcmtno[%s]", m_cCmt911.sOldcmtno);
	
    if( 0 == strcmp("001", m_cCmt911.sOldcmtno) || 0 == strcmp("005", m_cCmt911.sOldcmtno)
     || 0 == strcmp("007", m_cCmt911.sOldcmtno) )
	{
		CBpbcoutsendlist cBpbcoutsendlist;
		
		string strSql = "";
		strSql = " MSGID = '";
		strSql += m_strMsgNo;
		strSql += "' and DBTRBRNCHID = '";
		strSql += m_cCmt911.sOldsendbank;
		strSql += "'";

		SETCTX(cBpbcoutsendlist);
			
		iRet = cBpbcoutsendlist.find(strSql);
		
		if(OPERACT_SUCCESS != iRet)
		{
			sprintf(m_szErrMsg, "cBpbcoutsendlist find fail:  [%d][%s]", 
				iRet, cBpbcoutsendlist.GetSqlErr());
			Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
	
		while(0 == cBpbcoutsendlist.fetch())
		{
			iRet = GetTagVal(strRval, cBpbcoutsendlist.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				Trace(L_INFO,  __FILE__,  __LINE__, NULL, "txid[%s]", cBpbcoutsendlist.m_txid.c_str());
				m_strMsgID = cBpbcoutsendlist.m_txid;
				//m_strReserve = cBpbcoutsendlist.m_reserve; //�����ڷ�911ʱ�����ڻ�ȡԭ��������
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cBpbcoutsendlist.m_mbmsgid.c_str(), 22);
        
			    //�жϼ�ֱ���������ֱ����������ͨѶ��
				DirectInter(cBpbcoutsendlist.m_cdtrbrnchid.c_str(), 
							cBpbcoutsendlist.m_dbtrbrnchid.c_str(), 
							cBpbcoutsendlist.m_instddrctpty.c_str(),  
							pchMsg, 
							"BEPS"); 
			}
			else if(-2 == iRet)
			{
				Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "ԭҵ�����ڷ���ϵͳ��Ϊ��,����ת��������");
				break;
			}
		}
		
		cBpbcoutsendlist.closeCursor();
	}
	else
	{
		int    iRet    = OPERACT_FAILED;
		string strRsflag = "";// �����˱�ʶ
		string strRval = "";
		string strWhere = "";
		
		CSyscbbabankcode cSyscbbabankcode;
		
		strWhere += "bankcode = '";
		strWhere += m_cCmt911.sOldsendbank;
		strWhere += "'";
	
		SETCTX(cSyscbbabankcode);
	
		iRet = cSyscbbabankcode.find(strWhere);
		if (SQL_SUCCESS != iRet) 
	    {
	        sprintf(m_szErrMsg, "cSyscbbabankcode.find():��ѯsys_cbbabankcode��¼��, [%d][%s]",
	        		iRet, cSyscbbabankcode.GetSqlErr()); 
			
	        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
	        PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
	    }
		
		while(SQL_SUCCESS == iRet)
		{
			iRet = cSyscbbabankcode.fetch();	
			if (SQLNOTFOUND == iRet) 
			{
				strRsflag = "0";// ���ڷ���
				cSyscbbabankcode.closeCursor();
				break;
			}
			else if (SQL_SUCCESS != iRet) 
			{
				sprintf(m_szErrMsg, "cSyscbbabankcode.fetch():��ȡsys_cbbabankcode��¼��, [%d][%s]",
						iRet, cSyscbbabankcode.GetSqlErr()); 
				
				Trace(L_ERROR,	__FILE__,  __LINE__, NULL, m_szErrMsg);
				PMTS_ThrowException(__FILE__, __LINE__, DB_GET_DATA_FAIL, m_szErrMsg);
			}
			
			strRsflag = "2";// ��������
		}
		
		cSyscbbabankcode.closeCursor();
		
		if( 0 == strcmp("012", m_cCmt911.sOldcmtno) )
		{
			CCmcnotsgninfbiz cCmcnotsgninfbiz;
			
			cCmcnotsgninfbiz.m_msgid    = m_strMsgNo;
			cCmcnotsgninfbiz.m_instgpty	= m_cCmt911.sOldsendbank;
			cCmcnotsgninfbiz.m_srcflag	= strRsflag;
			
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cCmcnotsgninfbiz.m_msgid    = [%s]", cCmcnotsgninfbiz.m_msgid.c_str());
		    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "cCmcnotsgninfbiz.m_instgpty = [%s]", cCmcnotsgninfbiz.m_instgpty.c_str());
		    
		    SETCTX(cCmcnotsgninfbiz);
			
			iRet = cCmcnotsgninfbiz.findByPK();
			if (SQLNOTFOUND == iRet) 
		    {
		        sprintf(m_szErrMsg, "cCmcnotsgninfbiz.find():��ѯCM_CNOTSGNINFBIZδ�ҵ�����,����Ϊ���ո�����,����Ҫת��������"); 
				
		        Trace(L_INFO,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		        
		        return;
		    }
			if(OPERACT_SUCCESS != iRet)
			{
				 sprintf(m_szErrMsg, "cCmcnotsgninfbiz findByPK fail:  [%d][%s]", 
					 iRet, cCmcnotsgninfbiz.GetSqlErr());
				 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
				 PMTS_ThrowException(DB_GET_DATA_FAIL);
			}
			
			iRet = GetTagVal(strRval, cCmcnotsgninfbiz.m_reserve, ":orimsgsys:");
			if(0 == iRet)
			{
				strcpy(m_szDisSys, strRval.c_str());
				strncpy(m_szOrgnlMbMsgId, cCmcnotsgninfbiz.m_mbmsgid.c_str(), 22);
			
				//�жϼ�ֱ���������ֱ����������ͨѶ��
			    DirectInter(cCmcnotsgninfbiz.m_instgpty.c_str(), 
			    			cCmcnotsgninfbiz.m_instddrctpty.c_str(), 
			    			cCmcnotsgninfbiz.m_instdpty.c_str(), 
			    			pchMsg, 
				    		cCmcnotsgninfbiz.m_syscd.c_str());
			}
			else if(-2 == iRet)
			{
				Trace(L_INFO,  __FILE__,	__LINE__, NULL, "ԭҵ�����ڷ���ϵͳ��Ϊ��,����ת��������");
			}
		}
		else if ( 0 == strcmp("301", m_cCmt911.sOldcmtno) || 
				  0 == strcmp("302", m_cCmt911.sOldcmtno))
		{
			CCmtransinfoqry cCmtransinfoqry;
			
			string strSql = "";
			strSql = " MSGID = '";
			strSql += m_strMsgNo;
			strSql += "' and RSFLAG = '";
			strSql += strRsflag;
			strSql += "' and INSTGINDRCTPTY = '";
			strSql += m_cCmt911.sOldsendbank;
			strSql += "'";
	
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql[%s]", strSql.c_str());
			
			SETCTX(cCmtransinfoqry);
				
			iRet = cCmtransinfoqry.find(strSql);
			if(OPERACT_SUCCESS != iRet)
			{
				 sprintf(m_szErrMsg, "cCmtransinfoqry find fail:  [%d][%s]", 
					 iRet, cCmtransinfoqry.GetSqlErr());
				 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, m_szErrMsg);
				 PMTS_ThrowException(DB_GET_DATA_FAIL);
			}
		
			while(0 == cCmtransinfoqry.fetch())
			{
				iRet = GetTagVal(strRval, cCmtransinfoqry.m_reserve, ":orimsgsys:");
				if(0 == iRet)
				{
					//m_strReserve = cCmtransinfoqry.m_reserve; //�����ڷ�911ʱ�����ڻ�ȡԭ��������
					m_strMsgID   = cCmtransinfoqry.m_msgid;
					strcpy(m_szDisSys, strRval.c_str());
					strncpy(m_szOrgnlMbMsgId, cCmtransinfoqry.m_mbmsgid.c_str(), 22);
			    
					//�жϼ�ֱ���������ֱ����������ͨѶ��
				    DirectInter(cCmtransinfoqry.m_instgindrctpty.c_str(),
				                cCmtransinfoqry.m_instdindrctpty.c_str(), 
				    			cCmtransinfoqry.m_instddrctpty.c_str(), 
				    			pchMsg, 
				    			cCmtransinfoqry.m_sysid.c_str());
				}
				else if(-2 == iRet)
				{
					Trace(L_INFO,  __FILE__,	__LINE__, NULL, "ԭҵ�����ڷ���ϵͳ��Ϊ��,����ת��������");
				}
			}
			
			cCmtransinfoqry.closeCursor();
		}
		else//����������ͨѶ��
		{
	        Trace(L_INFO, __FILE__, __LINE__, NULL, "������������[%s]", m_cCmt911.sOldcmtno);
		}
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkCmt911::InsertComsendmb()");
}
void CRecvBkCmt911::UpdateState013()
{
	
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt911::UpdateState013()");
	//���ո�ҵ����ϸ��
	CBpcfcaqry m_CBpcfcaqry;
    SETCTX(m_CBpcfcaqry);
	string strSQL="";
    strSQL = "UPDATE BP_CFCAQRY t SET t.STATETIME = sysdate, t.PROCSTATE = '24' ";   
    //strSQL = strSQL + m_cCmt911.sProcstate + "' ";
    strSQL += ", t.PROCESSCODE = '";
    strSQL = strSQL + m_cCmt911.sProcode + "' ";
    // ������Ϣ��ʽ��
    strSQL += ", t.RJCTINF = '" + CBpErrFmt::parse(m_cCmt911.sProcode) + "' ";

    strSQL += " WHERE t.MSGID = '";
	strSQL += m_strMsgNo.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_cCmt911.sOldsendbank;
    strSQL += "' ";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=[%s]",strSQL.c_str());
    int iRet = m_CBpcfcaqry.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
            iRet, m_entitybase.GetSqlErr());
        //PMTS_ThrowException(DB_UPDATE_FAIL);
    }
    CBprealtmcstacctmg m_CBprealtmcstacctmg;
    SETCTX(m_CBprealtmcstacctmg);
    strSQL = "";
    strSQL = "UPDATE BP_REALTMCSTACCTMG t SET t.PROCTIME = sysdate, t.PROCSTATE = '24' ";   
    //strSQL = strSQL + m_cCmt911.sProcstate + "' ";
    //strSQL += ", t.PROCESSCODE = '";
    //strSQL = strSQL + m_cCmt911.sProcode +"' ";
    // ������Ϣ��ʽ��
    strSQL += ", t.RJCTINF = '" + CBpErrFmt::parse(m_cCmt911.sProcode) + "' ";

    strSQL += " WHERE t.MSGID = '";
	strSQL += m_strMsgNo.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_cCmt911.sOldsendbank;
    strSQL += "' ";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=[%s]",strSQL.c_str());
    iRet = m_CBprealtmcstacctmg.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
            iRet, m_entitybase.GetSqlErr());
        //PMTS_ThrowException(DB_UPDATE_FAIL);
    }
    
    strSQL="";
    strSQL = "UPDATE BP_CHCKCDTFORLD t SET t.PROCTIME = sysdate, t.PROCSTATE = '24' ";   
    //strSQL = strSQL + m_cCmt911.sProcstate + "' ";
    //strSQL += ", t.PROCESSCODE = '";
    //strSQL = strSQL + m_cCmt911.sProcode + "' ";
    // ������Ϣ��ʽ��
    strSQL += ", t.RJCTINF = '" + CBpErrFmt::parse(m_cCmt911.sProcode) + "' ";

    strSQL += " WHERE t.MSGID = '";
	strSQL += m_strMsgNo.c_str();
	strSQL += "' AND t.INSTGPTY = '";
	strSQL += m_cCmt911.sOldsendbank;
    strSQL += "' ";
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=[%s]",strSQL.c_str());
    iRet = m_CBpcfcaqry.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateStateʧ��[%d][%s]", 
            iRet, m_entitybase.GetSqlErr());
        //PMTS_ThrowException(DB_UPDATE_FAIL);
    }
}


/******************************************************************************
*  Function:   UpdateRspflag
*  Description:�޸�ԭ���뱨��Ӧ��״̬
*  Input:      ��
*  Output:     
*  Return:     0   : �����ɹ�,
               ����: ����ʧ��
*  Others:     ADD
*  Author:     lj
*  Date:       2012-08-30
*******************************************************************************/
INT32 CRecvBkCmt911:: UpdateRspflag(LPCSTR TableName)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBkCmt911::UpdateRspflag()");
    
    if(strlen(TableName) == 0)
    {
        return RTN_FAIL; 
    }

    int    iCount = 0;
    
    if(0 == strcmp(TableName,"CM_TRANSINFOQRY"))
    {
    	CCmtransinfoqry cCmtransinfoqry;
        SETCTX(cCmtransinfoqry);
        iCount = 0;
        string strSql  = "";
        strSql += " MSGID = '";
        strSql += m_strMsgNo.c_str();
    	strSql += "' AND INSTGINDRCTPTY = '";
    	strSql += m_cCmt911.sOldsendbank;
    	strSql += "' AND CONSIGNDATE = '";
    	strSql += m_cCmt911.sOldcmtdate;
    	strSql += "' AND RSFLAG <> 2";
  	
    	int iRet = cCmtransinfoqry.find(strSql);
		if(OPERACT_SUCCESS != iRet)
		{
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "cCmtransinfoqry find fail:  [%d][%s]", 
				 iRet, cCmtransinfoqry.GetSqlErr());
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
		
		while(0 == cCmtransinfoqry.fetch())
		{
		    iCount++;
		    if(iCount>1)
		    {
		        Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "�ҵ���ֹ1�����ݼ�¼������[%s]��ͨ�ű�ʶ��[%s]",
		        TableName, m_strMsgNo.c_str());
		        PMTS_ThrowException("�ҵ���ֹ1�����ݼ�¼");
		    }
		    
		    if( "CMT302" == cCmtransinfoqry.m_msgtp )
		    {
		        strSql = "UPDATE ";
    		    strSql += TableName;
    		    strSql += " t SET t.RSPFLAG = '0'";
                strSql += " WHERE t.RSFLAG = '2' AND MSGTP = 'CMT301' AND t.MSGID = '";
            	strSql += cCmtransinfoqry.m_qorgnlmsgid;
            	strSql += "' AND t.INSTGINDRCTPTY = '";
            	strSql += cCmtransinfoqry.m_qorgnlinstgdrctpty;
            	strSql += "'";
            	
            	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=%s", strSql.c_str());
		    }
		}
		
		iRet = cCmtransinfoqry.execsql(strSql.c_str());
		cCmtransinfoqry.closeCursor();
		if(OPERACT_SUCCESS != iRet)
        {
            Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "cCmtransinfoqry execsql fail:  [%d][%s]", 
				 iRet, cCmtransinfoqry.GetSqlErr());
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
        }
		
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvBkCmt911::UpdateRspflag()");
		return RTN_SUCCESS;
    }
	else if(0 == strcmp(TableName,"CM_PMTRTRCL"))
	{
	    CCmpmtrtrcl  m_Cmpmtrtrcl;
		SETCTX(m_Cmpmtrtrcl);
        iCount = 0;
		
        string strSql  = "";
        strSql += " MSGID = '";
        strSql += m_strMsgNo.c_str();
    	strSql += "' AND INSTGINDRCTPTY = '";
    	strSql += m_cCmt911.sOldsendbank;
    	strSql += "' AND CONSIGNDATE = '";
    	strSql += m_cCmt911.sOldcmtdate;
    	strSql += "' AND RSFLAG <> 2";
    	
    	Trace(L_INFO,  __FILE__,	__LINE__, NULL, "strSql [%s]", strSql.c_str());
    	
    	int iRet = m_Cmpmtrtrcl.find(strSql);
    	if(OPERACT_SUCCESS != iRet)
		{
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "m_Cmpmtrtrcl find fail:  [%d][%s]", 
				 iRet, m_Cmpmtrtrcl.GetSqlErr());
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
		
		while(0 == m_Cmpmtrtrcl.fetch())
		{
		    iCount++;
		    if(iCount>1)
		    {
		        Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "�ҵ���ֹ1�����ݼ�¼������[%s]��ͨ�ű�ʶ��[%s]",
		        TableName, m_strMsgNo.c_str());
		        //PMTS_ThrowException("�ҵ���ֹ1�����ݼ�¼");
		    }
		    
		    if( "CMT320" == m_Cmpmtrtrcl.m_msgtp )
		    {
		        strSql = "UPDATE ";
    		    strSql += TableName;
    		    strSql += " t SET t.RSPFLAG = '0'";
                strSql += " WHERE t.RSFLAG = '2' AND MSGTP = 'CMT319' AND t.MSGID = '";
            	strSql += m_Cmpmtrtrcl.m_orgnlmsgid;
            	strSql += "' AND t.INSTGINDRCTPTY = '";
            	strSql += m_Cmpmtrtrcl.m_orgninstgdrctpty;
            	strSql += "'";
            	
            	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=%s", strSql.c_str());
		    }
		}
		
		if( "CMT320" == m_Cmpmtrtrcl.m_msgtp )
		{
		    Trace(L_INFO,  __FILE__,	__LINE__, NULL, "strSql [%s]", strSql.c_str());
		    
    		iRet = m_Cmpmtrtrcl.execsql(strSql.c_str());
    		m_Cmpmtrtrcl.closeCursor();
			if(OPERACT_SUCCESS != iRet)
	        {
	            Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "m_Cmpmtrtrcl execsql fail:  [%d][%s]", 
					 iRet, m_Cmpmtrtrcl.GetSqlErr());
				 PMTS_ThrowException(DB_GET_DATA_FAIL);
	        }
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvBkCmt911::UpdateRspflag()");
			return RTN_SUCCESS;
		}
		
	}
	else if(0 == strcmp(TableName,"BP_CSTBDPCXLCL"))
    {
    	CBpcstbdpcxlcl cBpcstbdpcxlcl;
		SETCTX(cBpcstbdpcxlcl);
        iCount = 0;
		
        string strSql  = "";
        strSql += " MSGID = '";
        strSql += m_strMsgNo.c_str();
    	strSql += "' AND INSTGINDRCTPTY = '";
    	strSql += m_cCmt911.sOldsendbank;
    	strSql += "' AND CONSIGNDATE = '";
    	strSql += m_cCmt911.sOldcmtdate;
    	strSql += "' AND RSFLAG <> 2";
    	
    	Trace(L_INFO,  __FILE__,	__LINE__, NULL, "strSql [%s]", strSql.c_str());
    	
    	int iRet = cBpcstbdpcxlcl.find(strSql);
    	if(OPERACT_SUCCESS != iRet)
		{
			 Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "cBpcstbdpcxlcl find fail:  [%d][%s]", 
				 iRet, cBpcstbdpcxlcl.GetSqlErr());
			 PMTS_ThrowException(DB_GET_DATA_FAIL);
		}
		
		while(0 == cBpcstbdpcxlcl.fetch())
		{
		    iCount++;
		    if(iCount>1)
		    {
		        Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "�ҵ���ֹ1�����ݼ�¼������[%s]��ͨ�ű�ʶ��[%s]",
		        TableName, m_strMsgNo.c_str());
		        //PMTS_ThrowException("�ҵ���ֹ1�����ݼ�¼");
		    }
		    
		    if( "CMT328" == cBpcstbdpcxlcl.m_msgtp )
		    {
		        strSql = "UPDATE ";
    		    strSql += TableName;
    		    strSql += " t SET t.RSPFLAG = '0'";
                strSql += " WHERE t.RSFLAG = '2' AND MSGTP = 'CMT327' AND t.MSGID = '";
            	strSql += cBpcstbdpcxlcl.m_osqlmsgid;
            	strSql += "' AND t.INSTGINDRCTPTY = '";
            	strSql += cBpcstbdpcxlcl.m_osqinstgpty;
            	strSql += "'";
            	
            	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSql=%s", strSql.c_str());
		    }
		}

		if(cBpcstbdpcxlcl.m_stoppmtsts == "" )
		{
			//UpdateOriState(); //���ﻹδʵ�� ���ֹ��״̬Ϊͬ��� ��Ҫ��ԭ����״̬�޸Ļ�ȥ��
		}
		
		if( "CMT328" == cBpcstbdpcxlcl.m_msgtp )
		{
		    Trace(L_INFO,  __FILE__,	__LINE__, NULL, "strSql [%s]", strSql.c_str());
		    
    		iRet = cBpcstbdpcxlcl.execsql(strSql.c_str());
    		cBpcstbdpcxlcl.closeCursor();
			if(OPERACT_SUCCESS != iRet)
	        {
	            Trace(L_ERROR,  __FILE__,	__LINE__, NULL, "cBpcstbdpcxlcl execsql fail:  [%d][%s]", 
					 iRet, cBpcstbdpcxlcl.GetSqlErr());
				 PMTS_ThrowException(DB_GET_DATA_FAIL);
	        }
			Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvBkCmt911::UpdateRspflag()");    
			return RTN_SUCCESS;
        //m_Cmtransqry.commit();
		}
	}
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaveing CRecvBkCmt911::UpdateRspflag()");
    return RTN_FAIL;
}

void CRecvBkCmt911::UpdateCmFreeInfoState(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Enter CRecvBkCmt911::UpdateCmFreeInfoState");

	string strSql = " update cm_freeinfo set processcode='";
	strSql += m_cCmt911.sProcode;
	strSql += "', procstate='";
	strSql += m_strProcSts;
	strSql += "', busistate='";
	strSql += m_strBusistate;
	strSql += "' where mesgid='";
	strSql += m_cCmt911.sOldmssno;
	strSql += "' and instgindrctpty='";
	strSql += m_cCmt911.sOldsendbank;
	strSql += "' ";

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strSql=[%s]", strSql.c_str());

	CCmfreeinfo cfi;
	SETCTX(cfi);

	if (cfi.execsql(strSql) != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[cm_freeinfo update error[%s]", cfi.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "Leave CRecvBkCmt911::UpdateCmFreeInfoState");
}
