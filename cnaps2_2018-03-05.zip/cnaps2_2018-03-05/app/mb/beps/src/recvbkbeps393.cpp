/*
 *  recvbeps393.h
 *  Description: 批量签约应答(beps.393.001.01)来报处理类
 *  Created on: 2012-06-26
 *  Author: __wsh
 */

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkbeps393.h"

CRecvBkBeps393::CRecvBkBeps393()
{
}

CRecvBkBeps393::~CRecvBkBeps393()
{
}

//__wsh 2012-06-27 业务处理入口
int CRecvBkBeps393::Work(const char* szMsg)
{
	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Enter CRecvBkBeps393::Work");

	int iRet = -1;

	//解析报文
	iRet = UnPack(szMsg);

	//查询原业务汇总信息
	QryOrgnBiz_cl();

	//新增汇总来账记录
	iRet = InsertData_cl();

	//插入明细来账记录并处理协议
	iRet = InsertData_list();
	
	//更新原业务状态
	iRet = UpdateOrgnBiz();


	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Leave CRecvBkBeps393::Work");

	return iRet;
}

//__wsh 2012-06-26 解析报文
int CRecvBkBeps393::UnPack(const char* szMsg)
{
	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Enter CRecvBkBeps393::UnPack");
	int iRet = -1;

	if(NULL == szMsg || '\0' == szMsg[0]){
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "报文长度为空");
		PMTS_ThrowException(PRM_FAIL);
	}

	//获取工作日期
	iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
	if(RTN_SUCCESS != iRet){
		Trace(L_ERROR,  __FILE__, __LINE__,
				NULL, "获取工作日期失败！");
		PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
	}
	m_strWorkDate = m_sWorkDate;

	//解析报文
	if (OPERACT_SUCCESS != m_cBeps393.ParseXml(szMsg)){
		Trace(L_ERROR,  __FILE__,  __LINE__,
				NULL, "报文解析出错! iRet= %d", iRet);

		PMTS_ThrowException(__FILE__, __LINE__,
				OPT_PRS_MSG_FAIL, "报文解析出错");
	}

	ZFPTLOG.SetLogInfo("393", m_cBeps393.MsgId.c_str());

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBkBeps393::UnPack");

	return OPERACT_SUCCESS;
}


//__wsh 2012-06-27 核签
void CRecvBkBeps393::CheckSign393()
{
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CheckSign393");

	m_cBeps393.getOriSignStr();

	CheckSign(
		m_cBeps393.m_sSignBuff.c_str(),
		m_cBeps393.m_szDigitSign.c_str(),
		m_cBeps393.InstgDrctPty.c_str());

	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Leave CheckSign393");
}

//__wsh 2012-05-25 设置汇总表入库数据
void CRecvBkBeps393::SetData_cl(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBkBeps393::SetData_cl");

	m_ccmcl.m_workdate 		= m_strWorkDate;	 //工作日期
	m_ccmcl.m_msgtp 		= m_cBeps393.m_PMTSHeader.getMesgType(); //报文类型
	m_ccmcl.m_mesgid		= m_cBeps393.m_PMTSHeader.getMesgID();   //通信级标识
	m_ccmcl.m_mesgrefid		= m_cBeps393.m_PMTSHeader.getMesgRefID();//通信参考号
	m_ccmcl.m_msgid			= m_cBeps393.MsgId;	         //报文标识
	m_ccmcl.m_instgdrctpty	= m_cBeps393.InstgDrctPty;   //发送直接参与行
	m_ccmcl.m_instgpty		= m_cBeps393.GrpHdrInstgPty; //发送参与行
	m_ccmcl.m_instddrctpty	= m_cBeps393.InstdDrctPty;   //接收直接参与行
	m_ccmcl.m_instdpty		= m_cBeps393.GrpHdrInstdPty; //接收参与行
	m_ccmcl.m_syscd			= m_cBeps393.SysCd;			 //系统号
	m_ccmcl.m_rmk			= m_cBeps393.Rmk;			 //备注
	m_ccmcl.m_srcflag		= "1";						 //往来报标识1:往报， 2：来报
	m_ccmcl.m_qryoroprtp	= m_orgnccmcl.m_qryoroprtp;	 //查询类型
	m_ccmcl.m_procstate		= PR_HVBP_08;				 //处理状态，已发送

	m_ccmcl.m_orgnlinstgpty		= m_orgnccmcl.m_instgdrctpty;		
	m_ccmcl.m_orgnlmsgid		= m_orgnccmcl.m_msgid;		
	m_ccmcl.m_orgnlmt		= m_orgnccmcl.m_msgtp;

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBkBeps393::SetData_cl");
}

//__wsh 2012-06-26 来账汇总记录入库
int CRecvBkBeps393::InsertData_cl(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBkBeps393::InsertData_cl");

	int iRet = -1;

	SETCTX(m_ccmcl);

	//设置汇总数据
	SetData_cl();

	//插入数据
	iRet = m_ccmcl.insert();

	if(SQL_SUCCESS != iRet){
		char szErr[512] = {0};
		sprintf(szErr,
			"插入签约汇总表失败  iRet=%d cause=%s",
			iRet, m_ccmcl.GetSqlErr());
		Trace(L_ERROR, __FILE__, __LINE__,
				NULL, "%s", szErr);

		PMTS_ThrowException(__FILE__,
				__LINE__, DB_INSERT_FAIL, szErr);
	}

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBkBeps393::InsertData_cl");

	return iRet;
}

//__wsh 2012-05-25 设置来账明细数据
void CRecvBkBeps393::SetData_list(int iCount)
{
	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Enter CRecvBkBeps393::SetData_list");
    //解析明细
    m_cBeps393.ParseDetail(iCount);

	m_ccmlist.m_agrmtnb   = m_cBeps393.AgrmtNb;//协议号
	m_ccmlist.m_dbtrnm    = m_cBeps393.DbtrNm; //付款人名称
	printf("m_ccmlist.m_dbtrnm[%s]\n", m_ccmlist.m_dbtrnm.c_str());
	m_ccmlist.m_dbtrid    = m_cBeps393.OthrId; //付款人账号
	printf("m_ccmlist.m_dbtrid[%s]\n", m_ccmlist.m_dbtrid.c_str());
	m_ccmlist.m_dbtrissr  = m_cBeps393.Issr;   //付款人开户行行号
	printf("m_ccmlist.m_dbtrissr[%s]\n", m_ccmlist.m_dbtrissr.c_str());
	m_ccmlist.m_cdtrnm    = m_cBeps393.CdtrNm; //收款人名称
	m_ccmlist.m_rspsnsts  = m_cBeps393.Sts;    //应答状态
	m_ccmlist.m_acctsts   = m_cBeps393.AcctSts;//付款人账户状态
    m_ccmlist.m_dbtrbrnchid  = m_orgnccmlist.m_dbtrbrnchid;
    printf("m_ccmlist.m_dbtrbrnchid[%s]\n", m_ccmlist.m_dbtrbrnchid.c_str());
	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Leave CRecvBkBeps393::SetData_list");
}

//__wsh 2012-05-25
INT32 CRecvBkBeps393::InsertData_list(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Enter CRecvBkBeps393::InsertData_list");
	int iRet = -1;

	SETCTX(m_ccmlist);
	SETCTX(m_orgnccmlist);
	SETCTX(m_ccm);

	//设置公共部份明细
	m_ccmlist.m_workdate 	 = m_strWorkDate; 	//工作日期
	m_ccmlist.m_msgid	     = m_cBeps393.MsgId;//报文标识
	m_ccmlist.m_instgdrctpty = m_cBeps393.InstgDrctPty; //发送参与者
	m_ccmlist.m_qryoroprtp 	 = m_orgnccmcl.m_qryoroprtp;//协议查询或调整标识
	m_ccmlist.m_srcflag		 = "1";       //往来账标识， 1：往账，2：来
	m_ccmlist.m_procstate	 = PR_HVBP_08;//处理状态

	//设置循环部份明细
	int iCount = atoi(m_cBeps393.AcctCnt.c_str());
	for(int i = 0; i < iCount; ++i){
		    //查询原请求明细
	  QryOrgnBiz_list();
		//设置数据
		SetData_list(i);
		//处理合同变更
		DealCstCtrct();
		//插入数据
		iRet = m_ccmlist.insert();
		if(SQL_SUCCESS != iRet){
			char szErr[512] = {0};
			sprintf(szErr, "插入批量签约明细失败 iRet=%d cause=%s",
					iRet, m_ccmlist.GetSqlErr());
			Trace(L_ERROR, __FILE__, __LINE__,
					    NULL, "%s", szErr);

			PMTS_ThrowException(DB_INSERT_FAIL);
		}// end if
	}// end for

	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Leave CRecvBkBeps393::InsertData_list");
	return iRet;
}

//__wsh 2012-06-27 处理客户合同, 新增入库， 撤消更改状态
int CRecvBkBeps393::DealCstCtrct(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBkBeps393::DealCstCtrct");

	int iRet = -1;

	//查询或调整标志为查询"QT00"或应答状态为"PR09"已拒绝时时不处理
	if(m_orgnccmcl.m_qryoroprtp == "QT00" ||
	   m_cBeps393.Sts == "PR09"){
		Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Leave CRecvBkBeps393::DealCstCtrct");
		return 0;
	}


	
	Trace(L_INFO, __FILE__, __LINE__,
			m_ccmcl.m_msgid.c_str(), "变更类型[%s]",
			m_orgnccmlist.m_chngtpcd.c_str());
	
	if(m_orgnccmlist.m_chngtpcd == "CC00"){
		//新增合同
		iRet = AddNewCstCtrct();
	}
	else if(m_orgnccmlist.m_chngtpcd == "CC02"){
		//撤消合同
		iRet = RecallCstCtrct();
	}
	else{
		//未知变更类型
		Trace(L_ERROR, __FILE__, __LINE__,
				m_ccmcl.m_msgid.c_str(), "未知变更类型[%s]",
				m_orgnccmlist.m_chngtpcd.c_str());
	}

	if(0 != iRet){
		Trace(L_ERROR, __FILE__, __LINE__, m_ccmcl.m_msgid.c_str(),
				"处理合同失败,iRet=[%d] cause=[%s]", iRet, m_ccm.GetSqlErr());
		PMTS_ThrowException(DB_OPT_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBkBeps393::DealCstCtrct");

	return iRet;
}

//__wsh 2012-06-27 新增合同
int CRecvBkBeps393::AddNewCstCtrct(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBkBeps393::AddNewCstCtrct");

	int iRet = -1;
	//设置数据
	m_ccm.m_agrmtnb      = m_cBeps393.AgrmtNb; //合同号
	m_ccm.m_ctrctagrmttp = m_orgnccmcl.m_ctrctagrmttp;//合同类型
	m_ccm.m_srcflag      = "1"; //往来标识
	m_ccm.m_dbtrnm       = m_cBeps393.DbtrNm; //付款人名称
	m_ccm.m_dbtrid       = m_cBeps393.OthrId; //付款人账号
	m_ccm.m_dbtrissr     = m_cBeps393.Issr;   //付款人开户行号
	char dbtrmmbid[20] = {0};
	if(m_orgnccmlist.m_dbtrmmbid.empty())
		{
			GetSapBank(m_dbproc, m_orgnccmlist.m_dbtrbrnchid.c_str(), dbtrmmbid);
			Trace(L_INFO, __FILE__, __LINE__,NULL, "dbtrmmbid[%s]", dbtrmmbid);
			m_ccm.m_dbtrmmbid    = dbtrmmbid;  //付款清算行号
		}
		else
			{
				m_ccm.m_dbtrmmbid    = m_orgnccmlist.m_dbtrmmbid;  //付款清算行号
			}
	
	m_ccm.m_dbtrbrnchid  = m_orgnccmlist.m_dbtrbrnchid;//付款行号
	m_ccm.m_cdtrnm       = m_cBeps393.CdtrNm; //收款人名称
	m_ccm.m_acctsts      = m_cBeps393.AcctSts;//付款人账户状态
	m_ccm.m_procstate    = "35"; //处理状态 35：已生效 36：已撤消
	//入库
	iRet = m_ccm.findByPK();
	if( 0!= iRet && 1403 != iRet)
	{
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[BP_CSTCTRCTMG]查询客户签约协议表出错 iRet=[%d] cause=[%s]",
				iRet, m_ccm.GetSqlErr());
		PMTS_ThrowException(DB_FIND_FAIL);	        
	}
	else if(1403 == iRet)
	{
    	iRet = m_ccm.insert();	     
	    if (0 != iRet)
	    {
        		Trace(L_ERROR, __FILE__, __LINE__, NULL,
        				"[BP_CSTCTRCTMG]insert客户签约协议表出错 iRet=[%d] cause=[%s]",
        				iRet, m_ccm.GetSqlErr());
        		PMTS_ThrowException(DB_FIND_FAIL);	 		            
	    }        	   
	}
	else{
	    iRet = m_ccm.updatestate();
	    if (0 != iRet)
	    {
        		Trace(L_ERROR, __FILE__, __LINE__, NULL,
        				"[BP_CSTCTRCTMG]update客户签约协议表出错 iRet=[%d] cause=[%s]",
        				iRet, m_ccm.GetSqlErr());
        		PMTS_ThrowException(DB_FIND_FAIL);	 		            
	    }    
	}
	
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBkBeps393::AddNewCstCtrct");

	return iRet;
}

//__wsh 2012-06-27 撤消全同
int CRecvBkBeps393::RecallCstCtrct(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBkBeps393::RecallCstCtrct");

	int iRet = -1;

	string strSql = "";
	strSql += "update bp_cstctrctmg set procstate='36', proctime=sysdate ";
	strSql += "where agrmtnb='";
	strSql += m_cBeps393.AgrmtNb;
	strSql += "' and dbtrnm='";
	strSql += m_cBeps393.DbtrNm;
	strSql += "' and dbtrid='";
	strSql += m_cBeps393.OthrId;
	strSql += "' and dbtrissr='";
	strSql += m_cBeps393.Issr;
	strSql += "' ";
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "__strSql=[%s]", strSql.c_str());
	iRet = m_ccm.execsql(strSql);

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBkBeps393::RecallCstCtrct");

	return iRet;
}

//__wsh 2012-06-27 查询原业务汇总记录
void CRecvBkBeps393::QryOrgnBiz_cl(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBkBeps393::QryOrgnBiz_cl");

	string strSql = "";
	strSql += " msgid='";
	strSql += m_cBeps393.OrgnlMsgId;
	strSql += "' and instgdrctpty='";
	strSql += m_cBeps393.OrgnlInstgPty;
	strSql += "' and msgtp='";
	strSql += m_cBeps393.OrgnlMT;
	strSql += "' and srcflag='2' ";
	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "__strSql=[%s]", strSql.c_str());

	SETCTX(m_orgnccmcl);
	int iRet = m_orgnccmcl.find(strSql);
	if(SQL_SUCCESS == iRet){
		iRet = m_orgnccmcl.fetch();
		m_orgnccmcl.closeCursor();
	}

	if(iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[bp_cstctrctmgcl]查询原业务汇总表出错 iRet=[%d] cause=[%s]",
				iRet, m_orgnccmcl.GetSqlErr());
		PMTS_ThrowException(DB_FIND_FAIL);
	}


	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBkBeps393::QryOrgnBiz_cl");

}

//__wsh 2012-06-27 查询原业务明细记录
void CRecvBkBeps393::QryOrgnBiz_list(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Enter CRecvBkBeps393::QryOrgnBiz_list");

	string strSql = "";
	strSql += " msgid='";
	strSql += m_cBeps393.OrgnlMsgId;
	strSql += "' and instgdrctpty='";
	strSql += m_cBeps393.OrgnlInstgPty;
	strSql += "' and agrmtnb='";
	strSql += m_cBeps393.AgrmtNb;
	strSql += "' and srcflag='2' ";
	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "__strSql=[%s]", strSql.c_str());

	int iRet = m_orgnccmlist.find(strSql);
	if(SQL_SUCCESS == iRet){
		iRet = m_orgnccmlist.fetch();
		m_orgnccmlist.closeCursor();
	}
printf("原业务m_orgnccmlist.m_dbtrbrnchid[%s]\n", m_orgnccmlist.m_dbtrbrnchid.c_str());
	if(iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[bp_cstctrctmglist]查询原业务明细表出错 iRet=[%d] cause=[%s]",
				iRet, m_orgnccmlist.GetSqlErr());
		PMTS_ThrowException(DB_FIND_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBkBeps393::QryOrgnBiz_list");

}

//__wsh 2012-06-05 更新原业务状态
int CRecvBkBeps393::UpdateOrgnBiz(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__,
				NULL, "Enter CRecvBkBeps393::UpdateOrgnBiz");
	int iRet = -1;

	string strSql = "update bp_cstctrctmgcl set procstate='";
	strSql += PR_HVBP_07;
	strSql += "',  statetime=sysdate where msgid='";
	strSql += m_cBeps393.OrgnlMsgId;
	strSql += "' and instgdrctpty='";
	strSql += m_cBeps393.OrgnlInstgPty;
	strSql += "' and msgtp='";
	strSql += m_cBeps393.OrgnlMT;
	strSql += "' and srcflag='2' ";

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "__strSql=%s", strSql.c_str());

	iRet = m_orgnccmcl.execsql(strSql.c_str());
	if(iRet != SQL_SUCCESS){
		char szErr[512] = {0};
		sprintf(szErr, "[bp_cstctrctmglist]更新批量账户查询汇总 表失败 iRet=%d cause=%s",
				iRet, m_orgnccmcl.GetSqlErr());
		Trace(L_ERROR, __FILE__, __LINE__,
				NULL, "%s", szErr);

		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	Trace(L_INFO,  __FILE__,  __LINE__,
			NULL, "Leave CRecvBkBeps393::UpdateOrgnBiz");

	return iRet;
}
