/******************************************************************** 
文件名： recvbkbeps387.cpp
创建人： handongfeng
日  期： 2011-02-23
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif
#include "recvbkbeps387.h"

CRecvBkbeps387::CRecvBkbeps387()
{
    m_colltnchrgscl.m_msgtp = "beps.387.001.01";
    m_colltnchrgslist.m_msgtp = "beps.387.001.01";

}

CRecvBkbeps387::~CRecvBkbeps387()
{

}

int CRecvBkbeps387::Work(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps387::Work()...");

    // 解析报文
    unPack(szMsg);

    // 插入数据
    InsertData();

    //UpdataOriState();

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps387::Work()...");

    return OPERACT_SUCCESS;
}

INT32 CRecvBkbeps387::unPack(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps387::unPack()...");

    int iRet = -1;

    // 报文是否为空
    if (NULL == szMsg || '\0' == szMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");	
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "报文为空");
    }

    //获取工作日期
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");	
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;    

    // 解析报文
    if (OPERACT_SUCCESS != m_beps387.ParseXml(szMsg))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错! iRet= [%d]", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文解析出错!");
    }

    m_strMsgID = m_beps387.MsgId;

    ZFPTLOG.SetLogInfo("387", m_strMsgID.c_str());

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps387::unPack()...");

    return OPERACT_SUCCESS;
}

INT32 CRecvBkbeps387::InsertData()
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps387::InsertData()");

    m_colltnchrgscl.m_procstate = "01" ; 
    m_colltnchrgscl.m_workdate = m_strWorkDate ;   
    m_colltnchrgscl.m_consigdate = m_strWorkDate ; 
    m_colltnchrgscl.m_msgtp = "beps.387.001.01";
    m_colltnchrgscl.m_srcflag = '1' ; 

    m_colltnchrgscl.m_mesgid = m_beps387.m_PMTSHeader.getMesgID(); 
    m_colltnchrgscl.m_mesgrefid = m_beps387.m_PMTSHeader.getMesgRefID();
    m_colltnchrgscl.m_msgid = m_beps387.MsgId; 
    m_colltnchrgscl.m_instgdrctpty = m_beps387.InstgDrctPty; 
    m_colltnchrgscl.m_instgpty = m_beps387.GrpHdrInstgPty; 
    m_colltnchrgscl.m_instddrctpty = m_beps387.InstdDrctPty; 
    m_colltnchrgscl.m_instdpty = m_beps387.GrpHdrInstdPty; 
    m_colltnchrgscl.m_rmk = m_beps387.Rmk; 
    m_colltnchrgscl.m_syscd = m_beps387.SysCd;  
	m_colltnchrgscl.m_btchnb = m_beps387.OrgnlBtchNb;

    m_colltnchrgscl.m_orgnlmsgid = m_beps387.OrgnlMsgId;// 原报文标识号
    m_colltnchrgscl.m_orgnlinstgpty = m_beps387.OrgnlInstgPty;//原发起参与机构
    m_colltnchrgscl.m_orgnlbtchnb = m_beps387.OrgnlBtchNb;//原批次序号

    m_colltnchrgscl.m_npcprcsts = m_beps387.PrcSts;//NPC处理状态
    m_colltnchrgscl.m_npcprccd = m_beps387.PrcCd;//NPC处理码
    m_colltnchrgscl.m_npcrjctinf = m_beps387.NPCPrcInfRjctInf;//NPC拒绝信息
    m_colltnchrgscl.m_netgdt = m_beps387.NetgDt;//NPC轧差日期
    m_colltnchrgscl.m_netgrnd = m_beps387.NetgRnd;//NPC轧差场次
    m_colltnchrgscl.m_finalstatedate = m_beps387.SttlmDt;//NPC清算日期/终态日期

    //m_colltnchrgscl.m_rcvsndgttlamt = atof(m_beps387.Amt.c_str());//成功收款总金额
    m_colltnchrgscl.m_currency = m_beps387.Ccy;//成功收款总金额货币符号
    //m_colltnchrgscl.m_rcvsndgttlnb = 1;// 成功收款总笔数

    m_colltnchrgscl.m_dbtrmmbid = m_beps387.OrgnlInstgPty;//付款人户名
    m_colltnchrgscl.m_cdtrmmbid = m_beps387.OrgnlInstgPty;//付款人户名
    m_colltnchrgscl.m_checkstate = "01";//付款人户名

    m_colltnchrgscl.m_cdbtrid = m_beps387.DbtrAcctId;// 付款人账号
    m_colltnchrgscl.m_cdbtrnm = m_beps387.DbtrNm;//付款人名称
    m_colltnchrgscl.m_cdbtrbrnchid = m_beps387.DbtrAgtId;//付款行行号
    m_colltnchrgscl.m_procstate = "08";
    m_colltnchrgscl.m_ctgyprtry = m_beps387.CtgyPurpPrtry;//业务类型编码
    m_colltnchrgscl.m_ttlamt = atof(m_beps387.Amt.c_str());
    //m_colltnchrgscl.m_rspflag = "0";//回应标识

    SETCTX(m_colltnchrgscl);

    int iRet = m_colltnchrgscl.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__,  __LINE__, NULL, 
            "m_colltnchrgscl.insert() failed:error code =[%d],error cause =[%s]", iRet,m_colltnchrgscl.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "新增表失败");
    }

    SETCTX(m_colltnchrgslist);

	m_colltnchrgslist.m_workdate = m_strWorkDate;
    m_colltnchrgslist.m_consigdate = m_strWorkDate ; 
    m_colltnchrgslist.m_msgtp = "beps.387.001.01";
    m_colltnchrgslist.m_srcflag = '1' ; 
    m_colltnchrgslist.m_instgdrctpty = m_beps387.InstgDrctPty; 
    m_colltnchrgslist.m_instgpty = m_beps387.GrpHdrInstgPty; 
    m_colltnchrgslist.m_instddrctpty = m_beps387.InstdDrctPty; 
    m_colltnchrgslist.m_instdpty = m_beps387.GrpHdrInstdPty; 
	m_colltnchrgslist.m_syscd = "BEPS";
    m_colltnchrgslist.m_dbtrmmbid = m_beps387.OrgnlInstgPty;//付款人户名
    m_colltnchrgslist.m_cdtrmmbid = m_beps387.OrgnlInstgPty;//付款人户名
    m_colltnchrgslist.m_checkstate = "01";//付款人户名
	m_colltnchrgslist.m_ctgyprtry = m_beps387.CtgyPurpPrtry;
	m_colltnchrgslist.m_procstate = "08";
		
    m_colltnchrgslist.m_busistate = m_beps387.Sts;//业务状态
    //m_colltnchrgslist.m_rjctcd = m_beps387.RjctCd;//业务拒绝处理码
    m_colltnchrgslist.m_rjctinf = m_beps387.RspsnInfRjctInf;//业务拒绝信息
    m_colltnchrgslist.m_rjctprcpty = m_beps387.PrcPty;//业务处理参与机构
    m_colltnchrgslist.m_msgid = m_beps387.MsgId;//报文标识号        	
    m_colltnchrgslist.m_instgpty = m_beps387.GrpHdrInstgPty; 
    m_colltnchrgslist.m_txid = m_beps387.TxId;//明细标识号        
    m_colltnchrgslist.m_dbtrnm = m_beps387.DbtrNm           ;//付款人户名
    m_colltnchrgslist.m_dbtrid = m_beps387.DbtrAcctId           ;//付款人账号
    m_colltnchrgslist.m_dbtrbrnchid = m_beps387.DbtrAgtId           ;//付款行行号
    m_colltnchrgslist.m_cdtrbrnchid = m_beps387.CdtrAgtId           ;//收款行行号
    m_colltnchrgslist.m_cdtrnm = m_beps387.CdtrNm;//收款人名称
    m_colltnchrgslist.m_cdtrid = m_beps387.CdtrAcctId;//收款人账号
    m_colltnchrgslist.m_currency = m_beps387.Ccy;//货币符号
    m_colltnchrgslist.m_amout = atof(m_beps387.Amt.c_str());//金额  
    m_colltnchrgslist.m_puryprtry = m_beps387.PurpPrtry;  //业务种类编码        
    m_colltnchrgslist.m_srcflag = "1";
	m_colltnchrgslist.m_btchnb = m_beps387.OrgnlBtchNb;
    m_colltnchrgslist.m_amout = atof(m_beps387.Amt.c_str());

    SETCTX(m_colltnchrgslist);

    //明细表插入数据
    iRet = m_colltnchrgslist.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__,  __LINE__, NULL, 
            "m_colltnchrgslist.insert() failed:error code =[%d],error cause =[%s]", iRet,m_colltnchrgslist.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "新增表失败");
    }

    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps387::InsertData()");
    return iRet;
}

INT32 CRecvBkbeps387::UpdataOriState()
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps387::UpdataOriState()");

    //更新明细表
    string sql = "";

    sql  = "update COLLTNCHRGSLIST set procstate = '";
    sql += PR_HVBP_15;
    sql += "',purpstate = '";
    sql += m_beps387.PrcSts;
    sql += "',purprjctcd = '";
    sql += m_beps387.RjctCd;
    sql += "',purprjctinf = '";
    sql += m_beps387.RspsnInfRjctInf;
    sql += "',purpdealbank = '";
    sql += m_beps387.PrcPty;
    sql += "',npcprocstate = '";
    sql += m_beps387.PrcSts;
    sql += "',npcpoccode = '";
    sql += m_beps387.PrcCd;
    sql += "',netdate = '";
    sql += m_beps387.NetgDt;
    sql += "',netno = '";
    sql += m_beps387.NetgRnd;
    sql += "',sapdate = '";
    sql += m_beps387.SttlmDt;		
    sql += "', statetime = current timestamp";

    sql += "where purpmsgid = '";
    sql += m_beps387.OrgnlMsgId;
    sql +="' and sendbank = '";
    sql += m_beps387.OrgnlInstgPty;
    sql +="' and batchsn = '";
    sql += m_beps387.OrgnlBtchNb;
    sql +="' and msgid = '";
    sql += m_beps387.TxId;
    sql += "'";

    Trace(L_ERROR, __FILE__,  __LINE__, NULL,"sql=[%s]",sql.c_str());

    int m_iRet = m_colltnchrgslist.execsql(sql);
    if(OPERACT_SUCCESS != m_iRet)
    {
        Trace(L_ERROR, __FILE__,  __LINE__, NULL, 
            "execsql failed:error code =[%d],error cause =[%s]", m_iRet,m_colltnchrgslist.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "更新表失败");
    } 

    sql.empty();		


    //汇总表插入数据
    sql  = "update COLLTNCHRGSCL set procstate = '";
    sql += PR_HVBP_15;
    sql += "',purpstate = '";
    sql += m_beps387.PrcSts;
    sql += "',purprjctcd = '";
    sql += m_beps387.RjctCd;
    sql += "',purprjctinf = '";
    sql += m_beps387.RspsnInfRjctInf;
    sql += "',purpdealbank = '";
    sql += m_beps387.PrcPty;
    sql += "',npcprocstate = '";
    sql += m_beps387.PrcSts;
    sql += "',npcproccode = '";
    sql += m_beps387.PrcCd;
    sql += "',npcrjctinf = '";
    sql += m_beps387.NPCPrcInfRjctInf;
    sql += "',netdate = '";
    sql += m_beps387.NetgDt;
    sql += "',netno = '";
    sql += m_beps387.NetgRnd;
    sql += "',sapdate = '";
    sql += m_beps387.SttlmDt;
    sql += "',payeetotalamt = ";
    sql += m_beps387.Amt;
    sql += ",payeetotal = 1";
    sql += ",statetime = current timestamp";

    sql += "where msgid = '";
    sql += m_beps387.OrgnlMsgId;
    sql +="' and sendbank = '";
    sql += m_beps387.OrgnlInstgPty;
    sql +="' and batchsn = '";
    sql += m_beps387.OrgnlBtchNb;
    sql +="'";

    m_iRet = m_colltnchrgslist.execsql(sql);

    if(OPERACT_SUCCESS != m_iRet)
    {
        sprintf(m_szErrMsg,"insert() error,error code = [%d],error cause = [%s]",m_iRet,m_colltnchrgslist.GetSqlErr());

        Trace(L_INFO,  __FILE__,  __LINE__, NULL, m_szErrMsg);

        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL,m_szErrMsg);			
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps387::UpdataOriState()");

    return OPERACT_SUCCESS;
}

void CRecvBkbeps387::SendRtuMsg()
{
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "ENTER CRecvbeps381::SetRtuMsg");

   char m_sMsgRefId[20+1] = {0};
   
    m_beps389.MsgId           = m_colltnchrgscl.m_msgid;//报文标识号	
    m_beps389.CreDtTm         = m_strWorkDate;//报文发送时间
    m_beps389.InstgDrctPty    = m_colltnchrgscl.m_instgdrctpty;//发起直接参与机构
    m_beps389.GrpHdrInstgPty  = m_colltnchrgscl.m_instgpty;//间接发起参与机构
    m_beps389.InstdDrctPty    = m_colltnchrgscl.m_instddrctpty;//接收直接参与机构
    m_beps389.GrpHdrInstdPty  = m_colltnchrgscl.m_instdpty;//间接接收参与机构
    m_beps389.SysCd           = m_colltnchrgscl.m_syscd;//系统编号
    m_beps389.Rmk             = m_colltnchrgscl.m_rmk;//备注
    m_beps389.OrgnlMsgId      = m_colltnchrgscl.m_orgnlmsgid;//原报文标识号
    m_beps389.OrgnlInstgPty   = m_colltnchrgscl.m_orgnlinstgpty;//原发起参与机构
    m_beps389.OrgnlMT     = m_colltnchrgscl.m_msgtp;//原报文类型
    m_beps389.Sts             = m_colltnchrgscl.m_busistate;//业务状态
    m_beps389.RjctCd          = m_colltnchrgscl.m_processcode;//业务拒绝处理码
    m_beps389.RjctInf = m_colltnchrgscl.m_rjctinf;//业务拒绝信息
    m_beps389.PrcPty          = m_colltnchrgscl.m_rjctprcpty;//业务处理参与机构

    bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);
    if(false == bRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "参数错误");
	    PMTS_ThrowException(PRM_FAIL);
    }

    // 组文件头
    m_beps389.CreateXMlHeader("beps",                        \
                                m_colltnchrgscl.m_workdate.c_str(), \
                                m_colltnchrgscl.m_instgdrctpty.c_str(),\
                                m_colltnchrgscl.m_instddrctpty.c_str(),\
                                "beps.389.001.01",              \
                                m_sMsgRefId);

    AddQueue(m_beps389.m_sXMLBuff, m_beps389.m_sXMLBuff.size());
    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "LEAVE CRecvbeps381::SetRtuMsg");
    return ;
}

