/******************************************************************** 
�ļ����� recvbeps419.cpp
�����ˣ� aps-lel
��  �ڣ� 2011-04-20
�޸��ˣ� 
��  �ڣ� 
��  ����С������beps.419���Ĵ�����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkbeps419.h"


CRecvBkbeps419::CRecvBkbeps419()
{
    m_strMsgTp = "beps.419.001.01";
}

CRecvBkbeps419::~CRecvBkbeps419()
{
}

int CRecvBkbeps419::Work(LPCSTR szMsg)
{
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps419::Work()...");
	
	// ��������
	unPack(szMsg);
	
	//
	SetData(szMsg);
	
	// ��������
	InsertData();	
	
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps419::Work()...");
	return 0;
}

INT32 CRecvBkbeps419::unPack(LPCSTR szMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps419::unPack()...");
    // �����Ƿ�Ϊ��
    if (NULL == szMsg || '\0' == szMsg)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��"); 
        PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
    }

	/*
    //��ȡ��������
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(iRet != RTN_SUCCESS)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
        PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    */
    m_strWorkDate = m_sWorkDate;      

    // ��������
    if (OPERACT_SUCCESS != m_cbeps419.ParseXml(szMsg))
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "���Ľ�������! iRet= %d", iRet);
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "���Ľ�������");
    }
	
    m_strMsgID = m_cbeps419.MsgId;
	
	ZFPTLOG.SetLogInfo("419", m_strMsgID.c_str());
	
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps419::unPack()...");
	
    return OPERACT_SUCCESS;
}

INT32 CRecvBkbeps419::SetData(LPCSTR pchMsg)
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps419::SetData()");
	
	SETCTX(m_cBpCfOrgnl);
	
	//��ѯԭ418���뱨��
	QryOrgnBiz();
	
	//����ԭ418���뱨��״̬
	//UpdateOrgnBiz();
							
	// m_cBpchckcdtforld.m_mbmsgid	 = ;//���ڱ�ʶ��
	m_cBpchckcdtforld.m_workdate	 = m_strWorkDate;//
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__@@_m_strMsgTp=%s", m_strMsgTp.c_str());
	//m_cBpchckcdtforld.m_msgtp		 = m_strMsgTp;   //��������
	m_cBpchckcdtforld.m_msgtp		 = "beps.419.001.01";   //��������
	m_cBpchckcdtforld.m_mesgid 	     = m_cbeps419.m_PMTSHeader.getMesgID();//ͨ�ż���ʶ��
	m_cBpchckcdtforld.m_mesgrefid	 = m_cbeps419.m_PMTSHeader.getMesgRefID();//ͨ�ż��ο���
	m_cBpchckcdtforld.m_msgid		 = m_cbeps419.MsgId  ;//���ı�ʶ��
	m_cBpchckcdtforld.m_instgdrctpty  = m_cbeps419.InstgDrctPty ;//����ֱ�Ӳ������
	m_cBpchckcdtforld.m_instgpty	  = m_cbeps419.GrpHdrInstgPty ;//����������
	m_cBpchckcdtforld.m_instddrctpty  = m_cbeps419.InstdDrctPty ;//����ֱ�Ӳ������
	m_cBpchckcdtforld.m_instdpty	  = m_cbeps419.GrpHdrInstdPty;//���ղ������
	m_cBpchckcdtforld.m_syscd		  = m_cbeps419.SysCd;//ϵͳ���
	m_cBpchckcdtforld.m_rmk		      = m_cbeps419.Rmk ;//��ע
	m_cBpchckcdtforld.m_orgnlmsgid    = m_cbeps419.OrgnlMsgId;//ԭ���ı�ʶ��
	m_cBpchckcdtforld.m_orgnlinstgpty = m_cbeps419.OrgnlInstgPty;//ԭ����������
	m_cBpchckcdtforld.m_orgnlmt	      = m_cbeps419.OrgnlMT ;//ԭ�������� 
	//m_cBpchckcdtforld.m_applyorccltp  = ;//֧ƱȦ����������ʶ
	//m_cBpchckcdtforld.m_issedt	  = ;//��Ʊ����
	//m_cBpchckcdtforld.m_orcclnb	  = ;//֧Ʊ����
	//m_cBpchckcdtforld.m_orcclid	  = ;//��Ʊ���к�
	//m_cBpchckcdtforld.m_acctnb	  = ;//��Ʊ���˺�
	m_cBpchckcdtforld.m_currency      = m_cBpCfOrgnl.m_currency;//����
	m_cBpchckcdtforld.m_amt		      = m_cBpCfOrgnl.m_amt;     //���
	//m_cBpchckcdtforld.m_chckmd	  = ;//У��ģʽ
	//m_cBpchckcdtforld.m_chckcd	  = ;//У������
	//m_cBpchckcdtforld.m_imgfrntlen	=  ;//֧Ʊ����ͼ�񳤶�
	//m_cBpchckcdtforld.m_cntt 	  = ;//֧Ʊ����ͼ������
	m_cBpchckcdtforld.m_status 	= m_cbeps419.Sts;//ҵ��״̬
	m_cBpchckcdtforld.m_rjctcd 	= m_cbeps419.RjctCd  ;//ҵ��ܾ�������
	m_cBpchckcdtforld.m_rjctinf		= m_cbeps419.RjctInf ;//ҵ��ܾ���Ϣ
	m_cBpchckcdtforld.m_rjcprcpty	= m_cbeps419.PrcPty ;//ҵ�����������
	m_cBpchckcdtforld.m_procstate	= PR_HVBP_08;//����״̬
	//m_cBpchckcdtforld.m_proctime 	= ;//״̬����ʱ��
	//m_cBpchckcdtforld.m_pmttpprtry	= ;//ҵ�����ͱ���
    m_cBpchckcdtforld.m_srcflag = "1";
      
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps419::SetData()");
    return OPERACT_SUCCESS;
}

INT32 CRecvBkbeps419::InsertData()
{
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps419::InsertData()...");
    
	SETCTX(m_cBpchckcdtforld);
   
	//��������

	iRet = m_cBpchckcdtforld.insert();
	char szInfo[256] = {0};
	sprintf(szInfo, "iRet=%d err=%s", iRet, m_cBpchckcdtforld.GetSqlErr());
	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__@@__%s", szInfo);
	if(SQL_SUCCESS != iRet)
	{
        sprintf(m_szErrMsg,"execsql() error,error code = [%d] error cause = [%s]",
                iRet,m_cBpchckcdtforld.GetSqlErr());
                
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
				
		PMTS_ThrowException(__FILE__, __LINE__, 
		                    DB_INSERT_FAIL, m_szErrMsg);
	}
    
    Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps419::InsertData()...");
    return OPERACT_SUCCESS;
}

void CRecvBkbeps419::CheckSign419()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvbeps384::CheckSign419...");
	
	m_cbeps419.getOriSignStr();
	
	CheckSign(m_cbeps419.m_sSignBuff.c_str(),
						m_cbeps419.m_szDigitSign.c_str(),
						m_cbeps419.InstgDrctPty.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBkbeps419::CheckSign419...");
}

//__wsh 2012-05-28 ��ѯԭ���뱨����Ϣ
INT32 CRecvBkbeps419::QryOrgnBiz(void)
{
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "Enter CRecvBkbeps419::QryOrgnBiz");
    int iRet = -1;
    
    m_cBpCfOrgnl.m_msgid     = m_cbeps419.OrgnlMsgId;
    m_cBpCfOrgnl.m_instgpty  = m_cbeps419.OrgnlInstgPty;
    m_cBpCfOrgnl.m_srcflag   = "2";
    
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
        "__@@__MSGID:%s INSTGPTY:%s", 
        m_cBpCfOrgnl.m_msgid.c_str(),
        m_cBpCfOrgnl.m_instgpty.c_str());
    
    iRet = m_cBpCfOrgnl.findByPK();
    if(iRet != SQL_SUCCESS){
        char szErr[1024] = {0};
        sprintf(szErr, "QryOrgnBiz Failed, iRet=%d, Cause=%s",
            iRet, m_cBpCfOrgnl.GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "%s", szErr);
        PMTS_ThrowException(__FILE__, __LINE__, 
		                    DB_FIND_FAIL, szErr);   
    }

    Trace(L_DEBUG, __FILE__, __LINE__, NULL, "Leave CRecvBkbeps419::QryOrgnBiz");
    
    return iRet;   
}

//__wsh 2012-05-28 ����ԭ���뱨��418״̬
INT32 CRecvBkbeps419::UpdateOrgnBiz(void)
{
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
                        "Enter CRecvBkbeps419::UpdateOrgnBiz");
    
    int iRet = -1;
    
    string strProcState = (m_cbeps419.Sts == "PR05") ? PR_HVBP_74 : PR_HVBP_24;
        
    string strSql = "update bp_chckcdtforld set procstate = '";
    strSql += strProcState;
    strSql += "', status = '";
    strSql += m_cbeps419.Sts;
    //ҵ��״̬Ϊ�Ѿܾ�ʱ�����¾ܾ��뼰�ܾ���Ϣ
    if(m_cbeps419.Sts == "PR09"){
        strSql += "', rjctcd = '";
        strSql += m_cbeps419.RjctCd;
        strSql += "', rjctinf = '";
        strSql += m_cbeps419.RjctInf;
    }
    strSql += "' where msgid = '";
    strSql += m_cbeps419.OrgnlMsgId;
    strSql += "' and instgpty = '";
    strSql += m_cbeps419.OrgnlInstgPty;
    strSql += "' and srcflag = '1' ";
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
                "__@@_strSql=%s", strSql.c_str());
    iRet = m_cBpCfOrgnl.execsql(strSql.c_str());
    if(iRet != SQL_SUCCESS){
        char szErr[1024] = {0};
        sprintf(szErr, "UpdateOrgnBiz Failed, iRet=%d, Cause=%s",
            iRet, m_cBpCfOrgnl.GetSqlErr());
        Trace(L_ERROR, __FILE__, __LINE__, NULL, "%s", szErr);
        PMTS_ThrowException(__FILE__, __LINE__, 
		                    DB_UPDATE_FAIL, szErr);
    }
    
    Trace(L_DEBUG, __FILE__, __LINE__, NULL, 
                        "Leave CRecvBkbeps419::UpdateOrgnBiz");
    
    return iRet;
}


