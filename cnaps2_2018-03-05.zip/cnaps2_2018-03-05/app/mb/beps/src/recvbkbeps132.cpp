#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkbeps132.h"

using namespace ZFPT;

CRecvBkBeps132::CRecvBkBeps132()
{
    m_szOriSign = "";
    m_strMsgTp  = "beps.132.001.01";
}

CRecvBkBeps132::~CRecvBkBeps132()
{
}

//__wsh 2012-08-24 ҵ�������
INT32 CRecvBkBeps132::Work(const char* szmsg)
{
	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Enter CRecvBkBeps132::Work");

	int iRet = -1;

	//��ѹ����
	UnPack(szmsg);

	//����ԭҵ��
	QryOrgnlBiz();

	//��¼���ݿ�
	InsertData();

	//����ԭҵ��״̬
	//iRet = UpdateOrgnlBiz();

	Trace(L_INFO, __FILE__, __LINE__,
				NULL, "Leave CRecvBkBeps132::Work");

	return 0;
}
//__wsh 2012-08-24 ��ѹ����
int CRecvBkBeps132::UnPack(const char* szMsg)
{
	Trace(L_DEBUG, __FILE__, __LINE__,
			NULL, "Enter CRecvBkBeps132::UnPack");
	int iRet = -1;

	if(NULL == szMsg || '\0' == szMsg[0]){
		Trace(L_ERROR, __FILE__, __LINE__, NULL, "���ĳ���Ϊ��");
		PMTS_ThrowException(PRM_FAIL);
	}

	//��������
	if (OPERACT_SUCCESS != m_cBeps132.ParseXml(szMsg)){
		Trace(L_ERROR,  __FILE__,  __LINE__,
				NULL, "���Ľ�������! iRet= %d", iRet);

		PMTS_ThrowException(__FILE__, __LINE__,
				OPT_PRS_MSG_FAIL, "���Ľ�������");
	}
    //m_strNpcMsg = szMsg;

	m_strWorkDate = m_sWorkDate;

    ZFPTLOG.SetLogInfo("132", m_cBeps132.MsgId.c_str());

	Trace(L_DEBUG, __FILE__, __LINE__,
			NULL, "Leave CRecvBkBeps132::UnPack");

	return OPERACT_SUCCESS;
}

//__wsh 2012-08-24 ��ѯԭҵ��
int CRecvBkBeps132::QryOrgnlBiz(void)
{
	Trace(L_DEBUG, __FILE__, __LINE__,
				NULL, "Enter CRecvBkBeps132::QryOrgnlBiz");
	int iRet = -1;

	m_orgnlbiz.m_cdtrbrnchid = m_cBeps132.OrgnlCdtrAgtId;
	m_orgnlbiz.m_txid        = m_cBeps132.OrgnlTxId;

	Trace(L_DEBUG, __FILE__, __LINE__, NULL,
		"m_orgnlbiz.m_cdtrbrnchid=[%s]",
		m_orgnlbiz.m_cdtrbrnchid.c_str());

	Trace(L_DEBUG, __FILE__, __LINE__, NULL,
		"m_orgnlbiz.m_txid=[%s]", m_orgnlbiz.m_txid.c_str());

	SETCTX(m_orgnlbiz);
	iRet = m_orgnlbiz.findByPK();
	if(iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
			"[bp_bdsendlist]��ѯԭҵ��ʧ��:[%s]", m_orgnlbiz.GetSqlErr());
		PMTS_ThrowException(DB_FIND_BY_PK_FAIL);
	}

	Trace(L_DEBUG, __FILE__, __LINE__,
				NULL, "Leave CRecvBkBeps132::QryOrgnlBiz");

	return iRet;
}

//__wsh 2012-08-24 �������
int CRecvBkBeps132::InsertData(void)
{
	Trace(L_DEBUG, __FILE__, __LINE__,
				NULL, "Enter CRecvBkBeps132::InsertData");

	InsertData_cl();

	InsertData_list();

	Trace(L_DEBUG, __FILE__, __LINE__,
				NULL, "Leave CRecvBkBeps132::InsertData");

	return 0;
}

//__wsh 2012-08-24 ��ִ����132��¼��ǻ��ܱ�
int CRecvBkBeps132::InsertData_cl(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Enter CRecvBkBeps132::InsertData_cl");
	int iRet = -1;

	m_bcrcvcl.m_workdate     = m_strWorkDate; //��������
	m_bcrcvcl.m_consigdate   = m_cBeps132.MsgId.substr(0, 8); //ί������
	m_bcrcvcl.m_msgtp        = "beps.132.001.01"; //���ı�ʶ
	m_bcrcvcl.m_msgid        = m_cBeps132.MsgId; //���ı�ʶ
	m_bcrcvcl.m_instgdrctpty = m_cBeps132.DbtrAgtMmbId; //����ֱ�Ӳ�����
	m_bcrcvcl.m_instddrctpty = m_cBeps132.CdtrAgtMmbId; //����ֱ�Ӳ�����
	m_bcrcvcl.m_srcflag      = "1";
	m_bcrcvcl.m_rmk          = m_cBeps132.AddtlInf;
	m_bcrcvcl.m_ccy          = m_cBeps132.Ccy; //���ҷ���
	
    m_bcrcvcl.m_nboftxs  = 1; //��ϸ����
    m_bcrcvcl.m_ctrlsum  = atof(m_cBeps132.IntrBkSttlmAmt.c_str());	
    
	if(m_cBeps132.StsId == "PR02")
  {		
	  m_bcrcvcl.m_succnboftxs  = 1;
    m_bcrcvcl.m_ctrlsuccsum  = atof(m_cBeps132.IntrBkSttlmAmt.c_str());
	}
	else
	{		
	  m_bcrcvcl.m_succnboftxs  = 0;
    m_bcrcvcl.m_ctrlsuccsum  = 0.00;		
	}
	m_bcrcvcl.m_sapsnboftxs  = 0;
    m_bcrcvcl.m_ctrlsapssum  = 0.0;
    m_bcrcvcl.m_dgtsign      = "DIGTAL SIGN";
    m_bcrcvcl.m_realtimeflag = "1";
    m_bcrcvcl.m_isrbflg      = "0";
    m_bcrcvcl.m_checkstate   = PR_CNCH_00;

	m_bcrcvcl.m_mesgid    = m_cBeps132.m_PMTSHeader.getMesgID();
	m_bcrcvcl.m_mesgrefid = m_cBeps132.m_PMTSHeader.getMesgRefID();

    int iAfCnt = m_cBeps132.m_pXMLProc.m_PMTSSpecilDataMap.size();
    string strVal = "";
	for(int i = 0; i < iAfCnt; ++i){
		strVal.clear();
		strVal = m_cBeps132.GetAddtlInf(i);
		if(strstr(strVal.c_str(),"/F61/") != NULL){//ҵ��״̬
			GetTagVal(m_bcrcvcl.m_busistate, strVal, "/F61/");
		}
		else if(strstr(strVal.c_str(),"/C01/") != NULL){//NPC��������
			GetTagVal(m_bcrcvcl.m_netgdt, strVal, "/C01/");
		}
		else if(strstr(strVal.c_str(),"/E05/") != NULL){//NPC�����
			GetTagVal(m_bcrcvcl.m_netgrnd, strVal, "/E05/");
		}
		else if(strstr(strVal.c_str(),"/C00/") != NULL){//NPC��������/��̬����
			GetTagVal(m_bcrcvcl.m_finalstatedate, strVal, "/C00/");
		}
	}

	//char szProcSts[8] = {0};
	//TransProcStates(m_bcrcvcl.m_busistate.c_str(), szProcSts);
	m_bcrcvcl.m_busistate = "";
	m_bcrcvcl.m_procstate = PR_HVBP_08; //����״̬

    SETCTX(m_bcrcvcl);
	iRet = m_bcrcvcl.insert();
	if(iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
				"[bc_bdrcvcl]�������:[%s]", m_bcrcvcl.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Leave CRecvBkBeps132::InsertData_cl");

	return iRet;
}

//__wsh 2012-08-24 ��ִ����132��¼�����ϸ��
int CRecvBkBeps132::InsertData_list(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
					NULL, "Enter CRecvBkBeps132::InsertData_list");
	int iRet = -1;

	m_bcrcvlist.m_workdate      = m_strWorkDate; //��������
	m_bcrcvlist.m_consigdate    = m_cBeps132.MsgId.substr(0, 8); //ί������
	m_bcrcvlist.m_msgtp         = "beps.132.001.01"; //��������
	m_bcrcvlist.m_msgid         = m_cBeps132.MsgId; //���ı�ʶ
	m_bcrcvlist.m_instgdrctpty  = m_bcrcvcl.m_instgdrctpty; //����ֱ�Ӳ�����
	m_bcrcvlist.m_instddrctpty  = m_bcrcvcl.m_instddrctpty; //����ֱ�Ӳ�����
	m_bcrcvlist.m_txid          = m_cBeps132.OrgnlTxId; //��ϸ��ʶ

	m_bcrcvlist.m_dbtnm        = m_orgnlbiz.m_dbtnm; //����������
	m_bcrcvlist.m_dbtracctid   = m_orgnlbiz.m_dbtracctid; //�������˺�
	m_bcrcvlist.m_dbtrissr     = m_orgnlbiz.m_dbtrissr; //�����˿������к�
	m_bcrcvlist.m_dbtrbrnchid  = m_cBeps132.DbtrAgtId; //�����к�
	m_bcrcvlist.m_dbtaddr      = m_orgnlbiz.m_dbtaddr; //�����˵�ַ

	m_bcrcvlist.m_cdtrnm       = m_orgnlbiz.m_cdtrnm; //�տ�������
	m_bcrcvlist.m_cdtracctid   = m_orgnlbiz.m_cdtracctid; //�տ����˺�
	m_bcrcvlist.m_cdtrissr     = m_orgnlbiz.m_cdtrissr; //�տ��˿����к�
	m_bcrcvlist.m_cdtrbrnchid  = m_cBeps132.CdtrAgtId; //�տ��к�
	m_bcrcvlist.m_cdtaddr      = m_orgnlbiz.m_cdtaddr; //�տ��˵�ַ

	m_bcrcvlist.m_currency     = m_cBeps132.Ccy; //���ҷ���
	m_bcrcvlist.m_amount       = m_cBeps132.StsId == "PR02" ?
			atof(m_cBeps132.IntrBkSttlmAmt.c_str()) : 0.0; //���
	m_bcrcvlist.m_pmttpprtry   = m_cBeps132.CtgyPurpPrtry; //ҵ������
	m_bcrcvlist.m_purpprtry    = m_orgnlbiz.m_purpprtry; //ҵ������

	m_bcrcvlist.m_procstate    = m_bcrcvcl.m_procstate; //����״̬
	m_bcrcvlist.m_acctstate    = BUS_INIT;
	m_bcrcvlist.m_checkstate   = PR_CNCH_00;

	m_bcrcvlist.m_orgnlmsgid   = m_cBeps132.OrgnlMsgId; //ԭ���ı�ʶ
	m_bcrcvlist.m_orgnlmsgtp   = m_cBeps132.OrgnlMsgNmId; //ԭ��������
	m_bcrcvlist.m_oriinstgpty  = m_cBeps132.OrgnlCdtrAgtId; //ԭ���������
	m_bcrcvlist.m_oriinstgdrctpty = m_cBeps132.OrgnlCdtrAgtMmbId; //ԭ����ֱ�Ӳ�����
	m_bcrcvlist.m_oritxid      = m_cBeps132.OrgnlTxId; //ԭ��ϸ��ʶ
	m_bcrcvlist.m_oriamount    = atof(m_cBeps132.IntrBkSttlmAmt.c_str()); //ԭ���׽��

	m_bcrcvlist.m_busistate    = m_bcrcvcl.m_busistate; //ҵ��״̬
	m_bcrcvlist.m_netgdt       = m_bcrcvcl.m_netgdt; //��������
	m_bcrcvlist.m_netgrnd      = m_bcrcvcl.m_netgrnd; //�����
	m_bcrcvlist.m_remark       = m_bcrcvcl.m_rmk; //��ע
	m_bcrcvlist.m_srcflag      = "0";
	//m_bcrcvlist.m_printno      = 0;
	//m_bcrcvlist.m_finalstatedate = m_bcrcvcl.m_finalstatedate; //��̬����
	//m_bcrcvlist.m_npcmsg       = m_strNpcMsg;

	m_bcrcvlist.m_replystate   = m_cBeps132.StsId; //ҵ���ִ״̬
	m_bcrcvlist.m_replyprocesscode = m_cBeps132.RsnPrtry; //ҵ��ܾ���
	m_bcrcvlist.m_replyrjctinf = m_cBeps132.TxInfAndStsAddtlInf;//ҵ��ܾ���Ϣ

	SETCTX(m_bcrcvlist);
	iRet = m_bcrcvlist.insert();
	if(iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
			"[bc_bdrecvlist]�������:[%s]", m_bcrcvlist.GetSqlErr());
		PMTS_ThrowException(DB_INSERT_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__,
			 NULL, "Leave CRecvBkBeps132::InsertData_list");

	return iRet;
}

//__wsh 2012-08-24 ����ԭҵ��
int CRecvBkBeps132::UpdateOrgnlBiz(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			 NULL, "Enter CRecvBkBeps132::UpdateOrgnlBiz");

	int iRet = -1;

	//131����յ���ִҵ����̬Ϊ�ѳɹ���Ϊ��ֹ���㱨���޸���ҵ��״̬��
	//����ʱ�����������ڣ�������ֶν��и���

	//���»���
	string strSql = "update bp_bdrcvdcl set statetime=sysdate, procstate='";
	strSql += PR_HVBP_07;
	strSql += "', busistate='PR05', finalstatedate='";
	strSql += m_bcrcvcl.m_netgdt;
	strSql += "' where msgid='";
	strSql += m_cBeps132.OrgnlMsgId;
	strSql += "' and instgdrctpty='";
	strSql += m_cBeps132.OrgnlCdtrAgtMmbId;
	strSql += "' ";

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strSql=[%s]", strSql.c_str());

	iRet = m_orgnlbiz.execsql(strSql);
	if(iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
			"[bp_bcoutsndcl]���³���:[%s]", m_orgnlbiz.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	//������ϸ
	strSql.clear();
	strSql = "update bp_bdrecvlist set statetime=sysdate, procstate='";
	strSql += PR_HVBP_07;
	strSql += "', busistate='PR05', replystate='";
	strSql += m_bcrcvlist.m_replystate;
	strSql += "', replyprocesscode='";
	strSql += m_bcrcvlist.m_replyprocesscode;
	strSql += "', replyrjctinf='";
	strSql += m_bcrcvlist.m_replyrjctinf;
	strSql += "', finalstatedate='";
	strSql += m_bcrcvcl.m_netgdt;
	strSql += "' where txid='";
	strSql += m_cBeps132.OrgnlTxId;
	strSql += "' and cdtrbrnchid='";
	strSql += m_cBeps132.OrgnlCdtrAgtId;
	strSql += "' ";

	Trace(L_DEBUG, __FILE__, __LINE__, NULL, "__strSql=[%s]", strSql.c_str());

	iRet = m_orgnlbiz.execsql(strSql);
	if(iRet != SQL_SUCCESS){
		Trace(L_ERROR, __FILE__, __LINE__, NULL,
			"[bp_bcoutsndcl]���³���:[%s]", m_orgnlbiz.GetSqlErr());
		PMTS_ThrowException(DB_UPDATE_FAIL);
	}

	Trace(L_INFO, __FILE__, __LINE__,
			 NULL, "Leave CRecvBkBeps132::UpdateOrgnlBiz");

	return iRet;
}

//__wsh 2012-08-24 ������ǩ
void CRecvBkBeps132::ChkSign132(void)
{
	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBkBeps132::ChkSign132");

	m_cBeps132.getOriSignStr();

	CheckSign(
			m_cBeps132.m_sSignBuff.c_str(),
			m_cBeps132.m_szDigitSign.c_str(),
			m_cBeps132.DbtrAgtMmbId.c_str());

	Trace(L_INFO, __FILE__, __LINE__,
			NULL, "Leave CRecvBkBeps132::ChkSign132");

}

