/******************************************************************** 
文件名： recvbkbeps381.cpp
创建人： handongfeng
日  期： 2011-02-23
修改人： 
日  期： 
描  述：
版  本： 
Copyright (c) 2011  YLINK 
********************************************************************/ 

#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkbeps381.h"

CRecvBkbeps381::CRecvBkbeps381()
{
    m_colltnchrgscl.m_msgtp = "beps.381.001.01";
    m_colltnchrgslist.m_msgtp = "beps.381.001.01";
    memset(m_sMsgRefId389, 0x00, sizeof(m_sMsgRefId389));

}

CRecvBkbeps381::~CRecvBkbeps381()
{

}

int CRecvBkbeps381::Work(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps381::Work()");

    // 解析报文
    unPack(szMsg);

    SetData(szMsg);

    // 插入数据
    InsertData();

	UpdateOrgnData();
	
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps381::Work()");
    return OPERACT_SUCCESS;
}



INT32 CRecvBkbeps381::unPack(LPCSTR szMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps381::unPack()");
    int iRet = -1;
    
    // 报文是否为空
    if (NULL == szMsg || '\0' == szMsg)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文为空");	
    	PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "报文为空");
    }
    
    //获取工作日期
    iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_BEPS);
    if(iRet != RTN_SUCCESS)
    {
    	Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "获取工作日期失败！");	
    	PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
    }
    m_strWorkDate = m_sWorkDate;    

    // 解析报文
    iRet = m_beps381.ParseXml(szMsg);
    if (OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "报文解析出错! iRet= %d", iRet);	
        PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, "获取解析对象失败");
    }
    
    m_strMsgID = m_beps381.MsgId;
    ZFPTLOG.SetLogInfo("381", m_strMsgID.c_str());

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps381::unPack()");
    return OPERACT_SUCCESS;
}

INT32 CRecvBkbeps381::InsertData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps381::InsertData()");
    m_colltnchrgscl.m_procstate = PR_HVBP_08 ; //已收妥
    m_colltnchrgscl.m_workdate = m_strWorkDate ; 
    m_colltnchrgscl.m_trnsmtdt = m_beps381.OrgnlTrnsmtDt;     
    m_colltnchrgscl.m_consigdate = m_strWorkDate ; 
    m_colltnchrgscl.m_mesgid = m_beps381.m_PMTSHeader.getMesgID(); 
    m_colltnchrgscl.m_mesgrefid = m_beps381.m_PMTSHeader.getMesgRefID();
    m_colltnchrgscl.m_syscd = "BEPS" ; 
    m_colltnchrgscl.m_srcflag = m_colltnchrgslist.m_srcflag;

    m_colltnchrgscl.m_msgid = m_beps381.MsgId; 
    m_colltnchrgscl.m_checkstate = "1"; 
    m_colltnchrgscl.m_instgdrctpty = m_beps381.InstgDrctPty; 
    m_colltnchrgscl.m_instgpty = m_beps381.GrpHdrInstgPty; 
    m_colltnchrgscl.m_instddrctpty = m_beps381.InstdDrctPty; 
    m_colltnchrgscl.m_instdpty = m_beps381.GrpHdrInstdPty; 
    m_colltnchrgscl.m_rmk = m_beps381.Rmk; 
    m_colltnchrgscl.m_btchnb = m_beps381.OrgnlBtchNb; 
    m_colltnchrgscl.m_dbtrmmbid = m_beps381.RcvgDtlsBrnchId; 
    m_colltnchrgscl.m_cdtrmmbid = m_beps381.RcvgDtlsBrnchId; 
    m_colltnchrgscl.m_cdbtrnm = m_beps381.CdtrNm; 
    m_colltnchrgscl.m_cdbtrid = m_beps381.CdtrAcctId; 
    m_colltnchrgscl.m_cdbtrbrnchid = m_beps381.CdtrAgtId; 
    m_colltnchrgscl.m_currency = m_beps381.AmtCcy; 
	m_colltnchrgscl.m_rcvsndgttlamt = atof(m_beps381.RcvgTtlAmt.c_str()); 
	m_colltnchrgscl.m_rcvsndgttlnb = atoi(m_beps381.RcvgTtlNb.c_str()) ; 
	
    m_colltnchrgscl.m_ttlamt = atof(m_beps381.RcvgTtlAmt.c_str()); 
    m_colltnchrgscl.m_cdbtrnb = atoi(m_beps381.RcvgTtlNb.c_str()) ; 
    m_colltnchrgscl.m_ctgyprtry = m_beps381.OrgnlTxTpCd ; 
    //m_colltnchrgscl.m_puryprtry = m_beps381.OrgnlCtgyPurpCd ; 

	m_colltnchrgscl.m_orgnlbtchnb = m_beps381.OrgnlBtchNb;
	m_colltnchrgscl.m_orgnlinstgpty = m_beps381.OrgnlInstgPty;
	m_colltnchrgscl.m_orgnlmsgid = m_beps381.OrgnlMsgId;
	m_colltnchrgscl.m_orgnlrtrltd = atoi(m_beps381.OrgnlRtrLtd.c_str());
	m_colltnchrgscl.m_orgnltrnsmtdt = m_beps381.OrgnlTrnsmtDt;
	m_colltnchrgscl.m_orgnlttlam = atof(m_beps381.OrgnlTtlAmt.c_str());
	m_colltnchrgscl.m_orgnlttlnb = atoi(m_beps381.OrgnlTtlNb.c_str());
    m_colltnchrgscl.m_orgnltxtpcd = m_beps381.OrgnlTxTpCd;
		
    m_colltnchrgscl.setctx(m_dbproc);
    int iRet = m_colltnchrgscl.insert();
    if(OPERACT_SUCCESS != iRet)
    {
        Trace(L_ERROR, __FILE__,  __LINE__, NULL, 
            "m_colltnchrgscl.insert() failed:error code =[%d],error cause =[%s]", iRet,m_colltnchrgscl.GetSqlErr());
        PMTS_ThrowException(__FILE__, __LINE__, DB_INSERT_FAIL, "新增表失败");
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps381::InsertData()");
    return iRet;
}

INT32 CRecvBkbeps381::SetData(LPCSTR pchMsg)
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps381::SetData()");

    SETCTX(m_colltnchrgslist);
    int iRet = -1;
    int iNum = atoi(m_beps381.OrgnlTtlNb.c_str());

    char sMesgId[20 + 1] = {0};
    
    GetMsgIdValue(m_dbproc, sMesgId, eRefId,  SYS_BEPS);
    
    m_colltnchrgslist.m_instgdrctpty = m_beps381.InstgDrctPty;//发起直接参与机构
    m_colltnchrgslist.m_instgpty = m_beps381.GrpHdrInstgPty;//间接发起参与机构
    m_colltnchrgslist.m_instddrctpty = m_beps381.InstdDrctPty;//接收直接参与机构
    m_colltnchrgslist.m_instdpty = m_beps381.GrpHdrInstdPty;//间接发起参与机构
    m_colltnchrgslist.m_syscd = "BEPS"           ;//系统编号
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "iNum[%d]",iNum);
    for(int i = 0; i < iNum; i++)
    {
        m_beps381.ParseDetail(i);

        //add jienjun 20120606
        m_colltnchrgslist.m_workdate = m_strWorkDate;
        m_colltnchrgslist.m_consigdate = m_strWorkDate;
        m_colltnchrgslist.m_msgtp = "beps.381.001.01";
        m_colltnchrgslist.m_mesgid = sMesgId;
        m_colltnchrgslist.m_mesgrefid = sMesgId;
        m_colltnchrgslist.m_msgid = m_beps381.MsgId;//报文标识号	
        m_colltnchrgslist.m_rmk = m_beps381.Rmk;//备注
        m_colltnchrgslist.m_srcflag = "1";//1：往帐 2：付款方来帐 3：收款方来帐
        m_colltnchrgslist.m_btchnb = m_beps381.OrgnlBtchNb;
        m_colltnchrgslist.m_txid = m_beps381.TxId;
        m_colltnchrgslist.m_dbtrnm = m_beps381.DbtrNm           ;//付款人户名
        m_colltnchrgslist.m_dbtrid = m_beps381.DbtrAcctId           ;//付款人账号
        //m_colltnchrgslist.m_dbtrmmbid = m_beps381.RcvgDtlsBrnchId;
        m_colltnchrgslist.m_dbtrmmbid = m_beps381.InstgDrctPty;
        m_colltnchrgslist.m_dbtrbrnchid = m_beps381.RcvgDtlsBrnchId;//付款行行号

        m_colltnchrgslist.m_cdtrmmbid = m_beps381.OrgnlInstgPty;
        m_colltnchrgslist.m_cdtrbrnchid = m_beps381.CdtrAgtId           ;//收款行行号
        m_colltnchrgslist.m_cdtrnm = m_beps381.CdtrNm;//收款人名称
        m_colltnchrgslist.m_cdtrid = m_beps381.CdtrAcctId;//收款人账号
        m_colltnchrgslist.m_currency = m_beps381.AmtCcy;//货币符号
        m_colltnchrgslist.m_currency = "CNY";//测试用
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_colltnchrgslist.m_currency=%s", m_colltnchrgslist.m_currency.c_str());
        m_colltnchrgslist.m_amout = atof(m_beps381.Amt.c_str());//金额
        m_colltnchrgslist.m_ctgyprtry = m_beps381.OrgnlTxTpCd;
        m_colltnchrgslist.m_puryprtry = m_beps381.OrgnlCtgyPurpCd;
        //m_colltnchrgslist.m_endtoendid = m_beps381.EndToEndId;
        //m_colltnchrgslist.m_chckflg = m_beps381.ChckFlg;

		m_colltnchrgslist.m_processcode = m_beps381.RjctCd;
		m_colltnchrgslist.m_busistate = m_beps381.Sts;
		m_colltnchrgslist.m_rjctinf = m_beps381.RspsnInfRjctInf;

        m_colltnchrgslist.m_procstate = PR_HVBP_08;
        m_colltnchrgslist.m_addtlinf = m_beps381.AddtlInf;//附言
        
        //明细表插入数据
        if(OPERACT_SUCCESS != m_colltnchrgslist.insert())
        {
            Trace(L_INFO,  __FILE__,  __LINE__, NULL, "插入明细表失败,回滚汇总表, ERROR = %s", m_colltnchrgslist.GetSqlErr());
            break; //return OPERACT_FAILED;  回执这里不能直接返回
        }
        
        // 循环加签要素
        m_beps381.AddTxStr();  

        ++m_iTotalNum;
        m_iTotalAmt += m_colltnchrgslist.m_amout;
        
    }

    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps381::SetData()");
    return OPERACT_SUCCESS;
}

INT32 CRecvBkbeps381::UpdateOrgnData()
{
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps381::UpdateOrgnData()");

    SETCTX(m_colltnchrgscl);

    char m_sMsgRefId[20+1] = {0};
    bool bRet = GetMsgIdValue(m_dbproc, m_sMsgRefId, eRefId, SYS_BEPS);

    string strSQL;
	strSQL += "UPDATE bp_colltnchrgscl t SET t.STATETIME = sysdate, t.PROCSTATE = '07' ";	
    strSQL += " WHERE t.MSGID = '";
	strSQL += m_colltnchrgscl.m_orgnlmsgid.c_str();
	strSQL += "' AND t.instgpty = '";
	strSQL += m_colltnchrgscl.m_orgnlinstgpty.c_str(); 									
	strSQL += "' AND SRCFLAG = '2'";
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    int iRet = m_colltnchrgscl.execsql(strSQL.c_str());
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateState失败, iRet=%d, %s", iRet, m_colltnchrgscl.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }    

	strSQL = "UPDATE bp_colltnchrgslist t SET t.STATETIME = sysdate, t.PROCSTATE = '07' ";    
    strSQL += " WHERE t.MSGID = '";
	strSQL += m_colltnchrgscl.m_orgnlmsgid.c_str();
	strSQL += "' AND t.instgpty = '";
	strSQL += m_colltnchrgscl.m_orgnlinstgpty.c_str(); 									
	strSQL += "' AND SRCFLAG = '2'";
    
    Trace(L_INFO,  __FILE__,  __LINE__, NULL, "strSQL=%s", strSQL.c_str());
    
    iRet = m_colltnchrgscl.execsql(strSQL.c_str());
    
    if(RTN_SUCCESS != iRet)
    {
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "UpdateState失败, iRet=%d, %s", iRet, m_colltnchrgslist.GetSqlErr());
        PMTS_ThrowException(DB_UPDATE_FAIL);
    }   

    
    Trace(L_INFO,  __FILE__,  __LINE__,NULL, "LEAVE CRecvBkbeps381::UpdateOrgnData");
    return iRet;

    return OPERACT_SUCCESS;
}


void CRecvBkbeps381::CheckSign381()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvBeps381::CheckSign381()");
	
	m_beps381.getOriSignStr();
	
	CheckSign(m_beps381.m_sSignBuff.c_str(),
			m_beps381.m_szDigitSign.c_str(),
			m_beps381.InstgDrctPty.c_str());
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvBeps381::CheckSign381()");
}




