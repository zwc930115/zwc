#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvbkbeps720.h"

using namespace ZFPT;

CRecvBkbeps720::CRecvBkbeps720()
{
}

CRecvBkbeps720::~CRecvBkbeps720()
{

}

INT32 CRecvBkbeps720::Work(LPCSTR szMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "ENTER CRecvBkbeps720::Work()");

	//do nothing	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "LEAVE CRecvBkbeps720::Work()");
	return 0;
}

