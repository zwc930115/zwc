/*
 *  recvbeps395.h
 *  Description: 指量客户账户查询来报处理类beps.395.001.01
 *  Created on: 2012-6-5
 *  Author: __wsh
 */

#ifndef RECVBKBEPS395_H_
#define RECVBKBEPS395_H_


#include "beps395.h"
#include "recvbkbepsbase.h"

#include "bpcstacctqrycl.h"
#include "bpcstacctqrylist.h"

class CRecvBkbeps395 : public CRecvbkBepsBase
{
public:
	CRecvBkbeps395();

    ~CRecvBkbeps395();

    int Work(LPCSTR szMsg);

private:

    int UnPack(LPCSTR szMsg);

    int SetData_cl(void);

    int InsertData_cl(void);

    int GetAcctDtls(int iCount);

    int SetData_list(int iCount);

    int InsertData_list(void);

    void CheckSign395(void);

    int UpdateOrgnBiz(void);

private:

    beps395 m_cBeps395;

    CBpcstacctqrycl m_caqcl;

    CBpcstacctqrylist m_caqlist;

};

#endif /* RECVBEPS395_H_ */
