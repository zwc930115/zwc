/******************************************************************** 
�ļ����� recvpkg001.h
�����ˣ� aps-lel
��  �ڣ� 2011-05-25
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __RECVPKG001_H__BK
#define __RECVPKG001_H__BK

#include "recvbkbepsbase.h"
#include "pkg001.h"
#include "bpbcoutsendlist.h"
#include "bpbcoutsndcl.h"

class CRecvBkPkg001 : public CRecvbkBepsBase
{
public:
    CRecvBkPkg001();
    ~CRecvBkPkg001();
    int Work(LPCSTR szMsg);
    
private:

    void ParserAppData(const char* szSrcAppData, string& szDstAppData);
    
    int InsertData();
    int SetData(LPCSTR pchMsg);
    int unPack(LPCSTR szMsg);
	void AddMac();
    int FundSettle();
	int CheckMac001();
	
    pkg001              m_cPkg001;
    CBpbcoutsendlist	m_cBpbcoutrecvlist;
    CBpbcoutsndcl		m_cBpbcoutrcvcl;

};

#endif

