/*
 * 	recvbeps415.cpp
 *	Description: ʵʱ����֪ͨ����beps.415.001.01������
 *  Created on: 2012-07-09
 *  Author: __wsh
 */

#ifndef RECVBKBEPS415_H
#define RECVBKBEPS415_H

#include "beps415.h"
#include "recvbkbepsbase.h"

#include "bpcstpmtcxl.h" 

class CRecvBkBeps415 : public CRecvbkBepsBase
{
public:
    CRecvBkBeps415();

    ~CRecvBkBeps415();

    INT32 Work(LPCSTR szMsg);
    
private:
    int UnPack(LPCSTR szMsg);

    void SetData(void);

    int InsertData(void);

    void  CheckSign415(void);
	
private:
    beps415           m_cBeps415;
    
    CBpcstpmtcxl      m_cpc;
};

#endif /*RECVBEPS415_H*/


