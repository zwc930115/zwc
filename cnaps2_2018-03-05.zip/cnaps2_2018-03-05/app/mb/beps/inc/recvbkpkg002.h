/******************************************************************** 
�ļ����� recvpkg002.h
�����ˣ� handongfeng
��  �ڣ� 2011-04-15
�޸��ˣ� 
��  �ڣ� 
��  ���� 
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/

#ifndef __RECVPKG002_H__BK
#define __RECVPKG002_H__BK

#include "recvbkbepsbase.h"
#include "pkg002.h"
#include "bpbdsendlist.h"
#include "bpbdsndcl.h"

class CRecvBkPkg002 : public CRecvbkBepsBase
{
public:
	CRecvBkPkg002();
	~CRecvBkPkg002();
	INT32 Work(LPCSTR szMsg);
    
private:
	INT32 unPack(LPCSTR szMsg);
	INT32 InsertDb(LPCSTR pchMsg);
    INT32 CheckAcct();
    INT32 CheckMac002();
	void ParserAppData(const char* szSrcAppData, string& szDstAppData);
	void AddMac();
    
	pkg002         m_pkg002;
	CBpbdsendlist  m_BpBdList;
	CBpbdsndcl     m_BpBdCl;
};

#endif


