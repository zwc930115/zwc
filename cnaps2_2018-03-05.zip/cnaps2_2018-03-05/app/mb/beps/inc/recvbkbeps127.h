/******************************************************************** 
�ļ����� recvbeps127.h
�����ˣ� handongfeng
��  �ڣ� 2011-02-23
�޸��ˣ� 
��  �ڣ� 
��  ����
��  ���� 
Copyright (c) 2011  YLINK 
********************************************************************/ 
#ifndef __RECVBKBEPS127_H__
#define __RECVBKBEPS127_H__

#include "recvbkbepsbase.h"
#include "beps127.h"
#include "bpbdrecvlist.h"
#include "bpbdrcvcl.h"
#include "bpbdsendlist.h"
#include "bpbdsndcl.h"

class CRecvBkbeps127 : public CRecvbkBepsBase
{
public:
    CRecvBkbeps127();
    ~CRecvBkbeps127();    
    int Work(LPCSTR szMsg);
    void InsertUserInfoTel(void);
public:
    void SetRtuMsg();
private:
    void  CheckSign127();
    INT32 InsertData();
    INT32 SetData(LPCSTR pchMsg);
    INT32 unPack(LPCSTR szMsg);
    beps127		    m_cBeps127;
    CBpbdsendlist	m_BpList;
    CBpbdsndcl		m_Bpcl;
};

#endif
