
#ifndef RECVBKBEPS123_H
#define RECVBKBEPS123_H

#include "recvbkbepsbase.h"
#include "beps123.h"
#include "beps124.h"

#include "bpbdrecvlist.h" 
#include "bpbdrcvcl.h" 
#include "bpbcoutsendlist.h" 
#include "bpbcoutsndcl.h" 


class CRecvBkBeps123 : public CRecvbkBepsBase
{
public:
	CRecvBkBeps123();

	~CRecvBkBeps123();

	INT32 Work(LPCSTR szMsg);
    
private:
	int  UnPack(const char* szmsg);

	int  InsertData(void);

	int  InsertData_bc_cl(void);

	int  InsertData_bc_list(void);

	int  InsertData_bd_cl(void);

	int  InsertData_bd_list(void);

	void SetReply(void);

	int  BuildReplyMsg124(void);

	void ChkSign123(void);

	void AddSign124(void);

	int  DoReply(void);
	
private:
	beps123          m_cBeps123;

	beps124          m_cBeps124;

	CBpbcoutsndcl    m_bcrcvcl;

	CBpbcoutsendlist m_bcrcvlist;

	CBpbdrcvcl       m_bdsndcl;

	CBpbdrecvlist    m_bdsndlist;
	
	string           m_strNpcMsg;

	char             m_szRefId[32+1];

	char             m_szMsgId[32+1];
	
	char             m_szTxId[32+1];
};

#endif /*RECVBKBEPS123_H*/


