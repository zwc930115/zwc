#ifndef _RECVSAPS604_H_
#define _RECVSAPS604_H_

#include "recvsapsbase.h"
#include "saps604.h"
#include "hvsndexchglist.h"
#include "hvrcvexchglist.h"   //add by zwc 20180117 for cnaps2g_v1.4.6
#include "hvtrofacsndlist.h"
#include "syssapbankinfo.h" 

class CRecvSaps604 : public CRecvSapsBase
{
	
public:
	CRecvSaps604();
	~CRecvSaps604();
	
	INT32 doWorkSelf(LPCSTR sMsg);
	INT32 unPack(LPCSTR sMsg);
	INT32 UpdateData(void);
	INT32 InsertComsendmb(LPCSTR sMsg);//������ͨѶ�� added by hhc 2012-02-14
	void  CheckSign604();
	
private:
	saps604          m_saps604;
	CHvsndexchglist  m_Hvsnddexlist;
	CHvrcvexchglist  m_Hvrcvexlist;    //add by zwc 20180117 for cnaps2g_v1.4.6
	CHvsndexchglist  m_OriHvsnddexlist;
	CHvtrofacsndlist m_Hvtrosndlist;
	CSyssapbankinfo  m_Syssapbankinfo;
	
	string	m_strProcSts;
};

#endif

