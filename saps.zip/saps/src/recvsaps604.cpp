
#ifdef _LINUX_
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#endif

#include "recvsaps604.h"

using namespace ZFPT;

CRecvSaps604::CRecvSaps604()
{

	m_strProcSts = "";
    m_strMsgTp = "saps.604.001.01";

}

CRecvSaps604::~CRecvSaps604()
{
	
}

INT32 CRecvSaps604::doWorkSelf(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "CRecvSaps604::doWorkSelf()");			

	// ��������
	unPack(pchMsg);
	
	//��ǩ
	CheckSign604();

	InsertComsendmb(pchMsg);		

	UpdateData();
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvSaps604::doWorkSelf()");
	
	return RTN_SUCCESS;
}

INT32 CRecvSaps604::unPack(LPCSTR pchMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvSaps604::unPack()");
	
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "pchMsg = [%s]", pchMsg);

	int iRet = RTN_FAIL;

	// �����Ƿ�Ϊ��
	if (NULL == pchMsg || '\0' == pchMsg)
	{
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "����Ϊ��");	
		PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "����Ϊ��");
	}

	// ��������
	iRet = m_saps604.ParseXml(pchMsg);
	if (RTN_SUCCESS != iRet)
	{
		sprintf(m_szErrMsg, "CRecvSaps604::unPack:��������ʧ��[%d]", iRet);

		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);

		PMTS_ThrowException(__FILE__, __LINE__, OPT_PRS_MSG_FAIL, m_szErrMsg);
	}

	m_strMsgID = m_saps604.MsgId;

	ZFPTLOG.SetLogInfo("604", m_saps604.MsgId.c_str());
	
	// ��ȡ��������
	iRet = GetWorkDate(m_dbproc, m_sWorkDate, SYS_HVPS);
    if(iRet != RTN_SUCCESS)
	{
	 Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "��ȡ��������ʧ�ܣ�");   
	 PMTS_ThrowException(OPT_GET_WORK_DATE_FAIL);
	}
	
	m_strWorkDate = m_sWorkDate;  
	
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "MsgId           ���ı�ʶ��           = [%s]" ,  m_saps604.MsgId         .c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "CreDtTm         ���ķ���ʱ��         = [%s]" ,  m_saps604.CreDtTm       .c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "InstgDrctPty    ����ֱ�Ӳ������     = [%s]" ,  m_saps604.InstgDrctPty  .c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "GrpHdrInstgPty  ����������         = [%s]" ,  m_saps604.GrpHdrInstgPty.c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "InstdDrctPty    ����ֱ�Ӳ������     = [%s]" ,  m_saps604.InstdDrctPty  .c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "GrpHdrInstdPty  ���ղ������         = [%s]" ,  m_saps604.GrpHdrInstdPty.c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "SysCd           ϵͳ���             = [%s]" ,  m_saps604.SysCd         .c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "Rmk             ��ע                 = [%s]" ,  m_saps604.Rmk           .c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "OrgnlMsgId      ԭ���ı�ʶ��         = [%s]" ,  m_saps604.OrgnlMsgId    .c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "OrgnlInstgPty   ԭ����������       = [%s]" ,  m_saps604.OrgnlInstgPty .c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "OrgnlMT         ԭ��������           = [%s]" ,  m_saps604.OrgnlMT       .c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "PrcSts          NPC����״̬          = [%s]" ,  m_saps604.PrcSts        .c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "PrcCd           NPC������            = [%s]" ,  m_saps604.PrcCd         .c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "RjctInf         NPC�ܾ���Ϣ          = [%s]" ,  m_saps604.RjctInf       .c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "NetgDt          NPC��������          = [%s]" ,  m_saps604.NetgDt        .c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "NetgRnd         NPC�����          = [%s]" ,  m_saps604.NetgRnd       .c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "SttlmDt         NPC��������/��̬���� = [%s]" ,  m_saps604.SttlmDt       .c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "RcvTm           NPC����ʱ��          = [%s]" ,  m_saps604.RcvTm         .c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "TrnsmtTm        NPCת��ʱ��          = [%s]" ,  m_saps604.TrnsmtTm      .c_str());
	Trace(L_DEBUG,  __FILE__,  __LINE__, NULL, "Bal             ��ǰ���             = [%s]" ,  m_saps604.Bal           .c_str());

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvSaps604::unPack()");	

	return RTN_SUCCESS;
}

/******************************************************************************
*  Function:   InsertComsendmb
*  Description:������ͨѶ��
*  Input:      LPCSTR sMsg
*  Output:     
*  Return:     0   : �����ɹ�,
               ����: ����ʧ��
*  Others:     ��
*  Author:     hhc
*  Date:       2012-03-04
*******************************************************************************/
INT32 CRecvSaps604::InsertComsendmb(LPCSTR sMsg)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvSaps604::InsertComsendmb()");
	
	int    iRet = RTN_FAIL;
	string strRval = "";
	
	//��IBPS����״̬תΪ��ƽ̨�Ĵ���״̬
	char sProcSts[2 + 1] = {0};

    TransProcStates(m_saps604.PrcSts.c_str(), sProcSts);
    m_strProcSts = sProcSts;   

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "OrgnlMT[%s]", m_saps604.OrgnlMT.c_str());
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_strProcSts[%s]", m_strProcSts.c_str());
	//�ж���111��112����141����
	if( NULL != strstr(m_saps604.OrgnlMT.c_str(),"111") ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"112" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT100" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT101" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT102" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT103" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT105" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT108" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT121" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT122" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT123" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT124" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT229" ) )
	{
		//������ֵ
		m_Hvsnddexlist.m_msgtp = m_saps604.OrgnlMT;  
		m_Hvsnddexlist.m_msgid = m_saps604.OrgnlMsgId;
		m_Hvsnddexlist.m_instgindrctpty = m_saps604.OrgnlInstgPty;

		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_msgtp=[%s]" ,m_Hvsnddexlist.m_msgtp.c_str());
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_msgid=[%s]" ,m_Hvsnddexlist.m_msgid.c_str());
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_instgindrctpty=[%s]" ,m_Hvsnddexlist.m_instgindrctpty.c_str());

		//��������
		if (0 != m_Hvsnddexlist.setctx(m_dbproc))
		{
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
			PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
		}

		//��ѯԭҵ��
		iRet = m_Hvsnddexlist.findByPK();
		if (RTN_SUCCESS != iRet)
		{
			snprintf(m_szErrMsg, sizeof(m_szErrMsg) - 1, 
				"�յ�����604���ģ�����ԭ������ʴ�������ҵ����Ϣʧ��;[%d]", iRet);
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);       
			PMTS_ThrowException(__FILE__, __LINE__, DB_FIND_BY_PK_FAIL, m_szErrMsg);        
		}		

		//����Ҫ���µ��ֶθ�ֵ
		m_Hvsnddexlist.m_busistate      = m_saps604.PrcSts ;  //NPC����״̬
		m_Hvsnddexlist.m_processcode    = m_saps604.PrcCd  ;  //NPC������
		m_Hvsnddexlist.m_rjctinf        = m_saps604.RjctInf;  //NPC�ܾ���Ϣ
		m_Hvsnddexlist.m_finalstatedate = m_saps604.SttlmDt;  //NPC��������/��̬����
		m_Hvsnddexlist.m_procstate      = m_strProcSts     ;  //����״̬
		Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_Hvsnddexlist.m_procstate[%s]", m_Hvsnddexlist.m_procstate.c_str());
	}
	/*����ֻ���ղ�����
	else if( NULL != strstr(m_saps604.OrgnlMT.c_str(),"141") 
		  || NULL != strstr(m_saps604.OrgnlMT.c_str(),"142") )
	{
		//������ֵ
		//m_Hvtrosndlist.m_rsflag       = "0";	//��Ϊ������  
		m_Hvtrosndlist.m_msgid        = m_saps604.OrgnlMsgId;
		m_Hvtrosndlist.m_instgindrctpty = m_saps604.OrgnlInstgPty;

		Trace(L_INFO,	__FILE__,  __LINE__, NULL, "m_msgid=[%s]" ,m_Hvtrosndlist.m_msgid.c_str());
		Trace(L_INFO,	__FILE__,  __LINE__, NULL, "m_instgdrctpty=[%s]" ,m_Hvtrosndlist.m_instgdrctpty.c_str());

		//��������
		if (0 != m_Hvtrosndlist.setctx(m_dbproc))
		{
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
			PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
		}

		//��ѯԭҵ��
		iRet = m_Hvtrosndlist.findByPK();
		if (RTN_SUCCESS != iRet)
		{
			snprintf(m_szErrMsg, sizeof(m_szErrMsg) - 1, 
				"�յ�����604���ģ�����ԭ��ʱת��ҵ���ҵ����Ϣʧ��:[%d]", iRet);
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_FIND_BY_PK_FAIL, m_szErrMsg);        
		}
		
		strcpy(m_szDisSys, strRval.c_str());
		strncpy(m_szOrgnlMbMsgId, m_Hvtrosndlist.m_mbmsgid.c_str(), 22);
    		
		// ����ͨѶ���ֶθ�ֵ
		m_strCdCode = ":cdcode:" + m_Hvtrosndlist.cdcode;
    
	    //�жϼ�ֱ���������ֱ����������ͨѶ��
	    DirectInter(m_Hvtrosndlist.m_instgindrctpty.c_str(), 
	    			m_Hvtrosndlist.m_instdindrctpty.c_str(),
	    			m_Hvtrosndlist.m_cdtmmbid.c_str(), 
	    			sMsg);

		//����Ҫ���µ��ֶθ�ֵ
		m_Hvtrosndlist.m_busistate      = m_saps604.PrcSts ; //NPC����״̬	                                       
		m_Hvtrosndlist.m_processcode    = m_saps604.PrcCd  ; //NPC������	                                         
		m_Hvtrosndlist.m_rjctinf        = m_saps604.RjctInf; //NPC�ܾ���Ϣ	                                         	                                         
		m_Hvtrosndlist.m_finalstatedate = m_saps604.SttlmDt; //NPC��������/��̬����	                 	
		m_Hvtrosndlist.m_procstate      = m_strProcSts     ; //����״̬
	}
	*/
	//add by zwc 20171116 ����hvps.115.001.01
	else if( NULL != strstr(m_saps604.OrgnlMT.c_str(),"115") )
	{
        char selectStr[200]={0};
		m_Hvsnddexlist.m_msgid        = m_saps604.OrgnlMsgId;
		m_Hvsnddexlist.m_instgindrctpty = m_saps604.OrgnlInstgPty;
        m_Hvsnddexlist.m_msgtp        = m_saps604.OrgnlMT;
        
        sprintf(selectStr," MSGID='%s' and MSGTP='%s' and INSTGINDRCTPTY='%s'",
                 m_Hvsnddexlist.m_msgid.c_str(),
                 m_Hvsnddexlist.m_msgtp.c_str(),
                 m_Hvsnddexlist.m_instgindrctpty.c_str());

		Trace(L_INFO,	__FILE__,  __LINE__, NULL, "selectStr=[%s]" ,selectStr);

		//��������
		if (0 != m_Hvsnddexlist.setctx(m_dbproc))
		{
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
			PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
		}

		//��ѯԭҵ��
		iRet = m_Hvsnddexlist.find(selectStr);
		if (RTN_SUCCESS != iRet)
		{
			snprintf(m_szErrMsg, sizeof(m_szErrMsg) - 1, 
				"�յ�����604���ģ�����ԭ����������ҵ���ҵ����Ϣʧ��:[%d]", iRet);
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_FIND_BY_PK_FAIL, m_szErrMsg);        
		}
		iRet = m_Hvsnddexlist.fetch();
    	if(iRet == SQLNOTFOUND)
    	{
    		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������iRet=[%d]",iRet);
    	    //m_cHvtrofacrcvlist.closeCursor();
    	    PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "m_Hvsnddexlistû���ҵ�����������ԭҵ��");
    	}

		//����Ҫ���µ��ֶθ�ֵ
		m_Hvsnddexlist.m_busistate      = m_saps604.PrcSts ; //NPC����״̬	                                       
		m_Hvsnddexlist.m_processcode    = m_saps604.PrcCd  ; //NPC������	                                         
		m_Hvsnddexlist.m_rjctinf        = m_saps604.RjctInf; //NPC�ܾ���Ϣ	                                         	                                         
		m_Hvsnddexlist.m_finalstatedate = m_saps604.SttlmDt; //NPC��������/��̬����	                 	
		m_Hvsnddexlist.m_procstate      = m_strProcSts     ; //����״̬
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_Hvsnddexlist.m_procstate[%s]", m_Hvsnddexlist.m_procstate.c_str());

        m_Hvsnddexlist.closeCursor();
	}
	//add end
	//add by zwc 20180117 ����hvps.118.001.01��hvps.116.001.01
	else if( NULL != strstr(m_saps604.OrgnlMT.c_str(),"118") ||
		     NULL != strstr(m_saps604.OrgnlMT.c_str(),"116"))
	{
        char selectStr[200]={0};
		m_Hvrcvexlist.m_msgid        = m_saps604.OrgnlMsgId;
		m_Hvrcvexlist.m_instgindrctpty = m_saps604.OrgnlInstgPty;
        m_Hvrcvexlist.m_msgtp        = m_saps604.OrgnlMT;
        
        sprintf(selectStr," MSGID='%s' and MSGTP='%s' and INSTGINDRCTPTY='%s'",
                 m_Hvrcvexlist.m_msgid.c_str(),
                 m_Hvrcvexlist.m_msgtp.c_str(),
                 m_Hvrcvexlist.m_instgindrctpty.c_str());

		Trace(L_INFO,	__FILE__,  __LINE__, NULL, "selectStr=[%s]" ,selectStr);

		//��������
		if (0 != m_Hvrcvexlist.setctx(m_dbproc))
		{
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "setctx error");	
			PMTS_ThrowException(__FILE__, __LINE__, DB_CNNCT_FAIL, "setctx error");
		}

		//��ѯԭҵ��
		iRet = m_Hvrcvexlist.find(selectStr);
		if (RTN_SUCCESS != iRet)
		{
			snprintf(m_szErrMsg, sizeof(m_szErrMsg) - 1, 
				"�յ�����604���ģ�����ԭ����������ҵ���ҵ����Ϣʧ��:[%d]", iRet);
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_FIND_BY_PK_FAIL, m_szErrMsg);        
		}
		iRet = m_Hvrcvexlist.fetch();
    	if(iRet == SQLNOTFOUND)
    	{
    		Trace(L_DEBUG, __FILE__, __LINE__, NULL, "û�д���ȡ������iRet=[%d]",iRet);
    	    //m_cHvtrofacrcvlist.closeCursor();
    	    PMTS_ThrowException(__FILE__, __LINE__, PRM_FAIL, "m_Hvrcvexlistû���ҵ�����������ԭҵ��");
    	}

		//����Ҫ���µ��ֶθ�ֵ
		m_Hvrcvexlist.m_busistate      = m_saps604.PrcSts ; //NPC����״̬	                                       
		m_Hvrcvexlist.m_processcode    = m_saps604.PrcCd  ; //NPC������	                                         
		m_Hvrcvexlist.m_rjctinf        = m_saps604.RjctInf; //NPC�ܾ���Ϣ	                                         	                                         
		m_Hvrcvexlist.m_finalstatedate = m_saps604.SttlmDt; //NPC��������/��̬����	                 	
		m_Hvrcvexlist.m_procstate      = m_strProcSts     ; //����״̬
        Trace(L_INFO,  __FILE__,  __LINE__, NULL, "m_Hvrcvexlist.m_procstate[%s]", m_Hvrcvexlist.m_procstate.c_str());

        m_Hvrcvexlist.closeCursor();
	}
	//add end
	else//����������ͨѶ��
	{
        Trace(L_INFO, __FILE__, __LINE__, NULL, "������������[%s]", m_saps604.OrgnlMT.c_str());
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvSaps604::InsertComsendmb()");

	return RTN_SUCCESS;
}
	
/******************************************************************************
*  Function:   UpdateData
*  Description:���´�����ʻ����ϸ��hv_rcvexchglist
*  Input:      ��
*  Output:     
*  Return:     0   : �����ɹ�,
               ����: ����ʧ��
*  Others:     ��
*  Author:     xlz
*  Date:       2011-03-04
*******************************************************************************/
INT32 CRecvSaps604::UpdateData(void)
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvSaps604::UpdateData()");

	int iRet = RTN_FAIL;
	char strSQL[1024] = {0};
	char sz_TempBal[30];
	STRING strSql;

	if(NULL != strstr(m_saps604.OrgnlMT.c_str(),"111") ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"112" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT100" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT101" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT102" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT103" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT105" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT108" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT121" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT122" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT123" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT124" ) ||
        NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT229" ))
	{
	    if( (NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT108" ) ||
	        NULL != strstr(m_Hvsnddexlist.m_ctgypurpprtry.c_str(),"A105" ))
	        && PROCESS_PR04 == m_saps604.PrcSts)
	    {
	        if( NULL != strstr(m_saps604.OrgnlMT.c_str(),"CMT108" ) )
	        {
	            string strTemp="";
	            GetTagVal(m_OriHvsnddexlist.m_msgid,  m_Hvsnddexlist.m_ustrdstr, "051:");
	            GetTagVal(strTemp,  m_Hvsnddexlist.m_ustrdstr, "005:");
	            char msgno[8 + 1] ={0};
	            sprintf(msgno, "%08d", atoi(strTemp.c_str()));
	            m_OriHvsnddexlist.m_msgid += msgno;
	            
	            strTemp="";
	            GetTagVal(strTemp,  m_Hvsnddexlist.m_ustrdstr, "02B:");
	            m_OriHvsnddexlist.m_msgtp = "CMT" + strTemp; 
	            
	            char *sTableNm = "hv_rcvexchglist";
	            
	            sprintf(strSQL,  " UPDATE %s t SET"
							" t.isrbflg = '1'"
 							" WHERE t.MSGID = '%s'"
							" AND t.MSGTP = '%s' ",
							sTableNm,
							m_OriHvsnddexlist.m_msgid.c_str(),
							m_OriHvsnddexlist.m_msgtp.c_str());
				
				SETCTX(m_OriHvsnddexlist);
            	int iRet = m_OriHvsnddexlist.execsql(strSQL);
            	if(iRet != RTN_SUCCESS)
            	{
            	    sTableNm = "hv_rcvexchglisthis";
            	    memset(strSQL, 0, sizeof(strSQL));
            	    
            	    sprintf(strSQL,  " UPDATE %s t SET"
							" t.isrbflg = '1'"
 							" WHERE t.MSGID = '%s'"
							" AND t.MSGTP = '%s' ",
							sTableNm,
							m_OriHvsnddexlist.m_msgid.c_str(),
							m_OriHvsnddexlist.m_msgtp.c_str());
							
					iRet = m_OriHvsnddexlist.execsql(strSQL);
            	    if(iRet != RTN_SUCCESS)
					{		
                		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸�ԭ֧��ҵ���˻ر�־ʧ��iRet=%d, %s", iRet, m_OriHvsnddexlist.GetSqlErr());
                		PMTS_ThrowException(DB_UPDATE_FAIL);
            	    }
            	}   
	        }
	        else
	        {
	            string strTemp="";
                GetTagVal(m_OriHvsnddexlist.m_msgid,  m_Hvsnddexlist.m_ustrdstr, "/E51/");
                GetTagVal(m_OriHvsnddexlist.m_instgindrctpty,  m_Hvsnddexlist.m_ustrdstr, "/A70/");
                //GetTagVal(m_OriHvsnddexlist.m_msgtp,  m_Hvsnddexlist.m_ustrdstr, "/F40/");
         
	            char *sTableNm = "hv_rcvexchglist"; 
	            sprintf(strSQL,  " UPDATE %s t SET"
							" t.isrbflg = '1'"
 							" WHERE t.MSGID = '%s'"
							" AND t.INSTGINDRCTPTY = '%s' ",
							sTableNm,
							m_OriHvsnddexlist.m_msgid.c_str(),
							m_OriHvsnddexlist.m_instgindrctpty.c_str());
				
				SETCTX(m_OriHvsnddexlist);
            	int iRet = m_OriHvsnddexlist.execsql(strSQL);
            	if(iRet != RTN_SUCCESS)
            	{
            	    sTableNm = "hv_rcvexchglisthis";
            	    memset(strSQL, 0, sizeof(strSQL));
            	    
            	    sprintf(strSQL,  " UPDATE %s t SET"
							" t.isrbflg = '1'"
 							" WHERE t.MSGID = '%s'"
							" AND t.INSTGINDRCTPTY = '%s' ",
							sTableNm,
							m_OriHvsnddexlist.m_msgid.c_str(),
							m_OriHvsnddexlist.m_instgindrctpty.c_str());

					Trace(L_DEBUG,	__FILE__,  __LINE__, NULL, "strSQL = [%s]", strSQL);
					
				    iRet = m_OriHvsnddexlist.execsql(strSQL);
            	    if(iRet != RTN_SUCCESS)
					{		
                		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, "�޸�ԭ֧��ҵ���˻ر�־ʧ��iRet=%d, %s", iRet, m_OriHvsnddexlist.GetSqlErr());
                		//PMTS_ThrowException(DB_UPDATE_FAIL);
            	    }
            	}
	        }
	    }

		iRet = m_Hvsnddexlist.updatestate();
		if (RTN_SUCCESS != iRet)
		{
			snprintf(m_szErrMsg, sizeof(m_szErrMsg) - 1, "update hv_sndexchglist failed[%d][%s]", iRet,m_Hvsnddexlist.GetSqlErr());

			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);

			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
		}

	}
	else if(NULL != strstr(m_saps604.OrgnlMT.c_str(),"141"))
	{
		iRet = m_Hvtrosndlist.updatestate();
		if (RTN_SUCCESS != iRet)
		{	
			snprintf(m_szErrMsg, sizeof(m_szErrMsg) - 1, "update hv_trofacsndlist failed[%d][%s]", iRet,m_Hvtrosndlist.GetSqlErr());
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
		}
	}
	//add by zwc 20171116 
	else if(NULL != strstr(m_saps604.OrgnlMT.c_str(),"115"))
	{
		iRet = m_Hvsnddexlist.updatestate();
		if (RTN_SUCCESS != iRet)
		{	
			snprintf(m_szErrMsg, sizeof(m_szErrMsg) - 1, "update hv_sndexchglist failed[%d][%s]", iRet,m_Hvsnddexlist.GetSqlErr());
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
		}
	}
	//add end
    //add by zwc 20180117
	else if(NULL != strstr(m_saps604.OrgnlMT.c_str(),"118")||
		    NULL != strstr(m_saps604.OrgnlMT.c_str(),"116"))
	{
		iRet = m_Hvrcvexlist.updatestate();
		if (RTN_SUCCESS != iRet)
		{	
			snprintf(m_szErrMsg, sizeof(m_szErrMsg) - 1, "update m_Hvrcvexlist failed[%d][%s]", iRet,m_Hvrcvexlist.GetSqlErr());
			Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
			PMTS_ThrowException(__FILE__, __LINE__, DB_UPDATE_FAIL, m_szErrMsg);
		}
	}
    //add end
	else
	{
		snprintf(m_szErrMsg, sizeof(m_szErrMsg) - 1, 
			"���Ϸ���ԭ��������[%s]",m_saps604.OrgnlMT.c_str());
		Trace(L_ERROR,  __FILE__,  __LINE__, NULL, m_szErrMsg);
		PMTS_ThrowException(__FILE__, __LINE__, DB_OTH_ERR, m_szErrMsg);
	}

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvSaps604::UpdateData()");

	return RTN_SUCCESS;
}

void CRecvSaps604::CheckSign604()
{
	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "entering CRecvSaps604::CheckSign604...");
	
	m_saps604.getOriSignStr();
	
	CheckSign(m_saps604.m_sSignBuff.c_str(),
						m_saps604.m_szDigitSign.c_str(),
						m_saps604.InstgDrctPty.c_str());

	Trace(L_INFO,  __FILE__,  __LINE__, NULL, "leaving CRecvSaps604::CheckSign604...");
}
	

