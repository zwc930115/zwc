/**
 * author:helen 
 * created date:2010.03.04
 */
package com.ylink.cnaps2.hvps.action.payment.search;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.connection.UserSuppliedConnectionProvider;

import com.ylink.cnaps2.ConfigManager;
import com.ylink.cnaps2.ccms.service.CmBankinfoService;
import com.ylink.cnaps2.common.Page;
import com.ylink.cnaps2.common.Pager;
import com.ylink.cnaps2.common.WebUtils;
import com.ylink.cnaps2.common.action.BaseDispatchAction;
import com.ylink.cnaps2.enums.ProcessStateEnum;
import com.ylink.cnaps2.enums.RsFlagEnum;
import com.ylink.cnaps2.enums.SrcFlagEnum;
import com.ylink.cnaps2.hvps.entity.HvRcvexchglist;
import com.ylink.cnaps2.hvps.entity.HvSndRcvexchg_TrofacPO;
import com.ylink.cnaps2.hvps.entity.HvSndexchglist;
import com.ylink.cnaps2.hvps.entity.HvTrofacrcvlist;
import com.ylink.cnaps2.hvps.entity.HvTrofacsndlist;
import com.ylink.cnaps2.hvps.enums.HvBusTypeMap;
import com.ylink.cnaps2.hvps.formbeans.HvSndExchglistForm;
import com.ylink.cnaps2.hvps.service.HvRcvexchglistService;
import com.ylink.cnaps2.hvps.service.HvSndexchglistService;
import com.ylink.cnaps2.hvps.service.HvTrofacrcvlistService;
import com.ylink.cnaps2.hvps.service.HvTrofacsndlistService;
import com.ylink.cnaps2.util.AddonDomainUtil;
import com.ylink.cnaps2.util.DateUtil;
import com.ylink.cnaps2.util.XssUtil;
import com.ylink.cnaps2.util.outputExcel.XlsUtil;
import com.ylink.cnaps2.web.UserSession;

public class HvpsSndRcvSearchAction extends BaseDispatchAction {
	private Logger log = Logger.getLogger(HvpsSndRcvSearchAction.class);

	@Resource
	private HvSndexchglistService hvSndexchglistService;
	@Resource
	private CmBankinfoService cmBankinfoService;
	@Resource
	private HvTrofacsndlistService hvTrofacsndlistService;
	@Resource
	private HvTrofacrcvlistService hvTrofacrcvlistService;
	@Resource
	private HvRcvexchglistService hvRcvexchglistService;
	
	String totalAmount = "0";

	// click "left menu item" to init datas (which are on hvSndExchgSearch.jsp)
	// and then goto hvSndExchgSearch.jsp
	public ActionForward queryUI(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		HvSndExchglistForm hvSndExchglistForm = (HvSndExchglistForm) form;
		XssUtil.filter(hvSndExchglistForm);
		UserSession userSession = UserSession.getUserSession(request);
		String strlog = ".queryUI-->";
		log.debug(strlog + "start:");
		hvSndExchglistForm.setWorkdate(userSession.getHvwkDate());
		hvSndExchglistForm.setRsflag(SrcFlagEnum.RECV.getCode());
		Map hvTypeMap = HvBusTypeMap.map;
		request.setAttribute("hvTypeMap", hvTypeMap);
		request.setAttribute("init", true);
		request.setAttribute("form", hvSndExchglistForm);
		return mapping.findForward("hvSndRcvSearch");
	}

	// click "search " button (which is on hvSndExchgSearch.jsp)to get datas
	// from db and go back to hvSndExchgSearch.jsp
	public ActionForward queryByClickingSearchBtn(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map hvTypeMap = HvBusTypeMap.map;
		request.setAttribute("hvTypeMap", hvTypeMap);
		String strlog = ".queryByClickingSearchBtn--<";
		log.debug(strlog + "start>");

		// get datas from view by hvSndExchglistForm
		HvSndExchglistForm hvSndExchglistForm = (HvSndExchglistForm) form;
		XssUtil.filter(hvSndExchglistForm);

		String strMsgId = hvSndExchglistForm.getMsgid() == null ? ""
				: hvSndExchglistForm.getMsgid().trim();// msgId:报文标志号
		String strWorkdate = hvSndExchglistForm.getWorkdate() == null ? ""
				: hvSndExchglistForm.getWorkdate().trim();// workdate:工作日期

		String strInstgindrctpty = "";
		String strInstdindrctpty = "";

		String strDbtracctid = hvSndExchglistForm.getDbtracctid() == null ? ""
				: hvSndExchglistForm.getDbtracctid().trim();// dbtid:付款方账号
		String strCdtracctid = hvSndExchglistForm.getCdtracctid() == null ? ""
				: hvSndExchglistForm.getCdtracctid().trim();// cdtid:收款方账号
		String strProcstate = hvSndExchglistForm.getProcstate() == null ? ""
				: hvSndExchglistForm.getProcstate().trim();// procstate:处理状态
		String strMsgtp = (hvSndExchglistForm.getMsgtp() == null) ? ""
				: hvSndExchglistForm.getMsgtp().trim();// msgtp:报文类型
		String strRsflag = (hvSndExchglistForm.getRsflag() == null) ? ""
				: hvSndExchglistForm.getRsflag().trim();// rsflag:往来帐标志

		// amount_down:金额下限; amount_up:金额上限
		String strAmount_down = hvSndExchglistForm.getAmount_down();
		String strAmount_up = hvSndExchglistForm.getAmount_up();
		double douAmount_down = 0.0;
		double douAmount_up = 0.0;
		if (!StringUtils.isBlank(strAmount_down)) {
			douAmount_down = Double.parseDouble(strAmount_down);
		}
		if (!StringUtils.isBlank(strAmount_up)) {
			douAmount_up = Double.parseDouble(strAmount_up);
		}

		String sqlBanks = hvSndExchglistForm.getSqlBanks();

		// set Pagation infos:
		int pageSize = ConfigManager.getInstance().getDefaultPageSize();
		int offset = Pager.getPageOffset(request);
		int pageNo = 1;
		if (offset != 0) {
			pageNo = (offset / pageSize) + 1;
		}

		
		Page page = new Page();
		if ("1".equals(strRsflag) || "0".equals(strRsflag)) {// 往帐查询,查询
			// 往帐“当前表”&&往帐"历史表"
			strInstgindrctpty = hvSndExchglistForm.getOdficode();
			strInstdindrctpty = hvSndExchglistForm.getRdficode();
			page = hvSndQuery(hvSndExchglistForm, pageSize, pageNo);
		} else if ("2".equals(strRsflag)) {// 来帐查询,查询 来帐"当前表" && 来帐"历史表"
			strInstgindrctpty = hvSndExchglistForm.getLzodficode();
			strInstdindrctpty = hvSndExchglistForm.getLzrdficode();
			page = hvRcvQuery(hvSndExchglistForm, pageSize, pageNo);
		} else if ("All".equals(strRsflag)) {
			// 全部来往帐
			// TODO
			page = hvAllQuery(request, hvSndExchglistForm, pageSize, pageNo);

		}

		/**
		 * get query datas(hvSndexchglists) from db by these criterias and set
		 * query datas(hvSndexchglists) into Page
		 */

		List<HvSndRcvexchg_TrofacPO> list = (List<HvSndRcvexchg_TrofacPO>) page
				.getResult();
		if (list==null || list.isEmpty()) {
			saveMessage(request, "找不到对应记录");
		}else
		{///计算总交易金额2014年7月28日11:24:45  by xsw
			//totalAmount = "1234";//bpBcoutRecvCLlistService.getSumAmountSqlBy(frm);
		}
		request.setAttribute("hvSndRcvexchg_TrofacPOlists", list);
		request.setAttribute("totalAmount", totalAmount);
		String url = WebUtils.generateSearchURL(request);
		log.debug("1.url=" + url);
		Pager.savePagerInfo(request, offset, pageSize, page.getTotalCount(),
				url);

		// set hvSndexchglists to request scope ,so we can get it in jsp page
		request.setAttribute("form", hvSndExchglistForm);
		log.debug(strlog + "end>");
		return mapping.findForward("hvSndRcvSearch");
	}

	public ActionForward notTtransmitLvbList(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		HvSndExchglistForm hvSndExchglistForm = (HvSndExchglistForm) form;
		UserSession us = UserSession.getUserSession(request);
		String workdate_end = us.getHvwkDate();
		Date parseDate = null;
		parseDate = DateUtil.parse(workdate_end, "yyyyMMdd");
		String workdate_start = DateUtil.format(DateUtil.getnDaysAfter(-10,
				parseDate), "yyyyMMdd");
		if (StringUtils.isBlank(hvSndExchglistForm.getStartworkdate())) {
			hvSndExchglistForm.setStartworkdate(workdate_start);
		}
		if (StringUtils.isBlank(hvSndExchglistForm.getEndworkdate())) {
			hvSndExchglistForm.setEndworkdate(workdate_end);
		}
		hvSndExchglistForm.setLzrdficode(us.getUserBankNo());
		hvSndExchglistForm.setRsflag("2");

		// set Pagation infos:
		int pageSize = ConfigManager.getInstance().getDefaultPageSize();
		int offset = Pager.getPageOffset(request);
		int pageNo = 1;
		if (offset != 0) {
			pageNo = (offset / pageSize) + 1;
		}

		Page page = hvRcvexchglistService.getNotTransmitLvbPage(
				hvSndExchglistForm, pageNo, pageSize);

		List<HvSndRcvexchg_TrofacPO> list = (List<HvSndRcvexchg_TrofacPO>) page
				.getResult();
		request.setAttribute("hvSndRcvexchg_TrofacPOlists", list);

		String url = WebUtils.generateSearchURL(request);
		log.debug("1.url=" + url);
		Pager.savePagerInfo(request, offset, pageSize, page.getTotalCount(),
				url);

		// set hvSndexchglists to request scope ,so we can get it in jsp page
		request.setAttribute("form", hvSndExchglistForm);
		return mapping.findForward("notLvbSearch");
	}

	public ActionForward queuingList(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		HvSndExchglistForm frm = new HvSndExchglistForm();
		UserSession userSession = UserSession.getUserSession(request);
		String endDate = userSession.getHvwkDate();
		Date parseDate = null;
		parseDate = DateUtil.parse(endDate, "yyyyMMdd");
		String startDate = DateUtil.format(DateUtil.getnDaysAfter(-10,
				parseDate), "yyyyMMdd");
		frm.setStartworkdate(startDate);
		frm.setEndworkdate(endDate);
		frm.setProcstate(ProcessStateEnum.QUEUEED.getCode());
		frm.setRsflag(RsFlagEnum.SEND.getCode());
		frm.setOdficode(userSession.getUserBankNo());
		frm.setMsgtp("");
		return this.queryByClickingSearchBtn(mapping, frm, request, response);
	}

	private Page hvAllQuery(HttpServletRequest request,
			HvSndExchglistForm hvSndExchglistForm, int pageSize, int pageNo) {

		Page allPage = hvSndexchglistService.getAll(hvSndExchglistForm,
				pageSize, pageNo);

		// TODO Auto-generated method stub
		return allPage;
	}

	/**
	 * 查询正在排队的业务
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward queryQueuing(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		String strlog = ".queryByClickingSearchBtn--<";
		log.debug(strlog + "start>");

		// get datas from view by hvSndExchglistForm
		HvSndExchglistForm hvSndExchglistForm = (HvSndExchglistForm) form;
		XssUtil.filter(hvSndExchglistForm);
		UserSession us = (UserSession) request.getSession().getAttribute(
				UserSession.USER_SESSION_KEY);
		String noInit = request.getParameter("noInit");
		if (noInit == null) {
			hvSndExchglistForm.setWorkdate(us.getHvwkDate());
			hvSndExchglistForm.setRsflag("0"); // ＭＢ行内　　０、、、、、默认设置为1.客户端
			hvSndExchglistForm.setMsgtp("");
			hvSndExchglistForm.setProcstate(ProcessStateEnum.QUEUEED.getCode());

			hvSndExchglistForm.setOdficode(us.getUserBankNo());
		}

		String strMsgId = hvSndExchglistForm.getMsgid() == null ? ""
				: hvSndExchglistForm.getMsgid().trim();// msgId:报文标志号
		String strWorkdate = hvSndExchglistForm.getWorkdate() == null ? ""
				: hvSndExchglistForm.getWorkdate().trim();// workdate:工作日期
		strWorkdate = DateUtil.getTrimDate(strWorkdate);

		String strInstgindrctpty = "";// instgindrctpty:发起行行号(发起参与机构)
		String strInstdindrctpty = "";// instdindrctpty:接收行行号(接收参与机构)

		String strDbtracctid = hvSndExchglistForm.getDbtracctid() == null ? ""
				: hvSndExchglistForm.getDbtracctid().trim();// dbtid:付款方账号
		String strCdtracctid = hvSndExchglistForm.getCdtracctid() == null ? ""
				: hvSndExchglistForm.getCdtracctid().trim();// cdtid:收款方账号
		String strProcstate = hvSndExchglistForm.getProcstate() == null ? ""
				: hvSndExchglistForm.getProcstate().trim();// procstate:处理状态
		String strMsgtp = (hvSndExchglistForm.getMsgtp() == null) ? ""
				: hvSndExchglistForm.getMsgtp().trim();// msgtp:报文类型
		String strRsflag = (hvSndExchglistForm.getRsflag() == null) ? ""
				: hvSndExchglistForm.getRsflag().trim();// rsflag:往来帐标志

		// amount_down:金额下限; amount_up:金额上限
		String strAmount_down = hvSndExchglistForm.getAmount_down();
		String strAmount_up = hvSndExchglistForm.getAmount_up();
		double douAmount_down = 0.0;
		double douAmount_up = 0.0;
		if (!StringUtils.isBlank(strAmount_down)) {
			douAmount_down = Double.parseDouble(strAmount_down);
		}
		if (!StringUtils.isBlank(strAmount_up)) {
			douAmount_up = Double.parseDouble(strAmount_up);
		}

		String sqlBanks = hvSndExchglistForm.getSqlBanks();

		// just for test
		log.debug(strlog + "1.strAmount_down=" + strAmount_down
				+ "; 2.douAmount_down=" + douAmount_down
				+ "; 3.douAmount_down=" + douAmount_down + "; 4.strAmount_up="
				+ strAmount_up + "; 5.douAmount_up=" + douAmount_up
				+ "; 6.strMsgId=" + strMsgId + "; 7.strWorkdate=" + strWorkdate
				+ "; 8.strInstgindrctpty=" + strInstgindrctpty
				+ "; 9.strInstdindrctpty=" + strInstdindrctpty
				+ "; 10.strDbtracctid=" + strDbtracctid + "; 11.strCdtracctid="
				+ strCdtracctid + "; 12.strProcstate=" + strProcstate
				+ "; 13.strMsgtp =" + strMsgtp + "; 14.strRsflag =" + strRsflag
				+ "; 13.sqlBanks =" + sqlBanks);
		// set Pagation infos:
		int pageSize = ConfigManager.getInstance().getDefaultPageSize();
		int offset = Pager.getPageOffset(request);
		int pageNo = 1;
		if (offset != 0) {
			pageNo = (offset / pageSize) + 1;
		}
		Page page = new Page();
		if ("1".equals(strRsflag) || "0".equals(strRsflag)) {// 往帐查询,查询
			// 往帐“当前表”&&往帐"历史表"
			strInstgindrctpty = hvSndExchglistForm.getOdficode();
			strInstdindrctpty = hvSndExchglistForm.getRdficode();
			page = hvSndQuery(hvSndExchglistForm, pageSize, pageNo);
			BigDecimal totalQueueAmt = hvSndexchglistService
					.getTotalAmt(hvSndExchglistForm);
			request.setAttribute("totalqueueingAmount", totalQueueAmt);
		} else if ("2".equals(strRsflag)) {// 来帐查询,查询 来帐"当前表" && 来帐"历史表"
			strInstgindrctpty = hvSndExchglistForm.getLzodficode();
			strInstdindrctpty = hvSndExchglistForm.getLzrdficode();
			page = hvRcvQuery(hvSndExchglistForm, pageSize, pageNo);
		}
		/**
		 * get query datas(hvSndexchglists) from db by these criterias and set
		 * query datas(hvSndexchglists) into Page
		 */
		@SuppressWarnings("unchecked")
		List<HvSndRcvexchg_TrofacPO> list = (List<HvSndRcvexchg_TrofacPO>) page
				.getResult();

		if (list == null || list.isEmpty()) {
			saveMessage(request, "找不到对应记录");
		}

		String url = WebUtils.generateSearchURL(request);
		log.debug("1.url=" + url);
		Pager.savePagerInfo(request, offset, pageSize, page.getTotalCount(),
				url);

		request.setAttribute("hvSndRcvexchg_TrofacPOlists", list);
		// set hvSndexchglists to request scope ,so we can get it in jsp page
		request.setAttribute("form", hvSndExchglistForm);
		request.setAttribute("noInit", "1");
		return mapping.findForward("queuing");
	}

	// click "details " button (which is on hvSndExchgSearch.jsp)to get datas
	// from db and go back to hvSndExchgSearch.jsp
	public ActionForward queryByClickingDeatisBtn(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String strlog = ".queryByClickingDeatisBtn-->";
		log.debug(strlog + "start:");

		String strMsgid = request.getParameter("msgid") == null ? "" : request
				.getParameter("msgid").trim();// msgId:报文标志号;
		String strMsgtp = request.getParameter("msgtp") == null ? "" : request
				.getParameter("msgtp").trim().toLowerCase();// msgtp:报文类型，hvps.111.001.01,hvps.112.001.01
		String strInstgindrctpty = request.getParameter("instgindrctpty") == null ? ""
				: request.getParameter("instgindrctpty").trim();// instgindrctpty:发起参与机构
		String strRsflag = request.getParameter("rsflag") == null ? ""
				: request.getParameter("rsflag").trim();// 往来帐标志
		String strCDCode = request.getParameter("cdcode") == null ? ""
				: request.getParameter("cdcode").trim();// 借贷标识.二代为CRDT：贷记,DBIT：借记.接收一代报文转换一下对应关系为
		// 0
		// 贷记，1
		// 借记

		log.debug(strlog + "1.strMsgId=" + strMsgid + "; 2.strMsgtp="
				+ strMsgtp + "; 3.strInstgindrctpty=" + strInstgindrctpty
				+ "; 4.strRsflag=" + strRsflag + "; 5.strCDCode=" + strCDCode);

		String strDbtid = "";
		String strCdtid = "";
		// String strInstgdrctpty="";
		String strInstdindrctpty = "";
		String strUstrdstr = "";
		String strCtgypurpprtry = "";
		String strPurpprtry = "";
		String strClrmbid1 = "";// CLRMBID1中介机构1
		String strClrmbid1name = "";// CLRMBID1NAME中介机构1名称
		String strClrmbid2 = "";// CLRMBID2中介机构2
		String strClrmbid2name = "";// CLRMBID2NAME中介机构2名称

		// query data from db//客户汇兑或金融汇兑或一代报文
		if ("hvps.111.001.01".equals(strMsgtp)
				|| "hvps.112.001.01".equals(strMsgtp)
				||"hvps.115.001.01".equals(strMsgtp)
				||"hvps.116.001.01".equals(strMsgtp)
				||"hvps.118.001.01".equals(strMsgtp)
				|| strMsgtp.startsWith("CMT1".toLowerCase())) {
			
			if ("1".equals(strRsflag) || "0".equals(strRsflag)) {// 往帐:0.行内
				// 1.客户端
				HvSndexchglist hvSndexchglistInfo = hvSndexchglistService
						.getSingleHvSndexchglistInfoByPK(strMsgid, strMsgtp,
								strInstgindrctpty);

				if (hvSndexchglistInfo == null) {// 没有查询到纪录，就返回错误的页面
					saveMessage(request, "找不到对应的明细记录");
					return mapping.findForward("forwardErrorDetailPage");
				}

				// 行内信息(保留数据中)
				Map mapreserve = null;
				if (null != hvSndexchglistInfo.getReserve()
						&& !"".equals(hvSndexchglistInfo.getReserve())) {
					// :orimsgsys:REM:orimsgno:111:orimsgtpcd:A100
					mapreserve = AddonDomainUtil
							.getAddonMapForFirstGen(hvSndexchglistInfo
									.getReserve().substring(1));
					request.setAttribute("orimsgsys", mapreserve
							.get("strorimsgsys"));
				}

				request.setAttribute("hvSndexchglistInfo", hvSndexchglistInfo);
				StringBuffer sb = new StringBuffer(1000);
				sb.append(hvSndexchglistInfo.getUstrdstr()).append(":").append(
						hvSndexchglistInfo.getCdtaddinfo()).append(":").append(
						hvSndexchglistInfo.getDbtaddinfo());

				strUstrdstr = sb.toString();
				strDbtid = hvSndexchglistInfo.getDbtid();// dbtid:付款行行号;
				strCdtid = hvSndexchglistInfo.getCdtid();// cdtid:收款行行号
				strInstgindrctpty = hvSndexchglistInfo.getId()
						.getInstgindrctpty();// instgindrctpty:发起参与机构
				strInstdindrctpty = hvSndexchglistInfo.getInstdindrctpty();// instdindrctpty:接收参与机构
				strCtgypurpprtry = hvSndexchglistInfo.getCtgypurpprtry();// ctgypurpprtry:业务类型编码
				strPurpprtry = hvSndexchglistInfo.getPurpprtry();// 业务种类
				strClrmbid1 = hvSndexchglistInfo.getClrmbid1();
				strClrmbid1name = hvSndexchglistInfo.getClrmbid1name();
				strClrmbid2 = hvSndexchglistInfo.getClrmbid2();
				strClrmbid2name = hvSndexchglistInfo.getClrmbid2name();
			} else if ("2".equals(strRsflag)) {// 来帐
				HvRcvexchglist hvRcvexchglistInfo = hvRcvexchglistService
						.getSingleHvRcvexchglistInfoByPK(strMsgid, strMsgtp,
								strInstgindrctpty);

				if (hvRcvexchglistInfo == null) {// 没有查询到纪录，就返回错误的页面
					saveMessage(request, "找不到对应的明细记录");
					return mapping.findForward("forwardErrorDetailPage");

				}

				// 行内信息(保留数据中)
				Map mapreserve = null;
				if (null != hvRcvexchglistInfo.getReserve()
						&& !"".equals(hvRcvexchglistInfo.getReserve())) {
					// :orimsgsys:REM:orimsgno:111:orimsgtpcd:A100
					mapreserve = AddonDomainUtil
							.getAddonMapForFirstGen(hvRcvexchglistInfo
									.getReserve().substring(1));
					request.setAttribute("orimsgsys", mapreserve
							.get("strorimsgsys"));
				}

				request.setAttribute("hvRcvexchglistInfo", hvRcvexchglistInfo);

				strDbtid = hvRcvexchglistInfo.getDbtid();// dbtid:付款行行号;
				strCdtid = hvRcvexchglistInfo.getCdtid();// cdtid:收款行行号
				strInstgindrctpty = hvRcvexchglistInfo.getId()
						.getInstgindrctpty();// instgindrctpty:发起参与机构
				strInstdindrctpty = hvRcvexchglistInfo.getInstdindrctpty();// instdindrctpty:接收参与机构
				strUstrdstr = hvRcvexchglistInfo.getUstrdstr();
				strCtgypurpprtry = hvRcvexchglistInfo.getCtgypurpprtry();// ctgypurpprtry:业务类型编码
				strPurpprtry = hvRcvexchglistInfo.getPurpprtry();// 业务种类
				strClrmbid1 = hvRcvexchglistInfo.getClrmbid1();
				strClrmbid1name = hvRcvexchglistInfo.getClrmbid1name();
				strClrmbid2 = hvRcvexchglistInfo.getClrmbid2();
				strClrmbid2name = hvRcvexchglistInfo.getClrmbid2name();
			} else if ("All".equals(strRsflag)) {
				String code = strCDCode.replace("_", "");
				if ("hvsndexchglist".equals(code.toLowerCase())) {
					HvSndexchglist hvSndexchglistInfo = hvSndexchglistService
							.getSingleHvSndexchglistInfoByPK(strMsgid,
									strMsgtp, strInstgindrctpty);

					if (hvSndexchglistInfo == null) {// 没有查询到纪录，就返回错误的页面
						saveMessage(request, "找不到对应的明细记录");
						return mapping.findForward("forwardErrorDetailPage");
					}

					// 行内信息(保留数据中)
					Map mapreserve = null;
					if (null != hvSndexchglistInfo.getReserve()
							&& !"".equals(hvSndexchglistInfo.getReserve())) {
						// :orimsgsys:REM:orimsgno:111:orimsgtpcd:A100
						mapreserve = AddonDomainUtil
								.getAddonMapForFirstGen(hvSndexchglistInfo
										.getReserve().substring(1));
						request.setAttribute("orimsgsys", mapreserve
								.get("strorimsgsys"));
					}

					request.setAttribute("hvSndexchglistInfo",
							hvSndexchglistInfo);

					strDbtid = hvSndexchglistInfo.getDbtid();// dbtid:付款行行号;
					strCdtid = hvSndexchglistInfo.getCdtid();// cdtid:收款行行号
					strInstgindrctpty = hvSndexchglistInfo.getId()
							.getInstgindrctpty();// instgindrctpty:发起参与机构
					strInstdindrctpty = hvSndexchglistInfo.getInstdindrctpty();// instdindrctpty:接收参与机构
					strUstrdstr = hvSndexchglistInfo.getUstrdstr();
					strCtgypurpprtry = hvSndexchglistInfo.getCtgypurpprtry();// ctgypurpprtry:业务类型编码
					strPurpprtry = hvSndexchglistInfo.getPurpprtry();// 业务种类
					strClrmbid1 = hvSndexchglistInfo.getClrmbid1();
					strClrmbid1name = hvSndexchglistInfo.getClrmbid1name();
					strClrmbid2 = hvSndexchglistInfo.getClrmbid2();
					strClrmbid2name = hvSndexchglistInfo.getClrmbid2name();
				} else if ("hvrcvexchglist".equals(code.toLowerCase())) {
					HvRcvexchglist hvRcvexchglistInfo = hvRcvexchglistService
							.getSingleHvRcvexchglistInfoByPK(strMsgid,
									strMsgtp, strInstgindrctpty);

					if (hvRcvexchglistInfo == null) {// 没有查询到纪录，就返回错误的页面
						saveMessage(request, "找不到对应的明细记录");
						return mapping.findForward("forwardErrorDetailPage");

					}

					// 行内信息(保留数据中)
					Map mapreserve = null;
					if (null != hvRcvexchglistInfo.getReserve()
							&& !"".equals(hvRcvexchglistInfo.getReserve())) {
						// :orimsgsys:REM:orimsgno:111:orimsgtpcd:A100
						mapreserve = AddonDomainUtil
								.getAddonMapForFirstGen(hvRcvexchglistInfo
										.getReserve().substring(1));
						request.setAttribute("orimsgsys", mapreserve
								.get("strorimsgsys"));
					}

					request.setAttribute("hvRcvexchglistInfo",
							hvRcvexchglistInfo);

					strDbtid = hvRcvexchglistInfo.getDbtid();// dbtid:付款行行号;
					strCdtid = hvRcvexchglistInfo.getCdtid();// cdtid:收款行行号
					strInstgindrctpty = hvRcvexchglistInfo.getId()
							.getInstgindrctpty();// instgindrctpty:发起参与机构
					strInstdindrctpty = hvRcvexchglistInfo.getInstdindrctpty();// instdindrctpty:接收参与机构
					strUstrdstr = hvRcvexchglistInfo.getUstrdstr();
					strCtgypurpprtry = hvRcvexchglistInfo.getCtgypurpprtry();// ctgypurpprtry:业务类型编码
					strPurpprtry = hvRcvexchglistInfo.getPurpprtry();// 业务种类
					strClrmbid1 = hvRcvexchglistInfo.getClrmbid1();
					strClrmbid1name = hvRcvexchglistInfo.getClrmbid1name();
					strClrmbid2 = hvRcvexchglistInfo.getClrmbid2();
					strClrmbid2name = hvRcvexchglistInfo.getClrmbid2name();
				}

			}
		} else if ("hvps.141.001.01".equals(strMsgtp)||"cmt232".equals(strMsgtp)||
		    "hvps.141.002.01".equals(strMsgtp)) {// 即时转帐
			if ("1".equals(strRsflag) || "0".equals(strRsflag)) {// 往帐 0.行内
				// 1.客户端
				HvTrofacsndlist hvTrofacsndlistInfo = hvTrofacsndlistService
						.getSingleHvTrofacsndlistInfoByPK(strMsgid,
								strInstgindrctpty);
				if (hvTrofacsndlistInfo == null) {// 没有查询到纪录，就返回错误的页面
					saveMessage(request, "找不到对应的明细记录");
					return mapping.findForward("forwardErrorDetailPage");
				}

				// 行内信息(保留数据中)
				Map mapreserve = null;
				if (null != hvTrofacsndlistInfo.getReserve()
						&& !"".equals(hvTrofacsndlistInfo.getReserve())) {
					// :orimsgsys:REM:orimsgno:111:orimsgtpcd:A100
					mapreserve = AddonDomainUtil
							.getAddonMapForFirstGen(hvTrofacsndlistInfo
									.getReserve().substring(1));
					request.setAttribute("orimsgsys", mapreserve
							.get("strorimsgsys"));
				}

				request
						.setAttribute("hvTrofacsndlistInfo",
								hvTrofacsndlistInfo);

				strDbtid = hvTrofacsndlistInfo.getDbtid();// dbtid:付款行行号;
				strCdtid = hvTrofacsndlistInfo.getCdtid();// cdtid:收款行行号
				strInstgindrctpty = hvTrofacsndlistInfo.getId()
						.getInstgindrctpty();// instgindrctpty:发起参与机构
				strInstdindrctpty = hvTrofacsndlistInfo.getInstdindrctpty();// instgindrctpty:参与机构
				strUstrdstr = hvTrofacsndlistInfo.getUstrdstr();
				strCtgypurpprtry = hvTrofacsndlistInfo.getCtgypurpprtry();// ctgypurpprtry:业务类型编码
				strPurpprtry = hvTrofacsndlistInfo.getPurpprtry();// 业务种类

			} else if ("2".equals(strRsflag)) {// 来帐
				HvTrofacrcvlist hvTrofacrcvlistInfo = hvTrofacrcvlistService
						.getSingleHvTrofacrcvlistInfoByPK(strMsgid,
								strInstgindrctpty, strCDCode);
				if (hvTrofacrcvlistInfo == null) {// 没有查询到纪录，就返回错误的页面
					saveMessage(request, "找不到对应的明细记录");
					return mapping.findForward("forwardErrorDetailPage");
				}

				// 行内信息(保留数据中)
				Map mapreserve = null;
				if (null != hvTrofacrcvlistInfo.getReserve()
						&& !"".equals(hvTrofacrcvlistInfo.getReserve())) {
					// :orimsgsys:REM:orimsgno:111:orimsgtpcd:A100
					mapreserve = AddonDomainUtil
							.getAddonMapForFirstGen(hvTrofacrcvlistInfo
									.getReserve().substring(1));
					request.setAttribute("orimsgsys", mapreserve
							.get("strorimsgsys"));
				}

				request
						.setAttribute("hvTrofacrcvlistInfo",
								hvTrofacrcvlistInfo);

				strDbtid = hvTrofacrcvlistInfo.getDbtid();// dbtid:付款行行号;
				strCdtid = hvTrofacrcvlistInfo.getCdtid();// cdtid:收款行行号
				strInstgindrctpty = hvTrofacrcvlistInfo.getId()
						.getInstgindrctpty();// instgindrctpty:发起参与机构
				strInstdindrctpty = hvTrofacrcvlistInfo.getInstdindrctpty();// instgindrctpty:参与机构
				strUstrdstr = hvTrofacrcvlistInfo.getUstrdstr();
				strCtgypurpprtry = hvTrofacrcvlistInfo.getCtgypurpprtry();// ctgypurpprtry:业务类型编码
				strPurpprtry = hvTrofacrcvlistInfo.getPurpprtry();// 业务种类
			} else if ("All".equals(strRsflag)) { // 所有帐
				String code = strCDCode.replace("_", "");
				if ("hvtrofacsndlist".equals(code.toLowerCase())) {
					HvTrofacsndlist hvTrofacsndlistInfo = hvTrofacsndlistService
							.getSingleHvTrofacsndlistInfoByPK(strMsgid,
									strInstgindrctpty);
					if (hvTrofacsndlistInfo == null) {// 没有查询到纪录，就返回错误的页面
						saveMessage(request, "找不到对应的明细记录");
						return mapping.findForward("forwardErrorDetailPage");
					}

					// 行内信息(保留数据中)
					Map mapreserve = null;
					if (null != hvTrofacsndlistInfo.getReserve()
							&& !"".equals(hvTrofacsndlistInfo.getReserve())) {
						// :orimsgsys:REM:orimsgno:111:orimsgtpcd:A100
						mapreserve = AddonDomainUtil
								.getAddonMapForFirstGen(hvTrofacsndlistInfo
										.getReserve().substring(1));
						request.setAttribute("orimsgsys", mapreserve
								.get("strorimsgsys"));
					}

					request.setAttribute("hvTrofacsndlistInfo",
							hvTrofacsndlistInfo);

					strDbtid = hvTrofacsndlistInfo.getDbtid();// dbtid:付款行行号;
					strCdtid = hvTrofacsndlistInfo.getCdtid();// cdtid:收款行行号
					strInstgindrctpty = hvTrofacsndlistInfo.getId()
							.getInstgindrctpty();// instgindrctpty:发起参与机构
					strInstdindrctpty = hvTrofacsndlistInfo.getInstdindrctpty();// instgindrctpty:参与机构
					strUstrdstr = hvTrofacsndlistInfo.getUstrdstr();
					strCtgypurpprtry = hvTrofacsndlistInfo.getCtgypurpprtry();// ctgypurpprtry:业务类型编码
					strPurpprtry = hvTrofacsndlistInfo.getPurpprtry();// 业务种类
				} else {
					HvTrofacrcvlist hvTrofacrcvlistInfo = hvTrofacrcvlistService
							.getSingleHvTrofacrcvlistInfoByPK(strMsgid,
									strInstgindrctpty, strCDCode);
					if (hvTrofacrcvlistInfo == null) {// 没有查询到纪录，就返回错误的页面
						saveMessage(request, "找不到对应的明细记录");
						return mapping.findForward("forwardErrorDetailPage");
					}

					// 行内信息(保留数据中)
					Map mapreserve = null;
					if (null != hvTrofacrcvlistInfo.getReserve()
							&& !"".equals(hvTrofacrcvlistInfo.getReserve())) {
						// :orimsgsys:REM:orimsgno:111:orimsgtpcd:A100
						mapreserve = AddonDomainUtil
								.getAddonMapForFirstGen(hvTrofacrcvlistInfo
										.getReserve().substring(1));
						request.setAttribute("orimsgsys", mapreserve
								.get("strorimsgsys"));
					}

					request.setAttribute("hvTrofacrcvlistInfo",
							hvTrofacrcvlistInfo);

					strDbtid = hvTrofacrcvlistInfo.getDbtid();// dbtid:付款行行号;
					strCdtid = hvTrofacrcvlistInfo.getCdtid();// cdtid:收款行行号
					strInstgindrctpty = hvTrofacrcvlistInfo.getId()
							.getInstgindrctpty();// instgindrctpty:发起参与机构
					strInstdindrctpty = hvTrofacrcvlistInfo.getInstdindrctpty();// instgindrctpty:参与机构
					strUstrdstr = hvTrofacrcvlistInfo.getUstrdstr();
					strCtgypurpprtry = hvTrofacrcvlistInfo.getCtgypurpprtry();// ctgypurpprtry:业务类型编码
					strPurpprtry = hvTrofacrcvlistInfo.getPurpprtry();// 业务种类
				}
			}
		}

		log.debug(strlog + "1.strDbtid=" + strDbtid + "; 2.strCdtid="
				+ strCdtid + "; 3.strInstgindrctpty=" + strInstgindrctpty
				+ "; 4.strInstdindrctpty=" + strInstdindrctpty
				+ "; 5.strUstrdstr =" + strUstrdstr + "; 6.strCtgypurpprtry="
				+ strCtgypurpprtry + "; 7.strPurpprtry=" + strPurpprtry);

		// get 付款行行名
		String strDbtBankName = cmBankinfoService.getBankNameBy(strDbtid);
		log.debug(strlog + "1.strDbtBankName=" + strDbtBankName);
		request.setAttribute("strDbtBankName", strDbtBankName);

		// get 收款行行名
		String strCdtBankName = cmBankinfoService.getBankNameBy(strCdtid);
		log.debug(strlog + "1.strCdtBankName=" + strCdtBankName);
		request.setAttribute("strCdtBankName", strCdtBankName);

		// get 发起行行名
		String strInstgindrctptyName = cmBankinfoService
				.getBankNameBy(strInstgindrctpty);
		log.debug(strlog + "1.strInstgindrctptyName=" + strInstgindrctptyName);
		request.setAttribute("strInstgindrctptyName", strInstgindrctptyName);

		// get 接收行行名
		String strInstdindrctptyName = cmBankinfoService
				.getBankNameBy(strInstdindrctpty);
		log.debug(strlog + "1.strInstdindrctptyName=" + strInstdindrctptyName);
		request.setAttribute("strInstdindrctptyName", strInstdindrctptyName);

		// get 中介机构1
		request.setAttribute("clrmbid1", strClrmbid1);
		// get 中介机构1名字
		request.setAttribute("clrmbid1name", strClrmbid1name);
		// get 中介机构2
		request.setAttribute("clrmbid2", strClrmbid2);
		// get 中介机构2名字
		request.setAttribute("clrmbid2name", strClrmbid2name);

		String strForwardPageName = "";
		if ("All".equals(strRsflag)) {
			strForwardPageName = goToPageBy(strMsgtp, strCtgypurpprtry,
					strPurpprtry, strUstrdstr, strRsflag, request, strCDCode
							.replace("_", ""));
		} else {
			// goto different page according to ctgypurpprtry(业务类型编码) and
			// msgtp(报文类型)
			strForwardPageName = goToPageBy(strMsgtp, strCtgypurpprtry,
					strPurpprtry, strUstrdstr, strRsflag, request);
		}
		log.debug(strlog + "strForwardPageName=" + strForwardPageName);

		if ("forwardErrorDetailPage".equals(strForwardPageName)) {
			saveMessage(request, "找不到对应的明细页面，请检查明细路径！");
		}

		log.debug(strlog + "end");
		return mapping.findForward(strForwardPageName);
	}

	/**
	 * for 来帐: if is "客户汇兑业务"报文or"金融汇兑业务"报文,then query HV_RCVEXCHGLIST表 和
	 * HV_RCVEXCHGLISTHIS表; else if "即时转帐业务"报文,then query
	 * HV_TROFACSNDLIST表和HV_TROFACSNDLISTHIS表 else if "客户汇兑业务"报文or"金融汇兑业务" or
	 * "即时转帐业务"报文,then query HV_TROFACSNDLIST和HV_RCVEXCHGLIST表
	 * 
	 * @param sqlBanks
	 *            TODO
	 */

	private Page hvRcvQuery(HvSndExchglistForm form, int pageSize, int pageNo) {

		String strlog = "hvRcvQuery--<";
		log.debug(strlog + "start>");
		Page page = new Page();
		String strMsgtp = form.getMsgtp();

		// "客户汇兑业务"报文or"金融汇兑业务"报文
		if ("hvps.111.001.01".equals(strMsgtp)
				||"hvps.112.001.01".equals(strMsgtp)
				||"hvps.115.001.01".equals(strMsgtp)
				||"hvps.116.001.01".equals(strMsgtp)
				||"hvps.118.001.01".equals(strMsgtp)
				|| strMsgtp.startsWith("CMT") || "".equals(strMsgtp)) {
			if ("CMT232".equals(strMsgtp)) {
				page = hvTrofacrcvlistService.getHvTrofacrcvlistInfoBy(form,
						pageNo, pageSize);
				if (page.getTotalCount()>0) {
					totalAmount = hvTrofacrcvlistService.getSumAmount(form);
				}
				
			} else {
				page = hvRcvexchglistService.getHvRcvexchglistInfoBy(form,
						pageNo, pageSize);
				if (page.getTotalCount()>0) {
					totalAmount = hvRcvexchglistService.getSumAmount(form);
				}
			}
			// for "即时转帐业务"报文,query HV_TROFACSNDLIST表
		} else if ("hvps.141.001.01".equals(strMsgtp)||
		    "hvps.141.002.01".equals(strMsgtp)) {
			page = hvTrofacrcvlistService.getHvTrofacrcvlistInfoBy(form,
					pageNo, pageSize);
			if (page.getTotalCount()>0) {
				totalAmount = hvTrofacrcvlistService.getSumAmount(form);
			}
		}
		return page;
	}

	/**
	 * for 往帐: if is "客户汇兑业务"报文or"金融汇兑业务" or "一代" 报文,then query
	 * HV_SNDEXCHGLIST表和HV_SNDEXCHGLISTHIS表; else if "即时转帐业务"报文,then query
	 * HV_TROFACSNDLIST表和HV_TROFACSNDLIST表
	 * 
	 * @param sqlBanks
	 *            TODO
	 * @param srcFlag
	 *            TODO
	 */
	private Page hvSndQuery(HvSndExchglistForm form, int pageSize, int pageNo) {
		log.debug("hvSndQuery -->");
		String strMsgtp = form.getMsgtp();
		Page page = new Page();
		if ("hvps.111.001.01".equals(strMsgtp)
				|| "hvps.112.001.01".equals(strMsgtp)
				||"hvps.115.001.01".equals(strMsgtp)
				||"hvps.116.001.01".equals(strMsgtp)
				||"hvps.118.001.01".equals(strMsgtp)
				|| strMsgtp.startsWith("CMT") || "".equals(strMsgtp)) {
			if ("CMT232".equals(strMsgtp)) {
				page = hvTrofacsndlistService.getHvTrofacsndlistInfoBy(form,
						pageNo, pageSize);
				if (page.getTotalCount()>0) {
					totalAmount = hvTrofacsndlistService.getSumAmount(form);
				}
			} else {
				page = hvSndexchglistService.getHvSndexchglistInfoBy(form,
						pageNo, pageSize);
				if (page.getTotalCount()>0) {
					totalAmount = hvSndexchglistService.getSumAmount(form);
				}
			}
		} else if ("hvps.141.001.01".equals(strMsgtp)||
		    "hvps.141.002.01".equals(strMsgtp)) {
			page = hvTrofacsndlistService.getHvTrofacsndlistInfoBy(form,
					pageNo, pageSize);
			if (page.getTotalCount()>0) {
				totalAmount = hvTrofacsndlistService.getSumAmount(form);
			}
		}
		return page;
	}

	// strMsgtp:报文类型； strCtgypurpprtry:业务类型编码；
	private String goToPageBy(String strMsgtp, String strCtgypurpprtry,
			String strPurpprtry, String strUstrdstr, String strRsflag,
			HttpServletRequest request) {
		String strlog = ".goToPageBy-->";
		log.debug(strlog + "start:");

		strMsgtp = strMsgtp == null ? "" : strMsgtp.trim();
		strCtgypurpprtry = strCtgypurpprtry == null ? "" : strCtgypurpprtry
				.trim();
		strPurpprtry = strPurpprtry == null ? "" : strPurpprtry.trim();
		log.debug(strlog + "1.strMsgtp=" + strMsgtp + "; 2.strCtgypurpprtry="
				+ strCtgypurpprtry + "; 3.strPurpprtry=" + strPurpprtry);

		String strForwardPageName = "forwardErrorDetailPage";
		String strAddonMap = "";
		String strAddonToken = "";

		String strSndRcvToken = "";
		if ("1".equals(strRsflag) || "0".equals(strRsflag)) {// 往帐:0行内,1.客户端
			strSndRcvToken = "Snd";
		} else if ("2".equals(strRsflag)) {// 来帐
			strSndRcvToken = "Rcv";
		}

		// get additional datas which fields not exist in db
		Map<String, String> addonMap = new HashMap<String, String>();
		if (strMsgtp.startsWith("hvps")) {// for the second generation
			addonMap = AddonDomainUtil.getAddonMap(strUstrdstr);
		} else if (strMsgtp.startsWith("CMT".toLowerCase())) {// for the first
			// generation
			addonMap = AddonDomainUtil.getAddonMapForFirstGen(strUstrdstr);
		}

		if ("hvps.111.001.01".equals(strMsgtp)) {// 1.hvps.111.001.01:客户发起汇兑业务报文
			strForwardPageName = "hvps111" + strSndRcvToken + "Dtl";
			// 附加数据: A100(汇兑业务); A105(退汇); A201(支票);
			// A202(城市商业银行汇票资金汇划)，A203(银行汇票)
			strAddonMap = "ustrdstr" + strCtgypurpprtry + "Map";
			strAddonToken = "Hv111_" + strCtgypurpprtry + strSndRcvToken
					+ "Addon";
		} else if ("hvps.112.001.01".equals(strMsgtp)) {// 2.hvps.112.001.01:金融机构发起汇兑业务报文
			strForwardPageName = "hvps112" + strSndRcvToken + "Dtl";
			// 附加数据：A100,A105,A201,A202,A307
			strAddonMap = "ustrdstrHvps112Map";
			strAddonToken = "Hv112_" + strCtgypurpprtry + strSndRcvToken
					+ "Addon";
		} else if ("hvps.115.001.01".equals(strMsgtp)) {// 2.hvps.115.001.01:金融机构发起汇兑业务报文
			strForwardPageName = "hvps115" + strSndRcvToken + "Dtl";
			// 附加数据：A100,A105,A201,A202,A307
			strAddonMap = "ustrdstrHvps115Map";
			strAddonToken = "Hv115_" + strCtgypurpprtry + strSndRcvToken
					+ "Addon";
		} else if  ("hvps.116.001.01".equals(strMsgtp)) {// 2.hvps.116.001.01:金融机构发起汇兑业务报文
			strForwardPageName = "hvps116" + strSndRcvToken + "Dtl";
			// 附加数据：A100,A105,A201,A202,A307
			strAddonMap = "ustrdstrHvps115Map";
			strAddonToken = "Hv116_" + strCtgypurpprtry + strSndRcvToken
					+ "Addon";
		} else if  ("hvps.118.001.01".equals(strMsgtp)) {// 2.hvps.118.001.01:金融机构发起汇兑业务报文
			strForwardPageName = "hvps118" + strSndRcvToken + "Dtl";
			// 附加数据：A100,A105,A201,A202,A307
			strAddonMap = "ustrdstrHvps118Map";
			strAddonToken = "Hv118_" + strCtgypurpprtry + strSndRcvToken
					+ "Addon";
		}else if("hvps.141.001.01".equals(strMsgtp)||"cmt232".equals(strMsgtp)||
		    "hvps.141.001.01".equals(strMsgtp)) {// 3.hvps.141.001.01:即时转账报文
			strForwardPageName = "trofac" + strSndRcvToken + "Dtl";
			// 附加数据：
			strAddonMap = "ustrdstrMap";
			strAddonToken = "Hv141_" + strCtgypurpprtry + strSndRcvToken
					+ "Addon";
			if ("G109".equals(strCtgypurpprtry)) {
				strAddonToken = "Hv141_" + strCtgypurpprtry + "_"
						+ strPurpprtry + strSndRcvToken + "Addon";
			}
		} else if (strMsgtp.startsWith("CMT1".toLowerCase())) {// for the first
			// generation
			strForwardPageName = "cmt" + strSndRcvToken + "Dtl";
			// 附加数据：cmt101; CMT102; CMT105; CMT108
			strAddonMap = "ustrdstr" + strMsgtp.toUpperCase() + "Map";
			strAddonToken = strMsgtp.toUpperCase() + strSndRcvToken + "Addon";
		}

		log.debug(strlog + "1.strForwardPageName=" + strForwardPageName
				+ "; 2.strAddonMap=" + strAddonMap + "; 3.strAddonToken="
				+ strAddonToken);
		request.setAttribute(strAddonMap, addonMap);
		request.setAttribute("addonToken", strAddonToken);
		return strForwardPageName;
	}

	// 当往来账标志为全部的时候跳转页面
	private String goToPageBy(String strMsgtp, String strCtgypurpprtry,
			String strPurpprtry, String strUstrdstr, String strRsflag,
			HttpServletRequest request, String strCDCode) {

		if ("hvsndexchglist".equals(strCDCode.toLowerCase())
				|| "hvtrofacsndlist".equals(strCDCode.toLowerCase())) {
			return this.goToPageBy(strMsgtp, strCtgypurpprtry, strPurpprtry,
					strUstrdstr, "1", request);
		} else if ("hvrcvexchglist".equals(strCDCode.toLowerCase())) {
			return this.goToPageBy(strMsgtp, strCtgypurpprtry, strPurpprtry,
					strUstrdstr, "2", request);
		} else {
			return this.goToPageBy(strMsgtp, strCtgypurpprtry, strPurpprtry,
					strUstrdstr, "2", request);
		}
	}

}
