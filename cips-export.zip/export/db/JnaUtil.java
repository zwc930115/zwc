package com.ylink.export.db;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Pointer;

public class JnaUtil {

	public interface Clibrary extends Library {
		Clibrary INSTANTCE = (Clibrary) Native.loadLibrary("ccps.3des", Clibrary.class);
		
		int Crypt3Des(int type, String in, String key, Pointer out);
		
		int Crypt3Des(int type, String in, String key, byte[] out);
	}
	
	public static String jnaCall(String cipherText) {
		if (cipherText == null || cipherText.trim().length() == 0) {
			return null;
		}
		
		String key = "1234678abcedfa197abceef1398772effaabceffe980764e";
		byte[] out = new byte[cipherText.length()];
		
		Clibrary.INSTANTCE.Crypt3Des(1, cipherText, key, out);
		
		return new String(out).trim();
	}
}
