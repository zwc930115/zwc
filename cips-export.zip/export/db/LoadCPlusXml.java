package com.ylink.export.db;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoadCPlusXml {
	
	private Logger log = LoggerFactory.getLogger(LoadCPlusXml.class);

	
	private String passWord;
	
	/**密码类型:0,明文;1,密文*/
	private String passWordTp;
	
	public void init() throws Exception {
		getJdbcProp();
		
		encrypt();
		
	}
	
	
	public void getJdbcProp(){
		log.info("开始加载JDBC参数");
		InputStream in = null;
		try {
			in = new FileInputStream("configure/properties/jdbc.properties");
			Properties p = new Properties();
			p.load(in);
			passWordTp = p.getProperty("jdbc.passwordType");
			passWord = p.getProperty("jdbc.password");
		} catch (Exception e) {
			e.printStackTrace();
			log.error("加载JDBC参数异常：" + e.getMessage());
		}finally{
			if(null != in){
				try {
					in.close();
				} catch (IOException e) {
				}
			}
		}
	}
	
	public void encrypt() {
		log.info("开始执行数据库密码解密操作");
		/**0,明文;1,密文*/
		if (passWordTp != null && passWordTp.trim().length() != 0) {
			if (passWordTp.equals("0")) {
				log.info("当前数据库密码格式为明文，不做解密操作");
			} else if (passWordTp.equals("1")) {
				log.info("当前数据库密码格式为密文，执行解密操作");
				if(null != passWord && passWord.trim().length() != 0){
					passWord = JnaUtil.jnaCall(passWord);
					log.info("数据库密码解密成功[{}]", passWord);
					//passWord = "cipss";
				}else{
					log.error("获取jdbc.properties_jdbc.password数据库密码为空");
				}
			} else{
				log.error("jdbc.properties_jdbc.passwordType数据内容配置错误");
			}
		} else {
			log.error("获取jdbc.properties_jdbc.passwordType数据密码格式为空，默认不做解密操作");
		}
	}


	public String getPassWord() {
		return passWord;
	}


	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}


	public String getPassWordTp() {
		return passWordTp;
	}


	public void setPassWordTp(String passWordTp) {
		this.passWordTp = passWordTp;
	}
}
