package com.ylink.export.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class DBPool {

	private static Logger log = LoggerFactory.getLogger(DBPool.class);
	
	private static ComboPooledDataSource dataSource;
	
	private static long timeout = 3000L;
	
	private static long slice = 200L;

	public static Connection getConn() throws SQLException {
		Connection conn = null;
		int tryTimes = 0;
		try {
			tryTimes++;
			conn = dataSource.getConnection();
		} catch(Exception e) {
			log.error("第[{}]次获取数据库连接失败:{},将在[{}ms]内继续尝试连接", 
					tryTimes, e.getMessage(), timeout);
			e.printStackTrace();
		}
		int wait = 0;
		while (conn == null && wait < timeout) {
			try {
				Thread.sleep(slice);
				wait += slice;
			} catch(Exception e) {
				log.error("Thread hold 失败:{}", e.getMessage());
				e.printStackTrace();
			}
			try {
				tryTimes++;
				conn = dataSource.getConnection();
			} catch(Exception e) {
				log.error("第[{}]次获取数据库连接失败:{},将在[{}ms]内继续尝试连接", 
						tryTimes, e.getMessage(), timeout-wait);
				e.printStackTrace();
			}
		}
		return conn;
	}

	public ComboPooledDataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(ComboPooledDataSource dataSource) {
		DBPool.dataSource = dataSource;
	}
	
	public static long getTimeout() {
		return timeout;
	}

	public static void setTimeout(long timeout) {
		DBPool.timeout = timeout;
	}

	public static void releaseResourceAndAutoCommit(ResultSet rs,
		PreparedStatement stmt, Connection conn) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.setAutoCommit(true);
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
	}
	
	public static void releaseResource(PreparedStatement pst, Connection conn) {
		releaseResource(null, pst, conn);
	}

	public static void releaseResource(ResultSet rs, PreparedStatement pst, Connection conn) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				log.error("释放结果集ResultSet失败:{}", e.getMessage());
				e.printStackTrace();
			}
		}
		
		if (pst != null) {
			try {
				pst.close();
			} catch (SQLException e) {
				log.error("释放PreparedStatement失败:{}", e.getMessage());
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				log.error("释放Connection失败:{}", e.getMessage());
				e.printStackTrace();
			}
			
		}
	}

	public static void releaseResourceAndAutoCommit(
			PreparedStatement stmt, Connection conn) {
		releaseResourceAndAutoCommit(null, stmt, conn);
	}
	
	public static void destroy() {
		if (dataSource != null) {
			dataSource.close();
		}
	}
}
