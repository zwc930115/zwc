package com.ylink.export.db;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ylink.export.annotation.Column;

public class DBUtil {
	
	private static Logger log = LoggerFactory.getLogger(DBUtil.class);
	
	
	public static Connection getConn(){
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			log.error("加载数据库驱动异常：" + e.getMessage());
		}

		try {
			conn = DriverManager.getConnection("jdbc:oracle:thin:@172.168.65.164:1521:pdborcl", "cipstest", "cipstest");
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("获取数据库连接异常");
		}
		return conn;
	}

 	public static <T> List<T> selectListBySql(Class<T> clzz,String sql,Object... args){
		Field[] fields = null;
		try {
			fields = clzz.getDeclaredFields();
		} catch(Exception e) {
			log.error("获取类[{}]的属性失败:{}", clzz.toString(), e.getMessage());
			e.printStackTrace();
			return null;
		}
		if (fields == null || fields.length == 0) {
			log.warn("类[{}]属性为空,无可进行操作", clzz.toString());
			return null;
		}
		/**数据库操作*/
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<T> list = null;
		try {
			log.info("获取数据库连接");
			conn = DBPool.getConn();
			if (conn == null) {
				return null;
			}
			log.info("编译SQL[{}]", sql.toString());
			pst = conn.prepareStatement(sql.toString());
			log.info("装配属性值[{}]", Arrays.toString(args));
			if(null != args && args.length >0){
				for (int i=0; i<args.length; i++) {
					pst.setObject(i+1, args[i]);
				}
			}
			rs = pst.executeQuery();
			log.info("数据库操作成功");
			ResultSetMetaData rsmd = rs.getMetaData();
			int colNum = rsmd.getColumnCount();
			list = new ArrayList<T>();
			String colName = "" ;
			while (rs.next()) {
				/**对象赋值*/
				T obj = clzz.newInstance();
				for (int i=1; i<=colNum; ++i) {
					for (int j=0; j<fields.length; ++j) {
						Field f = fields[j];
						Column anno = f.getAnnotation(Column.class) ;
						if(anno != null){
							colName = anno.name() ;
						}else{
							colName = f.getName() ;
						}
						if (colName.equalsIgnoreCase(rsmd.getColumnLabel(i))) {
							Object value = rs.getObject(i);
							if (value instanceof BigDecimal) {
								String type = f.getType().getSimpleName();
								if (!BigDecimal.class.getSimpleName().equals(type)) {
									BigDecimal bigDecimal = (BigDecimal) value;
									if (type.equals(Integer.class.getSimpleName())) {
										value = bigDecimal.intValue();
									} else if (type.equals(Long.class.getSimpleName())) {
										value = bigDecimal.longValue();
									} else if (type.equals(String.class.getSimpleName())) {
										value = bigDecimal.toPlainString();
									}
								}
							}
							boolean flag = f.isAccessible();
							f.setAccessible(true);
							f.set(obj, value);
							f.setAccessible(flag);
						}
					}
				}
				list.add(obj);
			}
		} catch (Exception e) {
			log.error("执行SQL语句[{}]失败:{}", sql.toString(), e.getMessage());
			e.printStackTrace();
		} finally {
			DBPool.releaseResource(rs, pst, conn);
		}
		return list;
	}
}
