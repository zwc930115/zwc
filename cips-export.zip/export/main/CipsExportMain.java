package com.ylink.export.main;

import java.util.concurrent.TimeUnit;

import org.slf4j.LoggerFactory;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.core.joran.spi.JoranException;
import ch.qos.logback.core.util.StatusPrinter;

import com.ylink.export.util.SpringUtil;

public class CipsExportMain {

	private static String runChl = "CCPSExport";
	
	public static void main(String[] args) {
		
		if (args != null && args.length != 0) {
			String runNode = args[0];
			if (runNode != null && runNode.equalsIgnoreCase("CCPSCOMM2")) {
				runChl = "CCPSCOMM2";
			} else {
				runChl = "CCPSCOMM1";
			}
		}
		
		initLogback();
		
		AbstractApplicationContext context = new FileSystemXmlApplicationContext(
				"configure/spring/spring.xml"/*, "resources/spring/spring-mq.xml"*//*,
				"resources/spring/spring-scheduler.xml"*/);
		
		SpringUtil.ctx = context;
		
		while (true) {
			try {
				TimeUnit.MILLISECONDS.sleep(10000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void initLogback() {
		
		LoggerContext lc = (LoggerContext) LoggerFactory.getILoggerFactory();

		JoranConfigurator configurator = new JoranConfigurator();
		
		configurator.setContext(lc);

		lc.reset();

		try {
			configurator.doConfigure("configure/logback/logback.xml");
		} catch (JoranException e) {
			System.out.println("初始化logback失败: " + e.getMessage());
			e.printStackTrace();
		}
		
		StatusPrinter.printInCaseOfErrorsOrWarnings(lc);
		StatusPrinter.print(lc);
	}

	public static String getRunChl() {
		return runChl;
	}

	public void setRunChl(String runChl) {
		CipsExportMain.runChl = runChl;
	}
}
