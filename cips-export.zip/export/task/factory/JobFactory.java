package com.ylink.export.task.factory;

import org.quartz.Job;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class JobFactory implements FactoryBean<JobDetail>, 
		BeanNameAware, ApplicationContextAware, InitializingBean {
	
	private String name;
	private String group;
	private Class<? extends Job> jobClass;
	//private JobDataMap jobDataMap = new JobDataMap();
	private JobDataMap jobDataMap;
	private boolean durability = true;
	private boolean requestsRecovery = false;
	private String description;
	private String beanName;
	private ApplicationContext applicationContext;
	private String applicationContextJobDataKey;
	private JobDetail jobDetail;
	
	@Override
	public void afterPropertiesSet() {
		
		if (this.name == null) {
			this.name = this.beanName;
		}

		if (this.group == null) {
			this.group = "DEFAULT";
		}

		JobBuilder jobBuilder = JobBuilder
				.newJob(this.jobClass)
				.withIdentity(this.name, this.group)
				.requestRecovery(this.requestsRecovery)
				.storeDurably(this.durability)
				.withDescription(this.description);

		this.jobDetail = jobBuilder.build();
		
		//jobDataMap.put("jobClass", jobClass);
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public Class<? extends Job> getJobClass() {
		return jobClass;
	}

	public void setJobClass(Class<? extends Job> jobClass) {
		this.jobClass = jobClass;
	}

	public JobDataMap getJobDataMap() {
		return jobDataMap;
	}

	public void setJobDataMap(JobDataMap jobDataMap) {
		this.jobDataMap = jobDataMap;
	}

	public boolean isDurability() {
		return durability;
	}

	public void setDurability(boolean durability) {
		this.durability = durability;
	}

	public boolean isRequestsRecovery() {
		return requestsRecovery;
	}

	public void setRequestsRecovery(boolean requestsRecovery) {
		this.requestsRecovery = requestsRecovery;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getApplicationContextJobDataKey() {
		return applicationContextJobDataKey;
	}

	public void setApplicationContextJobDataKey(String applicationContextJobDataKey) {
		this.applicationContextJobDataKey = applicationContextJobDataKey;
	}

	public JobDetail getJobDetail() {
		return jobDetail;
	}

	public void setJobDetail(JobDetail jobDetail) {
		this.jobDetail = jobDetail;
	}

	public String getBeanName() {
		return beanName;
	}

	public ApplicationContext getApplicationContext() {
		return applicationContext;
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		this.applicationContext = applicationContext;
	}

	@Override
	public void setBeanName(String beanName) {
		this.beanName = beanName;
	}

	@Override
	public JobDetail getObject() {
		return this.jobDetail;
	}

	@Override
	public Class<?> getObjectType() {
		return JobDetail.class;
	}

	@Override
	public boolean isSingleton() {
		return true;
	}
}
