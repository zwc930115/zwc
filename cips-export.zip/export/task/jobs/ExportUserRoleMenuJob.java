package com.ylink.export.task.jobs;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ylink.export.db.DBUtil;
import com.ylink.export.util.Constant;
import com.ylink.export.util.Dictionaries;
import com.ylink.export.util.JavaExecUtil;
import com.ylink.export.util.SFTPUtil;
import com.ylink.export.util.ftp.SFTPBean;
import com.ylink.export.util.ftp.SFTPUtils;
import com.ylink.export.util.pojo.UserRoleMenuPojo;

/**
 * 定时导出用户权限数据
 */
@DisallowConcurrentExecution
public class ExportUserRoleMenuJob implements Job {
	
	private Logger log = LoggerFactory.getLogger(ExportUserRoleMenuJob.class);

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {

		String cuurTime = new SimpleDateFormat("yyyyMMDD").format(new Date());
		if(!new File(Constant.localFilePath + cuurTime).exists()){
			try {
				String dateString = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
				String tarName = "HBAP-CN-A-HTSAHBCNCIPS-01.grmrdata." + dateString;
				String filePath = Constant.localFilePath + tarName;
				
				//1、判断文件信息
				isExsitFilePath(new File(Constant.localFilePath));
				
				//2、新建文件存放目录
				new File(filePath).mkdir();
				//3、导出文件
				exprotFile(filePath);

				//JavaExecUtil.execCmd("pwd");
				//跳转到文件目录
				String cdCmd = "cd "+filePath+"/";
				log.info("cdCmd[{}]", cdCmd);
				//JavaExecUtil.execCmd(cdCmd);

				
				//4、压缩目标文件为tar包
				String cmd = "tar -cvf "+ filePath +".tar -C "+filePath+" .";
				log.info("开始压缩tar文件[{}]", cmd);
				JavaExecUtil.execCmd(cmd);
				log.info("压缩tar文件完毕："+ filePath + ".tar");
				
				log.info("开始上传文件：" + filePath + ".tar");
				//5、上传SFTP
				SFTPUtil.upload4RSA(filePath + ".tar");
				log.info("文件上传成功");
				
				//6、在当前目录下新建当前日期目录，代表当天文件已生成
				new File(Constant.localFilePath + new SimpleDateFormat("yyyyMMDD").format(new Date())).mkdir();
			} catch (Exception e) {
				e.printStackTrace();
				log.error("导出用户角色权限数据异常：" + e.getMessage());
			}
		}else{
			log.info("[{}],当日文件已成功导出并上传成功，不再重复生成", cuurTime);
		}
	}
	

	public void exprotFile(String filePaht) {
		exportUserData(filePaht);
		exprotUserRoleDate(filePaht);
		exprotRoleMenuPojo(filePaht);
	}

	/**
	 * 导出用户数据
	 * @param filePath
	 */
	public void exportUserData(String filePath){
		log.info("开始导出用户数据");
		String querySql = "select a.accountname as accountname,a.lastlogintime as lastlogintime," +
				"a.username as createusername,a.createDate as createDate,a.userstate as userstate from TSYS_USER a" +
				",Tsys_Role b,Tsys_User_Role c " +
				"where a.id = c.user_id and b.id = c.role_id";
		int num = 0;
		List<UserRoleMenuPojo> userList = DBUtil.selectListBySql(
				UserRoleMenuPojo.class, querySql);
		if (userList == null || userList.isEmpty()) {
			log.error("查询系统用户信息数据为空");
		}
		log.info("过滤前用户数据条数：" + userList.size());
		
		Map<String, UserRoleMenuPojo> map = new HashMap<String, UserRoleMenuPojo>();
		for (UserRoleMenuPojo userPojo : userList) {
			map.put(userPojo.getAccountname(), userPojo);
		}

		List<UserRoleMenuPojo> list = new ArrayList<UserRoleMenuPojo>(map.values());
		
		log.info("过滤后用户数据条数：" + list.size());
		
		String dateString = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		String userFileName = "HBAP-CN-A-HTSAHBCNCIPS-01.acct." + dateString + ".csv";

		StringBuffer sb = new StringBuffer();
		sb.append("account_id,").append("person_id,")
				.append("native_first_name,").append("native_middle_name,")
				.append("native_last_name,").append("last_login_timestamp,")
				.append("creation_timestamp,").append("account_type,")
				.append("account_status,").append("native_account_status,")
				.append("system_id,").append("system_region,")
				.append("system_entity").append("\r\n");
		
		for (UserRoleMenuPojo pojo : list) {
			String acctId = checkAcctId(pojo.getAccountname());
			String personId = checkPersonId(pojo.getAccountname());
			if(!"".equals(acctId) && !"".equals(personId)){
				sb.append(acctId + ",").append(personId + ",")
				.append(checkStr(pojo.getCreateusername()) + ",").append(",").append(",")
				.append(checkDate(pojo.getLastlogintime()) + ",").append(checkDate(pojo.getCreatedate()) + ",")
				.append("User,").append(checkStatus(pojo.getUserstate()) + ",")
				.append(",").append("HBAP-CN-A-HTSAHBCNCIPS-01,").append("HBCN,").append("CN").append("\r\n");
				num ++;
			}
		}
		log.info("共导出[{}]条数据", userList.size());
		log.info("实际写文件[{}]条数据", num);
		sb.append("TRAILER,").append(new SimpleDateFormat("MMddyyyyHHmmss").format(new Date())+ ",").append(num);

		if(exportCsv(new File(filePath  + "/" + userFileName), sb.toString())){
	    	log.info("用户用户信息数据导出成功，对应文件信息[{}]", filePath  + "/" + userFileName);
	    } else {
	    	log.info("用户用户信息数据导出失败！");
	    }
	}
	
	/**
	 * 导出用户角色数据
	 * @throws IOException
	 */
	public void exprotUserRoleDate(String filePath){
		log.info("开始导出用户角色信息数据");
		String querySql = "select a.accountname as accountname,b.rolename as roleName from Tsys_User a,Tsys_Role b,Tsys_User_Role c " +
				"where a.id = c.user_id and b.id = c.role_id group by a.accountname,b.rolename";
		int num = 0;
		List<UserRoleMenuPojo> userRoleList = DBUtil.selectListBySql(UserRoleMenuPojo.class, querySql);
		if (userRoleList == null || userRoleList.isEmpty()) {
			log.error("查询用户角色信息数据为空");
		}
		
		String dateString = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		String userRoleFileName = "HBAP-CN-A-HTSAHBCNCIPS-01.entl." + dateString + ".csv";
		
		StringBuffer sb = new StringBuffer();
		sb.append("account_id,").append("system_id,").append("account_source,").
			append("entitlement_type,").append("system_profile,").append("entitlement,").append("action").append("\r\n");
		Dictionaries.init();
		for (UserRoleMenuPojo pojo : userRoleList) {
			String roleName = roleNamecheck(pojo.getRoleName());
			String acctId = checkAcctId(pojo.getAccountname());
			if(!"".equals(roleName) && !"".equals(acctId)){
				sb.append(acctId + ",").append("HBAP-CN-A-HTSAHBCNCIPS-01,").append("System,").append("P,")
				.append(roleName + ",").append(",").append("").append("\r\n");
				num ++;
			}
		}
		log.info("共导出[{}]条数据", userRoleList.size());
		log.info("实际写文件[{}]条数据", num);
		sb.append("TRAILER,").append(new SimpleDateFormat("MMddyyyyHHmmss").format(new Date())+ ",").append(num);
		
	    if(exportCsv(new File(filePath  + "/" + userRoleFileName), sb.toString())){
	    	log.info("用户角色信息数据导出成功，对应文件信息[{}]", filePath  + "/" + userRoleFileName);
	    } else {
	    	log.info("用户角色信息数据导出失败！");
	    }
	}


	/**
	 * 导出角色权限菜单数据
	 * @param filePath
	 */
	public void exprotRoleMenuPojo(String filePath) {
		log.info("开始导出角色权限菜单数据");
		String querySql = "select t.rolename as roleName, m.id as meunName from " +
				"(select a.rolename, b.privilege_id from Tsys_Role a, Tsys_Role_Privilege b where a.id = b.role_id) t, " +
				"TSYS_MENU m, Tsys_Privilege_Menu p " +
				"where t.privilege_id = p.privilege_id and p.meun_id = m.id group by t.rolename, m.id";
		int num = 0;
		List<UserRoleMenuPojo> userRoleList = DBUtil.selectListBySql(UserRoleMenuPojo.class, querySql);
		if (userRoleList == null || userRoleList.isEmpty()) {
			log.error("查询角色权限菜单信息数据为空");
		}
		
		String dateString = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		String roleMenuFileName = "HBAP-CN-A-HTSAHBCNCIPS-01.smod." + dateString + ".csv";
		
		StringBuffer sb = new StringBuffer();
		sb.append("system_id,").append("system_profile,").append("security_definition_type,").
			append("system_profile_child,").append("entitlement,").append("action").append("\r\n");
		Dictionaries.init();
		for (UserRoleMenuPojo pojo : userRoleList) {
			String roleName = roleNamecheck(pojo.getRoleName());
			String menuName = menuNamecheck(pojo.getMeunName());
			if(!"".equals(roleName) && !"".equals(menuName)){
				sb.append("HBAP-CN-A-HTSAHBCNCIPS-01,").append(roleName + ",").append("E,").append(",")
				.append(menuName + ",").append("").append("\r\n");
				num ++;
			}
		}
		log.info("共导出[{}]条数据", userRoleList.size());
		log.info("实际写文件[{}]条数据", num);
		sb.append("TRAILER,").append(new SimpleDateFormat("MMddyyyyHHmmss").format(new Date())+ ",").append(num);
		
	    if(exportCsv(new File(filePath  + "/" + roleMenuFileName), sb.toString())){
	    	log.info("角色权限菜单数据导出成功，对应文件信息[{}]", filePath  + "/" + roleMenuFileName);
	    } else {
	    	log.info("角色权限菜单数据导出失败");
	    }
	}
	
	/**
	 * 导出文件
	 * @param file
	 * @param data
	 * @return
	 */
	public boolean exportCsv(File file, String data) {
		boolean isSucess = false;

		FileOutputStream out = null;
		OutputStreamWriter osw = null;
		BufferedWriter bw = null;
		try {
			out = new FileOutputStream(file);
			osw = new OutputStreamWriter(out, "GB2312");
			bw = new BufferedWriter(osw);
			bw.write(data);

			bw.flush();
			isSucess = true;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("文件生成失败：" + e.getMessage());
			isSucess = false;
		} finally {
			if (bw != null) {
				try {
					bw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (osw != null) {
				try {
					osw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return isSucess;
	}
	
	/**
	 * sftp上传文件
	 * @param uploadFile
	 * @param saveFile
	 * @throws Exception
	 */
	public void sFtpUploadFile(String uploadFile,String saveFile) throws Exception{
		log.info("开始上传tar文件：目标文件[{}]，目标文件名称[{}],目标文件上传路径[{}]", uploadFile, saveFile, Constant.sftpPath);
		try {
			SFTPBean sftpBean = new SFTPBean();
			
			sftpBean.setHost(Constant.sftpIp);
			sftpBean.setPort(Integer.parseInt(Constant.sftpPort));
			sftpBean.setUsername(Constant.sftpUserName);
			sftpBean.setPassword(Constant.sftpPassWord);
			sftpBean.setTimeout(Integer.parseInt(Constant.sftoTimeOut));
			sftpBean.setPrivateKey(null);
			sftpBean.setPassphrase(null);
			SFTPUtils sftp = new SFTPUtils(sftpBean);
			
			sftp.upload(uploadFile , Constant.sftpPath, saveFile);
			log.info("文件上传成功");
		} catch (Exception e) {
			e.printStackTrace();
			log.error("SFTP上传文件异常：" + e.getMessage());
			throw new Exception("SFTP上传文件异常：" + e.getMessage());
		}finally{
			SFTPUtils.release();
		}
	}
	
	public String checkPersonId(String personId){
		if(null == personId || personId.trim().length() == 0){
			return "";
		} else if (personId.length() > 8){
			String acct = personId.substring(0, 8);
			if(isNum(acct)){
				return acct;
			}else{
				return "";
			}
		} else {
			if(isNum(personId)){
				return personId;
			}else{
				return "";
			}
		}
	}
	
	public String checkAcctId(String acctId){
		if(null == acctId || acctId.trim().length() == 0){
			return "";
		} else if (acctId.length() > 8){
			String acct = acctId.substring(0, 8);
			if(isNum(acct)){
				return acctId;
			}else{
				return "";
			}
		} else {
			if(isNum(acctId)){
				return acctId;
			}else{
				return "";
			}
		}
	}

	public String checkStr(String strText) {
		if (null == strText || strText.trim().length() == 0) {
			return "";
		} else {
			return strText;
		}
	}
	
	
	public String roleNamecheck(String strText) {
		if (null == strText || strText.trim().length() == 0) {
			return "";
		} else {
			if(isContainChinese(strText)){
				String roleName = Dictionaries.roleMap.get(strText);
				if(null == roleName || roleName.trim().length() == 0){
					return "";
				} else {
					return roleName;
				}
			} else {
				return strText;
			}
		}
	}
	
/*	public String roleNamecheck(String strText) {
		if (null == strText || strText.trim().length() == 0) {
			return "";
		} else {
			String roleName = Dictionaries.roleMap.get(strText);
			if(null == roleName || roleName.trim().length() == 0){
				return "";
			} else {
				return roleName;
			}
		}
	}*/
	
	public String menuNamecheck(String strText) {
		if (null == strText || strText.trim().length() == 0) {
			return "";
		} else {
			String roleMenu = Dictionaries.menuMap.get(strText);
			if(null == roleMenu || roleMenu.trim().length() == 0){
				return "";
			} else {
				return roleMenu;
			}
		}
	}

	public String checkStatus(String strText) {
		if (null == strText || strText.trim().length() == 0) {
			return "";
		} else {
			if ("stop".equals(strText)) {
				return "disable";
			} else {
				return "Active";
			}
		}
	}

	public String checkDate(Date date) {
		if (null == date) {
			return "";
		}
		SimpleDateFormat format = new SimpleDateFormat("MMddyyyyHHmmss");
		try {
			return format.format(date);
		} catch (Exception e) {
			return "";
		}
	}
	
	/**
	 * 判断当前目录文件是否存在，存在则把下面子文件全删除，不存在则新建目录
	 * @param f
	 */
	public void isExsitFilePath(File f) {
		if (f == null) {
			return;
		} else if (f.exists()) {// 如果此抽象指定的对象存在并且不为空。
			/*if (f.isFile()) {
				f.delete();// 如果此抽象路径代表的是文件，直接删除。
			} else if (f.isDirectory()) {// 如果此抽象路径指代的是目录
				String[] str = f.list();// 得到目录下的所有路径
				if (str == null) {
					f.delete();// 如果这个目录下面是空，则直接删除
				} else {// 如果目录不为空，则遍历名字，得到此抽象路径的字符串形式。
					for (String st : str) {
						isExsitFilePath(new File(f, st));
					}// 遍历清楚所有当前文件夹里面的所有文件。
					//f.delete();// 清楚文件夹里面的东西后再来清楚这个空文件夹
				}
			}*/
		}else{
			f.mkdir();
		}
	}
	
	public static boolean isContainChinese(String str) {
		//String regex = "^[a-z0-9A-Z\u4e00-\u9fa5]+$";//其他需要，直接修改正则表达式就好
		Pattern p = Pattern.compile("[\u4e00-\u9fa5]");
		Matcher m = p.matcher(str);
		if (m.find()) {
			return true;
		}
		return false;
	}
	
	public static boolean isNum(String str) {
		Pattern pattern = Pattern.compile("[0-9]*");
	    return pattern.matcher(str).matches();
		//String regex = "^[a-z0-9A-Z\u4e00-\u9fa5]+$";//其他需要，直接修改正则表达式就好
	}
	
	public static void main(String[] args) {
		System.out.println(isNum("12345"));
	}
}

