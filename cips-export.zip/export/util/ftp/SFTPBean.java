
package com.ylink.export.util.ftp;

public class SFTPBean {
	
	String host; 
	int port; 
	String username; 
	String password; 
	int timeout;
	String privateKey;
	String passphrase;
	
	public void setHost(String host){
		this.host = host;
	}
	public String getHost(){
		return this.host;
	}
	
	public void setPort(int port){
		this.port = port;
	}
	public int getPort(){
		return this.port;
	}
	
	public void setUsername(String username){
		this.username = username;
	}
	public String getUsername(){
		return this.username;
	}
	
	public void setPassword(String password){
		this.password = password;
	}
	public String getPassword(){
		return this.password;
	}
	
	public void setTimeout(int timeout){
		this.timeout = timeout;
	}
	public int getTimeout(){
		return this.timeout;
	}
	
	public void setPrivateKey(String privateKey){
		this.privateKey = privateKey;
	}
	public String getPrivateKey(){
		return this.privateKey;
	}
	
	public void setPassphrase(String passphrase){
		this.passphrase = passphrase;
	}
	public String getPassphrase(){
		return this.passphrase;
	}
}
