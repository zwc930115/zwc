/**
 * 版权所有(C) 2016 深圳市雁联计算系统有限公司
 * 创建:Administrator 2016-4-18
 */

package com.ylink.export.util.ftp;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

/**
 * @author Administrator
 * @date 2016-4-18
 * @description：TODO
 */

public class SFTPUtils {
	
	private final static Logger logger = LoggerFactory.getLogger(SFTPUtils.class);

	/** 规避多线程并发 */
	private static ThreadLocal<SFTPUtils> sftpLocal = new ThreadLocal<SFTPUtils>();

	private ChannelSftp channelSftp = null;
	private Channel channel = null;
	private Session session = null;

	/**
	 * 获取本地线程存储的sftp客户端
	 * @return
	 * @throws Exception
	 */
	public static SFTPUtils getSftpUtil(SFTPBean sftpBean) throws Exception {
		SFTPUtils sftpUtil = sftpLocal.get();
		if (null == sftpUtil || !sftpUtil.isConnected()) {
			sftpUtil = new SFTPUtils(sftpBean);

			sftpLocal.set(sftpUtil);
		}
		return sftpLocal.get();
	}

	/**
	 * 释放本地线程存储的sftp客户端
	 */
	public static void release() {
		if (null != sftpLocal.get()) {
			sftpLocal.get().disconnect();
			sftpLocal.set(null);
		}
	}

	/**
	 * 构造函数
	 * <p>
	 * 非线程安全，故权限为私有
	 * </p>
	 * 
	 * @throws Exception
	 */
	public SFTPUtils(SFTPBean sftpBean) throws Exception {
		super();
		connect(sftpBean);
	}

	/**
	 * 利用JSch包实现SFTP下载、上传文件
	 * 
	 * @param host
	 *            主机host
	 * @param username
	 *            主机登陆用户名
	 * @param password
	 *            主机登陆密码
	 * @param port
	 *            主机ssh2登陆端口，如果取默认值(默认值22)，传-1
	 * @param timeout
	 *            超时时间
	 * @param privateKey
	 *            密钥文件路径
	 * @param passphrase
	 *            密钥的密码
	 * 
	 */
	private void connect(SFTPBean sftpBean) throws Exception {
		JSch jsch = null;
		try {

			jsch = new JSch();

			// 设置密钥和密码
			if (sftpBean.getPrivateKey() != null
					&& !"".equals(sftpBean.getPrivateKey())) {
				if (sftpBean.getPassphrase() != null
						&& "".equals(sftpBean.getPassphrase())) {
					// 设置带口令的密钥
					jsch.addIdentity(sftpBean.getPrivateKey(),
							sftpBean.getPassphrase());
				} else {
					// 设置不带口令的密钥
					jsch.addIdentity(sftpBean.getPrivateKey());
				}
			}

			if (sftpBean.getPort() <= 0) {
				// 连接服务器，采用默认端口
				session = jsch.getSession(sftpBean.getUsername(),
						sftpBean.getHost());
			} else {
				// 采用指定的端口连接服务器
				session = jsch.getSession(sftpBean.getUsername(),
						sftpBean.getHost(), sftpBean.getPort());
			}
			// 如果服务器连接不上，则抛出异常
			if (session == null) {
				throw new Exception("session is null");
			}
			logger.info("Session created.");

			// 设置登陆主机的密码
			session.setPassword(sftpBean.getPassword());// 设置密码
			// 设置第一次登陆的时候提示，可选值：(ask | yes | no)
			Properties sshConfig = new Properties();
			sshConfig.put("StrictHostKeyChecking", "no");
			session.setConfig(sshConfig);
			// 设置登陆超时时间
			session.connect(sftpBean.getTimeout());
			logger.info("Session connected.");
			channel = session.openChannel("sftp");
			channel.connect();
			logger.info("Opening Channel.");
			channelSftp = (ChannelSftp) channel;
			logger.info("Connected to " + sftpBean.getHost() + ".");
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			throw new Exception(e.getMessage());
		}
	}

	/**
	 * 关闭sftp服务器连接
	 * @return
	 */
	private void disconnect() {
		try {
			if (channelSftp != null) {
				if (channelSftp.isConnected()) {
					channelSftp.disconnect();
				} else if (channelSftp.isClosed()) {
					logger.info("sftp is closed already");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		}

		try {
			if (session != null) {
				session.disconnect();
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		}

		try {
			if (channel != null) {
				channel.disconnect();
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		}
	}

	/**
	 * 是否已连接
	 * 
	 * @return
	 */
	private boolean isConnected() {
		return null != channel && channel.isConnected();
	}

	@SuppressWarnings("static-access")
	private boolean isDirExist(String directory, ChannelSftp sftp)
			throws Exception {
		boolean isDirExistFlag = false;
		try {
			sftp.cd(directory);
			isDirExistFlag = true;
		} catch (SftpException sException) {
			if (sftp.SSH_FX_NO_SUCH_FILE == sException.id) {
				isDirExistFlag = false;
			} else {
				throw new Exception("SFTP检查是否为已存在的目录错误："
						+ sException.getMessage());
			}
		} catch (Exception e) {
			throw new Exception("SFTP检查是否为已存在的目录错误：" + e.getMessage());
		}
		return isDirExistFlag;
	}

	/**
	 * 创建一个文件目录
	 * 
	 * @param rfilepath
	 * @param sftp
	 * @author fengbo 20140226
	 */
	private void createDir(String createpath, ChannelSftp sftp)
			throws Exception {
		try {
			if (isDirExist(createpath, sftp)) {
				return;
			}
			String pathArry[] = createpath.split("/");
			// StringBuffer filePath = new StringBuffer("/"); 如果放开则为根目录
			StringBuffer filePath = new StringBuffer("");
			for (String path : pathArry) {
				if (path.equals("")) {
					continue;
				}
				filePath.append(path + "/");
				logger.info("当前目录:" + filePath);
				if (isDirExist(path.toString(), sftp)) {
					logger.info("当前目录存在,进入当前目录:" + filePath.toString());
					// sftp.cd(path.toString());
					logger.info("执行成功:" + filePath);
				} else {
					logger.info("当前目录不存在,创建当前目录:" + filePath.toString());
					// 建立目录
					sftp.mkdir(path.toString());
					// 进入并设置为当前目录
					sftp.cd(path.toString());
					logger.info("执行成功:" + filePath.toString());
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("创建路径错误：" + e.getMessage());

		}
	}

	private boolean renameFileName(String domains, String oldfilename,
			String newfilename, ChannelSftp sftp) throws Exception {
		boolean isDirExistFlag = false;
		try {
			if (domains != null && domains.trim().length() > 0) {
				sftp.cd(domains);
			}
			sftp.rename(oldfilename, newfilename);
			isDirExistFlag = true;
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("SFTP修改文件名错误：" + e.getMessage());
		}
		return isDirExistFlag;
	}

	/**
	 * 利用JSch包实现SFTP下载文件
	 * 
	 * @param host
	 *            主机IP
	 * @param username
	 *            主机登陆用户名
	 * @param password
	 *            主机登陆密码
	 * @param port
	 *            主机ssh2登陆端口，如果取默认值，传-1
	 * @param timeout
	 *            登陆超时时间
	 * @param domains
	 *            登陆目录
	 * @param oldfilename
	 *            被修改的文件名
	 * @param newfilename
	 *            修改后的文件名
	 */
	public boolean rename(String domains, String oldfilename, String newfilename) throws Exception {
		boolean isDirExistFlag = false;
		try {
			isDirExistFlag = renameFileName(domains, oldfilename, newfilename,
					channelSftp);
		} catch (Exception e) {
			throw new Exception("SFTP修改文件名错误：" + e.getMessage());
		}
		return isDirExistFlag;
	}

	/**
	 * 利用JSch包实现SFTP下载文件
	 * 
	 * @param host
	 *            主机IP
	 * @param username
	 *            主机登陆用户名
	 * @param password
	 *            主机登陆密码
	 * @param port
	 *            主机ssh2登陆端口，如果取默认值，传-1
	 * @param timeout
	 *            登陆超时时间
	 * @param domains
	 *            登陆目录
	 * @param downloadFile
	 *            被下载的远程服务器的文件名
	 * @param saveFile
	 *            下传到本地服务器的文件名
	 */
	public void download(String domains, String downloadFile, String saveFile) throws Exception {
		InputStream instream = null;
		OutputStream outstream = null;
		try {
			channelSftp.cd(domains);
			File file = new File(saveFile);
			outstream = new FileOutputStream(file);

			// InputStream is = sftp.get(downloadFile, new MyProgressMonitor());
			instream = channelSftp.get(downloadFile);
			byte[] buff = new byte[1024 * 2];
			int read;
			if (instream != null) {
				logger.info("Start to read input stream");

				while ((read = instream.read(buff, 0, buff.length)) > 0) {
					outstream.write(buff, 0, read);
					outstream.flush();
				}

				logger.info("input stream read done.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		} finally {
			try {
				if (instream != null) {
					instream.close();
					instream = null;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if (outstream != null) {
					outstream.close();
					outstream = null;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 利用JSch包实现SFTP上传文件
	 * 
	 * @param host
	 *            主机IP
	 * @param username
	 *            主机登陆用户名
	 * @param password
	 *            主机登陆密码
	 * @param port
	 *            主机ssh2登陆端口，如果取默认值，传-1
	 * @param timeout
	 *            登陆超时时间
	 * @param domains
	 *            登陆目录
	 * @param uploadFile
	 *            被上传的本地文件名
	 * @param saveFile
	 *            上传到服务器的文件名
	 */
	public void upload(String uploadFile, String domains, String saveFile) throws Exception {
		OutputStream outstream = null;
		InputStream instream = null;
		try {
			createDir(domains, channelSftp);
			// 以下代码实现从本地上传一个文件到服务器，如果要实现下载，对换以下流就可以了
			instream = new FileInputStream(new File(uploadFile));
			/*
			 * OVERWRITE
			 * 完全覆盖模式，这是JSch的默认文件传输模式，即如果目标文件已经存在，传输的文件将完全覆盖目标文件，产生新的文件。 RESUME
			 * 恢复模式，如果文件已经传输一部分，这时由于网络或其他任何原因导致文件传输中断，如果下一次传输相同的文件，
			 * 
			 * 则会从上一次中断的地方续传。
			 * 
			 * APPEND 追加模式，如果目标文件已存在，传输的文件将在目标文件后追加。
			 */
			outstream = channelSftp.put(saveFile, ChannelSftp.OVERWRITE); // 使用OVERWRITE模式
			byte[] buff = new byte[1024 * 256]; // 设定每次传输的数据块大小为256KB
			int read;
			if (outstream != null) {
				logger.info("Start to read input stream");
				while ((read = instream.read(buff, 0, buff.length)) > 0) {
					outstream.write(buff, 0, read);
					outstream.flush();
				}
				logger.info("input stream read done.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			throw new Exception(e.getMessage());
		} finally {
			try {
				if (outstream != null) {
					outstream.close();
					outstream = null;
				}
			} catch (Exception e) {
			}
			try {
				if (instream != null) {
					instream.close();
					instream = null;
				}
			} catch (Exception e) {
			}
		}
	}

	public void uploadByRename(String uploadFile, String domains, String saveFile) throws Exception {
		OutputStream outstream = null;
		InputStream instream = null;
		String saveFileTemp = null;
		try {
			saveFileTemp = "tmp_" + saveFile;
			
			createDir(domains, channelSftp);
			// 以下代码实现从本地上传一个文件到服务器，如果要实现下载，对换以下流就可以了
			instream = new FileInputStream(new File(uploadFile));
			/*
			 * OVERWRITE
			 * 完全覆盖模式，这是JSch的默认文件传输模式，即如果目标文件已经存在，传输的文件将完全覆盖目标文件，产生新的文件。 RESUME
			 * 恢复模式，如果文件已经传输一部分，这时由于网络或其他任何原因导致文件传输中断，如果下一次传输相同的文件，
			 * 
			 * 则会从上一次中断的地方续传。
			 * 
			 * APPEND 追加模式，如果目标文件已存在，传输的文件将在目标文件后追加。
			 */
			outstream = channelSftp.put(saveFileTemp, ChannelSftp.OVERWRITE); // 使用OVERWRITE模式
			byte[] buff = new byte[1024 * 256]; // 设定每次传输的数据块大小为256KB
			int read;
			if (outstream != null) {
				logger.info("Start to read input stream");
				while ((read = instream.read(buff, 0, buff.length)) > 0) {
					outstream.write(buff, 0, read);
					outstream.flush();
				}
				logger.info("input stream read done.");
			}

			if (!renameFileName(domains, saveFileTemp, saveFile, channelSftp)) {
				throw new Exception("上次文件错误，修改名称异常");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			throw new Exception(e.getMessage());
		} finally {
			try {
				if (outstream != null) {
					outstream.close();
					outstream = null;
				}
			} catch (Exception e) {
			}
			try {
				if (instream != null) {
					instream.close();
					instream = null;
				}
			} catch (Exception e) {
			}
		}
	}

	public static void main(String[] args) {
		try {
			SFTPBean sftpBean = new SFTPBean();
			sftpBean.setHost("168.33.98.96");
			sftpBean.setPort(-1);
			sftpBean.setUsername("root");
			sftpBean.setPassword("root");
			sftpBean.setTimeout(1000);
			sftpBean.setPrivateKey(null);
			sftpBean.setPassphrase(null);
			SFTPUtils SFTPUtils = getSftpUtil(sftpBean);
			SFTPUtils.download("log", "param.sh", "e:/xxxparam.sh");
			//SFTPUtils.upload("e:/xxxparam.sh", "text/1/", "xxxparam.sh");
			//SFTPUtils.uploadByRename("e:/xxxparam.sh", "text/1/", "xxxparam.sh");
			release();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	   //获取SFTP文件列表          
    @SuppressWarnings("unchecked")
	public List<String> getFileNameList(String remotePath) throws Exception
    {
            java.util.Vector<LsEntry> vvv = channelSftp.ls(remotePath);
            ArrayList<String> objList = new ArrayList<String>();
            for (LsEntry lsEntry : vvv) {
            	String fileName =lsEntry.getFilename();
            	objList.add(fileName);
            }
            return objList;
    }

	public boolean downloads(String ftpServerBaseDir,
			List<String> resultFileNameList, String localdownloadDir) throws Exception {
		// TODO Auto-generated method stub
		for (String downloadFile : resultFileNameList) {
			this.download(ftpServerBaseDir, downloadFile, localdownloadDir+"/"+downloadFile);
		}
		return false;
	}

}
