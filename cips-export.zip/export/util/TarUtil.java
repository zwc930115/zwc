package com.ylink.export.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
/**
 * 将目标文件夹下面的所有文件打包成tar包，tar包目录和最底层文件夹同名，tar包存放目录与最底层文件夹同一级
 * @author Lzp
 * @date 2018-01-20
 */
public class TarUtil {
	
	/**
     * 归档
     * @param entry
     * @throws IOException
     * @author yutao
     * @return 
     * @date 2017年5月27日下午1:48:23
     */
    public static String archive(String fileName) throws IOException {
        File file = new File(fileName);
        TarArchiveOutputStream tos = new TarArchiveOutputStream(new FileOutputStream(file.getAbsolutePath() + ".tar"));
        String base = file.getName();
        if(file.isDirectory()){
            archiveDir(file, tos, base);
        }else{
            archiveHandle(tos, file, base);
        }

        tos.close();
        return file.getAbsolutePath() + ".tar";
    }

/**
     * 递归处理，准备好路径
     * @param file
     * @param tos
     * @param base 
     * @throws IOException
     */
    public static void archiveDir(File file, TarArchiveOutputStream tos, String basePath) throws IOException {
        File[] listFiles = file.listFiles();
        for(File fi : listFiles){
            if(fi.isDirectory()){
                archiveDir(fi, tos, basePath + File.separator + fi.getName());
            }else{
                archiveHandle(tos, fi, basePath);
            }
        }
    }

/**
     * 具体归档处理（文件）
     * @param tos
     * @param fi
     * @param base
     * @throws IOException
     */
    public static void archiveHandle(TarArchiveOutputStream tos, File fi, String basePath) throws IOException {
        TarArchiveEntry tEntry = new TarArchiveEntry(basePath + File.separator + fi.getName());
        tEntry.setSize(fi.length());

        tos.putArchiveEntry(tEntry);

        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(fi));

        byte[] buffer = new byte[1024];
        int read = -1;
        while((read = bis.read(buffer)) != -1){
            tos.write(buffer, 0 , read);
        }
        bis.close();
        tos.closeArchiveEntry();//这里必须写，否则会失败
    }

}
