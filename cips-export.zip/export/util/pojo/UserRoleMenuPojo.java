package com.ylink.export.util.pojo;

import java.util.Date;

import com.ylink.export.annotation.Column;
import com.ylink.export.annotation.JdbcType;

/**
 * 公共查询返回对象
 * 
 * @author lzp
 * @date 2017-11-30
 */
public class UserRoleMenuPojo {

	// 用户
	@Column(name = "userId", jdbcType = JdbcType.VARCHAR)
	private String userId;

	// 角色名称
	@Column(name = "roleName", jdbcType = JdbcType.VARCHAR)
	private String roleName;

	// 菜单名称
	@Column(name = "meunName", jdbcType = JdbcType.VARCHAR)
	private String meunName;

	/**
	 * ACCOUNTNAME 账户名 VARCHAR2 60
	 */
	@Column(name = "ACCOUNTNAME", jdbcType = JdbcType.VARCHAR)
	private String accountname;

	/**
	 * LASTLOGINTIME 最后登录时间 DATE 7
	 */
	@Column(name = "LASTLOGINTIME", jdbcType = JdbcType.TIMESTAMP)
	private Date lastlogintime;

	/**
	 * CREATEUSERNAME 创建者 VARCHAR2 60
	 */
	@Column(name = "CREATEUSERNAME", jdbcType = JdbcType.VARCHAR)
	private String createusername;

	/**
	 * CREATEDATE 创建日期 DATE 7
	 */
	@Column(name = "CREATEDATE", jdbcType = JdbcType.TIMESTAMP)
	private Date createdate;

	/**
	 * USERSTATE 用户状态 1：待复核 2：正常 3：停用 VARCHAR2 10
	 */
	@Column(name = "USERSTATE", jdbcType = JdbcType.VARCHAR)
	private String userstate;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getMeunName() {
		return meunName;
	}

	public void setMeunName(String meunName) {
		this.meunName = meunName;
	}

	public String getAccountname() {
		return accountname;
	}

	public void setAccountname(String accountname) {
		this.accountname = accountname;
	}

	public Date getLastlogintime() {
		return lastlogintime;
	}

	public void setLastlogintime(Date lastlogintime) {
		this.lastlogintime = lastlogintime;
	}

	public String getCreateusername() {
		return createusername;
	}

	public void setCreateusername(String createusername) {
		this.createusername = createusername;
	}

	public Date getCreatedate() {
		return createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public String getUserstate() {
		return userstate;
	}

	public void setUserstate(String userstate) {
		this.userstate = userstate;
	}

}
