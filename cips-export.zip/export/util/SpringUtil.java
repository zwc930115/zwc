package com.ylink.export.util;

import java.util.Map;

import org.springframework.context.ApplicationContext;
/**
 * 
 * 类描述： spring帮助类
 * 创建者： zhangls
 * 项目名称： cips-sim-server
 * 创建时间： 2014-12-30 下午4:07:13
 * 版本号： v1.0
 */
public class SpringUtil {
	
	public static ApplicationContext ctx; 
	
	/**
	 * 根据Bean的名称
	 * 
	 * @param beanName bean名称
	 * @param clazz Class
	 * @return T
	 */
	public static <T> T getBean(String beanName, Class<T> clazz) {
		return getBean(beanName, clazz, ctx);
	}
	
	
	/**
	 * 根据Bean的名称
	 * 
	 * @param beanName bean名称
	 * @param clazz Class
	 * @param applicationContext 应用上下文
	 * @return T
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getBean(String beanName, Class<T> clazz, 
			ApplicationContext applicationContext) {
		if (beanName == null || beanName.trim().length() == 0) {
			return null;
		}
		try {
			Object obj = applicationContext.getBean(beanName);
			if (null == obj) {
				return null;
			}
			return (T) obj;
		} catch(Exception e) {
			return null;
		}
	}
	
	/**
	 * 根据Bean的名称或接口获取Bean
	 * 
	 * @param beanName bean名称
	 * @param clazz Class
	 * @return T
	 */
	public static <T> T getBeanWithInterface(String beanName, Class<T> clazz) {
		return getBeanWithInterface(beanName, clazz, ctx);
	}
	
	
	/**
	 * 根据Bean的名称或接口获取Bean
	 * 
	 * @param beanName bean名称
	 * @param clazz Class
	 * @param applicationContext 应用上下文
	 * @return T
	 */
	public static <T> T getBeanWithInterface(String beanName, Class<T> clazz, 
			ApplicationContext applicationContext) {
		T t = getBean(beanName, clazz, applicationContext);
		if (null == t) {
			Map<String, T> beans = getBeans(clazz, applicationContext);
			if (beans == null || beans.isEmpty()) {
				return null;
			}
			t = beans.values().iterator().next();
		}
		return t;
	}
	
	/**
	 * 获取子类或实现类
	 * 
	 * @param clazz  Class<T> 基类或接口
	 * @param applicationContext 应用上下文
	 * @return Map<String,T>
	 */
	public static <T> Map<String,T> getBeans(Class<T> clazz, 
			ApplicationContext applicationContext) {
		Map<String, T> t = null;
		try {
			t = applicationContext.getBeansOfType(clazz);
		} catch (Exception e) {
			
		}
		
		return t;
	}
	
	/**
	 * spring getBean
	 * @param 根据spring配置的bean名称那么获取bean（如果未指定名称，默认为首字母小写）
	 * @return Object
	 */
	public static Object getBean(String beanName) {
		Object o = null;
		try {
			o = ctx.getBean(beanName);
		} catch (Exception e) {
			
		}
		return o;
	}
	
	
	/**
	 * spring getBean 
	 * @param 根据类的class获取类的bean
	 * @return 返回指定泛型
	 */
	public static <T> T getBean(Class<T> beanClass) {
		T t = null;
		try {
			t = ctx.getBean(beanClass);
		} catch(Exception e) {
			
		}
		return t;
	}

	
	/**
	 * spring getBeans 
	 * @param 根据当前类
	 * @param Class<T>  转为成指定类型
	 * @return 返回指定泛型
	 */
	public static <T> Map<String, T> getBeans(Class<T> clazz) {
		Map<String, T> t = null;
		try {
			t = ctx.getBeansOfType(clazz);
		} catch(Exception e) {
			
		}
		return t;
	}
	
}
