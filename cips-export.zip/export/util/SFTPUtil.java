package com.ylink.export.util;

import com.jcraft.jsch.*;

import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by apple on 2018/1/20.
 */
public class SFTPUtil {

	private static Logger log = LoggerFactory.getLogger(SFTPUtil.class);

    public static  String SFTP_REQ_HOST = Constant.sftpIp;
    public static  String SFTP_REQ_PORT = Constant.sftpPort;
    public static  String SFTP_REQ_USERNAME = Constant.sftpUserName;
    public static  String SFTP_REQ_PASSWORD = Constant.sftpPassWord;
    public static String SFTP_PRIVATEKEY_PATH = Constant.sftPrivateKeyPath;
    public static String SFTP_PRIVATEKEY_PSW = Constant.sftpPrivateKeyPsw;
    public static String SFTP_PATH = Constant.sftpPath;
    public static final int SFTP_DEFAULT_PORT = 22;

    public static ChannelSftp getChannel( int timeout) throws JSchException {

         int ftpPort = SFTPUtil.SFTP_DEFAULT_PORT;
        if (SFTP_REQ_PORT != null && !SFTP_REQ_PORT.equals("")) {
            ftpPort = Integer.valueOf(SFTP_REQ_PORT);
        }

        JSch jsch = new JSch(); // 创建JSch对象

        Session session = jsch.getSession(SFTP_REQ_USERNAME, SFTP_REQ_HOST, ftpPort); // 根据用户名，主机ip，端口获取一个Session对象
        log.info("Session created.");
        if (SFTP_REQ_PASSWORD != null) {
            session.setPassword(SFTP_REQ_PASSWORD); // 设置密码
        }
        Properties config = new Properties();
        config.put("StrictHostKeyChecking", "no");
        session.setConfig(config); // 为Session对象设置properties
        session.setTimeout(timeout); // 设置timeout时间
        session.connect(); // 通过Session建立链接
        log.info("Session connected.");

        log.info("Opening Channel.");
        Channel  channel = session.openChannel("sftp"); // 打开SFTP通道
        channel.connect(); // 建立SFTP通道的连接
        log.info("Connected successfully to ftpHost = " + SFTP_REQ_HOST + ",as ftpUserName = " + SFTP_REQ_USERNAME
                + ", returning: " + channel);
        return (ChannelSftp) channel;
    }


    public static ChannelSftp getChannelByRSA( int timeout) throws JSchException {

        int ftpPort = SFTPUtil.SFTP_DEFAULT_PORT;
        if (SFTP_REQ_PORT != null && !SFTP_REQ_PORT.equals("")) {
            ftpPort = Integer.valueOf(SFTP_REQ_PORT);
        }

        JSch jsch = new JSch(); // 创建JSch对象
        log.info("privatekeypath = "+SFTP_PRIVATEKEY_PATH + "   and privatekey psw = "+ SFTP_PRIVATEKEY_PSW);
        if(SFTP_PRIVATEKEY_PSW==null||SFTP_PRIVATEKEY_PSW.trim().equals("")){
            jsch.addIdentity(SFTP_PRIVATEKEY_PATH);
        }else{
            jsch.addIdentity(SFTP_PRIVATEKEY_PATH,SFTP_PRIVATEKEY_PSW);
        }

        Session session = jsch.getSession(SFTP_REQ_USERNAME, SFTP_REQ_HOST, ftpPort); // 根据用户名，主机ip，端口获取一个Session对象
       log.info("Session created.");

        Properties config = new Properties();
        config.put("StrictHostKeyChecking", "no");
        session.setConfig(config); // 为Session对象设置properties
        session.setTimeout(timeout); // 设置timeout时间
        session.connect(); // 通过Session建立链接
        log.info("Session connected.");

        log.info("Opening Channel.");
        Channel  channel = session.openChannel("sftp"); // 打开SFTP通道
        channel.connect(); // 建立SFTP通道的连接
        log.info("Connected successfully to ftpHost = " + SFTP_REQ_HOST + ",as ftpUserName = " + SFTP_REQ_USERNAME
                + ", returning: " + channel);
        return (ChannelSftp) channel;
    }

    public static void upload(String src) throws Exception{
        ChannelSftp channelSftp = null;
        try {
        	log.info("sftp文件存放目录：" + SFTP_PATH);
            channelSftp  = getChannel(6000);
            channelSftp.put(src,SFTP_PATH);

            log.info("jsch sftp put success");
        } catch (JSchException e) {
            log.error("jsch sftp init fail!!!!!");
            e.printStackTrace();
            throw new Exception(e.getMessage());
        } catch (SftpException e) {
            log.error("jsch sftp put fail !!!!");
            e.printStackTrace();
            throw new Exception(e.getMessage());
        }finally {
            channelSftp.disconnect();
        }

    }


    public static  void upload4RSA(String src)throws Exception{
        ChannelSftp channelSftp = null;
        try {
        	log.info("sftp文件存放目录：" + SFTP_PATH);
            channelSftp  = getChannelByRSA(6000);
            channelSftp.put(src,SFTP_PATH);

            log.info("jsch sftp put success");
        } catch (JSchException e) {
            log.error("jsch sftp init fail!!!!!");
            e.printStackTrace();
            throw new Exception(e.getMessage());
        } catch (SftpException e) {
            log.error("jsch sftp put fail !!!!");
            e.printStackTrace();
            throw new Exception(e.getMessage());
        }finally {
            channelSftp.disconnect();
        }
    }


    public static void main(String args[]) throws Exception {
        SFTPUtil.upload4RSA("/Users/apple/Downloads/rsa");
    }
}
