package com.ylink.export.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 文件导出辅助参数
 * @author Lzp
 * @date 2018-01-20
 */
public class Constant {
	
	public static Logger log = LoggerFactory.getLogger(Constant.class);
	
	/**jdbc驱动*/
	public static String jdbcDriver = "oracle.jdbc.driver.OracleDriver";
	/**jdbc*/
	public static String jdbcUrl = "jdbc:oracle:thin:@172.168.65.164:1521:pdborcl";
	/**jdbc用户名*/
	public static String jdbcUserName = "cipstest";
	/**jdbc密码*/
	public static String jdbcPassWord = "cipstest";
	
	/**sftp地址*/
	public static String sftpIp = "172.168.65.164";
	/**sftp端口*/
	public static String sftpPort = "22";
	/**sftp用户名*/
	public static String sftpUserName = "";
	/**sftp密码*/
	public static String sftpPassWord = "";
	/**sftp超时时间*/
	public static String sftoTimeOut = "30000";

	/**SFTP秘钥路径*/
	public static String sftPrivateKeyPath="";
	/**SFTP秘钥密码*/
	public static  String sftpPrivateKeyPsw="";
	/**sftp访问路径*/
	public static String sftpPath = "/home/exportFile";
	
	/**本地临时文件存放路径*/
	public static final String localFilePath = "configure/exportFile/";
	
	public static void init(){
		log.info("开始加载导出文件所需参数");
		InputStream in = null;
		try {
			System.out.println(new File(".").getAbsolutePath());
			in = new FileInputStream("configure/properties/constant.properties");
			Properties p = new Properties();
			p.load(in);
			sftpIp = p.getProperty("sftpIp");
			sftpPort = p.getProperty("sftpPort");
			sftpUserName = p.getProperty("sftpUserName");
			sftpPassWord = p.getProperty("sftpPassWord");
			sftoTimeOut = p.getProperty("sftoTimeOut");
			sftpPath = p.getProperty("sftpPath");
			sftPrivateKeyPath = p.getProperty("sftpPrivateKeyPath");
			sftpPrivateKeyPsw = p.getProperty("sftpPrivateKeyPsw");
		} catch (Exception e) {
			e.printStackTrace();
			log.error("加载导出文件所需参数异常");
		}finally{
			if(null != in){
				try {
					in.close();
				} catch (IOException e) {
				}
			}
		}
	}
	
	static{
		init();
		//Dictionaries.init();
	}
	

}
