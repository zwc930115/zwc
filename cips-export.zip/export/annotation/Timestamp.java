package com.ylink.export.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @desc Oracle时间Timestamp注解
 * @author Someone
 *
 * @date 2016-08-18 19:37:00
 *
 */
@Target({ ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
public @interface Timestamp {

}
