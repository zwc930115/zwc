package com.ylink.export.annotation;

public enum CompareType {
	/**
	 * 左加LIKE%
	 */
	LIKE_LEFT("LIKE"),
	/**
	 * 右加LIKE%
	 */
	LIKE_RIGHT("LIKE"),
	/**
	 * 左右都加LIKE%
	 */
	LIKE_LEFT_AND_RIGHT("LIKE"),
	/**
	 * 等于
	 */
	EQ("="),
	/**
	 * 不等于
	 */
	NEQ("<>"),
	/**
	 * 大于
	 */
	GT(">"),
	/**
	 * 大于等于
	 */
	GT_EQ(">="),
	/**
	 * 小于等于
	 */
	LT_EQ("<="),
	/**
	 * 小于
	 */
	LT("<"),
	
	/**
	 * ISNULL
	 */
	ISNULL("IS NULL"),
	
	/**
	 * ISNULL
	 */
	ISNOTNULL("IS NOT NULL"),
	/**
	 * IN
	 */
	IN("IN"),
	/**
	 * NOT IN
	 */
	NOTIN("NOT IN");
	
	private String value;
	
	private CompareType(String value){
		this.value = value;
	}
	
	public String getValue(){
		return value;
	}
	
	/**
	 * 转换like的百分号
	 * @param val
	 * @return
	 */
	public String getLikeValue(String val) {
		if (val.contains("'")) {
			val = val.replace("'", "");
		}
		String likeString;
		switch (this) {
		case LIKE_LEFT:
			likeString = "%" + val;
			break;
		case LIKE_RIGHT:
			likeString = val + "%";
			break;
		case LIKE_LEFT_AND_RIGHT:
			likeString = "%" + val + "%";
			break;
		default:
			likeString = val;
			break;
		}
		return likeString;
	 }
}
