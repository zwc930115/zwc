package com.ylink.export.annotation;

/**
 * @desc JdbcTypeEnum
 * @author Someone
 *
 * @date 2016-09-11 17:28:26
 *
 */
public enum JdbcType {

	ID("ID"),
	CHAR("CHAR"),
	VARCHAR("VARCHAR"),
	LONGVARCHAR("LONGVARCHAR"),
	NUMERIC("NUMERIC"),
	DECIMAL("DECIMAL"),
	BIT("BIT"),
	BOOLEAN("BOOLEAN"),
	TINYINT("TINYINT"),
	SMALLINT("SMALLINT"),
	INTEGER("INTEGER"),
	BIGINT("BIGINT"),
	REAL("REAL"),
	FLOAT("FLOAT"),
	DOUBLE("DOUBLE"),
	BINARY("BINARY"),
	VARBINARY("VARBINARY"),
	LONGVARBINARY("LONGVARBINARY"),
	DATE("DATE"),
	TIME("TIME"),
	TIMESTAMP("TIMESTAMP"),
	CLOB("CLOB"),
	BLOB("BLOB"),
	ARRAY("ARRAY"),
	DISTINCT("DISTINCT"),
	STRUCT("STRUCT"),
	REF("REF"),
	DATALINK("DATALINK"),
	JAVA_OBJECT("JAVA_OBJECT"),
	;
	
	private String value;

	private JdbcType(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
